﻿Imports denaro.fis
Partial Class fetchquery
    Inherits System.Web.UI.Page
    Public vReturn As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Or Session("uid") = Nothing Then
            vReturn = "expired"
            Exit Sub
        End If

        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader

        Dim vDump As New StringBuilder
        Dim vDocAmount As String = ""
        Dim vString As String = ""

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vReturn = "error"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        cm.Connection = c

        Try
            cm.CommandText = "select Doc_Id, Doc_Name, Supplier_Cd, Date_Uploaded, Status_Cd, " & _
                "(select SupplierName from supplier where supplier.SupplierCd = dm_document.Supplier_Cd ) as SupName, " & _
                "(select Descr from dm_category where dm_category.Category_Id=dm_document.Category_Id ) as CatName,  " & _
                "(select Descr from dm_document_status where dm_document_status.Status_Cd=dm_document.Status_Cd ) as StatusName, " & _
                "(select Value from dm_document_dtl where Keyword_Id='37' and dm_document_dtl.Doc_Id=dm_document.Doc_Id ) as vAmount, " & _
                "(select Value from dm_document_dtl where Keyword_Id='20' and dm_document_dtl.Doc_Id=dm_document.Doc_Id ) as vRecFrom, " & _
                "(select Value from dm_document_dtl where Keyword_Id='35' and dm_document_dtl.Doc_Id=dm_document.Doc_Id ) as vVendor, " & _
                "(select Value from dm_document_dtl where Keyword_Id='38' and dm_document_dtl.Doc_Id=dm_document.Doc_Id ) as vRef, " & _
                "(select Value from dm_document_dtl where Keyword_Id='31' and dm_document_dtl.Doc_Id=dm_document.Doc_Id ) as vOtherInfo, " & _
                "Date_Encoded, Date_Created, SAP_Number from dm_document where Doc_Id=" & Request.Form("id")

            rs = cm.ExecuteReader
            If rs.Read Then
                If Not IsDBNull(rs("vAmount")) Then
                    If IsNumeric(rs("vAmount")) Then
                        vDocAmount = Format(Val(rs("vAmount").ToString.Replace(",", "")), "##,##0.00")
                    Else
                        vDocAmount = rs("vAmount")
                    End If
                Else
                    vDocAmount = "0.00"
                End If

                vReturn = rs("Status_Cd") & "~" & _
                    rs("Date_Uploaded") & "~" & _
                    IIf(IsDBNull(rs("vRecFrom")), "", rs("vRecFrom")) & "~" & _
                    rs("Doc_Name") & "~" & _
                    rs("SAP_Number") & "~" & _
                    rs("Supplier_Cd") & "~" & _
                    rs("SupName") & "~" & _
                    IIf(IsDBNull(rs("vVendor")), "", rs("vVendor")) & "~" & _
                    vDocAmount & "~" & _
                    IIf(IsDBNull(rs("vRef")), "", rs("vRef")) & "~" & _
                    rs("CatName") & "~" & _
                    rs("StatusName") & "~" & _
                    rs("vOtherInfo")

                vString = rs("Doc_Id") & "," & rs("Date_Uploaded") & ",""" & rs("vRecFrom") & """,""" & _
                    rs("Doc_Name") & """," & rs("SAP_Number") & "," & rs("Supplier_Cd") & ",""" & _
                    rs("SupName") & """,""" & rs("vVendor") & """,""" & _
                    vDocAmount & """," & _
                    rs("vRef") & "," & rs("CatName") & "," & rs("StatusName") & ",""" & rs("vOtherInfo") & """"

                vDump.AppendLine(vString)
            End If
            rs.Close()
            IO.File.AppendAllText(Server.MapPath(".") & "/downloads/" & Session.SessionID & "-QueriesReport.csv", vDump.ToString)
        Catch ex As SqlClient.SqlException
            vReturn = "error"
        Finally
            c.Close()
            c.Dispose()
            cm.Dispose()
        End Try
    End Sub
End Class
