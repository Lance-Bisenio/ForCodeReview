﻿Imports denaro.fis
Partial Class volumecount_getprev
    Inherits System.Web.UI.Page
    Public vResponse As String = ""
    Public vData As String = ""
    Private vRowId() As String = {"Invoices", "HDE", "HDP", "EBE", "EO"}

    Dim txtInvTotal As Integer = 0
    Dim txtExp_A_Total As Integer = 0
    Dim txtExp_B_Total As Integer = 0

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'Response.Write(Request.QueryString("q"))

        Response.Write("<table style='width:99%; border-collapse:collapse;' border='1' class='mainGridView' align='center'>" & _
            "<tr>" & _
                "<th class='titleBar' style='border: solid 1px #8b8b8a;'><b>Volume Count</b></th>" & _
                "<th class='titleBar' style='border: solid 1px #8b8b8a;'><b>Invoices</b></th>" & _
                "<th class='titleBar' style='border: solid 1px #8b8b8a;'><b>Help Desk (Email)</b></th>" & _
                "<th class='titleBar' style='border: solid 1px #8b8b8a;'><b>Help Desk (Phone)</b></th>" & _
                "<th class='titleBar' style='border: solid 1px #8b8b8a;'><b>Exceptions - Budget Exced</b></th>" & _
                "<th class='titleBar' style='border: solid 1px #8b8b8a;'><b>Exception - Others</b></th>" & _
            "</tr>")

        GetBalancePrevDay()

        Response.Write("<tr>" & _
                "<td class='labelBL' height='22px' colspan='6'>&nbsp;<b>Received for the Day</b></td>" & _
            "</tr>")

        GetAfter_3PM_PreviousDay()      'get the Previous Day starting 3:00pm to 11:59:59pm
        GetBefore_12_Noon()             'get the received document starting 12:00:00am to 11:59:59am
        Get12_Noon_3_PM()               'get the received document starting 12:00:00pm to 3mp
        Void_documents()                'get all void document for the day
        GetExceptions_Current()         'get current exceptions

        Response.Write("<tr>" & _
            "<td class='labelBL' height='22px' colspan='6'>&nbsp;</td>" & _
        "</tr>")

        Response.Write("<tr>" & _
                "<td class='labelBL' height='22px' colspan='6'>&nbsp;<b>Processed for the Day</b></td>" & _
            "</tr>")

        GetProcessed_As_of_12_noon()
        GetProcessed_After_12_noon()

        Response.Write("<tr>" & _
                "<td class='labelBL' height='22px' colspan='6'>&nbsp;</td>" & _
            "</tr>")

        GetDouble_Send_Wrong_Send_JV_Cancelled_For_GL()
        Balance_for_Today()             'display the total balance

    End Sub

    Private Sub GetBalancePrevDay()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        'Dim rs As SqlClient.SqlDataReader
        Dim vSql As String = ""
        Dim vFilter As String = ""
      
        Dim vPrevDateS As Date = Format(CDate(Request.QueryString("q")), "yyyy-MM-dd")
        Dim vPrevDateE As Date = Format(DateAdd(DateInterval.Day, -1, CDate(Request.QueryString("q"))), "yyyy-MM-dd")

        cm.Connection = c
        c.Open()

        vSql += "select count(distinct(Doc_Id)) as vCount from dm_ledger "
        Response.Write("<tr><td class='labelBL' height='22px'>&nbsp;<b>Balance Previous Day</b></td>")

        For Each t As String In vRowId
            Select Case t
                Case "Invoices"
                    getPrevDayBalance()

                Case "HDE"                      'Help Desk (Email)
                    Response.Write("<td class='labelBC'>0</td>")

                Case "HDP"                      'Help Desk (Phone)
                    Response.Write("<td class='labelBC'>0</td>")

                Case "EBE"                      'Exceptions - Budget Exceed
                    getPrevDayBalance_Exceptions_A()

                Case "EO"                       'Exception - Others
                    Response.Write("<td class='labelBC'>0</td>")
            End Select
        Next
        Response.Write("</tr>")


        c.Close()
        c.Dispose()
        cm.Dispose()

    End Sub

    Private Sub getPrevDayBalance()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cm_ref As New SqlClient.SqlCommand

        Dim rs As SqlClient.SqlDataReader
        Dim vPrevBal As Integer = 0

        Dim vCurrDay As Date = Format(CDate(Request.QueryString("q")), "yyyy-MM-dd")
        Dim vPrevDay As Date = Format(DateAdd(DateInterval.Day, -1, CDate(Request.QueryString("q"))), "yyyy-MM-dd")

        cm.Connection = c
        cm_ref.Connection = c
        c.Open()

        cm.CommandText = "select CurrBalance from dm_volumecount where TranDate='" & vPrevDay & "' and TranCode='Invoices'"
        rs = cm.ExecuteReader
        If rs.Read Then
            vPrevBal = IIf(IsDBNull(rs("CurrBalance")), 0, rs("CurrBalance"))
        End If
        rs.Close()

        cm.CommandText = "select TranDate from dm_volumecount where TranDate ='" & Request.QueryString("q") & "' and TranCode='Invoices'"
        rs = cm.ExecuteReader
        If rs.Read Then
            cm_ref.CommandText = "update dm_volumecount set BalPrevDay=" & vPrevBal & " where " & _
                "TranDate='" & Request.QueryString("q") & "' and TranCode='Invoices'"
            cm_ref.ExecuteNonQuery()

        Else
            cm_ref.CommandText = "insert into dm_volumecount (TranDate, TranCode, BalPrevDay) values " & _
                "('" & Request.QueryString("q") & "', 'Invoices', " & vPrevBal & ")"
            cm_ref.ExecuteNonQuery()
        End If
        rs.Close()

        txtInvTotal = vPrevBal + txtInvTotal
        Response.Write("<td class='labelBC'>" & vPrevBal & "</td>")

        c.Close()
        c.Dispose()
        cm.Dispose()

    End Sub

    Private Sub getPrevDayBalance_Exceptions_A()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cm_ref As New SqlClient.SqlCommand

        Dim rs As SqlClient.SqlDataReader
        Dim vPrevBalExp_A As Integer = 0

        Dim vCurrDay As Date = Format(CDate(Request.QueryString("q")), "yyyy-MM-dd")
        Dim vPrevDay As Date = Format(DateAdd(DateInterval.Day, -1, CDate(Request.QueryString("q"))), "yyyy-MM-dd")

        cm.Connection = c
        cm_ref.Connection = c
        c.Open()

        cm.CommandText = "select CurrBalance from dm_volumecount where TranDate='" & vPrevDay & "' and TranCode='EBE'"
        rs = cm.ExecuteReader
        If rs.Read Then
            vPrevBalExp_A = IIf(IsDBNull(rs("CurrBalance")), 0, rs("CurrBalance"))
        End If
        rs.Close()

        cm.CommandText = "select TranDate from dm_volumecount where TranDate ='" & Request.QueryString("q") & "' and TranCode='EBE'"
        rs = cm.ExecuteReader
        If rs.Read Then
            cm_ref.CommandText = "update dm_volumecount set BalPrevDay=" & vPrevBalExp_A & " where " & _
                "TranDate='" & Request.QueryString("q") & "' and TranCode='EBE'"
            cm_ref.ExecuteNonQuery()

        Else
            cm_ref.CommandText = "insert into dm_volumecount (TranDate, TranCode, BalPrevDay) values " & _
                "('" & Request.QueryString("q") & "', 'EBE', " & vPrevBalExp_A & ")"
            cm_ref.ExecuteNonQuery()
        End If
        rs.Close()

        txtExp_A_Total = vPrevBalExp_A + txtExp_A_Total
        Response.Write("<td class='labelBC'>" & vPrevBalExp_A & "</td>")

        c.Close()
        c.Dispose()
        cm.Dispose()

    End Sub

    Private Sub GetAfter_3PM_PreviousDay()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cm_ref As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim vSql As String = ""
        Dim vFilter As String = ""
        
        Dim vPrevDateE As Date = DateAdd(DateInterval.Day, -1, CDate(Request.QueryString("q")))

        cm.Connection = c
        cm_ref.Connection = c
        c.Open()

        vSql += "select count(distinct(Doc_Id)) as vCount from dm_ledger "
        Response.Write("<tr><td class='labelBL' height='22px'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;After 3 PM (Previous day)</td>")

        For Each t As String In vRowId
            Select Case t
                Case "Invoices"

                    vFilter += "a where a.Status_Cd =1 and exists (select Doc_Id from dm_document where " & _
                        "Status_Cd not in (16) and a.Doc_Id=dm_document.Doc_Id and " & _
                        "Date_Uploaded between '" & vPrevDateE & " 15:00:00' and '" & vPrevDateE & " 23:59:59')"

                    cm.CommandText = vSql & vFilter
                    'Response.Write(cm.CommandText)
                    rs = cm.ExecuteReader
                    If rs.Read Then
                        cm_ref.CommandText = "update dm_volumecount set After3pmPrev=" & rs("vCount") & " where " & _
                        "TranDate='" & Request.QueryString("q") & "' and TranCode='Invoices'"
                        cm_ref.ExecuteNonQuery()

                        Response.Write("<td class='labelBC'>" & rs("vCount") & "</td>")
                        txtInvTotal = rs("vCount") + txtInvTotal
                    End If
                    rs.Close()

                    

                    vFilter = ""

                Case "HDE" 'Help Desk (Email)
                    vFilter += " where Status_Cd=99 "
                    cm.CommandText = vSql & vFilter

                    rs = cm.ExecuteReader
                    If rs.Read Then
                        Response.Write("<td class='labelBC'>0</td>")
                    End If
                    rs.Close()
                    vFilter = ""
                Case "HDP" 'Help Desk (Phone)
                    vFilter += " where Status_Cd=99 "
                    cm.CommandText = vSql & vFilter

                    rs = cm.ExecuteReader
                    If rs.Read Then
                        Response.Write("<td class='labelBC'>0</td>")
                    End If
                    rs.Close()
                    vFilter = ""
                Case "EBE" 'Exceptions - Budget Exceed
                    'vFilter += "a where a.Status_Cd in (4,5,6,7) and exists (select Doc_Id from dm_document where " & _
                    '    "Status_Cd in (4,5,6,7) and a.Doc_Id=dm_document.Doc_Id) and " & _
                    '    "TranDate between '" & vPrevDateE & " 15:00:00' and '" & vPrevDateE & " 23:59:59' " & _
                    '    "and Remarks like 'Budget Exceeded |%'"

                    vFilter += "a where a.Status_Cd in (4,5,6,7) and " & _
                        "TranDate between '" & vPrevDateE & " 15:00:00' and '" & vPrevDateE & " 23:59:59' " & _
                        "and Remarks like 'Budget Exceeded |%'"

                    cm.CommandText = vSql & vFilter

                    rs = cm.ExecuteReader
                    If rs.Read Then
                        Response.Write("<td class='labelBC'>" & rs("vCount") & "</td>")
                    End If
                    rs.Close()
                    vFilter = ""
                Case "EO" 'Exception - Others

                    'vFilter += "a where a.Status_Cd in (4,5,6,7) and exists (select Doc_Id from dm_document where " & _
                    '    "Status_Cd in (4,5,6,7) and a.Doc_Id=dm_document.Doc_Id) and " & _
                    '    "TranDate between '" & vPrevDateE & " 15:00:00' and '" & vPrevDateE & " 23:59:59' " & _
                    '    "and Remarks like 'No Response w/in 24 hrs |%'"

                    vFilter += "a where a.Status_Cd in (4,5,6,7) and " & _
                        "TranDate between '" & vPrevDateE & " 15:00:00' and '" & vPrevDateE & " 23:59:59' " & _
                        "and Remarks like 'No Response w/in 24 hrs |%'"

                    cm.CommandText = vSql & vFilter
                    rs = cm.ExecuteReader
                    If rs.Read Then
                        Response.Write("<td class='labelBC'>" & rs("vCount") & "</td>")
                    End If
                    rs.Close()
                    vFilter = ""
            End Select
        Next
        Response.Write("</tr>")

        c.Close()
        c.Dispose()
        cm.Dispose()

    End Sub

    Private Sub GetBefore_12_Noon()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cm_ref As New SqlClient.SqlCommand

        Dim rs As SqlClient.SqlDataReader
        Dim vSql As String = ""
        Dim vFilter As String = ""

        cm.Connection = c
        cm_ref.Connection = c
        c.Open()

        vSql += "select count(distinct(Doc_Id)) as vCount from dm_ledger "
        Response.Write("<tr><td class='labelBL' height='22px'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Before 12 Noon</td>")

        For Each t As String In vRowId
            Select Case t
                Case "Invoices"

                    vFilter += "a where a.Status_Cd =1 and exists (select Doc_Id from dm_document where " & _
                        "Status_Cd not in (16) and a.Doc_Id=dm_document.Doc_Id and " & _
                        "Date_Uploaded between '" & _
                            Format(CDate(Request.QueryString("q")), "yyyy-MM-dd") & " 00:00:00' and '" & _
                            Format(CDate(Request.QueryString("q")), "yyyy-MM-dd") & " 11:59:59') and a.Remarks like '%New Records%'"

                    cm.CommandText = vSql & vFilter
                    'Response.Write(cm.CommandText)
                    rs = cm.ExecuteReader

                    If rs.Read Then
                        cm_ref.CommandText = "update dm_volumecount set Before12Noon=" & rs("vCount") & " where " & _
                        "TranDate='" & Request.QueryString("q") & "' and TranCode='Invoices'"
                        cm_ref.ExecuteNonQuery()

                        Response.Write("<td class='labelBC'>" & rs("vCount") & "</td>")
                        txtInvTotal = rs("vCount") + txtInvTotal
                    End If
                    rs.Close()
                    vFilter = ""

                Case "HDE" 'Help Desk (Email)
                    vFilter += " where Status_Cd=99 "
                    cm.CommandText = vSql & vFilter

                    rs = cm.ExecuteReader
                    If rs.Read Then
                        Response.Write("<td class='labelBC'>0</td>")
                    End If
                    rs.Close()
                    vFilter = ""
                Case "HDP" 'Help Desk (Phone)
                    vFilter += " where Status_Cd=99 "
                    cm.CommandText = vSql & vFilter

                    rs = cm.ExecuteReader
                    If rs.Read Then
                        Response.Write("<td class='labelBC'>0</td>")
                    End If
                    rs.Close()
                    vFilter = ""
                Case "EBE" 'Exceptions - Budget Exceed
                    'exists (select Doc_Id from dm_document where " & _
                    '   "Status_Cd in (4,5,6,7) and a.Doc_Id=dm_document.Doc_Id) and " & _

                    vFilter += "a where a.Status_Cd in (4,5,6,7) and TranDate between '" & _
                            Format(CDate(Request.QueryString("q")), "yyyy-MM-dd") & " 00:00:00' and '" & _
                            Format(CDate(Request.QueryString("q")), "yyyy-MM-dd") & " 11:59:59' and Remarks like 'Budget Exceeded |%'"

                    cm.CommandText = vSql & vFilter
                    rs = cm.ExecuteReader

                    If rs.Read Then
                        Response.Write("<td class='labelBC'>" & rs("vCount") & "</td>")
                    End If
                    rs.Close()
                    vFilter = ""
                Case "EO" 'Exception - Others
                    'and exists (select Doc_Id from dm_document where " & _
                    '    "Status_Cd in (4,5,6,7) and a.Doc_Id=dm_document.Doc_Id) and " & _

                    vFilter += "a where (a.Status_Cd in (4,5,6,7) and TranDate between '" & _
                            Format(CDate(Request.QueryString("q")), "yyyy-MM-dd") & " 00:00:00' and '" & _
                            Format(CDate(Request.QueryString("q")), "yyyy-MM-dd") & " 11:59:59' and Remarks like 'No Response w/in 24 hrs |%') " & _
                        "or (a.Status_Cd in (4,5,6,7) and TranDate between '" & _
                            Format(CDate(Request.QueryString("q")), "yyyy-MM-dd") & " 00:00:00' and '" & _
                            Format(CDate(Request.QueryString("q")), "yyyy-MM-dd") & " 11:59:59' and Remarks like 'Others |%')"

                    cm.CommandText = vSql & vFilter
                    'Response.Write(cm.CommandText)
                    rs = cm.ExecuteReader
                    If rs.Read Then
                        Response.Write("<td class='labelBC'>" & rs("vCount") & "</td>")
                    End If
                    rs.Close()
                    vFilter = ""
            End Select
        Next
        Response.Write("</tr>")

        c.Close()
        c.Dispose()
        cm.Dispose()

    End Sub

    Private Sub Get12_Noon_3_PM()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cm_ref As New SqlClient.SqlCommand

        Dim rs As SqlClient.SqlDataReader
        Dim vSql As String = ""
        Dim vFilter As String = ""

        cm.Connection = c
        cm_ref.Connection = c
        c.Open()

        vSql += "select count(distinct(Doc_Id)) as vCount from dm_ledger "
        Response.Write("<tr><td class='labelBL' height='22px'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;12 Noon - 3 PM</td>")

        For Each t As String In vRowId
            Select Case t
                Case "Invoices"

                    vFilter += "a where a.Status_Cd =1 and exists (select Doc_Id from dm_document where " & _
                        "Status_Cd not in (16) and a.Doc_Id=dm_document.Doc_Id and " & _
                        "Date_Uploaded between '" & _
                            Format(CDate(Request.QueryString("q")), "yyyy-MM-dd") & " 12:00:00' and '" & _
                            Format(CDate(Request.QueryString("q")), "yyyy-MM-dd") & " 14:59:59') and a.Remarks like '%New Records%'"

                    cm.CommandText = vSql & vFilter
                    rs = cm.ExecuteReader
                    If rs.Read Then
                        cm_ref.CommandText = "update dm_volumecount set Curr12pm3pm=" & rs("vCount") & " where " & _
                        "TranDate='" & Request.QueryString("q") & "' and TranCode='Invoices'"
                        cm_ref.ExecuteNonQuery()

                        Response.Write("<td class='labelBC'>" & rs("vCount") & "</td>")
                        txtInvTotal = rs("vCount") + txtInvTotal
                    End If
                    rs.Close()
                    vFilter = ""

                Case "HDE" 'Help Desk (Email)
                    vFilter += " where Status_Cd=99 "
                    cm.CommandText = vSql & vFilter

                    rs = cm.ExecuteReader
                    If rs.Read Then
                        Response.Write("<td class='labelBC'>0</td>")
                    End If
                    rs.Close()
                    vFilter = ""
                Case "HDP" 'Help Desk (Phone)
                    vFilter += " where Status_Cd=99 "
                    cm.CommandText = vSql & vFilter

                    rs = cm.ExecuteReader
                    If rs.Read Then
                        Response.Write("<td class='labelBC'>0</td>")
                    End If
                    rs.Close()
                    vFilter = ""
                Case "EBE" 'Exceptions - Budget Exceed
                    'exists (select Doc_Id from dm_document where " & _
                    '    "Status_Cd in (4,5,6,7) and a.Doc_Id=dm_document.Doc_Id) and " & _

                    vFilter += "a where a.Status_Cd in (4,5,6,7) and TranDate between '" & _
                            Format(CDate(Request.QueryString("q")), "yyyy-MM-dd") & " 12:00:00' and '" & _
                            Format(CDate(Request.QueryString("q")), "yyyy-MM-dd") & " 14:59:59' and Remarks like 'Budget Exceeded |%'"

                    cm.CommandText = vSql & vFilter
                    rs = cm.ExecuteReader
                    If rs.Read Then
                        Response.Write("<td class='labelBC'>" & rs("vCount") & "</td>")
                    End If
                    rs.Close()
                    vFilter = ""
                Case "EO" 'Exception - Others
                    'exists (select Doc_Id from dm_document where " & _
                    '    "Status_Cd in (4,5,6,7) and a.Doc_Id=dm_document.Doc_Id) and " & _

                    'vFilter += "a where a.Status_Cd in (4,5,6,7) and TranDate between '" & _
                    '        Format(CDate(Request.QueryString("q")), "yyyy-MM-dd") & " 12:00:00' and '" & _
                    '        Format(CDate(Request.QueryString("q")), "yyyy-MM-dd") & " 14:59:59' and Remarks like 'No Response w/in 24 hrs |%'"

                    vFilter += "a where (a.Status_Cd in (4,5,6,7) and TranDate between '" & _
                            Format(CDate(Request.QueryString("q")), "yyyy-MM-dd") & " 12:00:00' and '" & _
                            Format(CDate(Request.QueryString("q")), "yyyy-MM-dd") & " 14:59:59' and Remarks like 'No Response w/in 24 hrs |%') " & _
                        "or (a.Status_Cd in (4,5,6,7) and TranDate between '" & _
                            Format(CDate(Request.QueryString("q")), "yyyy-MM-dd") & " 12:00:00' and '" & _
                            Format(CDate(Request.QueryString("q")), "yyyy-MM-dd") & " 14:59:59' and Remarks like 'Others |%')"

                    cm.CommandText = vSql & vFilter
                    rs = cm.ExecuteReader
                    If rs.Read Then
                        Response.Write("<td class='labelBC'>" & rs("vCount") & "</td>")
                    End If
                    rs.Close()
                    vFilter = ""
            End Select
        Next
        Response.Write("</tr>")

        c.Close()
        c.Dispose()
        cm.Dispose()
    End Sub

    Private Sub Void_documents()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cm_ref As New SqlClient.SqlCommand

        'Dim rs As SqlClient.SqlDataReader
        Dim vSql As String = ""
        Dim vFilter As String = ""

        cm.Connection = c
        cm_ref.Connection = c
        c.Open()

        vSql += "select count(*) as vCount from dm_document "
        Response.Write("<tr><td class='labelBL' height='22px'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Void Documents</td>")

        For Each t As String In vRowId
            Select Case t
                Case "Invoices"

                    'vFilter += " where date_Uploaded between '" & _
                    '    Format(CDate(Request.QueryString("q")), "yyyy-MM-dd") & " 00:00:00' and '" & _
                    '    Format(CDate(Request.QueryString("q")), "yyyy-MM-dd") & " 23:59:59' and Status_Cd =16 "
                    'cm.CommandText = vSql & vFilter
                    'rs = cm.ExecuteReader

                    'If rs.Read Then

                    '    'cm_ref.CommandText = "update dm_volumecount set VoidDocs=0 where " & _
                    '    '"TranDate='" & Request.QueryString("q") & "' and TranCode='Invoices'"
                    '    'cm_ref.ExecuteNonQuery()

                    '    'Response.Write("<td class='labelBC_r'>(" & rs("vCount") & ")</td>")
                    '    Response.Write("<td class='labelBC_r'>(0)</td>")
                    '    'txtInvTotal = txtInvTotal - rs("vCount")
                    'End If
                    'rs.Close()
                    'vFilter = ""
                    Response.Write("<td class='labelBC_r'>(0)</td>")
                Case "HDE" 'Help Desk (Email)
                    Response.Write("<td class='labelBC'>0</td>")
                    vFilter = ""
                Case "HDP" 'Help Desk (Phone)
                    Response.Write("<td class='labelBC'>0</td>")
                    vFilter = ""
                Case "EBE" 'Exceptions - Budget Exceed
                    Response.Write("<td class='labelBC'>0</td>")
                    vFilter = ""
                Case "EO" 'Exception - Others
                    Response.Write("<td class='labelBC'>0</td>")
                    vFilter = ""
            End Select
        Next
        Response.Write("</tr>")

        c.Close()
        c.Dispose()
        cm.Dispose()

    End Sub

    Private Sub GetExceptions_Current()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cm_ref As New SqlClient.SqlCommand

        Dim rs As SqlClient.SqlDataReader
        Dim vSql As String = ""
        Dim vFilter As String = ""

        cm.Connection = c
        cm_ref.Connection = c
        c.Open()

        vSql += "select count(distinct(Doc_Id)) as vCount from dm_ledger "
        Response.Write("<tr><td class='labelBL' height='22px'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Exceptions (Current)</td>")

        For Each t As String In vRowId
            Select Case t
                Case "Invoices"

                    vFilter += " where TranDate between '" & _
                        Format(CDate(Request.QueryString("q")), "yyyy-MM-dd") & " 00:00:00' and '" & _
                        Format(CDate(Request.QueryString("q")), "yyyy-MM-dd") & " 23:59:59' and Status_Cd in (4,5,6,7) "
                    cm.CommandText = vSql & vFilter
                    'Response.Write(cm.CommandText)
                    rs = cm.ExecuteReader

                    If rs.Read Then
                        cm_ref.CommandText = "update dm_volumecount set Exceptions=" & rs("vCount") & " where " & _
                        "TranDate='" & Request.QueryString("q") & "' and TranCode='Invoices'"
                        cm_ref.ExecuteNonQuery()

                        Response.Write("<td class='labelBC_r'>(" & rs("vCount") & ")</td>")
                        txtInvTotal = txtInvTotal - rs("vCount")
                    End If
                    rs.Close()
                    vFilter = ""

                Case "HDE" 'Help Desk (Email)
                    Response.Write("<td class='labelBC'>0</td>")
                    vFilter = ""
                Case "HDP" 'Help Desk (Phone)
                    Response.Write("<td class='labelBC'>0</td>")
                    vFilter = ""
                Case "EBE" 'Exceptions - Budget Exceed
                    Response.Write("<td class='labelBC'>0</td>")
                    vFilter = ""
                Case "EO" 'Exception - Others
                    Response.Write("<td class='labelBC'>0</td>")
                    vFilter = ""
            End Select
        Next
        Response.Write("</tr>")

        c.Close()
        c.Dispose()
        cm.Dispose()
    End Sub

    Private Sub GetProcessed_After_12_noon()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cm_ref As New SqlClient.SqlCommand

        Dim rs As SqlClient.SqlDataReader
        Dim vSql As String = ""
        Dim vFilter As String = ""

        cm.Connection = c
        cm_ref.Connection = c
        c.Open()


        Response.Write("<tr><td class='labelBL' height='22px'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Processed After 12 noon</td>")

        For Each t As String In vRowId
            Select Case t
                Case "Invoices"
                    If CDate(Request.QueryString("q")) > "07/27/2011" Then
                        BuildRecords12_23()
                    Else
                        vSql += "select count(distinct(Doc_Id)) as vCount from dm_ledger where Status_Cd in (13,14) "
                        vFilter += "and exists (select User_Id from user_list where Position='Team Leader' and user_list.User_Id = dm_ledger.CreatedBy ) " & _
                            "and exists (select Doc_Id from dm_document where Status_Cd not in (16,19,20) " & _
                            "and dm_ledger.Doc_Id=dm_document.Doc_Id) and TranDate between '" & _
                                Format(CDate(Request.QueryString("q")), "yyyy-MM-dd") & " 12:00:00' and '" & _
                                Format(CDate(Request.QueryString("q")), "yyyy-MM-dd") & " 23:59:59'"
                        cm.CommandText = vSql & vFilter
                        'Response.Write(cm.CommandText)
                        rs = cm.ExecuteReader
                        If rs.Read Then
                            cm_ref.CommandText = "update dm_volumecount set Processed12pm3pm=" & rs("vCount") & " where " & _
                            "TranDate='" & Request.QueryString("q") & "' and TranCode='Invoices'"
                            cm_ref.ExecuteNonQuery()

                            Response.Write("<td class='labelBC_r'>(" & rs("vCount") & ")</td>")
                            txtInvTotal = txtInvTotal - rs("vCount")
                        End If
                        rs.Close()
                        vFilter = ""
                    End If

                Case "HDE" 'Help Desk (Email)
                    Response.Write("<td class='labelBC'>0</td>")
                    vFilter = ""
                Case "HDP" 'Help Desk (Phone)
                    Response.Write("<td class='labelBC'>0</td>")
                    vFilter = ""
                Case "EBE" 'Exceptions - Budget Exceed
                    Response.Write("<td class='labelBC'>0</td>")
                    vFilter = ""
                Case "EO" 'Exception - Others
                    Response.Write("<td class='labelBC'>0</td>")
                    vFilter = ""
            End Select
        Next
        Response.Write("</tr>")

        c.Close()
        c.Dispose()
        cm.Dispose()
    End Sub

    Private Sub GetProcessed_As_of_12_noon()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cm_ref As New SqlClient.SqlCommand

        Dim rs As SqlClient.SqlDataReader
        Dim vSql As String = ""
        Dim vFilter As String = ""

        cm.Connection = c
        cm_ref.Connection = c
        c.Open()


        Response.Write("<tr><td class='labelBL' height='22px'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Processed (As of 11:59am)</td>")

        For Each t As String In vRowId
            Select Case t
                Case "Invoices"

                    If CDate(Request.QueryString("q")) > "07/27/2011" Then
                        BuildRecords()
                    Else
                        vSql += "select count(distinct(Doc_Id)) as vCount from dm_ledger a where a.Status_Cd in (13,14) "
                        vFilter += "and exists (select User_Id from user_list where Position='Team Leader' and user_list.User_Id = a.CreatedBy ) and " & _
                            "exists (select Doc_Id from dm_document where Status_Cd not in (16,19,20) and a.Doc_Id=dm_document.Doc_Id) " & _
                            "and TranDate between '" & _
                                Format(CDate(Request.QueryString("q")), "yyyy-MM-dd") & " 00:00:00' and '" & _
                                Format(CDate(Request.QueryString("q")), "yyyy-MM-dd") & " 11:59:59' " & _
                            "and a.Doc_Id not in " & _
                            "(select distinct Doc_Id from dm_ledger b where  " & _
                            "b.Status_Cd in (13,14) and exists " & _
                            "(select Doc_Id from dm_document where Status_Cd not in (16,19,20) and b.Doc_Id=dm_document.Doc_Id) " & _
                            "and b.TranDate between '" & _
                                Format(CDate(Request.QueryString("q")), "yyyy-MM-dd") & " 12:00:00' and '" & _
                                Format(CDate(Request.QueryString("q")), "yyyy-MM-dd") & " 23:59:59') "

                        cm.CommandText = vSql & vFilter
                        'Response.Write(cm.CommandText)
                        rs = cm.ExecuteReader
                        If rs.Read Then
                            cm_ref.CommandText = "update dm_volumecount set Processed12am12pm=" & rs("vCount") & " where " & _
                            "TranDate='" & Request.QueryString("q") & "' and TranCode='Invoices'"
                            cm_ref.ExecuteNonQuery()
                            'Response.Write(cm_ref.CommandText)

                            Response.Write("<td class='labelBC_r'>(" & rs("vCount") & ")</td>")
                            txtInvTotal = txtInvTotal - rs("vCount")
                        End If
                        rs.Close()
                        vFilter = ""
                    End If

                Case "HDE" 'Help Desk (Email)
                    Response.Write("<td class='labelBC'>0</td>")
                    vFilter = ""
                Case "HDP" 'Help Desk (Phone)
                    Response.Write("<td class='labelBC'>0</td>")
                    vFilter = ""
                Case "EBE" 'Exceptions - Budget Exceed
                    Response.Write("<td class='labelBC'>0</td>")
                    vFilter = ""
                Case "EO" 'Exception - Others
                    Response.Write("<td class='labelBC'>0</td>")
                    vFilter = ""
            End Select
        Next
        Response.Write("</tr>")

        c.Close()
        c.Dispose()
        cm.Dispose()
    End Sub

    Private Sub BuildRecords()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim vIdList As String = ""

        'If StartDate.Value = "" Then
        '    vscript = "alert('Please select Date.')"
        '    Exit Sub
        'End If

        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim cm_a As New SqlClient.SqlCommand
        'Dim rs_a As SqlClient.SqlDataReader
        Dim cm_b As New SqlClient.SqlCommand
        'Dim rs_b As SqlClient.SqlDataReader

        Dim vSupp As String = ""
        Dim iRows As Integer = 0
        Dim iSW As Integer = 0
        Dim vTotal As Integer = 0
        Dim vCtr As Integer = 1
        Dim vOTTL As Integer = 0
        Dim vFCount As Integer = 0
        Dim vLess As Integer = 0

        Dim vBTotal() As Integer = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}

        c.Open()
        cm.Connection = c
        cm_a.Connection = c
        cm_b.Connection = c
        Dim vHCount As Integer = 0

        cm.CommandText = "select USER_ID, fullname, " & _
            "(select count(distinct(Doc_Id)) from dm_stockcard where TranDate between '" & _
                Format(CDate(Request.QueryString("q")), "yyyy/MM/dd ") & " 00:00:00' and '" & _
                Format(CDate(Request.QueryString("q")), "yyyy/MM/dd ") & " 09:59:59' and " & _
                "user_list.User_Id=dm_stockcard.User_Id and Qty = 1 ) as Time7to10, " & _
            "(select count(distinct(Doc_Id)) from dm_stockcard where TranDate between '" & _
                Format(CDate(Request.QueryString("q")), "yyyy/MM/dd ") & " 10:00:00' and '" & _
                Format(CDate(Request.QueryString("q")), "yyyy/MM/dd ") & " 10:59:59' and " & _
                "user_list.User_Id=dm_stockcard.User_Id and Qty = 1 ) as Time10to11, " & _
            "(select count(distinct(Doc_Id)) from dm_stockcard where TranDate between '" & _
                Format(CDate(Request.QueryString("q")), "yyyy/MM/dd ") & " 11:00:00' and '" & _
                Format(CDate(Request.QueryString("q")), "yyyy/MM/dd ") & " 11:59:59' and " & _
                "user_list.User_Id=dm_stockcard.User_Id and Qty = 1 ) as Time11to12, " & _
            "(select count(distinct(Doc_Id)) from dm_stockcard where TranDate between '" & _
                Format(CDate(Request.QueryString("q")), "yyyy/MM/dd ") & " 00:00:00' and '" & _
                Format(CDate(Request.QueryString("q")), "yyyy/MM/dd ") & " 11:59:59' and " & _
                "user_list.User_Id=dm_stockcard.User_Id and Qty = -1 ) as Time24to25 " & _
            "from user_list where Position='Team Leader' order by FullName"

        rs = cm.ExecuteReader
        vData = ""

        Do While rs.Read
            vTotal = 0
            vData += "<tr><td class='labelBC'>" & vCtr & "</td>" & _
                "<td class='labelBL' style='padding:5px; color: #000000'>&nbsp;" & rs("User_Id") & " -> " & rs("FullName") & "</td>" ' & rs("User_Id") & " -> " 

            For i As Integer = 2 To 5
                If Not IsDBNull(rs(i)) Then
                    vTotal += rs(i)
                    vLess = 0
                    vLess = rs(5)
                End If

                If Not IsDBNull(rs(i)) Then
                    vBTotal(i) += rs(i)
                Else
                    vData += "<td class='labelBC' style='color: #cccccc;" & " '>0</td>"
                End If
            Next
            vCtr += 1

            vTotal = vTotal - vLess
            vIdList = ""
            vOTTL += vTotal

        Loop
        rs.Close()

        cm.CommandText = "update dm_volumecount set Processed12am12pm=" & vOTTL & " where " & _
            "TranDate='" & Request.QueryString("q") & "' and TranCode='Invoices'"
        cm.ExecuteNonQuery()

        Response.Write("<td class='labelBC_r'>(" & vOTTL & ")</td>")
        txtInvTotal = txtInvTotal - vOTTL

        c.Close()
        c.Dispose()
        cm.Dispose()
        cm_a.Dispose()
        cm_b.Dispose()

    End Sub

    Private Sub BuildRecords12_23()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim vIdList As String = ""

        'If StartDate.Value = "" Then
        '    vscript = "alert('Please select Date.')"
        '    Exit Sub
        'End If

        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim cm_a As New SqlClient.SqlCommand
        'Dim rs_a As SqlClient.SqlDataReader
        Dim cm_b As New SqlClient.SqlCommand
        'Dim rs_b As SqlClient.SqlDataReader

        Dim vSupp As String = ""
        Dim iRows As Integer = 0
        Dim iSW As Integer = 0
        Dim vTotal As Integer = 0
        Dim vCtr As Integer = 1
        Dim vOTTL As Integer = 0
        Dim vFCount As Integer = 0
        Dim vLess As Integer = 0

        Dim vBTotal() As Integer = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}

        c.Open()
        cm.Connection = c
        cm_a.Connection = c
        cm_b.Connection = c
        Dim vHCount As Integer = 0

        ' and User_id='balatbatmo' and user_Id='tabernillajl ' 
        cm.CommandText = "select USER_ID, fullname, " & _
            "(select count(distinct(Doc_Id)) from dm_stockcard where TranDate between '" & _
                Format(CDate(Request.QueryString("q")), "yyyy/MM/dd ") & " 12:00:00' and '" & _
                Format(CDate(Request.QueryString("q")), "yyyy/MM/dd ") & " 12:59:59' and " & _
                "user_list.User_Id=dm_stockcard.User_Id and Qty = 1 ) as Time12to13, " & _
            "(select count(distinct(Doc_Id)) from dm_stockcard where TranDate between '" & _
                Format(CDate(Request.QueryString("q")), "yyyy/MM/dd ") & " 13:00:00' and '" & _
                Format(CDate(Request.QueryString("q")), "yyyy/MM/dd ") & " 13:59:59' and " & _
                "user_list.User_Id=dm_stockcard.User_Id and Qty = 1 ) as Time13to15, " & _
            "(select count(distinct(Doc_Id)) from dm_stockcard where TranDate between '" & _
                Format(CDate(Request.QueryString("q")), "yyyy/MM/dd ") & " 14:00:00' and '" & _
                Format(CDate(Request.QueryString("q")), "yyyy/MM/dd ") & " 14:59:59' and " & _
                "user_list.User_Id=dm_stockcard.User_Id and Qty = 1 ) as Time14to15, " & _
            "(select count(distinct(Doc_Id)) from dm_stockcard where TranDate between '" & _
                Format(CDate(Request.QueryString("q")), "yyyy/MM/dd ") & " 15:00:00' and '" & _
                Format(CDate(Request.QueryString("q")), "yyyy/MM/dd ") & " 15:59:59' and " & _
                "user_list.User_Id=dm_stockcard.User_Id and Qty = 1 ) as Time15to16, " & _
            "(select count(distinct(Doc_Id)) from dm_stockcard where TranDate between '" & _
                Format(CDate(Request.QueryString("q")), "yyyy/MM/dd ") & " 16:00:00' and '" & _
                Format(CDate(Request.QueryString("q")), "yyyy/MM/dd ") & " 16:59:59' and " & _
                "user_list.User_Id=dm_stockcard.User_Id and Qty = 1 ) as Time16to17, " & _
            "(select count(distinct(Doc_Id)) from dm_stockcard where TranDate between '" & _
                Format(CDate(Request.QueryString("q")), "yyyy/MM/dd ") & " 17:00:00' and '" & _
                Format(CDate(Request.QueryString("q")), "yyyy/MM/dd ") & " 17:59:59' and " & _
                "user_list.User_Id=dm_stockcard.User_Id and Qty = 1 ) as Time17to18, " & _
            "(select count(distinct(Doc_Id)) from dm_stockcard where TranDate between '" & _
                Format(CDate(Request.QueryString("q")), "yyyy/MM/dd ") & " 18:00:00' and '" & _
                Format(CDate(Request.QueryString("q")), "yyyy/MM/dd ") & " 18:59:59' and " & _
                "user_list.User_Id=dm_stockcard.User_Id and Qty = 1 ) as Time18to19, " & _
            "(select count(distinct(Doc_Id)) from dm_stockcard where TranDate between '" & _
                Format(CDate(Request.QueryString("q")), "yyyy/MM/dd ") & " 19:00:00' and '" & _
                Format(CDate(Request.QueryString("q")), "yyyy/MM/dd ") & " 19:59:59' and " & _
                "user_list.User_Id=dm_stockcard.User_Id and Qty = 1 ) as Time19to20, " & _
            "(select count(distinct(Doc_Id)) from dm_stockcard where TranDate between '" & _
                Format(CDate(Request.QueryString("q")), "yyyy/MM/dd ") & " 20:00:00' and '" & _
                Format(CDate(Request.QueryString("q")), "yyyy/MM/dd ") & " 20:59:59' and " & _
                "user_list.User_Id=dm_stockcard.User_Id and Qty = 1 ) as Time20to21, " & _
            "(select count(distinct(Doc_Id)) from dm_stockcard where TranDate between '" & _
                Format(CDate(Request.QueryString("q")), "yyyy/MM/dd ") & " 21:00:00' and '" & _
                Format(CDate(Request.QueryString("q")), "yyyy/MM/dd ") & " 21:59:59' and " & _
                "user_list.User_Id=dm_stockcard.User_Id and Qty = 1 ) as Time21to22, " & _
            "(select count(distinct(Doc_Id)) from dm_stockcard where TranDate between '" & _
                Format(CDate(Request.QueryString("q")), "yyyy/MM/dd ") & " 22:00:00' and '" & _
                Format(CDate(Request.QueryString("q")), "yyyy/MM/dd ") & " 22:59:59' and " & _
                "user_list.User_Id=dm_stockcard.User_Id and Qty = 1 ) as Time22to23, " & _
            "(select count(distinct(Doc_Id)) from dm_stockcard where TranDate between '" & _
                Format(CDate(Request.QueryString("q")), "yyyy/MM/dd ") & " 23:00:00' and '" & _
                Format(CDate(Request.QueryString("q")), "yyyy/MM/dd ") & " 23:59:59' and " & _
                "user_list.User_Id=dm_stockcard.User_Id and Qty = 1 ) as Time23to24, " & _
            "(select count(distinct(Doc_Id)) from dm_stockcard where TranDate between '" & _
                Format(CDate(Request.QueryString("q")), "yyyy/MM/dd ") & " 12:00:00' and '" & _
                Format(CDate(Request.QueryString("q")), "yyyy/MM/dd ") & " 23:59:59' and " & _
                "user_list.User_Id=dm_stockcard.User_Id and Qty = -1 ) as Time24to25 " & _
            "from user_list where Position='Team Leader' order by FullName"

        'Response.Write(cm.CommandText)

        rs = cm.ExecuteReader
        vData = ""
        Do While rs.Read
            vTotal = 0
            vData += "<tr><td class='labelBC'>" & vCtr & "</td>" & _
                "<td class='labelBL' style='padding:5px; color: #000000'>&nbsp;" & rs("User_Id") & " -> " & rs("FullName") & "</td>" ' & rs("User_Id") & " -> " 

            For i As Integer = 2 To 14
                If Not IsDBNull(rs(i)) Then
                    vTotal += rs(i)
                    vLess = 0
                    vLess = rs(14)
                End If

                If Not IsDBNull(rs(i)) Then
                    vBTotal(i) += rs(i)
                Else
                    vData += "<td class='labelBC' style='color: #cccccc;" & " '>0</td>"
                End If
            Next
            vCtr += 1

            vTotal = vTotal - vLess
            vIdList = ""
            vOTTL += vTotal

        Loop
        rs.Close()

        cm.CommandText = "update dm_volumecount set Processed12am12pm=" & vOTTL & " where " & _
            "TranDate='" & Request.QueryString("q") & "' and TranCode='Invoices'"
        cm.ExecuteNonQuery()

        Response.Write("<td class='labelBC_r'>(" & vOTTL & ")</td>")
        txtInvTotal = txtInvTotal - vOTTL

        c.Close()
        c.Dispose()
        cm.Dispose()
        cm_a.Dispose()
        cm_b.Dispose()

    End Sub

    Private Sub GetDouble_Send_Wrong_Send_JV_Cancelled_For_GL()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cm_ref As New SqlClient.SqlCommand

        Dim rs As SqlClient.SqlDataReader
        Dim vSql As String = ""
        Dim vFilter As String = ""

        cm.Connection = c
        cm_ref.Connection = c
        c.Open()

        vSql += "select count(distinct(Doc_Id)) as vCount from dm_ledger "
        Response.Write("<tr><td class='labelBL' height='22px'>&nbsp;<b>Double send / Wrong Send (JV) / Cancelled / For GL</b></td>")

        For Each t As String In vRowId
            Select Case t
                Case "Invoices"

                    vFilter += " where TranDate between '" & _
                        Format(CDate(Request.QueryString("q")), "yyyy-MM-dd") & " 00:00:00' and '" & _
                        Format(CDate(Request.QueryString("q")), "yyyy-MM-dd") & " 23:59:59' and Status_Cd in (19,20) "
                    cm.CommandText = vSql & vFilter
                    'Response.Write(cm.CommandText)
                    rs = cm.ExecuteReader

                    If rs.Read Then
                        cm_ref.CommandText = "update dm_volumecount set DoubleSend=" & rs("vCount") & " where " & _
                        "TranDate='" & Request.QueryString("q") & "' and TranCode='Invoices'"
                        cm_ref.ExecuteNonQuery()

                        Response.Write("<td class='labelBC_r'>(" & rs("vCount") & ")</td>")
                        txtInvTotal = txtInvTotal - rs("vCount")
                    End If
                    rs.Close()
                    vFilter = ""

                Case "HDE" 'Help Desk (Email)
                    Response.Write("<td class='labelBC'>0</td>")
                    vFilter = ""
                Case "HDP" 'Help Desk (Phone)
                    Response.Write("<td class='labelBC'>0</td>")
                    vFilter = ""
                Case "EBE" 'Exceptions - Budget Exceed
                    Response.Write("<td class='labelBC'>0</td>")
                    vFilter = ""
                Case "EO" 'Exception - Others
                    Response.Write("<td class='labelBC'>0</td>")
                    vFilter = ""
            End Select
        Next
        Response.Write("</tr>")

        c.Close()
        c.Dispose()
        cm.Dispose()
    End Sub

    Private Sub Balance_for_Today()

        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand

        cm.Connection = c
        c.Open()

        Dim vSql As String = ""
        Dim vFilter As String = ""

        Response.Write("<tr><td class='labelBL' height='22px'>&nbsp;<b>Balance for Today</b></td>")

        For Each t As String In vRowId
            Select Case t
                Case "Invoices"
                    cm.CommandText = "update dm_volumecount set CurrBalance=" & txtInvTotal & " where " & _
                        "TranDate='" & Request.QueryString("q") & "' and TranCode='Invoices'"
                    cm.ExecuteNonQuery()

                    Response.Write("<td class='labelBC'>" & txtInvTotal & "</td>")

                Case "HDE" 'Help Desk (Email)
                    Response.Write("<td class='labelBC'>0</td>")

                Case "HDP" 'Help Desk (Phone)
                    Response.Write("<td class='labelBC'>0</td>")

                Case "EBE" 'Exceptions - Budget Exceed
                    cm.CommandText = "update dm_volumecount set CurrBalance=" & txtExp_A_Total & " where " & _
                        "TranDate='" & Request.QueryString("q") & "' and TranCode='EBE'"
                    cm.ExecuteNonQuery()

                    Response.Write("<td class='labelBC'>" & txtExp_A_Total & "</td>")


                Case "EO" 'Exception - Others
                    cm.CommandText = "update dm_volumecount set CurrBalance=" & txtExp_B_Total & " where " & _
                        "TranDate='" & Request.QueryString("q") & "' and TranCode='EO'"
                    cm.ExecuteNonQuery()

                    Response.Write("<td class='labelBC'>" & txtExp_B_Total & "</td>")

            End Select
        Next
        Response.Write("</tr>")

    End Sub
End Class
