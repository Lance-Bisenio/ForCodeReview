﻿Imports denaro.fis
Partial Class teamleadcount
    Inherits System.Web.UI.Page
    Public vHeader_A As String = ""
    Public vData As String = ""
    Public vscript As String

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
        End If

        If Not CanRun(Session("caption"), Request.Item("id")) Then
            Session("denied") = 1
            Server.Transfer("main.aspx")
        End If

        If Not IsPostBack Then

            BuildCombo("select AgencyCd,AgencyName from agency where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='agency' and Property_Value=AgencyCd) order by AgencyName", cmbAgency)

            BuildCombo("select Category_Id,Descr from dm_category where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='Category' and Property_Value=Category_Id) order by Descr", cmbCatg)

            'BuildCombo("select Status_Cd,Descr from dm_document_status where exists (select User_Id from rights_list where User_Id='" & _
            '    Session("uid") & "' and property='Status' and Property_Value=Status_Cd) order by Descr", cmbStatus)


            Dim c As New SqlClient.SqlConnection(connStr)
            Dim cm As New SqlClient.SqlCommand
            Dim rs As SqlClient.SqlDataReader

            c.Open()
            cm.Connection = c
       
            cm.CommandText = "select StatusCd from empendcounter where Position='Team Leader'"
            rs = cm.ExecuteReader
            If rs.Read Then
                txtEndCount.Text = rs("StatusCd")
                BuildCombo("select Status_Cd,Descr from dm_document_status where Status_Cd in (" & rs("StatusCd") & ") ", cmbStatus)
            End If
            rs.Close()
            cm.Dispose()
            c.Close()

            BuildCombo("select SupplierCd, SupplierName from supplier order by SupplierName", cmbVendor)

            cmbAgency.Items.Add("All")
            cmbAgency.SelectedValue = "All"
            cmbCatg.Items.Add("All")
            cmbCatg.SelectedValue = "All"
            cmbStatus.Items.Add("All")
            cmbStatus.SelectedValue = "All"
            cmbVendor.Items.Add("All")
            cmbVendor.SelectedValue = "All"

            cmbMonth.SelectedIndex = Month(Now) - 1

            'cmbYrFr.Items.Clear()
            'cmbYrTo.Items.Clear()
            For iCtr = Year(Now) To Year(Now) + 2
                cmbYear.Items.Add(iCtr)
            Next iCtr




            BuildHeaders()
        End If



    End Sub

    'Private Sub BuildHeaders()
    '    For i As Integer = 0 To 17
    '        vHeader_A += "<th class='titleBar' style='width: 55px; border: solid 1px #8b8b8a;'>" & vTime(i) & "</th>"
    '    Next
    'End Sub
    
    'Private Sub BuildRecords()
    '    Dim c As New SqlClient.SqlConnection(connStr)
    '    Dim vIdList As String = ""

    '    If StartDate.Value = "" Then
    '        vscript = "alert('Please select Date.')"
    '        Exit Sub
    '    End If

    '    Dim cm As New SqlClient.SqlCommand
    '    Dim rs As SqlClient.SqlDataReader
    '    Dim cm_a As New SqlClient.SqlCommand
    '    'Dim rs_a As SqlClient.SqlDataReader
    '    Dim cm_b As New SqlClient.SqlCommand
    '    'Dim rs_b As SqlClient.SqlDataReader

    '    Dim vSupp As String = ""
    '    Dim iRows As Integer = 0
    '    Dim iSW As Integer = 0
    '    Dim vTotal As Integer = 0
    '    Dim vCtr As Integer = 1
    '    Dim vOTTL As Integer = 0
    '    Dim vFCount As Integer = 0
    '    Dim vLess As Integer = 0

    '    Dim vBTotal() As Integer = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}

    '    c.Open()
    '    cm.Connection = c
    '    cm_a.Connection = c
    '    cm_b.Connection = c
    '    Dim vHCount As Integer = 0
    '    Dim vEmpStatus As String = ""

    '    If cmbEmpStatus.SelectedValue <> "All" Then
    '        vEmpStatus = " and POSMenus like '" & cmbEmpStatus.SelectedValue & "%' "
    '    End If

    '    ' and User_id='balatbatmo' and user_Id='tabernillajl ' 
    '    cm.CommandText = "select USER_ID, fullname, " & _
    '        "(select count(distinct(Doc_Id)) from dm_stockcard where TranDate between '" & _
    '            Format(CDate(Request.Form("StartDate")), "yyyy/MM/dd ") & " 00:00:00' and '" & _
    '            Format(CDate(Request.Form("StartDate")), "yyyy/MM/dd ") & " 06:59:59' and " & _
    '            "user_list.User_Id=dm_stockcard.User_Id and Qty = 1 ) as Time7to10, " & _
    '        "(select count(distinct(Doc_Id)) from dm_stockcard where TranDate between '" & _
    '            Format(CDate(Request.Form("StartDate")), "yyyy/MM/dd ") & " 07:00:00' and '" & _
    '            Format(CDate(Request.Form("StartDate")), "yyyy/MM/dd ") & " 09:59:59' and " & _
    '            "user_list.User_Id=dm_stockcard.User_Id and Qty = 1 ) as Time7to10, " & _
    '        "(select count(distinct(Doc_Id)) from dm_stockcard where TranDate between '" & _
    '            Format(CDate(Request.Form("StartDate")), "yyyy/MM/dd ") & " 10:00:00' and '" & _
    '            Format(CDate(Request.Form("StartDate")), "yyyy/MM/dd ") & " 10:59:59' and " & _
    '            "user_list.User_Id=dm_stockcard.User_Id and Qty = 1 ) as Time10to11, " & _
    '        "(select count(distinct(Doc_Id)) from dm_stockcard where TranDate between '" & _
    '            Format(CDate(Request.Form("StartDate")), "yyyy/MM/dd ") & " 11:00:00' and '" & _
    '            Format(CDate(Request.Form("StartDate")), "yyyy/MM/dd ") & " 11:59:59' and " & _
    '            "user_list.User_Id=dm_stockcard.User_Id and Qty = 1 ) as Time11to12, " & _
    '        "(select count(distinct(Doc_Id)) from dm_stockcard where TranDate between '" & _
    '            Format(CDate(Request.Form("StartDate")), "yyyy/MM/dd ") & " 12:00:00' and '" & _
    '            Format(CDate(Request.Form("StartDate")), "yyyy/MM/dd ") & " 12:59:59' and " & _
    '            "user_list.User_Id=dm_stockcard.User_Id and Qty = 1 ) as Time12to13, " & _
    '        "(select count(distinct(Doc_Id)) from dm_stockcard where TranDate between '" & _
    '            Format(CDate(Request.Form("StartDate")), "yyyy/MM/dd ") & " 13:00:00' and '" & _
    '            Format(CDate(Request.Form("StartDate")), "yyyy/MM/dd ") & " 13:59:59' and " & _
    '            "user_list.User_Id=dm_stockcard.User_Id and Qty = 1 ) as Time13to15, " & _
    '        "(select count(distinct(Doc_Id)) from dm_stockcard where TranDate between '" & _
    '            Format(CDate(Request.Form("StartDate")), "yyyy/MM/dd ") & " 14:00:00' and '" & _
    '            Format(CDate(Request.Form("StartDate")), "yyyy/MM/dd ") & " 14:59:59' and " & _
    '            "user_list.User_Id=dm_stockcard.User_Id and Qty = 1 ) as Time14to15, " & _
    '        "(select count(distinct(Doc_Id)) from dm_stockcard where TranDate between '" & _
    '            Format(CDate(Request.Form("StartDate")), "yyyy/MM/dd ") & " 15:00:00' and '" & _
    '            Format(CDate(Request.Form("StartDate")), "yyyy/MM/dd ") & " 15:59:59' and " & _
    '            "user_list.User_Id=dm_stockcard.User_Id and Qty = 1 ) as Time15to16, " & _
    '        "(select count(distinct(Doc_Id)) from dm_stockcard where TranDate between '" & _
    '            Format(CDate(Request.Form("StartDate")), "yyyy/MM/dd ") & " 16:00:00' and '" & _
    '            Format(CDate(Request.Form("StartDate")), "yyyy/MM/dd ") & " 16:59:59' and " & _
    '            "user_list.User_Id=dm_stockcard.User_Id and Qty = 1 ) as Time16to17, " & _
    '        "(select count(distinct(Doc_Id)) from dm_stockcard where TranDate between '" & _
    '            Format(CDate(Request.Form("StartDate")), "yyyy/MM/dd ") & " 17:00:00' and '" & _
    '            Format(CDate(Request.Form("StartDate")), "yyyy/MM/dd ") & " 17:59:59' and " & _
    '            "user_list.User_Id=dm_stockcard.User_Id and Qty = 1 ) as Time17to18, " & _
    '        "(select count(distinct(Doc_Id)) from dm_stockcard where TranDate between '" & _
    '            Format(CDate(Request.Form("StartDate")), "yyyy/MM/dd ") & " 18:00:00' and '" & _
    '            Format(CDate(Request.Form("StartDate")), "yyyy/MM/dd ") & " 18:59:59' and " & _
    '            "user_list.User_Id=dm_stockcard.User_Id and Qty = 1 ) as Time18to19, " & _
    '        "(select count(distinct(Doc_Id)) from dm_stockcard where TranDate between '" & _
    '            Format(CDate(Request.Form("StartDate")), "yyyy/MM/dd ") & " 19:00:00' and '" & _
    '            Format(CDate(Request.Form("StartDate")), "yyyy/MM/dd ") & " 19:59:59' and " & _
    '            "user_list.User_Id=dm_stockcard.User_Id and Qty = 1 ) as Time19to20, " & _
    '        "(select count(distinct(Doc_Id)) from dm_stockcard where TranDate between '" & _
    '            Format(CDate(Request.Form("StartDate")), "yyyy/MM/dd ") & " 20:00:00' and '" & _
    '            Format(CDate(Request.Form("StartDate")), "yyyy/MM/dd ") & " 20:59:59' and " & _
    '            "user_list.User_Id=dm_stockcard.User_Id and Qty = 1 ) as Time20to21, " & _
    '        "(select count(distinct(Doc_Id)) from dm_stockcard where TranDate between '" & _
    '            Format(CDate(Request.Form("StartDate")), "yyyy/MM/dd ") & " 21:00:00' and '" & _
    '            Format(CDate(Request.Form("StartDate")), "yyyy/MM/dd ") & " 21:59:59' and " & _
    '            "user_list.User_Id=dm_stockcard.User_Id and Qty = 1 ) as Time21to22, " & _
    '        "(select count(distinct(Doc_Id)) from dm_stockcard where TranDate between '" & _
    '            Format(CDate(Request.Form("StartDate")), "yyyy/MM/dd ") & " 22:00:00' and '" & _
    '            Format(CDate(Request.Form("StartDate")), "yyyy/MM/dd ") & " 22:59:59' and " & _
    '            "user_list.User_Id=dm_stockcard.User_Id and Qty = 1 ) as Time22to23, " & _
    '        "(select count(distinct(Doc_Id)) from dm_stockcard where TranDate between '" & _
    '            Format(CDate(Request.Form("StartDate")), "yyyy/MM/dd ") & " 23:00:00' and '" & _
    '            Format(CDate(Request.Form("StartDate")), "yyyy/MM/dd ") & " 23:59:59' and " & _
    '            "user_list.User_Id=dm_stockcard.User_Id and Qty = 1 ) as Time23to24, " & _
    '        "(select count(distinct(Doc_Id)) from dm_stockcard where TranDate between '" & _
    '            Format(CDate(Request.Form("StartDate")), "yyyy/MM/dd ") & " 00:00:00' and '" & _
    '            Format(CDate(Request.Form("StartDate")), "yyyy/MM/dd ") & " 23:59:59' and " & _
    '            "user_list.User_Id=dm_stockcard.User_Id and Qty = -1 ) as Time24to25 " & _
    '        "from user_list where Position='Team Leader' " & vEmpStatus & " order by LineUp, FullName"

    '    'Response.Write(cm.CommandText)

    '    rs = cm.ExecuteReader
    '    vData = ""

    '    Do While rs.Read
    '        vTotal = 0
    '        vData += "<tr><td class='labelBC'>" & vCtr & "</td>" & _
    '            "<td class='labelBL' style='padding:5px; color: #000000'>&nbsp;" & rs("FullName") & "</td>" '" & rs("User_Id") & " -> 

    '        For i As Integer = 2 To 18
    '            If Not IsDBNull(rs(i)) Then
    '                vTotal += rs(i)
    '                vLess = 0
    '                vLess = rs(18)
    '            End If

    '            If Not IsDBNull(rs(i)) Then

    '                vBTotal(i) += rs(i)

    '                If i = 18 Then
    '                    vData += "<td class='linkstyle-z' style='padding:5px; cursor:pointer; color:red' title='Click here to view " & _
    '                        "Details' onclick='OpenPop(""" & rs("User_Id") & """, """ & _
    '                        Format(CDate(Request.Form("StartDate")), "yyyy/MM/dd ") & """,""less"",""DC"");'>(" & rs(i) & ")</td>"
    '                Else
    '                    vData += "<td class='labelBC' style='color: " & IIf(rs(i) = 0, "#cccccc;", "#000000;") & " '>" & rs(i) & "</td>"
    '                End If
    '            Else
    '                vData += "<td class='labelBC' style='color: #cccccc;" & " '>0</td>"
    '            End If
    '        Next
    '        vCtr += 1

    '        vTotal = vTotal - (vLess * 2)
    '        vData += "<td class='linkstyle-z' style='padding:5px; cursor:pointer;' title='Click here to view " & _
    '                 "Details' onclick='OpenPop(""" & rs("User_Id") & """, """ & _
    '                    Format(CDate(Request.Form("StartDate")), "yyyy/MM/dd ") & """);'>" & vTotal & "</td>" & _
    '            "</tr>" & vbNewLine
    '        vIdList = ""
    '        vOTTL += vTotal

    '    Loop
    '    rs.Close()

    '    vData += "<tr><td></td>" & _
    '        "<td class='labelR'style='height: 30px;'><b>Total Processed for the Day :</b>&nbsp;&nbsp;</td>"

    '    For i As Integer = 2 To 18
    '        If i = 18 Then
    '            vData += "<td class='labelBC' style='color: red;'><b>(" & vBTotal(i) & ")</b></td>"
    '        Else
    '            vData += "<td class='labelBC'><b>" & vBTotal(i) & "</b></td>"
    '        End If

    '    Next

    '    vData += "<td class='labelC' style='Width:60px;'><b>" & vOTTL & "</b></td>"

    '    c.Close()
    '    c.Dispose()
    '    cm.Dispose()
    '    cm_a.Dispose()
    '    cm_b.Dispose()

    'End Sub

    'Private Sub BuildData(ByVal sender As Object)
    '    Dim vCol As Integer = 0
    '    Dim vName As String = sender

    '    For i As Integer = 0 To 14
    '        vHeader_A += "<th class='titleBar' style='width: 45px; border: solid 1px #8b8b8a;'>" & vTime(i) & "</th>"
    '    Next
    'End Sub

    'Protected Sub cmdRefresh_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdRefresh.Click
    '    If CDate(Request.Form("StartDate")) > "2011-07-27" Then
    '        'response.write(Request.Form("StartDate"))
    '        BuildHeaders()
    '        BuildRecords()
    '    End If

    'End Sub

    'Protected Sub cmdReturn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.Click
    '    Server.Transfer("main.aspx")
    'End Sub

    Protected Sub cmdSearch_Click(sender As Object, e As EventArgs) Handles cmdSearch.Click
        BuildHeaders()
        CollectData()
    End Sub

    Private Sub CollectData()
        Dim vFilter As String = ""

        If cmbAgency.SelectedValue <> "All" Then
            vFilter += " and AgencyCd ='" & cmbAgency.SelectedValue & "'"
        End If

        If cmbStatus.SelectedValue <> "All" Then
            vFilter += " and Status_Cd =" & cmbStatus.SelectedValue
        Else
            vFilter += " and Status_Cd in (" & txtEndCount.Text & ")"
        End If

        If cmbCatg.SelectedValue <> "All" Then
            vFilter += " and Category_Cd ='" & cmbCatg.SelectedValue & "'"
        End If

        If cmbVendor.SelectedValue <> "All" Then
            vFilter += " and Supplier_Cd ='" & cmbVendor.SelectedValue & "' "
        End If

        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cmref As New SqlClient.SqlCommand
        Dim cmsub As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim rsref As SqlClient.SqlDataReader
        Dim rssub As SqlClient.SqlDataReader

        Dim vDocCollection As String = ""
        Dim vGTotal As Integer = 0
        Dim vDailyCtr As Integer = 0
        Dim vCtr As Integer = 1

        c.Open()
        cm.Connection = c
        cmref.Connection = c
        cmsub.Connection = c
         
        cm.CommandText = "select User_Id, FullName from user_list where Position ='Team Leader'"
        rs = cm.ExecuteReader

        Do While rs.Read
            vData += "<tr ><td class='labelC'>" & vCtr & "</td><td  style='padding:5px;' class='labelL'><b>&nbsp;" & rs("Fullname") & "</td>"
            vCtr += 1

            For i As Integer = 1 To txtLastDay.Text

                cmref.CommandText = "select Doc_Id, AgencyCd, Category_Cd, Status_Cd, Supplier_Cd, TranDate from dm_ledger where  TranDate between '" & cmbMonth.SelectedValue & "-" & i & "-" & cmbYear.SelectedValue & " 00:00' and " & _
                    " '" & cmbMonth.SelectedValue & "-" & i & "-" & cmbYear.SelectedValue & " 23:59' and CreatedBy='" & rs("User_Id") & "' " & _
                    vFilter & " Group by Doc_Id, AgencyCd, Category_Cd, Status_Cd, Supplier_Cd, TranDate Order by Doc_Id  "

                'Response.Write(cmref.CommandText & "<br>")
                rsref = cmref.ExecuteReader
                Do While rsref.Read

                    cmsub.CommandText = "select Doc_Id, TranDate from dm_ledger where Doc_Id='" & rsref("Doc_Id") & "' and TranDate between '" & cmbMonth.SelectedValue & "-01-" & cmbYear.SelectedValue & " 00:00' and " & _
                        " '" & cmbMonth.SelectedValue & "-" & txtLastDay.Text & "-" & cmbYear.SelectedValue & " 23:59' " & _
                        vFilter & " Order by Doc_Id  desc, TranDate"

                    rssub = cmsub.ExecuteReader
                    If rssub.Read Then

                        If CDate(rssub("TranDate")) > CDate(rsref("TranDate")) Then
                            vDailyCtr += 0
                        Else
                            vDailyCtr += 1
                        End If
                    Else
                        vDailyCtr += 1
                    End If
                    rssub.Close()

                Loop
                vData += "<td class='labelR' style=' " & IIf(vDailyCtr = 0, "color:#cccccc;", "color:#000000;") & " '>" & vDailyCtr & "&nbsp;</td>"
                vGTotal += vDailyCtr
                vDailyCtr = 0
                'End If
                rsref.Close()


            Next

            vData += "<td class='labelC' style=''>" & vGTotal & "</td>"
            vData += "</tr>"
            vGTotal = 0
        Loop
        rs.Close()

        c.Close()
        c.Dispose()
        cm.Dispose()
        cmref.Dispose()
    End Sub

    Protected Sub cmbMonth_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbMonth.SelectedIndexChanged
        BuildHeaders()
    End Sub

    Private Sub BuildHeaders()

        Dim vLastDayofMonth As String
        vLastDayofMonth = New DateTime(cmbYear.SelectedValue, cmbMonth.SelectedValue, 1).AddMonths(1).AddDays(-1)
        txtLastDay.Text = Day(CDate(vLastDayofMonth))
        'vHeader_A += vLastDayofMonth

        For i As Integer = 1 To Day(CDate(vLastDayofMonth))
            vHeader_A += "<th class='titleBar' style='width: 35px; border: solid 1px #8b8b8a;'>" & i & "</th>"
        Next
        vHeader_A += "<th class='titleBar' style='width: 55px; border: solid 1px #8b8b8a;'>Total</th>"
    End Sub

    Protected Sub cmdClose_Click(sender As Object, e As EventArgs) Handles cmdClose.Click
        Server.Transfer("main.aspx")
    End Sub
End Class
