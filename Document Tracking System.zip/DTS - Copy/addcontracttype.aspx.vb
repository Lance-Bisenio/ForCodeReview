﻿Imports denaro.fis

Partial Class addcontracttype
    Inherits System.Web.UI.Page
    Dim c As New sqlclient.sqlConnection
    Public vscript As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = Nothing Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If

        If Not IsPostBack Then
            Dim cm As New sqlclient.sqlCommand
            Dim dr As sqlclient.sqlDataReader
            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c
            cm.CommandText = "SELECT type_cd,Descr FROM dm_contract_type WHERE type_cd='" & Session("vline") & "'"
            dr = cm.ExecuteReader
            If dr.Read Then
                txtContractId.Text = dr("type_cd")
                txtContractName.Text = dr("Descr")
            End If
            dr.Close()
            cm.Dispose()
            c.Close()
        End If
    End Sub

    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Dim cm As New sqlclient.sqlCommand
        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c
        If Session("vline") <> "" Then
            EventLog(Session("uid"), Request.ServerVariables("REMOTE_ADDR"), "EDIT", "", "", "Contract Type " & Session("vline") & _
                     "-" & txtContractName.Text, "Contract")

            cm.CommandText = "update dm_contract_type set Descr='" & CleanVar(txtContractName.Text) & _
                "' where type_cd='" & Session("vline") & "'"
        Else
            EventLog(Session("uid"), Request.ServerVariables("REMOTE_ADDR"), "ADD", "", "", "Contract Type " & _
                     "-" & txtContractName.Text, "Contract")

            cm.CommandText = "INSERT INTO dm_contract_type(Descr)values('" & CleanVar(txtContractName.Text) & "')"
        End If

        cm.ExecuteNonQuery()
        cm.Dispose()
        c.Close()

        vscript = "alert('Record successfully saved.');window.opener.document.form1.submit();"
    End Sub

    Protected Sub btnClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Session.Remove("vline")
        vscript = "self.close();"
    End Sub
End Class
