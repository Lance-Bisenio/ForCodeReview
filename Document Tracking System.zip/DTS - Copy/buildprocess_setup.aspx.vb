﻿Imports denaro

Partial Class buildprocess_setup
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not IsPostBack Then

            BuildCombo("select AgencyCd,AgencyName from agency where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='agency' and Property_Value=AgencyCd) order by AgencyName", cmbAgency)
            'cmbAgency.Items.Add("All")
            'cmbAgency.SelectedValue = "All"

            BuildCombo("select Category_Id,Descr from dm_category where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='Category' and Property_Value=Category_Id) order by Descr", cmbCatg)
            'cmbCatg.Items.Add("All")
            'cmbCatg.SelectedValue = "All"

            BuildCombo("select Status_Cd,Descr from dm_document_status order by Descr", cmbStatus)
            'cmbStatus.Items.Add("All")
            'cmbStatus.SelectedValue = "All"

            BuildCombo("select Status_Cd,Descr from dm_document_status order by Descr", cmbPrevStatus)
            cmbPrevStatus.Items.Add(" ")
            cmbPrevStatus.SelectedValue = " "

            Dim c As New SqlClient.SqlConnection
            Dim cm As New SqlClient.SqlCommand
            Dim rs As SqlClient.SqlDataReader
            Dim vNextList As String = ""

            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c

            cm.CommandText = "select * from dm_process where Process_Id='" & Request.Item("Id") & "'"
            rs = cm.ExecuteReader
            If rs.Read Then
                cmbAgency.SelectedValue = rs("AgencyCd")
                cmbCatg.SelectedValue = rs("Category_Id")
                cmbStatus.SelectedValue = rs("Status_Cd")
                cmbPrevStatus.SelectedValue = IIf(IsDBNull(rs("PrevStatus_Cd")), " ", rs("PrevStatus_Cd"))
                vNextList += rs("NextStep")
            End If
            rs.Close()
            SetList("select Status_Cd, Descr from dm_document_status  order by Descr", vNextList, "chkStatusList")

            c.Close()
            c.Dispose()
            cm.Dispose()
        End If
    End Sub

    Private Sub GetRecord()
        Dim c As New SqlClient.SqlConnection
        Dim cm As New SqlClient.SqlCommand
        Dim dr As SqlClient.SqlDataReader
        Dim vList As String = ""
        Dim vAdminList As String = ""

        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c

        'cm.CommandText = "select Remarks,Purpose from item where ItemCd='" & Request.Item("ItemCd") & "'"
        'dr = cm.ExecuteReader
        'If dr.Read Then
        '    'txtPurpose.Text = IIf(IsDBNull(dr("Purpose")), "", dr("Purpose"))
        '    'TxtRemarks.Text = IIf(IsDBNull(dr("Remarks")), "", dr("Remarks"))
        'End If
        'dr.Close()

        'cm.CommandText = "select SupplierCd from item where ItemCd='" & Request.Item("ItemCd") & "'"
        'dr = cm.ExecuteReader
        'If dr.Read Then
        '    vList = IIf(IsDBNull(dr("SupplierCd")), "", dr("SupplierCd"))
        'End If
        'dr.Close()
        'SetList("select SupplierCd,SupplierName from Supplier_ref order by SupplierName", vList, "chkSupList")

        vList = ""
        cm.CommandText = "select Alternates from item where ItemCd='" & Request.Item("ItemCd") & "'"
        dr = cm.ExecuteReader
        If dr.Read Then
            vList = IIf(IsDBNull(dr("Alternates")), "", dr("Alternates"))
        End If
        dr.Close()
        SetList("select ItemCd,ItemName from item where ItemCd<>'" & Request.Item("ItemCd") & "' order by ItemName", vList, "chkItemList")

        c.Close()
    End Sub

    Private Sub SetList(ByVal pSQL As String, ByVal pChkField As String, ByVal vType As String)

        Dim c As New SqlClient.SqlConnection
        Dim cm As New SqlClient.SqlCommand
        Dim dr As SqlClient.SqlDataReader

        Dim iCtr As Integer
        Dim vList() As String
        Dim iLoop As Integer

        'Session("oldval") = ""
        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c

        cm.CommandText = pSQL
        dr = cm.ExecuteReader

        If vType = "chkStatusList" Then
            chkStatusList.Items.Clear()

            vList = pChkField.Split(",")
            Do While dr.Read
                chkStatusList.Items.Add(dr(0) & "=>" & dr(1))
                If Request.Item("Id") <> "" Then
                    For iLoop = 0 To UBound(vList)
                        If vList(iLoop) = dr(0) Then
                            chkStatusList.Items(iCtr).Selected = True
                            Session("oldval") += chkStatusList.Items(iCtr).Text.Replace("=", "-") & "<br/>"
                            Exit For
                        End If
                    Next
                End If

                iCtr += 1
            Loop
        End If

        iCtr = 0
        'vList = pChkField.Split(",")

        'If Session("oldval") <> "" Then
        '    Session("oldval") = Session("oldval").ToString.Substring(0, Session("oldval").ToString.Length - 5).Replace("'", "''")
        'End If
        dr.Close()
        cm.Dispose()
    End Sub

    Protected Sub txtCancel_Click(sender As Object, e As EventArgs) Handles txtCancel.Click
        vScript = "self.close();"
    End Sub

    Protected Sub txtEdit_Click(sender As Object, e As EventArgs) Handles txtSave.Click
        Dim c As New SqlClient.SqlConnection
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader

        Dim vData As String
        Dim vNextSteplist As String = ""
        Dim vIsAssign As String = ""

        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c

        For iCtr = 0 To chkStatusList.Items.Count - 1
            If chkStatusList.Items(iCtr).Selected Then
                vData = ExtractData(chkStatusList.Items(iCtr).Text)
                vNextSteplist += vData & ","
            End If
        Next

        vNextSteplist = Mid(vNextSteplist, 1, Len(vNextSteplist) - 1)
        cm.CommandText = "select * from dm_document_status where Status_Cd in (" & vNextSteplist & ") order by Status_Cd"
        vNextSteplist = ""
        rs = cm.ExecuteReader
        Do While rs.Read
            vNextSteplist += rs("Status_Cd") & ","
            vIsAssign += rs("IsAssign") & ","
        Loop
        rs.close()

        vNextSteplist = Mid(vNextSteplist, 1, Len(vNextSteplist) - 1)
        vIsAssign = Mid(vIsAssign, 1, Len(vIsAssign) - 1)

        If Request.Item("Id") <> "" Then
            'EventLog(Session("uid"), Request.ServerVariables("REMOTE_ADDR"), "EDIT", "", "", "Document Status" & Session("vline") & _
            '         "-" & txtdocstatname.Text, "Document Status")

            cm.CommandText = "update dm_process set AgencyCd='" & cmbAgency.SelectedValue & "', Category_Id='" & cmbCatg.SelectedValue & _
                "', Status_Cd='" & cmbStatus.SelectedValue & "', PrevStatus_Cd='" & cmbPrevStatus.SelectedValue & _
                "', NextStep='" & vNextSteplist & "', IsAssign='" & vIsAssign & "' where Process_Id=" & Request.Item("Id")

        Else
            'EventLog(Session("uid"), Request.ServerVariables("REMOTE_ADDR"), "ADD", "", "", "Document Status" & _
            '         "-" & txtdocstatname.Text, "Document Status")

            cm.CommandText = "INSERT INTO dm_process (AgencyCd,Category_Id,Status_Cd,PrevStatus_Cd,NextStep,IsAssign) values " & _
                "('" & cmbAgency.SelectedValue & "','" & cmbCatg.SelectedValue & "','" & cmbStatus.SelectedValue & "','" & _
                cmbPrevStatus.SelectedValue & "','" & vNextSteplist & "','" & vIsAssign & "') "

        End If
        cm.ExecuteNonQuery()

        'Response.Write(cm.CommandText)
        vScript = "alert('Record successfully saved.'); window.opener.document.form1.submit(); window.close(); "
        cm.Dispose()
        c.Close()

    End Sub
End Class
