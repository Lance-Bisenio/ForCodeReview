﻿Imports System.Data
Imports denaro.fis
Partial Class queue
    Inherits System.Web.UI.Page
    Public vScript As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            'Server.Transfer("index.aspx")
            Dim MachineIP = Request.ServerVariables("REMOTE_ADDR")
            Dim vSQL As String = ""
            Dim IsActive As Integer = 0


            vSQL = "select top 1 User_Id from audit where MachineId='" & MachineIP & "' and " _
                & "TranDate between '" & Format(Now, "yyyy-MM-dd") & " 00:00' and '" & Format(Now, "yyyy-MM-dd") & " 23:59' " _
                & "order by trandate desc"

            Session("uid") = GetRef(vSQL, "")

            vSQL = "select * from user_list where User_Id='" & Session("uid") & "'"

            Dim c As New SqlClient.SqlConnection(connStr)
            Dim cm As New SqlClient.SqlCommand(vSQL, c)
            Dim rs As SqlClient.SqlDataReader

            c.Open()
            rs = cm.ExecuteReader
            If rs.Read Then
                IsActive = 1
                'vScript = "openlink(" & rs("Doc_Id") & "," & rs("Status_Cd") & ");"

                Session("caption") = IIf(IsDBNull(rs("Caption")), "", rs("Caption"))
                Session("userlevel") = IIf(IsDBNull(rs("UserLevel")), 0, rs("UserLevel"))
                Session("agencylist") = IIf(IsDBNull(rs("AgencyCd")), "", rs("AgencyCd"))

                Session("Catglist") = IIf(IsDBNull(rs("CategoryCd")), "", rs("CategoryCd"))
                Session("Statuslist") = IIf(IsDBNull(rs("StatusCd")), "", rs("StatusCd"))
                Session("deptlist") = IIf(IsDBNull(rs("DeptCd")), "", rs("DeptCd"))

                Session("rclist") = IIf(IsDBNull(rs("Rc_Cd")), "", rs("Rc_Cd"))

                Session("sectionlist") = IIf(IsDBNull(rs("SectionCd")), "", rs("SectionCd"))
                Session("divlist") = IIf(IsDBNull(rs("DivCd")), "", rs("DivCd"))
                Session("unitlist") = IIf(IsDBNull(rs("UnitCd")), "", rs("UnitCd"))
                Session("typelist") = IIf(IsDBNull(rs("EmploymentType")), "", rs("EmploymentType"))

                Session("EmpPos") = IIf(IsDBNull(rs("Position")), "", "Position : " & rs("Position"))
                Session("EmpEmail") = IIf(IsDBNull(rs("Email")), "", "Email : " & rs("Email"))
                Session("EmpFullName") = IIf(IsDBNull(rs("FullName")), "", rs("FullName"))

                Session("sessionid") = Session.SessionID

            End If
            rs.Close()
            c.Close()
            c.Dispose()
            cm.Dispose()

            If IsActive = 0 Then
                Server.Transfer("index.aspx")
            End If
        End If

        If Not IsPostBack Then
            If CanRun(Session("caption"), 27) = True Then
                cmdAssign.Disabled = False
            Else
                cmdAssign.Disabled = True
            End If

            cmbShow.Items.Clear()
            For iCtr = 1 To 6
                cmbShow.Items.Add(15 * iCtr)
            Next iCtr

            Session.Remove("norecord")

            BuildCombo("select Status_Cd,Descr from dm_document_status where exists (select User_Id from rights_list where User_Id='" _
                       & Session("uid") & "' and property='Status' and Property_Value=Status_Cd) order by Descr", cmbStatus)
            cmbStatus.Items.Add("All")
            cmbStatus.SelectedValue = "All"

            BuildCombo("select Category_Id,Descr from dm_Category where exists (select User_Id from rights_list where User_Id='" _
                       & Session("uid") & "' and property='Category' and Property_Value=Category_Id) order by Descr", cmdCatg)
            cmdCatg.Items.Add("All")
            cmdCatg.SelectedValue = "All"

            BuildCombo("select User_Id,FullName from user_list order by User_Id", cmdUserList)
            cmdUserList.Items.Add("All")
            cmdUserList.SelectedValue = "All"

            BuildCombo("select SupplierCd, SupplierName from supplier order by SupplierName", cmdVendor)
            cmdVendor.Items.Add("All")
            cmdVendor.Items.Add("Disable this filter")
            cmdVendor.SelectedValue = "All"

            BuildCombo("select Location_Id,Descr from dm_document_location  order by Descr", cmdLoc)
            cmdLoc.Items.Add("All")
            cmdLoc.SelectedValue = "All"

            BuildCombo("select Type_Cd,Descr from dm_contract_type  order by Descr", cmbDocType)
            cmbDocType.Items.Add("All")
            cmbDocType.SelectedValue = "All"

            'BuildCombo("select Emp_Cd,Emp_Cd+' => '+Emp_Lname+', '+Emp_Fname from py_emp_master  order by Emp_Lname", cmdEmp)
            cmdEmp.Items.Add("All")
            'cmdEmp.Items.Add("Disable this filter")
            cmdEmp.SelectedValue = "All"

            txtDDateFrom.Text = Format(Now.AddMonths(-1), "MM/dd/yyyy")
            txtDDateTo.Text = Format(Now, "MM/dd/yyyy")


            reminders()

            If tlbDocInfo.Rows.Count = 0 Then
                Session("norecord") = "1"
                'Server.Transfer("main.aspx") 'no record available
            End If

        Else
            'reminders()
        End If

        If txtReload.Value = "Reload" Then
            reminders()
            txtReload.Value = "Done Reload"
        End If

    End Sub

    Public Function GetElapsedTime(ByVal pDateEncoded As String, ByVal pDateAssigned As String) As Single
        'Dim vElapsed As Single
        'If pDateAssigned = "" Then
        '    vElapsed = Math.Round(DateDiff(DateInterval.Minute, CDate(pDateEncoded), Now) / 60, 2)
        'Else
        '    vElapsed = Math.Round(DateDiff(DateInterval.Minute, CDate(pDateAssigned), Now) / 60, 2)
        'End If
        'Return vElapsed

        Dim vElapsedDay As Single = 0

        If pDateAssigned = "" Then
            vElapsedDay = Math.Round(DateDiff(DateInterval.Day, CDate(pDateEncoded), Now), 2)
        Else
            vElapsedDay = Math.Round(DateDiff(DateInterval.Day, CDate(pDateAssigned), Now), 2)
        End If

        Dim vDaysAlert As Integer = vElapsedDay
        Dim iCtr As Integer = 0
        Dim vTmpDueDate As Date

        If pDateAssigned = "" Then
            vTmpDueDate = Format(CDate(pDateEncoded), "MM/dd/yyyy")
        Else
            vTmpDueDate = Format(CDate(pDateAssigned), "MM/dd/yyyy")
        End If

        Dim vExact_DueDate As Date = vTmpDueDate.AddDays(vDaysAlert)
        Dim vTempExact_DueDate As Date = vTmpDueDate

        Do While iCtr <= vDaysAlert - 1
            vTmpDueDate = vTmpDueDate.AddDays(1)

            If vTmpDueDate.DayOfWeek <> DayOfWeek.Sunday And vTmpDueDate.DayOfWeek <> DayOfWeek.Saturday Then
                iCtr += 1
            End If

            If vTmpDueDate >= vExact_DueDate Then
                Exit Do
            End If
        Loop

        vTempExact_DueDate = vTempExact_DueDate.AddDays(iCtr)
        'iCtr = 0

        If pDateAssigned = "" Then
            vElapsedDay = Math.Round(DateDiff(DateInterval.Minute, CDate(pDateEncoded), vTempExact_DueDate) / 60, 2)
        Else
            vElapsedDay = Math.Round(DateDiff(DateInterval.Minute, CDate(pDateAssigned), vTempExact_DueDate) / 60, 2)
        End If
        'vElapsedDay = Math.Round(DateDiff(DateInterval.Minute, CDate(vTmpDueDate), vTempExact_DueDate) / 60, 2)

        Return vElapsedDay

    End Function

    Public Function GetElapsedDay(ByVal pDateEncoded As String, ByVal pDateAssigned As String) As Single
        Dim vElapsedDay As Single = 0

        If pDateAssigned = "" Then
            vElapsedDay = Math.Round(DateDiff(DateInterval.Day, CDate(pDateEncoded), Now), 2)
        Else
            vElapsedDay = Math.Round(DateDiff(DateInterval.Day, CDate(pDateAssigned), Now), 2)
        End If

        Dim vDaysAlert As Integer = vElapsedDay
        Dim iCtr As Integer = 0
        Dim vTmpDueDate As Date

        If pDateAssigned = "" Then
            vTmpDueDate = Format(CDate(pDateEncoded), "MM/dd/yyyy")
        Else
            vTmpDueDate = Format(CDate(pDateAssigned), "MM/dd/yyyy")
        End If

        Dim vExact_DueDate As Date = vTmpDueDate.AddDays(vDaysAlert)

        Do While iCtr <= vDaysAlert - 1
            vTmpDueDate = vTmpDueDate.AddDays(1)

            If vTmpDueDate.DayOfWeek <> DayOfWeek.Sunday And vTmpDueDate.DayOfWeek <> DayOfWeek.Saturday Then
                iCtr += 1
            End If

            If vTmpDueDate >= vExact_DueDate Then
                Exit Do
            End If
        Loop

        Return iCtr
    End Function

    Public Function CheckDueDate(ByVal pDueDate As String, pType As String) As String
        Dim vDueDate As Date
        Dim vDaysAlert As Integer = 2 'days 
        Dim iCtr As Integer = 0
        Dim vColor As String = "black"

        ' tlbDocInfo.Columns(12).ItemStyle.ForeColor = Color.Black
        If pDueDate = "" Then
            Return "&nbsp;"
        Else
            If IsDate(pDueDate) Then
                vDueDate = CDate(pDueDate)
                If Now > vDueDate Then
                    Dim vTmpDueDate As Date = vDueDate
                    Do While iCtr <= vDaysAlert
                        vTmpDueDate = vTmpDueDate.AddDays(1)
                        If vTmpDueDate.DayOfWeek <> DayOfWeek.Sunday And vTmpDueDate.DayOfWeek <> DayOfWeek.Saturday Then
                            iCtr += 1
                        End If
                    Loop
                    If iCtr > vDaysAlert Then
                        'tlbDocInfo.Columns(12).ItemStyle.ForeColor = Color.Red
                        vColor = "red"
                    End If
                End If

                If pType = "tasklist" Then
                    Return "<label style='color:" & vColor & ";'>" & Format(vDueDate.AddDays(15), "MM/dd/yyyy") & "</label>"
                Else
                    Return Format(vDueDate.AddDays(15), "MM/dd/yyyy")
                End If 
            Else
                Return "&nbsp;"
            End If
        End If
    End Function

    Private Sub reminders()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cmRef As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim da As New SqlClient.SqlDataAdapter
        Dim ds As New DataSet

        Dim vElapsed As Single = 0
        Dim vNewStatus As Integer = 99
        Dim vFilter As String = ""
        Dim vFromDate As Date
        Dim vToDate As Date
        Dim vAcountable As String = ""

        Dim vStatus() As String = {"", "", ""}  'index 0=status 5, index 1=status 6,index 2=status 7

        c.Open()
        cm.Connection = c
        cmRef.Connection = c

        'If cmbStatus.SelectedValue <> "All" Then
        '    cm.CommandText = "select * from dm_document_status where Status_Cd=" & cmbStatus.SelectedValue
        '    'Response.Write(cm.CommandText)
        '    rs = cm.ExecuteReader
        '    If rs.Read Then
        '        If rs("IsAssign") = 1 Then
        '            cmdAssign.Disabled = False
        '            cmdAssign.Value = "Assign " & cmbStatus.SelectedItem.Text
        '        Else
        '            cmdAssign.Disabled = True
        '            cmdAssign.Value = "Assign"
        '        End If
        '    End If
        '    rs.Close()
        'Else
        '    cmdAssign.Disabled = True
        '    cmdAssign.Value = "Assign"
        'End If

        vFilter = ""

        If cmbStatus.SelectedValue <> "All" Then
            vFilter += " and Status_Cd =" & cmbStatus.SelectedValue
        Else
            vFilter += " and Status_Cd in (" & Session("Statuslist") & ")"
        End If

        If cmdCatg.SelectedValue <> "All" Then
            vFilter += " and Category_Id =" & cmdCatg.SelectedValue
        End If

        If cmdVendor.SelectedValue <> "All" And cmdVendor.SelectedValue <> "Disable this filter" Then
            vFilter += " and Supplier_Cd ='" & cmdVendor.SelectedValue & "' "
        End If

        If cmdVendor.SelectedValue = "Disable this filter" Then
            vFilter += " and CreditTo is not null "
        End If

        If cmbDocType.SelectedValue <> "All" Then
            vFilter += " and Contract_Id ='" & cmbDocType.SelectedValue & "' "
        End If

        If cmdLoc.SelectedValue <> "All" Then
            vFilter += " and Location_Id ='" & cmdLoc.SelectedValue & "' "
        End If

        If cmdUserList.SelectedValue <> "All" Then
            vFilter += " and Emp_Cd ='" & cmdUserList.SelectedValue & "' "
        End If

        If cmdEmp.SelectedValue <> "All" And cmdEmp.SelectedValue <> "Disable this filter" Then
            vFilter += " and CreditTo ='" & cmdEmp.SelectedValue & "' "
        End If

        If cmdEmp.SelectedValue = "Disable this filter" Then
            vFilter += " and CreditTo is null "
        End If

        If txtDocId.Text <> "" Then
            vFilter += " and Doc_Id ='" & txtDocId.Text.Trim & "' "
        End If

        cm.CommandText = "select * from user_list where User_Id='" & Session("uid") & "'"
        rs = cm.ExecuteReader
        If rs.Read Then
            Select Case rs("Position")
                Case "Processor"
                    vAcountable = " and Emp_Cd='" & Session("uid") & "' "
                Case "Team Leader"
                    vAcountable = ""
            End Select
        End If
        rs.Close()

        If txtDDateFrom.Text <> "" And txtDDateTo.Text <> "" Then

            vFromDate = IIf(txtDDateFrom.Text.Length > 10, Format(CDate(txtDDateFrom.Text), "yyyy/MM/dd HH:mm:ss"), Format(CDate(txtDDateFrom.Text), "yyyy/MM/dd") & " 00:00:00")
            vToDate = IIf(txtDDateTo.Text.Length > 10, Format(CDate(txtDDateTo.Text), "yyyy/MM/dd HH:mm:ss"), Format(CDate(txtDDateTo.Text), "yyyy/MM/dd") & " 23:59:59")

            vFilter += " and DueDate between '" & vFromDate & "' and '" & vToDate & "' "
        End If

        If txtSAPNo.Text.Trim <> "" Then
            vFilter += " and SAP_Number like '%" & txtSAPNo.Text.Trim & "%' "
        End If


        Try
            '"(select Terms from supplier where supplier.SupplierCd=dm_document.Supplier_Cd) as PayTerms, " &
            '"(select SupplierName from supplier where supplier.SupplierCd=dm_document.Supplier_Cd) as VendorDescr, " &

            Session("vSql") = "select DueDate, OrigFileName, Doc_Id, Doc_Name, Date_Assigned, Date_Encoded, Date_Uploaded, " _
                & "SAP_Number, BatchClearingNo,VendorClearingNo, Uploaded_Path, " _
            & "b.Terms as PayTerms, b.SupplierName as VendorDescr, " _
            & "(select Descr from dm_category where dm_category.Category_Id=a.Category_Id) as CatName, " _
            & "(select Descr from dm_document_location where dm_document_location.Location_Id=a.Location_Id) as LocName, " _
            & "(select Descr from dm_contract_type where dm_contract_type.Type_Cd=a.Contract_Id) as DocTypeName, " _
            & "(select Descr from dm_document_status where dm_document_status.Status_Cd=a.Status_Cd) as StatusName, " _
            & "(select FullName from user_list where user_list.User_Id=a.Emp_Cd ) as FullName, " _
            & "(select Value from dm_document_dtl where a.Doc_Id=dm_document_dtl.Doc_Id and dm_document_dtl.Keyword_Id='37') as Amount, " _
            & "(select Value from dm_document_dtl where a.Doc_Id=dm_document_dtl.Doc_Id and dm_document_dtl.Keyword_Id='38') as vRef, " _
            & "(select Emp_Lname+', '+Emp_Fname from py_emp_master where Emp_Cd=CreditTo) as vEmp, " _
            & "(select Terms from py_emp_master where Emp_Cd=CreditTo) as vEmpTerms " _
            & "from dm_document a " _
            & "inner join supplier b on a.Supplier_Cd=b.SupplierCd " _
            & "where AgencyCd in ('" & Session("AgencyList") & "')" & vFilter & " " & vAcountable & " "

            da = New SqlClient.SqlDataAdapter(Session("vSql"), c)

            'Response.Write(da.SelectCommand.CommandText)
            'Exit Sub

            da.Fill(ds, "document")
            tlbDocInfo.DataSource = ds.Tables("document")
            tlbDocInfo.DataBind()
            lblTotalDocs.Text = "<b>Total Documents Retrieved : " & tlbDocInfo.DataSource.Rows.Count & "</b>"


        Catch ex As SqlClient.SqlException
            'Response.Write(da.SelectCommand.CommandText)
        End Try

        da.Dispose()
        ds.Dispose()
        cm.Dispose()
        cmRef.Dispose()

        c.Close()
        c.Dispose()

    End Sub

    Protected Sub tlbDocInfo_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles tlbDocInfo.PageIndexChanging
        tlbDocInfo.PageIndex = e.NewPageIndex
        reminders()
    End Sub

    Protected Sub tlbDocInfo_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tlbDocInfo.SelectedIndexChanged
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand("select Doc_Id,Status_Cd from dm_document where Doc_Id=" & tlbDocInfo.SelectedRow.Cells(1).Text, c)
        Dim rs As SqlClient.SqlDataReader

        c.Open()
        rs = cm.ExecuteReader
        If rs.Read Then
            vScript = "openlink(" & rs("Doc_Id") & "," & rs("Status_Cd") & ");"
        End If
        rs.Close()
        c.Close()
        c.Dispose()
        cm.Dispose()
    End Sub

    Protected Sub cmdSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSearch.Click
        If txtDDateFrom.Text.Trim <> "" Then
            If Not IsDate(txtDDateFrom.Text) Then
                vScript = "alert('Invalid date and time format in Date from field')"
                Exit Sub
            End If

            If txtDDateTo.Text.Trim = "" Then
                vScript = "alert('Invalid date and time format in Date To field')"
                Exit Sub
            End If
        End If

        If txtDDateTo.Text.Trim <> "" And txtDDateFrom.Text.Trim <> "" Then
            If Not IsDate(txtDDateTo.Text) Then
                vScript = "alert('Invalid date and time format in Date to field')"
                Exit Sub
            End If

            If CDate(txtDDateFrom.Text) > CDate(txtDDateTo.Text) Then
                vScript = "alert('From Date should be earlier than To Date')"
                Exit Sub
            End If

            If txtDDateFrom.Text = "" Then
                vScript = "alert('Invalid date and time format in Date From field')"
                Exit Sub
            End If

        ElseIf (txtDDateTo.Text.Trim <> "" And txtDDateFrom.Text.Trim = "") Or _
                (txtDDateTo.Text.Trim = "" And txtDDateFrom.Text.Trim <> "") Then
            vScript = "alert('You should put valid date values for both From date and To Date fields.');"
            Exit Sub
        End If
        reminders()
    End Sub

    Public Function FormatDate(ByVal pDate As String) As String
        If pDate = "" Then
            Return "&nbsp;"
        Else
            Return Format(CDate(pDate), "MM/dd/yyyy")
        End If
    End Function

    Protected Sub cmbShow_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbShow.SelectedIndexChanged
        tlbDocInfo.PageSize = cmbShow.SelectedValue
        reminders()
    End Sub

    Protected Sub cmdDownload_Click(sender As Object, e As EventArgs) Handles cmdDownload.Click
        'Response.Write(Session("vSql"))
        Dim vFile As String = ""
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim cmref As New SqlClient.SqlCommand

        Dim vFilename = Server.MapPath(".") & "/downloads/" & Session.SessionID & "-TaskListDownload.csv"
        Dim vDump As New StringBuilder
        Dim vBuildData As String = ""

        c.Open()
        cm.Connection = c
        cmref.Connection = c

        If IO.File.Exists(vFilename) Then
            Try
                IO.File.Delete(vFilename)
            Catch ex As IO.IOException
                vScript = "alert('Error deleting dump file. Error is: " & ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                Exit Sub
            End Try
        End If

        vDump.AppendLine("Doc. ID,Orig Doc. Name,Doc. Name,Vendor / Employee,Pay Terms,Category, Doc Status,Doc Type,Loc Name," _
                         & "Amount,SAP No.,Vendor Clearing No,Batch Clearing No,Reference,Date Received,Due Date,Elapsed (Day)")

        'Response.Write(cm.CommandText)
        cm.CommandText = Session("vSql")
        rs = cm.ExecuteReader
        Do While rs.Read

            vBuildData = rs("Doc_Id") & ", " _
                & rs("OrigFileName").ToString.Replace(",", "") & ", " _
                & rs("Doc_Name").ToString.Replace(",", "") & ", " _
                & IIf(IsDBNull(rs("VendorDescr")), rs("vEmp").ToString.Replace(",", ""), rs("VendorDescr").ToString.Replace(",", "")) & "," _
                & IIf(IsDBNull(rs("PayTerms")), rs("vEmpTerms").ToString.Replace(",", ""), rs("PayTerms").ToString.Replace(",", "")) & "," _
                & rs("CatName") & "," _
                & rs("StatusName") & "," _
                & rs("DocTypeName") & "," _
                & rs("LocName") & "," _
                & rs("Amount") & "," _
                & rs("SAP_Number") & "," _
                & rs("VendorClearingNo") & "," _
                & rs("BatchClearingNo") & "," _
                & rs("vRef") & "," _
                & Format(rs("Date_Uploaded"), "MM/dd/yyyy") & "," _
               & CheckDueDate(IIf(IsDBNull(rs("DueDate")), "", rs("DueDate")), "download") & "," _
               & GetElapsedDay(IIf(IsDBNull(rs("Date_Encoded")), "", rs("Date_Encoded")), IIf(IsDBNull(rs("Date_Assigned")), "", rs("Date_Assigned")))

            vDump.AppendLine(vBuildData)
        Loop

        IO.File.WriteAllText(vFilename, vDump.ToString)
        vScript = "alert('Download complete.'); window.open('downloads/" & Session.SessionID & "-TaskListDownload.csv');"

        rs.Close()
        cm.Dispose()
        cmref.Dispose()

        c.Close()
        c.Dispose()
    End Sub
End Class
