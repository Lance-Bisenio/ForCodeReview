﻿Imports denaro.fis
Partial Class adddepartment
    Inherits System.Web.UI.Page
    Public vscript As String = ""
    Dim c As New sqlclient.sqlConnection

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = Nothing Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If

        If Not IsPostBack Then
            Dim cm As New sqlclient.sqlCommand
            Dim dr As sqlclient.sqlDataReader
            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c
            cm.CommandText = "select Dept_Cd,Descr from hr_dept_ref where Dept_Cd='" & Session("deptid") & "'"
            dr = cm.ExecuteReader
            If dr.Read Then
                txtDeptId.Text = dr("Dept_Cd")
                txtDeptName.Text = dr("Descr")
            End If
            dr.Close()
            cm.Dispose()
            c.Close()
        End If
    End Sub

    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Dim cm As New sqlclient.sqlCommand
        Dim rs As sqlclient.sqlDataReader

        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c
        If txtDeptName.Text = "" Or txtDeptId.Text = "" Then
            cm.Dispose()
            c.Close()
            vscript = "alert('Dept. code and dept. name must be filled up.');"
            Exit Sub
        Else
            If Session("deptid") = "" Then
                cm.CommandText = "SELECT Descr from hr_dept_ref WHERE Dept_Cd='" & CleanVar(txtDeptId.Text) & "'"
                rs = cm.ExecuteReader()
                If rs.Read Then
                    vscript = "alert('Duplicate record found! Please provide a different dept. code.');"
                    rs.Close()
                    cm.Dispose()
                    c.Close()
                    Exit Sub
                End If
                rs.Close()
                'cm.Dispose()
                'c.Close()
            End If
        End If


        'cm.Connection = c
        If Session("deptid") <> "" Then
            EventLog(Session("uid"), Request.ServerVariables("REMOTE_ADDR"), "EDIT", "", "", "Department" & Session("vline") & _
                     "-" & CleanVar(txtDeptName.Text), "Department")

            cm.CommandText = "update hr_dept_ref set Dept_Cd='" & CleanVar(txtDeptId.Text) & "',Descr='" & CleanVar(txtDeptName.Text) & _
                "' where Dept_Cd='" & Session("deptid") & "'"
        Else
            EventLog(Session("uid"), Request.ServerVariables("REMOTE_ADDR"), "ADD", "", "", "Department" & _
                     "-" & CleanVar(txtDeptName.Text), "Department")
            cm.CommandText = "INSERT INTO hr_dept_ref(Dept_Cd,Descr)values('" & CleanVar(txtDeptId.Text) & "','" & CleanVar(txtDeptName.Text) & "')"
            Session("deptid") = CleanVar(txtDeptId.Text)
        End If

        cm.ExecuteNonQuery()
        cm.Dispose()
        c.Close()
        vscript = "alert('Record successfully saved.');window.opener.document.form1.submit();"
    End Sub

    Protected Sub btnClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnClose.Click
        vscript = "self.close();"
    End Sub
End Class
