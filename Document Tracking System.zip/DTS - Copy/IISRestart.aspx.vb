﻿
Partial Class IISRestart
    Inherits System.Web.UI.Page

    Private Sub IISRestart_Load(sender As Object, e As EventArgs) Handles Me.Load
        Dim p As New Process()
        p.StartInfo.FileName = "D:\xyz.exe"
        p.StartInfo.Arguments = "hello there"
        p.Start()
        p.WaitForExit()
    End Sub
End Class
