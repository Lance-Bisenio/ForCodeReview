Namespace denaro
    Partial Class empstep1
        Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub


        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region
        Dim c As New sqlclient.sqlconnection
        Public vScript As String = ""
        Public vBankList As String = ""

        'Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load, Me.Load
        '    If Session("uid") = "" Then
        '        vScript = "alert('Your login session has expired. Please login again.'); window.close();"
        '    End If

        '    'If Not CanRun(Session("caption"), "41.1") Then
        '    '    'Server.Transfer("empstep2_1.aspx")
        '    '    Exit Sub
        '    'End If

        '    ''    If Not IsPostBack Then

        '    ''        BuildCombo("select AgencyCd,AgencyName from agency where exists (select User_Id from rights_list where User_Id='" & _
        '    ''        Session("uid") & "' and property='agency' and Property_Value=AgencyCd) order by AgencyName", cmbAgency)

        '    ''        BuildCombo("select Rc_Id,Descr from emp_rc_ref order by Descr", cmbRC)
        '    ''        BuildCombo("select Dept_Id,Descr from emp_department_ref order by Descr", cmbDept)
        '    ''        BuildCombo("select Loc_Id,Descr from emp_location_ref order by Descr", cmbLoc)
        '    ''        BuildCombo("select Pos_Id,Descr from emp_position_ref order by Descr", cmbPos)

        '    Response.Write(Session("empid") & "lance test")



        '    ''        ''If Session("empid") = "" Then
        '    ''        ''    'c.ConnectionString = connStr
        '    ''        ''    'c.Open()
        '    ''        ''    'cm.Connection = c
        '    ''        ''    'cm.CommandText = "SELECT Emp_Cd + 1 FROM py_emp_master WHERE substring(Emp_Cd,1,2) = '" & Format(Now, "yy") & _
        '    ''        ''    '                 "' ORDER BY Emp_Cd DESC SET ROWCOUNT 1"
        '    ''        ''    'rs = cm.ExecuteReader
        '    ''        ''    'If rs.Read Then
        '    ''        ''    '    Me.txtId.Text = Format(rs(0), "000000")
        '    ''        ''    'Else
        '    ''        ''    '    Me.txtId.Text = Format(Now, "yy0001")
        '    ''        ''    'End If
        '    ''        ''    'Me.txtBarcode.Text = Me.txtId.Text
        '    ''        ''    'cm.Dispose()
        '    ''        ''    'c.Close()
        '    ''        ''End If


        '    ''        ''txtDateResign.Enabled = False
        '    ''        ''If Session("empid") <> "" Then
        '    ''        ''    txtDateResign.Enabled = True

        '    ''        ''    c.ConnectionString = connStr
        '    ''        ''    c.Open()
        '    ''        ''    cm.Connection = c

        '    ''        ''    cm.CommandText = "select Rc_Cd,Agency_Cd,DivCd,DeptCd,SectionCd,UnitCd,Emp_Cd,BarcodeId," & _
        '    ''        ''        "Emp_Fname,Emp_Mname,Emp_Lname,NickName,Pos_Cd,EmploymentType,Emp_Status,Date_Resign from py_emp_master where " & _
        '    ''        ''        "Emp_Cd='" & Session("empid") & "'"


        '    ''        ''    Try
        '    ''        ''        rs = cm.ExecuteReader
        '    ''        ''        If rs.Read Then
        '    ''        ''            txtId.Text = IIf(IsDBNull(rs("Emp_Cd")), "", rs("Emp_Cd"))
        '    ''        ''            txtFirst.Text = IIf(IsDBNull(rs("Emp_Fname")), "", rs("Emp_Fname"))
        '    ''        ''            txtMiddle.Text = IIf(IsDBNull(rs("Emp_Mname")), "", rs("Emp_Mname"))
        '    ''        ''            txtLast.Text = IIf(IsDBNull(rs("Emp_Lname")), "", rs("Emp_Lname"))
        '    ''        ''            'txtFirst.Text = IIf(IsDBNull(rs("NickName")), "", rs("NickName"))
        '    ''        ''            txtDateResign.Text = IIf(IsDBNull(rs("Date_Resign")), "", rs("Date_Resign"))
        '    ''        ''            'chkConfi.Checked = rs("Confidential")

        '    ''        ''            cmbRC.SelectedValue = PointData("select Rc_Cd,Descr from rc where Rc_Cd='" & rs("Rc_Cd") & "'")
        '    ''        ''            cmbAgency.SelectedValue = PointData("select AgencyCd,AgencyName from agency where AgencyCd='" & rs("Agency_Cd") & "'")
        '    ''        ''            cmbPos.SelectedValue = PointData("select Div_Cd,Descr from hr_div_ref where Div_Cd='" & rs("DivCd") & "'")
        '    ''        ''            cmbDept.SelectedValue = PointData("select Dept_Cd,Descr from hr_dept_ref where Dept_Cd='" & rs("DeptCd") & "'")
        '    ''        ''            cmbLoc.SelectedValue = PointData("select Section_Cd,Descr from hr_section_ref where Section_Cd='" & rs("SectionCd") & "'")

        '    ''        ''        End If
        '    ''        ''        rs.Close()
        '    ''        ''    Catch ex As SqlClient.SqlException
        '    ''        ''        Response.Write("Error in retrieving data. " & ex.Message)
        '    ''        ''    End Try
        '    ''        ''    cm.Dispose()
        '    ''        ''    c.Close()

        '    ''        ''ElseIf Session("fromapplicant") = "1" Then
        '    ''        ''    Dim vRC As String = ""
        '    ''        ''    Dim vAgency As String = ""
        '    ''        ''    Dim vDiv As String = ""
        '    ''        ''    Dim vDept As String = ""
        '    ''        ''    Dim vSection As String = ""
        '    ''        ''    Dim vUnit As String = ""
        '    ''        ''    Dim vPos As String = ""
        '    ''        ''    Dim iCtr As Integer = 1
        '    ''        ''    Dim vStatus As String = ""

        '    ''        ''    'c.ConnectionString = connStr
        '    ''        ''    'c.Open()
        '    ''        ''    'cm.Connection = c

        '    ''        ''    'cmbRC.SelectedValue = PointData("select Rc_Cd,Descr from rc where Rc_Cd='" & vRC & "'")
        '    ''        ''    'cmbAgency.SelectedValue = PointData("select AgencyCd,AgencyName from agency where AgencyCd='" & vAgency & "'")
        '    ''        ''    'cmbPos.SelectedValue = PointData("select Div_Cd,Descr from hr_div_ref where Div_Cd='" & vDiv & "'")
        '    ''        ''    'cmbDept.SelectedValue = PointData("select Dept_Cd,Descr from hr_dept_ref where Dept_Cd='" & vDept & "'")
        '    ''        ''    'cmbLoc.SelectedValue = PointData("select Section_Cd,Descr from hr_section_ref where Section_Cd='" & vSection & "'")
        '    ''        ''    'cmbUnit.SelectedValue = PointData("select Unit_Cd,Descr from hr_unit_ref where Unit_Cd='" & vUnit & "'")

        '    ''        ''End If
        '    ''    End If

        '    ''    'BuildBankList()
        'End Sub

        Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
            If Session("uid") = "" Then
                vScript = "alert('Your login session has expired. Please login again.'); window.close();"
            End If

            If Not IsPostBack Then
                BuildCombo("select AgencyCd,AgencyName from agency where exists (select User_Id from rights_list where User_Id='" & _
                                    Session("uid") & "' and property='agency' and Property_Value=AgencyCd) order by AgencyName", cmbAgency)

                BuildCombo("select Rc_Id,Descr from emp_rc_ref order by Descr", cmbRC)
                BuildCombo("select Dept_Id,Descr from emp_department_ref order by Descr", cmbDept)
                BuildCombo("select Loc_Id,Descr from emp_location_ref order by Descr", cmbLoc)
                BuildCombo("select Pos_Id,Descr from emp_position_ref order by Descr", cmbPos)

                cmbPos.Items.Add(" ")
                cmbPos.SelectedValue = " "
                cmbDept.Items.Add(" ")
                cmbDept.SelectedValue = " "
                cmbLoc.Items.Add(" ")
                cmbLoc.SelectedValue = " "
                cmbRC.Items.Add(" ")
                cmbRC.SelectedValue = " "

                If Session("empid") <> "" Then
                    GetEmpDetails()
                End If
            End If

            BuildBankList()
        End Sub

        Private Sub BuildBankList()
            Dim c As New SqlClient.SqlConnection
            Dim rs As SqlClient.SqlDataReader
            Dim cm As New SqlClient.SqlCommand
            Dim vSQL As String = ""

            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c
            vSQL = "select * "

            If Session("empid") <> "" Then
                vSQL += ",(select Bank_No from emp_banklist where emp_banklist.Bank_Id=emp_bank_ref.Bank_Id and Emp_Cd='" & Session("empid") & "' ) as vBankNo  "
            End If

            vSQL += "from emp_bank_ref"

            cm.CommandText = vSQL

            rs = cm.ExecuteReader
            vBankList = ""
            Do While rs.Read
                vBankList += "<tr><td class='labelR'>" & rs("Descr") & " :</td><td class='labelL'>" & _
                    "<input type='text' id='" & rs("Bank_Id") & "' name='" & rs("Bank_Id") & "' "

                If Session("empid") <> "" Then
                    vBankList += "value='" & rs("vBankNo") & "' "
                Else
                    vBankList += "value='' "
                End If

                vBankList += "runat='server' style='width: 150px;' ></td></tr>"

                ' "<input type='text' id='" & rs("Descr").ToString.Replace(" ", "_") & "' name='" & rs("Descr").ToString.Replace(" ", "_") & "' runat='server' style='width: 150px;' ></td></tr>"
            Loop
            rs.Close()
            cm.Dispose()
            c.Close()
            c.Dispose()

        End Sub

        Private Sub GetEmpDetails()
            Dim c As New SqlClient.SqlConnection
            Dim rs As SqlClient.SqlDataReader
            Dim cm As New SqlClient.SqlCommand

            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c

            cm.CommandText = "select Agency_Cd,Rc_Cd,DeptCd,Emp_Cd,LocCd,Emp_Email,Date_Start," & _
                        "Emp_Fname,Emp_Mname,Emp_Lname,NickName,Pos_Cd,Emp_Status,Date_Resign " & _
                        "from py_emp_master where Emp_Cd='" & Session("empid") & "'"

            rs = cm.ExecuteReader
            If rs.Read Then
                cmbRC.SelectedValue = rs("Rc_Cd")                           'PointData("select Rc_Id,Descr from emp_rc_ref where Rc_Id='" & rs("Rc_Cd") & "'")
                cmbAgency.SelectedValue = rs("Agency_Cd")           'PointData("select AgencyCd,AgencyName from agency where AgencyCd='" & rs("Agency_Cd") & "'")
                cmbPos.SelectedValue = rs("Pos_Cd")                         'PointData("select Pos_Id,Descr from emp_position_ref where Pos_Id='" & rs("Pos_Cd") & "'")
                cmbDept.SelectedValue = rs("DeptCd")                    'PointData("select Dept_Id,Descr from emp_department_ref where Dept_Id='" & rs("DeptCd") & "'")
                cmbLoc.SelectedValue = rs("LocCd")                          'PointData("select Loc_Id,Descr from emp_location_ref where Loc_Id='" & rs("LocCd") & "'")

                txtId.Text = IIf(IsDBNull(rs("Emp_Cd")), "", rs("Emp_Cd"))
                txtOldEmpId.Value = IIf(IsDBNull(rs("Emp_Cd")), "", rs("Emp_Cd"))

                txtFirst.Text = IIf(IsDBNull(rs("Emp_Fname")), "", rs("Emp_Fname"))
                txtMiddle.Text = IIf(IsDBNull(rs("Emp_Mname")), "", rs("Emp_Mname"))
                txtLast.Text = IIf(IsDBNull(rs("Emp_Lname")), "", rs("Emp_Lname"))
                txtEmail.Text = IIf(IsDBNull(rs("Emp_Email")), "", rs("Emp_Email"))

                If Not IsDBNull(rs("Date_Start")) Then
                    txtDateStart.Text = Format(rs("Date_Start"), "MM/dd/yyyy")
                End If

                If Not IsDBNull(rs("Date_Resign")) Then
                    txtDateResign.Text = Format(rs("Date_Resign"), "MM/dd/yyyy")
                End If

            End If
            rs.Close()

            cm.Dispose()
            c.Close()
            c.Dispose()
        End Sub

        Protected Sub cmdSave_Click(sender As Object, e As EventArgs) Handles cmdSave.Click
            If txtId.Text = "" Then
                lblErrorMessage.Visible = True
                lblErrorMessage.Text = "Enter employee id"
                Exit Sub
            End If

            If txtFirst.Text = "" Then
                lblErrorMessage.Visible = True
                lblErrorMessage.Text = "Enter employee First Name"
                Exit Sub
            End If

            If txtMiddle.Text = "" Then
                lblErrorMessage.Visible = True
                lblErrorMessage.Text = "Enter employee Middle Name"
                Exit Sub
            End If

            If txtLast.Text = "" Then
                lblErrorMessage.Visible = True
                lblErrorMessage.Text = "Enter employee Last Name"
                Exit Sub
            End If

            If txtOldEmpId.Value = "" Then
                ValidateData()
            Else
                If txtOldEmpId.Value <> txtId.Text.Trim Then
                    ValidateData()
                Else
                    UpdateRecord()
                End If
            End If

            Session.Remove("empid")
        End Sub

        Protected Sub cmdCancel_Click(sender As Object, e As EventArgs) Handles cmdCancel.Click
            Session.Remove("empid")
        End Sub

        Private Sub ValidateData()

            Dim c As New SqlClient.SqlConnection
            Dim rs As SqlClient.SqlDataReader
            Dim cm As New SqlClient.SqlCommand

            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c

            cm.CommandText = "select Emp_Cd from py_emp_master where  Emp_Cd='" & txtId.Text.Trim & "'"

            rs = cm.ExecuteReader
            If rs.Read Then
                If rs("Emp_Cd") <> "" Then
                    lblErrorMessage.Visible = True
                    lblErrorMessage.Text = "Employee Id already exists."
                    ''Invalid date format in Date Resign field
                    rs.Close()
                    cm.Dispose()
                    c.Close()
                    c.Dispose()
                    Exit Sub

                End If
            End If
            rs.Close()

            lblErrorMessage.Visible = False
            lblErrorMessage.Text = ""

            cm.Dispose()
            c.Close()
            c.Dispose()

            If Session("empid") <> "" Then
                UpdateRecord()
            Else
                CreateRecord()
            End If

        End Sub

        Private Sub UpdateRecord()
            Dim vSQL As String = ""
            Dim cm As New SqlClient.SqlCommand
            Dim vDate_Resign As String = ""
            Dim vDate_Start As String = ""
            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c

            If txtDateResign.Text.Trim = "" Then
                vDate_Resign = "Date_resign=null"
            Else
                vDate_Resign = "Date_resign='" & Format(CDate(txtDateResign.Text.Trim), "MM/dd/yyyy") & "'"
            End If


            If txtDateStart.Text.Trim = "" Then
                vDate_Start = "Date_Start=null"
            Else
                vDate_Start = "Date_Start='" & Format(CDate(txtDateStart.Text.Trim), "MM/dd/yyyy") & "'"
            End If

            cm.CommandText = "update py_emp_master set " & _
                "Agency_Cd='" & cmbAgency.SelectedValue & "', Rc_Cd='" & cmbRC.SelectedValue & "', Pos_Cd='" & cmbPos.SelectedValue & "'," & _
                "DeptCd='" & cmbDept.SelectedValue & "',LocCd='" & cmbLoc.SelectedValue & "',Emp_Fname='" & txtFirst.Text.Trim & "'," & _
                "Emp_Lname='" & txtLast.Text.Trim & "',Emp_Mname='" & txtMiddle.Text.Trim & "'," & _
                "" & vDate_Start & "," & vDate_Resign & ", Emp_Email='" & txtEmail.Text & "',Emp_Cd='" & txtId.Text & "' " & _
                "where Emp_Cd='" & txtOldEmpId.Value & "' "
            cm.ExecuteNonQuery()

            cm.Dispose()
            c.Dispose()
            c.Close()

            CreateBankList()
        End Sub

        Private Sub CreateRecord()
            Dim vSQL As String = ""
            Dim cm As New SqlClient.SqlCommand
            Dim vDate_Resign As String = ""
            Dim vDate_Start As String = ""

            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c

            If txtDateResign.Text.Trim = "" Then
                vDate_Resign = "null"
            Else
                vDate_Resign = Format(CDate(txtDateResign.Text.Trim), "MM/dd/yyyy")
            End If


            If txtDateStart.Text.Trim = "" Then
                vDate_Start = "null"
            Else
                vDate_Start = "'" & Format(CDate(txtDateStart.Text.Trim), "MM/dd/yyyy") & "'"
            End If

            cm.CommandText = "insert py_emp_master (Date_Start,Date_Resign,DivCd,SectionCd,UnitCd," & _
                "Agency_Cd,Rc_Cd,Pos_Cd,DeptCd,LocCd,Emp_Fname,Emp_Lname,Emp_Mname,Emp_Email,Emp_Cd,Terms) values ( " & _
                "" & vDate_Start & "," & vDate_Resign & ",99,99,99," & _
                "'" & cmbAgency.SelectedValue & "','" & cmbRC.SelectedValue & "','" & cmbPos.SelectedValue & "'," & _
                "'" & cmbDept.SelectedValue & "','" & cmbLoc.SelectedValue & "','" & txtFirst.Text.Trim & "'," & _
                "'" & txtLast.Text.Trim & "','" & txtMiddle.Text.Trim & "','" & txtEmail.Text & "','" & txtId.Text & "',7)"
            'Response.Write(cm.CommandText)
            cm.ExecuteNonQuery()

            cm.Dispose()
            c.Dispose()
            c.Close()

            CreateBankList()
        End Sub

        Private Sub CreateBankList()
            Dim c As New SqlClient.SqlConnection
            Dim rs As SqlClient.SqlDataReader
            Dim cm As New SqlClient.SqlCommand
            Dim cmref As New SqlClient.SqlCommand

            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c
            cmref.Connection = c

            cmref.CommandText = "delete from emp_banklist where Emp_Cd='" & txtId.Text.Trim & "'  "
            cmref.ExecuteNonQuery()

            cm.CommandText = "select * from emp_bank_ref"
            rs = cm.ExecuteReader

            Do While rs.Read
                cmref.CommandText = "insert into emp_banklist values ('" & txtId.Text.Trim & "','" & rs("Bank_Id") & "','" & Request.Item(rs("Bank_Id")) & "','" & rs("Descr") & "') "
                cmref.ExecuteNonQuery()
            Loop
            rs.Close()
            cm.Dispose()
            c.Close()
            c.Dispose()

            lblErrorMessage.Visible = True
            lblErrorMessage.ForeColor = Color.Blue
            lblErrorMessage.Text = "Successfully saved."
            vScript = "opener.location.reload(); window.close();"
        End Sub

        '        Private Sub cmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        '            Session.Remove("oldval")
        '            Session.Remove("empid")
        '            vScript = "window.close();"
        '        End Sub

        '        Private Sub txtFirst_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtFirst.Init
        '            Dim txt As System.Web.UI.WebControls.TextBox
        '            txt = CType(sender, System.Web.UI.WebControls.TextBox)
        '            txt.Attributes.Add("onblur", "copyval();")
        '        End Sub

        '        Private Sub cmdSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        '            If Page.IsValid Then


        '                Dim vSQL As String = ""
        '                Dim cm As New SqlClient.SqlCommand
        '                Dim rs As SqlClient.SqlDataReader

        '                Dim vDateResign As String = ""
        '                Dim vDateName As String = ""
        '                Dim vDateResign2 As String = ""

        '                c.ConnectionString = connStr
        '                c.Open()
        '                cm.Connection = c

        '                If txtDateResign.Text.Trim <> "" Then
        '                    If Not IsDate(txtDateResign.Text) Then
        '                        vScript = "alert('Invalid date format in Date Resign field')"
        '                        Exit Sub
        '                    End If
        '                    vDateName = ", Date_Resign"
        '                    vDateResign = ",'" & txtDateResign.Text & "'"
        '                    vDateResign2 = ", Date_Resign='" & txtDateResign.Text & "'"
        '                Else
        '                    vDateResign2 = ", Date_Resign=null"
        '                End If

        '                If Session("empid") = "" Then 'add mode
        'Again:
        '                    vSQL = "insert into py_emp_master (Rc_Cd,Agency_Cd,DivCd,DeptCd,SectionCd,UnitCd,Emp_Cd,BarcodeId," & _
        '                        "Emp_Fname,Emp_Mname,Emp_Lname,NickName,Pos_Cd,EmploymentType,Emp_Status,ImgPath) values ('" & _
        '                        cmbRC.SelectedValue & "','" & _
        '                        cmbAgency.SelectedValue & "','" & _
        '                        cmbPos.SelectedValue & "','" & _
        '                        cmbDept.SelectedValue & "','" & _
        '                        cmbLoc.SelectedValue & "','" & _
        '                        RTrim(txtId.Text.Trim) & "','" & _
        '                        RTrim(txtBarcode.Text.Trim) & "','" & _
        '                        txtFirst.Text & "','" & _
        '                        txtMiddle.Text & "','" & _
        '                        txtLast.Text & "','" & _
        '                        txtFirst.Text & "','99','99','" & _
        '                        RTrim(txtId.Text.Trim) & "','../pics/" & txtId.Text & "')"
        '                    Session("empid") = RTrim(txtId.Text.Trim)
        '                    cm.CommandText = vSQL
        '                    Try
        '                        cm.ExecuteNonQuery()
        '                        Session("newval") = "Emp Id=" & txtId.Text & _
        '                            "|Biometrics Id=" & txtBarcode.Text & _
        '                            "|First Name=" & txtFirst.Text & _
        '                            "|Middle Name=" & txtMiddle.Text & _
        '                            "|Last Name=" & txtLast.Text & _
        '                            "|Cost Center=" & cmbRC.SelectedValue & _
        '                            "|Agency=" & cmbAgency.SelectedValue & _
        '                            "|Division=" & cmbPos.SelectedValue & _
        '                            "|Department=" & cmbDept.SelectedValue & _
        '                            "|Section=" & cmbLoc.SelectedValue

        '                        EventLog(Session("uid"), Request.ServerVariables("REMOTE_ADDR"), "ADD", _
        '                            Session("oldval"), Session("newval"), "Employee ID: " & txtId.Text & _
        '                            " was added", "201 Profile", c)
        '                        Session.Remove("oldval")
        '                        Session.Remove("newval")

        '                    Catch ex As SqlClient.SqlException
        '                        txtId.Text = Format(Val(txtId.Text) + 1, "000000")
        '                        txtBarcode.Text = txtId.Text
        '                        'GoTo Again
        '                    End Try
        '                    vScript = "alert('Successfully saved.'); " & _
        '                    "opener.document.getElementById('txtRefreshList').value='refresh'; " & _
        '                    "opener.document.form1.submit(); window.close();"

        '                Else 'edit mode

        '                    'vSQL = "update py_emp_master set Rc_Cd='" & cmbRC.SelectedValue & _
        '                    '    "',Agency_Cd='" & cmbAgency.SelectedValue & _
        '                    '    "',DivCd='" & cmbDiv.SelectedValue & _
        '                    '    "',DeptCd='" & cmbDept.SelectedValue & _
        '                    '    "',SectionCd='" & cmbSection.SelectedValue & _
        '                    '    "',UnitCd='" & cmbUnit.SelectedValue & _
        '                    '    "',Emp_Cd='" & RTrim(txtId.Text.Trim) & _
        '                    '    "',BarCodeId='" & RTrim(txtBarcode.Text.Trim) & _
        '                    '    "',Emp_Fname='" & txtFirst.Text & _
        '                    '    "',Emp_Mname='" & txtMiddle.Text & _
        '                    '    "',Emp_Lname='" & txtLast.Text & _
        '                    '    "',NickName='" & txtFirst.Text & _
        '                    '    "',Pos_Cd='99',EmploymentType='99',Emp_Status='" & RTrim(txtId.Text.Trim) & _
        '                    '    "',Modified_Date='" & Format(Now, "yyy/MM/dd HH:mm:ss") & _
        '                    '    "',Modified_By='" & Session("uid") & _
        '                    '    "',User_id='" & txtId.Text & _
        '                    '    "' " & vDateResign2 & " where Emp_Cd='" & Session("empid") & "'"
        '                    'cm.CommandText = vSQL
        '                    'Try
        '                    '    cm.ExecuteNonQuery()
        '                    '    Session("empid") = RTrim(txtId.Text.Trim)
        '                    '    Session("newval") = "Emp Id=" & txtId.Text & _
        '                    '        "|Biometrics Id=" & txtBarcode.Text & _
        '                    '        "|First Name=" & txtFirst.Text & _
        '                    '        "|Middle Name=" & txtMiddle.Text & _
        '                    '        "|Last Name=" & txtLast.Text & _
        '                    '        "|Cost Center=" & cmbRC.SelectedValue & _
        '                    '        "|Agency=" & cmbAgency.SelectedValue & _
        '                    '        "|Division=" & cmbDiv.SelectedValue & _
        '                    '        "|Department=" & cmbDept.SelectedValue & _
        '                    '        "|Section=" & cmbSection.SelectedValue & _
        '                    '        "|Unit=" & cmbUnit.SelectedValue

        '                    EventLog(Session("uid"), Request.ServerVariables("REMOTE_ADDR"), "EDIT", _
        '                        Session("oldval"), Session("newval"), "Employee ID: " & txtId.Text & _
        '                        " was added/edited", "201 Profile", c)
        '                    Session.Remove("oldval")
        '                    Session.Remove("newval")


        '                    Catch ex As SqlClient.SqlException
        '                        Response.Write("Error in SQL: " & ex.Message)
        '                    End Try
        '                    vScript = "alert('Successfully saved.'); " & _
        '                        "opener.document.getElementById('txtRefreshList').value='refresh'; " & _
        '                        "opener.document.form1.submit(); window.close();"

        '                End If

        '            End If
        '        End Sub

        '        Private Sub vldEmpId_ServerValidate(ByVal source As System.Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles vldEmpId.ServerValidate
        '            If Session("empid") <> txtId.Text Then
        '                Dim cm As New sqlclient.sqlCommand
        '                Dim rs As sqlclient.sqlDataReader

        '                c.ConnectionString = connStr
        '                c.Open()
        '                cm.Connection = c
        '                cm.CommandText = "select Emp_Cd from py_emp_master where Emp_Cd='" & txtId.Text & "'"
        '                Try
        '                    rs = cm.ExecuteReader
        '                    rs.Read()
        '                    args.IsValid = Not rs.HasRows
        '                    cm.Dispose()
        '                    c.Close()
        '                    Exit Sub
        '                Catch ex As sqlclient.sqlException
        '                    Response.Write("Error executing SQL during employee id validattion.<Br>" & ex.Message)
        '                End Try
        '                cm.Dispose()
        '                c.Close()
        '                args.IsValid = False
        '            Else
        '                args.IsValid = True
        '            End If
        '        End Sub

        '        Protected Sub vldEmpBio_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles vldEmpBio.ServerValidate
        '            If Session("empid") <> txtId.Text Then
        '                Dim cm As New SqlClient.SqlCommand
        '                Dim rs As SqlClient.SqlDataReader

        '                c.ConnectionString = connStr
        '                c.Open()
        '                cm.Connection = c
        '                cm.CommandText = "select Emp_Cd from py_emp_master where BarcodeId='" & txtBarcode.Text & "'"
        '                Try
        '                    rs = cm.ExecuteReader
        '                    rs.Read()
        '                    args.IsValid = Not rs.HasRows
        '                    cm.Dispose()
        '                    c.Close()
        '                    Exit Sub
        '                Catch ex As SqlClient.SqlException
        '                    Response.Write("Error executing SQL during employee id validattion.<Br>" & ex.Message)
        '                End Try
        '                cm.Dispose()
        '                c.Close()
        '                args.IsValid = False
        '            Else
        '                args.IsValid = True
        '            End If
        '        End Sub

    End Class

End Namespace
