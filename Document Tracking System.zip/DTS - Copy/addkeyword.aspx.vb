Imports denaro.fis

Partial Class addkeyword
    Inherits System.Web.UI.Page
    Public vScript As String = ""


    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Dim c As New sqlclient.sqlConnection(connStr)
        Dim cm As New sqlclient.sqlCommand
        If Session("vline") = "" Then
            EventLog(Session("uid"), Request.ServerVariables("REMOTE_ADDR"), "ADD", "", "", "Keyword Item " & _
                     "-" & CleanVar(txtDescription.Text), "Keyword")

            cm.CommandText = "INSERT INTO dm_keywords(Descr,Data_Type,Encoded_By,Date_Encoded)VALUES('" & _
                                     CleanVar(txtDescription.Text) & "','" & cmbType.SelectedValue & _
                                     "','" & Session("uid") & "','" & Format(Now, "yyyy/MM/dd") & "')"
        Else
            EventLog(Session("uid"), Request.ServerVariables("REMOTE_ADDR"), "EDIT", "", "", "Keyword Item " & Session("vline") & _
                     "-" & CleanVar(txtDescription.Text), "Keyword")

            cm.CommandText = "UPDATE dm_keywords SET Descr='" & CleanVar(txtDescription.Text) & "',Data_Type='" & cmbType.SelectedValue & _
                             "' WHERE Keyword_Id='" & Session("vline") & "'"
        End If

        cm.Connection = c
        c.Open()
        cm.ExecuteNonQuery()

        c.Close()
        cm.Dispose()

        vScript = "alert('Record saved.');window.opener.document.form1.submit();"
        'txtDescription.Text = ""

    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = Nothing Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If
        If Not IsPostBack Then


            Dim c As New sqlclient.sqlConnection(connStr)
            Dim cm As New sqlclient.sqlCommand
            Dim rs As sqlclient.sqlDataReader

            If Session("vline") = "" Then
                cm.CommandText = "SELECT * FROM dm_keywords Order by Data_Type"
            Else
                cm.CommandText = "SELECT * FROM dm_keywords WHERE Keyword_Id='" & Session("vline") & "'"
            End If

            cm.Connection = c
            c.Open()

            rs = cm.ExecuteReader
            If rs.Read Then
                txtDescription.Text = IIf(Session("vline") = "", "", rs("Descr"))
                cmbType.SelectedValue = rs("Data_Type")
            End If
            rs.Close()
            c.Dispose()
            cm.Dispose()
        End If
    End Sub

    Protected Sub btnClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Session.Remove("vline")
        vScript = "self.close();"
    End Sub
End Class

