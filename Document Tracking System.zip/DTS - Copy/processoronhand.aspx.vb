﻿Imports System.Data
Imports denaro.fis
Partial Class processoronhand
    Inherits System.Web.UI.Page
    Public vHeader_A As String = ""
    Public vHeader_B As String = ""
    Public vHeader_C As String = ""
    Public vData As String = ""
    Public vEmpData As String = ""
    Public vscript As String


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If

        If Not CanRun(Session("caption"), Request.Item("id")) Then
            Session("denied") = 1
            Server.Transfer("main.aspx")
        End If

        If vCode.Value <> "" Then
            BuildRecords()
            BuildEmpRecords()
        End If

        If Not IsPostBack Then
            txtFrom.Text = Format(Now(), "MM/dd/yyyy")
            txtTo.Text = Format(Now(), "MM/dd/yyyy")

            BuildCombo("select Status_Cd, Descr from dm_document_status where Status_Cd in (2,3,9,11,14,17)", cmdList)
            cmdList.Items.Add("All")
            cmdList.SelectedValue = "All"

            BuildCombo("select SupplierCd,SupplierName from supplier order by SupplierCd", cmdComp)
            cmdComp.Items.Add("All")
            cmdComp.SelectedValue = "All"

            BuildCombo("select Category_Id,Descr from dm_Category where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='Category' and Property_Value=Category_Id) order by Descr", cmbCatg)
            cmbCatg.Items.Add("All")
            cmbCatg.SelectedValue = "All"

        End If
    End Sub


    Private Sub BuildRecords()
        Dim c As New SqlClient.SqlConnection(connStr)

        'If StartDate.Value = "" Then
        '    vscript = "alert('Please select Date.')"
        '    Exit Sub
        'End If

        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim cm_a As New SqlClient.SqlCommand
        'Dim rs_a As SqlClient.SqlDataReader
        Dim cm_b As New SqlClient.SqlCommand
        Dim rs_b As SqlClient.SqlDataReader

        Dim vDiff As Integer = 0
        Dim vStatus As String = ""

        Dim iRows As Integer = 0
        Dim iSW As Integer = 0

        c.Open()
        cm.Connection = c
        cm_b.Connection = c
        cm_a.Connection = c

        Dim vEmpStatus As String = ""
        Dim vFilter As String = ""
        'Dim vFromDate As Date
        Dim vStatusList As String = ""
        Dim vCtr As Integer = 1
        Dim vTtl As Integer = 0

        vFilter = ""
        If txtFrom.Text <> "" And txtTo.Text <> "" Then

            'vFromDate = IIf(txtFrom.Text.Length > 10, Format(CDate(txtFrom.Text), "yyyy/MM/dd") & " 00:00:00", Format(CDate(txtFrom.Text), "yyyy/MM/dd") & " 00:00:00")
            'vToDate = IIf(txtTo.Text.Length > 10, Format(CDate(txtTo.Text), "yyyy/MM/dd") & " 23:59:59", Format(CDate(txtTo.Text), "yyyy/MM/dd") & " 23:59:59")

            vFilter += " and Date_Uploaded between '" & Format(CDate(txtFrom.Text), "yyyy/MM/dd") & " 00:00:00" & _
                "' and '" & Format(CDate(txtTo.Text), "yyyy/MM/dd") & " 23:59:59" & "'"

            'vFilter += " and Date_Assigned between '" & Format(CDate(txtFrom.Text), "yyyy/MM/dd") & " 00:00:00" & _
            '    "' and '" & Format(CDate(txtTo.Text), "yyyy/MM/dd") & " 23:59:59" & "'"
        End If

        If cmdComp.SelectedValue <> "All" Then
            vFilter += " and Supplier_Cd ='" & cmdComp.SelectedValue & "' "
        End If

        If cmdList.SelectedValue <> "All" Then
            vFilter += " and Status_Cd=" & cmdList.SelectedValue
        End If

        If cmbCatg.SelectedValue <> "All" Then
            vFilter += " and Category_Id=" & cmbCatg.SelectedValue
        End If

        If cmbEmpStatus.SelectedValue <> "All" Then
            vEmpStatus = " and POSMenus like '" & cmbEmpStatus.SelectedValue & "%' "
        End If

        cm.CommandText = "select StatusCd, User_Id, FullName from user_list where Position ='Processor' " & vEmpStatus & " order by LineUp, FullName"
        'Response.Write(cm.CommandText)
        rs = cm.ExecuteReader
        vData = ""
        Do While rs.Read
            vStatusList = rs("StatusCd").ToString.Replace("1,25,26,", "")
            vSlist.Value = rs("StatusCd").ToString.Replace("1,25,26,", "")

            vData += "<tr><td class='labelC'>" & vCtr & "</td>" & _
                "<td class='labelL' style='padding:5px; color: #000000'>&nbsp;" & rs("FullName") & "</td>"

            cm_b.CommandText = "select count(*) as Onhand from dm_document where Status_Cd in (" & vStatusList & ") " & _
                " and Emp_Cd ='" & rs("User_Id") & "' " & vFilter

            rs_b = cm_b.ExecuteReader

            If rs_b.Read Then
                vData += "<td class='linkstyle-z' style='padding:5px; cursor:pointer;' onclick='activeMode(""" & rs("User_Id") & """);' title='Click here to show details'>" & rs_b("Onhand") & "</td>"

                vTtl = vTtl + rs_b("Onhand")
            End If
            rs_b.Close()
            vStatusList = ""
            vCtr += 1
        Loop
        rs.Close()

        'cm_b.CommandText = "select count(*) as Onhand from dm_document where Status_Cd in (2,3,9,11,14,17) " & vFilter
        'rs_b = cm_b.ExecuteReader
        'rs_b.Read()

        vData += "<tr>" & _
            "<td class='labelBR' style='padding:5px;' colspan='2'><b>Total : &nbsp;</b>" & _
                "</td><td class='labelC' style='padding:5px;' ><b>" & vTtl & "</b></td>" & _
            "</tr>"

        'rs_b.Close()
        rs.Close()
        c.Close()
        c.Dispose()
        cm.Dispose()
    End Sub

    Private Sub BuildEmpRecords()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim vElapsed As Single = 0
        Dim vStatus As String = ""

        Dim vFilter As String = ""
        'Dim vFromDate As Date
        Dim vAmount As String = ""
        Dim vCtr As Integer = 1
        Dim vDateAssigned As String = ""

        vFilter = ""
        If txtFrom.Text <> "" And txtTo.Text <> "" Then

            'vFromDate = IIf(txtFrom.Text.Length > 10, Format(CDate(txtFrom.Text), "yyyy/MM/dd") & " 00:00:00", Format(CDate(txtFrom.Text), "yyyy/MM/dd") & " 00:00:00")
            'vToDate = IIf(txtTo.Text.Length > 10, Format(CDate(txtTo.Text), "yyyy/MM/dd") & " 23:59:59", Format(CDate(txtTo.Text), "yyyy/MM/dd") & " 23:59:59")

            vFilter += " and Date_Uploaded between '" & Format(CDate(txtFrom.Text), "yyyy/MM/dd") & " 00:00:00" & _
                "' and '" & Format(CDate(txtTo.Text), "yyyy/MM/dd") & " 23:59:59" & "'"

            'vFilter += " and Date_Assigned between '" & Format(CDate(txtFrom.Text), "yyyy/MM/dd") & " 00:00:00" & _
            '    "' and '" & Format(CDate(txtTo.Text), "yyyy/MM/dd") & " 23:59:59" & "'"
        End If

        c.Open()
        cm.Connection = c

        If cmdComp.SelectedValue <> "All" Then
            vFilter += " and Supplier_Cd ='" & cmdComp.SelectedValue & "' "
        End If

        If cmbCatg.SelectedValue <> "All" Then
            vFilter += " and Category_Id=" & cmbCatg.SelectedValue
        End If

        If cmdList.SelectedValue <> "All" Then
            vFilter += " and Status_Cd=" & cmdList.SelectedValue
        Else
            vFilter += " and Status_Cd in (" & vSlist.Value & ")"
        End If

        cm.CommandText = "select Doc_Id, Doc_Name, Date_Uploaded, Date_Assigned, " & _
                "(select SupplierName from supplier where supplier.supplierCd=dm_document.Supplier_Cd) as CompName, " & _
                "(select Descr from dm_document_Status where dm_document_Status.Status_Cd=dm_document.Status_Cd) as StatusName, " & _
                "(select Descr from dm_category where dm_category.Category_Id=dm_document.Category_Id) as CatName, " & _
                "(select Value from dm_document_dtl where dm_document.Doc_Id=dm_document_dtl.Doc_Id and dm_document_dtl.Keyword_Id='35') as VendorName, " & _
                "(select Value from dm_document_dtl where dm_document.Doc_Id=dm_document_dtl.Doc_Id and dm_document_dtl.Keyword_Id='37') as Amount " & _
                "from dm_document where Emp_Cd ='" & vCode.Value & "' " & vFilter & " order by Doc_Id"
        'Response.Write(cm.CommandText)
        rs = cm.ExecuteReader
        vEmpData = ""

        Do While rs.Read
            'vElapsed = Math.Round(DateDiff(DateInterval.Minute, CDate(rs("Date_Assigned")), Now) / 60, 2)

            If Not IsDBNull(rs("Amount")) Then
                vAmount = rs("Amount").replace(",", "")
            End If

            If Not IsDBNull(rs("Date_Assigned")) Then
                vDateAssigned = Format(rs("Date_Assigned"), "MM/dd/yyyy hh:mm:ss")
            End If

            vEmpData += "<tr class='linkstyle-row' onclick='divOpen(" & rs("Doc_Id") & ");'><td class='labelC'>" & vCtr & "</td>" & _
            "<td class='labelC' style='padding:5px; color: #000000;'>" & rs("Doc_Id") & "</td>" & _
            "<td class='labelL' style='padding:5px; color: #000000;'>&nbsp;" & rs("Doc_Name") & "</td>" & _
            "<td class='labelL' style='padding:5px; color: #000000;'>&nbsp;" & rs("CompName") & "</td>" & _
            "<td class='labelL' style='padding:5px; color: #000000;'>&nbsp;" & rs("CatName") & "</td>" & _
            "<td class='labelL' style='padding:5px; color: #000000;'>&nbsp;" & rs("StatusName") & "</td>" & _
            "<td class='labelC' style='padding:5px; color: #000000;'>" & Format(rs("Date_Uploaded"), "MM/dd/yyyy hh:mm") & "</td>" & _
            "<td class='labelC' style='padding:5px; color: #000000;'>" & vDateAssigned & "</td>" & _
            "<td class='labelR' style='padding:5px; color: #000000;'>" & Format(Val(vAmount), "###,###,##0.00") & "</td>" & _
            "</tr>"

            ' "<td class='labelL' style='padding:5px; color: #000000;'>" & rs("VendorName") & "</td>" & _
            ' 'Format(Val(Eval(rs("Amount")).ToString.Replace(",", "")), "###,###,##0.00") & "</td>" & _
            '<td class='labelBC' style='padding:5px; color: #000000;'>" & vElapsed & "</td>"<td class='labelBC' style='padding:5px; color: #000000;'>" & vElapsed & "</td>" & _
            vElapsed = 0
            vCtr += 1
        Loop

        rs.Close()
        c.Close()
        c.Dispose()
        cm.Dispose()
    End Sub

    Protected Sub cmdRefresh_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdRefresh.Click
        If txtFrom.Text.Trim <> "" Then
            If Not IsDate(txtFrom.Text) Then
                vscript = "alert('Invalid date and time format in Date from field')"
                Exit Sub
            End If

            If txtTo.Text.Trim = "" Then
                vscript = "alert('Invalid date and time format in Date To field')"
                Exit Sub
            End If

        End If

        If txtTo.Text.Trim <> "" And txtFrom.Text.Trim <> "" Then
            If Not IsDate(txtTo.Text) Then
                vscript = "alert('Invalid date and time format in Date to field')"
                Exit Sub
            End If

            If CDate(txtFrom.Text) > CDate(txtTo.Text) Then
                vscript = "alert('From Date should be earlier than To Date')"
                Exit Sub
            End If

            If txtFrom.Text = "" Then
                vscript = "alert('Invalid date and time format in Date From field')"
                Exit Sub
            End If

        ElseIf (txtTo.Text.Trim <> "" And txtFrom.Text.Trim = "") Or _
                (txtTo.Text.Trim = "" And txtFrom.Text.Trim <> "") Then
            vscript = "alert('You should put valid date values for both From date and To Date fields.');"
            Exit Sub
        End If

        BuildRecords()
        vCode.Value = ""
        vEmpData = ""
    End Sub

    Protected Sub cmdReturn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.Click
        Server.Transfer("main.aspx")
    End Sub
End Class
