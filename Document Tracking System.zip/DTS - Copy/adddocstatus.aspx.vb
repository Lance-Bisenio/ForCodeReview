﻿Imports denaro.fis
Partial Class adddocstatus
    Inherits System.Web.UI.Page
    Dim c As New sqlclient.sqlConnection
    Public vscript As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = Nothing Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If

        If Not IsPostBack Then
            Dim cm As New sqlclient.sqlCommand
            Dim dr As sqlclient.sqlDataReader
            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c
            cm.CommandText = "select status_cd,Descr,IsEnable from dm_document_status where status_cd='" & Session("vline") & "'"
            dr = cm.ExecuteReader
            If dr.Read Then

                rdoGSettings.SelectedValue = dr("IsEnable")
                txtdocstatid.Text = dr("status_cd")
                txtdocstatname.Text = dr("Descr")
            End If
            dr.Close()
            cm.Dispose()
            c.Close()
        End If
    End Sub

    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Dim cm As New sqlclient.sqlCommand
        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c
        If Session("vline") <> "" Then
            EventLog(Session("uid"), Request.ServerVariables("REMOTE_ADDR"), "EDIT", "", "", "Document Status" & Session("vline") & _
                     "-" & txtdocstatname.Text, "Document Status")

            cm.CommandText = "update dm_document_status set IsEnable='" & rdoGSettings.SelectedValue & "', Descr='" & CleanVar(txtdocstatname.Text) & _
                "' where status_cd='" & Session("vline") & "'"

            vscript = "alert('Record successfully saved.'); window.opener.document.form1.submit(); window.close(); "
        Else
            EventLog(Session("uid"), Request.ServerVariables("REMOTE_ADDR"), "ADD", "", "", "Document Status" & _
                     "-" & txtdocstatname.Text, "Document Status")

            cm.CommandText = "INSERT INTO dm_document_status(Descr,IsEnable)values('" & CleanVar(txtdocstatname.Text) & "','" & rdoGSettings.SelectedValue & "')"
            vscript = "alert('Record successfully saved.'); window.opener.document.form1.submit();"
        End If

        cm.ExecuteNonQuery()
        cm.Dispose()
        c.Close()


    End Sub

    Protected Sub btnClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Session.Remove("vline")
        vscript = "self.close();"
    End Sub

   
End Class
