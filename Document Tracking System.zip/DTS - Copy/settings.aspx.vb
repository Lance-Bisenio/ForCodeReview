﻿Imports denaro.fis
Partial Class settings
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Protected Sub cmdClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdClose.Click
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If

        If Not CanRun(Session("caption"), Request.Item("id")) Then
            Session("denied") = 1
            Server.Transfer("main.aspx")
        End If

        If Not IsPostBack Then
            Dim c As New SqlClient.SqlConnection(connStr)
            Dim cm As New SqlClient.SqlCommand
            Dim rs As SqlClient.SqlDataReader

            Try
                c.Open()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                c.Dispose()
                cm.Dispose()
                Exit Sub
            End Try

            cm.Connection = c
            cm.CommandText = "select UploadPath,EmailOption,Authentication from glsyscntrl"
            Try
                rs = cm.ExecuteReader
                If rs.Read Then
                    txtUploadPath.Text = IIf(IsDBNull(rs("UploadPath")), "", rs("UploadPath"))
                    rdoEmail.SelectedValue = rs("EmailOption")
                    rdoAuthentication.SelectedValue = rs("Authentication")
                End If
                rs.Close()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to retrieve database. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            Finally
                c.Close()
                cm.Dispose()
            End Try
        Else
            If txtConfirm.Value = "y" Then
                Try
                    Dim vFile As String = Server.MapPath(".") & "\..\Uploaded\" & txtUploadPath.Text
                    'Dim vfile As String = txtUploadPath.Text
                    'Response.Write(vFile)
                    IO.Directory.CreateDirectory(vFile)
                    SaveChanges()
                Catch ex As IO.IOException
                    vScript = "alert('Error occurred while trying to create the folder. Error is: " & _
                        ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                End Try
            End If
        End If
    End Sub
    Private Sub SaveChanges()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        cm.Connection = c
        cm.CommandText = "update glsyscntrl set UploadPath='" & Server.MapPath(".") & "\..\Uploaded" & txtUploadPath.Text & _
                        "',EmailOption=" & rdoEmail.SelectedValue & ",Authentication=" & rdoAuthentication.SelectedValue
        'cm.CommandText = "update glsyscntrl set UploadPath='" & txtUploadPath.Text & _
        ' "',EmailOption=" & rdoEmail.SelectedValue
        Try
            cm.ExecuteNonQuery()
            vScript = "alert('Changes were successfully saved.');"
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to save changes. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            cm.Dispose()
            c.Dispose()
        End Try
    End Sub
    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        'validate existence of folder.
        'Response.Write(txtUploadPath.Text)
        If IO.Directory.Exists(txtUploadPath.Text) Then
            'file is valid
            SaveChanges()
        Else
            vScript = "return ask();"
        End If
    End Sub
End Class
