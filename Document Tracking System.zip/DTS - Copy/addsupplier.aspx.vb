﻿Imports denaro.fis
Partial Class addsupplier
    Inherits System.Web.UI.Page
    Public vscript As String = ""
    Dim c As New sqlclient.sqlConnection

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
       
        If Session("uid") = Nothing Then
            vscript = "alert('Your login session has expired. Please re-login again.'); window.close();"
            Exit Sub
        End If

        If Not IsPostBack Then
            Dim cm As New sqlclient.sqlCommand
            Dim dr As sqlclient.sqlDataReader
            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c
            cm.CommandText = "select suppliercd,suppliername,contactperson,contactno,faxno,address,ParentDealerCd, Terms  " & _
                             "from supplier where suppliercd='" & CleanVar(Session("vline")) & "'"
            dr = cm.ExecuteReader
            If dr.Read Then
                txtSuppId.Text = dr("suppliercd")
                txtSuppName.Text = dr("suppliername")
                txtContactPerson.Text = IIf(IsDBNull(dr("contactperson")), "", dr("contactperson"))
                txtContactNumber.Text = IIf(IsDBNull(dr("contactno")), "", dr("contactno"))
                txtFaxNo.Text = IIf(IsDBNull(dr("faxno")), "", dr("faxno"))
                txtAddress.Text = IIf(IsDBNull(dr("address")), "", dr("address"))
                txtSAPVendorCd.Text = IIf(IsDBNull(dr("ParentDealerCd")), "", dr("ParentDealerCd"))
                txtPTerms.Text = IIf(IsDBNull(dr("Terms")), "", dr("Terms"))
            End If
            dr.Close()
            cm.Dispose()
            c.Close()
        End If
    End Sub

    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Dim cm As New sqlclient.sqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim vSupplierCd As String = ""

        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c
        If txtSuppId.Text = "" Or txtSuppName.Text = "" Then
            cm.Dispose()
            c.Close()
            vscript = "alert('Supplier code and Supplier name must be filled up.');"
            Exit Sub
        Else
            If Session("vline") = "" Then
                cm.CommandText = "SELECT suppliername from supplier WHERE suppliercd='" & CleanVar(txtSuppId.Text) & "'"
                rs = cm.ExecuteReader()
                If rs.Read Then
                    vscript = "alert('Duplicate record found! Please provide a different supplier code.');"
                    rs.Close()
                    cm.Dispose()
                    c.Close()
                    Exit Sub
                End If
                rs.Close()
                'cm.Dispose()
                'c.Close()
            End If
        End If


        'cm.Connection = c
        If Session("vline") <> "" Then
            EventLog(Session("uid"), Request.ServerVariables("REMOTE_ADDR"), "EDIT", "", "", "Supplier " & Session("vline") & _
                     "-" & txtSuppName.Text, "Supplier")

            cm.CommandText = "update supplier set " & _
                "SupplierCd='" & CleanVar(txtSuppId.Text) & "', " & _
                "SupplierName='" & CleanVar(txtSuppName.Text) & "', " & _
                "ContactPerson='" & CleanVar(txtContactPerson.Text) & "', " & _
                "ContactNo='" & CleanVar(txtContactNumber.Text) & "', " & _
                "Faxno='" & CleanVar(txtFaxNo.Text) & "', " & _
                "Address='" & CleanVar(txtAddress.Text) & "', " & _
                "ParentDealerCd='" & CleanVar(txtSAPVendorCd.Text) & "', " & _
                "Terms='" & CleanVar(txtPTerms.Text) & "' " & _
                "where SupplierCd='" & CleanVar(Session("vline")) & "'"


        Else
            EventLog(Session("uid"), Request.ServerVariables("REMOTE_ADDR"), "ADD", "", "", "Supplier" & _
                     "-" & txtSuppName.Text, "Section")

            cm.CommandText = "select MAX(CONVERT(INT, SupplierCd)) as vSupplierCd from supplier "
            rs = cm.ExecuteReader()
            If rs.Read Then
                vSupplierCd = rs("vSupplierCd") + 1
            End If
            rs.Close()

            'cm.CommandText = "INSERT INTO supplier(SupplierCd,SupplierName,ContactPerson,ContactNo,FaxNo,Address,ParentDealerCd,Terms)values('" & _
            '                 CleanVar(txtSuppId.Text) & "','" & CleanVar(txtSuppName.Text) & "','" & CleanVar(txtContactPerson.Text) & "','" & _
            '                 CleanVar(txtContactNumber.Text) & "','" & CleanVar(txtFaxNo.Text) & "','" & CleanVar(txtAddress.Text) & "')"

            cm.CommandText = "INSERT INTO supplier(SupplierCd,SupplierName,ContactPerson,ContactNo,FaxNo,Address,ParentDealerCd,Terms)values('" & _
                             vSupplierCd & "','" & CleanVar(txtSuppName.Text) & "','" & CleanVar(txtContactPerson.Text) & "','" & _
                             CleanVar(txtContactNumber.Text) & "','" & CleanVar(txtFaxNo.Text) & "','" & CleanVar(txtAddress.Text) & _
                             "','" & CleanVar(txtSAPVendorCd.Text) & "','" & CleanVar(txtPTerms.Text) & "')"

            'Response.Write(cm.CommandText)
            


        End If

        cm.ExecuteNonQuery()
        cm.Dispose()
        c.Close()
        vscript = "alert('Record successfully saved.'); window.opener.document.form1.submit(); window.close();"
        
    End Sub

    Protected Sub btnClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Session.Remove("vline")
        vscript = "self.close();"
    End Sub
End Class
