﻿Imports denaro.fis
Partial Class queue_multi_assign
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Public vDump As String = ""
    Public vAction As String = ""

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load

        If Session("uid") = "" Then
            vScript = "alert('Your login session has expired. Please re-login again.'); window.close();"
            Exit Sub
        End If

        If Not IsPostBack Then
            BuildCombo("select AgencyCd,AgencyName from agency where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='agency' and Property_Value=AgencyCd) order by AgencyName", cmbAgency)

            BuildCombo("select Status_Cd,Descr from dm_document_status where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='Status' and Property_Value=Status_Cd) order by Descr", cmbStatus)
            'cmbStatus.Items.Add("All")
            'cmbStatus.SelectedValue = "All"

            BuildCombo("select Category_Id,Descr from dm_Category where exists (select User_Id from rights_list where User_Id='" & _
               Session("uid") & "' and property='Category' and Property_Value=Category_Id) order by Descr", cmdCatg)
            'cmdCatg.Items.Add("All")
            'cmdCatg.SelectedValue = "All"

            BuildCombo("select SupplierCd, SupplierName from supplier order by SupplierName", cmdVendor)
            cmdVendor.Items.Add("All")
            cmdVendor.SelectedValue = "All"

            BuildCombo("select Location_Id,Descr from dm_document_location  order by Descr", cmdLoc)
            cmdLoc.Items.Add("All")
            cmdLoc.SelectedValue = "All"

            BuildCombo("select Type_Cd,Descr from dm_contract_type  order by Descr", cmbDocType)
            cmbDocType.Items.Add("All")
            cmbDocType.SelectedValue = "All"

            BuildCombo("select User_Id,Fullname from user_list where POSMenus like 'Active%' and Position='Processor' ", cmbProcess)
            cmbProcess.Items.Add(" ")
            cmbProcess.SelectedValue = " "
        End If

        

    End Sub

    Protected Sub cmdSearch_Click(sender As Object, e As EventArgs) Handles cmdSearch.Click
        txtSelectedDocs.Value = ""
        txtDocList.Value = ""
        txtSelectedStatus.Value = ""
        cmbProcess.SelectedValue = " "

        BuildProcess()
        BuildRecords()
    End Sub

    Private Sub BuildProcess()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cmRef As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim rsRef As SqlClient.SqlDataReader
        Dim vFilter As String = ""

        c.Open()
        cm.Connection = c
        cmRef.Connection = c

        vFilter = ""

        If cmbAgency.SelectedValue <> "All" Then
            vFilter += " AgencyCd ='" & cmbAgency.SelectedValue & "' "
        End If
        If cmbStatus.SelectedValue <> "All" Then
            vFilter += " and Status_Cd =" & cmbStatus.SelectedValue
        End If

        cm.CommandText = "select NextTask from dm_process_dtl where " & vFilter
        'Response.Write(cm.CommandText)
        Try
            rs = cm.ExecuteReader
            If rs.Read Then
                cmRef.CommandText = "select *, " & _
                    "(select Descr from dm_document_status where dm_document_status.Status_Cd=dm_process_dtl.Status_Cd) as StatusName " & _
                    "from dm_process_dtl where TaskId=" & rs("NextTask")
                rsRef = cmRef.ExecuteReader
                Do While rsRef.Read

                    If rsRef("SetResource") = 1 Then
                        vAction += "<input type='button' id='" & rsRef("Status_Cd") & "' name='" & rsRef("Status_Cd") & "' value='Assign " & rsRef("StatusName") & "' " & _
                            "onclick='getList(""" & rsRef("Status_Cd") & """,""" & rsRef("StatusName") & """,""" & rsRef("SetResource") & """);' >" ' openlink(""" & cmbStatus.SelectedValue & """, """ & rsRef("Status_Cd") & """);'>"  disabled='disabled'
                    Else
                        vAction += "<input type='button' id='" & rsRef("Status_Cd") & "' name='" & rsRef("Status_Cd") & "' value='" & rsRef("StatusName") & "' " & _
                            "onclick='getList(""" & rsRef("Status_Cd") & """,""" & rsRef("StatusName") & """,""" & rsRef("SetResource") & """);' >"
                    End If
                Loop
            End If
            rs.Close()
        Catch ex As SqlClient.SqlException

        End Try

        cm.Dispose()
        cmRef.Dispose()
        c.Close()
        c.Dispose()

    End Sub

    Private Sub BuildRecords()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        'Dim cmRef As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        'Dim da As New SqlClient.SqlDataAdapter
        'Dim ds As New DataSet

        'Dim vElapsed As Single = 0
        Dim vClass As String = "class='odd'"

        Dim vFromDate As Date
        Dim vToDate As Date
        Dim vFilter As String = ""
        Dim vAcountable As String = ""
        Dim vCtr As Integer = 1
        Dim vStatus() As String = {"", "", ""}  'index 0=status 5, index 1=status 6,index 2=status 7

        c.Open()
        cm.Connection = c

        cm.CommandText = "select * from user_list where User_Id='" & Session("uid") & "'"
        rs = cm.ExecuteReader
        If rs.Read Then
            Select Case rs("Position")
                Case "Processor"
                    vAcountable = " Emp_Cd='" & Session("uid") & "' and "
                Case "Team Leader"
                    vAcountable = ""
            End Select
        End If
        rs.Close()

        vFilter = ""

        'cm.CommandText = "select * from dm_process_dtl where Status_Cd=" & cmbStatus.SelectedValue
        'rs = cm.ExecuteReader
        'If rs.Read Then

        'End If
        'rs.Close()

        vFilter = ""
        If cmbAgency.SelectedValue <> "All" Then
            vFilter += " and AgencyCd ='" & cmbAgency.SelectedValue & "' "
        End If

        If txtDDateFrom.Text <> "" And txtDDateTo.Text <> "" Then

            vFromDate = IIf(txtDDateFrom.Text.Length > 10, Format(CDate(txtDDateFrom.Text), "yyyy/MM/dd HH:mm:ss"), Format(CDate(txtDDateFrom.Text), "yyyy/MM/dd") & " 00:00:00")
            vToDate = IIf(txtDDateTo.Text.Length > 10, Format(CDate(txtDDateTo.Text), "yyyy/MM/dd HH:mm:ss"), Format(CDate(txtDDateTo.Text), "yyyy/MM/dd") & " 23:59:59")

            vFilter += " and DueDate between '" & vFromDate & _
                "' and '" & vToDate & "' "
        End If

        If cmdCatg.SelectedValue <> "All" Then
            vFilter += " and Category_Id =" & cmdCatg.SelectedValue
        End If

        If cmbStatus.SelectedValue <> "All" Then
            vFilter += " and Status_Cd =" & cmbStatus.SelectedValue
        End If

        If cmbDocType.SelectedValue <> "All" Then
            vFilter += " and Contract_Id ='" & cmbDocType.SelectedValue & "' "
        End If

        If cmdLoc.SelectedValue <> "All" Then
            vFilter += " and Location_Id ='" & cmdLoc.SelectedValue & "' "
        End If

        If cmdVendor.SelectedValue <> "All" Then
            vFilter += " and Supplier_Cd ='" & cmdVendor.SelectedValue & "' "
        End If

        cm.CommandText = "select DueDate, OrigFileName, Doc_Id, Doc_Name, Date_Assigned, Date_Encoded, Date_Uploaded, " & _
            "(select Terms from supplier where supplier.SupplierCd=dm_document.Supplier_Cd) as PayTerms, " & _
            "(select SupplierName from supplier where supplier.SupplierCd=dm_document.Supplier_Cd) as VendorDescr, " & _
            "(select Descr from dm_category where dm_category.Category_Id=dm_document.Category_Id) as CatName, " & _
            "(select Descr from dm_document_location where dm_document_location.Location_Id=dm_document.Location_Id) as LocName, " & _
            "(select Descr from dm_contract_type where dm_contract_type.Type_Cd=dm_document.Contract_Id) as DocTypeName, " & _
            "(select Descr from dm_document_status where dm_document_status.Status_Cd=dm_document.Status_Cd) as StatusName, " & _
            "(select FullName from user_list where user_list.User_Id=dm_document.Emp_Cd ) as FullName, " & _
            "(select Value from dm_document_dtl where dm_document.Doc_Id=dm_document_dtl.Doc_Id and dm_document_dtl.Keyword_Id='37') as Amount " & _
            "from dm_document where Status_Cd in (" & Session("Statuslist") & ") and " & vAcountable & " '" & Session("Catglist") & "' like '%'+cast(Category_Id as varchar)+'%'" & vFilter
        'Response.Write(cm.CommandText)
        Try
            rs = cm.ExecuteReader

            Do While rs.Read

                vDump += "<tr " & vClass & ">"
                vDump += "<td class='labelC'><input type='checkbox' id='" & rs("Doc_Id") & "' name='chk' /></td>"
                vDump += "<td class='labelC'>" & vCtr & "</td>"
                vDump += "<td class='labelC'>" & rs("Doc_Id") & "</td>"
                vDump += "<td class='labelL'>&nbsp;" & rs("Doc_Name") & "</td>"
                vDump += "<td class='labelL'>" & rs("VendorDescr") & "</td>"
                vDump += "<td class='labelR'>" & rs("Amount") & "&nbsp;</td>"
                vDump += "<td class='labelC'>" & rs("PayTerms") & "</td>"
                vDump += "<td class='labelC'>" & Format(rs("Date_Uploaded"), "MM/dd/yyyy") & "</td>"
                vDump += "</tr>"

                txtDocList.Value += rs("Doc_Id") & ","

                vCtr += 1

                If vClass = "class='odd'" Then
                    vClass = "class='even'"
                Else
                    vClass = "class='odd'"
                End If
            Loop
            rs.Close()
        Catch ex As SqlClient.SqlException

        End Try

        cm.Dispose()
        c.Close()
        c.Dispose()

    End Sub

    Private Sub SaveProcess()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader

        Dim cmRef As New SqlClient.SqlCommand
        Dim rsRef As SqlClient.SqlDataReader

        Dim vDuration As Single = 0
        Dim vDateStart As Date
        Dim vGRno As String = ""

        c.Open()
        cm.Connection = c
        cmRef.Connection = c

        '=============================================================================================================================================
        ' VALIDATE DM_PROCESS IF THE SELECTED STATUS IS THE LAST PROCESS
        ' GET THE NEXT STATUS BASE ON THE SELECTED STATUS
        '=============================================================================================================================================
        Dim vPosted As String = ""
        Dim vNextStatus As String = ""


        '=============================================================================================================================================
        'save a copy to the documents notes
        '=============================================================================================================================================

        cmRef.CommandText = "select * from dm_document where Doc_Id in (" & Mid(txtSelectedDocs.Value, 1, Len(txtSelectedDocs.Value) - 1) & ")"
        Try

            rsRef = cmRef.ExecuteReader
            Do While rsRef.Read

                vDateStart = rsRef("Date_Encoded")
                If Not IsDBNull(rsRef("Date_Assigned")) Then
                    vDateStart = CDate(rsRef("Date_Assigned"))
                End If

                vDuration = Math.Round(DateDiff(DateInterval.Minute, vDateStart, Now) / 60, 2)
                cm.CommandText = "insert into dm_document_notes (Doc_Id, Notes, Date_Encoded, Encoded_By, Emp_Cd," & _
                    "Date_Start,Date_Finish,Duration,Status_Cd) values (" & rsRef("Doc_Id") & ",'" & _
                    IIf(IsDBNull(rsRef("Contents")), "For Review", rsRef("Contents")) & "','" & _
                    Format(CDate(rsRef("Date_Encoded")), "yyyy/MM/dd HH:mm:ss") & "','" & _
                    rsRef("Encoded_By") & "','" & IIf(IsDBNull(rsRef("Emp_Cd")), rsRef("Encoded_By"), rsRef("Emp_Cd")) & _
                    "','" & Format(vDateStart, "yyyy/MM/dd HH:mm:ss") & _
                    "','" & Format(Now, "yyyy/MM/dd HH:mm:ss") & "'," & vDuration & "," & rsRef("Status_Cd") & ")"
                cm.ExecuteNonQuery()

                cm.CommandText = "insert into dm_ledger (Doc_ID, Status_Cd, Category_Cd, TranDate, CreatedBy, Supplier_Cd, Remarks, AgencyCd, IsAssignTo) " & _
                    "values (" & rsRef("Doc_Id") & ", " & txtSelectedStatus.Value & ", " & rsRef("Category_Id") & ", '" & _
                    Format(Now, "yyyy/MM/dd HH:mm:ss") & "', '" & Session("uid") & "', " & rsRef("Supplier_Cd") & ", '[Multi Assign Module] : " & txtReason.Text.Trim & _
                    "','" & rsRef("AgencyCd") & "' ,'" & cmbProcess.SelectedValue & "')"
                cm.ExecuteNonQuery()

                ' =============================================================================================================================================
                ' GET PROCESS FLOW
                ' =============================================================================================================================================

                cm.CommandText = "select * from dm_process where Category_Id='" & rsRef("Category_Id") & _
                    "' and PrevStatus_Cd='" & rsRef("Status_Cd") & "' and Status_Cd='" & txtSelectedStatus.Value & "' "

                rs = cm.ExecuteReader
                If rs.Read Then
                    vNextStatus = IIf(IsDBNull(rs("NextStep")), ",NextStatus=null", ",NextStatus='" & rs("NextStep") & "'")
                End If
                rs.Close()

                ' =============================================================================================================================================
                ' UPDATE DM_DOCUMENT
                ' =============================================================================================================================================

                cm.CommandText = "update dm_document set " & _
                    "DateModify='" & Now() & "', " & _
                    "ModifyBy='" & Session("uid") & "', " & _
                    "Contents='" & txtReason.Text & "'," & _
                    "PrevStatus=Status_Cd, Status_Cd=" & txtSelectedStatus.Value & " " & vNextStatus & "," & _
                    "Emp_Cd='" & cmbProcess.SelectedValue & "'," & _
                    "Date_Assigned='" & Format(Now, "yyyy/MM/dd HH:mm:ss") & "' " & _
                    "where Doc_Id=" & rsRef("Doc_Id")
                cm.ExecuteNonQuery()

                'Response.Write(cm.CommandText & "<br>")
                '=============================================================================================================================================
                '=============================================================================================================================================
            Loop
            rsRef.Close()

        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to save changes. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            cm.Dispose()
            cmRef.Dispose()
        End Try

        'vScript = "alert('Changes were successfully saved.');"'window.close();"
        'vScript = "window.opener.document.form1.submit(); "
    End Sub

    Protected Sub cmdSave_Click(sender As Object, e As EventArgs) Handles cmdSave.Click

        If txtResouceType.Value = 1 Then
            If cmbProcess.SelectedValue = " " Then
                vScript = "alert('Please select processor.');" ' document.getElementById('trans').style.visibility = 'visible'; document.getElementById('vRemarks').style.visibility = 'visible';"

                BuildProcess()
                BuildRecords()

                Exit Sub
            End If
        End If

        SaveProcess()

        txtSelectedDocs.Value = ""
        txtDocList.Value = ""
        txtSelectedStatus.Value = ""

        BuildProcess()
        BuildRecords()

        vScript = "window.opener.document.form1.txtReload.value='Reload';  window.opener.document.form1.submit();  "
    End Sub

    Protected Sub cmdClose_Click(sender As Object, e As EventArgs) Handles cmdClose.Click
        vScript = "window.close();"
    End Sub
End Class
