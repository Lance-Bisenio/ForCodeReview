﻿Imports denaro.fis
Partial Class monthlysla_dtl
    Inherits System.Web.UI.Page
    Public vScript As String = ""

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        'Response.Write(Mid(Session(Request.Item("id")), 1, Len(Session(Request.Item("id"))) - 1) & "<br>")
        'Response.Write(Session(Request.Item("id")))

        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
        End If

        If Session("uid") = "" Or Session("uid") = Nothing Then
            vScript = "alert('Your login session has expired. Please re-login again.'); window.close();"
            Exit Sub
        End If

        If Not IsPostBack Then
            BuildCombo("select distinct(Emp_Cd) as vEmp,(select FullName from user_list where User_Id=Emp_Cd) as vFullName  " & _
                       "from sla_temp where CreatedBy='" & Session("uid") & "' and  Remarks='GoodDocs' ", cmbFilters)

            cmbFilters.Items.Add("03DAYS")
            cmbFilters.Items.Add("4DAYS")
            cmbFilters.Items.Add("B5DAYS")
            cmbFilters.Items.Add("OTHERS")

            cmbFilters.SelectedValue = Request.Item("vRef")

            cmbShow.Items.Clear()
            For iCtr = 1 To 6
                cmbShow.Items.Add(15 * iCtr)
            Next iCtr
            BuildData()
        End If

    End Sub

    Private Sub BuildData()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cmRef As New SqlClient.SqlCommand
        'Dim rs As SqlClient.SqlDataReader
        Dim da As New SqlClient.SqlDataAdapter
        Dim ds As New DataSet
        Dim vSQL As String = ""
        Dim vSubFilter As String = ""

        c.Open()
        cm.Connection = c
        cmRef.Connection = c

        cmbStatus.Enabled = False

        vSubFilter = " Remarks='GoodDocs' and Emp_Cd='" & cmbFilters.SelectedValue & "'"

        If cmbFilters.SelectedValue = "03DAYS" Then
            vSubFilter = " Remarks='GoodDocs' and  DaysProcess between 0 and 3"
        End If
        If cmbFilters.SelectedValue = "4DAYS" Then
            vSubFilter = " Remarks='GoodDocs' and  DaysProcess = 4"
        End If
        If cmbFilters.SelectedValue = "B5DAYS" Then
            vSubFilter = " Remarks='GoodDocs' and  DaysProcess >=5"
        End If

        If cmbFilters.SelectedValue = "OTHERS" Then
            vSubFilter = " Remarks='NonGoodDocs'  "

            cmbStatus.Enabled = True
            If txtTags.Value = "" Then
                vSQL = "select distinct(Status_Cd) as vStatusCd, " & _
                                              "(select Descr from dm_document_status where dm_document_status.Status_Cd=sla_temp.Status_Cd) as vStatusName  " & _
                                              "from sla_temp where  CreatedBy='" & Session("uid") & "' and " & vSubFilter & "  "

                BuildCombo(vSQL, cmbStatus)
                cmbStatus.Items.Add("All")
                cmbStatus.SelectedValue = "All"
                txtTags.Value = 1
            End If

            If cmbStatus.SelectedValue <> "All" Then
                vSubFilter += " and Status_Cd=" & cmbStatus.SelectedValue
            End If
        Else
            cmbStatus.Items.Clear()
            txtTags.Value = ""
        End If

        vSQL = "select Doc_Id,DaysProcess, DaysProcess, " & _
            "(select Doc_Name from dm_document where dm_document.Doc_Id=sla_temp.Doc_Id) as vDocName, " & _
            "(select Date_Uploaded from dm_document where dm_document.Doc_Id=sla_temp.Doc_Id) as vDateRec, " & _
            "(select DueDate from dm_document where dm_document.Doc_Id=sla_temp.Doc_Id) as vDueDate, " & _
            "(select SAP_Number from dm_document where dm_document.Doc_Id=sla_temp.Doc_Id) as vSAPNum, " & _
            "(select VendorClearingNo from dm_document where dm_document.Doc_Id=sla_temp.Doc_Id) as vVendorClrNo,  " & _
            "(select BatchClearingNo from dm_document where dm_document.Doc_Id=sla_temp.Doc_Id) as vBatchClrNo, " & _
            "(select SupplierName from supplier where supplier.supplierCd=sla_temp.Supplier_Cd) as vVendorName,  " & _
            "(select Descr from dm_document_Status where dm_document_status.Status_Cd=sla_temp.Status_Cd) as vCurrStatus, " & _
            "(select Value from dm_document_dtl where sla_temp.Doc_Id=dm_document_dtl.Doc_Id and dm_document_dtl.Keyword_Id='37') as vAmount, " & _
            "(select Value from dm_document_dtl where sla_temp.Doc_Id=dm_document_dtl.Doc_Id and dm_document_dtl.Keyword_Id='38') as vRef " & _
            "from sla_temp where   CreatedBy='" & Session("uid") & "' and " & vSubFilter & " order by sla_temp.DaysProcess "

        Session("vSQL") = vSQL

        da = New SqlClient.SqlDataAdapter(vSQL, c)

        Try
            'Response.Write(da.SelectCommand.CommandText)
            da.Fill(ds, "document")

            tlbDocInfo.DataSource = ds.Tables("document")
            tlbDocInfo.DataBind()
            lblTotalDocs.Text = "<b>Total Documents Retrieved : " & tlbDocInfo.DataSource.Rows.Count & "</b>"

        Catch ex As SqlClient.SqlException
            'Response.Write(da.SelectCommand.CommandText)
        End Try

        da.Dispose()
        ds.Dispose()
        c.Dispose()

    End Sub

    Protected Sub tlbDocInfo_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles tlbDocInfo.PageIndexChanging
        tlbDocInfo.PageIndex = e.NewPageIndex
        BuildData()
    End Sub

    Protected Sub cmbShow_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbShow.SelectedIndexChanged
        tlbDocInfo.PageSize = cmbShow.SelectedValue
        BuildData()
    End Sub

    Protected Sub tlbDocInfo_SelectedIndexChanged(sender As Object, e As EventArgs) Handles tlbDocInfo.SelectedIndexChanged
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand("select Doc_Id,Status_Cd from dm_document where Doc_Id=" & tlbDocInfo.SelectedRow.Cells(1).Text, c)
        Dim rs As SqlClient.SqlDataReader

        c.Open()
        rs = cm.ExecuteReader
        If rs.Read Then
            vScript = "openlink(" & rs("Doc_Id") & "," & rs("Status_Cd") & ");"
        End If
        rs.Close()
        c.Close()
        c.Dispose()
        cm.Dispose()
    End Sub

    Protected Sub cmbFilters_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbFilters.SelectedIndexChanged
        BuildData()
    End Sub

    Protected Sub cmbStatus_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbStatus.SelectedIndexChanged
        BuildData()
    End Sub

    Protected Sub cmbDump_Click(sender As Object, e As EventArgs) Handles cmbDump.Click

        Dim vFile As String = ""
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim cmref As New SqlClient.SqlCommand

        Dim vFilename = Server.MapPath(".") & "/downloads/" & Session.SessionID & "-Monthly_SLA_Report.csv"
        Dim vDump As New StringBuilder
        Dim vBuildData As String = ""

        c.Open()
        cm.Connection = c
        cmref.Connection = c

        If IO.File.Exists(vFilename) Then
            Try
                IO.File.Delete(vFilename)
            Catch ex As IO.IOException
                vScript = "alert('Error deleting dump file. Error is: " & ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                Exit Sub
            End Try
        End If

        vDump.AppendLine("Doc Id, Doc Name, Vendor Name, Status, Amount, Reference, SAP No., Date Receive, Days")

        'Response.Write(cm.CommandText)
        cm.CommandText = Session("vSQL")
        rs = cm.ExecuteReader
        Do While rs.Read

            vBuildData = rs("Doc_Id") & ", " & _
                rs("vDocName").ToString.Replace(",", "") & ", " & _
                rs("vVendorName").ToString.Replace(",", "") & "," & _
                rs("vCurrStatus") & "," & _
                rs("vAmount") & "," & _
                rs("vRef").ToString.Replace(",", "") & "," & _
                rs("vSAPNum") & "," & _
                rs("vDateRec") & "," & _
                rs("DaysProcess") & "  "

            vDump.AppendLine(vBuildData)
        Loop

        IO.File.WriteAllText(vFilename, vDump.ToString)
        vScript = "alert('Download complete.'); window.open('downloads/" & Session.SessionID & "-Monthly_SLA_Report.csv');"

        rs.Close()
        cm.Dispose()
        cmref.Dispose()

        c.Close()
        c.Dispose()

    End Sub

    Protected Sub cmbSearch_Click(sender As Object, e As EventArgs) Handles cmbSearch.Click
        BuildData()

    End Sub
End Class
