﻿Imports denaro.fis
Partial Class processorcount_fetch
    Inherits System.Web.UI.Page
    Public vReturn As String = ""
    Dim vAct As Integer = 0
    Dim vGR As Integer = 0
    Dim vDiff As Integer = 0
    Dim vTotalAct As Integer = 0
    Dim vTotalRG As Integer = 0

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Or Session("uid") = Nothing Then
            vReturn = "expired"
            Exit Sub
        End If

        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader

        Dim vDump As New StringBuilder
        Dim vDocAmount As String = ""
        Dim vString As String = ""
        Dim vTranDate As Date = CDate(Request.Form("txn"))

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vReturn = "error"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        cm.Connection = c

        Try
            cm.CommandText = "select User_Id, "
            For i As Integer = 8 To 21

                cm.CommandText += "(select count(distinct Doc_Id) from dm_ledger a where a.Status_Cd=10 and exists  " & _
                    "(select Doc_Id from dm_document where Status_Cd not in (11,16,19,20) and a.Doc_Id=dm_document.Doc_Id) and  " & _
                        "TranDate between '" & vTranDate & "  " & Format(IIf(i = 8, 0, i), "00") & ":00:00' and '" & _
                            vTranDate & "  " & Format(i, "00") & ":59:59' and a.Doc_Id not in  " & _
                        "(select distinct Doc_Id from dm_ledger b where b.Status_Cd=10 and exists  " & _
                        "(select Doc_Id from dm_document where Status_Cd not in (11,16,19,20) and b.Doc_Id=dm_document.Doc_Id) and  " & _
                        "b.TranDate between '" & vTranDate & "  " & Format(i + 1, "00") & ":00:00' and '" & _
                            vTranDate & "  23:59:59') and User_Id=CreatedBy) as Act_" & i & ", "

                cm.CommandText += "(select count(distinct Doc_Id) from dm_ledger a where a.Status_Cd=18 and exists  " & _
                    "(select Doc_Id from dm_document where Status_Cd not in (11,16,19,20) and a.Doc_Id=dm_document.Doc_Id) and  " & _
                        "TranDate between '" & vTranDate & "  " & Format(IIf(i = 8, 0, i), "00") & ":00:00' and '" & _
                            vTranDate & "  " & Format(i, "00") & ":59:59' and a.Doc_Id not in  " & _
                        "(select distinct Doc_Id from dm_ledger b where b.Status_Cd=18 and exists  " & _
                        "(select Doc_Id from dm_document where Status_Cd not in (11,16,19,20) and b.Doc_Id=dm_document.Doc_Id) and  " & _
                        "b.TranDate between '" & vTranDate & "  " & Format(i + 1, "00") & ":00:00' and '" & _
                            vTranDate & "  23:59:59') and User_Id=CreatedBy) as Gr_" & i & ", "

                cm.CommandText += "(select count(distinct Doc_Id) from dm_ledger a where a.Status_Cd=10 and exists  " & _
                    "(select Doc_Id from dm_document where Status_Cd not in (11,16,19,20) and LineItem between 1 and 3 and a.Doc_Id=dm_document.Doc_Id) and  " & _
                        "TranDate between '" & vTranDate & "  " & Format(IIf(i = 8, 0, i), "00") & ":00:00' and '" & _
                            vTranDate & "  " & Format(i, "00") & ":59:59' and a.Doc_Id not in  " & _
                        "(select distinct Doc_Id from dm_ledger b where b.Status_Cd=10 and exists  " & _
                        "(select Doc_Id from dm_document where Status_Cd not in (11,16,19,20) and LineItem between 1 and 3 " & _
                            "and b.Doc_Id=dm_document.Doc_Id) and  " & _
                        "b.TranDate between '" & vTranDate & "  " & Format(i + 1, "00") & ":00:00' and '" & _
                            vTranDate & "  23:59:59') and User_Id=CreatedBy) as LNum_1_3" & i & ", "

                cm.CommandText += "(select count(distinct Doc_Id) from dm_ledger a where a.Status_Cd=10 and exists  " & _
                    "(select Doc_Id from dm_document where Status_Cd not in (11,16,19,20) and LineItem between 4 and 6 and a.Doc_Id=dm_document.Doc_Id) and  " & _
                        "TranDate between '" & vTranDate & "  " & Format(IIf(i = 8, 0, i), "00") & ":00:00' and '" & _
                            vTranDate & "  " & Format(i, "00") & ":59:59' and a.Doc_Id not in  " & _
                        "(select distinct Doc_Id from dm_ledger b where b.Status_Cd=10 and exists  " & _
                        "(select Doc_Id from dm_document where Status_Cd not in (11,16,19,20) and LineItem between 4 and 6 " & _
                            "and b.Doc_Id=dm_document.Doc_Id) and  " & _
                        "b.TranDate between '" & vTranDate & "  " & Format(i + 1, "00") & ":00:00' and '" & _
                            vTranDate & "  23:59:59') and User_Id=CreatedBy) as LNum_4_6_" & i & ", "

                cm.CommandText += "(select count(distinct Doc_Id) from dm_ledger a where a.Status_Cd=10 and exists  " & _
                    "(select Doc_Id from dm_document where Status_Cd not in (11,16,19,20) and LineItem between 7 and 9 and a.Doc_Id=dm_document.Doc_Id) and  " & _
                        "TranDate between '" & vTranDate & "  " & Format(IIf(i = 8, 0, i), "00") & ":00:00' and '" & _
                            vTranDate & "  " & Format(i, "00") & ":59:59' and a.Doc_Id not in  " & _
                        "(select distinct Doc_Id from dm_ledger b where b.Status_Cd=10 and exists  " & _
                        "(select Doc_Id from dm_document where Status_Cd not in (11,16,19,20) and LineItem between 4 and 6 " & _
                            "and b.Doc_Id=dm_document.Doc_Id) and  " & _
                        "b.TranDate between '" & vTranDate & "  " & Format(i + 1, "00") & ":00:00' and '" & _
                            vTranDate & "  23:59:59') and User_Id=CreatedBy) as LNum_7_9_" & i & ", "

                cm.CommandText += "(select count(distinct Doc_Id) from dm_ledger a where a.Status_Cd=10 and exists  " & _
                    "(select Doc_Id from dm_document where Status_Cd not in (11,16,19,20) and LineItem >=10 and a.Doc_Id=dm_document.Doc_Id) and  " & _
                        "TranDate between '" & vTranDate & "  " & Format(IIf(i = 8, 0, i), "00") & ":00:00' and '" & _
                            vTranDate & "  " & Format(i, "00") & ":59:59' and a.Doc_Id not in  " & _
                        "(select distinct Doc_Id from dm_ledger b where b.Status_Cd=10 and exists  " & _
                        "(select Doc_Id from dm_document where Status_Cd not in (11,16,19,20) and LineItem >=10 " & _
                            "and b.Doc_Id=dm_document.Doc_Id) and  " & _
                        "b.TranDate between '" & vTranDate & "  " & Format(i + 1, "00") & ":00:00' and '" & _
                            vTranDate & "  23:59:59') and User_Id=CreatedBy) as LNum_10_" & i & ", "
            Next
            cm.CommandText += " FullName from user_list where User_Id='" & Request.Form("id") & "'"

            rs = cm.ExecuteReader
            If rs.Read Then

                vReturn = rs("FullName") & "~" & _
                    rs("User_Id") & "~" & _
                    rs("User_Id") & "~"

                For i As Integer = 8 To 21

                    vDiff = rs("Act_" & i) - 7
                    vTotalAct += rs("Act_" & i)
                    vTotalRG += rs("Gr_" & i)

                    vReturn += rs("Act_" & i) & "~" & _
                    rs("Gr_" & i) & "~" & _
                    rs("LNum_1_3" & i) & "~" & _
                    rs("LNum_4_6_" & i) & "~" & _
                    rs("LNum_7_9_" & i) & "~" & _
                    rs("LNum_10_" & i) & "~" & _
                    vDiff & "~"
                Next

                vReturn += vTotalAct & "~" & _
                    vTotalRG

                vAct += vAct + vTotalAct
                vGR += vGR + vTotalRG
            
            End If
            rs.Close()

        Catch ex As SqlClient.SqlException
            vReturn = "error"
        Finally
            c.Close()
            c.Dispose()
            cm.Dispose()
        End Try
    End Sub
    
End Class
