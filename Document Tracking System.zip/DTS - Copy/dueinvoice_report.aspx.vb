﻿Imports denaro.fis
Partial Class dueinvoice_report
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Public vDumpTitle As String = ""
    Public vDumpHeader As String = ""
    Public vDump As String = ""

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load

        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            vScript = "window.close();"
        End If

        'If Not CanRun(Session("caption"), Request.Item("id")) Then
        '    Session("denied") = 1
        '    vScript = "window.close();"
        'End If

        vDumpTitle += "<br><table id='tblQuery' style='width:100%; border-collapse:collapse;' border='0'>" & _
           "<tr><td class='labelC' style='font-size:12px; font-family:Verdana;'><b>" & Session("vTitle") & "</b><td></tr></table><br><br>"

        If Request.Item("vModule") = "ReturnNon" Then
            BuildRetunNon()
        Else
            BuildData()
        End If


    End Sub

    Private Sub BuildData()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim vCtr As Integer = 1
        Dim vReceivedDate As String = ""
        Dim vDueDate As String = ""
        c.Open()
        cm.Connection = c
        cm.CommandText = Session("vSQL")

        vDumpHeader += "<tr>" & _
                "<td class='labelC' style='width:40px;'><b>#</b></td>" & _
                "<td class='labelC' style='width:60px;'><b>Doc ID</b></td>" & _
                "<td class='labelC'><b>Vendor Name</b></td>" & _
                "<td class='labelC' style='width:80px;'><b>Pay<br>Terms</b></td>" & _
                "<td class='labelC' style='width:80px;'><b>Category</b></td>" & _
                "<td class='labelC' style='width:150px;'><b>Status</b></td>" & _
                "<td class='labelC' style='width:150px;'><b>Doc Type</b></td>" & _
                "<td class='labelC' style='width:80px;'><b>Location</b></td>" & _
                "<td class='labelC' style='width:80px;'><b>Amount</b></td>" & _
                "<td class='labelC' style='width:80px;'><b>Date Rec</b></td>" & _
                "<td class='labelC' style='width:80px;'><b>Due Date</b></td>" & _
                "<td class='labelC' style='width:60px;'><b>Elapsed<br>(Day)</b></td>" & _
            "</tr>"

        rs = cm.ExecuteReader
        Do While rs.Read
            vDump += "<tr>" & _
                "<td class='labelC'>" & vCtr & "</td>" & _
                "<td class='labelC' style='padding:5px;'><b>&nbsp;" & rs("Doc_Id") & "</td>" & _
                "<td class='labelL'>" & rs("VendorDescr") & "</td>" & _
                "<td class='labelC'>" & rs("PayTerms") & "</td>" & _
                "<td class='labelL'>" & rs("CatName") & "</td>" & _
                "<td class='labelL'>" & rs("StatusName") & "</td>" & _
                "<td class='labelL'>" & rs("DocTypeName") & "</td>" & _
                "<td class='labelL'>" & rs("LocName") & "</td>" & _
                "<td class='labelR'>" & Format(Val(rs("Amount")), "#,###,##0.00") & "</td>"

            If Not IsDBNull(rs("Date_Uploaded")) Then
                vReceivedDate = Format(rs("Date_Uploaded"), "MM/dd/yyyy")
           End If

            If Not IsDBNull(rs("DueDate")) Then
                vDueDate = Format(CDate(rs("DueDate")), "MM/dd/yyyy")
            End If

            ' vDueDate = rs("DueDate")
            vDump += "<td class='labelC'>" & vReceivedDate & "</td>" & _
                    "<td class='labelC'>" & vDueDate & "</td>" & _
                    "<td class='labelC'>" & GetElapsedDay(vDueDate) & "</td>" & _
                "</tr>"
            vCtr += 1
        Loop
        rs.Close()

        cm.Dispose()
        c.Dispose()
        c.Close()

    End Sub

    Private Sub BuildRetunNon()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cmref As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim rsref As SqlClient.SqlDataReader
        Dim vCtr As Integer = 1
        Dim vReceivedDate As String = ""
        Dim vDueDate As String = ""
        Dim vElaps As Single = 0
        Dim vDateReturn As String = ""
        Dim vDateEmail As String = ""
        Dim vDateRec As String = ""
        Dim vRecReason As String = ""

        c.Open()
        cm.Connection = c
        cmref.Connection = c
        cm.CommandText = Session("vSQL")

        vDumpHeader += "<tr>" & _
                "<td class='labelC' style='width:40px;'><b>#</b></td>" & _
                "<td class='labelC' style='width:50px;'><b>Doc ID</b></td>" & _
                 "<td class='labelC' style='width:80px;'><b>Date Rec.</b></td>" & _
                "<td class='labelC'><b>Vendor Name</b></td>" & _
                "<td class='labelC' style='width:100px;'><b>Doc. Ref. #</b></td>" & _
                "<td class='labelC' style='width:100px;'><b>Amount</b></td>" & _
                "<td class='labelC' style='width:100px;'><b>Date Returned</b></td>" & _
                "<td class='labelC' style='width:80px;'><b>Date E-mailed</b></td>" & _
                "<td class='labelC' style='width:80px;'><b>Addressee</b></td>" & _
                "<td class='labelC' style='width:80px;'><b>Location</b></td>" & _
                "<td class='labelC' style='width:130px;'><b>Status</b></td>" & _
                "<td class='labelC' style='width:80px;'><b>Return Reason</b></td>" & _
                "<td class='labelC' style='width:80px;'><b>Elapsed (Day)</b></td>" & _
            "</tr>"

        rs = cm.ExecuteReader
        Do While rs.Read
            If Not IsDBNull(rs("Date_Uploaded")) Then
                'If rs("Date_Uploaded") <> "" Then
                vDateRec = Format(CDate(rs("Date_Uploaded")), "MM/dd/yyyy")
                'End If
            End If

            If Not IsDBNull(rs("vDateRet")) Then
                If rs("vDateRet") <> "" Then
                    vDateReturn = Format(CDate(rs("vDateRet")), "MM/dd/yyyy")
                End If
            End If

            If Not IsDBNull(rs("vDateEmail")) Then
                If rs("vDateEmail") <> "" Then
                    vDateEmail = Format(CDate(rs("vDateEmail")), "MM/dd/yyyy")
                End If
            End If


            vDump += "<tr>" & _
                "<td class='labelC'>" & vCtr & "</td>" & _
                "<td class='labelC' style='padding:5px;'><b>&nbsp;" & rs("Doc_Id") & "</td>" & _
                "<td class='labelC'>" & vDateRec & "</td>" & _
                "<td class='labelL'>" & rs("VendorDescr") & "</td>" & _
                "<td class='labelL'>" & IIf(IsDBNull(rs("vRef")), "", rs("vRef")) & "</td>" & _
                "<td class='labelR'>" & Format(Val(rs("VAmount")), "#,###,##0.00") & "</td>" & _
                "<td class='labelC'>" & vDateReturn & "</td>" & _
                "<td class='labelC'>" & vDateEmail & "</td>" & _
                "<td class='labelL'>" & IIf(IsDBNull(rs("vOtherInfo")), "", rs("vOtherInfo")) & "</td>"

            If Not IsDBNull(rs("vDateRet")) Then
                If rs("vDateRet") <> "" Then
                    vElaps = Math.Round(DateDiff(DateInterval.Day, CDate(rs("vDateRet")), Now), 2)
                End If
            End If

            If Not IsDBNull(rs("vReturnReason")) Then
                If rs("vReturnReason") <> "" Then
                    cmref.CommandText = "select Descr from dm_keywords where Keyword_Id=" & rs("vReturnReason")
                    rsref = cmref.ExecuteReader
                    If rsref.Read Then
                        vRecReason = rsref("Descr")
                    End If
                    rsref.Close()
                End If
            End If

            vDump += "<td class='labelL'>" & rs("LocName") & "</td>" & _
                "<td class='labelL'>" & rs("StatusName") & "</td>" & _
                "<td class='labelL'>" & vRecReason & " </td>" & _
                "<td class='labelC'>" & vElaps & "</td></tr>"

            vDateRec = ""
            vDateEmail = ""
            vDateReturn = ""
            vRecReason = ""

            vElaps = 0
            vCtr += 1
        Loop
        rs.Close()

        cm.Dispose()
        c.Dispose()
        c.Close()

    End Sub

    Public Function GetElapsedDay(ByVal pDueDate As String) As Single
        Dim vElapsedDay As Single = 0
        Dim vColor As String = "black"

        If Not IsDBNull(pDueDate) Then
            If pDueDate = "" Then
                Return 0
                'vElapsedDay = Math.Round(DateDiff(DateInterval.Day, CDate(pDueDate), Now), 2)
            Else
                vElapsedDay = Math.Round(DateDiff(DateInterval.Day, CDate(pDueDate), Now), 2)

                If vElapsedDay >= 1 Then
                    Return vElapsedDay ' "<label style='color:red;'>" & vElapsedDay & "</label>"
                Else
                    Return vElapsedDay
                End If

            End If
        Else
            Return 0
        End If

    End Function


End Class
