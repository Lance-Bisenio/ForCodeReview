﻿Imports denaro.fis
Partial Class addcategoryloc
    Inherits System.Web.UI.Page
    Public vscript As String = ""

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Session("uid") = Nothing Then
            vscript = "alert('Your login session has expired. Please re-login again.'); window.close(); "
            Exit Sub
        End If

        If Not IsPostBack Then
            BuildCombo("select AgencyCd,AgencyName from agency where exists (select User_Id from rights_list where User_Id='" & _
                           Session("uid") & "' and property='agency' and Property_Value=AgencyCd) order by AgencyName", cmbComp)

            BuildCombo("select Category_Id, Descr from dm_category where exists (select User_Id from rights_list where User_Id='" & _
                    Session("uid") & "' and property='category' and Property_Value=Category_Id) order by Descr", cmbCatg)

            cmbCatg.Items.Add(" ")
            cmbCatg.SelectedValue = " "

            DataRefresh()
        End If

    End Sub

    Private Sub DataRefresh()
        Dim c As New sqlclient.sqlConnection(connStr)
        Dim da As sqlclient.sqlDataAdapter
        Dim ds As New DataSet

        da = New SqlClient.SqlDataAdapter("select DocPath, (select Descr from dm_category where dm_category.Category_Id=dm_category_location.Category_Id) as CatgName," & _
            "(select Descr from dm_category where dm_category.Category_Id=dm_category_location.ParentCatg_Id) as ParentCatgName," & _
            "(select agencyName from agency where dm_category_location.AgencyCd=agency.AgencyCd) as CompName " & _
            "from dm_category_location where  Category_Id='" & Request.Item("vCatg") & "'", c)

        'Response.Write("select (select Descr from dm_category where dm_category.Category_Id=dm_category_location.Category_Id) as CatgName," & _
        '    "(select agencyName from agency where dm_category_location.AgencyCd=agency.AgencyCd) as CompName " & _
        '    "from dm_category_location where AgencyCd='" & cmbComp.SelectedValue & "' and Category_Id='" & Request.Item("vCatg") & "'")

        da.Fill(ds, "DocPath")
        tblFolderLoc.DataSource = ds.Tables("DocPath")
        tblFolderLoc.DataBind()
        da.Dispose()
        ds.Dispose()
        c.Dispose()
    End Sub

    Protected Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        vscript = "self.close();"
    End Sub

    Protected Sub btnCreate_Click(sender As Object, e As EventArgs) Handles btnCreate.Click

        Dim c As New SqlClient.SqlConnection
        Dim cm As New SqlClient.SqlCommand

        Dim SubFilder As String = ""
        Dim vFolderPath As String = ""

        If cmbCatg.SelectedValue.Trim = "" Then
            SubFilder = "\" & CleanVar(Request.Item("vCatgName")).Replace(" ", "_")
        Else
            SubFilder = "\" & CleanVar(cmbCatg.SelectedItem.Text).Replace(" ", "_") & "\" & CleanVar(Request.Item("vCatgName")).Replace(" ", "_")
        End If

        vFolderPath = Server.MapPath(".") & "\..\Uploaded\" & cmbComp.SelectedValue & SubFilder & ""
        IO.Directory.CreateDirectory(vFolderPath)
        'Response.Write(vFolderPath)

        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c

        EventLog(Session("uid"), Request.ServerVariables("REMOTE_ADDR"), "ADD", "", "", "Category Location " & Session("vline") & _
                 "-" & "\..\Uploaded\" & cmbComp.SelectedValue & SubFilder, "Category Location")

        cm.CommandText = "insert into dm_category_location (AgencyCd, ParentCatg_Id, Category_Id, DocPath) values ('" & _
                cmbComp.SelectedValue & "','" & cmbCatg.SelectedValue & "','" & Request.Item("vCatg") & "','" & "\..\Uploaded\" & cmbComp.SelectedValue & SubFilder & "')"
        Try
            'Response.Write(cm.CommandText)
            cm.ExecuteNonQuery()

        Catch ex As DataException
            vscript = "alert('An error occurred while trying to Save the new record.');"
        End Try
        
        cm.Dispose()
        c.Close()
        c.Dispose()

        vscript = "alert('Record successfully saved.'); window.opener.document.form1.submit(); window.close();"


        'If Session("vline") = "" Then

        '    'create a directory
        '    Dim vFileYear As String = Server.MapPath(".") & "\..\Uploaded\" & CleanVar(txtCatName.Text).Replace(" ", "_") & "\" & Format(Now, "yyyy")
        '    IO.Directory.CreateDirectory(vFileYear)

        '    'Create a directory in the year created
        '    Dim vLoopMonth As Integer
        '    Dim vLoopDay As Integer
        '    Dim vLoopHOur As Integer
        '    Dim vmonthfolder As String = Server.MapPath(".") & "\..\Uploaded\" & CleanVar(txtCatName.Text).Replace(" ", "_") & "\" & Format(Now, "yyyy")
        '    Dim vdayfolder As String = Server.MapPath(".") & "\..\Uploaded\"
        '    For vLoopMonth = 1 To 12
        '        IO.Directory.CreateDirectory(vmonthfolder & "\" & vLoopMonth)
        '        For vLoopDay = 1 To 31
        '            IO.Directory.CreateDirectory(vmonthfolder & "\" & vLoopMonth & "\" & vLoopDay)
        '            For vLoopHOur = 0 To 23
        '                IO.Directory.CreateDirectory(vmonthfolder & "\" & vLoopMonth & "\" & vLoopDay & "\" & vLoopHOur)
        '            Next vLoopHOur
        '        Next vLoopDay
        '    Next vLoopMonth
        'End If
        'Session("vline") = ""



    End Sub
End Class
