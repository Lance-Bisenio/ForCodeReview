﻿Imports System.Security.Principal
Imports denaro.fis
Partial Class testfile
    Inherits System.Web.UI.Page

    Dim vSQL As String = ""

    Public vData As String = ""
    Protected Sub cmdinsert_Click(sender As Object, e As EventArgs) Handles cmdinsert.Click
        testinsert_v4()
    End Sub

    Private Sub testinsert_v4()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cm_sub As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader

        Dim cmRef As New SqlClient.SqlCommand
        Dim rsRef As SqlClient.SqlDataReader
        Dim vName() As String
        Dim vCtr As Integer = 1

        c.Open()
        cm.Connection = c
        cmRef.Connection = c
        cm_sub.Connection = c
        Dim SAPAcct As String = ""

        'cm.CommandText = "select distinct(Supplier_SAP) from tblTemp2 where Supplier_SAP is not null or Supplier_SAP<>''"
        cm.CommandText = "Select distinct(Account) From tblNAISAP Where Account Is Not null"

        rs = cm.ExecuteReader
        Do While rs.Read
            vData += "<tr>"
            'SAPAcct += "'" & rs("Supplier_SAP") & "',"
            GetDetails(rs("Account"))
            vData += "</tr>"
        Loop
        rs.Close()

        'SAPAcct = SAPAcct.Substring(0, SAPAcct.Length - 1)

        c.Close()
            c.Dispose()
            cm.Dispose()
            cm.Dispose()
    End Sub
    Private Sub GetDetails(Acct As String)

        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cm_sub As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader

        Dim cmRef As New SqlClient.SqlCommand
        Dim rsRef As SqlClient.SqlDataReader
        Dim vName() As String

        Dim vSAPTran As String = ""
        Dim vDTSTran As String = ""
        Dim vVendorName As String = ""
        Dim vCnt As String = ""

        c.Open()
        cm.Connection = c
        cmRef.Connection = c
        cm_sub.Connection = c


        vSQL = "select Vendor_Name from tblNAISAP where Account='" & Acct & "' "
        vVendorName = GetRef(vSQL, 0)
        vData += "<td>" & Acct & "</td>"
        vData += "<td>" & vVendorName & "</td>"



        'SAP records
        vSQL = "select count(Account) as ttlInvNo " _
            & "from tblNAISAP where Account='" & Acct & "' "

        vSAPTran = GetRef(vSQL, 0)
        vData += "<td>" & vSAPTran & "</td>"



        'DTS records
        vSQL = "select count(Doc_Id) as ttlInvNo " _
            & "from tblTemp2 where Supplier_SAP='" & Acct & "' "

        vDTSTran = GetRef(vSQL, 0)
        vData += "<td>" & vDTSTran & "</td>"


        'SAP Data Match or found in DTS records
        vSQL = "select count(Doc_Id) as ttlInvNo " _
            & "from tblTemp2 where Supplier_SAP='" & Acct & "' and " _
            & "CONVERT(NVARCHAR(MAX), InvNo) in (select InvNo from tblNAISAP where Account='" & Acct & "')"

        vCnt = GetRef(vSQL, 0)
        vData += "<td>" & vCnt & "</td>"


        c.Close()
        c.Dispose()
        cm.Dispose()
        cm.Dispose()
    End Sub

    Private Sub testinsert()

        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cm_sub As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader

        Dim cmRef As New SqlClient.SqlCommand
        Dim rsRef As SqlClient.SqlDataReader


        c.Open()
        cm.Connection = c
        cmRef.Connection = c
        cm_sub.Connection = c
        '20,31,37,38
        cm.CommandText = "select * from dm_document where Doc_id in (18578, 18579, 18580,185734,18578,18579,18580," & _
"18581,18582,18583,18584,18585,18586,18587,18588,18589,18590," & _
"18591,18592,18593,18594,18595,18597," & _
"18604,18605,18606,18607,18608,18609,18615,18617,18618,18619,18620," & _
"18622,18623,18626,18638," & _
"18632,18633,18634,18635,18636,18637,18638,18639,18640," & _
"18641,18642,18643,18644,18645,1864,18647,18648,18649,18650," & _
"18651,18652,18653,18654,18656,18657,18658,18659,18660," & _
"18661,18662,18663,18664,18666,18667,18668,18669,18670) "
        rs = cm.ExecuteReader
        Do While rs.Read

            Response.Write("insert into dm_document_dtl (Doc_Id, Keyword_Id, Value, Alert_Before_Hrs, EmailAlert, EmailFrequency, EmailFrequencyCount ) " & _
                            "values ('" & rs("Doc_Id") & "', 20, '', 0,0,0,0)<br>")
            Response.Write("insert into dm_document_dtl (Doc_Id, Keyword_Id, Value, Alert_Before_Hrs, EmailAlert, EmailFrequency, EmailFrequencyCount ) " & _
                           "values ('" & rs("Doc_Id") & "', 31, '', 0,0,0,0)<br>")
            Response.Write("insert into dm_document_dtl (Doc_Id, Keyword_Id, Value, Alert_Before_Hrs, EmailAlert, EmailFrequency, EmailFrequencyCount ) " & _
                            "values ('" & rs("Doc_Id") & "', 37, '', 0,0,0,0)<br>")
            Response.Write("insert into dm_document_dtl (Doc_Id, Keyword_Id, Value, Alert_Before_Hrs, EmailAlert, EmailFrequency, EmailFrequencyCount ) " & _
                           "values ('" & rs("Doc_Id") & "', 38, '', 0,0,0,0)<br><br>")
        Loop

        c.Close()
        c.Dispose()
        cm.Dispose()
        cm.Dispose()
    End Sub

    Private Sub testfile_v2()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim da As New SqlClient.SqlDataAdapter
        Dim ds As New DataSet
        Dim iRows As Integer
        Dim vEndDate As String
        Dim vElapsed As Decimal

        vData = ""

        c.Open()
        da = New SqlClient.SqlDataAdapter("select * from dm_ledger where createdby='aanzano' order by createdby,doc_id,category_cd,supplier_cd,tranno", c)
        da.Fill(ds, "ledger")

        iRows = ds.Tables("ledger").Rows.Count - 1


        For iCtr As Integer = 0 To iRows
            With ds.Tables("ledger")
                vElapsed = 0
                If iCtr < iRows Then
                    vEndDate = .Rows(iCtr + 1).Item("TranDate").ToString
                    vElapsed = DateDiff(DateInterval.Minute, CDate(.Rows(iCtr).Item("TranDate").ToString), CDate(vEndDate)) / 60
                Else
                    vEndDate = "end"
                End If

                vData += "<tr><td>" & .Rows(iCtr).Item("TranNo").ToString & "</td>" & _
                    "<td>" & .Rows(iCtr).Item("Doc_Id") & "</td>" & _
                    "<td>" & .Rows(iCtr).Item("Status_Cd") & "</td>" & _
                    "<td>" & .Rows(iCtr).Item("Category_Cd") & "</td>" & _
                    "<td>" & .Rows(iCtr).Item("Supplier_Cd") & "</td>" & _
                    "<td>" & .Rows(iCtr).Item("TranDate") & "</td>" & _
                    "<td>" & vEndDate & "</td>" & _
                    "<td>" & vElapsed & "</td>" & _
                    "<td>" & .Rows(iCtr).Item("CreatedBy") & "</td></tr>"
            End With
        Next

        c.Close()
        c.Dispose()
        da.Dispose()
        ds.Dispose()
    End Sub

    Public Function GetElapsedDay(ByVal pDateEncoded As String, ByVal pDateAssigned As String) As Single
        Dim vElapsedDay As Single

        'If pDateAssigned = "" Then
        '    vElapsedDay = Math.Round(DateDiff(DateInterval.Day, CDate(pDateEncoded), CDate(pDateAssigned)), 2)
        'Else
        vElapsedDay = Math.Round(DateDiff(DateInterval.Day, CDate(pDateEncoded), CDate(pDateAssigned)), 2)
        'End If
        Return vElapsedDay
    End Function
End Class
