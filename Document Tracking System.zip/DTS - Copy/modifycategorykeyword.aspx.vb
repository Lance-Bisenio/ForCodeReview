﻿Imports denaro.fis
Partial Class modifycategorykeyword
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            vScript = "alert('Your login session has expired. Please re-login again.'); window.close();"
            Exit Sub
        End If

        'If Session("kid") = "" Or Session("kid") = Nothing Or Request.Item("vId") = "" Or Request.Item("vId") = Nothing Then
        '    vScript = "alert('You must first select a Category Keyword to edit or add.');"
        '    Exit Sub
        'End If

        'If Session("kid") = "" Or Session("kid") = Nothing Or Session("vline") = "" Or Session("vline") = Nothing Then
        '    vScript = "alert('You must first select a Category Keyword to edit or add.');"
        '    Exit Sub
        'End If

        If Not IsPostBack Then

            'txtCatgId.Text = Session("vline")
            txtCatgId.Text = Request.Item("vId")
            'Response.Write(Request.Item("vId"))

            BuildCombo("select Keyword_Id,Descr from dm_keywords where not exists (select Keyword_Id from " & _
                "dm_category_property where Category_Id=" & txtCatgId.Text & " and dm_category_property.Keyword_Id=" & _
                "dm_keywords.Keyword_Id) order by Descr", cmbKeyword)

            Dim c As New SqlClient.SqlConnection(connStr)
            Dim cm As New SqlClient.SqlCommand("select Descr from dm_category where Category_Id=" & txtCatgId.Text, c)
            Dim rs As SqlClient.SqlDataReader

            Try
                c.Open()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                c.Dispose()
                cm.Dispose()
                Exit Sub
            End Try

            Try
                rs = cm.ExecuteReader
                If rs.Read Then
                    txtCatDescr.Text = rs("Descr")
                End If
                rs.Close()

                If Request.Item("m") = "e" Then
                    cmbKeyword.Items.Add(New ListItem(Session("kdescr"), Session("kid")))
                    cmbKeyword.SelectedValue = Session("kid")
                    cm.CommandText = "select * from dm_category_property where Category_Id=" & txtCatgId.Text & _
                        " and Keyword_Id=" & Session("kid")
                    rs = cm.ExecuteReader
                    If rs.Read Then
                        txtSeq.Text = rs("SeqId")
                        rdoType.SelectedValue = rs("Type")
                    End If
                End If
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to read Categories. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            Finally
                c.Close()
                cm.Dispose()
                c.Dispose()
            End Try
        End If
    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error has occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try
        Try
            cm.Connection = c
            If Request.Item("m") = "e" Then 'edit mode
                cm.CommandText = "update dm_category_property set Keyword_Id=" & cmbKeyword.SelectedValue & _
                    ",SeqId=" & Val(txtSeq.Text) & ",Type=" & rdoType.SelectedValue & _
                    " where Category_Id=" & txtCatgId.Text & _
                    " and Keyword_Id=" & Session("kid")
            Else
                cm.CommandText = "insert into dm_category_property (Category_Id,Keyword_Id,SeqId,Type) values (" & _
                    txtCatgId.Text & "," & cmbKeyword.SelectedValue & "," & Val(txtSeq.Text) & "," & _
                    rdoType.SelectedValue & ")"
            End If
            cm.ExecuteNonQuery()
            vScript = "alert('Changes were successfully saved.');window.opener.document.form1.submit(); window.close();"
        Catch ex As Exception
            vScript = "alert('Error occurred while trying to save record. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            c.Dispose()
            cm.Dispose()
        End Try
    End Sub
End Class
