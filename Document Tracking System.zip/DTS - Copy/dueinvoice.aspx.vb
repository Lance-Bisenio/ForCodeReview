﻿Imports denaro.fis
Partial Class dueinvoice
    Inherits System.Web.UI.Page
    Public vHeader_A As String = ""
    Public vTitle As String = ""
    Public vData As String = ""
    Public vscript As String

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
        End If

        If Not CanRun(Session("caption"), Request.Item("id")) Then
            Session("denied") = 1
            Server.Transfer("main.aspx")
        End If

        If Not IsPostBack Then
            GetAllStatus()

            BuildCombo("select AgencyCd,AgencyName from agency where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='agency' and Property_Value=AgencyCd) order by AgencyName", cmbAgency)

            BuildCombo("select Category_Id,Descr from dm_category where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='Category' and Property_Value=Category_Id) order by Descr", cmbCatg)

            BuildCombo("select Status_Cd, Descr from dm_document_status where Status_Cd in (" & Mid(txtStatusList.Text, 1, Len(txtStatusList.Text) - 1) & ") ", cmbStatus)

            BuildCombo("select SupplierCd, SupplierName from supplier order by SupplierName", cmbVendor)

            BuildCombo("select type_cd, Descr from dm_contract_type order by Descr", cmbDocType)
            BuildCombo("select Location_Id,Descr from dm_document_location order by Location_Id", cmbLocation)

            cmbAgency.Items.Add("All")
            cmbAgency.SelectedValue = "All"
            cmbCatg.Items.Add("All")
            cmbCatg.SelectedValue = "All"
            cmbStatus.Items.Add("All")
            cmbStatus.SelectedValue = "All"
            cmbVendor.Items.Add("All")
            cmbVendor.SelectedValue = "All"
            cmbDocType.Items.Add("All")
            cmbDocType.SelectedValue = "All"
            cmbLocation.Items.Add("All")
            cmbLocation.SelectedValue = "All"

            cmbMonth.SelectedIndex = Month(Now) - 1

            cmbYrFr.Items.Clear()
            cmbYrTo.Items.Clear()
            For iCtr = 2013 To Year(Now) + 2
                cmbYrFr.Items.Add(iCtr)
                cmbYrTo.Items.Add(iCtr)
            Next iCtr

            cmbDayFr.Items.Clear()
            cmbDayTo.Items.Clear()
            For iCtr = 1 To 31
                cmbDayFr.Items.Add(iCtr)
                cmbDayTo.Items.Add(iCtr)
            Next iCtr

            cmbYrFr.SelectedIndex = Year(Now)
            cmbMonth.SelectedIndex = Month(Now) - 1
            cmbDayFr.SelectedIndex = 0

            cmbYrTo.SelectedIndex = Year(Now)
            cmbMonthTo.SelectedIndex = Month(Now) - 1
            cmbDayTo.SelectedIndex = 14

            cmbShow.Items.Clear()
            For iCtr = 1 To 6
                cmbShow.Items.Add(15 * iCtr)
            Next iCtr
        End If

        Session.Remove("vSQL")
        Session.Remove("Hearders")
    End Sub

    Protected Sub cmbMonth_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbMonth.SelectedIndexChanged
        cmbMonthTo.SelectedIndex = cmbMonth.SelectedValue - 1
    End Sub

    Private Sub GetAllStatus()
 
        Dim cm As New SqlClient.SqlCommand
        Dim dr As SqlClient.SqlDataReader
        Dim vList As String = ""
        Dim vAdminList As String = ""
        Dim vStatusList As String = ""


        Dim c As New SqlClient.SqlConnection(connStr)
        c.Open()
        cm.Connection = c

        cm.CommandText = "select StatusCd from empendcounter where ModuleName='Due Invoice Report'"
        txtStatusList.Text = ""

        dr = cm.ExecuteReader
        If dr.Read Then
            vStatusList += dr("StatusCd") & ","
            txtStatusList.Text += dr("StatusCd") & ","
        End If
        dr.Close()

        cm.CommandText = "select Status_Cd, Descr from dm_document_status where Status_Cd in (" & Mid(vStatusList, 1, Len(vStatusList) - 1) & ") " '"
        ' Response.Write(cm.CommandText)
        dr = cm.ExecuteReader
        If dr.Read Then
            vList = IIf(IsDBNull(dr("Status_Cd")), "", dr("Status_Cd"))
        End If
        dr.Close()
        vList = Mid(vStatusList, 1, Len(vStatusList) - 1)
        SetList("select Status_Cd, Descr from dm_document_status order by Descr", vList, "chkStatusList")
        c.Close()
    End Sub

    Private Sub SetList(ByVal pSQL As String, ByVal pChkField As String, ByVal vType As String)
        Dim cm As New SqlClient.SqlCommand
        Dim dr As SqlClient.SqlDataReader
        Dim iCtr As Integer
        Dim vList() As String
        Dim iLoop As Integer

        Dim c As New SqlClient.SqlConnection(connStr)
        c.Open()
        cm.Connection = c
        cm.CommandText = pSQL
        dr = cm.ExecuteReader

        'If vType = "chkStatusList" Then
        chkStatusList.Items.Clear()
        vList = pChkField.Split(",")
        Do While dr.Read
            chkStatusList.Items.Add(dr(0) & "=>" & dr(1))
            For iLoop = 0 To UBound(vList)
                If vList(iLoop) = dr(0) Then
                    chkStatusList.Items(iCtr).Selected = True
                    Exit For
                End If
            Next
            iCtr += 1
        Loop
        ''End If
        dr.Close()
        cm.Dispose()
    End Sub

    Private Sub BuildData()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cmRef As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim da As New SqlClient.SqlDataAdapter
        Dim ds As New DataSet

        Dim vElapsed As Single = 0
        Dim vNewStatus As Integer = 99
        Dim vFilter As String = ""
        'Dim vFromDate As Date
        'Dim vToDate As Date
        Dim vAcountable As String = ""

        Dim vStatus() As String = {"", "", ""}  'index 0=status 5, index 1=status 6,index 2=status 7

        c.Open()
        cm.Connection = c
        cmRef.Connection = c

        vFilter = ""

        If cmbAgency.SelectedValue <> "All" Then
            vFilter += " and AgencyCd =" & cmbAgency.SelectedValue
        End If

        If cmbStatus.SelectedValue <> "All" Then
            vFilter += " and Status_Cd =" & cmbStatus.SelectedValue
        Else
            vFilter += " and Status_Cd in (" & Mid(txtStatusList.Text, 1, Len(txtStatusList.Text) - 1) & ") "
        End If

        If cmbCatg.SelectedValue <> "All" Then
            vFilter += " and Category_Id =" & cmbCatg.SelectedValue
        End If

        If cmbVendor.SelectedValue <> "All" Then
            vFilter += " and Supplier_Cd ='" & cmbVendor.SelectedValue & "' "
        End If

        If cmbDocType.SelectedValue <> "All" Then
            vFilter += " and Contract_Id ='" & cmbDocType.SelectedValue & "' "
        End If

        If cmbLocation.SelectedValue <> "All" Then
            vFilter += " and Location_Id ='" & cmbLocation.SelectedValue & "' "
        End If

        Dim vDueDate As String = " and DueDate between '" & _
            CDate(cmbMonth.SelectedValue & "/" & cmbDayFr.SelectedValue & "/" & cmbYrFr.SelectedValue) & " 00:00' and '" & _
            CDate(cmbMonthTo.SelectedValue & "/" & cmbDayTo.SelectedValue & "/" & cmbYrTo.SelectedValue) & " 23:59'"

        Session("vTitle") = "Business Process Outsourcing International, Inc.<br><br>Due Invoice Report <br>FROM " & _
             Format(CDate(cmbMonth.SelectedValue & "/" & cmbDayFr.SelectedValue & "/" & cmbYrFr.SelectedValue), "MM/dd/yyyy") & " TO " & _
             Format(CDate(cmbMonthTo.SelectedValue & "/" & cmbDayTo.SelectedValue & "/" & cmbYrTo.SelectedValue), "MM/dd/yyyy") & ""

        Try
            Session("vSQL") = "select DueDate, OrigFileName, Doc_Id, Doc_Name, Date_Assigned, Date_Encoded, Date_Uploaded, " & _
            "(select Terms from supplier where supplier.SupplierCd=dm_document.Supplier_Cd) as PayTerms, " & _
            "(select SupplierName from supplier where supplier.SupplierCd=dm_document.Supplier_Cd) as VendorDescr, " & _
            "(select Descr from dm_category where dm_category.Category_Id=dm_document.Category_Id) as CatName, " & _
            "(select Descr from dm_document_location where dm_document_location.Location_Id=dm_document.Location_Id) as LocName, " & _
            "(select Descr from dm_contract_type where dm_contract_type.Type_Cd=dm_document.Contract_Id) as DocTypeName, " & _
            "(select Descr from dm_document_status where dm_document_status.Status_Cd=dm_document.Status_Cd) as StatusName, " & _
            "(select FullName from user_list where user_list.User_Id=dm_document.Emp_Cd ) as FullName, " & _
            "(select Value from dm_document_dtl where dm_document.Doc_Id=dm_document_dtl.Doc_Id and dm_document_dtl.Keyword_Id='37') as Amount " & _
            "from dm_document where Doc_Id is not null " & vFilter & vDueDate & " order by VendorDescr "



            da = New SqlClient.SqlDataAdapter(Session("vSQL"), c)

            'Response.Write(da.SelectCommand.CommandText)

            da.Fill(ds, "document")
            tlbDocInfo.DataSource = ds.Tables("document")
            tlbDocInfo.DataBind()
            lblTotalDocs.Text = "<b>Total Documents Retrieved : " & tlbDocInfo.DataSource.Rows.Count & "</b>"


        Catch ex As SqlClient.SqlException
            'Response.Write(da.SelectCommand.CommandText)
        End Try

        da.Dispose()
        ds.Dispose()
        cm.Dispose()
        cmRef.Dispose()

        c.Close()
        c.Dispose()

    End Sub

    Public Function CheckDueDate(ByVal pDueDate As String) As String

        Return pDueDate

        'If pDueDate = "" Then
        '    Return "&nbsp;"
        'Else
        'End If

        'Dim vDueDate As Date
        'Dim vDaysAlert As Integer = 2 'days 
        'Dim iCtr As Integer = 0
        'Dim vColor As String = "black"

        '' tlbDocInfo.Columns(12).ItemStyle.ForeColor = Color.Black
        'If pDueDate = "" Then
        '    Return "&nbsp;"
        'Else
        '    If IsDate(pDueDate) Then
        '        vDueDate = CDate(pDueDate)
        '        If Now > vDueDate Then
        '            Dim vTmpDueDate As Date = vDueDate
        '            Do While iCtr <= vDaysAlert
        '                vTmpDueDate = vTmpDueDate.AddDays(1)
        '                If vTmpDueDate.DayOfWeek <> DayOfWeek.Sunday And vTmpDueDate.DayOfWeek <> DayOfWeek.Saturday Then
        '                    iCtr += 1
        '                End If
        '            Loop
        '            If iCtr > vDaysAlert Then
        '                'tlbDocInfo.Columns(12).ItemStyle.ForeColor = Color.Red
        '                vColor = "red"
        '            End If
        '        End If

        '        Return "<label style='color:" & vColor & ";'>" & Format(vDueDate, "MM/dd/yyyy") & "</label>"
        '    Else
        '        Return "&nbsp;"
        '    End If
        'End If
    End Function

    Public Function GetElapsedDay(ByVal pDueDate As String) As Single
        Dim vElapsedDay As Single = 0
        Dim vColor As String = "black"

        If pDueDate = "" Then
            Return "&nbsp;"
            'vElapsedDay = Math.Round(DateDiff(DateInterval.Day, CDate(pDueDate), Now), 2)
        Else
            vElapsedDay = Math.Round(DateDiff(DateInterval.Day, CDate(pDueDate), Now), 2)

            If vElapsedDay >= 1 Then
                Return vElapsedDay ' "<label style='color:red;'>" & vElapsedDay & "</label>"
            Else
                Return vElapsedDay
            End If

        End If
    End Function

    Protected Sub cmdSearch_Click(sender As Object, e As EventArgs) Handles cmdSearch.Click
        BuildData()
    End Sub

    Protected Sub cmbShow_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbShow.SelectedIndexChanged
        tlbDocInfo.PageSize = cmbShow.SelectedValue
        BuildData()
    End Sub

    Protected Sub cmdClose_Click(sender As Object, e As EventArgs) Handles cmdClose.Click
        Session.Remove("vSQL")
        Session.Remove("Hearders")
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub tlbDocInfo_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles tlbDocInfo.PageIndexChanging
        tlbDocInfo.PageIndex = e.NewPageIndex
        BuildData()
    End Sub

    Protected Sub tlbDocInfo_SelectedIndexChanged(sender As Object, e As EventArgs) Handles tlbDocInfo.SelectedIndexChanged
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand("select Doc_Id,Status_Cd from dm_document where Doc_Id=" & tlbDocInfo.SelectedRow.Cells(1).Text, c)
        Dim rs As SqlClient.SqlDataReader

        c.Open()
        rs = cm.ExecuteReader
        If rs.Read Then 
            vscript = "openlink(" & rs("Doc_Id") & ");"
        End If

        rs.Close()
        c.Close()
        c.Dispose()
        cm.Dispose()
    End Sub

    Protected Sub cmdSave_Click(sender As Object, e As EventArgs) Handles cmdSave.Click
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim vStatuslist As String = ""
        Dim vDataSet As String

        cm.Connection = c
        c.Open()

        For iCtr = 0 To chkStatusList.Items.Count - 1
            If chkStatusList.Items(iCtr).Selected Then
                vDataSet = ExtractData(chkStatusList.Items(iCtr).Text)
                vStatuslist += vDataSet & ","
            End If
        Next

        If vStatuslist = "" Then
            vscript = "alert('Please select status');"
            GetAllStatus()
            BuildCombo("select Status_Cd, Descr from dm_document_status where Status_Cd in (" & Mid(txtStatusList.Text, 1, Len(txtStatusList.Text) - 1) & ") ", cmbStatus)
            cmbStatus.Items.Add("All")
            cmbStatus.SelectedValue = "All"
            Exit Sub
        End If

        vStatuslist = Mid(vStatuslist, 1, Len(vStatuslist) - 1)
        cm.CommandText = "update empendcounter set StatusCd='" & vStatuslist & "' where ModuleName='Due Invoice Report' "
       
        Try
            cm.ExecuteNonQuery()
            vscript = "alert('Status settings successfully save');"

        Catch ex As DataException
            vscript = "alert('An error occurred while trying to Save the new record.');"
        End Try

        c.Close()
        c.Dispose()
        cm.Dispose()

        GetAllStatus()
        BuildCombo("select Status_Cd, Descr from dm_document_status where Status_Cd in (" & Mid(txtStatusList.Text, 1, Len(txtStatusList.Text) - 1) & ") ", cmbStatus)
        cmbStatus.Items.Add("All")
        cmbStatus.SelectedValue = "All"
    End Sub

    'Protected Sub cmdSelectAll_Click(sender As Object, e As EventArgs) Handles cmdSelectAll.Click
    '    trans.Visible = True
    '    divCon.Visible = True

    '    For iCtr = 0 To chkStatusList.Items.Count - 1
    '        chkStatusList.Items(iCtr).Selected = True
    '    Next
    'End Sub

    'Protected Sub cmdDeSelectAll_Click(sender As Object, e As EventArgs) Handles cmdDeSelectAll.Click
    '    trans.EnableTheming = True
    '    divCon.EnableViewState = True

    '    For iCtr = 0 To chkStatusList.Items.Count - 1
    '        chkStatusList.Items(iCtr).Selected = False
    '    Next
    'End Sub
End Class
