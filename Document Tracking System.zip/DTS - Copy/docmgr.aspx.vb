Imports denaro.fis
Partial Class docmgr
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Public vData As String = ""
    Public OtherFilter As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Dim MachineIP = Request.ServerVariables("REMOTE_ADDR")
            Dim IsActive As Integer = 0
            Dim vSQL As String = ""

            vSQL = "select top 1 User_Id from audit where MachineId='" & MachineIP & "' and " _
                & "TranDate between '" & Format(Now, "yyyy-MM-dd") & " 00:00' and '" & Format(Now, "yyyy-MM-dd") & " 23:59' " _
                & "order by trandate desc"

            Session("uid") = GetRef(vSQL, "")

            vSQL = "select * from user_list where User_Id='" & Session("uid") & "'"

            Dim c As New SqlClient.SqlConnection(connStr)
            Dim cm As New SqlClient.SqlCommand(vSQL, c)
            Dim rs As SqlClient.SqlDataReader

            c.Open()
            rs = cm.ExecuteReader
            If rs.Read Then
                IsActive = 1
                Session("caption") = IIf(IsDBNull(rs("Caption")), "", rs("Caption"))
                Session("userlevel") = IIf(IsDBNull(rs("UserLevel")), 0, rs("UserLevel"))
                Session("agencylist") = IIf(IsDBNull(rs("AgencyCd")), "", rs("AgencyCd"))

                Session("Catglist") = IIf(IsDBNull(rs("CategoryCd")), "", rs("CategoryCd"))
                Session("Statuslist") = IIf(IsDBNull(rs("StatusCd")), "", rs("StatusCd"))
                Session("deptlist") = IIf(IsDBNull(rs("DeptCd")), "", rs("DeptCd"))

                Session("rclist") = IIf(IsDBNull(rs("Rc_Cd")), "", rs("Rc_Cd"))

                Session("sectionlist") = IIf(IsDBNull(rs("SectionCd")), "", rs("SectionCd"))
                Session("divlist") = IIf(IsDBNull(rs("DivCd")), "", rs("DivCd"))
                Session("unitlist") = IIf(IsDBNull(rs("UnitCd")), "", rs("UnitCd"))
                Session("typelist") = IIf(IsDBNull(rs("EmploymentType")), "", rs("EmploymentType"))

                Session("EmpPos") = IIf(IsDBNull(rs("Position")), "", "Position : " & rs("Position"))
                Session("EmpEmail") = IIf(IsDBNull(rs("Email")), "", "Email : " & rs("Email"))
                Session("EmpFullName") = IIf(IsDBNull(rs("FullName")), "", rs("FullName"))

                Session("sessionid") = Session.SessionID

            End If
            rs.Close()
            c.Close()
            c.Dispose()
            cm.Dispose()

            If IsActive = 0 Then
                'vScript = "alert('Your login session has expired. Please re-login again.'); window.close();"
                Server.Transfer("index.aspx")
                Exit Sub
            End If
        End If
        'If Session("uid") = "" Then
        '    Server.Transfer("index.aspx")
        '    Exit Sub
        'End If

        If Not CanRun(Session("caption"), Request.Item("id")) Then
            Session("denied") = 1
            Server.Transfer("main.aspx")
        End If

        If Not IsPostBack Then
            ' ''cmbMo.Items.Clear()
            ''cmbMo.Items.Add("All")
            ' ''For iCtr = 1 To 12
            ' ''    cmbMo.Items.Add(Format(iCtr, "##"))
            ' ''Next iCtr
            ''cmbMo.SelectedValue = Month(Now())

            ''cmbYr.Items.Clear()
            ''For iCtr = 2013 To Year(Now) + 2
            ''    cmbYr.Items.Add(iCtr)
            ''Next iCtr
            ''cmbMo.SelectedValue = Format(Now(), "yyyy")

            txtRecDateFrom.Text = Now
            txtRecDateFrom.Text = Format(CDate(txtRecDateFrom.Text).AddDays(-(CDate(txtRecDateFrom.Text).Day - 1)), "MM/dd/yyyy")
            txtRecDateTo.Text = Format(Now, "MM/dd/yyyy")

            cmbShow.Items.Clear()
            For iCtr = 1 To 6
                cmbShow.Items.Add(15 * iCtr)
            Next iCtr

            BuildCombo("select distinct(Encoded_By), " _
                & "(select FullName from user_list where user_list.USER_ID=dm_document.Encoded_By ) as vFullName " _
                & "from dm_document where Encoded_By <> '' and Date_Uploaded between '" & txtRecDateFrom.Text.Trim & " 00:00:00" _
                & "' and '" & txtRecDateTo.Text.Trim & " 23:59:00" & "' ", cmbEncoded)

            BuildCombo("select AgencyCd,AgencyName from agency where exists (select User_Id from rights_list where User_Id='" _
               & Session("uid") & "' and property='agency' and Property_Value=AgencyCd) order by AgencyName", cmbAgency)
            BuildCombo("select Category_Id,Descr from dm_Category where exists (select User_Id from rights_list where User_Id='" _
                       & Session("uid") & "' and property='Category' and Property_Value=Category_Id) order by Descr", cmbCatg)
            BuildCombo("select Type_Cd,Descr from dm_contract_type  order by Descr", cmbDocType)
            BuildCombo("select SupplierCd, SupplierName from supplier order by SupplierName", cmbVendor)
            BuildCombo("select Location_Id,Descr from dm_document_location  order by Descr", cmbLoc)

            BuildCombo("select Emp_Cd,Emp_Cd+' => '+Emp_Lname+', '+Emp_Fname from py_emp_master  order by Emp_Lname", cmbEmp)
            cmbEmp.Items.Add("All")
            cmbEmp.Items.Add("Disable this filter")
            cmbEmp.SelectedValue = "All"

            BuildCombo("select Status_Cd,Descr from dm_document_status where (IsEnable=1 or exists " _
                       & "(select User_Id from rights_list where User_Id='userid' and property='Status' and Property_Value=Status_Cd) ) " _
                       & "order by Descr", cmbStatus)

            BuildCombo("select distinct(Emp_Cd), (select Fullname from user_list where user_id=Emp_Cd ) as fullname " _
                       & "from dm_document where Emp_Cd is not null and Emp_Cd != '' and AgencyCd='" & cmbAgency.SelectedValue & "' order by fullname ", cmbAcc)

            cmbEncoded.Items.Add("All")
            cmbCatg.Items.Add("All")
            cmbDocType.Items.Add("All")
            cmbVendor.Items.Add("All")
            cmbVendor.Items.Add("Disable this filter")
            cmbLoc.Items.Add("All")
            cmbStatus.Items.Add("All")
            cmbAcc.Items.Add("All")

            cmbEncoded.SelectedValue = "All"
            cmbCatg.SelectedValue = "All"
            cmbDocType.SelectedValue = "All"
            cmbVendor.SelectedValue = "All"
            cmbLoc.SelectedValue = "All"
            cmbStatus.SelectedValue = "All"
            cmbAcc.SelectedValue = "All"

            cmdEdit.Enabled = CanRun(Session("caption"), 11)
            cmdDelete.Enabled = CanRun(Session("caption"), 12)
            cmdPreview.Enabled = CanRun(Session("caption"), 13)
            cmdEdit.Enabled = False
            cmdDelete.Enabled = False
            cmdPreview.Enabled = False
            'BuildKeywords()

        End If

        BuildKeywords()
        'cmdNew.Enabled = CanRun(Session("caption"), 10)
        'cmdBatch.Enabled = CanRun(Session("caption"), 65)
        'cmdProperties.Enabled = CanRun(Session("caption"), 14)
        'btnViewNotes.Enabled = CanRun(Session("caption"), 15)
        'cmdVoidDoc.Enabled = False

    End Sub

    Public Function GetElapsedTime(ByVal pDateEncoded As String, ByVal pDateAssigned As String) As Single
        Dim vElapsed As Single

        If pDateAssigned = "" Then
            vElapsed = Math.Round(DateDiff(DateInterval.Minute, CDate(pDateEncoded), Now) / 60, 2)
        Else
            vElapsed = Math.Round(DateDiff(DateInterval.Minute, CDate(pDateAssigned), Now) / 60, 2)
        End If
        Return vElapsed
    End Function

    Private Sub DataRefresh()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim da As SqlClient.SqlDataAdapter
        Dim ds As New DataSet
        Dim vStatus As String = ""
        Dim vSearch As String = ""
        Dim vElapsed As Single = 0
        Dim vSQL As String = ""

        If txtDueDate.Text.Trim <> "" Then
            If Not IsDate(txtDueDate.Text.Trim) Then
                vScript = "alert('Invalid value in Due Date');"
                c.Close()
                c.Dispose()
                Exit Sub
            End If
            vSearch += " and DueDate between '" & txtDueDate.Text.Trim & " 00:00:00" & "' and '" & txtDueDate.Text.Trim & " 23:59:00" & "'"
        End If

        If cmbAgency.SelectedValue <> "All" Then
            vSearch += " AgencyCd ='" & cmbAgency.SelectedValue & "' "
        End If

        If txtSearch.Text.Trim <> "" Then
            vSearch += " and Doc_Name like '%" & txtSearch.Text & "%' "
        End If

        If txtDocID.Text.Trim <> "" Then
            vSearch += " and Doc_Id='" & txtDocID.Text & "' "
        End If

        If cmbCatg.SelectedValue <> "All" Then
            vSearch += " and Category_Id =" & cmbCatg.SelectedValue
        End If

        If cmbStatus.SelectedValue <> "All" Then
            vSearch += " and Status_Cd =" & cmbStatus.SelectedValue
        End If

        If cmbDocType.SelectedValue <> "All" Then
            vSearch += " and Contract_Id ='" & cmbDocType.SelectedValue & "' "
        End If

        If cmbAcc.SelectedValue <> "All" Then
            vSearch += " and Emp_Cd ='" & cmbAcc.SelectedValue & "' "
        End If

        If cmbLoc.SelectedValue <> "All" Then
            vSearch += " and Location_Id ='" & cmbLoc.SelectedValue & "' "
        End If

        If cmbVendor.SelectedValue <> "All" And cmbVendor.SelectedValue <> "Disable this filter" Then
            vSearch += " and Supplier_Cd ='" & cmbVendor.SelectedValue & "' "
        End If

        If cmbVendor.SelectedValue = "Disable this filter" Then
            vSearch += " and CreditTo is not null "
        End If

        'If cmbMo.SelectedValue <> "All" Then
        '    vSearch += " and Month(Date_Uploaded)='" & cmbMo.SelectedValue & "'"
        'End If

        If txtSAP.Text.Trim <> "" Then
            vSearch += " and SAP_Number like '%" & txtSAP.Text.Trim & "%' "
        End If

        If txtVCNo.Text.Trim <> "" Then
            vSearch += " and VendorClearingNo like '%" & txtVCNo.Text.Trim & "%'"
        End If

        If txtBCNo.Text.Trim <> "" Then
            vSearch += " and BatchClearingNo like '%" & txtBCNo.Text.Trim & "%'"
        End If

        If cmbEncoded.SelectedValue <> "All" Then
            vSearch += " and Encoded_By='" & cmbEncoded.SelectedValue & "'"
        End If

        If cmbEmp.SelectedValue <> "All" And cmbEmp.SelectedValue <> "Disable this filter" Then
            vSearch += " and CreditTo ='" & cmbEmp.SelectedValue & "' "
        End If

        If cmbEmp.SelectedValue = "Disable this filter" Then
            vSearch += " and CreditTo is null "
        End If

        ''If txtRecDateFrom.Text.Trim = "" Or txtRecDateTo.Text.Trim = "" Then
        ''    txtRecDateFrom.Text = Now
        ''    txtRecDateFrom.Text = Format(CDate(txtRecDateFrom.Text).AddDays(-(CDate(txtRecDateFrom.Text).Day - 1)), "MM/dd/yyyy")
        ''    txtRecDateTo.Text = Format(Now, "MM/dd/yyyy")
        ''Else
        ''vSearch += " and Date_Uploaded between '" & txtRecDateFrom.Text.Trim & " 00:00:00" & "' and '" & txtRecDateTo.Text.Trim & " 23:59:00" & "'"
        ''End If

        If txtRecDateFrom.Text.Trim <> "" Or txtRecDateTo.Text.Trim <> "" Then
            vSearch += " and Date_Uploaded between '" & txtRecDateFrom.Text.Trim & " 00:00:00" & "' and '" & txtRecDateTo.Text.Trim & " 23:59:00" & "'"
        End If

        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim vFilterKeywors As String = ""

        Try
            c.Open()
            cm.Connection = c
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        'Response.Write(Request.Form("txt20") & " : test ")

        cm.CommandText = "select distinct Keyword_Id, SeqId," _
            & "(select Descr from dm_keywords where dm_keywords.Keyword_Id=dm_category_property.Keyword_Id) as Descr, " _
            & "(select Data_Type from dm_keywords where dm_keywords.Keyword_Id=dm_category_property.Keyword_Id) as Data_Type " _
            & "from dm_category_property order by SeqId"
        'Response.Write(cm.CommandText)
        Try
            rs = cm.ExecuteReader

            OtherFilter += "<tr>"
            Do While rs.Read
                'Response.Write(Request.Form("txt" & rs("Keyword_Id")) & " *<br>")
                If Request.Form(rs("Keyword_Id").ToString) <> "" And Request.Form(rs("Keyword_Id").ToString) <> "All" Then
                    vFilterKeywors += " and exists " _
                        & "(select distinct Doc_Id from dm_document_dtl where Keyword_Id=" & rs("Keyword_Id") _
                    & " and value like '%" & Request.Form(rs("Keyword_Id").ToString) & "%' and " _
                    & "dm_document.Doc_Id = dm_document_dtl.Doc_Id)"
                End If

            Loop
            rs.Close()
            ' Response.Write(vFilterKeywors)
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to retrieve keywords. Error is: " & ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Close()
            cm.Dispose()
            c.Dispose()
            Exit Sub
        End Try

        vSQL = "select Doc_Id, Doc_Name, Created_By, Encoded_By, Uploaded_By, Date_Encoded, Date_Assigned, Emp_Cd,Date_Uploaded,DueDate,SAP_Number, VendorClearingNo, BatchClearingNo, Uploaded_Path, " _
            & "(select FullName from user_list where user_list.User_Id=dm_document.Emp_Cd) as EmpName, " _
            & "(select SupplierName from supplier where supplier.supplierCd=dm_document.Supplier_Cd) as VendorDescr, " _
            & "(select Descr from dm_contract_type where dm_contract_type.Type_Cd=dm_document.Contract_Id) as ContactType, " _
            & "(select Descr from dm_document_Status where dm_document_status.Status_Cd=dm_document.Status_Cd) as Status, " _
            & "(select top 1 (select  Fullname from User_list where User_Id=CreatedBy) " _
            & "as TeamName from dm_ledger where dm_ledger.Doc_Id=dm_document.Doc_Id and IsAssignTo is not null order by dm_ledger.TranNo desc) as Teamleader, " _
            & "(select top 1 (select Fullname from User_list where User_Id=IsAssignTo) " _
            & "as ProcName from dm_ledger where dm_ledger.Doc_Id=dm_document.Doc_Id and IsAssignTo is not null order by dm_ledger.TranNo desc) as Processor, " _
            & "(select Value from dm_document_dtl where dm_document.Doc_Id=dm_document_dtl.Doc_Id and dm_document_dtl.Keyword_Id='38') as vRef, " _
            & "(select Emp_Lname+', '+Emp_Fname from py_emp_master where Emp_Cd=CreditTo) as vEmp " _
            & "from dm_document where  " & vSearch & vFilterKeywors
        'Response.Write(vSQL)

        Session("vFilters") = vSearch & vFilterKeywors

        da = New SqlClient.SqlDataAdapter(vSQL, c)
        da.Fill(ds, "DocInfo")
        tlbDocInfo.DataSource = ds.Tables("DocInfo")
        tlbDocInfo.DataBind()
        lblTotalDocs.Text = "<b>Total Documents Retrieved : " & tlbDocInfo.DataSource.Rows.Count & "</b>"

        da.Dispose()
        ds.Dispose()
        c.Dispose()
        tlbDocInfo.SelectedIndex = -1

    End Sub

    Protected Sub tlbDocInfo_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles tlbDocInfo.PageIndexChanging
        tlbDocInfo.PageIndex = e.NewPageIndex
        DataRefresh()
    End Sub

    Protected Sub tlbDocInfo_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tlbDocInfo.SelectedIndexChanged
        Session("docid") = tlbDocInfo.SelectedRow.Cells(1).Text
        cmdEdit.Enabled = CanRun(Session("caption"), 11)
        cmdPreview.Enabled = CanRun(Session("caption"), 13)
        'cmdBatch.Enabled = CanRun(Session("caption"), 65)
        'cmdVoidDoc.Enabled = CanRun(Session("caption"), 12)

    End Sub

    Protected Sub cmdClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdClose.Click
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub cmdPreview_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdPreview.Click

        Dim vFile As String = ""
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader

        c.Open()
        cm.Connection = c
        cm.CommandText = "select Uploaded_Path from dm_document where Doc_Id=" & tlbDocInfo.SelectedRow.Cells(1).Text
        rs = cm.ExecuteReader
        If rs.Read Then
            If Not IsDBNull(rs("Uploaded_Path")) Then
                vFile = rs("Uploaded_Path")
            End If
        End If

        rs.Close()
        If vFile <> "" Then
            'vScript = "winpreview=window.open('http://" & System.Configuration.ConfigurationManager.AppSettings.Get("ServerIp") & "/" & vFile.ToLower & _
            '    "',""preview"",""width=800,height=600,top=10,left=10,toolbars=no,resizable=yes""); winpreview.focus();"
            vScript = "activeMode(""" & vFile.ToLower & """);"
        Else
            vScript = "alert('No Attached document to view.');"
        End If

        cm.Dispose()
        c.Close()
        c.Dispose()

    End Sub

    Protected Sub cmdDelete_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDelete.Click

        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader

        Dim cmRef As New SqlClient.SqlCommand

        Dim vDuration As Single = 0
        Dim vDateStart As Date

        c.Open()
        cm.Connection = c
        cmRef.Connection = c

        cm.CommandText = "select Doc_Id, User_Id, Status_Cd from dm_stockcard where Doc_Id='" & tlbDocInfo.SelectedRow.Cells(1).Text & "' and Status_Cd=14"
        rs = cm.ExecuteReader
        If rs.Read Then

            cmRef.CommandText = "insert into dm_stockcard (TranDate, CreatedBy, Doc_Id, Qty, Status_Cd, Remarks, User_Id) " _
                & "values ('" & Format(Now, "yyyy/MM/dd HH:mm:ss") & "', '" & Session("uid") & "', " & rs("Doc_Id") _
                & ", -1, " & rs("Status_Cd") & ", 'Override By : " & Session("uid") & "', '" & rs("User_Id") & "')"
            cmRef.ExecuteNonQuery()

        End If
        rs.Close()

        cm.CommandText = "select * from dm_document where Doc_Id=" & tlbDocInfo.SelectedRow.Cells(1).Text
        rs = cm.ExecuteReader

        If rs.Read Then

            vDateStart = rs("Date_Encoded")
            If Not IsDBNull(rs("Date_Assigned")) Then
                vDateStart = CDate(rs("Date_Assigned"))
            End If

            vDuration = Math.Round(DateDiff(DateInterval.Minute, vDateStart, Now) / 60, 2)
            cmRef.CommandText = "insert into dm_document_notes (Doc_Id,Notes,Date_Encoded,Encoded_By,Emp_Cd," _
                & "Date_Start,Date_Finish,Duration,Status_Cd) values (" & rs("Doc_Id") & ",'" _
                & IIf(IsDBNull(rs("Contents")), "Validated", rs("Contents")) & "','" _
                & Format(CDate(rs("Date_Encoded")), "yyyy/MM/dd HH:mm:ss") & "','" _
                & rs("Encoded_By") & "','" & IIf(IsDBNull(rs("Emp_Cd")), rs("Encoded_By"), rs("Emp_Cd")) _
                & "','" & Format(vDateStart, "yyyy/MM/dd HH:mm:ss") _
                & "','" & Format(Now, "yyyy/MM/dd HH:mm:ss") & "'," & vDuration & "," & rs("Status_Cd") & ")"
            cmRef.ExecuteNonQuery()

            'insert to lance table dm_ledger
            cmRef.CommandText = "insert into dm_ledger (Doc_ID, Status_Cd, Category_Cd, TranDate, CreatedBy, Supplier_Cd, Remarks) " _
                & "values (" & rs("Doc_Id") & ", 16, " & rs("Category_Id") & ", '" _
                & Format(Now, "yyyy/MM/dd HH:mm:ss") & "', '" & Session("uid") & "', " & rs("Supplier_Cd") _
                & ", '" & txtReason.Text & " | This document is being void by : " & Session("uid") & "')"

            cmRef.ExecuteNonQuery()

            cmRef.CommandText = "update dm_document set DateModify='" & Now() & "', ModifyBy='" & Session("uid") _
                & "', Status_Cd ='16', contents='" & txtReason.Text _
                & "' where Doc_Id=" & tlbDocInfo.SelectedRow.Cells(1).Text
            cmRef.ExecuteNonQuery()

            EventLog(Session("uid"), Request.ServerVariables("REMOTE_ADDR"), "UPDATE", "", "", "Document " & tlbDocInfo.SelectedRow.Cells(1).Text _
                     & "-" & tlbDocInfo.SelectedRow.Cells(1).Text, "Document")
        End If

        'DataRefresh(txtSearch.Text)

        rs.Close()
        c.Close()
        cm.Dispose()
        c.Dispose()

    End Sub


    Private Sub BuildSubListbox(ByVal vKey As String)
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader

        Dim cmSub As New SqlClient.SqlCommand
        Dim rsSub As SqlClient.SqlDataReader

        Dim vSubKeyList As String = ""
        Dim vlblName As String = ""
        Dim vSql As String = ""
        Dim vSeleted As String = "selected='selected'"

        c.Open()
        cm.Connection = c
        cmSub.Connection = c

        'txtOtherInfo.Text = ""
        'vDumpSubKey = ""

        cm.CommandText = "select * from dm_category_property where Keyword_id=" & vKey & ""

        Try
            rs = cm.ExecuteReader
            If rs.Read Then
                OtherFilter += "<tr><td class='labelR'>" & rs("LabelText") & " : </td>"
                OtherFilter += "<td><select class='labelL' id='" & vKey & "' name='" & vKey & "' runat='server' style='width:196px;'>"

                cmSub.CommandText = rs("SetResource")
                'Response.Write(rs("SetResource"))
                rsSub = cmSub.ExecuteReader
                OtherFilter += "<option value='All' " & vSeleted & ">All</option>"

                Do While rsSub.Read

                    'If IsNumeric(rsSub("vID")) Then
                    '    'Response.Write(Val(Request.Form(rsSub("vID"))))
                    '    '    If rsSub("vID") = Val(Request.Form(rsSub("vID"))) Then
                    '    '        vSeleted = "selected='selected'"
                    '    '    End If
                    'Else
                    '    Response.Write(Request.Form(rsSub("vID")))
                    '    If rsSub("vID") = Request.Form(rsSub("vID")) Then
                    '        vSeleted = "selected='selected'"
                    '    End If
                    'End If

                    OtherFilter += "<option value='" & rsSub("vID") & "' >" & rsSub("vDescr") & "</option>"
                    vSeleted = ""
                Loop



                rsSub.Close()
                OtherFilter += "</td></tr>"
            End If
            rs.Close()

        Catch ex As DataException
            vScript = "alert('An error occurred while trying to Save the new record.');"

            c.Close()
            c.Dispose()
            cm.Dispose()
        End Try

    End Sub

    Private Sub BuildKeywords()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim vSelected As String = ""
        Dim vCntr As Integer = 0
        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('An error occur while trying to connect to database. Error is: " & ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"

            c.Dispose()
            cm.Dispose()
            c.Close()
            Exit Sub
        End Try


        cm.Connection = c
        cm.CommandText = "select distinct Keyword_Id, SeqId, SetResource, " _
            & "(select Descr from dm_keywords where dm_keywords.Keyword_Id=dm_category_property.Keyword_Id) as Descr, " _
            & "(select Data_Type from dm_keywords where dm_keywords.Keyword_Id=dm_category_property.Keyword_Id) as Data_Type " _
            & "from dm_category_property order by Keyword_Id"

        rs = cm.ExecuteReader
        Session("KeywordList") = ""

        Do While rs.Read
            vCntr += 1
            Session("KeywordList") += "," & rs("Descr")

            Select Case rs("Data_Type")

                Case "STRING", "NUMERIC", "TEXTAREA"

                    OtherFilter += "<tr><td class='labelR'>" & rs("Descr") & " : </td><td><input type='text' class='label' style='width: 192px;' runat='server' " _
                        & "name='" & rs("Keyword_Id").ToString & "' id='" & rs("Keyword_Id").ToString & "' value='" & Request.Form(rs("Keyword_Id").ToString) & "' /></td></tr>"

                Case "LIST"
                    BuildSubListbox(rs("Keyword_Id"))

                Case "DATE"
                    'vDump += "<tr><td class='labelR'>" & rsRef("Descr") & _
                    '    " : </td><td><input class='labelC' type='text' style='width: 70px;' maxlength='10' name='" & _
                    '    Val(rs("Keyword_Id")) & "' id='" & Val(rs("Keyword_Id")) & _
                    '    "' onBlur='return ValidateForm(" & Val(rs("Keyword_Id")) & ")' />&nbsp;&nbsp;&nbsp;mm/dd/yyyy</td></tr>"

                    OtherFilter += "<tr><td class='labelR'>" & rs("Descr") _
                        & " : </td><td><input class='labelL' type='text' style='width: 171px;' maxlength='10' name='" & Val(rs("Keyword_Id")) & "' id='" & Val(rs("Keyword_Id")) _
                        & "' onFocus='showCalendarControl(this);' readonly='readonly' value=''/> " _
                        & "<img src='images/calendar.png' class='ImgCalerdar' style='vertical-align:middle;' onclick='showCalendarControl(txtRecDateFrom);' title='Show Calendar'/></td></tr>"

                    '<tr>
                    '    <td>Date Rec. From :</td>
                    '    <td><asp:TextBox ID="txtRecDateFrom" runat="server" CssClass="labelL" Width="173px"></asp:TextBox>
                    '        <img src="images/calendar.png" class="ImgCalerdar" style="vertical-align:middle;" onclick="showCalendarControl(txtRecDateFrom);" title="Show Calendar"/>
                    '    </td>
                    '</tr>

                    'For i As Integer = 0 To 11
                    '    If Format(Val(i), "00") = Hour(Now()) Then
                    '        vSelected = "Selected='Selected'"
                    '    End If
                    '    OtherFilter += "<option " & vSelected & " >" & Format(Val(i), "00") & "</option>"
                    'Next

                    'OtherFilter += "</select><select class='labelL' name='" & _
                    '    Val(rs("Keyword_Id")) & "_mm' id='" & Val(rs("Keyword_Id")) & "_mm'>"

                    'For i As Integer = 0 To 59
                    '    OtherFilter += "<option>" & Format(Val(i), "00") & "</option>"
                    'Next

                    'OtherFilter += "</select><select class='labelL' name='" & _
                    '    Val(rs("Keyword_Id")) & "_am' id='" & Val(rs("Keyword_Id")) & "_am'>" & _
                    '        "<option>AM</option><option>PM</option>" & _
                    '        "</select></td></tr>"

                    'Case "TIME"
                    '    OtherFilter += "<tr><td class='labelR'>" & rs("Descr") & _
                    '        ":</td><td><input class='label' type='text' style='width: 150px;' maxlength='7' name='" & _
                    '        Val(rs("Keyword_Id")) & "' id='" & Val(rs("Keyword_Id")) & "' />&nbsp;&nbsp;&nbsp;hh:mm </td></tr>"
                    'Case "TEXTAREA"
                    '    OtherFilter += "<tr><td class='labelR' valign='top'>" & rs("Descr") & _
                    '        ":</td><td><textarea class='labelL' style='width: 222px;' rows='2' name='" & _
                    '            Val(rs("Keyword_Id")) & "' id='" & Val(rs("Keyword_Id")) & "' ></textarea></td></tr>"

                    'Case "YES/NO"
                    '    OtherFilter += "<tr><td class='labelR'>" & rs("Descr") & " : </td><td><input type='checkbox' name='" & _
                    '        Val(rs("Keyword_Id")) & "' id='" & Val(rs("Keyword_Id")) & "' /></td></tr>"
            End Select

            'OtherFilter += "<tr><td class='labelR'>" & rs("Descr") & " :</td>" & _
            '    "<td class='labelL'>" & _
            '        "<input type='text' runat='server' id='txt" & rs("Keyword_Id") & "' name='txt" & _
            '            rs("Keyword_Id") & "' class='labelL' style='width:192px' value='" & Request.Form("txt" & rs("Keyword_Id")) & "' />" & _
            '    "</td></tr>"
        Loop

        rs.Close()
        cm.Dispose()
        c.Close()
        c.Dispose()
    End Sub

    Protected Sub cmdEdit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdEdit.Click
        If Session("docid") > 0 Then
            vScript = "modifyDoc();"
        Else
            vScript = "alert('You must select a record before you can use the edit command');"
        End If
    End Sub

    Protected Sub cmdSearch_Click(sender As Object, e As EventArgs) Handles cmdSearch.Click
        DataRefresh()
        'BuildKeywords()
    End Sub

    Protected Sub cmbShow_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbShow.SelectedIndexChanged
        tlbDocInfo.PageSize = cmbShow.SelectedValue
        DataRefresh()
        'BuildKeywords()
    End Sub

    Protected Sub cmdView_Click(sender As Object, e As EventArgs) Handles cmdView.Click
        vScript = "OpenDetails(" & tlbDocInfo.SelectedRow.Cells(1).Text & ");"
    End Sub

    Protected Sub cmvDump_Click(sender As Object, e As EventArgs) Handles cmvDump.Click
        Dim vFile As String = ""
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim cmref As New SqlClient.SqlCommand
        Dim rsref As SqlClient.SqlDataReader

        Dim vFilename = Server.MapPath(".") & "/downloads/" & Session.SessionID & "-QueriesReport.csv"
        Dim vDump As New StringBuilder
        Dim vBuildData As String = ""

        c.Open()
        cm.Connection = c
        cmref.Connection = c

        cm.CommandTimeout = 800
        cmref.CommandTimeout = 800

        If IO.File.Exists(vFilename) Then
            Try
                IO.File.Delete(vFilename)
            Catch ex As IO.IOException
                vScript = "alert('Error deleting dump file. Error is: " & ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                Exit Sub
            End Try
        End If

        vDump.AppendLine("Doc Id, Orig File Name, Doc Name, Encoded By, Date Encoded," _
                         & "Date Receive, Remarks, Uploaded Path, Last Modify, SAP_Number, Due Date, " _
                         & "Vendor Clearing No, Batch Clearing No, Company Name, Category Name, Location Name, " _
                         & "Doc Type Name,Status Name, Vendor Code, Vendor Name, Pay Terms, Credit To / Employee, Bank No." & Session("KeywordList"))

        'cm.CommandText = "select *, " _
        '    & "(select Terms from supplier where supplier.SupplierCd=dm_document.Supplier_Cd) as PayTerms, " _
        '    & "(select AgencyName from agency where agency.agencyCd=dm_document.agencyCd) as CompName, " _
        '    & "(select ParentDealerCd from supplier where supplier.SupplierCd=dm_document.Supplier_Cd) as VendorCd, " _
        '    & "(select SupplierName from supplier where supplier.SupplierCd=dm_document.Supplier_Cd) as VendorName, " _
        '    & "(select Descr from dm_category where dm_category.Category_Id=dm_document.Category_Id) as CatName, " _
        '    & "(select Descr from dm_document_location where dm_document_location.Location_Id=dm_document.Location_Id) as LocName, " _
        '    & "(select Descr from dm_contract_type where dm_contract_type.Type_Cd=dm_document.Contract_Id) as DocTypeName, " _
        '    & "(select Descr from dm_document_status where dm_document_status.Status_Cd=dm_document.Status_Cd) as StatusName, " _
        '    & "(select FullName from user_list where user_list.User_Id=dm_document.Emp_Cd ) as FullName, " _
        '    & "(select Emp_Lname+' '+Emp_Fname from py_emp_master where Emp_Cd=CreditTo) as vEmp, " _
        '    & "(select Bank_No from emp_banklist where emp_banklist.Emp_Cd=dm_document.CreditTo and emp_banklist.Bank_Id=dm_document.Bank_Id) as vEmpBank " _
        '    & "from dm_document where " & Session("vFilters")

        cm.CommandText = "select Doc_Id,OrigFileName,Doc_Name,Encoded_By,Date_Encoded,Date_Uploaded,Contents,Uploaded_Path, " _
            & "Emp_Cd,SAP_Number,DueDate,VendorClearingNo,BatchClearingNo, Category_Id," _
            & "(select Terms from supplier where supplier.SupplierCd=dm_document.Supplier_Cd) as PayTerms, " _
            & "(select AgencyName from agency where agency.agencyCd=dm_document.agencyCd) as CompName, " _
            & "(select ParentDealerCd from supplier where supplier.SupplierCd=dm_document.Supplier_Cd) as VendorCd, " _
            & "(select SupplierName from supplier where supplier.SupplierCd=dm_document.Supplier_Cd) as VendorName, " _
            & "(select Descr from dm_category where dm_category.Category_Id=dm_document.Category_Id) as CatName, " _
            & "(select Descr from dm_document_location where dm_document_location.Location_Id=dm_document.Location_Id) as LocName, " _
            & "(select Descr from dm_contract_type where dm_contract_type.Type_Cd=dm_document.Contract_Id) as DocTypeName, " _
            & "(select Descr from dm_document_status where dm_document_status.Status_Cd=dm_document.Status_Cd) as StatusName, " _
            & "(select FullName from user_list where user_list.User_Id=dm_document.Emp_Cd ) as FullName, " _
            & "(select Emp_Lname+' '+Emp_Fname from py_emp_master where Emp_Cd=CreditTo) as vEmp, " _
            & "(select Bank_No from emp_banklist where emp_banklist.Emp_Cd=dm_document.CreditTo and emp_banklist.Bank_Id=dm_document.Bank_Id) as vEmpBank " _
            & "from dm_document where " & Session("vFilters")


        'Response.Write(cm.CommandText)
        rs = cm.ExecuteReader
        Do While rs.Read

            vBuildData = rs("Doc_Id") & "," & rs("OrigFileName") & "," & rs("Doc_Name") & "," & rs("Encoded_By") & "," & rs("Date_Encoded") _
                & "," & rs("Date_Uploaded") & ",""" & rs("Contents").ToString.Replace(",", "") & """," & rs("Uploaded_Path").ToString.Replace(",", "") & "," & rs("Emp_Cd") & "," & rs("SAP_Number") & "," & rs("DueDate") _
                & "," & rs("VendorClearingNo") & "," & rs("BatchClearingNo") & "," & rs("CompName") & "," & rs("CatName") & "," & rs("LocName") _
                & "," & rs("DocTypeName") & "," & rs("StatusName") & "," & rs("VendorCd") & "," & rs("VendorName").ToString.Replace(",", "") & "," & rs("PayTerms") _
                & "," & rs("vEmp") & "," & rs("vEmpBank") & ""

            'cmref.CommandText = "select * from dm_document_dtl where Doc_Id='" & rs("Doc_Id") & "' order by Keyword_Id "
            cmref.CommandText = "select Keyword_Id," _
                & "(select Value from dm_document_dtl where dm_document_dtl.Keyword_Id=dm_category_property.Keyword_Id " _
                & "and dm_document_dtl.Doc_Id=" & rs("Doc_Id") & ") as vData " _
                & "from dm_category_property where Category_Id=" & rs("Category_Id") & " order by Keyword_Id"
            'Response.Write(cmref.CommandText)
            rsref = cmref.ExecuteReader

            Do While rsref.Read
                vBuildData += "," & IIf(IsDBNull(rsref("vData")), "", rsref("vData").ToString.Replace(",", ""))
            Loop
            rsref.Close()
            'Response.Write(vBuildData)
            vDump.AppendLine(vBuildData)
        Loop
        IO.File.WriteAllText(vFilename, vDump.ToString)

        vScript = "alert('Download complete.'); window.open('downloads/" & Session.SessionID & "-QueriesReport.csv');"

        rs.Close()
        cm.Dispose()
        cmref.Dispose()

        c.Close()
        c.Dispose()

    End Sub

    Protected Sub cmbStatus_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbStatus.SelectedIndexChanged
        'BuildKeywords()
    End Sub
End Class

