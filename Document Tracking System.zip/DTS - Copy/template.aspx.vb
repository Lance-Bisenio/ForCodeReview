﻿
Partial Class template
    Inherits System.Web.UI.Page

End Class
