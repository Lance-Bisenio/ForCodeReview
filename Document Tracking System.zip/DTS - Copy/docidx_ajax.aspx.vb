﻿Imports denaro.fis
Partial Class docidx_ajax
    Inherits System.Web.UI.Page
    Public VendorList As String = ""
    Dim vSQL As String = ""
    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Dim VendorNameKey As String = Request.Item("VendorNameKey")

        'If PendingItemsList.Trim <> "" Then
        GetVendorList(VendorNameKey)


        'End If

    End Sub
    Private Sub GetVendorList(SysParam As String)

        Dim c As New SqlClient.SqlConnection
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        c.ConnectionString = connStr

        Try
            c.Open()
            cm.Connection = c
        Catch ex As SqlClient.SqlException
            ScriptManager.RegisterStartupScript(Me, Page.GetType, "Script", "alert('Database connection error.');", True)
            Exit Sub
        End Try


        vSQL = "select SupplierCd, SupplierName from supplier " _
            & "where SupplierName Like '" & SysParam & "%' " _
            & "order by SupplierName"

        VendorList = vSQL
        cm.CommandText = vSQL
        rs = cm.ExecuteReader
        Do While rs.Read
            VendorList += "<option value='" & rs("SupplierCd") & "' >" & rs("SupplierName") & "</option>"
        Loop

        rs.Close()


        c.Close()
        c.Dispose()
        cm.Dispose()


        'Response.Write(VendorList)
    End Sub
End Class
