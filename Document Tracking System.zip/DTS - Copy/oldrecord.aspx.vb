﻿Imports denaro.fis
Partial Class oldrecord
    Inherits System.Web.UI.Page
    Public vData As String = ""
    Public vscript As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cmRef As New SqlClient.SqlCommand

        Dim rs As SqlClient.SqlDataReader
        Dim rsRef As SqlClient.SqlDataReader

        Dim i As Integer = 1
        Dim vClass As String = ""
        Dim vTag As String = ""

        vClass = "odd"

        'If Session("uid") = "" Then
        '    vscript = "alert('Your login session has expired. Please re-login again.'); window.close();"
        '    Exit Sub
        'End If

        'If Session("uid") = "" Then
        '    Server.Transfer("index.aspx")
        '    Exit Sub
        'End If

        cm.Connection = c
        cmRef.Connection = c
        c.Open()

        cm.CommandText = "select *, " & _
            "(select Descr from dm_category where dm_category.Category_Id=dm_oldrecord.Category_Id) as Category, " & _
            "(select Descr from dm_document_Status where dm_document_status.Status_Cd=dm_oldrecord.Status_Cd) as Status, " & _
            "(select Descr from dm_contract_type where dm_contract_type.Type_Cd=dm_oldrecord.Contract_Id) as ContactType, " & _
            "(select SupplierName from supplier where supplier.supplierCd=dm_oldrecord.Supplier_Cd) as CompName, " & _
            "(select FullName from user_list where user_list.User_Id=dm_oldrecord.Emp_Cd) as EmpName, " & _
            "(select FullName from user_list where user_list.User_Id=dm_oldrecord.ModifyBy) as EditedBy " & _
            "from dm_oldrecord where doc_id=" & Request.Item("Doc_Id") & " order by TranNo "
        Try

            rs = cm.ExecuteReader
            Do While rs.Read

                If i = 1 Then
                    vTag = "Old"
                Else
                    vTag = "New"
                End If

                vData += "<tr class=" & vClass & "><td class='labelC' style='padding:3px' valign='top'>" & vTag & "</td>" & _
                           "<td class='labelL' style='padding:3px' valign='top'>" & rs("Doc_Id") & "</td>" & _
                           "<td class='labelL' style='padding:3px' valign='top'>" & rs("Doc_Name") & "</td>" & _
                           "<td class='labelL' style='padding:3px' valign='top'>" & rs("ContactType") & "</td>" & _
                           "<td class='labelL' style='padding:3px' valign='top'>" & rs("CompName") & "</td>" & _
                           "<td class='labelL' style='padding:3px' valign='top'>" & rs("Category") & "</td>" & _
                           "<td class='labelL' style='padding:3px' valign='top'>" & rs("Status") & "</td>" & _
                           "<td class='labelL' style='padding:3px' valign='top'>" & rs("EmpName") & "</td>" & _
                           "<td class='labelL' style='padding:3px' valign='top'>" & rs("Sap_Number") & "</td>" & _
                           "<td class='labelL' style='padding:3px' valign='top'>" & rs("LineItem") & "</td>" & _
                           "<td class='labelL' style='padding:3px' valign='top'>" & rs("GRNumber") & "</td>"

                cmRef.CommandText = "select * from dm_oldrecord_dtl where doc_id=" & Request.Item("Doc_Id") & _
                    " and TranNo='" & rs("TranNo") & "' order by TranNo "
                rsRef = cmRef.ExecuteReader
                Do While rsRef.Read
                    If rsRef("Keyword_Id") = "37" Then
                        vData += "<td class='labelR' style='padding:3px' valign='top'>" & rsRef("Value") & "</td>"
                    Else
                        vData += "<td class='labelL' style='padding:3px' valign='top'>" & rsRef("Value") & "</td>"
                    End If

                    '        "<td class='labelL' style='padding:3px'>" & rsRef("Value") & "</td>" & _
                    '        "<td class='labelL' style='padding:3px'>" & rsRef("Value") & "</td>" & _
                    '        "<td class='labelL' style='padding:3px'>" & rsRef("Value") & "</td>" & _
                    '        "<td class='labelL' style='padding:3px'>" & rsRef("Value") & "</td>"
                Loop
                rsRef.Close()

                vData += "<td class='labelL' style='padding:3px' valign='top'>" & rs("EditedBy") & "</td>"
                vData += "<td class='labelL' style='padding:3px' valign='top'>" & rs("DateModify") & "</td>"

                vData += "</tr>"

                If i = 2 Then
                    vClass = IIf(vClass = "odd", "even", "odd")
                    i = 0
                End If
                i += 1
            Loop
            rs.Close()










        Catch ex As SqlClient.SqlException
            vscript = "alert('An error occur while trying to access the database.  Error is: " & _
                      ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            c.Dispose()
            cm.Dispose()
        End Try

        If Not IsPostBack Then

        End If
    End Sub
End Class
