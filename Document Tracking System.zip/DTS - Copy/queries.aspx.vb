﻿Imports denaro.fis
Partial Class queries
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Public vKeywords As String = ""
    Public OtherFilter As String = ""
    Public vData As String = ""
    Public vHeader As String = ""
    Dim vKeyFilters As String = ""
    Dim vFilters As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If

        If Not IsPostBack Then
            combomaker("select AgencyCd,AgencyName from agency order by AgencyCd", cmbAgency) 'Agency
            combomaker("select Category_Id,Descr from dm_category order by Descr", cmbCategory) ' Category
            combomaker("select Status_Cd,Descr from dm_document_status order by Status_Cd", cmbStatus) 'status
            combomaker("select SupplierCd,SupplierName from supplier order by SupplierCd", cmbSupplier) 'supplier
            combomaker("select User_Id,FullName from user_list where Position<>'Administrator' order by User_Id", cmbUsers) 'Profile
            combomaker("select distinct uploaded_by, (select FullName from user_list where" & _
                       " user_list.User_Id=dm_document.Uploaded_By ) as Fullname from dm_document ", cmbEncoders)

            txtDateS.Text = Format(CDate(Now()), "MM/dd/yyyy") & " 00:00:00"
            txtDateE.Text = Format(CDate(Now()), "MM/dd/yyyy hh:mm:ss")

            cmdException.Enabled = False
            cmdException2.Style("visibility") = "hidden"

            'If CanRun(Session("caption"), Request.Item("id")) Then
            '    DataRefresh()
            'Else
            '    Session("denied") = 1
            '    Server.Transfer("main.aspx")
            'End If
        End If

    End Sub

    Private Sub DataRefresh()
        Dim c As New sqlclient.sqlConnection(connStr)
        Dim cm As New sqlclient.sqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim vSelected As String = ""
        Dim vCntr As Integer = 0
        Try
            c.Open()
        Catch ex As sqlclient.sqlException
            vscript = "alert('An error occur while trying to connect to database. Error is: " & _
                       ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"

            c.Dispose()
            cm.Dispose()
            c.Close()
            Exit Sub
        End Try

        cm.Connection = c
        cm.CommandText = "select distinct Keyword_Id, SeqId, " & _
            "(select Descr from dm_keywords where dm_keywords.Keyword_Id=dm_category_property.Keyword_Id) as Descr, " & _
            "(select Data_Type from dm_keywords where dm_keywords.Keyword_Id=dm_category_property.Keyword_Id) as Data_Type " & _
            "from dm_category_property order by SeqId"

        rs = cm.ExecuteReader
        vKeywords = ""

        OtherFilter = "<tr>"
        Do While rs.Read

            vCntr += 1
            OtherFilter += "<td class='labelR'>" & rs("Descr") & " :</td>" & _
                "<td class='labelL'>" & _
                    "<input type='text' runat='server' id='txt" & rs("Keyword_Id") & "' name='txt" & _
                        rs("Keyword_Id") & "' class='labelL' style='width:181px' value='" & Request.Form("txt" & rs("Keyword_Id")) & "' />" & _
                "</td>"

            If vCntr = 3 Then
                OtherFilter += "</tr>"
                vCntr = 0
            End If
        Loop

        rs.Close()
        cm.Dispose()
        c.Close()
        c.Dispose()
    End Sub

    Private Sub combomaker(ByVal psql As String, ByVal pcombo As System.Web.UI.WebControls.DropDownList)
        Dim c As New sqlclient.sqlConnection
        Dim cm As New sqlclient.sqlCommand
        Dim rs As sqlclient.sqlDataReader

        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c
        cm.CommandText = psql
        rs = cm.ExecuteReader
        pcombo.Items.Clear()
        pcombo.Items.Add(New ListItem("All", "All"))
        Do While rs.Read
            pcombo.Items.Add(New ListItem(rs(0) & "=>" & IIf(IsDBNull(rs(1)), "null", rs(1)), rs(0)))
        Loop
        rs.Close()

        c.Close()
        c.Dispose()
        cm.Dispose()
    End Sub

    Protected Sub cmdClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdClose.Click
        Session("docid") = 0
        Server.Transfer("main.aspx")
        Session.Remove("cols")
        Session.Remove("colsdescr")
        Session.Remove("qryresults")
    End Sub
    
    Protected Sub cmdSearchNow_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSearchNow.Click
        txtvMode.Text = "Search"

        If txtDateS.Text.Trim <> "" Then
            If Not IsDate(txtDateS.Text) Then
                vScript = "alert('Invalid date and time format in Date from field')"
                Exit Sub
            End If

            If txtDateE.Text.Trim = "" Then
                vScript = "alert('Invalid date and time format in Date To field')"
                Exit Sub
            End If

        End If

        If txtDateE.Text.Trim <> "" And txtDateS.Text.Trim <> "" Then
            If Not IsDate(txtDateE.Text) Then
                vScript = "alert('Invalid date and time format in Date to field')"
                Exit Sub
            End If

            If CDate(txtDateS.Text) > CDate(txtDateE.Text) Then
                vScript = "alert('From Date should be earlier than To Date')"
                Exit Sub
            End If

            If txtDateS.Text = "" Then
                vScript = "alert('Invalid date and time format in Date From field')"
                Exit Sub
            End If

        ElseIf (txtDateE.Text.Trim <> "" And txtDateS.Text.Trim = "") Or _
                (txtDateE.Text.Trim = "" And txtDateS.Text.Trim <> "") Then
            vScript = "alert('You should put valid date values for both From date and To Date fields.');"
            Exit Sub
        End If

        DataRefresh()

        If cmbStatus.SelectedValue = "3" Then
            cmdException.Enabled = CanRun(Session("caption"), 68)
            cmdException2.Style("visibility") = "visible"
            'For_ExceptionTeam()
            vHeader = "<th class='titleBar' style='border: solid 1px #8b8b8a; color: #ffffff; width: 30px'><b></b></th>"
            'cmdException2.Style("visibility") = "visible"
            'Else
            'cmdException2.Style("visibility") = "hidden"
        End If

        Dim vFilename = Server.MapPath(".") & "/downloads/" & Session.SessionID & "-QueriesReport.csv"
        Dim vDump As New StringBuilder

        If IO.File.Exists(vFilename) Then
            Try
                IO.File.Delete(vFilename)
            Catch ex As IO.IOException
                vScript = "alert('Error deleting dump file. Error is: " & ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                Exit Sub
            End Try
        End If

        vDump.AppendLine("Doc ID,Date Received,Received From,Doc Name,SAP Doc. No.,CompanyCode,Company Name,Vendor Name,Amount,Reference No.,Category,Status,Other Info")
        IO.File.WriteAllText(vFilename, vDump.ToString)
        lnkDownload.NavigateUrl = "downloads/" & Session.SessionID & "-QueriesReport.csv"
        reminders()
    End Sub
   
    Private Sub reminders()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader

        Dim vFilter As String = ""
        Dim vFromDate As Date
        Dim vToDate As Date

        vFilter = ""
        If txtDateS.Text <> "" Then
            vFromDate = IIf(txtDateS.Text.Length > 10, CDate(txtDateS.Text), Format(CDate(txtDateS.Text), "yyyy/MM/dd") & " 00:00:00")
            vToDate = IIf(txtDateE.Text.Length > 10, CDate(txtDateE.Text), Format(CDate(txtDateE.Text), "yyyy/MM/dd") & " 23:59:59")

            vFilter += " Date_Uploaded between '" & vFromDate & "' and '" & vToDate & "' "
        End If

        If cmbAgency.SelectedValue <> "All" Then
            vFilter += " and AgencyCd ='" & cmbAgency.SelectedValue & "'"
        End If

        If cmbCategory.SelectedValue <> "All" Then
            vFilter += " and Category_Id =" & cmbCategory.SelectedValue
        End If

        If cmbStatus.SelectedValue <> "All" Then
            vFilter += " and Status_Cd =" & cmbStatus.SelectedValue
        End If

        If cmbUsers.SelectedValue <> "All" Then
            vFilter += " and Emp_Cd ='" & cmbUsers.SelectedValue & "' "
        End If

        If cmbSupplier.SelectedValue <> "All" Then
            vFilter += " and Supplier_Cd ='" & cmbSupplier.SelectedValue & "' "
        End If

        If cmbUsers.SelectedValue <> "All" Then
            vFilter += " and ModifyBy ='" & cmbUsers.SelectedValue & "' "
        End If

        If cmbEncoders.SelectedValue <> "All" Then
            vFilter += " and Uploaded_By ='" & cmbEncoders.SelectedValue & "' "
        End If

        If txtSAPno.Text.Trim <> "" Then
            vFilter += " and SAP_Number like '%" & txtSAPno.Text.Trim & "%' "
        End If

        If txtDocName.Text.Trim <> "" Then
            vFilter += " and Doc_Name like '%" & txtDocName.Text.Trim & "%' "
        End If

        If txtGRNo.Text.Trim <> "" Then
            vFilter += " and GRNumber='" & txtGRNo.Text.Trim & "' "
        End If

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        cm.Connection = c

        cm.CommandText = "select distinct Keyword_Id, SeqId, " & _
            "(select Descr from dm_keywords where dm_keywords.Keyword_Id=dm_category_property.Keyword_Id) as Descr, " & _
            "(select Data_Type from dm_keywords where dm_keywords.Keyword_Id=dm_category_property.Keyword_Id) as Data_Type " & _
            "from dm_category_property order by SeqId"

        Try

            rs = cm.ExecuteReader
            vKeywords = ""

            OtherFilter += "<tr>"
            Do While rs.Read
                If Request.Item("txt" & rs("Keyword_Id")).Trim <> "" Then
                    vFilter += " and exists " & _
                    "(select distinct Doc_Id from dm_document_dtl where Keyword_Id=" & rs("Keyword_Id") & _
                    " and value like '%" & Request.Item("txt" & rs("Keyword_Id")) & "%' and " & _
                    "dm_document.Doc_Id = dm_document_dtl.Doc_Id)"
                End If
            Loop
            rs.Close()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to retrieve keywords. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Close()
            cm.Dispose()
            c.Dispose()
            Exit Sub
        End Try

        cm.CommandText = "select Doc_Id from dm_document where " & vFilter & " order by Date_Uploaded, Doc_Id, Doc_Name"
        'txtSAPno.Text = cm.CommandText

        Try
            txtDocList.Value = ""
            rs = cm.ExecuteReader
            txtDocList.Value = ""
            Do While rs.Read
                txtDocList.Value += rs("Doc_Id") & ","
            Loop
            rs.Close()

            If txtDocList.Value <> "" Then
                txtDocList.Value = Mid(txtDocList.Value, 1, Len(txtDocList.Value) - 1)
            End If
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to retrieve documents.  Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            cm.Dispose()
            c.Dispose()
            DataRefresh()
            vScript = "getData();"
        End Try
    End Sub

    Private Sub For_ExceptionTeam()

        'Dim c As New SqlClient.SqlConnection(connStr)

        'Dim cm As New SqlClient.SqlCommand
        'Dim cmRef As New SqlClient.SqlCommand

        'Dim rs As SqlClient.SqlDataReader

        ''Dim da As New SqlClient.SqlDataAdapter
        ''Dim ds As New DataSet

        'Dim vElapsed As Single = 0
        'Dim vNewStatus As Integer = 99
        'Dim vFilter As String = ""
        'Dim vFromDate As Date
        'Dim vToDate As Date
        'Dim vDump As New StringBuilder
        'Dim vDocAmount As Integer = 0
        'Dim vCtr As Integer = 1
        'Dim vString As String = ""
        'Dim vDocList As String = ""

        'c.Open()
        'cm.Connection = c
        'cmRef.Connection = c

        'Dim vFilename = Server.MapPath(".") & "/downloads/QueriesReport.csv"

        'If IO.File.Exists(vFilename) Then
        '    Try
        '        IO.File.Delete(vFilename)
        '    Catch ex As IO.IOException
        '        vScript = "alert('Cannot delete temp file. Error is : " & ex.Message.Replace(vbCrLf, "\n ").Replace("'", "") & "');"
        '        Exit Sub
        '    End Try
        'End If

        'vDump.AppendLine("Doc ID,Date Received,Received From,Doc Name,SAP Doc. No.,CompanyCode,Company Name,Vendor Name,Amount,Reference No.,Category,Status")

        'vFilter = ""
        'If txtDateS.Text <> "" Then
        '    vFromDate = IIf(txtDateS.Text.Length > 10, CDate(txtDateS.Text), Format(CDate(txtDateS.Text), "yyyy/MM/dd") & " 00:00:00")
        '    vToDate = IIf(txtDateE.Text.Length > 10, CDate(txtDateE.Text), Format(CDate(txtDateE.Text), "yyyy/MM/dd") & " 23:59:59")

        '    vFilter += " Date_Uploaded between '" & vFromDate & "' and '" & vToDate & "' "
        'End If

        'If cmbCategory.SelectedValue <> "All" Then
        '    vFilter += " and Category_Id =" & cmbCategory.SelectedValue
        'End If

        'If cmbStatus.SelectedValue <> "All" Then
        '    vFilter += " and Status_Cd =" & cmbStatus.SelectedValue
        'End If

        'If cmbUsers.SelectedValue <> "All" Then
        '    vFilter += " and Emp_Cd ='" & cmbUsers.SelectedValue & "' "
        'End If

        'If cmbSupplier.SelectedValue <> "All" Then
        '    vFilter += " and Supplier_Cd ='" & cmbSupplier.SelectedValue & "' "
        'End If

        'If cmbUsers.SelectedValue <> "All" Then
        '    vFilter += " and ModifyBy ='" & cmbUsers.SelectedValue & "' "
        'End If

        'If cmbEncoders.SelectedValue <> "All" Then
        '    vFilter += " and Uploaded_By ='" & cmbEncoders.SelectedValue & "' "
        'End If

        'If txtSAPno.Text.Trim <> "" Then
        '    vFilter += " and SAP_Number like '%" & txtSAPno.Text.Trim & "%' "
        'End If

        'If txtDocName.Text.Trim <> "" Then
        '    vFilter += " and Doc_Name like '%" & txtDocName.Text.Trim & "%' "
        'End If

        'cm.CommandText = "select distinct Keyword_Id, SeqId, " & _
        '    "(select Descr from dm_keywords where dm_keywords.Keyword_Id=dm_category_property.Keyword_Id) as Descr, " & _
        '    "(select Data_Type from dm_keywords where dm_keywords.Keyword_Id=dm_category_property.Keyword_Id) as Data_Type " & _
        '    "from dm_category_property order by SeqId"

        'rs = cm.ExecuteReader
        'vKeywords = ""

        'OtherFilter += "<tr>"
        'Do While rs.Read
        '    If Request.Item("txt" & rs("Keyword_Id")).Trim <> "" Then
        '        vFilter += " and exists " & _
        '            "(select distinct Doc_Id from dm_document_dtl where Keyword_Id=" & rs("Keyword_Id") & _
        '            " and Value like '%" & Request.Item("txt" & rs("Keyword_Id")) & "%' and " & _
        '            "dm_document.Doc_Id = dm_document_dtl.Doc_Id)"
        '    End If
        'Loop
        'rs.Close()

        '' Try
        'cm.CommandText = "select Doc_Id, Doc_Name, Supplier_Cd, Date_Uploaded, Status_Cd, Contents, Category_Id," & _
        '    "(select SupplierName from supplier where supplier.SupplierCd = dm_document.Supplier_Cd ) as SupName, " & _
        '    "(select Descr from dm_category where dm_category.Category_Id=dm_document.Category_Id ) as CatName,  " & _
        '    "(select Descr from dm_document_status where dm_document_status.Status_Cd=dm_document.Status_Cd ) as StatusName, " & _
        '    "(select Value from dm_document_dtl where Keyword_Id='37' and dm_document_dtl.Doc_Id=dm_document.Doc_Id ) as vAmount, " & _
        '    "(select Value from dm_document_dtl where Keyword_Id='20' and dm_document_dtl.Doc_Id=dm_document.Doc_Id ) as vRecFrom, " & _
        '    "(select Value from dm_document_dtl where Keyword_Id='35' and dm_document_dtl.Doc_Id=dm_document.Doc_Id ) as vVendor, " & _
        '    "(select Value from dm_document_dtl where Keyword_Id='38' and dm_document_dtl.Doc_Id=dm_document.Doc_Id ) as vRef, " & _
        '    "Date_Encoded, Date_Created, SAP_Number from dm_document where " & vFilter & " order by Date_Uploaded, Doc_Id, Doc_Name"

        ''Response.Write(cm.CommandText)
        'rs = cm.ExecuteReader
        'Do While rs.Read


        '    If IsNumeric(rs("vAmount")) Then
        '        vDocAmount = rs("vAmount")
        '    End If

        '    If txtvMode.Text = "Save" Then
        '        vData += "<tr " & IIf(Request.Form("chk_" & rs("Doc_Id")) = "on", "style=' background-color: #c8e4e9;'", "") & ">" & _
        '        "<td class='labelBL' style='padding:5px;'>" & vCtr & "</td>"
        '    Else
        '        vData += "<tr>" & _
        '        "<td class='labelBL' style='padding:5px;'>" & vCtr & "</td>"
        '    End If




        '    vData += "<td class='labelBC' style='padding:5px;'>" & _
        '        "<input id='chk_" & rs("Doc_Id") & "' name='chk_" & rs("Doc_Id") & "' type='checkbox' runat ='server' />"


        '    'vDocAmount = rs("Doc_Id")
        '    If txtvMode.Text = "Save" Then
        '        If Request.Form("chk_" & rs("Doc_Id")) = "on" Then

        '            vDocList += rs("Doc_Id") & ","
        '            cmRef.CommandText = "insert into dm_ledger (Doc_ID, Status_Cd, Category_Cd, TranDate, CreatedBy, Supplier_Cd, Remarks) " & _
        '                   "values (" & rs("Doc_Id") & ", 4, " & rs("Category_Id") & ", '" & _
        '                   Format(Now, "yyyy/MM/dd HH:mm:ss") & "', '" & Session("uid") & "', " & rs("Supplier_Cd") & ", '" & _
        '                   rs("Contents") & " | " & rdoExcept.SelectedItem.Text & " | Modify using queries reports')"
        '            cmRef.ExecuteNonQuery()

        '        End If
        '    End If

        '    vData += "</td>"
        '    vData += "<td style='padding:5px;'>" & rs("Doc_Id") & "</td>" & _
        '        "<td class='labelBC' style='padding:5px;'>" & rs("Date_Uploaded") & "</td>" & _
        '        "<td class='labelBL' style='padding:5px;'>" & rs("vRecFrom") & "</td>" & _
        '        "<td class='linkstyle-z' style='padding:5px; text-align:left; cursor:pointer;' onclick='openlink(" & _
        '            rs("Doc_Id") & "," & rs("Status_Cd") & ");' title='" & rs("Doc_Name") & "'>" & rs("Doc_Name") & "</td>" & _
        '        "<td class='labelBC' style='padding:5px;'>" & rs("SAP_Number") & "</td>" & _
        '        "<td class='labelBC' style='padding:5px;'>" & rs("Supplier_Cd") & "</td>" & _
        '        "<td class='labelBL' style='padding:5px;'>" & rs("SupName") & "</td>" & _
        '        "<td class='labelBL' style='padding:5px;'>" & rs("vVendor") & "</td>" & _
        '        "<td class='labelBR' style='padding:5px;'>" & _
        '            IIf(IsNumeric(rs("vAmount")), Format(vDocAmount, "##,##0.00"), rs("vAmount")) & "</td>" & _
        '        "<td class='labelBL' style='padding:5px;'>" & rs("vRef") & "</td>" & _
        '        "<td class='labelBL' style='padding:5px;'>" & rs("CatName") & "</td>"

        '    If Request.Form("chk_" & rs("Doc_Id")) = "on" And txtvMode.Text = "Save" Then
        '        vData += "<td class='labelBL' style='padding:5px; color: #e20020'>Exception</td>"
        '    Else
        '        vData += "<td class='labelBL' style='padding:5px;'>" & rs("StatusName") & "</td>"
        '    End If

        '    vData += "</tr>"

        '    vString = rs("Doc_Id") & "," & rs("Date_Uploaded") & ",""" & rs("vRecFrom") & """," & _
        '        rs("Doc_Name") & "," & rs("SAP_Number") & "," & rs("Supplier_Cd") & ",""" & _
        '        rs("SupName") & """,""" & rs("vVendor") & """," & _
        '            IIf(IsNumeric(rs("vAmount")), Format(vDocAmount, "####0.00"), rs("vAmount")) & "," & _
        '        rs("vRef") & "," & rs("CatName") & "," & rs("StatusName")

        '    vDump.AppendLine(vString)
        '    vCtr += 1
        'Loop

        'rs.Close()

        'If txtvMode.Text = "Save" Then
        '    If vDocList <> "" Then
        '        vDocList = Mid(vDocList, 1, Len(vDocList) - 1)
        '        cmRef.CommandText = "update dm_document set Contents='" & rdoExcept.SelectedItem.Text & " | " & txtReason.Text & _
        '            "', Status_Cd=4, Date_Assigned='" & Format(Now, "yyyy/MM/dd HH:mm:ss") & _
        '            "', DateModify='" & Format(Now, "yyyy/MM/dd HH:mm:ss") & "', ModifyBy='" & Session("uid") & _
        '            "' where Doc_Id in (" & vDocList & ")"

        '        cmRef.ExecuteNonQuery()
        '    End If
        '    DataRefresh()
        'End If


        'txtReason.Text = ""
        'IO.File.WriteAllText(vFilename, vDump.ToString)

        'c.Close()
        'c.Dispose()
        'cm.Dispose()
        'cmRef.Dispose()
    End Sub

    Protected Sub ccmdClose2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ccmdClose2.Click
        Session("docid") = 0
        Server.Transfer("main.aspx")
        Session.Remove("cols")
        Session.Remove("colsdescr")
        Session.Remove("qryresults")
    End Sub

    Protected Sub cmdException_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdException.Click
        Dim vSelectedDocs = txtSelectedDocs.Value
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim cmRef As New SqlClient.SqlCommand

        cm.Connection = c
        cmRef.Connection = c

        If vSelectedDocs <> "" Then
            vSelectedDocs = Mid(vSelectedDocs, 1, Len(vSelectedDocs) - 1)

            Try
                c.Open()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                c.Dispose()
                cm.Dispose()
                cmRef.Dispose()
                Exit Sub
            End Try

            
            Try
                cm.CommandText = "select Category_Id,Supplier_Cd,Doc_Id,Contents from dm_document where Doc_Id in (" & vSelectedDocs & ")"
                rs = cm.ExecuteReader
                Do While rs.Read
                    cmRef.CommandText = "insert into dm_ledger (Doc_ID, Status_Cd, Category_Cd, TranDate, CreatedBy, Supplier_Cd, Remarks) " & _
                       "values (" & rs("Doc_Id") & ", 4, " & rs("Category_Id") & ", '" & _
                       Format(Now, "yyyy/MM/dd HH:mm:ss") & "', '" & Session("uid") & "', " & rs("Supplier_Cd") & ", '" & _
                       rs("Contents") & " | " & rdoExcept.SelectedItem.Text & " | Modify using queries reports')"
                    cmRef.ExecuteNonQuery()
                Loop
                rs.Close()
                cm.CommandText = "update dm_document set Contents='" & rdoExcept.SelectedItem.Text & " | " & txtReason.Text & _
                   "', Status_Cd=4, Date_Assigned='" & Format(Now, "yyyy/MM/dd HH:mm:ss") & _
                   "', DateModify='" & Format(Now, "yyyy/MM/dd HH:mm:ss") & "', ModifyBy='" & Session("uid") & _
                   "' where Doc_Id in (" & vSelectedDocs & ")"
                cm.ExecuteNonQuery()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to udpate document. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            Finally
                c.Close()
                cm.Dispose()
                c.Dispose()
                cmdSearchNow_Click(sender, e)
            End Try
        End If
    End Sub

    Protected Sub txtDateS_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtDateS.TextChanged
        'Dim vDateDiff As Integer = 0

        'If Not IsDate(txtDateS.Text) Then
        '    vScript = "alert('Invalid date and time format in Date from field')"
        '    Exit Sub
        'End If

        'If CDate(txtDateS.Text) > CDate(txtDateE.Text) Then
        '    vScript = "alert('Date Received From Date should be earlier than To Date')"
        '    Exit Sub
        'End If

        'vDateDiff = DateDiff(DateInterval.Day, CDate(txtDateS.Text), CDate(txtDateE.Text))

        'If (vDateDiff > 14) Then
        '    txtDateE.Text = Format(CDate(txtDateS.Text).AddDays(14), "MM/dd/yyyy hh:mm:ss")
        'End If

        'DataRefresh()
    End Sub

    Protected Sub txtDateE_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtDateE.TextChanged
        'Dim vDateDiff As Integer = 0

        'If Not IsDate(txtDateS.Text) Then
        '    vScript = "alert('Invalid date and time format in Date from field')"
        '    Exit Sub
        'End If

        'If CDate(txtDateS.Text) > CDate(txtDateE.Text) Then
        '    vScript = "alert('Date Received From Date should be earlier than To Date')"
        '    Exit Sub
        'End If

        'vDateDiff = DateDiff(DateInterval.Day, CDate(txtDateS.Text), CDate(txtDateE.Text))

        'If (vDateDiff > 14) Then
        '    txtDateS.Text = Format(CDate(txtDateE.Text).AddDays(-14), "MM/dd/yyyy hh:mm:ss")
        'End If

        'DataRefresh()
    End Sub

End Class
