﻿Imports denaro.fis
Partial Class docidx
    Inherits System.Web.UI.Page
    Public vDump As String = ""
    Public vDumpSubKey As String = ""
    Public vFieldList As String = ""
    Public vScript As String = ""
    Public vBankList As String = ""
    Dim vSQL As String = ""


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Dim MachineIP = Request.ServerVariables("REMOTE_ADDR")
            Dim IsActive As Integer = 0


            vSQL = "select top 1 User_Id from audit where MachineId='" & MachineIP & "' and " _
                & "TranDate between '" & Format(Now, "yyyy-MM-dd") & " 00:00' and '" & Format(Now, "yyyy-MM-dd") & " 23:59' " _
                & "order by trandate desc"

            Session("uid") = GetRef(vSQL, "")

            vSQL = "select * from user_list where User_Id='" & Session("uid") & "'"

            Dim c As New SqlClient.SqlConnection(connStr)
            Dim cm As New SqlClient.SqlCommand(vSQL, c)
            Dim rs As SqlClient.SqlDataReader

            c.Open()
            rs = cm.ExecuteReader
            If rs.Read Then
                IsActive = 1
                Session("caption") = IIf(IsDBNull(rs("Caption")), "", rs("Caption"))
                Session("userlevel") = IIf(IsDBNull(rs("UserLevel")), 0, rs("UserLevel"))
                Session("agencylist") = IIf(IsDBNull(rs("AgencyCd")), "", rs("AgencyCd"))

                Session("Catglist") = IIf(IsDBNull(rs("CategoryCd")), "", rs("CategoryCd"))
                Session("Statuslist") = IIf(IsDBNull(rs("StatusCd")), "", rs("StatusCd"))
                Session("deptlist") = IIf(IsDBNull(rs("DeptCd")), "", rs("DeptCd"))

                Session("rclist") = IIf(IsDBNull(rs("Rc_Cd")), "", rs("Rc_Cd"))

                Session("sectionlist") = IIf(IsDBNull(rs("SectionCd")), "", rs("SectionCd"))
                Session("divlist") = IIf(IsDBNull(rs("DivCd")), "", rs("DivCd"))
                Session("unitlist") = IIf(IsDBNull(rs("UnitCd")), "", rs("UnitCd"))
                Session("typelist") = IIf(IsDBNull(rs("EmploymentType")), "", rs("EmploymentType"))

                Session("EmpPos") = IIf(IsDBNull(rs("Position")), "", "Position : " & rs("Position"))
                Session("EmpEmail") = IIf(IsDBNull(rs("Email")), "", "Email : " & rs("Email"))
                Session("EmpFullName") = IIf(IsDBNull(rs("FullName")), "", rs("FullName"))

                Session("sessionid") = Session.SessionID

            End If
            rs.Close()
            c.Close()
            c.Dispose()
            cm.Dispose()

            If IsActive = 0 Then
                vScript = "alert('Your login session has expired. Please re-login again.'); window.close();"
                Exit Sub
            End If
        End If
        'If Session("uid") = "" Then
        '    vScript = "alert('Your login session has expired. Please re-login again.'); window.close();"
        '    Exit Sub
        'End If
        'Session("uid") = "Userid"

        Dim vTime() As String
        'Dim vDateRec As Date 

        If Not IsPostBack Then
            Dim vSelectedFiles As String = ""
            vSelectedFiles = Request.Item("f")

            Dim vFileList() As String = Request.Item("f").Split("|")
            Dim vDocCtr As Integer = vFileList.Length - 1

            If vSelectedFiles <> "" Then
                vSelectedFiles = Mid(vSelectedFiles, 1, Len(vSelectedFiles) - 1)
            End If

            txtFilename.Text = vSelectedFiles
            txtFilename.ToolTip = vSelectedFiles

            txtOrigDocName.Text = vSelectedFiles
            txtOrigDocName.Text = Mid(txtOrigDocName.Text, txtOrigDocName.Text.LastIndexOf("/") + 2)
            txtOrigDocName.Text = Mid(txtOrigDocName.Text, 1, txtOrigDocName.Text.LastIndexOf("."))


            txtDateEncode.Text = Format(Now(), "MM/dd/yyyy  HH:mm:ss")
            txtDateRec.Text = txtDateEncode.Text
            vTime = Request("f").ToString.Split("/")

            BuildCombo("select AgencyCd,AgencyName from agency where exists (select User_Id from rights_list where User_Id='" _
                       & Session("uid") & "' and property='agency' and Property_Value=AgencyCd) order by AgencyName", cmbAgency)
            cmbAgency.SelectedValue = Request.Item("vCompCd")

            BuildCombo("select Category_Id,Descr from dm_category where exists (select User_Id from rights_list where User_Id='" _
                       & Session("uid") & "' and property='Category' and Property_Value=Category_Id) order by Descr", cmbCategory)
            cmbCategory.Items.Add(" ")
            cmbCategory.SelectedValue = Request.Item("vCatg")


            BuildCombo("select Status_Cd,Descr from dm_document_status where exists (select User_Id from rights_list where User_Id='" _
                       & Session("uid") & "' and property='Status' and Property_Value=Status_Cd) order by Descr", cmbStatus)
            cmbStatus.SelectedValue = 1

            BuildCombo("select Location_Id,Descr from dm_document_location order by Location_Id", cmbLoc)

            BuildCombo("select type_cd, Descr from dm_contract_type order by Descr", cmbDocType) 'contract
            cmbDocType.Items.Add(" ")
            cmbDocType.SelectedValue = " "

            'BuildCombo("select SupplierCd, SupplierName from supplier order by SupplierName", cmbCompanyList)
            'cmbCompanyList.Items.Add(" ")
            'cmbCompanyList.SelectedValue = " "

            BuildCombo("select Emp_Cd, Emp_Cd+' => '+Emp_Lname+', '+Emp_Fname from py_emp_master order by Emp_Lname", cmbEmployee)
            cmbEmployee.Items.Add(" ")
            cmbEmployee.SelectedValue = " "

            ' ==========================================================================================================================================
            ' CREATE DOCUMENT NAME FORMAT BASE ON SELECTED CATEGORY
            ' ==========================================================================================================================================
            Select Case cmbCategory.SelectedItem.Text.Trim
                Case "Non- PO"
                    txtDocName.Text = Format(Now(), "yyyyMMdd") & "NPO"
                Case "PO"
                    txtDocName.Text = Format(Now(), "yyyyMMdd") & "PO"
            End Select

            Dim c As New SqlClient.SqlConnection(connStr)
            Dim cm As New SqlClient.SqlCommand
            Dim cm_ref As New SqlClient.SqlCommand
            Dim rs As SqlClient.SqlDataReader
            Dim vCtr As Integer = 0

            c.Open()
            cm.Connection = c
            cm_ref.Connection = c

            cm.CommandTimeout = 500
            cm_ref.CommandTimeout = 500

            Dim vFilename As String = Server.MapPath(".") & "\..\" & vFileList(0).Replace("/", "\")

            If IO.File.Exists(vFilename) Then
                Dim vFile As IO.FileInfo = My.Computer.FileSystem.GetFileInfo(vFilename)
                'Response.Write(vFile.Attributes)
                If vFile.Attributes = IO.FileAttributes.System Then

                    vScript = "alert('This file is currently in use by another user. Please select a different " _
                        & "file to encode or wait for the other user to release this file.'); window.close(); "

                    '"opener.document.getElementById('txtRefreshList').value='refresh'; " & _
                    '"opener.document.form1.submit(); window.close();"

                    'Exit Sub
                Else
                    ' =======================================================================================================================================================
                    ' SET THE SELECTED FILE TO .SYSTEM MEANING THIS DOCUMENT IS INPROCESS OF ENCODING
                    ' =======================================================================================================================================================

                    For i As Integer = 0 To vDocCtr
                        IO.File.SetAttributes(Server.MapPath(".") & "\..\" & vFileList(i).Replace("/", "\"), IO.FileAttributes.System)
                    Next

                    cm.CommandText = "select * from dm_audit_docs where Emp_Cd='" & Session("uid") & "' and FileName='" & Request.Item("f") & "'"
                    rs = cm.ExecuteReader

                    If rs.Read Then
                        'no record
                    Else
                        cm_ref.CommandText = "insert into dm_audit_docs values ('" & Session("uid") _
                            & "', '" & vSelectedFiles & "', '" & Format(CDate(Now()), "yyyy/MM/dd  HH:mm:ss") & "')"
                        cm_ref.ExecuteNonQuery()
                    End If
                    rs.Close()

                End If
            End If

            cm.CommandText = "select FullName from user_list where User_Id='" & Session("uid") & "'"
            rs = cm.ExecuteReader
            rs.Read()
            txtEncodedby.Text = rs("FullName")
            rs.Close()

            c.Close()
            cm.Dispose()
            c.Dispose()

            BuildKeyworks()
        Else
            vScript = "$('#cmbCompanyList').focus();"
        End If
    End Sub

    Private Sub BuildKeyworks()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cmRef As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim rsRef As SqlClient.SqlDataReader
        Dim vSelected As String = ""
        Dim vKeyList As String = ""

        c.Open()
        cm.Connection = c
        cmRef.Connection = c

        cm.CommandText = "select Keyword_Id from dm_category_property where Category_Id=" & cmbCategory.SelectedValue & " and StatusCd is null and Type=0 order by SeqId" 'get vertical fields
        rs = cm.ExecuteReader
        Do While rs.Read
            vKeyList += rs("Keyword_Id") & ","
        Loop
        rs.Close()

        cm.CommandText = "select Keyword_Id from dm_category_property where Category_Id=" & cmbCategory.SelectedValue & " and StatusCd=" & cmbStatus.SelectedValue & " and Type=0 order by SeqId" 'get vertical fields
        rs = cm.ExecuteReader
        Do While rs.Read
            vKeyList += rs("Keyword_Id") & ","
        Loop
        rs.Close()

        txtKeyList.Text = Mid(vKeyList, 1, Len(vKeyList) - 1)

        cm.CommandText = "select * from dm_category_property where Category_Id=" & cmbCategory.SelectedValue & _
            " and Keyword_Id in (" & Mid(vKeyList, 1, Len(vKeyList) - 1) & ") and Type=0 order by SeqId" 'get vertical fields
        
        rs = cm.ExecuteReader
        vDump = ""
        Do While rs.Read
            cmRef.CommandText = "select Descr,Data_Type from dm_keywords where Keyword_Id=" & rs("Keyword_Id")

            rsRef = cmRef.ExecuteReader
            If rsRef.Read Then

                vDump += "<div class='col-8'><div Class='form-group py-1 my-0'>"
                vDump += "<label class='py-0 my-0'>" & rsRef("Descr") & "</label>"

                Select Case rsRef("Data_Type").ToString.ToUpper

                    Case "STRING", "NUMERIC"
                        vDump += "<input class='form-control form-control-sm txt-tsize border border-danger' type='text' " _
                            & "name='" & Val(rs("Keyword_Id")) & "' " _
                            & "id='" & Val(rs("Keyword_Id")) & "' " _
                            & "value='" & Request.Item(rs("Keyword_Id")) & "' />"

                    Case "LIST"
                        BuildSubListbox(rs("Keyword_Id"))

                    Case "DATE"
                        vDump += "<input class='form-control form-control-sm txt-tsize' type='text' maxlength='10' name='" _
                            & Val(rs("Keyword_Id")) & "' id='" & Val(rs("Keyword_Id")) _
                            & "' onFocus='showCalendarControl(this);' readonly='readonly' value='" & Format(Now, "MM/dd/yyyy") & "'/>&nbsp;" _
                            & "<select class='form-control form-control-sm' name='" & Val(rs("Keyword_Id")) & "_hh' id='" & Val(rs("Keyword_Id")) & "_hh'>"

                        For i As Integer = 0 To 11
                            If Format(Val(i), "00") = Hour(Now()) Then
                                vSelected = "Selected='Selected'"
                            End If
                            vDump += "<option " & vSelected & " >" & Format(Val(i), "00") & "</option>"
                        Next

                        vDump += "</select><select class='form-control form-control-sm txt-tsize' name='" _
                            & Val(rs("Keyword_Id")) & "_mm' id='" & Val(rs("Keyword_Id")) & "_mm'>"

                        For i As Integer = 0 To 59
                            vDump += "<option>" & Format(Val(i), "00") & "</option>"
                        Next

                        vDump += "</select><select class='form-control form-control-sm txt-tsize' name='" _
                            & Val(rs("Keyword_Id")) & "_am' id='" & Val(rs("Keyword_Id")) & "_am'>" _
                            & "<option>AM</option><option>PM</option>" _
                            & "</select>"

                    Case "TIME"
                        vDump += "<input class='form-control form-control-sm txt-tsize' type='text' style='width: 150px;' maxlength='7' name='" _
                            & Val(rs("Keyword_Id")) & "' id='" & Val(rs("Keyword_Id")) & "' />&nbsp;&nbsp;&nbsp;hh:mm"
                    Case "TEXTAREA"
                        vDump += "<input class='form-control form-control-sm txt-tsize border border-info' type='text' " _
                            & "name='" & Val(rs("Keyword_Id")) & "' " _
                            & "id='" & Val(rs("Keyword_Id")) & "' " _
                            & "value='" & Request.Item(rs("Keyword_Id")) & "' />"


                        'vDump += "<textarea class='form-control form-control-sm txt-tsize' rows='2' name='" _
                        '    & Val(rs("Keyword_Id")) & "' id='" & Val(rs("Keyword_Id")) & "' ></textarea>"

                    Case "YES/NO"
                        vDump += "<input type='checkbox' class='form-control form-control-sm txt-tsize' name='" _
                            & Val(rs("Keyword_Id")) & "' id='" & Val(rs("Keyword_Id")) & "' />"
                End Select
                vDump += "</div></div>"
            End If
            rsRef.Close()
        Loop
        rs.Close()

        Session("vDump") = vDump
        c.Close()
        cm.Dispose()
        cmRef.Dispose()
        c.Dispose()
    End Sub
    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click

        If Not IsDate(txtDateRec.Text) Then
            vScript = "alert('Invalid Date Received. \nPlease follow the format (MM/DD/YYYY) \nOptional (hh:mm:ss)');"
            BuildKeyworks()
            Exit Sub
        End If

        If cmbEmployee.SelectedValue <> " " Then
            BuildCardList()
        End If

        CheckifExists()
        BuildKeyworks()

    End Sub

    Private Sub SaveModule()
        SaveDocMainInfo()
        CheckDueDate()
        SaveKeywords()
        vScript = "alert('Successfully Save');  window.close();"
    End Sub

    Private Sub SaveDocMainInfo()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cm_master As New SqlClient.SqlCommand
        Dim cm_sub As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader

        Dim cmRef As New SqlClient.SqlCommand
        'Dim rsRef As SqlClient.SqlDataReader
        Dim rs_master As SqlClient.SqlDataReader

        Dim vKey As String = ""
        Dim vDoc_Id As String = ""
        Dim vDate As String = ""
        Dim vCnt As Integer = 0

        Dim vFileCollections() As String = txtFilename.Text.Split("|")
        Dim vFilename As String
        Dim vTmpFile As String
        Dim vDestFile As String = ""
        Dim vDocName_Cnt As String = ""
        Dim vLastCnt As Integer

        c.Open()
        cm.Connection = c
        cmRef.Connection = c
        cm_sub.Connection = c
        cm_master.Connection = c

        cm.CommandTimeout = 500
        cm_master.CommandTimeout = 500

        ' =======================================================================================================================================================
        ' GET THE LAST COUNTER FOR NON-PO AND PO
        '   NON-PO = ApCounter
        '   PO = ArCounter
        ' =======================================================================================================================================================
        If chkModDocName.Checked = False Then
            cm.CommandText = "select ApCounter, ArCounter from glsyscntrl"
            rs = cm.ExecuteReader
            If rs.Read Then
                Select Case cmbCategory.SelectedItem.Text.Trim
                    Case "Non- PO"
                        vLastCnt = rs("ApCounter") + 1
                        vDocName_Cnt = txtDocName.Text.Trim & vLastCnt
                    Case "PO"
                        vLastCnt = rs("ArCounter") + 1
                        vDocName_Cnt = txtDocName.Text.Trim & vLastCnt
                End Select
            End If
            rs.Close()
        Else
            vDocName_Cnt = txtDocName.Text.Trim
        End If

        ' =======================================================================================================================================================
        ' VALIDATE IF THE DOCUMENT NAME EXSITS
        ' =======================================================================================================================================================
        cm_master.CommandText = "select Doc_Id, Doc_Name, Date_Uploaded, Uploaded_By " _
            & "from dm_document " _
            & "where Doc_Name='" & vDocName_Cnt & "' and " _
            & "year(Date_Created) between '" & Format(Now, "yyyy") - 1 & "' and '" & Format(Now, "yyyy") & "' "
        rs_master = cm_master.ExecuteReader

        If rs_master.Read Then

            If Not IsDBNull(rs_master("Doc_Id")) Then
                BuildKeyworks()

                vScript = "alert('The Document is already exists.\n\n Document ID : " & rs_master("Doc_Id") & "\n Document Name : " & rs_master("Doc_Name") & "\n Date Uploaded : " & rs_master("Date_Uploaded") & "\n Uploaded By : " & rs_master("Uploaded_By") & "'); " 'window.close();"

                'opener.document.getElementById('txtRefreshList').value='refresh'; " & _
                '"opener.document.form1.submit(); " '

                'cmdClose.Visible = True
                'cmdSave.Visible = False
                'cmdCancel.Visible = False

                ''For Each vTmpFile In vFileCollections
                ''    vFilename = Server.MapPath(".") & vTmpFile.Replace(" / ", " \ ")
                ''    'Response.Write(vFilename & "<br>")
                ''    If IO.File.Exists(vFilename) Then
                ''        Dim vFile As IO.FileInfo = My.Computer.FileSystem.GetFileInfo(vFilename)
                ''        ''IO.File.SetAttributes(vFilename, IO.FileAttributes.normal = IO.FileAttributes.System)
                ''        'IO.File.SetAttributes(vFilename, IO.FileAttributes.System)
                ''    Else
                ''        'Response.Write(vFilename)
                ''    End If
                ''Next
            End If

            c.Close()
            c.Dispose()

            cm.Dispose()
            cmRef.Dispose()
            cm_sub.Dispose()
            cm_master.Dispose()

            Exit Sub
        End If
        rs_master.Close()


        ' =======================================================================================================================================================
        ' GET THE NEXT STEP BASED ON THE SELECTED CATEGORY AND STARTING STATUS
        ' =======================================================================================================================================================
        Dim vNextStep As String = ""
        'If cmbStatus.SelectedValue = 1 Then ' THE STATUS CODE 1 IS "FOR PROCESSING" THE STARTING POINT OF DTS FLOW
        cm.CommandText = "select NextStep from dm_process where category_id='" _
            & cmbCategory.SelectedValue & "' and Status_Cd='" & cmbStatus.SelectedValue & "' and PrevStatus_Cd is null"

        rs = cm.ExecuteReader
        If rs.Read Then
            vNextStep = rs("NextStep")
        End If
        rs.Close()
        'End If


        ' =======================================================================================================================================================
        ' INSERT TO DM_DOCUMENT AS NEW RECORD
        ' =======================================================================================================================================================
        ' OLD CODE
        ' =======================================================================================================================================================
        ' cm.CommandText = "insert into dm_document (Doc_Name, Created_By, Encoded_By, Uploaded_By, Date_Created, Date_Encoded, " & _
        '    "Uploaded_Path, Category_Id, Status_Cd, NextStatus, Location_Id, contract_id, Supplier_Cd, Date_Uploaded) values " & _
        '    "('" & txtDocName.Text & "', '" & Session("uid") & "', '" & Session("uid") & "', '" & Session("uid") & "', " & _
        '    "'" & Format(Now, "yyyy/MM/dd HH:mm:ss") & "', '" & Format(Now, "yyyy/MM/dd  HH:mm:ss") & _
        '    "', '" & txtFilename.Text & "', " & Session("catgid") & ", 1, '" & vNextStep & "', 0, '" & cmbDocType.SelectedValue & "', '" & _
        '    cmbCompanyList.SelectedValue & "', '" & txtDateRec.Text & "')"
        ' Response.Write(cm.CommandText)

        ' =======================================================================================================================================================
        ' NEW CODE START HERE
        ' =======================================================================================================================================================
        cm.CommandText = "insert into dm_document (Doc_Name, Created_By, Encoded_By, Uploaded_By, Date_Created, Date_Encoded, " _
            & "Uploaded_Path, Category_Id, Status_Cd, NextStatus, Location_Id, contract_id, Supplier_Cd, Date_Uploaded,AgencyCd, OrigFileName,DueDate) values " _
            & "('" & vDocName_Cnt & "', '" & Session("uid") & "', '" & Session("uid") & "', '" & Session("uid") & "', " _
            & "'" & Format(Now, "yyyy/MM/dd HH:mm:ss") & "', '" & Format(Now, "yyyy/MM/dd  HH:mm:ss") _
            & "', '" & txtFilename.Text.Replace("Uploaded", "Doc_Archive") & "', " & cmbCategory.SelectedValue & ", '" _
            & cmbStatus.SelectedValue & "', '" & vNextStep & "', '" & cmbLoc.SelectedValue & "', '" & cmbDocType.SelectedValue & "', '" _
            & cmbCompanyList.SelectedValue & "', '" & txtDateRec.Text & "','" & Request.Item("vCompCd") & "', '" & txtOrigDocName.Text & "', '" & txtDateRec.Text & "')"
        Try
            cm.ExecuteNonQuery()
        Catch ex As DataException
            vScript = "alert('An error occurred while trying to Save the new record.');"
            c.Close()
            c.Dispose()
            cm.Dispose()
        End Try










        ' =======================================================================================================================================================
        ' AFTER SUCCESSFULLY SAVE UPDATE THE NON-PO AND PO COUNTER IN CLSYSCONTROL 
        ' =======================================================================================================================================================
        If chkModDocName.Checked = False Then
            Select Case cmbCategory.SelectedItem.Text.Trim
                Case "Non- PO"
                    cm.CommandText = "update glsyscntrl set ApCounter='" & vLastCnt & "'"
                Case "PO"
                    cm.CommandText = "update glsyscntrl set ArCounter='" & vLastCnt & "'"
            End Select

            Try
                cm.ExecuteNonQuery()
            Catch ex As DataException
                vScript = "alert('An error occurred while trying to Save the new record.');"
                c.Close()
                c.Dispose()
                cm.Dispose()
            End Try
        End If
        txtDocTemp.Text = ""

        ' =======================================================================================================================================================
        ' AFTER INSERTING THE DOCUMENT IN dm_document THIS CODE USE TO GET THE DOCUMENT ID. 
        '   BECAUSE THE DATATYPE OF Doc_Id in dm_document IS AUTO CREATE
        ' =======================================================================================================================================================
        cm.CommandText = "select top 1 Doc_Id from dm_document where " _
            & "Encoded_By ='" & Session("uid") & "' and " _
            & "OrigFileName='" & txtOrigDocName.Text.Trim & "' and  " _
            & "year(Date_Created) between '" & Format(Now, "yyyy") - 1 & "' and '" & Format(Now, "yyyy") & "' " _
            & "order by Date_Created desc"
        rs = cm.ExecuteReader
        If rs.Read Then
            vDoc_Id = rs("Doc_Id")
            txtDocTemp.Text = rs("Doc_Id")
        End If
        rs.Close()

        ' =======================================================================================================================================================
        ' TRANSFER ALL ENCODED DOCUMENTS
        ' =======================================================================================================================================================
        Dim iCtr As Integer = 1
        Dim vGetUploadedPath As String = ""
        Dim vUploadedPath As String = ""

        For Each vTmpFile In vFileCollections
            vFilename = Server.MapPath(".") & "\..\" & vTmpFile.Replace("/", "\")
            vDestFile = Server.MapPath(".") & "\..\" & vTmpFile.Replace("Uploaded", "Doc_Archive")
            vDestFile = vDestFile.Replace("/", "\")

            vGetUploadedPath = vTmpFile.Replace("/", "\")
            vGetUploadedPath = vTmpFile.Replace("Uploaded", "Doc_Archive")
            vGetUploadedPath = vGetUploadedPath.Replace("/", "\")
retry:
            vDestFile = Mid(vDestFile, 1, vDestFile.LastIndexOf("\") + 1) & Year(Now()) & "\" & vDoc_Id & IIf(vFileCollections.Length > 1, "-" & iCtr, "") & ".pdf"

            vUploadedPath += Mid(vGetUploadedPath, 1, vGetUploadedPath.LastIndexOf("\") + 1) & Year(Now()) & "\" & vDoc_Id & IIf(vFileCollections.Length > 1, "-" & iCtr, "") & ".pdf|"

            If IO.File.Exists(vDestFile) Then
                Dim vFile As IO.FileInfo = My.Computer.FileSystem.GetFileInfo(vFilename)

                'IO.File.SetAttributes(vFilename, IO.FileAttributes.System)
                'If System.IO.Directory.Exists(vDestFile) Then
                'System.IO.Directory.CreateDirectory(vDestFile)
                'End If
                iCtr += 1
                GoTo retry
            Else
                'Response.Write(vFilename)
                Try
                    System.IO.File.Move(vFilename, vDestFile)
                Catch ex As System.IO.IOException
                    vScript = "alert('An error occurred while trying to Move the document to Archive folder.');"

                End Try
            End If
            iCtr += 1
        Next

        vUploadedPath = vUploadedPath.Replace("\", "/")
        cm.CommandText = "update dm_document set Uploaded_Path='" & Mid(vUploadedPath, 1, Len(vUploadedPath) - 1) & "' where Doc_Id=" & vDoc_Id
        cm.ExecuteNonQuery()

        c.Close()
        c.Dispose()
        cm.Dispose()
        cmRef.Dispose()
        cm_sub.Dispose()
        cm_master.Dispose()

    End Sub

    Public Sub CheckDueDate()

        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim vDaysAlert As Integer = 0 'days 
        Dim vDoc_Id As String = txtDocTemp.Text
        Dim vCrediTo As String = ""

        c.Open()
        cm.Connection = c
        If cmbCompanyList.SelectedValue <> " " Then
            cm.CommandText = "select Terms from supplier where Terms > 0 and SupplierCd='" & cmbCompanyList.SelectedValue & "' "
        Else
            cm.CommandText = "select * from py_emp_master where Emp_Cd='" & cmbEmployee.SelectedValue & "' "
            vCrediTo = ", CreditTo='" & cmbEmployee.SelectedValue & "', " _
                & "Bank_Id='" & IIf(Request.Item("cmbAccnt") <> "", "null", Request.Item("cmbAccnt")) & "' "

        End If

        rs = cm.ExecuteReader
        If rs.Read Then
            If rs("Terms") > 0 Then
                vDaysAlert = rs("Terms")
            End If
        End If
        rs.Close()

        If vDaysAlert > 0 Then
            Dim vDueDate As Date = CDate(txtDateRec.Text.Trim)
            Dim iCtr As Integer = 0
            Dim pDueDate As String = ""
            Dim vTmpDueDate As Date = vDueDate

            ' ===================================================================================================================================
            ' GET DUE DATE. ADD DAYS BASED ON THE VENDOR PAYTEMS AND REMOVE WEEKEND DAYS
            ' ===================================================================================================================================
            vDueDate = vTmpDueDate.AddDays(vDaysAlert)
            vSQL = "update dm_document set DueDate='" & vDueDate & "'" & vCrediTo & " where Doc_Id=" & vDoc_Id
            cm.CommandText = vSQL

            Try
                cm.ExecuteNonQuery()
            Catch ex As DataException
                vScript = "alert('An error occurred while trying to update Due Date.');"

                c.Close()
                c.Dispose()
                cm.Dispose()
            End Try
        End If

        c.Close()
        c.Dispose()
        cm.Dispose()

    End Sub

    Private Sub SaveKeywords()

        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cm_sub As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader

        Dim cmRef As New SqlClient.SqlCommand
        'Dim rsRef As SqlClient.SqlDataReader

        Dim vKey As String = ""
        Dim vDoc_Id As String = txtDocTemp.Text
        Dim vDate As String = ""
        Dim vAssignTo As String = ""
        Dim vSQL As String = ""

        c.Open()
        cm.Connection = c
        cmRef.Connection = c
        cm_sub.Connection = c

        cm.CommandTimeout = 500
        cmRef.CommandTimeout = 500
        cm_sub.CommandTimeout = 500

        cm.CommandText = "select *, " _
            & "(select Descr from dm_keywords where dm_category_property.Keyword_Id=dm_keywords.Keyword_Id)  as Descr, " _
            & "(select Data_Type from dm_keywords where dm_category_property.Keyword_Id=dm_keywords.Keyword_Id) as DataType " _
            & " from dm_category_property where " _
            & "Category_Id=" & cmbCategory.SelectedValue & " and " _
            & "Keyword_Id in (" & txtKeyList.Text & ") and Type=0 order by SeqId"
        rs = cm.ExecuteReader

        Do While rs.Read
            vKey = rs("keyword_id")

            vSQL = "insert into dm_document_dtl (Doc_Id, Keyword_Id, Value, " & _
                        "Alert_Before_Hrs, EmailAlert, EmailFrequency, EmailFrequencyCount ) "

            Select Case rs("DataType")
                Case "STRING", "NUMERIC", "TIME"
                    vSQL += " values ('" & vDoc_Id & "', " & rs("keyword_id") & ", '" & Request.Form(vKey) & "', 0,0,0,0)"
                Case "LIST"
                    If Not IsDBNull(rs("CmdType")) Then
                        cm_sub.CommandText = rs("CmdType") & " " & rs("TableName") & " set " & rs("FieldName") & "='" & Request.Form(rs("keyword_id").ToString) & "' where " & rs("FieldKey") & "=" & vDoc_Id
                        cm_sub.ExecuteNonQuery()
                        vAssignTo = Request.Form(rs("keyword_id").ToString)
                    End If
                    vSQL += "values ('" & vDoc_Id & "', " & rs("keyword_id") & ", '" & Request.Form(rs("keyword_id").ToString) & "', 0,0,0,0)"
                Case "DATE"
                    If Request.Form(vKey) <> "" Then
                        vDate = Format(CDate(Request.Form(vKey)), "yyyy/MM/dd") & " " & Request.Form(vKey & "_hh") & ":" _
                            & Request.Form(vKey & "_mm") & ":00 " & Request.Form(vKey & "_am")

                        vSQL += "values ('" & vDoc_Id & "', " & rs("keyword_id") & ", '" _
                            & vDate & "', 0,0,0,0)"
                    Else
                        vSQL += "values ('" & vDoc_Id & "', " & rs("keyword_id") & ", '', 0,0,0,0)"
                    End If

                Case "TEXTAREA"
                    vSQL += "values ('" & vDoc_Id & "', " & rs("keyword_id") & ", '" & Request.Form(vKey) & "', 0,0,0,0)"

                Case "YES/NO"

            End Select
            cm_sub.CommandText = vSQL
            cm_sub.ExecuteNonQuery()

        Loop
        rs.Close()

        cm.CommandText = "insert into dm_ledger (Doc_ID, Status_Cd, Category_Cd, TranDate, " _
            & "CreatedBy, Remarks, Supplier_Cd, AgencyCd, IsAssignTo) " _
            & "values (" & vDoc_Id & ", '" & cmbStatus.SelectedValue & "', '" & cmbCategory.SelectedValue & "', '" _
            & Format(Now, "yyyy/MM/dd HH:mm:ss") & "', '" & Session("uid") & "','" _
            & IIf(cmbStatus.SelectedValue = 1, "New Records", cmbStatus.SelectedItem.Text) & "', '" _
            & cmbCompanyList.SelectedValue & "', '" & cmbAgency.SelectedValue & "', '" & vAssignTo & "')"
        Try
            cm.ExecuteNonQuery()
        Catch ex As DataException
            vScript = "alert('An error occurred while trying to Save the new record in dm_ledger.');"

        End Try

        cm.CommandText = "delete from dm_audit_docs where Emp_Cd ='" & Session("uid") & "' and Filename ='" & txtFilename.Text & "'"
        cm.ExecuteNonQuery()

        c.Close()
        c.Dispose()
        cm.Dispose()
        cmRef.Dispose()
        cm_sub.Dispose()

    End Sub

    Protected Sub cmdCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCancel.Click

        Dim vFileCollections() As String = txtFilename.Text.Split("|")
        Dim vTmpFile As String
        Dim vFilename As String

        For Each vTmpFile In vFileCollections
            vFilename = Server.MapPath(".") & "\..\" & vTmpFile.Replace("/", "\")
            If IO.File.Exists(vFilename) Then
                IO.File.SetAttributes(vFilename, IO.FileAttributes.System = IO.FileAttributes.Normal)
            End If
        Next

        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand

        c.Open()
        cm.Connection = c
        
        cm.CommandText = "delete from dm_audit_docs where Emp_Cd ='" & Session("uid") & "' and Filename ='" & txtFilename.Text & "'"
        cm.ExecuteNonQuery()

        cm.Dispose()
        c.Close()
        c.Dispose()
        vScript = "window.close();"
    End Sub

    Protected Sub cmbCategory_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbCategory.SelectedIndexChanged
       Select Case cmbCategory.SelectedItem.Text.Trim
            Case "Non- PO"
                txtDocName.Text = Format(Now(), "yyyyMMdd") & "NPO"
            Case "PO"
                txtDocName.Text = Format(Now(), "yyyyMMdd") & "PO"
        End Select
        BuildKeyworks()
    End Sub

    Protected Sub chkModDocName_CheckedChanged(sender As Object, e As EventArgs) Handles chkModDocName.CheckedChanged

        If chkModDocName.Checked = True Then
            txtDocName.ForeColor = Color.Black
            txtDocName.ReadOnly = False
        Else
            txtDocName.ForeColor = Color.Gray
            txtDocName.ReadOnly = True

            Select Case cmbCategory.SelectedItem.Text.Trim
                Case "Non- PO"
                    txtDocName.Text = Format(Now(), "yyyyMMdd") & "NPO"
                Case "PO"
                    txtDocName.Text = Format(Now(), "yyyyMMdd") & "PO"
            End Select
        End If
        If Session("vDump") = "" Then
            BuildKeyworks()
        Else
            vDump = Session("vDump")
        End If
        'BuildKeyworks()
    End Sub

    Protected Sub cmbStatus_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbStatus.SelectedIndexChanged
        If cmbEmployee.SelectedValue <> " " Then
            BuildCardList()
        End If
        If Session("vDump") = "" Then
            BuildKeyworks()
        Else
            vDump = Session("vDump")
        End If
    End Sub

    Private Sub BuildSubListbox(ByVal vKey As String)
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader

        Dim cmSub As New SqlClient.SqlCommand
        Dim rsSub As SqlClient.SqlDataReader

        Dim vSubKeyList As String = ""
        Dim vlblName As String = ""
        Dim vSql As String = ""

        c.Open()
        cm.Connection = c
        cmSub.Connection = c
        vDumpSubKey = ""

        cm.CommandText = "select * from dm_category_property where Category_Id=" & cmbCategory.SelectedValue & " and StatusCd=" & cmbStatus.SelectedValue & " and Keyword_id=" & vKey & ""

        Try
            rs = cm.ExecuteReader
            If rs.Read Then
                vDump += "<tr><td class='labelR'>" & rs("LabelText") & " : </td>"
                vDump += "<td><select class='labelL' id='" & vKey & "' name='" & vKey & "' style='width:226px;'>"

                cmSub.CommandText = rs("SetResource")
                'Response.Write(rs("SetResource"))
                rsSub = cmSub.ExecuteReader
                Do While rsSub.Read
                    vDump += "<option value='" & rsSub("vID") & "'  >" & rsSub("vDescr") & "</option>"
                Loop
                rsSub.Close()
                vDump += "</td></tr>"
            End If
            rs.Close()

        Catch ex As DataException
            vScript = "alert('An error occurred while trying to Save the new record.');"

            c.Close()
            c.Dispose()
            cm.Dispose()
        Finally
            c.Close()
            c.Dispose()
            cm.Dispose()
        End Try

    End Sub

    Protected Sub cmbEmployee_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbEmployee.SelectedIndexChanged
        cmbCompanyList.Items.Add(" ")
        cmbCompanyList.SelectedValue = " "
        'BuildKeyworks()
        BuildCardList()
        If Session("vDump") = "" Then
            BuildKeyworks()
        Else
            vDump = Session("vDump")
        End If
    End Sub

    Private Sub BuildCardList()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim vSelected As String = ""

        c.Open()
        cm.Connection = c

        vBankList = "<label class='py-0 my-0'>Account No:</label>"
        vBankList += "<select class='form-control form-control-sm txt-tsize' id='cmbAccnt' name='cmbAccnt' TabIndex='65'>"
        cm.CommandText = "select Bank_Id,Descr,Bank_No from emp_banklist where Emp_Cd='" & cmbEmployee.SelectedValue & "' "

        Try
            rs = cm.ExecuteReader
            Do While rs.Read
                If Request.Item("cmbAccnt") = rs("Bank_Id") Then
                    vSelected = " selected='selected'"
                Else
                    vSelected = ""
                End If
                vBankList += "<option value='" & rs("Bank_Id") & "'" & vSelected & "  >" & rs("Descr") & " => " & rs("Bank_No") & "</option>"
            Loop
            vBankList += "</select>"
            rs.Close()

            Session("vBankList") = vBankList

        Catch ex As DataException
            vScript = "alert('An error occurred while trying to Save the new record.');"
            c.Close()
            c.Dispose()
            cm.Dispose()
        Finally
            c.Close()
            c.Dispose()
            cm.Dispose()
        End Try
    End Sub

    Private Sub CheckifExists()

        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim vNotValid As Integer = 0
        Dim vValueIn As String = ""
        cm.CommandTimeout = 500
        txtDocExists.Value = ""

        If Request.Form("37") <> "" Then
            vValueIn = "'" & Request.Form("37") & "'"
        Else
            vScript = "alert('Please enter amount.')"
            Exit Sub
        End If

        ' FIND reference VALUE with same vendor name and 
        If Request.Form("38") <> "" Then
            If Request.Form("37") <> "" Then
                vValueIn += ","
            End If
            vValueIn += "'" & Request.Form("38") & "'"
        Else
            vScript = "alert('Please enter reference.')"
            Exit Sub
        End If

        c.Open()
        cm.Connection = c

        If cmbCompanyList.SelectedValue <> " " Then
            cm.CommandText = "select top 1 dm_document.Doc_Id from dm_document,dm_document_dtl " _
                & "where dm_document.Supplier_Cd='" & cmbCompanyList.SelectedValue & "' and " _
                & "year(Date_Created) between '" & Format(Now, "yyyy") - 1 & "' and '" & Format(Now, "yyyy") & "' and " _
                & "dm_document.Doc_Id=dm_document_dtl.Doc_Id and  " _
                & "convert(varchar,Value) in (" & vValueIn & ") order by Date_Created desc"
        Else
            cm.CommandText = "select top 1 dm_document.Doc_Id from dm_document,dm_document_dtl " _
                & "where dm_document.CreditTo='" & cmbEmployee.SelectedValue & "' and " _
                & "year(Date_Created) between '" & Format(Now, "yyyy") - 1 & "' and '" & Format(Now, "yyyy") & "' and " _
                & "dm_document.Doc_Id=dm_document_dtl.Doc_Id and  " _
                & "convert(varchar,Value) in (" & vValueIn & ") order by Date_Created desc"
        End If

        Try
            rs = cm.ExecuteReader
            If rs.Read Then
                vNotValid = 1
                txtDocExists.Value = rs("Doc_Id")
            End If
            'Do While rs.Read
            '    'lblErrorMessage.ForeColor = Color.Red
            '    'lblErrorMessage.Font.Size = 13
            '    'lblErrorMessage.Visible = True
            '    'lblErrorMessage.Text = "The system discovered the same information."
            'Loop
            rs.Close()

            If vNotValid = 1 Then
                vScript = "$('#divInfo').modal('show');"
                c.Close()
                c.Dispose()
                cm.Dispose()
                'vScript = "document.getElementById('divTrans').style.visibility = 'visible'; document.getElementById('divInfo').style.visibility = 'visible';"
            End If

        Catch ex As DataException
            vScript = "alert('An error occurred while trying to Save the new record.');"
            c.Close()
            c.Dispose()
            cm.Dispose()
        Finally
            c.Close()
            c.Dispose()
            cm.Dispose()
        End Try

        If vNotValid = 0 Then
            SaveModule()
        End If

    End Sub

    'Protected Sub cmbCompanyList_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbCompanyList.SelectedIndexChanged
    '    cmbEmployee.SelectedValue = " "
    '    BuildKeyworks()
    'End Sub

    Protected Sub cmdContinue_Click(sender As Object, e As EventArgs) Handles cmdContinue.Click
        SaveModule()
    End Sub

    Protected Sub cmdVoid_Click(sender As Object, e As EventArgs) Handles cmdVoid.Click
        SaveModule()

        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand

        c.Open()
        cm.Connection = c

        cm.CommandText = "update dm_ledger set Status_Cd=16, Remarks='Same Information (void)' where Doc_Id=" & txtDocTemp.Text
        cm.ExecuteNonQuery()

        cm.CommandText = "update dm_document set Status_Cd=16, Contents='Same Information (void)' where Doc_Id=" & txtDocTemp.Text
        cm.ExecuteNonQuery()

        cm.Dispose()
        c.Close()
        c.Dispose()
    End Sub

    Private Sub btnSearch_ServerClick(sender As Object, e As EventArgs) Handles btnSearch.ServerClick

        If txtVendorKeyName.Value.Trim <> "" Then
            vSQL = "select SupplierCd, SupplierName from supplier " _
            & "where SupplierName Like '" & txtVendorKeyName.Value.Trim & "%' " _
            & "order by SupplierName"

            BuildCombo(vSQL, cmbCompanyList)
        End If



        'cmbCompanyList.Items.Add(" ")
        'cmbCompanyList.SelectedValue = " "


        If Session("vDump") = "" Then
            BuildKeyworks()
        Else
            vDump = Session("vDump")
        End If


    End Sub

End Class
