﻿Imports denaro.fis

Partial Class addcategory
    Inherits System.Web.UI.Page
    
    Public vscript As String = ""
    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Dim c As New SqlClient.SqlConnection
        Dim cm As New SqlClient.SqlCommand
        'Dim dr As SqlClient.SqlDataReader
        Dim catid As String = ""
        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c

        If Request.Item("mode") = "a" Then

            EventLog(Session("uid"), Request.ServerVariables("REMOTE_ADDR"), "ADD", "", "", "Category Item " & _
                     "-" & CleanVar(txtCatName.Text), "Category")

            cm.CommandText = "INSERT INTO dm_category(GRed_By_Client,Descr,In_Charge) values (" & _
                    rdoGR.SelectedValue & ", '" & CleanVar(txtCatName.Text) & "'," & _
                    IIf(cmbInCharge.SelectedValue <> "N/A", "'" & cmbInCharge.SelectedValue & "'", "null") & ")"
        Else
            EventLog(Session("uid"), Request.ServerVariables("REMOTE_ADDR"), "EDIT", "", "", "Category Item " & Session("vline") & _
                     "-" & CleanVar(txtCatName.Text), "Category")

            cm.CommandText = "update dm_category set Descr='" & CleanVar(txtCatName.Text) & "' "

            If cmbInCharge.SelectedValue <> "N/A" Then
                cm.CommandText += ", In_Charge='" & cmbInCharge.SelectedValue & "' "
            Else
                cm.CommandText += ", In_Charge=null "
            End If
            cm.CommandText += ", GRed_By_Client=" & rdoGR.SelectedValue & " where Category_Id='" & Session("vline") & "'"
        End If

        'Response.Write(cm.CommandText)
        cm.ExecuteNonQuery()
        cm.Dispose()

        ''cm.CommandText = "select Category_Id from dm_category where Descr='" & CleanVar(txtCatName.Text) & "'"
        ''cm.Connection = c
        ''dr = cm.ExecuteReader
        ''If dr.Read Then
        ''    catid = dr("Category_Id")
        ''End If
        ''cm.Dispose()
        c.Close()
        c.Dispose()

        'If Session("vline") = "" Then
        '    'create a directory
        '    Dim vFileYear As String = Server.MapPath(".") & "\..\Uploaded\" & CleanVar(txtCatName.Text).Replace(" ", "_") & "\" & Format(Now, "yyyy")
        '    IO.Directory.CreateDirectory(vFileYear)

        '    'Create a directory in the year created
        '    Dim vLoopMonth As Integer
        '    Dim vLoopDay As Integer
        '    Dim vLoopHOur As Integer
        '    Dim vmonthfolder As String = Server.MapPath(".") & "\..\Uploaded\" & CleanVar(txtCatName.Text).Replace(" ", "_") & "\" & Format(Now, "yyyy")
        '    Dim vdayfolder As String = Server.MapPath(".") & "\..\Uploaded\"
        '    For vLoopMonth = 1 To 12
        '        IO.Directory.CreateDirectory(vmonthfolder & "\" & vLoopMonth)
        '        For vLoopDay = 1 To 31
        '            IO.Directory.CreateDirectory(vmonthfolder & "\" & vLoopMonth & "\" & vLoopDay)
        '            For vLoopHOur = 0 To 23
        '                IO.Directory.CreateDirectory(vmonthfolder & "\" & vLoopMonth & "\" & vLoopDay & "\" & vLoopHOur)
        '            Next vLoopHOur
        '        Next vLoopDay
        '    Next vLoopMonth
        'End If
        'Session("vline") = ""
        vscript = "alert('Record successfully saved.');window.opener.document.form1.submit(); window.close();"

    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        
        If Session("uid") = Nothing Then
            vscript = "alert('Your login session has expired. Please re-login again.'); window.close(); "
            Exit Sub
        End If

        If Not IsPostBack Then
            DataRefresh()
        End If
    End Sub
    Private Sub DataRefresh()
        Dim c As New SqlClient.SqlConnection
        Dim cm As New SqlClient.SqlCommand
        Dim dr As SqlClient.SqlDataReader

        BuildCombo("select Dept_Cd,Descr from hr_dept_ref order by Descr", cmbInCharge)
        cmbInCharge.Items.Add("N/A")
        cmbInCharge.SelectedValue = "N/A"
        If Request.Item("mode") = "a" Then
            txtCatId.Text = ""
            txtCatName.Text = ""
        Else
            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c

            cm.CommandText = "select Category_Id, Descr,In_Charge, GRed_By_Client from dm_category where Category_Id='" & Session("vline") & "'"
            dr = cm.ExecuteReader
            If dr.Read Then
                rdoGR.SelectedValue = dr("Gred_By_Client")
                txtCatId.Text = dr("Category_Id")
                txtCatName.Text = dr("Descr")
                cmbInCharge.SelectedValue = IIf(IsDBNull(dr("In_Charge")), "N/A", dr("In_Charge"))
            End If
            dr.Close()
            cm.Dispose()

            c.Close()
            c.Dispose()
            cm.Dispose()
        End If

        
    End Sub
    Protected Sub btnClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnClose.Click
        vscript = "self.close();"
    End Sub
End Class
