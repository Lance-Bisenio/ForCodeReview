﻿Imports denaro.fis

Partial Class contracttype
    Inherits System.Web.UI.Page
    Public vScript As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = Nothing Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If

        If Not IsPostBack Then
            If CanRun(Session("caption"), Request.Item("id")) Then
                DataRefresh()
            Else
                Session("denied") = "1"
                Server.Transfer("main.aspx")
            End If
        End If

        If Not CanRun(Session("caption"), 2) Then
            btnAdd.Enabled = False
        End If
        If Not CanRun(Session("caption"), 3) Then
            btnEdit.Enabled = False
        End If
        If Not CanRun(Session("caption"), 4) Then
            btnDelete.Enabled = False
        End If

        DataRefresh()

    End Sub
    Private Sub DataRefresh()
        Dim c As New sqlclient.sqlConnection(connStr)
        Dim da As sqlclient.sqlDataAdapter
        Dim ds As New DataSet

        da = New sqlclient.sqlDataAdapter("SELECT * FROM dm_contract_type ORDER BY descr", c)
        da.Fill(ds, "contractype")
        tblContractType.DataSource = ds.Tables("contractype")
        tblContractType.DataBind()
        da.Dispose()
        ds.Dispose()
        c.Close()
    End Sub

    Protected Sub tblContractType_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles tblContractType.PageIndexChanging
        tblContractType.PageIndex = e.NewPageIndex
        DataRefresh()
    End Sub

    Protected Sub btnEdit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnEdit.Click
        If tblContractType.SelectedIndex >= 0 Then
            Session("vline") = tblContractType.SelectedRow.Cells(0).Text
            vScript = "btnAdd_onclick();"
        Else
            vScript = "alert('You must first select a record before you can use the Edit command.');"
        End If
    End Sub

    Protected Sub btnDelete_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        If tblContractType.SelectedIndex >= 0 Then
            Dim c As New sqlclient.sqlConnection
            Dim cm As New sqlclient.sqlCommand

            EventLog(Session("uid"), Request.ServerVariables("REMOTE_ADDR"), "DELETE", "", "", "Contract Type" & tblContractType.SelectedRow.Cells(0).Text & _
                     "-" & tblContractType.SelectedRow.Cells(1).Text, "Contract")

            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c
            cm.CommandText = "DELETE FROM dm_contract_type WHERE type_cd='" & tblContractType.SelectedRow.Cells(0).Text & "'"
            cm.ExecuteNonQuery()
            cm.Dispose()
            c.Close()
            vScript = "alert('Record was successfully deleted.');"
            DataRefresh()
            tblContractType.SelectedIndex = -1
        Else
            vScript = "alert('You must first select a record before you can use the Delete command.');"
        End If
    End Sub

    Protected Sub btnDelete_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnDelete.Init
        btnDelete.Attributes.Add("onclick", "return ask();")
    End Sub

    Protected Sub btnAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        vScript = "btnAdd_onclick()"
    End Sub

    Protected Sub btnClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Server.Transfer("main.aspx")
    End Sub
End Class
