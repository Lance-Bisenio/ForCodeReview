﻿Imports denaro.fis
Partial Class catgprop
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            vScript = "alert('Your login session has expired. Please re-login again.'); window.close();"
            Exit Sub
        End If
        If Session("vline") = Nothing Or Session("vline") = "" Then
            vScript = "alert('You must first select a category to edit.'); window.close();"
            Exit Sub
        End If
        If Not IsPostBack Then
            txtId.Text = Session("vline")
            Dim c As New SqlClient.SqlConnection(connStr)
            Dim cm As New SqlClient.SqlCommand("select Descr from dm_category where Category_Id=" & txtId.Text, c)
            Dim rs As SqlClient.SqlDataReader

            Try
                c.Open()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                c.Dispose()
                cm.Dispose()
                Exit Sub
            End Try

            Try
                rs = cm.ExecuteReader
                If rs.Read Then
                    txtDescr.Text = rs("Descr")
                End If
                rs.Close()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to read Categories. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            Finally
                c.Close()
                cm.Dispose()
                c.Dispose()
            End Try
        End If
        DataRefresh()
    End Sub
    Private Sub DataRefresh()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim da As SqlClient.SqlDataAdapter
        Dim ds As New DataSet

        Try
            da = New SqlClient.SqlDataAdapter("select SeqId,Keyword_Id,(select Descr from dm_keywords where " & _
                "dm_keywords.Keyword_Id=dm_category_property.Keyword_Id) as Descr,Type from dm_category_property " & _
                "where Category_Id=" & Session("vline"), c)

            da.Fill(ds, "prop")
            tblProp.DataSource = ds.Tables("prop")
            tblProp.DataBind()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to retreive data. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Dispose()
            'da.Dispose()
            ds.Dispose()
        End Try
    End Sub

    Protected Sub cmdDel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDel.Click
        If tblProp.SelectedIndex >= 0 And tblProp.SelectedIndex <= tblProp.Rows.Count Then
            Dim c As New SqlClient.SqlConnection(connStr)
            Dim cm As New SqlClient.SqlCommand("delete from dm_category_property where Category_Id=" & txtId.Text & _
                                                " and Keyword_Id=" & tblProp.SelectedRow.Cells(1).Text, c)
            Try
                c.Open()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                c.Dispose()
                cm.Dispose()
                Exit Sub
            End Try
            Try
                cm.ExecuteNonQuery()
                DataRefresh()
            Catch ex As Exception
                vScript = "alert('Error occurred while trying to delete the Keyword. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            Finally
                c.Close()
                c.Dispose()
                cm.Dispose()
            End Try
        Else
            vScript = "alert('You must first select a Keyword to delete.');"
        End If
    End Sub

    Protected Sub tblProp_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles tblProp.PageIndexChanging
        tblProp.PageIndex = e.NewPageIndex
        DataRefresh()
    End Sub

    Protected Sub tblProp_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tblProp.SelectedIndexChanged

        Session("kid") = tblProp.SelectedRow.Cells(1).Text
        Session("kdescr") = tblProp.SelectedRow.Cells(2).Text
    End Sub
End Class
