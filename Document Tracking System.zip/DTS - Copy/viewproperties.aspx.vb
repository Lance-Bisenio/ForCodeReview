﻿Imports denaro.fis
Partial Class viewproperties
    Inherits System.Web.UI.Page
    Public vscript As String
    Public SubAttachment As String = ""
    Public vkeywords As String = ""
    Public vNotes As String = ""
    Dim vclass As String = "odd"
    Dim vSender As String = ""
    Dim vReceipient As String = ""
    Public vAction As String = ""
    'Public SubKeywords As String = ""
    Public vDumpKeywords As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Or Session("uid") = Nothing Then
            vscript = "alert('Your login session has expired. Please re-login again.'); window.close();"
            Exit Sub
        End If

        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If

        ' cmdVoid.Enabled = CanRun(Session("caption"), 66)
        'If Request.Form("txtRefreshList") = "refresh" Then
        '    vscript = "window.opener.document.form1.submit(); window.close();"
        'End If

        If Not IsPostBack Then
            GetDoc_MasterDetails()
            'BuildTaskOption()
        End If

        If txtSelectedStatus.Value <> "" Then
            GetDoc_MasterDetails()
            GetSub_Keywords()
        End If

        BuildTaskOption()
    End Sub

    Private Sub GetDoc_MasterDetails()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cmRef As New SqlClient.SqlCommand
        Dim cmSub As New SqlClient.SqlCommand

        Dim rs As SqlClient.SqlDataReader
        Dim rsref As SqlClient.SqlDataReader
        'Dim rsSub As SqlClient.SqlDataReader

        Dim vStatus As String = ""
        
        Dim i As Integer = 0
        Dim vGRedClient As Integer = 0
        Dim vOldStatus As String = ""
        Dim vDocAmount As String = ""
        Dim vDocSupp As String = ""
        Dim vPrevStatus As String = ""

        cm.Connection = c
        cmRef.Connection = c
        cmSub.Connection = c
        c.Open()

        cm.CommandText = "select * from user_list where User_Id='" & Session("uid") & "'"
        rs = cm.ExecuteReader
        If rs.Read Then
            lblEmpCd.Text = rs("User_Id")
            lblEmpName.Text = rs("FullName")
        End If
        rs.Close()

        cm.CommandText = "select count(Doc_Id) as vCount from dm_oldrecord where Doc_Id=" & Request.Item("id")
        rs = cm.ExecuteReader
        If rs.Read Then
            If rs("vCount") > 0 Then
                btnDocHistory.Enabled = True
            End If
        End If
        rs.Close()

        ' ====================================================================================================================
        ' GET THE FULL DETAILS OF THE DOCUMENT
        ' ====================================================================================================================
        cm.CommandText = "select GRedClient, LineItem, SAP_Number, Doc_Id,Doc_Name,Created_By,Encoded_By,Uploaded_By," & _
             "Date_Created,Date_Encoded,Date_Uploaded,Contents,Uploaded_Path, AgencyCd," & _
             "Category_id,location_id,status_cd,contract_id,Supplier_Cd,Sap_Number,LineItem,SubAttachment," & _
             "(select SupplierName from supplier where supplier.SupplierCd=dm_document.Supplier_Cd) as Supplier, " & _
             "(select Terms from supplier where supplier.SupplierCd=dm_document.Supplier_Cd) as PayTerms, SubAttachment , " & _
             "(select Descr from dm_document_location where dm_document_location.Location_Id=dm_document.Location_Id) as LocName, " & _
             "Contact_Person,Emp_Cd,Contents,GRNumber,PrevStatus,NextStatus, DueDate, VendorClearingNo, BatchClearingNo, OrigFileName from dm_document where Doc_Id=" & Request.Item("id")
        'Response.Write(cm.CommandText)

        Try
            BuildCombo("select Status_Cd,Descr from dm_document_status", cmbStatus)

            rs = cm.ExecuteReader
            If rs.Read Then

                cmbStatus.SelectedValue = rs("Status_Cd")
                lblDocId.Text = Request.Item("id")
                lblDocName.Text = IIf(IsDBNull(rs("Doc_Name")), "", rs("Doc_Name"))
                lblSAPNo.Text = IIf(IsDBNull(rs("SAP_Number")), "", rs("SAP_Number"))
                lblVCNo.Text = IIf(IsDBNull(rs("VendorClearingNo")), "", rs("VendorClearingNo"))
                lblBCNo.Text = IIf(IsDBNull(rs("BatchClearingNo")), "", rs("BatchClearingNo"))
                lblOrigFileName.Text = IIf(IsDBNull(rs("OrigFileName")), "", rs("OrigFileName"))
                lblTerms.Text = IIf(IsDBNull(rs("PayTerms")), "", rs("PayTerms"))

                lblCompCd.Text = rs("AgencyCd")
                lblCatCd.Text = rs("Category_Id")
                lblSupCd.Text = rs("Supplier_Cd")

                If Not IsPostBack Then
                    txtSDNo.Text = IIf(IsDBNull(rs("SAP_Number")), "", rs("SAP_Number"))
                    txtDueDate.Text = IIf(IsDBNull(rs("DueDate")), "", rs("DueDate"))
                    txtVCNo.Text = IIf(IsDBNull(rs("VendorClearingNo")), "", rs("VendorClearingNo"))
                    txtBCNo.Text = IIf(IsDBNull(rs("BatchClearingNo")), "", rs("BatchClearingNo"))
                    lblCNotes.Text = IIf(IsDBNull(rs("Contents")), "", rs("Contents"))
                    lblLoc.Text = IIf(IsDBNull(rs("LocName")), "", rs("LocName"))
                End If

                lblSupplier.Text = IIf(IsDBNull(rs("Supplier")), "", rs("Supplier"))

                If Not IsDBNull(rs("Doc_Name")) Then
                    lblDocName.Text = rs("Doc_Name")
                End If

                lblCreatedBy.Text = ""
                If Not IsDBNull(rs("Created_By")) Then
                    lblCreatedBy.Text = rs("Created_By")
                End If
                lblDateCreated.Text = ""
                If Not IsDBNull(rs("Date_Created")) Then
                    lblDateCreated.Text = Format("mm/dd/YYYY", rs("Date_Created"))
                End If

                lblEncodedBy.Text = ""
                If Not IsDBNull(rs("Encoded_By")) Then
                    lblEncodedBy.Text = rs("Encoded_By")
                End If

                lblDateEncoded.Text = ""
                If Not IsDBNull(rs("Date_Created")) Then
                    lblDateEncoded.Text = Format("mm/dd/YYYY", rs("Date_Created"))
                End If

                lblUploadedBy.Text = ""
                If Not IsDBNull(rs("Uploaded_By")) Then
                    lblUploadedBy.Text = rs("Uploaded_By")
                End If

                lblDateUploaded.Text = ""
                If Not IsDBNull(rs("Date_Uploaded")) Then
                    lblDateUploaded.Text = Format("mm/dd/YYYY", rs("Date_Uploaded"))
                End If

                lblCatName.Text = ""

                cmRef.CommandText = "select Descr from dm_category where Category_Id=" & rs("Category_id")
                rsref = cmRef.ExecuteReader
                If rsref.Read Then
                    lblCatName.Text = rsref("Descr")
                End If
                rsref.Close()

                'If cmbStatus.SelectedValue = 11 Then
                '    cmRef.CommandText = "select Top 1 Status_Cd from dm_document_Notes where Doc_Id=" & Request.Item("id") & " order by Notes_Id Desc"
                '    rsref = cmRef.ExecuteReader
                '    If rsref.Read Then
                '        vOldStatus = rsref("Status_Cd")
                '    End If
                '    rsref.Close()
                'End If

                lblContractId.Text = rs("contract_id")
                lblContractDesc.Text = ""
                cmRef.CommandText = "select descr from dm_contract_type where type_cd=" & rs("contract_id")
                rsref = cmRef.ExecuteReader
                If rsref.Read Then
                    lblContractDesc.Text = rsref("descr")
                End If
                rsref.Close()

                cmRef.CommandText = "select AgencyName from agency where AgencyCd='" & rs("AgencyCd") & "'"
                rsref = cmRef.ExecuteReader
                If rsref.Read Then
                    lblCompany.Text = IIf(IsDBNull(rsref("AgencyName")), "", rsref("AgencyName"))
                End If
                rsref.Close()
                vDocSupp = rs("Supplier_Cd")

                '' ====================================================================================================================
                '' GET THE NEXT STEP BASE ON THE CURRENT STATUS
                '' ====================================================================================================================

                'cmRef.CommandText = "select NextTask from dm_process_dtl where AgencyCd ='" & rs("AgencyCd") & "' and status_cd =" & Request.Item("s")
                ''Response.Write(cmRef.CommandText)
                'Try
                '    rsref = cmRef.ExecuteReader
                '    If rsref.Read Then

                '        cmSub.CommandText = "select *, " & _
                '            "(select Descr from dm_document_status where dm_document_status.Status_Cd=dm_process_dtl.Status_Cd) as StatusName " & _
                '            "from dm_process_dtl where TaskId=" & rsref("NextTask")
                '        rsSub = cmSub.ExecuteReader
                '        Do While rsSub.Read

                '            If rsSub("SetResource") = 1 Then
                '                vAction += "<input name='cmdAssign' class='button' type='button' value='Assign to " & rsSub("StatusName") & "' " & _
                '                       "onclick='showassign(" & rsSub("Status_Cd") & ");' />"
                '            Else
                '                vAction += "<input type='button' class='button' name='cmd_" & rsSub("Status_Cd") & _
                '                       "'value='" & rsSub("StatusName") & "' onclick='OpenPOP(""" & _
                '                                           rsSub("Status_Cd") & """,""" & rsSub("StatusName") & """);' />"
                '            End If
                '        Loop
                '        rsSub.Close()

                '    End If
                '    rsref.Close()
                'Catch ex As SqlClient.SqlException

                'End Try

                ''    If IsDBNull(rs("PrevStatus")) Then
                ''        vPrevStatus = " PrevStatus_Cd Is null "
                ''    ElseIf rs("PrevStatus") = 0 Then
                ''        vPrevStatus = " PrevStatus_Cd Is null "
                ''    Else
                ''        vPrevStatus = " PrevStatus_Cd='" & rs("PrevStatus") & "'"
                ''    End If

                ''    If Not IsDBNull(rs("NextStatus")) Then

                ''        vActionList = rs("NextStatus").ToString.Split(",")
                ''        cmRef.CommandText = "select * from dm_process where Category_Id='" & lblCatId.Text & _
                ''            "' and " & vPrevStatus & " and Status_Cd='" & Request.Item("s") & "'"

                ''        'Response.Write(cmRef.CommandText)
                ''        rsref = cmRef.ExecuteReader
                ''        If rsref.Read Then
                ''            vActionType = rsref("IsAssign").ToString.Split(",")

                ''            For i = 0 To UBound(vActionList)

                ''                cmRSub.CommandText = "select * from dm_document_status where Status_Cd='" & vActionList(i) & "'"
                ''                rsRSub = cmRSub.ExecuteReader
                ''                Do While rsRSub.Read

                ''                    ' ====================================================================================================
                ''                    ' vActionType = 1 MEANING THIS STATUS NEED TO ASSIGN TO OTHER EMPLOYEE OR PROCESSOR
                ''                    ' ====================================================================================================
                ''                    If vActionType(i) = 1 Then
                ''                        vAction += "<input name='cmdAssign' class='button' type='button' value='Assign to " & rsRSub("Descr") & "' " & _
                ''                            "onclick='showassign(" & rsRSub("Status_Cd") & ");' />"
                ''                    Else
                ''                        vAction += "<input type='button' class='button' name='cmd_" & rsRSub("Status_Cd") & _
                ''                            "'value='" & rsRSub("Descr") & "' onclick='OpenPOP(""" & _
                ''                            rsRSub("Status_Cd") & """,""" & rsRSub("Descr") & """);' />"
                ''                    End If

                ''                Loop
                ''                rsRSub.Close()
                ''            Next i
                ''        End If
                ''        rsref.Close()
                ''    End If
            End If
            rs.Close()

            ' '' ====================================================================================================================
            ' '' COLLECT THE DOCUMENT KEYWORDS
            ' '' ====================================================================================================================
            ''cm.CommandText = "select Doc_Id, dm_document_dtl.Keyword_Id, dm_keywords.Descr, dm_keywords.Data_Type, Value,Alert_On, Alert_Before_Hrs " & _
            ''     "from dm_document_dtl,dm_keywords where dm_document_dtl.Keyword_Id=dm_keywords.Keyword_Id and " & _
            ''     "Doc_Id=" & Request.Item("id") & " order by Descr"
            ''rs = cm.ExecuteReader

            ''Do While rs.Read
            ''    If rs("Data_Type") = "NUMERIC" Then
            ''        vDocAmount = rs("Value").replace(",", "")
            ''    End If

            ''    'If rs("Keyword_Id") = "37" Then
            ''    '    vDocAmount = rs("Value").replace(",", "")
            ''    'End If

            ''    vkeywords += "<tr class='" & vclass & "'><td class='labelR' style='padding:3px'>" & rs("Descr") & " :</td>" & _
            ''                     "<td class='labelL' style='padding:3px'>" & rs("Value") & "</td>" '& _
            ''    vclass = IIf(vclass = "odd", "even", "odd")
            ''Loop
            ''rs.Close()

            ' ====================================================================================================================
            ' SHOW DOCUMENT TRANSACTION FROM START TO END
            ' ====================================================================================================================
            ''Dim vLength As Integer = 0
            ''Dim vCount As String = ""
            ' ''Dim vCode() As String

            ''cm.CommandText = "select Doc_Id, TranDate, Remarks, " & _
            ''    "(select SupplierName from supplier where supplier.SupplierCd=dm_ledger.Supplier_Cd) as CompName, " & _
            ''    "(select Descr from dm_category where dm_category.Category_Id=dm_ledger.Category_Cd) as CatName, " & _
            ''    "(select Descr from dm_document_status where dm_document_status.Status_Cd=dm_ledger.Status_Cd) as StatusName, " & _
            ''    "(select SubAttachment from dm_document where dm_document.Doc_Id=dm_ledger.Doc_Id) as SubAttachment, " & _
            ''    "(select FullName from user_list where user_list.User_Id=dm_ledger.CreatedBy ) as User1, " & _
            ''    "(select FullName from user_list where user_list.User_Id=dm_ledger.IsAssignTo ) as User2 " & _
            ''    "from dm_ledger where Doc_Id=" & Request.Item("id") & " order by TranDate"

            ''rs = cm.ExecuteReader
            ''Do While rs.Read

            ''    vNotes += "<tr class='" & vclass & "'>" & _
            ''         "<td class='labelBL' style='padding:3px'>" & rs("Remarks") & "</td>" & _
            ''         "<td class='labelBL' style='padding:3px'>" & rs("StatusName") & "</td>" & _
            ''         "<td class='labelBL' style='padding:3px'>" & rs("User1") & "</td>" & _
            ''         "<td class='labelBL' style='padding:3px'>" & IIf(IsDBNull(rs("User2")), "", rs("User2")) & "</td>" & _
            ''         "<td class='labelBC' style='padding:3px'>" & Format(rs("TranDate"), "MM-dd-yyyy HH:mm") & "</td>" ' " & _

            ''    '"<td class='labelBC' style='padding:3px'>"

            ''    'If Not IsDBNull(rs("SubAttachment")) Then
            ''    '    vLength = rs("SubAttachment").Length
            ''    '    vCount = rs("SubAttachment").Substring(0, vLength - 1)
            ''    '    vCode = vCount.Split(",")

            ''    '    For x As Integer = 0 To vCode.Length - 1
            ''    '        vNotes += "<a class='linkmenu' href=""javascript:show('" & vCode(x) & "')"">" & vCode(x) & "</a>"
            ''    '    Next
            ''    'End If

            ''    'vNotes += "</td></tr>"
            ''    vNotes += "</tr>"
            ''    vclass = IIf(vclass = "odd", "even", "odd")
            ''Loop
            ''rs.Close()


        Catch ex As SqlClient.SqlException
            vscript = "alert('An error occur while trying to access the database.  Error is: " & _
                      ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            c.Dispose()
            cm.Dispose()
            cmRef.Dispose()
            cmSub.Dispose()
        End Try
    End Sub

    Public Sub BuildTaskOption()
        ' ====================================================================================================================
        ' GET THE NEXT STEP BASE ON THE CURRENT STATUS
        ' ====================================================================================================================
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cmRef As New SqlClient.SqlCommand
        Dim cmSub As New SqlClient.SqlCommand

        Dim rsref As SqlClient.SqlDataReader
        Dim rsSub As SqlClient.SqlDataReader
        Dim attachments() As String

        cmRef.Connection = c
        cmSub.Connection = c
        c.Open()

        cmRef.CommandText = "select SubAttachment from dm_document where Doc_Id=" & Request.Item("id")
        rsref = cmRef.ExecuteReader
        If rsref.Read Then
            If Not IsDBNull(rsref("SubAttachment")) Then
                txtSubAtt.Value = rsref("SubAttachment")
                attachments = rsref("SubAttachment").ToString.Split("|")
                For i = 0 To UBound(attachments) - 1
                    SubAttachment += "<a href='' class='textLinks' onclick='OpenSubAtt(""" & attachments(i) & """);'>" & attachments(i) & "</a><br>"
                Next i
            End If
        End If
        rsref.Close()

        cmRef.CommandText = "select NextTask from dm_process_dtl where AgencyCd ='" & lblCompCd.Text & "' and status_cd =" & Request.Item("s")
        Try
            rsref = cmRef.ExecuteReader
            If rsref.Read Then

                cmSub.CommandText = "select *, " & _
                    "(select Descr from dm_document_status where dm_document_status.Status_Cd=dm_process_dtl.Status_Cd) as StatusName " & _
                    "from dm_process_dtl where TaskId=" & rsref("NextTask")
                rsSub = cmSub.ExecuteReader
                Do While rsSub.Read

                    If rsSub("SetResource") = 1 Then
                        vAction += "<input name='cmdAssign' class='button' type='button' value='Assign to " & rsSub("StatusName") & "' " & _
                               "onclick='showassign(" & rsSub("Status_Cd") & ");' />"
                    Else
                        vAction += "<input type='button' class='button' name='cmd_" & rsSub("Status_Cd") & _
                               "'value='" & rsSub("StatusName") & "' onclick='OpenPOP(""" & _
                                                   rsSub("Status_Cd") & """,""" & rsSub("StatusName") & """);' />"
                    End If
                Loop
                rsSub.Close()
            End If
            rsref.Close()
        Catch ex As SqlClient.SqlException

        End Try
        c.Close()
        c.Dispose()
        cmRef.Dispose()
        cmSub.Dispose()
    End Sub

    Private Sub GetSub_Keywords()
        vscript = "document.getElementById('trans').style.visibility = 'visible'; document.getElementById('pnlValidate').style.visibility = 'visible';"
        cmdSave.Text = txtSelectedStatusName.Value

        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cmRef As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim rsRef As SqlClient.SqlDataReader
        Dim vSelected As String = ""
        Dim vKeyList As String = ""

        c.Open()
        cm.Connection = c
        cmRef.Connection = c

        cm.CommandText = "select Keyword_Id, SetResource, " & _
            "(select Descr from dm_keywords where dm_category_property.Keyword_Id=dm_keywords.Keyword_Id)  as Descr, " & _
            "(select Data_Type from dm_keywords where dm_category_property.Keyword_Id=dm_keywords.Keyword_Id) as DataType " & _
            "from dm_category_property where Category_Id=" & lblCatCd.Text & " and StatusCd=" & txtSelectedStatus.Value & " and Type=0 order by SeqId"

        rs = cm.ExecuteReader
        Do While rs.Read
            Select Case rs("DataType")

                Case "STRING", "NUMERIC"
                    vDumpKeywords += "<tr><td class='labelR'>" & rs("Descr") & _
                        " : </td><td><input class='label' type='text' style='width: 220px;' name='" & _
                        Val(rs("Keyword_Id")) & "' id='" & Val(rs("Keyword_Id")) & _
                        "' /></td></tr>"

                Case "LIST"
                    vDumpKeywords += "<tr><td class='labelR'>" & rs("Descr") & " : </td>"
                    vDumpKeywords += "<td><select class='labelL' id='" & rs("Keyword_Id") & "' name='" & rs("Keyword_Id") & "' runat='server' style='width:226px;'>"

                    cmRef.CommandText = rs("SetResource")
                    'Response.Write(rs("SetResource"))
                    rsRef = cmRef.ExecuteReader
                    Do While rsRef.Read
                        vDumpKeywords += "<option value='" & rsRef("vID") & "'  >" & rsRef("vDescr") & "</option>"
                    Loop
                    rsRef.Close()
                    vDumpKeywords += "</td></tr>"

                Case "DATE"

                    vDumpKeywords += "<tr><td class='labelR'>" & rs("Descr") & _
                        " : </td><td><input class='labelC' type='text' style='width: 80px;' maxlength='10' name='" & _
                        Val(rs("Keyword_Id")) & "' id='" & Val(rs("Keyword_Id")) & _
                        "' value='" & Format(Now, "MM/dd/yyyy") & "'/>&nbsp;" & _
                        "<select class='labelL' name='" & Val(rs("Keyword_Id")) & "_hh' id='" & Val(rs("Keyword_Id")) & "_hh'>" 'onFocus='showCalendarControl(this);' readonly='readonly' 

                    For i As Integer = 0 To 11
                        If Format(Val(i), "00") = Hour(Now()) Then
                            vSelected = "Selected='Selected'"
                        End If
                        vDumpKeywords += "<option " & vSelected & " >" & Format(Val(i), "00") & "</option>"
                    Next

                    vDumpKeywords += "</select><select class='labelL' name='" & _
                        Val(rs("Keyword_Id")) & "_mm' id='" & Val(rs("Keyword_Id")) & "_mm'>"

                    For i As Integer = 0 To 59
                        vDumpKeywords += "<option>" & Format(Val(i), "00") & "</option>"
                    Next

                    vDumpKeywords += "</select><select class='labelL' name='" & _
                        Val(rs("Keyword_Id")) & "_am' id='" & Val(rs("Keyword_Id")) & "_am'>" & _
                            "<option>AM</option><option>PM</option>" & _
                            "</select></td></tr>"

                Case "TIME"
                    vDumpKeywords += "<tr><td class='labelR'>" & rs("Descr") & _
                        ":</td><td><input class='label' type='text' style='width: 150px;' maxlength='7' name='" & _
                        Val(rs("Keyword_Id")) & "' id='" & Val(rs("Keyword_Id")) & "' />&nbsp;&nbsp;&nbsp;hh:mm </td></tr>"
                Case "TEXTAREA"
                    vDumpKeywords += "<tr><td class='labelR' valign='top'>" & rs("Descr") & _
                        ":</td><td><textarea class='labelL' style='width: 222px;' rows='2' name='" & _
                            Val(rs("Keyword_Id")) & "' id='" & Val(rs("Keyword_Id")) & "' ></textarea></td></tr>"

                Case "YES/NO"
                    vDumpKeywords += "<tr><td class='labelR'>" & rs("Descr") & " : </td><td><input type='checkbox' name='" & _
                        Val(rs("Keyword_Id")) & "' id='" & Val(rs("Keyword_Id")) & "' /></td></tr>"
            End Select

        Loop

        rs.Close()
        c.Close()
        c.Dispose()
        cm.Dispose()

    End Sub

    Protected Sub btnProperties_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnProperties.Click
        Panel2.Visible = False
        Panel3.Visible = True
        Panel4.Visible = False

        btnGeneral.CssClass = "MenuTabs"
        btnProperties.CssClass = "MenuTabs_Selected"
        btnNotes.CssClass = "MenuTabs"
        txtSelectedStatus.Value = ""
        txtSelectedStatusName.Value = ""
        vscript = "document.getElementById('trans').style.visibility = 'hidden'; document.getElementById('pnlValidate').style.visibility = 'hidden';"

        ' ====================================================================================================================
        ' COLLECT THE DOCUMENT KEYWORDS
        ' ====================================================================================================================
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cmRef As New SqlClient.SqlCommand
        Dim cmSub As New SqlClient.SqlCommand
        Dim vDocAmount As String = ""
        Dim rs As SqlClient.SqlDataReader
        Dim rsref As SqlClient.SqlDataReader

        cm.Connection = c
        cmRef.Connection = c
        c.Open()

        cm.CommandText = "select Doc_Id, dm_document_dtl.Keyword_Id, dm_keywords.Descr, dm_keywords.Data_Type, " & _
            "Value, CmdType, FieldName, TableName, FieldKey " & _
             "from dm_document_dtl,dm_keywords where dm_document_dtl.Keyword_Id=dm_keywords.Keyword_Id and " & _
             "Doc_Id=" & Request.Item("id") & " order by Descr"
        rs = cm.ExecuteReader
        Do While rs.Read
            If rs("Data_Type") = "NUMERIC" Then
                vDocAmount = rs("Value").replace(",", "")
            End If

            vkeywords += "<tr class='" & vclass & "'><td class='labelR' style='padding:3px'>" & rs("Descr") & " :</td>"

            If Not IsDBNull(rs("CmdType")) Then
                cmRef.CommandText = rs("CmdType") & " " & rs("FieldName") & " from " & rs("TableName") & " where " & rs("FieldKey") & "='" & rs("Value") & "'"
                rsref = cmRef.ExecuteReader

                If rsref.Read Then
                    vkeywords += "<td class='labelL' style='padding:3px'>" & rsref(rs("FieldName")) & "</td>"
                    vclass = IIf(vclass = "odd", "even", "odd")
                End If
                rsref.Close()

            Else
                vkeywords += "<td class='labelL' style='padding:3px'>" & rs("Value") & "</td>"
                vclass = IIf(vclass = "odd", "even", "odd")
            End If
        Loop

        rs.Close()
        c.Close()
        c.Dispose()
        cm.Dispose()
        cmRef.Dispose()

    End Sub

    Protected Sub btnGeneral_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnGeneral.Click
        Panel2.Visible = True
        Panel3.Visible = False
        Panel4.Visible = False
        btnGeneral.CssClass = "MenuTabs_Selected"
        btnProperties.CssClass = "MenuTabs"
        btnNotes.CssClass = "MenuTabs"

        GetDoc_MasterDetails()
        'BuildTaskOption()
    End Sub

    Protected Sub btnNotes_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnNotes.Click
        Panel2.Visible = False
        Panel3.Visible = False
        Panel4.Visible = True
        btnGeneral.CssClass = "MenuTabs"
        btnProperties.CssClass = "MenuTabs"
        btnNotes.CssClass = "MenuTabs_Selected"
        txtSelectedStatus.Value = ""
        txtSelectedStatusName.Value = ""
        vscript = "document.getElementById('trans').style.visibility = 'hidden'; document.getElementById('pnlValidate').style.visibility = 'hidden';"

        ' ====================================================================================================================
        ' SHOW DOCUMENT TRANSACTION FROM START TO END
        ' ====================================================================================================================
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
   
        cm.Connection = c
        c.Open()

        Dim vLength As Integer = 0
        Dim vCount As String = ""

        cm.CommandText = "select Doc_Id, TranDate, Remarks, " & _
            "(select SupplierName from supplier where supplier.SupplierCd=dm_ledger.Supplier_Cd) as CompName, " & _
            "(select Descr from dm_category where dm_category.Category_Id=dm_ledger.Category_Cd) as CatName, " & _
            "(select Descr from dm_document_status where dm_document_status.Status_Cd=dm_ledger.Status_Cd) as StatusName, " & _
            "(select SubAttachment from dm_document where dm_document.Doc_Id=dm_ledger.Doc_Id) as SubAttachment, " & _
            "(select FullName from user_list where user_list.User_Id=dm_ledger.CreatedBy ) as User1, " & _
            "(select FullName from user_list where user_list.User_Id=dm_ledger.IsAssignTo ) as User2 " & _
            "from dm_ledger where Doc_Id=" & Request.Item("id") & " order by TranDate"

        rs = cm.ExecuteReader
        Do While rs.Read

            vNotes += "<tr class='" & vclass & "'>" & _
                 "<td class='labelBL' style='padding:3px'>" & rs("Remarks") & "</td>" & _
                 "<td class='labelBL' style='padding:3px'>" & rs("StatusName") & "</td>" & _
                 "<td class='labelBL' style='padding:3px'>" & rs("User1") & "</td>" & _
                 "<td class='labelBL' style='padding:3px'>" & IIf(IsDBNull(rs("User2")), "", rs("User2")) & "</td>" & _
                 "<td class='labelBC' style='padding:3px'>" & Format(rs("TranDate"), "MM-dd-yyyy HH:mm") & "</td>" ' " & _

            vNotes += "</tr>"
            vclass = IIf(vclass = "odd", "even", "odd")
        Loop
        rs.Close()
        c.Close()
        c.Dispose()
        cm.Dispose()
        
    End Sub

    Protected Sub btnPreview_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnPreview.Click
        Dim vFile As String = ""
        Dim c As New sqlclient.sqlConnection(connStr)
        Dim cm As New sqlclient.sqlCommand
        Dim rs As sqlclient.sqlDataReader

        c.Open()
        cm.Connection = c
        cm.CommandText = "select Uploaded_Path from dm_document where Doc_Id=" & Request.Item("id")
        rs = cm.ExecuteReader
        If rs.Read Then
            If Not IsDBNull(rs("Uploaded_Path")) Then
                vFile = rs("Uploaded_Path")
            End If
        End If
        rs.Close()

        c.Close()
        c.Dispose()
        cm.Dispose()

        If vFile <> "" Then
            'vscript = "winpreview=window.open('http://" & Server.MachineName & "/" & vFile.ToLower & _
            'vscript = "winpreview=window.open('http://" & System.Configuration.ConfigurationManager.AppSettings.Get("ServerIp") & "/" & vFile.ToLower & _
            '    "',""preview"",""width=800,height=600,top=10,left=10,toolbars=no,resizable=yes""); winpreview.focus();"

            vscript = "showDoclist(""" & vFile.ToLower & """);"
        Else
            vscript = "alert('No Attached document to view.');"
        End If
        'BuildTaskOption()
    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand("select UserPassword from user_list where User_Id='test'", c)

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vscript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "'); window.close();"

            c.Close()
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        Select Case txtSelectedStatus.Value
            Case 10 ' FOR REVIEW AND POSTING
                
                If txtDueDate.Text.Trim = "" Then
                    vscript = "alert('Please enter Due Date.'); OpenPOP(""" & txtSelectedStatus.Value & """, """ & txtSelectedStatusName.Value & """);"
                    Exit Sub
                End If

                If txtSDNo.Text.Trim = "" Then
                    vscript = "alert('Please enter SAP Number.'); OpenPOP(""" & txtSelectedStatus.Value & """, """ & txtSelectedStatusName.Value & """);"
                    Exit Sub
                End If

            Case 28 ' FOR BATCH UPLOADING 
                If txtVCNo.Text.Trim = "" Then
                    vscript = "alert('Please enter Vendor Clearing No.'); OpenPOP(""" & txtSelectedStatus.Value & """, """ & txtSelectedStatusName.Value & """);"
                    Exit Sub
                End If

            Case 29 ' FOR BANK CLEARING NO.
                If txtBCNo.Text.Trim = "" Then
                    vscript = "alert('Please enter Batch Clearing No.'); OpenPOP(""" & txtSelectedStatus.Value & """, """ & txtSelectedStatusName.Value & """);"
                    Exit Sub
                End If

        End Select
        SaveTransaction(c, txtSelectedStatus.Value, Session("uid"))
        SaveSubKeywords()

        vscript = "window.opener.document.form1.txtReload.value='Reload';  window.opener.document.form1.submit();  window.close();"
    End Sub

    Private Sub SaveTransaction(ByRef c As SqlClient.SqlConnection, ByVal pMode As Integer, _
                          ByVal pAccountability As String, Optional ByVal pReason As String = "")

        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader

        Dim cmSrc As New SqlClient.SqlCommand
        Dim rsSrc As SqlClient.SqlDataReader

        Dim vDuration As Single = 0
        Dim vDateStart As Date
        Dim vGRno As String = ""

        cm.Connection = c
        cmSrc.Connection = c

        'save a copy to the documents notes
        cmSrc.CommandText = "select * from dm_document where Doc_Id=" & Request.Item("id")
        Try
            rsSrc = cmSrc.ExecuteReader

            If rsSrc.Read Then
                vDateStart = rsSrc("Date_Encoded")
                If Not IsDBNull(rsSrc("Date_Assigned")) Then
                    vDateStart = CDate(rsSrc("Date_Assigned"))
                End If

                vDuration = Math.Round(DateDiff(DateInterval.Minute, vDateStart, Now) / 60, 2)
                cm.CommandText = "insert into dm_document_notes (Doc_Id, Notes, Date_Encoded, Encoded_By, Emp_Cd," & _
                        "Date_Start,Date_Finish,Duration,Status_Cd) values (" & rsSrc("Doc_Id") & ",'" & _
                        IIf(IsDBNull(rsSrc("Contents")), "For Review", rsSrc("Contents")) & "','" & _
                        Format(CDate(rsSrc("Date_Encoded")), "yyyy/MM/dd HH:mm:ss") & "','" & _
                        rsSrc("Encoded_By") & "','" & IIf(IsDBNull(rsSrc("Emp_Cd")), rsSrc("Encoded_By"), rsSrc("Emp_Cd")) & _
                        "','" & Format(vDateStart, "yyyy/MM/dd HH:mm:ss") & _
                        "','" & Format(Now, "yyyy/MM/dd HH:mm:ss") & "'," & vDuration & "," & rsSrc("Status_Cd") & ")"
                cm.ExecuteNonQuery()

                'insert to lance table dm_ledger
                'cm.CommandText = "insert into dm_ledger (Doc_ID, Status_Cd, Category_Cd, TranDate, CreatedBy, Supplier_Cd, Remarks, AgencyCd) " & _
                '        "values (" & rsSrc("Doc_Id") & ", " & pMode & ", " & rsSrc("Category_Id") & ", '" & _
                '        Format(Now, "yyyy/MM/dd HH:mm:ss") & "', '" & lblEmpCd.Text & "', " & rsSrc("Supplier_Cd") & ", '" & _
                '        IIf(pReason = "", "", pReason & " | ") & txtNotes.Text & "','" & rsSrc("AgencyCd") & "' )"
                'cm.ExecuteNonQuery()

                '=============================================================================================================================================
                ' VALIDATE DM_PROCESS IF THE SELECTED STATUS IS THE LAST PROCESS
                ' GET THE NEXT STATUS BASE ON THE SELECTED STATUS
                '=============================================================================================================================================
                Dim vPosted As String = ""
                Dim vNextStatus As String = ""

                cm.CommandText = "select * from dm_process where Category_Id='" & rsSrc("Category_Id") & _
                    "' and PrevStatus_Cd='" & rsSrc("Status_Cd") & "' and Status_Cd='" & pMode & "' "
                'Response.Write(cm.CommandText)

                rs = cm.ExecuteReader
                If rs.Read Then
                    'vPosted = IIf(IsDBNull(rs("EndProcess")), "", ",Posted=1")
                    vNextStatus = IIf(IsDBNull(rs("NextStep")), ",NextStatus=null", ",NextStatus='" & rs("NextStep") & "'")
                End If
                rs.Close()

                ' =============================================================================================================================================
                ' OLD CODE FROM DTS VERTEX ONE
                ' =============================================================================================================================================
                ' now update the record
                ' cm.CommandText = "update dm_document set DateModify='" & Now() & "', ModifyBy='" & Session("uid") & _
                '    "', Contents='" & IIf(pReason = "", "", pReason & " |") & " due to: " & txtNotes.Text & _
                '    "',PrevStatus=Status_Cd,Status_Cd=" & pMode & " " & vNextStatus & ",Emp_Cd='" & _
                '    pAccountability & "', " & vGRno & _
                '    " Date_Assigned='" & Format(Now, "yyyy/MM/dd HH:mm:ss") & "', LineItem=" & _
                '    IIf(txtLineItem.Text = "", "null", txtLineItem.Text) & ",Sap_Number=" & _
                '    IIf(txtSAPNo.Text = "", "null", "'" & txtSAPNo.Text & "'") & " " & vPosted & _
                '    " where Doc_Id=" & rsSrc("Doc_Id")
                '
                ' =============================================================================================================================================
                ' NEW CODE FOR DTS BPO ORTIGAS
                ' =============================================================================================================================================

                cm.CommandText = "update dm_document set " & _
                    "DateModify='" & Now() & "', " & _
                    "ModifyBy='" & Session("uid") & "', " & _
                    "Contents='" & IIf(pReason = "", "", pReason & " |") & " due to: " & txtNotes.Text & "'," & _
                    "PrevStatus=Status_Cd, Status_Cd=" & pMode & " " & vNextStatus & "," & _
                    "Emp_Cd='" & pAccountability & "'," & _
                    "Date_Assigned='" & Format(Now, "yyyy/MM/dd HH:mm:ss") & "', " & _
                    "DueDate=" & IIf(txtDueDate.Text.Trim = "", "null", "'" & txtDueDate.Text.Trim & "'") & "," & _
                    "VendorClearingNo=" & IIf(txtVCNo.Text.Trim = "", "null", "'" & txtVCNo.Text.Trim & "'") & "," & _
                    "BatchClearingNo=" & IIf(txtBCNo.Text.Trim = "", "null", "'" & txtBCNo.Text.Trim & "'") & "," & _
                    "Sap_Number=" & IIf(txtSDNo.Text.Trim = "", "null", "'" & txtSDNo.Text.Trim & "'") & " " & _
                    "where Doc_Id=" & rsSrc("Doc_Id")
                cm.ExecuteNonQuery()
            End If
            rsSrc.Close()
             
        Catch ex As SqlClient.SqlException
            vscript = "alert('Error occurred while trying to save changes. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            cm.Dispose()
            cmSrc.Dispose()
        End Try

        'vscript = "alert('Changes were successfully saved.');"

    End Sub

    Private Sub SaveSubKeywords()
        Dim c As New SqlClient.SqlConnection(connStr)

        Dim cm As New SqlClient.SqlCommand
        Dim cm_sub As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader

        Dim vDoc_Id As String = Request.Item("id")
        Dim vDate As Date

        c.Open()
        cm.Connection = c
        cm_sub.Connection = c

        ' =============================================================================================================================================
        ' UPDATE SUB KEYWORDS
        ' =============================================================================================================================================
        Dim vKey As String = ""
        Dim vSQL As String = ""
        Dim vAssignTo As String = ""

        cm.CommandText = "select *, " & _
            "(select Descr from dm_keywords where dm_category_property.Keyword_Id=dm_keywords.Keyword_Id)  as Descr, " & _
            "(select Data_Type from dm_keywords where dm_category_property.Keyword_Id=dm_keywords.Keyword_Id) as DataType " & _
            "from dm_category_property where Category_Id=" & lblCatCd.Text & " and StatusCd=" & txtSelectedStatus.Value & " and Type=0 order by SeqId"

        rs = cm.ExecuteReader
        Do While rs.Read

            cm.CommandText = "delete from dm_document_dtl where Doc_Id=" & vDoc_Id & " and Keyword_Id=" & rs("keyword_id")
            Response.Write(cm.CommandText)
            'cm.ExecuteNonQuery()

            vSQL = "insert into dm_document_dtl (Doc_Id, Keyword_Id, Value, " & _
                            "Alert_Before_Hrs, EmailAlert, EmailFrequency, EmailFrequencyCount ) "
            vKey = rs("keyword_id")

            Select Case rs("DataType")
                Case "STRING", "NUMERIC", "TIME"
                    vSQL += " values ('" & vDoc_Id & "', " & rs("keyword_id") & ", '" & Request.Form(vKey) & "', 0,0,0,0)"
                Case "LIST"

                    If Not IsDBNull(rs("CmdType")) Then
                        cm_sub.CommandText = rs("CmdType") & " " & rs("TableName") & " set " & rs("FieldName") & "='" & Request.Form(rs("keyword_id").ToString) & "' where " & rs("FieldKey") & "=" & vDoc_Id
                        cm_sub.ExecuteNonQuery()
                        vAssignTo = Request.Form(rs("keyword_id").ToString)
                    End If

                    vSQL += " values ('" & vDoc_Id & "', " & rs("keyword_id") & ", '" & Request.Form(rs("keyword_id").ToString) & "', 0,0,0,0)"
                Case "DATE"
                    If Request.Form(vKey) <> "" Then
                        vDate = Format(CDate(Request.Form(vKey)), "yyyy/MM/dd") & " " & Request.Form(vKey & "_hh") & ":" & _
                            Request.Form(vKey & "_mm") & ":00 " & Request.Form(vKey & "_am")

                        vSQL += " values ('" & vDoc_Id & "', " & rs("keyword_id") & ", '" & _
                            vDate & "', 0,0,0,0)"
                    Else
                       vSQL += " values ('" & vDoc_Id & "', " & rs("keyword_id") & ", '', 0,0,0,0)"
                    End If
                Case "TEXTAREA"
                   vSQL += " values ('" & vDoc_Id & "', " & rs("keyword_id") & ", '" & Request.Form(vKey) & "', 0,0,0,0)"
                Case "YES/NO"
            End Select

            cm_sub.CommandText = vSQL
            cm_sub.ExecuteNonQuery()

        Loop
        rs.Close()

        cm.CommandText = "insert into dm_ledger (Doc_ID, Status_Cd, Category_Cd, TranDate, CreatedBy, Supplier_Cd, Remarks, AgencyCd, IsAssignTo) " & _
            "values (" & vDoc_Id & ", " & txtSelectedStatus.Value & ", " & lblCatCd.Text & ", '" & _
            Format(Now, "yyyy/MM/dd HH:mm:ss") & "','" & lblEmpCd.Text & "','" & lblSupCd.Text & "', '" & _
            IIf(lblCNotes.Text = "", "", lblCNotes.Text & " | ") & txtNotes.Text & "','" & lblCompCd.Text & "', '" & vAssignTo & "' )"
        cm.ExecuteNonQuery()

        c.Close()
        c.Dispose()
        cm.Dispose()
        cm_sub.Dispose()

    End Sub

    Protected Sub btnDocHistory_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnDocHistory.Click
        vscript = "showOldRecord(""" & Request.Item("id") & """);"
    End Sub

    Protected Sub btnSubAttachment_Click(sender As Object, e As EventArgs) Handles btnSubAttachment.Click
        vscript = "showSubAtt(""" & Request.Item("id") & """);"
        'BuildTaskOption()
    End Sub
End Class
