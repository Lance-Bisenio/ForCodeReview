﻿Imports denaro.fis
Partial Class queryresult
    Inherits System.Web.UI.Page
    Public qryresults As String = ""
    Public vscript As String = ""
    Public vaddcols As String = ""


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim vcols As Integer = 0
        Dim i As Integer = 0
        Dim cols() As String
        Dim addcols As String = ""
        Dim vcolmain As String = ""
        Dim vcolumnmain() As String
        Dim vcolkeyword As String = ""
        Dim vkeywordmain() As String
        Dim tmpcols As String = ""
        Dim test As String = ""

        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If
        'If Session("cols") <> "" Then
        'tmpcols = Session("cols") & IIf(Session("cols").ToString.LastIndexOf(Session("keywordscolumns")) < 1, Session("keywordscolumns"), "")
        'End If
        tmpcols = Session("cols")

        'Response.Write("main cols:" & Session("cols") & " temcols:" & tmpcols & " keywords:" & Session("keywordscolumns"))

        If Session("cols") <> "" Then

            Dim start As Integer = tmpcols.ToString.LastIndexOf("|")
            'Response.Write(start)
            vcolmain = tmpcols.ToString.Substring(0, IIf(start > 0, start - 1, 0))

            Dim eend As String = tmpcols.ToString.Replace(IIf(vcolmain = "", "|,", vcolmain & ",|,"), "")

            vcolkeyword = eend

            'vcolkeyword = tmpcols.ToString.Remove(0, start)

            'Response.Write("session cols:" & Session("cols") & " main colu:" & vcolmain & " sec colum:" & eend)

            ''Response.Write(" Keyword Col:" & vcolkeyword)
            cols = Session("colsdescr").ToString.Split(",")
            For vcols = 0 To UBound(cols)
                vaddcols += "<th class='labelC'>" & cols(vcols) & "</th>"
            Next
        End If

        Dim c As New SqlClient.SqlConnection
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader

        Dim cmRef As New SqlClient.SqlCommand
        Dim rsRef As SqlClient.SqlDataReader
        Dim vCtr As Integer = 1
        Dim vTeam As String = ""
        Dim vProcessor As String = ""
        'varray(0) = "Category_Id"
        'varray(1) = "Location_Id"

        Dim vclass As String = "odd"

        c.ConnectionString = connStr
        cm.Connection = c
        cmRef.Connection = c
        If vcolmain <> "" Then


            cm.CommandText = "select Doc_Id " & _
                         IIf(vcolmain <> "", "," & vcolmain, "") & " from dm_document " & Session("qryresults") & " order by Doc_Name"
        Else
            'Standard query

            If Session("qryresults") = "" Then
                Session("qryresults") = " where Date_Uploaded between '" & Format(Now, "yyyy-dd-MM") & " 00:00:00' and '" & Format(Now, "yyyy-dd-MM") & " 23:59:59'"
            End If

            cm.CommandText = "select Doc_Id,Doc_Name,Uploaded_Path,Date_Uploaded,Date_Assigned," & _
                            "(select SupplierName from supplier where supplier.SupplierCd=dm_document.Supplier_Cd) as SuppName, " & _
                            "(select Descr from dm_document_status where dm_document_status.Status_Cd=dm_document.Status_Cd) as StatusName, " & _
                            "(select FullName from user_list where user_list.User_Id=dm_document.Emp_Cd) as FullName, " & _
                            "(select Descr from dm_category where dm_category.Category_Id=dm_document.Category_Id) as CatName, " & _
                             "Created_By,Encoded_By,Date_Encoded" & _
                             IIf(vcolmain <> "", "," & vcolmain, "") & " from dm_document " & Session("qryresults") & " order by Doc_Name"

            'Response.Write(cm.CommandText & " => " & Session("qryresults"))
        End If

        'Response.Write(cm.CommandText)
        Try
            c.Open()
            rs = cm.ExecuteReader
            Do While rs.Read
                vTeam = ""
                vProcessor = ""

                cmRef.CommandText = "select top 1 Doc_Id, " & _
                "(select FullName from user_list where user_list.User_Id=dm_ledger.CreatedBy ) as User1, " & _
                "(select FullName from user_list where user_list.User_Id=dm_ledger.IsAssignTo ) as User2 " & _
                "from dm_ledger where Doc_Id='" & rs("Doc_Id") & "' and IsAssignTo is not null order by TranNo Desc"
                rsRef = cmRef.ExecuteReader

                If rsRef.Read Then
                    vTeam = IIf(IsDBNull(rsRef("User1")), "", rsRef("User1"))
                    vProcessor = IIf(IsDBNull(rsRef("User2")), "", rsRef("User2"))
                End If
                rsRef.Close()


                qryresults += "<tr class='" & vclass & "'><td class='labelBC'>" & vCtr & "</td>" & _
                                  "<td class='linkstyle-z' style='padding:5px; cursor:pointer;' title='Click here to view Details' onclick=openlink('" & rs("Doc_Id") & "'); style='text-decoration:underline;padding:2px;cursor:pointer;'>" & _
                                   rs("Doc_Id") & "</td>"

                If vcolmain = "" Then
                    
                    vaddcols = "<th class='labelBC' style='width:100px;'>Date Received</th>" & _
                        "<th class='labelBC' style='width:150px;'>Doc Name</th>" & _
                        "<th class='labelBC' style='width:150px;'> Company</th>" & _
                        "<th class='labelBC' style='width:100px;'>Category</th>" & _
                        "<th class='labelBC' style='width:150px;'>Doc. Status</th>" & _
                        "<th class='labelBC' style='width:100px;'>Date Posted</th>" & _
                        "<th class='labelBC' style='width:100px;'>Team Leader</th>" & _
                        "<th class='labelBC' style='width:100px;'>Processor</th>"


                    qryresults += "<td class='labelBC' style='padding:5px;'>" & Format(rs("Date_Uploaded"), "MM/dd/yy HH:mm") & "</td>" & _
                        "<td class='labelBL' style='padding:5px;'>" & rs("Doc_Name") & "</td>" & _
                        "<td class='labelBL' style='padding:5px;'>" & rs("SuppName") & "</td>" & _
                        "<td class='labelBL' style='padding:5px;'>" & rs("CatName") & "</td>" & _
                        "<td class='labelBL' style='padding:5px;'>" & rs("StatusName") & "</td>" & _
                        "<td class='labelBC' style='padding:5px;'>" & rs("Date_Assigned") & "</td>" & _
                        "<td class='labelBL' style='padding:5px;'>" & vTeam & "</td>" & _
                        "<td class='labelBL' style='padding:5px;'>" & vProcessor & "</td>"


                End If


                If vcolmain <> "" Then

                    vcolumnmain = vcolmain.Split(",")
                    For vcols = 0 To UBound(vcolumnmain)
                        If vcolumnmain(vcols) = "Status_Cd" Then

                            cmRef.CommandText = "select Descr from dm_document_status where Status_Cd=" & rs("" & vcolumnmain(vcols) & "")

                            'Response.Write(cmRef.CommandText)
                            rsRef = cmRef.ExecuteReader
                            If rsRef.Read Then
                                qryresults += "<td class='labelBL' style='padding:5px; width:100px;'>" & _
                                            IIf(IsDBNull(rsRef("Descr")), "", rsRef("Descr")) & "</td>"

                            End If
                            rsRef.Close()
                            'cmRef.Dispose()

                        ElseIf vcolumnmain(vcols) = "Category_Id" Then
                            'cmRef.Connection = c
                            cmRef.CommandText = "select Descr from dm_category where Category_Id=" & rs("" & vcolumnmain(vcols) & "")
                            rsRef = cmRef.ExecuteReader
                            If rsRef.Read Then
                                qryresults += "<td class='labelBL' style='padding:5px; width:100px;'>" & _
                                            IIf(IsDBNull(rsRef("Descr")), "", rsRef("Descr")) & "</td>"

                            End If
                            rsRef.Close()
                            'cmRef.Dispose()
                        Else
                            qryresults += "<td class='labelBL' style='padding:5px;'>" & _
                            IIf(IsDBNull(rs("" & vcolumnmain(vcols) & "")), "", rs("" & vcolumnmain(vcols) & "")) & "</td>"
                        End If
                    Next vcols
                End If

                If vcolkeyword <> "" Then

                    vkeywordmain = vcolkeyword.Split(",")
                    For vcols = 0 To UBound(vkeywordmain) - 1
                        'cmRef.Connection = c
                        cmRef.CommandText = "select Value from dm_document_dtl where Doc_Id=" & rs("Doc_Id") & _
                                            " and Keyword_Id=" & vkeywordmain(vcols)
                        'Response.Write(cmRef.CommandText)
                        rsRef = cmRef.ExecuteReader
                        If rsRef.Read Then
                            qryresults += "<td class='labelBL' style='padding:5px;'>" & rsRef("Value") & "</td>"
                        Else
                            qryresults += "<td class='labelBL' style='padding:5px;'>&nbsp;</td>"
                        End If
                        rsRef.Close()
                        'cmRef.Dispose()
                    Next
                End If

                qryresults += "</tr>"

                'Response.Write(qryresults)

                vclass = IIf(vclass = "odd", "even", "odd")
                vCtr += 1
            Loop
            c.Close()
            c.Dispose()
            cm.Dispose()
            cmRef.Dispose()

        Catch ex As SqlClient.SqlException
            vscript = "alert('An error occured while trying to access to database.  Error is: " & _
                      ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Close()
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try


    End Sub
End Class
