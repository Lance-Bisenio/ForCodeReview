﻿
Partial Class testfile_1
    Inherits System.Web.UI.Page

End Class
