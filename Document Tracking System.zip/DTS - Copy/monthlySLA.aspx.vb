﻿Imports denaro.fis
Partial Class monthlySLA
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Public vDump As String = ""
    Public vBuildRating As String = ""
   


    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If

        If Not CanRun(Session("caption"), Request.Item("id")) Then
            Session("denied") = 1
            Server.Transfer("main.aspx")
        End If

        If Not IsPostBack Then

            BuildCombo("select Status_Cd,Descr from dm_document_status where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='Status' and Property_Value=Status_Cd) order by Descr", cmbStatus)
            cmbStatus.SelectedValue = 10
            cmbMonth.SelectedIndex = Month(Now) - 1

            cmbYrFr.Items.Clear()
            cmbYrTo.Items.Clear()
            For iCtr = 2013 To Year(Now) + 2
                cmbYrFr.Items.Add(iCtr)
                cmbYrTo.Items.Add(iCtr)
            Next iCtr

            cmbDayFr.Items.Clear()
            cmbDayTo.Items.Clear()
            For iCtr = 1 To 31
                cmbDayFr.Items.Add(iCtr)
                cmbDayTo.Items.Add(iCtr)
            Next iCtr

            cmbYrFr.SelectedIndex = Year(Now)
            cmbMonth.SelectedIndex = Month(Now) - 1
            cmbDayFr.SelectedIndex = 0

            cmbYrTo.SelectedIndex = Year(Now)
            cmbMonthTo.SelectedIndex = Month(Now) - 1
            cmbDayTo.SelectedIndex = 14

        End If
        'BuildData()
    End Sub

    Public Function GetElapsedDay(ByVal pDateEncoded As String, ByVal pDatePost As String) As Single
        Dim vElapsedDay As Single
        vElapsedDay = Math.Round(DateDiff(DateInterval.Day, CDate(pDateEncoded), CDate(pDatePost)), 2)
        Return vElapsedDay
    End Function

    Protected Sub cmdClose_Click(sender As Object, e As EventArgs) Handles cmdClose.Click
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand("select User_Id from user_list where Position='Processor' order by fullname", c)
        Dim rs As SqlClient.SqlDataReader

        Try
            c.Open()
        Catch ex As Exception

        End Try

        rs = cm.ExecuteReader
        Do While rs.Read
            Session.Remove(rs("User_Id"))
        Loop
        rs.Close()

        cm.CommandText = "select Descr from dm_document_status"
        rs = cm.ExecuteReader
        Do While rs.Read
            Session.Remove(rs("Descr"))
        Loop
        rs.Close()

        c.Close()
        c.Dispose()
        cm.Dispose()

        Server.Transfer("main.aspx")
    End Sub

    Protected Sub cmbMonth_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbMonth.SelectedIndexChanged
        cmbMonthTo.SelectedIndex = cmbMonth.SelectedValue - 1
    End Sub

    Protected Sub cmdSearch_Click(sender As Object, e As EventArgs) Handles cmdSearch.Click
        GetAllReceiveDoc()
        CreateTempFile()
        BuildData()
    End Sub

    Private Sub GetAllReceiveDoc()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cmRef As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader

        c.Open()
        cm.Connection = c
        cmRef.Connection = c

        txtTtl_DocRec.Value = ""
        txtGoodTxn.Value = ""
        txtNonGoodTxn.Value = ""

        Dim vUploadedDate As String = " and Date_Uploaded between '" & _
           CDate(cmbMonth.SelectedValue & "/" & cmbDayFr.SelectedValue & "/" & cmbYrFr.SelectedValue) & " 00:00' and '" & _
           CDate(cmbMonthTo.SelectedValue & "/" & cmbDayTo.SelectedValue & "/" & cmbYrTo.SelectedValue) & " 23:59'"
        cm.CommandText = "select Doc_Id from dm_document where Doc_Id is not null " & vUploadedDate
        'Response.Write(cm.CommandText)
        rs = cm.ExecuteReader
        Do While rs.Read
            txtTtl_DocRec.Value += rs("Doc_Id") & ","
            Session("vDocCntr") += 1
        Loop
        rs.Close()

        Dim vDocRec As String()
        Dim vTemp As String = ""

        If txtTtl_DocRec.Value.Trim <> "" Then
            txtTtl_DocRec.Value = Mid(txtTtl_DocRec.Value, 1, Len(txtTtl_DocRec.Value) - 1)

            vDocRec = txtTtl_DocRec.Value.Split(",")

            For i As Integer = 0 To UBound(vDocRec)
                cm.CommandText = "select   Top 1 TranNo from dm_ledger where Doc_id=" & vDocRec(i) & " and Status_Cd=" & cmbStatus.SelectedValue & "  order by TranNo desc"
                'Response.Write(cm.CommandText & " <test 1><br>")
                rs = cm.ExecuteReader
                If rs.Read Then
                    txtGoodTxn.Value += rs("TranNo") & ","
                Else
                    rs.Close()
                    cm.CommandText = "select Top 1 TranNo from dm_ledger where Doc_id=" & vDocRec(i) & " order by TranNo desc"
                    'Response.Write(cm.CommandText & " <test 2><br>")
                    rs = cm.ExecuteReader
                    If rs.Read Then
                        txtNonGoodTxn.Value += rs("TranNo") & ","
                        Session("vNonGoodDocCntr") += 1
                    End If
                End If
                rs.Close()
            Next


            txtGoodTxn.Value = Mid(txtGoodTxn.Value, 1, Len(txtGoodTxn.Value) - 1)
            txtNonGoodTxn.Value = Mid(txtNonGoodTxn.Value, 1, Len(txtNonGoodTxn.Value) - 1)
        End If

        c.Close()
        c.Dispose()
        cm.Dispose()
    End Sub

    Private Sub CreateTempFile()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cmRef As New SqlClient.SqlCommand

        Dim rs As SqlClient.SqlDataReader
        Dim vGoodDoc As String()
        Dim vElapsedDay As Single

        c.Open()
        cm.Connection = c
        cmRef.Connection = c

        cm.CommandText = "delete from sla_temp  where CreatedBy='" & Session("uid") & "'"
        cm.ExecuteNonQuery()

        If txtGoodTxn.Value.Trim <> "" Then
            vGoodDoc = txtGoodTxn.Value.Split(",")
            For i As Integer = 0 To UBound(vGoodDoc)
                cm.CommandText = "select TranNo, TranDate, Doc_Id, AgencyCd, Category_Cd, Status_Cd, Supplier_Cd, CreatedBy," & _
                    "(select Date_Uploaded from dm_document where dm_document.Doc_Id= dm_ledger.Doc_Id) as vDateRec " & _
                    "from dm_ledger  where TranNo=" & vGoodDoc(i)

                rs = cm.ExecuteReader
                If rs.Read Then
                    vElapsedDay = GetElapsedDay(rs("vDateRec"), rs("TranDate"))

                    cmRef.CommandText = "insert into sla_temp (Emp_Cd,Doc_Id, DaysProcess, Date_Received, TranDate, Agency_Cd, Category_Cd, Status_Cd, Supplier_Cd, CreatedBy, Remarks) " & _
                        " values ('" & rs("CreatedBy") & "','" & rs("Doc_Id") & "','" & vElapsedDay & "','" & rs("vDateRec") & "','" & rs("TranDate") & "','" & rs("AgencyCd") & "'," & _
                        "'" & rs("Category_Cd") & "','" & rs("Status_Cd") & "','" & rs("Supplier_Cd") & "','" & Session("uid") & "','GoodDocs')"
                    cmRef.ExecuteNonQuery()

                End If
                rs.Close()
            Next
        End If

        If txtNonGoodTxn.Value.Trim <> "" Then
            vGoodDoc = txtNonGoodTxn.Value.Split(",")
            For i As Integer = 0 To UBound(vGoodDoc)
                cm.CommandText = "select TranNo, TranDate, Doc_Id, AgencyCd, Category_Cd, Status_Cd, Supplier_Cd, CreatedBy," & _
                    "(select Date_Uploaded from dm_document where dm_document.Doc_Id= dm_ledger.Doc_Id) as vDateRec " & _
                    "from dm_ledger  where TranNo=" & vGoodDoc(i)

                rs = cm.ExecuteReader
                If rs.Read Then
                    vElapsedDay = GetElapsedDay(rs("vDateRec"), rs("TranDate"))

                    cmRef.CommandText = "insert into sla_temp (Emp_Cd,Doc_Id, DaysProcess, Date_Received, TranDate, Agency_Cd, Category_Cd, Status_Cd, Supplier_Cd, CreatedBy, Remarks) " & _
                        " values ('" & rs("CreatedBy") & "','" & rs("Doc_Id") & "','" & vElapsedDay & "','" & rs("vDateRec") & "','" & rs("TranDate") & "','" & rs("AgencyCd") & "'," & _
                        "'" & rs("Category_Cd") & "','" & rs("Status_Cd") & "','" & rs("Supplier_Cd") & "','" & Session("uid") & "','NonGoodDocs')"
                    cmRef.ExecuteNonQuery()

                End If
                rs.Close()
            Next
        End If



        'cm.CommandText = ""
        'rs = cm.ExecuteReader
        'Do While rs.Read
        '    'vUserList += "'" & rs("CreatedBy") & "',"
        'Loop
        'rs.Close()

        c.Close()
        c.Dispose()
        cm.Dispose()
        cmRef.Dispose()

    End Sub

    Private Sub BuildData()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader

        Dim cmRef As New SqlClient.SqlCommand
        Dim rsRef As SqlClient.SqlDataReader
        Dim vSql As String = ""
        Dim vTotal As Integer = 0

        c.Open()
        cm.Connection = c
        cmRef.Connection = c
        vDump = ""
        Session.Remove("0-3days")
        Session.Remove("4days")
        Session.Remove("5days")

        cm.CommandText = "select distinct(Emp_Cd) as vEmp,(select FullName from user_list where User_Id=Emp_Cd) as vFullName  from sla_temp where Remarks='GoodDocs'  and CreatedBy='" & Session("uid") & "'"
        rs = cm.ExecuteReader
        Do While rs.Read
            vDump += "<tr><td class='labelL'>&nbsp;" & rs("vFullName") & "</td>"

            For i As Integer = 0 To 6
                vSql = "select Count(daysprocess) as vCtr from sla_temp where  Remarks='GoodDocs' and Emp_Cd='" & rs("vEmp") & "'  and CreatedBy='" & Session("uid") & "' and daysprocess =" & i
                Select Case i
                    Case 0
                        vSql = "select Count(daysprocess) as vCtr from sla_temp where  Remarks='GoodDocs' and Emp_Cd='" & rs("vEmp") & "' and CreatedBy='" & Session("uid") & "' and daysprocess <1 "
                    Case 5
                        vSql = "select Count(daysprocess) as vCtr from sla_temp where  Remarks='GoodDocs' and Emp_Cd='" & rs("vEmp") & "' and CreatedBy='" & Session("uid") & "' and daysprocess >4 "
                    Case 6
                        vSql = "select Count(daysprocess) as vCtr from sla_temp where  Remarks='GoodDocs' and Emp_Cd='" & rs("vEmp") & "'  and CreatedBy='" & Session("uid") & "' "
                End Select

                cmRef.CommandText = vSql
                rsRef = cmRef.ExecuteReader
                If rsRef.Read Then
                    Select Case i
                        Case 0 '1DAYS 
                            Session("0days") += rsRef("vCtr")
                            Session("0-3days") += rsRef("vCtr")
                        Case 1
                            Session("1days") += rsRef("vCtr")
                            Session("0-3days") += rsRef("vCtr")
                        Case 2
                            Session("2days") += rsRef("vCtr")
                            Session("0-3days") += rsRef("vCtr")
                        Case 3
                            Session("3days") += rsRef("vCtr")
                            Session("0-3days") += rsRef("vCtr")
                        Case 4 '4 DAYS
                            Session("4days") += rsRef("vCtr")
                        Case 5  'more than 5 DAYS
                            Session("5days") += rsRef("vCtr")
                    End Select

                    If i = 6 Then
                        vDump += "<td class='linkstyle-z'  style='text-align:right;' onclick='activeMode(""emp"",""" & rs("vEmp") & """);'>" & Format(rsRef("vCtr"), "#,###,##0") & "&nbsp;</td>"
                    Else
                        vDump += "<td class='labelR'  style='padding:5px;'>" & Format(rsRef("vCtr"), "#,###,##0") & "&nbsp;</td>"
                    End If

                End If
                rsRef.Close()
            Next
            vDump += "</tr>"
        Loop
        rs.Close()

        vTotal = (Session("0-3days") + Session("4days") + Session("5days"))

        vDump += "<tr style='font-weight:bold'><td class='labelR' style='padding:5px; color: #0940bd;border: solid 1px #000000'><b>TOTAL :&nbsp;</b></td>" & _
            "<td class='labelR'>" & Format(Session("0days"), "#,###,##0") & "&nbsp;</td><td class='labelR'>" & Format(Session("1days"), "#,###,##0") & "&nbsp;</td>" & _
            "<td class='labelR'>" & Format(Session("2days"), "#,###,##0") & "&nbsp;</td><td class='labelR'>" & Format(Session("3days"), "#,###,##0") & "&nbsp;</td>" & _
            "<td class='labelR'>" & Format(Session("4days"), "#,###,##0") & "&nbsp;</td><td class='labelR'>" & Format(Session("5days"), "#,###,##0") & "&nbsp;</td>" & _
            "<td class='labelR'>" & Format(vTotal, "#,###,##0") & "&nbsp;</td>"
        vDump += "</tr>"

        c.Close()
        c.Dispose()
        cm.Dispose()



        vBuildRating += "<tr>" & _
                "<td class='labelL' style='padding:5px;'><b>0-3 DAYS&nbsp;</b></td>" & _
                "<td class='labelC'>" & Format(Session("0-3days") / vTotal, "percent") & "</td>" & _
                "<td class='linkstyle-z' style='text-align:right;' onclick='activeMode(""summary"",""03DAYS"");'>" & Format(Session("0-3days"), "#,###,##0") & "&nbsp;</td>" & _
            "</tr><tr> " & _
                "<td class='labelL' style='padding:5px;'><b>4 DAYS&nbsp;</b></td>" & _
                "<td class='labelC'>" & Format(Session("4days") / vTotal, "percent") & "</td>" & _
                "<td class='linkstyle-z' style='text-align:right;' onclick='activeMode(""summary"",""4DAYS"");'>" & Format(Session("4days"), "#,###,##0") & "&nbsp;</td>" & _
            "</tr><tr> " & _
                "<td class='labelL' style='padding:5px;'><b>BEYOND 5 DAYS&nbsp;</b></td>" & _
                "<td class='labelC'>" & Format(Session("5days") / vTotal, "percent") & "</td>" & _
                "<td class='linkstyle-z'  style='text-align:right;' onclick='activeMode(""summary"",""B5DAYS"");'>" & Format(Session("5days"), "#,###,##0") & "&nbsp;</td>" & _
            "</tr><tr> " & _
                "<td class='labelR' style='padding:5px; color: #0940bd;border: solid 1px #000000'><b>TOTAL :&nbsp;</b></td>" & _
                "<td class='labelC'><b></b></td>" & _
                "<td class='labelR'><b>" & Format(vTotal, "#,###,##0") & "&nbsp;</b></td>" & _
            "</tr><tr><td colspan='3' style='padding:5px;'>&nbsp;</td></tr>"

        Session.Remove("0-3days")
        Session.Remove("0days")
        Session.Remove("1days")
        Session.Remove("2days")
        Session.Remove("3days")
        Session.Remove("4days")
        Session.Remove("5days")

        vBuildRating += "<tr>" & _
                "<td class='labelL' style='padding:5px;'><b>OTHERS&nbsp;</b></td>" & _
                "<td class='labelC'></td>" & _
                "<td class='linkstyle-z'  style='text-align:right;' onclick='activeMode(""summary"",""OTHERS"");'>" & Format(Session("vNonGoodDocCntr"), "#,###,##0") & "&nbsp;</td>" & _
            "</tr><tr> " & _
                "<td class='labelL' style='padding:5px;'><b>TOTAL DOCUMENT RECEIVED </b></td>" & _
                "<td class='labelC'></td>" & _
                "<td class='labelR'>" & Format(Session("vDocCntr"), "#,###,##0") & "&nbsp;</td>" & _
            "</tr><tr>"

        Session.Remove("vNonGoodDocCntr")
        Session.Remove("vDocCntr")

    End Sub

    'Private Sub BuildData_v3()
    '    Dim c As New SqlClient.SqlConnection(connStr)
    '    Dim cm As New SqlClient.SqlCommand
    '    Dim cmRef As New SqlClient.SqlCommand
    '    Dim rs As SqlClient.SqlDataReader
    '    Dim rsRef As SqlClient.SqlDataReader

    '    Dim vDocID_Exists As String = 0
    '    Dim vUserList As String = ""
    '    Dim vTranNoList As String = ""

    '    c.Open()
    '    cm.Connection = c
    '    cmRef.Connection = c

    '    Dim vTranDate As String = " and TranDate between '" & _
    '       CDate(cmbMonth.SelectedValue & "/" & cmbDayFr.SelectedValue & "/" & cmbYrFr.SelectedValue) & " 00:00' and '" & _
    '       CDate(cmbMonthTo.SelectedValue & "/" & cmbDayTo.SelectedValue & "/" & cmbYrTo.SelectedValue) & " 23:59'"

    '    Dim vUploadedDate As String = " and Date_Uploaded between '" & _
    '        CDate(cmbMonth.SelectedValue & "/" & cmbDayFr.SelectedValue & "/" & cmbYrFr.SelectedValue) & " 00:00' and '" & _
    '        CDate(cmbMonthTo.SelectedValue & "/" & cmbDayTo.SelectedValue & "/" & cmbYrTo.SelectedValue) & " 23:59'"

    '     -----------------------------------------------------------------------------------------------------------------------------------------
    '     GET THE LIST OF PROCESSOR
    '     -----------------------------------------------------------------------------------------------------------------------------------------
    '    cm.CommandText = "select Distinct(CreatedBy) from dm_ledger where  Status_Cd='" & cmbStatus.SelectedValue & "' " & vTranDate & "   "

    '    rs = cm.ExecuteReader
    '    Do While rs.Read
    '        vUserList += "'" & rs("CreatedBy") & "',"
    '    Loop
    '    rs.Close()

    '     -----------------------------------------------------------------------------------------------------------------------------------------
    '     GET THE LIST OF DOCUMENTS
    '     -----------------------------------------------------------------------------------------------------------------------------------------
    '    cm.CommandText = "select * from dm_ledger where  CreatedBy is not null  and Status_Cd='" & cmbStatus.SelectedValue & "' " & vTranDate & " order by Doc_Id desc "
    '    Response.Write(cm.CommandText)

    '    rs = cm.ExecuteReader
    '    Do While rs.Read
    '        If vDocID_Exists <> rs("Doc_Id") Then
    '            vTranNoList += rs("TranNo") & ","
    '            Session(rs("CreatedBy")) += rs("Doc_Id") & ","
    '        End If
    '        vDocID_Exists = rs("Doc_Id")
    '    Loop
    '    rs.Close()



    '    Dim vCoutPerDay() As Integer = {0, 0, 0, 0, 0, 0, 0}
    '    Dim vGTotal() As Integer = {0, 0, 0, 0, 0, 0, 0}
    '    Dim v0days As Integer = 0
    '    Dim v1days As Integer = 0
    '    Dim v2days As Integer = 0
    '    Dim v3days As Integer = 0
    '    Dim vDaysElapse As Integer

    '    Session.Remove("v0to3DaysDocList")
    '    Session.Remove("v0to3DaysDocList")
    '    Session.Remove("v0to3DaysDocList")
    '    Session.Remove("v4DaysDocList")
    '    Session.Remove("vMoreDaysDocList")

    '    cm.CommandText = "select FullName, User_Id from user_list where User_id in (" & Mid(vUserList, 1, Len(vUserList) - 1) & ") order by Position, Fullname"
    '    Response.Write(cm.CommandText)
    '    rs = cm.ExecuteReader
    '    Do While rs.Read

    '        vCoutPerDay(0) = 0
    '        vCoutPerDay(1) = 0
    '        vCoutPerDay(2) = 0
    '        vCoutPerDay(3) = 0
    '        vCoutPerDay(4) = 0
    '        vCoutPerDay(5) = 0
    '        vCoutPerDay(6) = 0
    '        Session.Remove(rs("User_Id"))

    '        cmRef.CommandText = "select Doc_Id, TranDate, " & _
    '                "(select Date_Uploaded from dm_document where dm_document.Doc_Id=dm_ledger.Doc_Id) as DateReceive " & _
    '                "from dm_ledger where TranNo in (" & Mid(vTranNoList, 1, Len(vTranNoList) - 1) & ") and  Status_Cd='" & cmbStatus.SelectedValue & _
    '                "' and CreatedBy='" & rs("User_id") & "' order by Doc_Id "
    '        rsRef = cmRef.ExecuteReader
    '        Do While rsRef.Read
    '            vDaysElapse = GetElapsedDay(Format(rsRef("DateReceive"), "MM/dd/yyyy"), Format(rsRef("TranDate"), "MM/dd/yyyy"))

    '            Select Case vDaysElapse
    '                Case Is = 0 '0 DAYS
    '                    vCoutPerDay(0) += 1
    '                    Session("v0to3DaysDocList") += rsRef("Doc_Id") & ", "
    '                Case Is < 2 '1 DAYS 
    '                    vCoutPerDay(1) += 1
    '                    Session("v0to3DaysDocList") += rsRef("Doc_Id") & ", "
    '                Case Is < 3 '2 DAYS
    '                    vCoutPerDay(2) += 1
    '                    Session("v0to3DaysDocList") += rsRef("Doc_Id") & ", "
    '                Case Is < 4 '3 DAYS
    '                    vCoutPerDay(3) += 1
    '                    Session("v0to3DaysDocList") += rsRef("Doc_Id") & ", "
    '                Case Is < 5 '4 DAYS
    '                    vCoutPerDay(4) += 1
    '                    Session("v4DaysDocList") += rsRef("Doc_Id") & ", "
    '                Case Else '> 4 and above
    '                    vCoutPerDay(5) += 1
    '                    Session("vMoreDaysDocList") += rsRef("Doc_Id") & ", "
    '            End Select
    '            Session(rs("User_Id")) += rsRef("Doc_Id") & ","

    '            vCoutPerDay(6) = (vCoutPerDay(0) + vCoutPerDay(1) + vCoutPerDay(2) + vCoutPerDay(3) + vCoutPerDay(4) + vCoutPerDay(5))
    '            vDocID_Exists = rsRef("Doc_Id")
    '        Loop
    '        rsRef.Close()

    '        vDump += "<tr>" & _
    '            "<td class='labelL' style='padding:5px;'><b>&nbsp;" & rs("FullName") & "</b></td>" & _
    '            "<td class='labelC'>" & vCoutPerDay(0) & "</td>" & _
    '            "<td class='labelC'>" & vCoutPerDay(1) & "</td>" & _
    '            "<td class='labelC'>" & vCoutPerDay(2) & "</td>" & _
    '            "<td class='labelC'>" & vCoutPerDay(3) & "</td>" & _
    '            "<td class='labelC'>" & vCoutPerDay(4) & "</td>" & _
    '            "<td class='labelC'>" & vCoutPerDay(5) & "</td>" & _
    '            "<td class='linkstyle-z' onclick='activeMode(""" & rs("User_Id") & """);'><b>" & vCoutPerDay(6) & "&nbsp;</b></td>" & _
    '        "</tr>"

    '        vGTotal(0) += vCoutPerDay(0)
    '        vGTotal(1) += vCoutPerDay(1)
    '        vGTotal(2) += vCoutPerDay(2)
    '        vGTotal(3) += vCoutPerDay(3)
    '        vGTotal(4) += vCoutPerDay(4)
    '        vGTotal(5) += vCoutPerDay(5)
    '        vGTotal(6) += vCoutPerDay(6)

    '    Loop
    '    rs.Close()


    '    Dim v0_3days As Decimal = 0
    '    Dim v4days As Decimal = 0
    '    Dim vBeyond5Days As Decimal = 0
    '    Dim vTotal As Decimal = 0

    '    Dim v0_3daysNum As Decimal = 0
    '    Dim v4daysNum As Decimal = 0
    '    Dim vBeyond5DaysNum As Decimal = 0
    '    Dim vTotalNum As Decimal = 0

    '    vDump += "<tr>" & _
    '            "<td class='labelR' style='padding:5px; color: #0940bd;border: solid 1px #000000;'><b>Grand Total :&nbsp;</b></td>" & _
    '            "<td class='labelC'><b>" & vGTotal(0) & "</b></td>" & _
    '            "<td class='labelC'><b>" & vGTotal(1) & "</b></td>" & _
    '            "<td class='labelC'><b>" & vGTotal(2) & "</b></td>" & _
    '            "<td class='labelC'><b>" & vGTotal(3) & "</b></td>" & _
    '            "<td class='labelC'><b>" & vGTotal(4) & "</b></td>" & _
    '            "<td class='labelC'><b>" & vGTotal(5) & "</b></td>" & _
    '            "<td class='labelC'><b>" & vGTotal(6) & "&nbsp;</b></td>" & _
    '        "</tr>"

    '    If vGTotal(6) > 0 Then
    '        v0_3days = ((vGTotal(0) + vGTotal(1) + vGTotal(2) + vGTotal(3)) / vGTotal(6))
    '        v4days = (vGTotal(4) / vGTotal(6))
    '        vBeyond5Days = (vGTotal(5) / vGTotal(6))

    '        v0_3daysNum = (vGTotal(0) + vGTotal(1) + vGTotal(2) + vGTotal(3))
    '        v4daysNum = vGTotal(4)
    '        vBeyond5DaysNum = vGTotal(5)

    '    End If

    '    vTotal = v0_3days + v4days + vBeyond5Days
    '    vTotalNum = v0_3daysNum + v4daysNum + vBeyond5DaysNum

    '    If Session("v0to3DaysDocList") <> "" Then
    '        Session("v0to3DaysDocList") = Mid(Session("v0to3DaysDocList"), 1, Len(Session("v0to3DaysDocList")) - 1)
    '    End If

    '    If Session("v4DaysDocList") <> "" Then
    '        Session("v4DaysDocList") = Mid(Session("v4DaysDocList"), 1, Len(Session("v4DaysDocList")) - 1)
    '    End If

    '    If Session("vMoreDaysDocList") <> "" Then
    '        Session("vMoreDaysDocList") = Mid(Session("vMoreDaysDocList"), 1, Len(Session("vMoreDaysDocList")) - 1)
    '    End If

    '    vBuildRating += "<tr>" & _
    '            "<td class='labelL' style='padding:5px;'><b>0-3 DAYS&nbsp;</b></td>" & _
    '            "<td class='labelC'>" & Format(v0_3days, "percent") & "</td>" & _
    '            "<td class='linkstyle-z' onclick='activeMode(""v0to3DaysDocList"");'>" & v0_3daysNum & "</td>" & _
    '        "</tr><tr> " & _
    '            "<td class='labelL' style='padding:5px;'><b>4 DAYS&nbsp;</b></td>" & _
    '            "<td class='labelC'>" & Format(v4days, "percent") & "</td>" & _
    '            "<td class='linkstyle-z' onclick='activeMode(""v4DaysDocList"");'>" & v4daysNum & "</td>" & _
    '        "</tr><tr> " & _
    '            "<td class='labelL' style='padding:5px;'><b>BEYOND 5 DAYS&nbsp;</b></td>" & _
    '            "<td class='labelC'>" & Format(vBeyond5Days, "percent") & "</td>" & _
    '            "<td class='linkstyle-z' onclick='activeMode(""vMoreDaysDocList"");'>" & vBeyond5DaysNum & "</td>" & _
    '        "</tr><tr> " & _
    '            "<td class='labelR' style='padding:5px; color: #0940bd;border: solid 1px #000000'><b>TOTAL :&nbsp;</b></td>" & _
    '            "<td class='labelC'><b>" & Format(vTotal, "percent") & "</b></td>" & _
    '            "<td class='labelC'><b>" & vTotalNum & "</b></td>" & _
    '        "</tr><tr><td colspan='3' style='padding:5px;'>&nbsp;</td></tr>"

    '    cm.Dispose()
    '    cmRef.Dispose()
    '    c.Close()

    'End Sub

    'Private Sub BuildData_v2()
    '    Dim c As New SqlClient.SqlConnection(connStr)
    '    Dim cm As New SqlClient.SqlCommand
    '    Dim cmRef As New SqlClient.SqlCommand
    '    Dim rs As SqlClient.SqlDataReader
    '    Dim rsRef As SqlClient.SqlDataReader

    '    Dim iCtr As Integer = 0
    '    Dim vCoutPerDay() As Integer = {0, 0, 0, 0, 0, 0, 0}
    '    Dim vGTotal() As Integer = {0, 0, 0, 0, 0, 0, 0}
    '    Dim v0days As Integer = 0
    '    Dim v1days As Integer = 0
    '    Dim v2days As Integer = 0
    '    Dim v3days As Integer = 0

    '    Dim vDaysElapse As Integer
    '    Dim vDocID_Exists As String = 0

    '    Dim vTranNoList As String = ""
    '    Dim vDocMasterList As String = ""
    '    Dim vDocList As String = ""
    '    Dim vUserList As String = ""

    '    Dim vTranDate As String = " and TranDate between '" & _
    '        CDate(cmbMonth.SelectedValue & "/" & cmbDayFr.SelectedValue & "/" & cmbYrFr.SelectedValue) & " 00:00:00' and '" & _
    '        CDate(cmbMonthTo.SelectedValue & "/" & cmbDayTo.SelectedValue & "/" & cmbYrTo.SelectedValue) & " 23:59:59'"

    '    Dim vUploadedDate As String = " and Date_Uploaded between '" & _
    '        CDate(cmbMonth.SelectedValue & "/" & cmbDayFr.SelectedValue & "/" & cmbYrFr.SelectedValue) & " 00:00:00' and '" & _
    '        CDate(cmbMonthTo.SelectedValue & "/" & cmbDayTo.SelectedValue & "/" & cmbYrTo.SelectedValue) & " 23:59:59'"

    '    c.Open()
    '    cm.Connection = c
    '    cmRef.Connection = c

    '    ' -----------------------------------------------------------------------------------------------------------------------------------------
    '    ' COLLECT ALL DOCUMENT WHERE DATE RECEIVE IS BASE IN THE DATERAGE
    '    ' -----------------------------------------------------------------------------------------------------------------------------------------
    '    cm.CommandText = "select Doc_Id from dm_document where Doc_Id is Not null " & vUploadedDate & " order by Doc_Id "
    '    rs = cm.ExecuteReader
    '    Do While rs.Read
    '        'vDocMasterList += rs("Doc_Id") & ","
    '        vDocList += rs("Doc_Id") & ","
    '    Loop
    '    rs.Close()
    '    'Response.Write(cm.CommandText)

    '    ' -----------------------------------------------------------------------------------------------------------------------------------------
    '    ' GET THE LIST OF PROCESSOR
    '    ' -----------------------------------------------------------------------------------------------------------------------------------------
    '    cm.CommandText = "select Distinct(CreatedBy) from dm_ledger where Status_Cd='" & cmbStatus.SelectedValue & "' and  CreatedBy is not null and CreatedBy !='' and " & _
    '        "Doc_Id in (" & Mid(vDocList, 1, Len(vDocList) - 1) & ")"

    '    rs = cm.ExecuteReader
    '    Do While rs.Read
    '        vUserList += "'" & rs("CreatedBy") & "',"
    '    Loop
    '    rs.Close()

    '    ' -----------------------------------------------------------------------------------------------------------------------------------------
    '    ' GET THE LAST PERSON WHO MODIFY THE DOCUMENT
    '    ' -----------------------------------------------------------------------------------------------------------------------------------------
    '    cm.CommandText = "select * from dm_ledger where Status_Cd='" & cmbStatus.SelectedValue & "' and  CreatedBy is not null and CreatedBy !='' and " & _
    '        "Doc_Id in (" & Mid(vDocList, 1, Len(vDocList) - 1) & ") order by Doc_Id, TranDate desc"
    '    vDocList = ""
    '    vDocID_Exists = 0
    '    rs = cm.ExecuteReader
    '    Do While rs.Read
    '        If vDocID_Exists <> rs("Doc_Id") Then
    '            vDocList += rs("Doc_Id") & ","
    '            vTranNoList += rs("TranNo") & ","


    '            Session(rs("CreatedBy")) += rs("Doc_Id") & ","
    '        End If
    '        vDocID_Exists = rs("Doc_Id")
    '    Loop
    '    rs.Close()
    '    'Response.Write(cm.CommandText)
    '    'Response.Write(vDocList)

    '    cm.CommandText = "select FullName, User_Id from user_list where User_id in (" & Mid(vUserList, 1, Len(vUserList) - 1) & ") order by Position, Fullname"
    '    'Response.Write(cm.CommandText)
    '    rs = cm.ExecuteReader
    '    Do While rs.Read

    '        'Response.Write(rs("FullName") & " : : " & Session(rs("User_Id")) & "<br>")
    '        If Session(rs("User_Id")) <> "" Then

    '            cmRef.CommandText = "select Doc_Id, TranDate, " & _
    '                "(select Date_Uploaded from dm_document where dm_document.Doc_Id=dm_ledger.Doc_Id) as DateReceive " & _
    '                "from dm_ledger where Doc_Id in (" & Mid(Session(rs("User_Id")), 1, Len(Session(rs("User_Id"))) - 1) & ") and  Status_Cd='" & cmbStatus.SelectedValue & _
    '                "' and CreatedBy='" & rs("User_id") & "' order by Doc_Id "

    '            'Response.Write(cmRef.CommandText & "<BR>")
    '            rsRef = cmRef.ExecuteReader

    '            vCoutPerDay(0) = 0
    '            vCoutPerDay(1) = 0
    '            vCoutPerDay(2) = 0
    '            vCoutPerDay(3) = 0
    '            vCoutPerDay(4) = 0
    '            vCoutPerDay(5) = 0
    '            vCoutPerDay(6) = 0

    '            Do While rsRef.Read

    '                If vDocID_Exists <> rsRef("Doc_Id") Then

    '                    Session(rs("User_Id")) += rsRef("Doc_Id") & ","
    '                    vDaysElapse = GetElapsedDay(Format(rsRef("DateReceive"), "MM/dd/yyyy"), Format(rsRef("TranDate"), "MM/dd/yyyy"))

    '                    Select Case vDaysElapse
    '                        Case Is = 0 '0 DAYS
    '                            vCoutPerDay(0) += 1
    '                            Session("v0to3DaysDocList") += rsRef("Doc_Id") & ", "
    '                        Case Is < 2 '1 DAYS 
    '                            vCoutPerDay(1) += 1
    '                            Session("v0to3DaysDocList") += rsRef("Doc_Id") & ", "
    '                        Case Is < 3 '2 DAYS
    '                            vCoutPerDay(2) += 1
    '                            Session("v0to3DaysDocList") += rsRef("Doc_Id") & ", "
    '                        Case Is < 4 '3 DAYS
    '                            vCoutPerDay(3) += 1
    '                            Session("v0to3DaysDocList") += rsRef("Doc_Id") & ", "
    '                        Case Is < 5 '4 DAYS
    '                            vCoutPerDay(4) += 1
    '                            Session("v4DaysDocList") += rsRef("Doc_Id") & ", "
    '                        Case Else '> 4 and above
    '                            vCoutPerDay(5) += 1
    '                            Session("vMoreDaysDocList") += rsRef("Doc_Id") & ", "
    '                    End Select
    '                End If

    '                vCoutPerDay(6) = (vCoutPerDay(0) + vCoutPerDay(1) + vCoutPerDay(2) + vCoutPerDay(3) + vCoutPerDay(4) + vCoutPerDay(5))
    '                vDocID_Exists = rsRef("Doc_Id")
    '            Loop
    '            rsRef.Close()

    '            vDump += "<tr>" & _
    '                "<td class='labelL' style='padding:5px;'><b>&nbsp;" & rs("FullName") & "</b></td>" & _
    '                "<td class='labelC'>" & vCoutPerDay(0) & "</td>" & _
    '                "<td class='labelC'>" & vCoutPerDay(1) & "</td>" & _
    '                "<td class='labelC'>" & vCoutPerDay(2) & "</td>" & _
    '                "<td class='labelC'>" & vCoutPerDay(3) & "</td>" & _
    '                "<td class='labelC'>" & vCoutPerDay(4) & "</td>" & _
    '                "<td class='labelC'>" & vCoutPerDay(5) & "</td>" & _
    '                "<td class='linkstyle-z' onclick='activeMode(""" & rs("User_Id") & """);'><b>" & vCoutPerDay(6) & "&nbsp;</b></td>" & _
    '            "</tr>"

    '            vGTotal(0) += vCoutPerDay(0)
    '            vGTotal(1) += vCoutPerDay(1)
    '            vGTotal(2) += vCoutPerDay(2)
    '            vGTotal(3) += vCoutPerDay(3)
    '            vGTotal(4) += vCoutPerDay(4)
    '            vGTotal(5) += vCoutPerDay(5)
    '            vGTotal(6) += vCoutPerDay(6)

    '            'Session.Remove(rs("User_Id"))

    '        End If
    '    Loop
    '    rs.Close()

    '    Dim v0_3days As Decimal = 0
    '    Dim v4days As Decimal = 0
    '    Dim vBeyond5Days As Decimal = 0
    '    Dim vTotal As Decimal = 0

    '    Dim v0_3daysNum As Decimal = 0
    '    Dim v4daysNum As Decimal = 0
    '    Dim vBeyond5DaysNum As Decimal = 0
    '    Dim vTotalNum As Decimal = 0

    '    vDump += "<tr>" & _
    '            "<td class='labelR' style='padding:5px; color: #0940bd;border: solid 1px #000000;'><b>Grand Total :&nbsp;</b></td>" & _
    '            "<td class='labelC'><b>" & vGTotal(0) & "</b></td>" & _
    '            "<td class='labelC'><b>" & vGTotal(1) & "</b></td>" & _
    '            "<td class='labelC'><b>" & vGTotal(2) & "</b></td>" & _
    '            "<td class='labelC'><b>" & vGTotal(3) & "</b></td>" & _
    '            "<td class='labelC'><b>" & vGTotal(4) & "</b></td>" & _
    '            "<td class='labelC'><b>" & vGTotal(5) & "</b></td>" & _
    '            "<td class='labelC'><b>" & vGTotal(6) & "&nbsp;</b></td>" & _
    '        "</tr>"

    '    If vGTotal(6) > 0 Then
    '        v0_3days = ((vGTotal(0) + vGTotal(1) + vGTotal(2) + vGTotal(3)) / vGTotal(6))
    '        v4days = (vGTotal(4) / vGTotal(6))
    '        vBeyond5Days = (vGTotal(5) / vGTotal(6))

    '        v0_3daysNum = (vGTotal(0) + vGTotal(1) + vGTotal(2) + vGTotal(3))
    '        v4daysNum = vGTotal(4)
    '        vBeyond5DaysNum = vGTotal(5)

    '    End If

    '    vTotal = v0_3days + v4days + vBeyond5Days
    '    vTotalNum = v0_3daysNum + v4daysNum + vBeyond5DaysNum

    '    If Session("v0to3DaysDocList") <> "" Then
    '        Session("v0to3DaysDocList") = Mid(Session("v0to3DaysDocList"), 1, Len(Session("v0to3DaysDocList")) - 1)
    '    End If

    '    If Session("v4DaysDocList") <> "" Then
    '        Session("v4DaysDocList") = Mid(Session("v4DaysDocList"), 1, Len(Session("v4DaysDocList")) - 1)
    '    End If

    '    If Session("vMoreDaysDocList") <> "" Then
    '        Session("vMoreDaysDocList") = Mid(Session("vMoreDaysDocList"), 1, Len(Session("vMoreDaysDocList")) - 1)
    '    End If

    '    vBuildRating += "<tr>" & _
    '            "<td class='labelL' style='padding:5px;'><b>0-3 DAYS&nbsp;</b></td>" & _
    '            "<td class='labelC'>" & Format(v0_3days, "percent") & "</td>" & _
    '            "<td class='linkstyle-z' onclick='activeMode(""v0to3DaysDocList"");'>" & v0_3daysNum & "</td>" & _
    '        "</tr><tr> " & _
    '            "<td class='labelL' style='padding:5px;'><b>4 DAYS&nbsp;</b></td>" & _
    '            "<td class='labelC'>" & Format(v4days, "percent") & "</td>" & _
    '            "<td class='linkstyle-z' onclick='activeMode(""v4DaysDocList"");'>" & v4daysNum & "</td>" & _
    '        "</tr><tr> " & _
    '            "<td class='labelL' style='padding:5px;'><b>BEYOND 5 DAYS&nbsp;</b></td>" & _
    '            "<td class='labelC'>" & Format(vBeyond5Days, "percent") & "</td>" & _
    '            "<td class='linkstyle-z' onclick='activeMode(""vMoreDaysDocList"");'>" & vBeyond5DaysNum & "</td>" & _
    '        "</tr><tr> " & _
    '            "<td class='labelR' style='padding:5px; color: #0940bd;border: solid 1px #000000'><b>TOTAL :&nbsp;</b></td>" & _
    '            "<td class='labelC'><b>" & Format(vTotal, "percent") & "</b></td>" & _
    '            "<td class='labelC'><b>" & vTotalNum & "</b></td>" & _
    '        "</tr><tr><td colspan='3' style='padding:5px;'>&nbsp;</td></tr>"

    '    ''Response.Write(vDocList)
    '    '' -----------------------------------------------------------------------------------------------------------------------------------------
    '    '' END OF SLA REPORT
    '    '' -----------------------------------------------------------------------------------------------------------------------------------------






    '    '' -----------------------------------------------------------------------------------------------------------------------------------------
    '    '' ITEM SUMMARY BY STATUS NAME
    '    '' -----------------------------------------------------------------------------------------------------------------------------------------

    '    'Dim vStatus_Exist As String = 0
    '    'Dim vTtlDocs As Integer = 0
    '    'Dim vTtlDocDis As Decimal
    '    'Dim vStatusName As Decimal

    '    'Dim vStatusList As String = ""
    '    'Dim vStatusFilter As String = ""
    '    'Dim vStatusArray() As String


    '    'cm.CommandText = "select Status_Cd, Doc_Id, " & _
    '    '   "(select Descr from dm_document_status where dm_document_status.Status_Cd=dm_document.Status_Cd) as StatusName " & _
    '    '   "from dm_document where Doc_Id not in (" & Mid(vDocList, 1, Len(vDocList) - 1) & ") " & vUploadedDate & " order by StatusName"
    '    'vDocList = ""
    '    'cm.CommandTimeout = 180

    '    'rs = cm.ExecuteReader
    '    'Do While rs.Read

    '    '    If vStatusFilter <> rs("Status_Cd").ToString Then
    '    '        vStatusList += rs("Status_Cd") & ","
    '    '    End If

    '    '    vStatusFilter = rs("Status_Cd")
    '    '    vDocList += rs("Doc_Id") & ","
    '    '    vTtlDocDis += 1
    '    'Loop
    '    ''Response.Write(cm.CommandText)
    '    ''Response.Write(vStatusList)
    '    'rs.Close()


    '    'vStatusArray = vStatusList.Split(",")

    '    'For i As Integer = 0 To UBound(vStatusArray) - 1

    '    '    cm.CommandText = "select * from dm_document_status where Status_Cd=" & vStatusArray(i)
    '    '    rs = cm.ExecuteReader
    '    '    If rs.Read Then
    '    '        vBuildRating += "<tr><td class='labelL' style='padding:5px;'><b>" & rs("Descr") & "</b></td>"
    '    '        vStatusName = rs("Status_Cd")
    '    '    End If
    '    '    rs.Close()

    '    '    cm.CommandText = "select Doc_Id from dm_document where Status_Cd=" & _
    '    '        vStatusArray(i) & " and Doc_Id in (" & Mid(vDocList, 1, Len(vDocList) - 1) & ") " & vUploadedDate & ""
    '    '    rs = cm.ExecuteReader

    '    '    iCtr = 0
    '    '    Session(vStatusArray(i)) = ""
    '    '    Do While rs.Read
    '    '        Session(vStatusArray(i)) += rs("Doc_Id") & ","
    '    '        iCtr += 1
    '    '    Loop

    '    '    vBuildRating += "<td class='labelC' style='padding:5px;'><b>" & Format(iCtr / vTtlDocDis, "percent") & "</b></td>"
    '    '    vBuildRating += "<td class='linkstyle-z' onclick='activeMode(""" & vStatusName & """);' style='padding:5px;'><b>" & iCtr & "</b></td>"
    '    '    rs.Close()

    '    'Next

    '    'vBuildRating += "<tr>" & _
    '    '        "<td class='labelR' style='padding:5px; color: #0940bd;border: solid 1px #000000'><b>TOTAL :&nbsp;</b></td>" & _
    '    '        "<td class='labelC'><b>100%</b></td>" & _
    '    '        "<td class='labelC'><b>" & vTtlDocDis & " </b></td>" & _
    '    '    "</tr><tr><td colspan='3'>&nbsp;</td></tr>"

    '    'vBuildRating += "<tr>" & _
    '    '        "<td class='labelR' style='padding:5px; color: #B80000; border: solid 1px #000000; font-size:11px'> " & _
    '    '            "<b>Total document received<br>Base on Received Date rage </b></td>" & _
    '    '        "<td class='labelC'> </td>" & _
    '    '        "<td class='labelC'><b>" & vTotalNum + vTtlDocDis & "</b></td>" & _
    '    '    "</tr><tr><td colspan='3'>&nbsp;</td></tr>"

    '    cm.Dispose()
    '    cmRef.Dispose()
    '    c.Close()
    '    c.Dispose()



    'End Sub

    ''Private Sub BuildData_v2()
    ''    Dim c As New SqlClient.SqlConnection(connStr)
    ''    Dim cm As New SqlClient.SqlCommand
    ''    Dim cmRef As New SqlClient.SqlCommand
    ''    Dim rs As SqlClient.SqlDataReader
    ''    Dim rsRef As SqlClient.SqlDataReader

    ''    Dim vCoutPerDay() As Integer = {0, 0, 0, 0, 0, 0, 0}
    ''    Dim vGTotal() As Integer = {0, 0, 0, 0, 0, 0, 0}

    ''    Dim iCtr As Integer = 0

    ''    Dim v0days As Integer = 0
    ''    Dim v1days As Integer = 0
    ''    Dim v2days As Integer = 0
    ''    Dim v3days As Integer = 0

    ''    Dim vDaysElapse As Integer
    ''    Dim vDocID_Exists As String = 0

    ''    Dim vTranNoList As String = ""
    ''    Dim vDocList As String = ""
    ''    Dim vUserList As String = ""

    ''    Dim vTranDate As String = " and TranDate between '" & _
    ''        CDate(cmbMonth.SelectedValue & "/" & cmbDayFr.SelectedValue & "/" & cmbYrFr.SelectedValue) & " 00:00:00' and '" & _
    ''        CDate(cmbMonthTo.SelectedValue & "/" & cmbDayTo.SelectedValue & "/" & cmbYrTo.SelectedValue) & " 23:59:59'"

    ''    Dim vUploadedDate As String = " and Date_Uploaded between '" & _
    ''        CDate(cmbMonth.SelectedValue & "/" & cmbDayFr.SelectedValue & "/" & cmbYrFr.SelectedValue) & " 00:00:00' and '" & _
    ''        CDate(cmbMonthTo.SelectedValue & "/" & cmbDayTo.SelectedValue & "/" & cmbYrTo.SelectedValue) & " 23:59:59'"

    ''    c.Open()
    ''    cm.Connection = c
    ''    cmRef.Connection = c

    ''    ' -----------------------------------------------------------------------------------------------------------------------------------------
    ''    ' COLLECT ALL TRANSACTION BASE IN STATUS AND TRANDATE; I USE THIS TO FILTER TRANSACTION
    ''    ' -----------------------------------------------------------------------------------------------------------------------------------------
    ''    'cm.CommandText = "select TranNo, Doc_Id, TranDate, CreatedBy, " & _
    ''    '        "(select Date_Uploaded from dm_document where dm_document.Doc_Id=dm_ledger.Doc_Id) as DateReceive " & _
    ''    '        "from dm_ledger where Status_Cd='" & cmbStatus.SelectedValue & "' and month(TranDate)='" & cmbMonth.SelectedValue & _
    ''    '        "' and CreatedBy=(select user_id from user_list where user_list.User_Id=dm_ledger.CreatedBy and Position='Processor') order by Doc_Id desc "
    ''    ' -----------------------------------------------------------------------------------------------------------------------------------------
    ''    ' SERVION 1.1.1
    ''    ' -----------------------------------------------------------------------------------------------------------------------------------------
    ''    cm.CommandText = "select TranNo, Doc_Id, TranDate, CreatedBy, " & _
    ''            "(select Date_Uploaded from dm_document where dm_document.Doc_Id=dm_ledger.Doc_Id) as DateReceive " & _
    ''            "from dm_ledger where Status_Cd='" & cmbStatus.SelectedValue & "' " & vTranDate & _
    ''            " order by Doc_Id desc "
    ''    Response.Write(cm.CommandText)

    ''    vDocList = ""
    ''    vTranNoList = ""
    ''    rs = cm.ExecuteReader
    ''    Do While rs.Read

    ''        If vDocID_Exists <> rs("Doc_Id") Then
    ''            'Response.Write(Month(rs("DateReceive")) & "=" & cmbMonth.SelectedValue)
    ''            If Month(rs("DateReceive")) = cmbMonth.SelectedValue Then

    ''                vTranNoList += rs("TranNo") & ","
    ''                vDocList += rs("Doc_Id") & ","

    ''            End If
    ''        End If

    ''        vDocID_Exists = rs("Doc_Id")
    ''    Loop
    ''    rs.Close()
    ''    'Response.Write(vDocList)

    ''    If vTranNoList = "" Then
    ''        vScript = "alert('No Documents Retrieved for the month of " & cmbMonth.SelectedItem.Text & "')"

    ''        cm.Dispose()
    ''        cmRef.Dispose()
    ''        c.Close()
    ''        c.Dispose()

    ''        Exit Sub
    ''    End If

    ''    vDocID_Exists = 0

    ''    ' -----------------------------------------------------------------------------------------------------------------------------------------
    ''    ' GET THE LIST OF PROCESSOR
    ''    ' -----------------------------------------------------------------------------------------------------------------------------------------
    ''    cm.CommandText = "select Distinct(CreatedBy) from dm_ledger where Status_Cd='" & cmbStatus.SelectedValue & "' " & vTranDate & " and CreatedBy!='' and CreatedBy is not null order by CreatedBy "
    ''    rs = cm.ExecuteReader
    ''    Do While rs.Read
    ''        vUserList += "'" & rs("CreatedBy") & "',"
    ''    Loop
    ''    rs.Close()

    ''    cm.CommandText = "select * from user_list where User_id in (" & Mid(vUserList, 1, Len(vUserList) - 1) & ") order by Position, Fullname"
    ''    'Response.Write(cm.CommandText)
    ''    rs = cm.ExecuteReader

    ''    Session("v0to3DaysDocList") = ""
    ''    Session("v4DaysDocList") = ""
    ''    Session("vMoreDaysDocList") = ""

    ''    Do While rs.Read

    ''        Session(rs("User_Id")) = ""

    ''        ' -----------------------------------------------------------------------------------------------------------------------------------------
    ''        ' GET ALL DOCUMENT IN DM_LEDGET WHERE STATUS IS 10 (10=FOR REVIEW AND POSTING) AND CREATED BY PROCESSOR
    ''        ' -----------------------------------------------------------------------------------------------------------------------------------------
    ''        'cmRef.CommandText = "select Doc_Id, TranDate, " & _
    ''        '    "(select Date_Uploaded from dm_document where dm_document.Doc_Id=dm_ledger.Doc_Id) as DateReceive " & _
    ''        '    "from dm_ledger where TranNo in (" & Mid(vTranNoList, 1, Len(vTranNoList) - 1) & ") and  Status_Cd='" & cmbStatus.SelectedValue & _
    ''        '    "' and CreatedBy='" & rs("User_id") & _
    ''        '    "' and month(TranDate)='" & cmbMonth.SelectedValue & "' order by Doc_Id "
    ''        ' -----------------------------------------------------------------------------------------------------------------------------------------
    ''        ' VERSION 1.1.1
    ''        ' -----------------------------------------------------------------------------------------------------------------------------------------
    ''        cmRef.CommandText = "select Doc_Id, TranDate, " & _
    ''            "(select Date_Uploaded from dm_document where dm_document.Doc_Id=dm_ledger.Doc_Id) as DateReceive " & _
    ''            "from dm_ledger where TranNo in (" & Mid(vTranNoList, 1, Len(vTranNoList) - 1) & ") and  Status_Cd='" & cmbStatus.SelectedValue & _
    ''            "' and CreatedBy='" & rs("User_id") & "' " & vTranDate & " order by Doc_Id "

    ''        'Response.Write(cmRef.CommandText)
    ''        rsRef = cmRef.ExecuteReader

    ''        vCoutPerDay(0) = 0
    ''        vCoutPerDay(1) = 0
    ''        vCoutPerDay(2) = 0
    ''        vCoutPerDay(3) = 0
    ''        vCoutPerDay(4) = 0
    ''        vCoutPerDay(5) = 0
    ''        vCoutPerDay(6) = 0

    ''        Do While rsRef.Read

    ''            If vDocID_Exists <> rsRef("Doc_Id") Then

    ''                Session(rs("User_Id")) += rsRef("Doc_Id") & ","
    ''                vDaysElapse = GetElapsedDay(Format(rsRef("DateReceive"), "MM/dd/yyyy"), Format(rsRef("TranDate"), "MM/dd/yyyy"))

    ''                Select Case vDaysElapse
    ''                    Case Is = 0 '0 DAYS
    ''                        vCoutPerDay(0) += 1
    ''                        Session("v0to3DaysDocList") += rsRef("Doc_Id") & ", "
    ''                    Case Is < 2 '1 DAYS 
    ''                        vCoutPerDay(1) += 1
    ''                        Session("v0to3DaysDocList") += rsRef("Doc_Id") & ", "
    ''                    Case Is < 3 '2 DAYS
    ''                        vCoutPerDay(2) += 1
    ''                        Session("v0to3DaysDocList") += rsRef("Doc_Id") & ", "
    ''                    Case Is < 4 '3 DAYS
    ''                        vCoutPerDay(3) += 1
    ''                        Session("v0to3DaysDocList") += rsRef("Doc_Id") & ", "
    ''                    Case Is < 5 '4 DAYS
    ''                        vCoutPerDay(4) += 1
    ''                        Session("v4DaysDocList") += rsRef("Doc_Id") & ", "
    ''                    Case Else '> 4 and above
    ''                        vCoutPerDay(5) += 1
    ''                        Session("vMoreDaysDocList") += rsRef("Doc_Id") & ", "
    ''                End Select
    ''            End If

    ''            vCoutPerDay(6) = (vCoutPerDay(0) + vCoutPerDay(1) + vCoutPerDay(2) + vCoutPerDay(3) + vCoutPerDay(4) + vCoutPerDay(5))
    ''            vDocID_Exists = rsRef("Doc_Id")
    ''        Loop
    ''        rsRef.Close()

    ''        vDump += "<tr>" & _
    ''            "<td class='labelL' style='padding:5px;'><b>&nbsp;" & rs("FullName") & "</b></td>" & _
    ''            "<td class='labelC'>" & vCoutPerDay(0) & "</td>" & _
    ''            "<td class='labelC'>" & vCoutPerDay(1) & "</td>" & _
    ''            "<td class='labelC'>" & vCoutPerDay(2) & "</td>" & _
    ''            "<td class='labelC'>" & vCoutPerDay(3) & "</td>" & _
    ''            "<td class='labelC'>" & vCoutPerDay(4) & "</td>" & _
    ''            "<td class='labelC'>" & vCoutPerDay(5) & "</td>" & _
    ''            "<td class='linkstyle-z' onclick='activeMode(""" & rs("User_Id") & """);'><b>" & vCoutPerDay(6) & "&nbsp;</b></td>" & _
    ''        "</tr>"

    ''        vGTotal(0) += vCoutPerDay(0)
    ''        vGTotal(1) += vCoutPerDay(1)
    ''        vGTotal(2) += vCoutPerDay(2)
    ''        vGTotal(3) += vCoutPerDay(3)
    ''        vGTotal(4) += vCoutPerDay(4)
    ''        vGTotal(5) += vCoutPerDay(5)
    ''        vGTotal(6) += vCoutPerDay(6)
    ''    Loop
    ''    rs.Close()

    ''    ' =============================================================================================================================================================================
    ''    ' NUNBER OF DAY REPORT
    ''    ' =============================================================================================================================================================================
    ''    Dim v0_3days As Decimal = 0
    ''    Dim v4days As Decimal = 0
    ''    Dim vBeyond5Days As Decimal = 0
    ''    Dim vTotal As Decimal = 0

    ''    Dim v0_3daysNum As Decimal = 0
    ''    Dim v4daysNum As Decimal = 0
    ''    Dim vBeyond5DaysNum As Decimal = 0
    ''    Dim vTotalNum As Decimal = 0

    ''    vDump += "<tr>" & _
    ''            "<td class='labelR' style='padding:5px; color: #0940bd;border: solid 1px #000000;'><b>Grand Total :&nbsp;</b></td>" & _
    ''            "<td class='labelC'><b>" & vGTotal(0) & "</b></td>" & _
    ''            "<td class='labelC'><b>" & vGTotal(1) & "</b></td>" & _
    ''            "<td class='labelC'><b>" & vGTotal(2) & "</b></td>" & _
    ''            "<td class='labelC'><b>" & vGTotal(3) & "</b></td>" & _
    ''            "<td class='labelC'><b>" & vGTotal(4) & "</b></td>" & _
    ''            "<td class='labelC'><b>" & vGTotal(5) & "</b></td>" & _
    ''            "<td class='labelC'><b>" & vGTotal(6) & "&nbsp;</b></td>" & _
    ''        "</tr>"

    ''    If vGTotal(6) > 0 Then
    ''        v0_3days = ((vGTotal(0) + vGTotal(1) + vGTotal(2) + vGTotal(3)) / vGTotal(6))
    ''        v4days = (vGTotal(4) / vGTotal(6))
    ''        vBeyond5Days = (vGTotal(5) / vGTotal(6))

    ''        v0_3daysNum = (vGTotal(0) + vGTotal(1) + vGTotal(2) + vGTotal(3))
    ''        v4daysNum = vGTotal(4)
    ''        vBeyond5DaysNum = vGTotal(5)

    ''    End If

    ''    vTotal = v0_3days + v4days + vBeyond5Days
    ''    vTotalNum = v0_3daysNum + v4daysNum + vBeyond5DaysNum

    ''    If Session("v0to3DaysDocList") <> "" Then
    ''        Session("v0to3DaysDocList") = Mid(Session("v0to3DaysDocList"), 1, Len(Session("v0to3DaysDocList")) - 1)
    ''    End If

    ''    If Session("v4DaysDocList") <> "" Then
    ''        Session("v4DaysDocList") = Mid(Session("v4DaysDocList"), 1, Len(Session("v4DaysDocList")) - 1)
    ''    End If

    ''    If Session("vMoreDaysDocList") <> "" Then
    ''        Session("vMoreDaysDocList") = Mid(Session("vMoreDaysDocList"), 1, Len(Session("vMoreDaysDocList")) - 1)
    ''    End If


    ''    vBuildRating += "<tr>" & _
    ''            "<td class='labelL' style='padding:5px;'><b>0-3 DAYS&nbsp;</b></td>" & _
    ''            "<td class='labelC'>" & Format(v0_3days, "percent") & "</td>" & _
    ''            "<td class='linkstyle-z' onclick='activeMode(""v0to3DaysDocList"");'>" & v0_3daysNum & "</td>" & _
    ''        "</tr><tr> " & _
    ''            "<td class='labelL' style='padding:5px;'><b>4 DAYS&nbsp;</b></td>" & _
    ''            "<td class='labelC'>" & Format(v4days, "percent") & "</td>" & _
    ''            "<td class='linkstyle-z' onclick='activeMode(""v4DaysDocList"");'>" & v4daysNum & "</td>" & _
    ''        "</tr><tr> " & _
    ''            "<td class='labelL' style='padding:5px;'><b>BEYOND 5 DAYS&nbsp;</b></td>" & _
    ''            "<td class='labelC'>" & Format(vBeyond5Days, "percent") & "</td>" & _
    ''            "<td class='linkstyle-z' onclick='activeMode(""vMoreDaysDocList"");'>" & vBeyond5DaysNum & "</td>" & _
    ''        "</tr><tr> " & _
    ''            "<td class='labelR' style='padding:5px; color: #0940bd;border: solid 1px #000000'><b>TOTAL :&nbsp;</b></td>" & _
    ''            "<td class='labelC'><b>" & Format(vTotal, "percent") & "</b></td>" & _
    ''            "<td class='labelC'><b>" & vTotalNum & "</b></td>" & _
    ''        "</tr><tr><td colspan='3' style='padding:5px;'>&nbsp;</td></tr>"


    ''    ' =============================================================================================================================================================================
    ''    ' OTHER INFORMATION TO THE DOCUMENT
    ''    ' =============================================================================================================================================================================

    ''    Dim vStatus_Exist As String = 0
    ''    Dim vTtlDocs As Integer = 0
    ''    Dim vTtlDocDis As Decimal
    ''    Dim vGTtlDocDis As Decimal

    ''    ' '' -----------------------------------------------------------------------------------------------------------------------------------------
    ''    ' '' SERVION 1.1.0
    ''    ' '' -----------------------------------------------------------------------------------------------------------------------------------------
    ''    ' '' cm.CommandText = "select status_Cd, " & _
    ''    ' ''   "(select Descr from dm_document_status where dm_document_status.Status_Cd=dm_document.Status_Cd) as StatusName " & _
    ''    ' ''   "from dm_document where Doc_Id not in (" & Mid(vDocList, 1, Len(vDocList) - 1) & ") and month(Date_Uploaded)='" & cmbMonth.SelectedValue & "' order by StatusName"
    ''    ' '' -----------------------------------------------------------------------------------------------------------------------------------------
    ''    ' '' SERVION 1.1.1
    ''    ' '' -----------------------------------------------------------------------------------------------------------------------------------------
    ''    cm.CommandText = "select status_Cd, " & _
    ''       "(select Descr from dm_document_status where dm_document_status.Status_Cd=dm_document.Status_Cd) as StatusName " & _
    ''       "from dm_document where Doc_Id not in (" & Mid(vDocList, 1, Len(vDocList) - 1) & ") " & vUploadedDate & " order by StatusName"

    ''    'Response.Write(cm.CommandText)
    ''    rs = cm.ExecuteReader
    ''    Do While rs.Read
    ''        vTtlDocDis += 1
    ''    Loop
    ''    'Response.Write(vTtlDocDis)
    ''    rs.Close()

    ''    ' '' -----------------------------------------------------------------------------------------------------------------------------------------
    ''    ' '' SERVION 1.1.0
    ''    ' '' -----------------------------------------------------------------------------------------------------------------------------------------
    ''    ' '' cm.CommandText = "select distinct(status_Cd) as StatusLis, " & _
    ''    ' ''    "(select Descr from dm_document_status where dm_document_status.Status_Cd=dm_document.Status_Cd) as StatusName " & _
    ''    ' ''    "from dm_document where Doc_Id not in (" & Mid(vDocList, 1, Len(vDocList) - 1) & ") and month(Date_Uploaded)='" & cmbMonth.SelectedValue & "' order by Status_Cd"
    ''    ' '' -----------------------------------------------------------------------------------------------------------------------------------------
    ''    ' '' SERVION 1.1.1
    ''    ' '' -----------------------------------------------------------------------------------------------------------------------------------------
    ''    ''cm.CommandText = "select distinct(status_Cd) as StatusLis, " & _
    ''    ''    "(select Descr from dm_document_status where dm_document_status.Status_Cd=dm_document.Status_Cd) as StatusName " & _
    ''    ''    "from dm_document where Doc_Id not in (" & Mid(vDocList, 1, Len(vDocList) - 1) & ") " & vUploadedDate & " order by Status_Cd"

    ''    ''Response.Write(cm.CommandText)
    ''    ''rs = cm.ExecuteReader
    ''    ''Do While rs.Read

    ''    ''    vBuildRating += "<tr><td class='labelL' style='padding:5px;'><b>" & rs("StatusName") & "</b></td>"

    ''    ''    ' -----------------------------------------------------------------------------------------------------------------------------------------
    ''    ''    ' SERVION 1.1.0
    ''    ''    ' -----------------------------------------------------------------------------------------------------------------------------------------
    ''    ''    'cmRef.CommandText = "select * from dm_document where Status_Cd=" & rs("StatusLis") & _
    ''    ''    '    " and Doc_Id not in (" & Mid(vDocList, 1, Len(vDocList) - 1) & ") and month(Date_Uploaded)='" & cmbMonth.SelectedValue & "'"
    ''    ''    ' -----------------------------------------------------------------------------------------------------------------------------------------
    ''    ''    ' SERVION 1.1.1
    ''    ''    ' -----------------------------------------------------------------------------------------------------------------------------------------
    ''    ''    cmRef.CommandText = "select * from dm_document where Status_Cd=" & rs("StatusLis") & _
    ''    ''        " and Doc_Id not in (" & Mid(vDocList, 1, Len(vDocList) - 1) & ") " & vUploadedDate & " "
    ''    ''    'Response.Write(cmRef.CommandText & "<br>") 
    ''    ''    rsRef = cmRef.ExecuteReader

    ''    ''    Session(rs("StatusName")) = ""

    ''    ''    Do While rsRef.Read
    ''    ''        Session(rs("StatusName")) += rsRef("Doc_Id") & ","
    ''    ''        iCtr += 1 
    ''    ''    Loop
    ''    ''    rsRef.Close()


    ''    ''    vGTtlDocDis += iCtr / vTtlDocDis
    ''    ''    vBuildRating += "<td class='labelC'>" & Format(iCtr / vTtlDocDis, "percent") & "</td>" & _
    ''    ''            "<td class='linkstyle-z' onclick='activeMode(""" & rs("StatusName") & """);'>" & iCtr & "</td></tr>"

    ''    ''    vTtlDocs += iCtr
    ''    ''    iCtr = 0

    ''    ''Loop
    ''    ''rs.Close()

    ''    ''vBuildRating += "<tr>" & _
    ''    ''        "<td class='labelR' style='padding:5px; color: #0940bd;border: solid 1px #000000'><b>Total Doc Distributed :&nbsp;</b></td>" & _
    ''    ''        "<td class='labelC'><b>" & Format(vGTtlDocDis, "percent") & "</b></td>" & _
    ''    ''        "<td class='labelC'><b>" & vTtlDocs & "</b></td>" & _
    ''    ''    "</tr>"

    ''    ''vBuildRating += "<tr>" & _
    ''    ''        "<td class='labelR' style='padding:5px; color: #0940bd;border: solid 1px #000000'><b>Total Doc as of " & cmbMonth.SelectedItem.Text & " :&nbsp;</b></td>" & _
    ''    ''        "<td class='labelC'> </td>" & _
    ''    ''        "<td class='labelC'><b>" & vTtlDocs + vTotalNum & "</b></td>" & _
    ''    ''    "</tr><tr><td colspan='3'>&nbsp;</td></tr>"

    ''    ''vTtlDocs = 0
    ''    ''vTotalNum = 0

    ''    cm.Dispose()
    ''    cmRef.Dispose()
    ''    c.Close()
    ''    c.Dispose()

    ''End Sub

    'Private Sub BuildData_v1()
    '    Dim c As New SqlClient.SqlConnection(connStr)
    '    Dim cm As New SqlClient.SqlCommand
    '    Dim cmRef As New SqlClient.SqlCommand
    '    Dim rs As SqlClient.SqlDataReader
    '    Dim rsRef As SqlClient.SqlDataReader

    '    Dim vCoutPerDay() As Integer = {0, 0, 0, 0, 0, 0, 0}
    '    Dim vGTotal() As Integer = {0, 0, 0, 0, 0, 0, 0}

    '    Dim iCtr As Integer = 0

    '    Dim v0days As Integer = 0
    '    Dim v1days As Integer = 0
    '    Dim v2days As Integer = 0
    '    Dim v3days As Integer = 0

    '    Dim vDaysElapse As Integer
    '    Dim vDocID_Exists As String = 0
    '    Dim v0to3DaysDocList As String = ""

    '    c.Open()
    '    cm.Connection = c
    '    cmRef.Connection = c


    '    ' -----------------------------------------------------------------------------------------------------------------------------------------
    '    ' GET THE LIST OF PROCESSOR
    '    ' -----------------------------------------------------------------------------------------------------------------------------------------

    '    cm.CommandText = "select * from user_list where Position='Processor' order by fullname"
    '    'Response.Write(cm.CommandText)
    '    rs = cm.ExecuteReader
    '    Do While rs.Read

    '        Session(rs("User_Id")) = ""

    '        ' -----------------------------------------------------------------------------------------------------------------------------------------
    '        ' GET ALL DOCUMENT IN DM_LEDGET WHERE STATUS IS 10 (10=FOR REVIEW AND POSTING) AND CREATED BY PROCESSOR
    '        ' -----------------------------------------------------------------------------------------------------------------------------------------
    '        cmRef.CommandText = "select Doc_Id, TranDate, " & _
    '            "(select Date_Uploaded from dm_document where dm_document.Doc_Id=dm_ledger.Doc_Id) as DateReceive " & _
    '            "from dm_ledger where Status_Cd='" & cmbStatus.SelectedValue & "' and CreatedBy='" & rs("User_id") & _
    '            "' and month(TranDate)='" & cmbMonth.SelectedValue & "' order by Doc_Id "
    '        'Response.Write(cmRef.CommandText)
    '        rsRef = cmRef.ExecuteReader

    '        vCoutPerDay(0) = 0
    '        vCoutPerDay(1) = 0
    '        vCoutPerDay(2) = 0
    '        vCoutPerDay(3) = 0
    '        vCoutPerDay(4) = 0
    '        vCoutPerDay(5) = 0
    '        vCoutPerDay(6) = 0

    '        Do While rsRef.Read

    '            If vDocID_Exists <> rsRef("Doc_Id") Then

    '                Session(rs("User_Id")) += rsRef("Doc_Id") & ","
    '                vDaysElapse = GetElapsedDay(Format(rsRef("DateReceive"), "MM/dd/yyyy"), Format(rsRef("TranDate"), "MM/dd/yyyy"))

    '                Select Case vDaysElapse
    '                    Case Is = 0 '0 DAYS
    '                        vCoutPerDay(0) += 1
    '                        v0to3DaysDocList += rsRef("Doc_Id") & ", "
    '                    Case Is < 2 '1 DAYS 
    '                        vCoutPerDay(1) += 1
    '                        v0to3DaysDocList += rsRef("Doc_Id") & ", "
    '                    Case Is < 3 '2 DAYS
    '                        vCoutPerDay(2) += 1
    '                        v0to3DaysDocList += rsRef("Doc_Id") & ", "
    '                    Case Is < 4 '3 DAYS
    '                        vCoutPerDay(3) += 1
    '                        v0to3DaysDocList += rsRef("Doc_Id") & ", "
    '                    Case Is < 5 '4 DAYS
    '                        vCoutPerDay(4) += 1
    '                    Case Else '> 4 and above
    '                        vCoutPerDay(5) += 1
    '                End Select
    '            End If

    '            vCoutPerDay(6) = (vCoutPerDay(0) + vCoutPerDay(1) + vCoutPerDay(2) + vCoutPerDay(3) + vCoutPerDay(4) + vCoutPerDay(5))
    '            vDocID_Exists = rsRef("Doc_Id")
    '        Loop
    '        rsRef.Close()

    '        vDump += "<tr>" & _
    '            "<td class='labelL' style='padding:5px;'><b>&nbsp;" & rs("FullName") & "</b></td>" & _
    '            "<td class='labelC'>" & vCoutPerDay(0) & "</td>" & _
    '            "<td class='labelC'>" & vCoutPerDay(1) & "</td>" & _
    '            "<td class='labelC'>" & vCoutPerDay(2) & "</td>" & _
    '            "<td class='labelC'>" & vCoutPerDay(3) & "</td>" & _
    '            "<td class='labelC'>" & vCoutPerDay(4) & "</td>" & _
    '            "<td class='labelC'>" & vCoutPerDay(5) & "</td>" & _
    '            "<td class='linkstyle-z' onclick='activeMode(""" & rs("User_Id") & """);'><b>" & vCoutPerDay(6) & "&nbsp;</b></td>" & _
    '        "</tr>"

    '        vGTotal(0) += vCoutPerDay(0)
    '        vGTotal(1) += vCoutPerDay(1)
    '        vGTotal(2) += vCoutPerDay(2)
    '        vGTotal(3) += vCoutPerDay(3)
    '        vGTotal(4) += vCoutPerDay(4)
    '        vGTotal(5) += vCoutPerDay(5)
    '        vGTotal(6) += vCoutPerDay(6)
    '    Loop
    '    rs.Close()

    '    Response.Write(v0to3DaysDocList)
    '    Dim v0_3days As Decimal = 0
    '    Dim v4days As Decimal = 0
    '    Dim vBeyond5Days As Decimal = 0
    '    Dim vTotal As Decimal = 0

    '    Dim v0_3daysNum As Decimal = 0
    '    Dim v4daysNum As Decimal = 0
    '    Dim vBeyond5DaysNum As Decimal = 0
    '    Dim vTotalNum As Decimal = 0

    '    vDump += "<tr>" & _
    '            "<td class='labelR' style='padding:5px;'><b>Grand Total :&nbsp;</b></td>" & _
    '            "<td class='labelC'><b>" & vGTotal(0) & "</b></td>" & _
    '            "<td class='labelC'><b>" & vGTotal(1) & "</b></td>" & _
    '            "<td class='labelC'><b>" & vGTotal(2) & "</b></td>" & _
    '            "<td class='labelC'><b>" & vGTotal(3) & "</b></td>" & _
    '            "<td class='labelC'><b>" & vGTotal(4) & "</b></td>" & _
    '            "<td class='labelC'><b>" & vGTotal(5) & "</b></td>" & _
    '            "<td class='labelC'><b>" & vGTotal(6) & "&nbsp;</b></td>" & _
    '        "</tr>"

    '    If vGTotal(6) > 0 Then
    '        v0_3days = ((vGTotal(0) + vGTotal(1) + vGTotal(2) + vGTotal(3)) / vGTotal(6))
    '        v4days = (vGTotal(4) / vGTotal(6))
    '        vBeyond5Days = (vGTotal(5) / vGTotal(6))

    '        v0_3daysNum = (vGTotal(0) + vGTotal(1) + vGTotal(2) + vGTotal(3))
    '        v4daysNum = vGTotal(4)
    '        vBeyond5DaysNum = vGTotal(5)

    '    End If

    '    vTotal = v0_3days + v4days + vBeyond5Days
    '    vTotalNum = v0_3daysNum + v4daysNum + vBeyond5DaysNum

    '    vBuildRating += "<tr>" & _
    '            "<td class='labelR' style='padding:5px;'><b>0-3 DAYS&nbsp;</b></td>" & _
    '            "<td class='labelC'>" & Format(v0_3days, "percent") & "</td>" & _
    '            "<td class='labelC'>" & v0_3daysNum & "</td>" & _
    '        "</tr><tr> " & _
    '            "<td class='labelR' style='padding:5px;'><b>4 DAYS&nbsp;</b></td>" & _
    '            "<td class='labelC'>" & Format(v4days, "percent") & "</td>" & _
    '            "<td class='labelC'>" & v4daysNum & "</td>" & _
    '        "</tr><tr> " & _
    '            "<td class='labelR' style='padding:5px;'><b>BEYOND 5 DAYS&nbsp;</b></td>" & _
    '            "<td class='labelC'>" & Format(vBeyond5Days, "percent") & "</td>" & _
    '            "<td class='labelC'>" & vBeyond5DaysNum & "</td>" & _
    '        "</tr><tr> " & _
    '            "<td class='labelR' style='padding:5px;'><b>TOTAL&nbsp;</b></td>" & _
    '            "<td class='labelC'><b>" & Format(vTotal, "percent") & "</b></td>" & _
    '            "<td class='labelC'><b>" & vTotalNum & "</b></td>" & _
    '        "</tr>"

    '    cm.Dispose()
    '    cmRef.Dispose()
    '    c.Close()
    '    c.Dispose()

    'End Sub
End Class
