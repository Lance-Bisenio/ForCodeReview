﻿
Partial Class viewdoclist
    Inherits System.Web.UI.Page
    Public vDump As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Dim vTempDocList() As String
        Dim iCtr As Integer

        vTempDocList = Request.Item("TempDocList").ToString.Split("|")

        For iCtr = 0 To UBound(vTempDocList)

            If iCtr = 0 Then
                frmPreview.Attributes("src") = "../" & vTempDocList(0) & ""
            End If

            vDump += "<a onclick='previewfile(""" & vTempDocList(iCtr) & """);' class='textLinks' style='cursor:pointer;' title='" & _
                        vTempDocList(iCtr) & "' />" & _
                        "<img src='images/pdf-icon.png' style='width:14x; height:14px; border: 0px;'> " & _
                        vTempDocList(iCtr) & "</a><br />"
        Next

    End Sub
End Class
