﻿Imports denaro.fis
Partial Class addcompany
    Inherits System.Web.UI.Page
    Dim c As New sqlclient.sqlConnection
    Public vscript As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = Nothing Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If

        If Not IsPostBack Then
            Dim cm As New SqlClient.SqlCommand
            Dim dr As SqlClient.SqlDataReader
            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c
            cm.CommandText = "select AgencyCd,AgencyName from Agency where AgencyCd='" & Session("vline") & "'"
            dr = cm.ExecuteReader
            If dr.Read Then
                txtAgencyCd.Text = dr("AgencyCd")
                txtAgencyName.Text = dr("AgencyName")
            End If
            dr.Close()
            cm.Dispose()
            c.Close()
        End If
    End Sub

    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Dim cm As New SqlClient.SqlCommand
        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c
        If Session("vline") <> "" Then
            EventLog(Session("uid"), Request.ServerVariables("REMOTE_ADDR"), "EDIT", "", "", "Agency/Company" & Session("vline") & _
                     "-" & txtAgencyName.Text, "Document Location")

            cm.CommandText = "update agency set AgencyName='" & CleanVar(txtAgencyName.Text) & _
                "' where AgencyCd='" & Session("vline") & "'"
        Else
            EventLog(Session("uid"), Request.ServerVariables("REMOTE_ADDR"), "ADD", "", "", "Agency/Company" & _
                     "-" & txtAgencyName.Text, "Category")

            cm.CommandText = "INSERT INTO agency (AgencyName)values('" & CleanVar(txtAgencyName.Text) & "')"
        End If

        cm.ExecuteNonQuery()
        cm.Dispose()
        c.Close()

        vscript = "alert('Record successfully saved.'); window.opener.document.form1.submit(); window.close();"
    End Sub

    Protected Sub btnClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Session.Remove("vline")
        vscript = "self.close();"
    End Sub
End Class
