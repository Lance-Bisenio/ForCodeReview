﻿Imports denaro.fis
Partial Class buildprocess
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Public vDump As String = ""


    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        'If Session("uid") = Nothing Then
        '    Server.Transfer("index.aspx")
        '    Exit Sub
        'End If

        If Not IsPostBack Then

            BuildCombo("select AgencyCd,AgencyName from agency where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='agency' and Property_Value=AgencyCd) order by AgencyName", cmbAgency)
            cmbAgency.Items.Add("All")
            cmbAgency.SelectedValue = "All"

            BuildCombo("select Category_Id,Descr from dm_category where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='Category' and Property_Value=Category_Id) order by Descr", cmbCatg)
            cmbCatg.Items.Add("All")
            cmbCatg.SelectedValue = "All"

            BuildCombo("select Status_Cd,Descr from dm_document_status order by Descr", cmbStatus)
            cmbStatus.Items.Add("All")
            cmbStatus.SelectedValue = "All"
            'DataRefresh()
        End If

        DataRefresh()
    End Sub

    Private Sub DataRefresh()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cmRef As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim rsRef As SqlClient.SqlDataReader
        Dim vStatusList As String = ""
        Dim vIsAssign As String = ""
        Dim vActionType() As String
        Dim vSearch As String = ""
        c.Open()
        cm.Connection = c
        cmRef.Connection = c

        If cmbAgency.SelectedValue <> "All" Then
            vSearch += " and AgencyCd ='" & cmbAgency.SelectedValue & "' "
        End If

        If cmbCatg.SelectedValue <> "All" Then
            vSearch += " and Category_Id =" & cmbCatg.SelectedValue
        End If

        If cmbStatus.SelectedValue <> "All" Then
            vSearch += " and Status_Cd =" & cmbStatus.SelectedValue
        End If

        cm.CommandText = "select *, " & _
            "(select AgencyName from agency where agency.AgencyCd=dm_process.AgencyCd) as CompName, " & _
            "(select Descr from dm_category where dm_category.Category_Id=dm_process.Category_Id) as CatName, " & _
            "(select Descr from dm_document_Status where dm_document_Status.Status_Cd=dm_process.Status_Cd) as CurrStatus, " & _
            "(select Descr from dm_document_Status where dm_document_Status.Status_Cd=dm_process.PrevStatus_Cd) as PrevStatus " & _
            " from dm_process where AgencyCd is not null " & vSearch & " order by AgencyCd, Category_Id, Process_Id"

        rs = cm.ExecuteReader
        Do While rs.Read
            vDump += "<tr>" & _
                   "<td class='labelL' style='vertical-align:top;'>&nbsp;" & rs("CompName") & "</td>" & _
                   "<td class='labelL' style='vertical-align:top'>&nbsp;" & rs("CatName") & "</td>" & _
                   "<td class='labelL' style='vertical-align:top'>&nbsp;" & rs("CurrStatus") & "</td>" & _
                   "<td class='labelL' style='vertical-align:top'>&nbsp;" & rs("PrevStatus") & "</td>"

            cmRef.CommandText = "select Descr from dm_document_Status where Status_Cd in (" & rs("NextStep") & ")"
            rsRef = cmRef.ExecuteReader
            Do While rsRef.Read
                vStatusList += "&nbsp;" & rsRef("Descr") & "<br>"
            Loop
            rsRef.Close()

            vDump += "<td class='labelL' style='vertical-align:top'>" & vStatusList & "</td>"


            vActionType = rs("IsAssign").ToString.Split(",")

            For i = 0 To UBound(vActionType)
                If vActionType(i) = 1 Then
                    vIsAssign += "&nbsp;Yes<br>"
                Else
                    vIsAssign += "&nbsp;No<br>"
                End If

            Next i
            vDump += "<td class='labelL' style='vertical-align:top'>" & vIsAssign & "</td>" & _
                "<td class='labelL' style='vertical-align:top'><input type='button' id='btnSelect' name='btnSelect' value='Select' onclick='Selected(" & rs("Process_Id") & ");' /></td></tr>"


            vIsAssign = ""
            vStatusList = ""
        Loop
        rs.Close()

        cm.Dispose()
        cmRef.Dispose()
        c.Close()
        c.Dispose()

    End Sub

    Protected Sub cmdSearch_Click(sender As Object, e As EventArgs) Handles cmdSearch.Click
        'DataRefresh()
    End Sub
End Class
