﻿Imports System.Collections.Generic
Imports System.Data
Imports System.IO
Imports System.Runtime.InteropServices
Imports denaro.fis
Partial Class queue
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Dim vSQL As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Session("uid") = "" Then
            Dim MachineIP = Request.ServerVariables("REMOTE_ADDR")

            Dim IsActive As Integer = 0
        End If

        If Not IsPostBack Then

        Else
            'reminders()
        End If
    End Sub


    Protected Sub btnUpload_Click(sender As Object, e As EventArgs)
        ' Check if a file is uploaded
        If FileUpload1.HasFile Then
            ' Get the file extension
            Dim fileExtension As String = Path.GetExtension(FileUpload1.PostedFile.FileName).ToLower()

            ' Check if the file is a CSV file
            If fileExtension = ".csv" Then
                Try
                    ' Save the uploaded file to the server (optional)
                    Dim filePath As String = Server.MapPath("~/Uploads/") & FileUpload1.FileName
                    FileUpload1.SaveAs(filePath)

                    ' Read the CSV file and display its content
                    Dim csvContent As List(Of String()) = ReadCsvFile(filePath)

                    ' Optionally display a success message
                    lblMessage.Text = "File uploaded successfully"
                    lblMessage.ForeColor = System.Drawing.Color.Green
                Catch ex As Exception
                    ' Handle any errors that might occur
                    lblMessage.Text = "Error: " & ex.Message
                End Try
            Else
                lblMessage.Text = "Please upload a CSV file."
            End If
        Else
            lblMessage.Text = "Please select a file to upload."
        End If
    End Sub

    Private Function ReadCsvFile(filePath As String) As List(Of String())
        Dim result As New List(Of String())
        Dim updateSQL As String = ""
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand(vSQL, c)
        Dim rs As SqlClient.SqlDataReader
        c.Open()


        Try
            Using reader As New StreamReader(filePath)
                While Not reader.EndOfStream
                    ' Read each line and split by comma
                    Dim line As String = reader.ReadLine()
                    Dim values As String() = line.Split(","c)
                    'Response.Write(values(0) & "<br>")

                    vSQL = "select Doc_Id, Doc_Name, SAP_Number, VendorClearingNo, batchClearingNo, Status_Cd, PaymentDate, " _
                        & "(select Status_Cd from dm_document_status c where Descr='" & values(5) & "') As TobeDocStatus," _
                        & "(select Descr from dm_document_status b where a.Status_Cd=b.Status_Cd) As DocStatus,  " _
                        & "(select SupplierName from supplier where supplier.SupplierCd=a.Supplier_Cd) As VendorDescr, " _
                        & "(select Descr from dm_paymethod where dm_paymethod.PayId=a.PaymentId) As PayDescr, " _
                        & "(select PayId from dm_paymethod where Descr='Supplier Financing') As TobePayId " _
                        & "from dm_document a " _
                        & "Where 1=1 and Doc_Id='" & values(0) & "'"

                    cm.CommandText = vSQL
                    rs = cm.ExecuteReader
                    If rs.Read Then
                        vScript += "<tr>" _
                            & "<td class=''>" & values(0) & "</td>" _
                            & "<td class=''>" & rs("VendorDescr") & "</td>" _
                            & "<td class=''>" & rs("SAP_Number") & "</td>" _
                            & "<td class=''>" & rs("VendorClearingNo") & "</td>" _
                            & "<td class=''>" & rs("batchClearingNo") & "</td>" _
                            & "<td class=''>" & rs("DocStatus") & "</td>" _
                            & "<td class=''>" & rs("PaymentDate") & "</td>" _
                            & "<td class=''>" & rs("PayDescr") & "</td>" _
                            & "<td class=''>" & values(1) & "</td>" _
                            & "<td class=''>" & values(2) & "</td>" _
                            & "<td class=''>" & values(3) & "</td>" _
                            & "<td class=''>" & values(5) & "</td>" _
                            & "<td class=''>" & values(6) & "</td>" _
                            & "<td class=''>" & values(7) & "</td>" _
                            & "<td class=''>" & values(4) & "</td>" _
                        & "</tr>"

                        updateSQL += "update dm_document set VendorClearingNo='" & values(2) & "'," _
                            & "batchClearingNo='" & values(3) & "'," _
                            & "Status_Cd='" & rs("TobeDocStatus") & "', " _
                            & "PaymentDate='" & values(6) & "', " _
                            & "PaymentId=" & rs("TobePayId") & " " _
                            & "where Doc_Id=" & values(0) & ";"

                    End If
                    rs.Close()
                    result.Add(values)
                End While

                'Response.Write(updateSQL & "<br>")
                CreateRecord(updateSQL)

            End Using
        Catch ex As Exception

            ' Handle any errors while reading the file
            lblMessage.Text = "Error reading the CSV file: " & ex.Message
        End Try

        Return result

        c.Close()
        c.Dispose()
        cm.Dispose()
    End Function

    Public Sub CreateRecord(pSQL As String)
        Dim c As New SqlClient.SqlConnection
        Dim cm As New SqlClient.SqlCommand
        Dim vReturnVal As String = ""
        c.ConnectionString = connStr

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            'vScript = "alert('Error occurred while trying to connect to database. Error code 101; Error is: " & ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        cm.Connection = c
        cm.CommandText = pSQL

        Try
            cm.ExecuteNonQuery()
        Catch ex As SqlClient.SqlException
            vReturnVal = "Error in SQL query insert/update:  " & ex.Message
        End Try

        c.Close()
        c.Dispose()
        cm.Dispose()

    End Sub
End Class



'vSQL = "select top 1 User_Id from audit where MachineId='" & MachineIP & "' and " _
'                & "TranDate between '" & Format(Now, "yyyy-MM-dd") & " 00:00' and '" & Format(Now, "yyyy-MM-dd") & " 23:59' " _
'                & "order by trandate desc"

'Session("uid") = GetRef(vSQL, "")

'vSQL = "select * from user_list where User_Id='" & Session("uid") & "'"

'Dim c As New SqlClient.SqlConnection(connStr)
'Dim cm As New SqlClient.SqlCommand(vSQL, c)
'Dim rs As SqlClient.SqlDataReader

'c.Open()
'rs = cm.ExecuteReader
'If rs.Read Then
'IsActive = 1
'Session("caption") = IIf(IsDBNull(rs("Caption")), "", rs("Caption"))
'Session("userlevel") = IIf(IsDBNull(rs("UserLevel")), 0, rs("UserLevel"))
'Session("agencylist") = IIf(IsDBNull(rs("AgencyCd")), "", rs("AgencyCd"))

'Session("Catglist") = IIf(IsDBNull(rs("CategoryCd")), "", rs("CategoryCd"))
'Session("Statuslist") = IIf(IsDBNull(rs("StatusCd")), "", rs("StatusCd"))
'Session("deptlist") = IIf(IsDBNull(rs("DeptCd")), "", rs("DeptCd"))

'Session("rclist") = IIf(IsDBNull(rs("Rc_Cd")), "", rs("Rc_Cd"))

'Session("sectionlist") = IIf(IsDBNull(rs("SectionCd")), "", rs("SectionCd"))
'Session("divlist") = IIf(IsDBNull(rs("DivCd")), "", rs("DivCd"))
'Session("unitlist") = IIf(IsDBNull(rs("UnitCd")), "", rs("UnitCd"))
'Session("typelist") = IIf(IsDBNull(rs("EmploymentType")), "", rs("EmploymentType"))

'Session("EmpPos") = IIf(IsDBNull(rs("Position")), "", "Position : " & rs("Position"))
'Session("EmpEmail") = IIf(IsDBNull(rs("Email")), "", "Email : " & rs("Email"))
'Session("EmpFullName") = IIf(IsDBNull(rs("FullName")), "", rs("FullName"))

'Session("sessionid") = Session.SessionID

'End If
'rs.Close()
'c.Close()
'c.Dispose()
'cm.Dispose()

'If IsActive = 0 Then
''Server.Transfer("index.aspx")
'End If