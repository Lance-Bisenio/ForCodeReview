﻿Imports denaro.fis
Partial Class unlockdocs
    Inherits System.Web.UI.Page
    Public vScript As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If

        If Not IsPostBack Then
            BindTable()
        End If

    End Sub

    Protected Sub tblDocsList_PageIndexChanged(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles tblDocsList.PageIndexChanging
        tblDocsList.PageIndex = e.NewPageIndex
        BindTable()
    End Sub
    

    Private Sub BindTable()

        Dim c As New SqlClient.SqlConnection(connStr)
        Dim da As SqlClient.SqlDataAdapter
        Dim ds As New DataSet

        da = New SqlClient.SqlDataAdapter("SELECT * FROM dm_audit_docs", c)
        da.Fill(ds, "docslist")
        tblDocsList.DataSource = ds.Tables("docslist")
        tblDocsList.DataBind()
        da.Dispose()
        ds.Dispose()
        c.Dispose()

    End Sub

    Protected Sub cmdUnlock_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdUnlock.Click

        If tblDocsList.SelectedIndex >= 0 Then
            Dim c As New SqlClient.SqlConnection
            Dim cm As New SqlClient.SqlCommand

            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c
            cm.CommandText = "DELETE FROM dm_audit_docs WHERE Emp_Cd='" & tblDocsList.SelectedRow.Cells(0).Text & _
                "' and Filename = '" & tblDocsList.SelectedRow.Cells(1).Text & "'"
            cm.ExecuteNonQuery()


            Dim vPath As String = tblDocsList.SelectedRow.Cells(1).Text
            Dim vFileCollections() As String = vPath.Split("|")
            Dim vTmpFile As String
            Dim vFilename As String

            For Each vTmpFile In vFileCollections
                vFilename = Server.MapPath(".") & "\..\" & vTmpFile.Replace("/", "\")
                If IO.File.Exists(vFilename) Then
                    IO.File.SetAttributes(vFilename, IO.FileAttributes.System = IO.FileAttributes.Normal)
                End If
            Next

            'Dim vFilename As String = Server.MapPath(".") & "\..\" & tblDocsList.SelectedRow.Cells(1).Text.Replace("/", "\")
            'If IO.File.Exists(vFilename) Then
            '    IO.File.SetAttributes(vFilename, IO.FileAttributes.System = IO.FileAttributes.Normal)
            'End If

            cm.Dispose()
            c.Close()

            vScript = "alert('Record was successfully Unlock.');"
            BindTable()
        Else
            vScript = "alert('You must first select a record before you can use the Unlock button');"
        End If
        

    End Sub

    Protected Sub tblDocsList_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tblDocsList.SelectedIndexChanged
        cmdUnlock.Enabled = True
    End Sub

    Protected Sub cmdDelete_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDelete.Click

        Dim c As New SqlClient.SqlConnection
        Dim cm As New SqlClient.SqlCommand

        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c

        cm.CommandText = "DELETE FROM dm_audit_docs"
        cm.ExecuteNonQuery()

        'Dim vFilename As String = Server.MapPath(".") & "\..\" & tblDocsList.SelectedRow.Cells(1).Text.Replace("/", "\")
        'If IO.File.Exists(vFilename) Then
        '    IO.File.SetAttributes(vFilename, IO.FileAttributes.System = IO.FileAttributes.Normal)
        'End If

        cm.Dispose()
        c.Close()
        vScript = "alert('Done');"
        BindTable()


        'Dim c As New SqlClient.SqlConnection
        'Dim cm As New SqlClient.SqlCommand
        'Dim cmsub As New SqlClient.SqlCommand
        'Dim rs As SqlClient.SqlDataReader

        'c.ConnectionString = connStr
        'c.Open()

        'cm.Connection = c
        'cmsub.Connection = c

        'cm.CommandText = "select * FROM dm_audit_docs"
        'Try
        '    rs = cm.ExecuteReader
        '    If rs.Read Then
        '        cmsub.CommandText = "DELETE FROM dm_audit_docs WHERE Emp_Cd='" & tblDocsList.SelectedRow.Cells(0).Text & _
        '            "' and Filename = '" & tblDocsList.SelectedRow.Cells(1).Text & "'"
        '        cmsub.ExecuteNonQuery()

        '    End If
        '    rs.Close()
        'Catch ex As SqlClient.SqlException
        '    vScript = "alert('Error occurred while trying to delete all docs. Error is: " & _
        '        ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        'Finally
        '    cm.Dispose()
        '    c.Close()
        'End Try



        ''Dim vFilename As String = Server.MapPath(".") & "\..\" & tblDocsList.SelectedRow.Cells(1).Text.Replace("/", "\")
        ''If IO.File.Exists(vFilename) Then
        ''    IO.File.SetAttributes(vFilename, IO.FileAttributes.System = IO.FileAttributes.Normal)
        ''End If

        'cm.Dispose()
        'c.Close()
    End Sub
End Class
