﻿Imports denaro
Partial Class empmaster
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Dim c As New SqlClient.SqlConnection

    Protected Sub cmdAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdAdd.Click
        Session.Remove("empid")
        'If lnkGeneral.Enabled Then
        vScript = "editwin=window.open('empstep1.aspx','empwin','toolbar=no,location=no,width=500,height=400,top=100,left=100');"
        'Else
        '    vScript = "alert('You cannot add new employee because you do not have rights in the General Information Tab. " & _
        '        "You should have access to this tab first before you can add new employees.');"
        'End If
    End Sub


    Protected Sub Page_PreLoad(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.PreLoad
        If Session("uid") = "" Then
            vScript = "alert('Your login session has expired. Please login again.'); "
            Server.Transfer("index.aspx")
        End If
        If Not IsPostBack Then

            cmbShow.Items.Clear()
            For iCtr = 1 To 6
                cmbShow.Items.Add(15 * iCtr)
            Next iCtr

            BuildCombo("select AgencyCd,AgencyName from agency where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='agency' and Property_Value=AgencyCd) order by AgencyName", cmbAgency)

            BuildCombo("select Rc_Id,Descr from emp_rc_ref order by Descr", cmbRc)
            BuildCombo("select Dept_Id,Descr from emp_department_ref order by Descr", cmbDept)
            BuildCombo("select Loc_Id,Descr from emp_location_ref order by Descr", cmbLoc)
            BuildCombo("select Pos_Id,Descr from emp_position_ref order by Descr", cmbPos)

            'cmbAgency.Items.Add("All")
            'cmbAgency.SelectedValue = "All"
            cmbPos.Items.Add("All")
            cmbPos.SelectedValue = "All"
            cmbDept.Items.Add("All")
            cmbDept.SelectedValue = "All"
            cmbLoc.Items.Add("All")
            cmbLoc.SelectedValue = "All"
            cmbRc.Items.Add("All")
            cmbRc.SelectedValue = "All"

            DataRefresh(txtSearch.Text)
        End If

        If Request.Form("txtRefreshList") = "refresh" Then
            DataRefresh(txtSearch.Text)
        End If

    End Sub

    Private Sub DataRefresh(ByVal pLetter As String)
        Dim da As SqlClient.SqlDataAdapter
        Dim ds As New DataSet
        Dim vFilter As String = ""



        Select Case Val(cmbStatus.SelectedValue)
            Case 1  'active employees only
                vFilter += " where Date_Resign is null "
            Case 0  'inactive employees only
                vFilter += " where Date_Resign is not null "
        End Select



        If txtSearch.Text.Trim <> "" Then
            vFilter += " and " & cmbType.SelectedValue & " like '" & txtSearch.Text & "%' "
        End If

        'filter by cost center ------------------------------------------------------------------------------------------
        If cmbAgency.SelectedValue <> "All" Then
            vFilter += " and Agency_Cd='" & cmbAgency.SelectedValue & "' "
        End If


        'filter by Position ---------------------------------------------------------------------------------------------
        If cmbPos.SelectedValue <> "All" Then
            vFilter += " and Pos_cd='" & cmbPos.SelectedValue & "' "
        End If

        'filter by Departments ------------------------------------------------------------------------------------------
        If cmbDept.SelectedValue <> "All" Then
            vFilter += " and DeptCd='" & cmbDept.SelectedValue & "' "
        End If

        'filter by Location ------------------------------------------------------------------------------------------
        If cmbLoc.SelectedValue <> "All" Then
            vFilter += " and LocCd='" & cmbLoc.SelectedValue & "' "
        End If

        vFilter += " order by " & cmbOrderBy.SelectedValue

        c.ConnectionString = connStr
        da = New SqlClient.SqlDataAdapter("select *," & _
            "(select Descr from emp_rc_ref where Rc_Id=Rc_Cd) as vRc_Cd, " & _
            "(select AgencyName from agency where agency.AgencyCd=py_emp_master.Agency_Cd) as vAgency_Cd, " & _
            "(select Descr from emp_location_ref where Loc_Id=LocCd) as vDivCd, " & _
            "(select Descr from emp_department_ref where Dept_Id=DeptCd) as vDeptCd, " & _
            "(select Descr from emp_position_ref where Pos_Id=Pos_Cd) as vSectionCd, " & _
            "(select Bank_No from emp_banklist where emp_banklist.Bank_Id=1 and emp_banklist.Emp_Cd=py_emp_master.Emp_Cd ) as vBPI, " & _
            "(select Bank_No from emp_banklist where emp_banklist.Bank_Id=2 and emp_banklist.Emp_Cd=py_emp_master.Emp_Cd) as vCredit " & _
            "from py_emp_master " & vFilter, c) ' 

        'Response.Write(da.SelectCommand.CommandText)

        da.Fill(ds, "MasterList")
        tblMasterList.DataSource = ds.Tables("MasterList")
        tblMasterList.DataBind()
        da.Dispose()
        ds.Dispose()
        lblTotalDocs.Text = "<b>Total Documents Retrieved : " & tblMasterList.DataSource.Rows.Count & "</b>"
        'tblMasterList.PageSize = 50

    End Sub

    Protected Sub cmdEdit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdEdit.Click
        If tblMasterList.SelectedIndex >= 0 Then
            Session("empid") = tblMasterList.SelectedRow.Cells(1).Text
            vScript = "editwin=window.open('empstep1.aspx','empwin','toolbar=no,location=no,width=40,height=580,top=10,left=100,scrollbars=no'); editwin.focus();"
        Else
            vScript = "alert('You must first select an employee.');"
        End If
    End Sub

    Protected Sub cmdSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSearch.Click
        DataRefresh(txtSearch.Text)
    End Sub

    Protected Sub cmdDelete_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDelete.Click
        If tblMasterList.SelectedIndex >= 0 Then
            Dim vId As String = tblMasterList.SelectedRow.Cells(0).Text
            Dim c As New SqlClient.SqlConnection
            Dim cm As New SqlClient.SqlCommand
            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c

            cm.CommandText = "delete from py_emp_master where Emp_Cd='" & vId & "'"
            cm.ExecuteNonQuery()

            cm.Dispose()
            c.Close()
            c.Dispose()

            vScript = "alert('Successfully Deleted.');"
            DataRefresh(Session("letter"))
        Else
            vScript = "alert('You must first select an employee.');"
        End If
    End Sub
    Protected Sub tblMasterList_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles tblMasterList.PageIndexChanging
        tblMasterList.PageIndex = e.NewPageIndex
        DataRefresh(Session("letter"))
    End Sub

    Protected Sub cmbShow_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbShow.SelectedIndexChanged
        tblMasterList.PageSize = cmbShow.SelectedValue
        DataRefresh(txtSearch.Text)
    End Sub
End Class


