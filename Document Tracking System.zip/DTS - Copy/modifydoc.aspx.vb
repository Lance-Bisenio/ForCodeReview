Imports denaro.fis
Partial Class modifydoc
    Inherits System.Web.UI.Page
    Dim c As New sqlclient.sqlConnection
    Public vScript As String = ""
    Public vDump As String = ""
    Public vBankList As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Session("uid") = Nothing Then
            vScript = "alert('Your login session has expired. Please re-login again.'); window.close();"
            Exit Sub
        End If

        If Session("docid") = Nothing Then
            vScript = "alert('Your login session has expired. Please re-login again.'); window.close();"
            Exit Sub
        End If '

        If Not IsPostBack Then
            txtDocID.Text = Session("docid")
            cmbStatus.Enabled = CanRun(Session("caption"), 67)
            cmbUsers.Enabled = CanRun(Session("caption"), 70)

            GetDetails()
            BuildKeyworks()

            
        End If
        
    End Sub

    Private Sub GetDetails()

        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cmRef As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader

        BuildCombo("select AgencyCd,AgencyName from agency where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='agency' and Property_Value=AgencyCd) order by AgencyName", cmbAgency)

        BuildCombo("select Category_Id,Descr from dm_category where exists (select User_Id from rights_list where User_Id='" & _
            Session("uid") & "' and property='Category' and Property_Value=Category_Id) order by Descr", cmbCatg)

        BuildCombo("select Status_Cd,Descr from dm_document_status order by Descr", cmbStatus)
        BuildCombo("select Location_Id,Descr from dm_document_location order by Location_Id", cmbLoc)
        BuildCombo("select type_cd, Descr from dm_contract_type order by Descr", cmbDocType)
        BuildCombo("select SupplierCd, SupplierName from supplier order by SupplierName", cmbVendor)

        BuildCombo("select User_Id,Fullname from user_list where POSMenus like 'Active%' and User_Id !='userid'", cmbUsers) 'and DeptCd like '%" & Session("uid") & "%'
        BuildCombo("select Status_Cd,Descr from dm_document_status where (IsEnable=1 or exists " & _
                "(select User_Id from rights_list where User_Id='userid' and property='Status' and Property_Value=Status_Cd) ) " & _
                "order by Descr", cmbStatus)


        BuildCombo("select PayId, Descr from dm_paymethod order by Descr ", cmbPayment)

        BuildCombo("select Emp_Cd, Emp_Cd+' => '+Emp_Lname+', '+Emp_Fname from py_emp_master order by Emp_Lname", cmbEmployee)
        cmbEmployee.Items.Add(" ")
        cmbEmployee.SelectedValue = " "

        cmbDocType.Items.Add(" ")
        cmbVendor.Items.Add(" ")
        cmbLoc.Items.Add(" ")
        'cmbStatus.Items.Add(" ")
        cmbUsers.Items.Add(" ")

        c.Open()
        cm.Connection = c
        cmRef.Connection = c
        'txtTitle.Text = "Edit Document Settings"
        cm.CommandText = "select * from dm_document where Doc_Id=" & Session("docid") & ""
        'Response.Write(cm.CommandText)
        rs = cm.ExecuteReader
        If rs.Read Then

            txtDocID.Text = IIf(IsDBNull(rs("Doc_Id")), "", rs("Doc_Id"))
            txtOrigDocName.Text = IIf(IsDBNull(rs("OrigFileName")), "", rs("OrigFileName"))
            txtDocName.Text = IIf(IsDBNull(rs("Doc_Name")), "", rs("Doc_Name"))

            txtH_DocName.Text = IIf(IsDBNull(rs("Doc_Name")), "", rs("Doc_Name"))
            txtH_Status.Text = IIf(IsDBNull(rs("Status_Cd")), "", rs("Status_Cd"))

            cmbAgency.SelectedValue = IIf(IsDBNull(rs("AgencyCd")), " ", rs("AgencyCd"))
            cmbStatus.SelectedValue = IIf(IsDBNull(rs("Status_Cd")), " ", rs("Status_Cd"))
            cmbCatg.SelectedValue = IIf(IsDBNull(rs("Category_Id")), " ", rs("Category_Id"))
            cmbUsers.SelectedValue = IIf(IsDBNull(rs("Emp_Cd")), " ", rs("Emp_Cd"))

            If rs("Supplier_Cd") = 0 Then
                cmbVendor.SelectedValue = " "
            Else
                cmbVendor.SelectedValue = IIf(IsDBNull(rs("Supplier_Cd")), " ", rs("Supplier_Cd"))
            End If

            cmbLoc.SelectedValue = IIf(IsDBNull(rs("Location_Id")), " ", rs("Location_Id"))
            cmbDocType.SelectedValue = IIf(IsDBNull(rs("Contract_Id")), " ", rs("Contract_Id"))
            cmbEmployee.SelectedValue = IIf(IsDBNull(rs("CreditTo")), " ", rs("CreditTo"))

            If cmbEmployee.SelectedValue <> " " Then
                txtBankId.Text = IIf(IsDBNull(rs("Bank_Id")), " ", rs("Bank_Id"))
                BuildCardList()
            Else
                txtBankId.Text = ""
            End If

            txtSAPNo.Text = IIf(IsDBNull(rs("SAP_Number")), "", rs("SAP_Number"))

            If Not IsDBNull(rs("Date_Uploaded")) Then
                txtReceivedDate.Text = Format(rs("Date_Uploaded"), "MM/dd/yyyy")
            End If

            If Not IsDBNull(rs("DueDate")) Then
                txtDueDate.Text = Format(rs("DueDate"), "MM/dd/yyyy")
            End If

            txtVCNo.Text = IIf(IsDBNull(rs("VendorClearingNo")), "", rs("VendorClearingNo"))
            txtBCNo.Text = IIf(IsDBNull(rs("BatchClearingNo")), "", rs("BatchClearingNo"))

        End If
        rs.Close()

        c.Close()
        cm.Dispose()
        cmRef.Dispose()
        c.Dispose()
    End Sub

    Private Sub BuildKeyworks()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cmRef As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim rsRef As SqlClient.SqlDataReader
        Dim vSelected As String = ""
        Dim vKeyList As String = ""

        c.Open()
        cm.Connection = c
        cmRef.Connection = c

        cm.CommandText = "select Keyword_Id from dm_category_property where Category_Id=" & cmbCatg.SelectedValue & " and StatusCd is null and Type=0 order by SeqId" 'get vertical fields
        rs = cm.ExecuteReader
        Do While rs.Read
            vKeyList += rs("Keyword_Id") & ","
        Loop
        rs.Close()

        cm.CommandText = "select Keyword_Id from dm_category_property where Category_Id=" & cmbCatg.SelectedValue & " and StatusCd=" & cmbStatus.SelectedValue & " and Type=0 order by SeqId" 'get vertical fields
        rs = cm.ExecuteReader
        Do While rs.Read
            vKeyList += rs("Keyword_Id") & ","
        Loop
        rs.Close()

        'cm.CommandText = "select * from dm_category_property where Category_Id=" & cmbCategory.SelectedValue & " and Type=0 order by SeqId" 'get vertical fields
        cm.CommandText = "select *, " & _
            "(select Value from dm_document_dtl where dm_category_property.Keyword_Id=dm_document_dtl.Keyword_Id and Doc_Id='" & txtDocID.Text & "') as vKeyValue," & _
            "(select Data_Type from dm_keywords where dm_category_property.Keyword_Id=dm_keywords.Keyword_Id) as DataType " & _
            " from dm_category_property where Category_Id=" & cmbCatg.SelectedValue & _
            " and Keyword_Id in (" & Mid(vKeyList, 1, Len(vKeyList) - 1) & ") and Type=0 order by SeqId" 'get vertical fields
        'Response.Write(cm.CommandText)

        rs = cm.ExecuteReader
        vDump = ""
        Do While rs.Read
            cmRef.CommandText = "select Descr, Data_Type from dm_keywords where Keyword_Id=" & rs("Keyword_Id")

            rsRef = cmRef.ExecuteReader
            If rsRef.Read Then
                Select Case rsRef("Data_Type")

                    Case "STRING", "NUMERIC"
                        vDump += "<div class='form-group mb-0'>" &
                                    "<label class='mb-0' for='inputsm'>" & rsRef("Descr") & "</label>" &
                                    "<input class='form-control input-sm fld-custom' " &
                                        "Type ='text'  " &
                                        "name ='" & Val(rs("Keyword_Id")) & "' " &
                                        "ID ='" & Val(rs("Keyword_Id")) & "' " &
                                        "value ='" & rs("vKeyValue") & "' />" &
                                "</div>"

                        'vDump += "<tr><td Class='labelR'>" & rsRef("Descr") & " : </td><td><input class='label' type='text' style='width: 220px;' name='" & _
                        '    Val(rs("Keyword_Id")) & "' id='" & Val(rs("Keyword_Id")) & "' value='" & rs("vKeyValue") & "' /></td></tr>"

                    Case "LIST"
                        BuildSubListbox(IIf(IsDBNull(rs("Keyword_Id")), "", (rs("Keyword_Id"))), IIf(IsDBNull(rs("vKeyValue")), "", rs("vKeyValue")))

                    Case "DATE"
                        vDump += "<tr><td class='labelR'>" & rsRef("Descr") & " : </td><td>" &
                            "<input class='form-control input-sm fld-custom' type='text' style='width: 78px;' maxlength='10' name='" & Val(rs("Keyword_Id")) & "' id='" & Val(rs("Keyword_Id")) &
                            "' onFocus='showCalendarControl(this);' readonly='readonly'"

                        If Not IsDBNull(rs("vKeyValue")) Then
                            If rs("vKeyValue") <> "" Then
                                vDump += "value='" & Format(CDate(rs("vKeyValue")), "MM/dd/yyyy") & "'/>&nbsp;"
                            Else
                                vDump += "value=''/>&nbsp;"
                            End If
                        End If

                        vDump += "<select class='form-control input-sm fld-custom' name='" & Val(rs("Keyword_Id")) & "_hh' id='" & Val(rs("Keyword_Id")) & "_hh'>"

                        For i As Integer = 0 To 11
                            If Format(Val(i), "00") = Hour(Now()) Then
                                vSelected = "Selected='Selected'"
                            End If
                            vDump += "<option " & vSelected & " >" & Format(Val(i), "00") & "</option>"
                        Next

                        vDump += "</select><select class='form-control input-sm fld-custom' name='" &
                            Val(rs("Keyword_Id")) & "_mm' id='" & Val(rs("Keyword_Id")) & "_mm'>"

                        For i As Integer = 0 To 59
                            vDump += "<option>" & Format(Val(i), "00") & "</option>"
                        Next

                        vDump += "</select><select class='form-control input-sm fld-custom' name='" &
                            Val(rs("Keyword_Id")) & "_am' id='" & Val(rs("Keyword_Id")) & "_am'>" &
                                "<option>AM</option><option>PM</option>" &
                                "</select></td></tr>"

                    Case "TIME"
                        vDump += "<tr><td class='labelR'>" & rsRef("Descr") &
                            ":</td><td><input class='form-control input-sm fld-custom' type='text' style='width: 150px;' maxlength='7' name='" &
                            Val(rs("Keyword_Id")) & "' id='" & Val(rs("Keyword_Id")) & "' value=" & rs("vKeyValue") & " />&nbsp;&nbsp;&nbsp;hh:mm </td></tr>"

                    Case "TEXTAREA"
                        vDump += "<tr><td class='labelR' valign='top'>" & rsRef("Descr") &
                            ":</td><td><textarea class='form-control input-sm fld-custom' style='width: 220px;' rows='2' name='" &
                                Val(rs("Keyword_Id")) & "' id='" & Val(rs("Keyword_Id")) & "' >" & rs("vKeyValue") & "</textarea></td></tr>"

                    Case "YES/NO"
                        vDump += "<tr><td class='labelR'>" & rsRef("Descr") & " : </td><td><input type='checkbox' name='" & _
                            Val(rs("Keyword_Id")) & "' id='" & Val(rs("Keyword_Id")) & "' /></td></tr>"
                End Select

            End If
            rsRef.Close()
        Loop
        rs.Close()

        c.Close()
        cm.Dispose()
        cmRef.Dispose()
        c.Dispose()
    End Sub

    Private Sub BuildSubListbox(ByVal vKey As String, ByVal vKeyValue As String)
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader

        Dim cmSub As New SqlClient.SqlCommand
        Dim rsSub As SqlClient.SqlDataReader

        Dim vSubKeyList As String = ""
        Dim vlblName As String = ""
        Dim vSql As String = ""
        Dim vDatatype As String = ""
        Dim vSeleted As String = ""

        c.Open()
        cm.Connection = c
        cmSub.Connection = c

        'txtOtherInfo.Text = ""
        'vDumpSubKey = ""

        cm.CommandText = "select * from dm_category_property where Category_Id=" & cmbCatg.SelectedValue & " and StatusCd=" & cmbStatus.SelectedValue & " and Keyword_id=" & vKey & ""
        'Response.Write(cm.CommandText)
        Try
            rs = cm.ExecuteReader
            If rs.Read Then
                vDump += "<tr><td class='labelR'>" & rs("LabelText") & " : </td>"
                vDump += "<td><select class='form-control input-sm fld-custom' id='" & vKey & "' name='" & vKey & "' runat='server' style='width:224px;'>"

                cmSub.CommandText = rs("SetResource")
                'Response.Write(rs("SetResource"))
                rsSub = cmSub.ExecuteReader
                Do While rsSub.Read

                    If IsNumeric(rsSub("vID")) Then
                        If rsSub("vID") = Val(vKeyValue) Then
                            vSeleted = "selected='selected'"
                        End If
                    Else
                        If rsSub("vID") = vKeyValue Then
                            vSeleted = "selected='selected'"
                        End If
                    End If

                    vDump += "<option value='" & rsSub("vID") & "' " & vSeleted & "  >" & rsSub("vDescr") & "</option>"
                    vSeleted = ""
                Loop
                rsSub.Close()
                vDump += "</td></tr>"
            End If
            rs.Close()

        Catch ex As DataException
            vScript = "alert('An error occurred while trying to Save the new record.');"

            c.Close()
            c.Dispose()
            cm.Dispose()
        End Try

    End Sub
    
    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click

        Select Case cmbStatus.SelectedValue
            Case 19, 16, 20, 25 'Cancelled, Void, Double Send, For Re-Scanning, For Return / Non Compliant

                If txtReason.Text.Trim = "" Then
                    vScript = "alert('Please Enter valid Reason.');"
                    BuildCardList()
                    BuildKeyworks()
                    Exit Sub
                Else
                    SaveDoc_Details()
                End If

            Case Else
                SaveDoc_Details()
        End Select
        vScript = "alert('Successfully Save'); opener.document.form1.submit();  window.close();"
    End Sub

    Private Sub SaveDoc_Details()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cm_v1 As New SqlClient.SqlCommand
        Dim cm_v2 As New SqlClient.SqlCommand

        Dim rs As SqlClient.SqlDataReader
        'Dim rs_v1 As SqlClient.SqlDataReader

        c.Open()
        cm.Connection = c
        cm_v1.Connection = c
        cm_v2.Connection = c
        cm.CommandTimeout = 500
        cm_v1.CommandTimeout = 500
        cm_v2.CommandTimeout = 500

        ' ------------------------------------------------------------------------------------------------------------------------------------------------------------------
        ' CREATE OLD AND NEW RECORDS BEFORE YOU MODIFY THE ORIGINA RECORD
        ' ------------------------------------------------------------------------------------------------------------------------------------------------------------------
        Dim vColumn As String = "Doc_Id,Doc_Name,Created_By,Encoded_By,Uploaded_By,Date_Created,Date_Encoded,Date_Uploaded,Contents,Uploaded_Path,Category_Id," & _
            "Location_Id,Status_Cd,Contract_Id,Supplier_Cd,Contact_Person,Emp_Cd,Date_Assigned,SAP_Number,LineItem,SubAttachment,ModifyBy,DateModify," & _
            "GRedClient,GRNumber,PrevStatus,Posted,NextStatus,AgencyCd,DueDate,VendorClearingNo,BatchClearingNo,OrigFileName,CreditTo,Bank_Id"

        cm.CommandText = "insert into dm_document_log (" & vColumn & ") select " & vColumn & " from dm_document where Doc_Id ='" & txtDocID.Text & "'"
        cm.ExecuteNonQuery()

        ' ------------------------------------------------------------------------------------------------------------------------------------------------------------------
        ' IF STATUS HAS CHANGE GET THE NEXT STEP AND PREV STEP IN DM_PROCESS
        ' ------------------------------------------------------------------------------------------------------------------------------------------------------------------
        Dim vNextStep As String = ""
        Dim vPrevStep As String = ""
        If cmbStatus.SelectedValue <> txtH_Status.Text Then
            cm.CommandText = "select * from dm_process where category_id='" & cmbCatg.SelectedValue & "' and Status_Cd='" & cmbStatus.SelectedValue & "' "
            rs = cm.ExecuteReader
            If rs.Read Then
                vNextStep = "NextStatus='" & rs("NextStep") & "', "
                vPrevStep = "PrevStatus='" & rs("PrevStatus_Cd") & "', "
            End If
            rs.Close()
        End If

        ' ------------------------------------------------------------------------------------------------------------------------------------------------------------------
        ' UPDATE THE DOCUMENT RECORDS
        ' ------------------------------------------------------------------------------------------------------------------------------------------------------------------
        If txtDueDate.Text <> "" Then
            txtDueDate.Text = ", DueDate='" & Format(CDate(txtDueDate.Text.Trim), "MM/dd/yyyy") & "' "
        End If
        Dim vBankNo As String = ""

        If cmbEmployee.SelectedValue <> " " Then
            vBankNo = ",Bank_Id=" & Request.Item("cmbAccnt") & ",CreditTo='" & cmbEmployee.SelectedValue & "'  "
        Else
            vBankNo = ",Bank_Id=null, CreditTo=null "
        End If

        cm.CommandText = "update dm_document set " & vNextStep & vPrevStep & " Doc_Name='" & txtDocName.Text.Trim & "', AgencyCd='" & cmbAgency.SelectedValue & _
            "', Category_Id='" & cmbCatg.SelectedValue & "', Contract_Id='" & cmbDocType.SelectedValue & "', Supplier_Cd='" & cmbVendor.SelectedValue & _
            "', Status_Cd='" & cmbStatus.SelectedValue & "', Location_Id='" & cmbLoc.SelectedValue & "', Emp_Cd='" & cmbUsers.SelectedValue & _
            "', SAP_Number='" & txtSAPNo.Text.Trim & "', VendorClearingNo='" & txtVCNo.Text.Trim & "', BatchClearingNo='" & txtBCNo.Text & "' " & _
            ",Contents='" & txtReason.Text.Trim & "', Date_Uploaded='" & txtReceivedDate.Text.Trim & "'  " & txtDueDate.Text & " " & _
            " " & vBankNo & " where Doc_Id='" & txtDocID.Text & "' "
        'Response.Write(cm.CommandText)
        cm.ExecuteNonQuery()

        ' ------------------------------------------------------------------------------------------------------------------------------------------------------------------
        ' UPDATE THE DOCUMENT KEYWORDS
        ' ------------------------------------------------------------------------------------------------------------------------------------------------------------------
        Dim vKey As String = ""
        Dim vSQL As String = ""
        Dim vAssignTo As String = ""
        Dim vdate As Date
        Dim vDoc_Id As String = txtDocID.Text
        Dim vKeyList As String = ""
        Dim vSelected As String = ""

        cm.CommandText = "select Keyword_Id from dm_category_property where Category_Id=" & cmbCatg.SelectedValue & " and StatusCd is null and Type=0 order by SeqId"
        rs = cm.ExecuteReader
        Do While rs.Read
            vKeyList += rs("Keyword_Id") & ","
        Loop
        rs.Close()

        cm.CommandText = "select Keyword_Id from dm_category_property where Category_Id=" & cmbCatg.SelectedValue & " and StatusCd=" & cmbStatus.SelectedValue & " and Type=0 order by SeqId"
        rs = cm.ExecuteReader
        Do While rs.Read
            vKeyList += rs("Keyword_Id") & ","
        Loop
        rs.Close()

        cm.CommandText = "select *, " & _
            "(select Descr from dm_keywords where dm_category_property.Keyword_Id=dm_keywords.Keyword_Id)  as Descr, " & _
            "(select Data_Type from dm_keywords where dm_category_property.Keyword_Id=dm_keywords.Keyword_Id) as DataType " & _
            "from dm_category_property where Category_Id=" & cmbCatg.SelectedValue & " and Keyword_Id in (" & Mid(vKeyList, 1, Len(vKeyList) - 1) & ")  and Type=0 order by SeqId"

        rs = cm.ExecuteReader
        Do While rs.Read

            cm_v1.CommandText = "delete from dm_document_dtl where Doc_Id=" & vDoc_Id & " and Keyword_Id=" & rs("keyword_id")
            'Response.Write(cm.CommandText)
            cm_v1.ExecuteNonQuery()

            vSQL = "insert into dm_document_dtl (Doc_Id, Keyword_Id, Value, " & _
                            "Alert_Before_Hrs, EmailAlert, EmailFrequency, EmailFrequencyCount ) "
            vKey = rs("keyword_id")

            Select Case rs("DataType")
                Case "STRING", "NUMERIC", "TIME"
                    vSQL += " values ('" & vDoc_Id & "', " & rs("keyword_id") & ", '" & Request.Form(vKey) & "', 0,0,0,0)"
                Case "LIST"

                    If Not IsDBNull(rs("CmdType")) Then
                        cm_v1.CommandText = rs("CmdType") & " " & rs("TableName") & " set " & rs("FieldName") & "='" & Request.Form(rs("keyword_id").ToString) & "' where " & rs("FieldKey") & "=" & vDoc_Id
                        cm_v1.ExecuteNonQuery()
                        vAssignTo = Request.Form(rs("keyword_id").ToString)
                    End If

                    vSQL += " values ('" & vDoc_Id & "', " & rs("keyword_id") & ", '" & Request.Form(rs("keyword_id").ToString) & "', 0,0,0,0)"
                Case "DATE"

                    If Request.Form(vKey) <> "" Then
                        vdate = Format(CDate(Request.Form(vKey)), "yyyy/MM/dd") & " " & Request.Form(vKey & "_hh") & ":" & _
                            Request.Form(vKey & "_mm") & ":00 " & Request.Form(vKey & "_am")

                        vSQL += " values ('" & vDoc_Id & "', " & rs("keyword_id") & ", '" & _
                            vdate & "', 0,0,0,0)"
                    Else
                        vSQL += " values ('" & vDoc_Id & "', " & rs("keyword_id") & ", '', 0,0,0,0)"
                    End If
                Case "TEXTAREA"
                    vSQL += " values ('" & vDoc_Id & "', " & rs("keyword_id") & ", '" & Request.Form(vKey) & "', 0,0,0,0)"
                Case "YES/NO"
            End Select

            cm_v1.CommandText = vSQL
            cm_v1.ExecuteNonQuery()
            'Response.Write(cm_v1)
        Loop
        rs.Close()

        ' ------------------------------------------------------------------------------------------------------------------------------------------------------------------
        ' CREATE RECORD IN DM_LEDGER. THE SYSTEM WILL SHOW YOU THE LIST OF TRANSACTION BASE ON SELECTED DOCUMENT
        ' ------------------------------------------------------------------------------------------------------------------------------------------------------------------
        cm.CommandText = "insert into dm_ledger (Doc_ID, Status_Cd, Category_Cd, TranDate, CreatedBy, Remarks, Supplier_Cd, AgencyCd, IsAssignTo) " & _
            "values (" & txtDocID.Text & ", '" & cmbStatus.SelectedValue & "', '" & cmbCatg.SelectedValue & "', '" & Format(Now, "yyyy/MM/dd HH:mm:ss") & _
            "', '" & Session("uid") & "','Edited : " & txtReason.Text.Trim & "', '" & cmbVendor.SelectedValue & "', '" & cmbAgency.SelectedValue & "','" & _
            IIf(vAssignTo = "", cmbUsers.SelectedValue, vAssignTo) & "')"
        cm.ExecuteNonQuery()

        c.Close()
        c.Dispose()

        cm.Dispose()
        cm_v1.Dispose()
        cm_v2.Dispose()
    End Sub

    Protected Sub chkModDocName_CheckedChanged(sender As Object, e As EventArgs) Handles chkModDocName.CheckedChanged
        If chkModDocName.Checked = True Then
            txtDocName.ForeColor = Color.Black
            txtDocName.ReadOnly = False
        Else
            txtDocName.ForeColor = Color.Gray
            txtDocName.ReadOnly = True
            txtDocName.Text = txtH_DocName.Text
        End If
        BuildKeyworks()
    End Sub

    Protected Sub cmbStatus_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbStatus.SelectedIndexChanged
        BuildCardList()
        BuildKeyworks()
    End Sub

    Protected Sub cmbVendor_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbVendor.SelectedIndexChanged
        cmbEmployee.SelectedValue = " "
        BuildKeyworks()
    End Sub

    Protected Sub cmbEmployee_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbEmployee.SelectedIndexChanged
        cmbVendor.SelectedValue = " "
        BuildKeyworks()
        BuildCardList()
    End Sub

    Private Sub BuildCardList()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim vSelected As String = ""

        c.Open()
        cm.Connection = c

        vBankList = "<tr><td class='labelR'>Account No : </td>"
        vBankList += "<td><select class='labelL' id='cmbAccnt' name='cmbAccnt' runat='server' style='width:226px;'>"
        cm.CommandText = "select * from emp_banklist where Emp_Cd='" & cmbEmployee.SelectedValue & "' "

        Try
            rs = cm.ExecuteReader
            Do While rs.Read
                If txtBankId.Text <> "" Then
                    'Response.Write(txtBankId.Text & "  = = " & rs("Bank_Id"))
                    If txtBankId.Text = rs("Bank_Id").ToString Then
                        vSelected = " selected='selected'"
                        ' Response.Write("1")
                    Else
                        vSelected = ""
                        'Response.Write("1")
                    End If
                Else
                    If Request.Item("cmbAccnt") = rs("Bank_Id") Then
                        vSelected = " selected='selected'"
                        ' Response.Write("3")
                    Else
                        vSelected = ""
                        'Response.Write("4")
                    End If
                End If

                vBankList += "<option value='" & rs("Bank_Id") & "'" & vSelected & "  >" & rs("Descr") & " => " & rs("Bank_No") & "</option>"
            Loop
            vBankList += "</select></td></tr>"
            rs.Close()

            Session("vBankList") = vBankList

        Catch ex As DataException
            vScript = "alert('An error occurred while trying to Save the new record.');"
            c.Close()
            c.Dispose()
            cm.Dispose()
        Finally
            c.Close()
            c.Dispose()
            cm.Dispose()
        End Try
    End Sub
End Class
