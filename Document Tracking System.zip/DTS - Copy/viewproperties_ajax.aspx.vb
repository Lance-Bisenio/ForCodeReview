﻿
Partial Class viewproperties_ajax
    Inherits System.Web.UI.Page
    Public vReturn As String = ""

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load

        Try
            vReturn = "test1~test2~"
        Catch ex As SqlClient.SqlException
            vReturn = "error"
        Finally
            'c.Close()
            'c.Dispose()
            'cm.Dispose()
        End Try
    End Sub
End Class
