﻿Imports System.Data
Imports denaro.fis
Partial Class volumecount
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Public vData_N1 As String = ""
    Public vData_N2 As String = ""
    Public vData_N3 As String = ""
    Public vData_N4 As String = ""
    Public vData_N5 As String = ""
    Public vData_N6 As String = ""
    Public vData_N7 As String = ""
    Public vData_N8 As String = ""
    Public vData_N9 As String = ""
    Public vData_N10 As String = ""
    Private vRowId() As String = {"Invoices", "HDE", "HDP", "EBE", "EO"}

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If

        If Not CanRun(Session("caption"), Request.Item("id")) Then
            Session("denied") = 1
            Server.Transfer("main.aspx")
        End If

        If Not IsPostBack Then
            cmbYr.Items.Clear()
            For iCtr = 2011 To Year(Now) + 2
                cmbYr.Items.Add(iCtr)
            Next iCtr

            cmbDay.Items.Clear()
            For iCtr = 1 To 30
                cmbDay.Items.Add(iCtr)
            Next iCtr

            cmbYr.SelectedIndex = Year(Now)
            cmbMonth.SelectedIndex = Month(Now) - 1
            cmbDay.SelectedIndex = Day(Now) - 1

            Dim vDate As Date = CDate(cmbYr.SelectedValue & "/" & cmbMonth.SelectedValue & "/" & cmbDay.SelectedValue)
            tranDate.Text = vDate
        End If
    End Sub

    'Private Sub BuildRecords()
    '    'GetBalancePrevDay()

    '    'GetAfter_4PM_PreviousDay()
    '    'GetBefore_12_Noon()
    '    'Get12_Noon_4_PM()
    '    'Void_documents()
    '    'GetExceptions_Current()

    '    'GetProcessed_As_of_12_noon()
    '    'GetProcessed_After_12_noon()

    '    'GetDouble_Send_Wrong_Send_JV_Cancelled_For_GL()
    '    'Balance_for_Today()
    'End Sub

    'Private Sub GetBalancePrevDay()
    '    Dim c As New SqlClient.SqlConnection(connStr)
    '    Dim cm As New SqlClient.SqlCommand
    '    Dim rs As SqlClient.SqlDataReader
    '    Dim vSql As String = ""
    '    Dim vFilter As String = ""
    '    'Dim vPrevDate As Date = DateAdd(DateInterval.Day, -1, CDate(txtStartDate.Value))

    '    'If CDate(txtStartDate.Value).DayOfWeek = DayOfWeek.Monday Then
    '    '    vPrevDate = DateAdd(DateInterval.Day, -3, CDate(txtStartDate.Value))
    '    'End If

    '    'Dim vPrevDateS As Date = Format(CDate(txtDateS.Text), "yyyy-MM-dd")

    '    Dim vPrevDateE As Date = Format(DateAdd(DateInterval.Day, -1, CDate(txtDateE.Text)), "yyyy-MM-dd")

    '    cm.Connection = c
    '    c.Open()

    '    vSql += "select count(distinct(Doc_Id)) as vCount from dm_ledger "
    '    vData_N1 += "<tr><td class='labelBL' height='22px'>&nbsp;<b>Balance Previous Day</b></td>"

    '    For Each t As String In vRowId
    '        Select Case t
    '            Case "Invoices"

    '                'vFilter += " where Date_Uploaded between '" & vPrevDate & " 00:00:00' and '" & _
    '                '    vPrevDate & " 23:59:59' and Status_Cd=1 "

    '                vFilter += "a where a.Status_Cd =1 and exists (select Doc_Id from dm_document where " & _
    '                    "Status_Cd not in (20,19,16,15,14,13,12) and a.Doc_Id=dm_document.Doc_Id) and " & _
    '                    "TranDate between '" & vPrevDateE & " 00:00:00' and '" & vPrevDateE & " 23:59:59'"

    '                cm.CommandText = vSql & vFilter
    '                'Response.Write(cm.CommandText)
    '                rs = cm.ExecuteReader

    '                If rs.Read Then
    '                    vData_N1 += "<td class='labelBC'>" & rs("vCount") & "</td>"
    '                    txtInvTotal.Text = rs("vCount")
    '                End If
    '                rs.Close()
    '                vFilter = ""

    '            Case "HDE" 'Help Desk (Email)
    '                vFilter += ""
    '                cm.CommandText = vSql & vFilter

    '                rs = cm.ExecuteReader
    '                If rs.Read Then
    '                    vData_N1 += "<td class='labelBC'>0</td>"
    '                End If
    '                rs.Close()
    '                vFilter = ""
    '            Case "HDP" 'Help Desk (Phone)
    '                vFilter += " where Status_Cd=99 "
    '                cm.CommandText = vSql & vFilter

    '                rs = cm.ExecuteReader
    '                If rs.Read Then
    '                    vData_N1 += "<td class='labelBC'>0</td>"
    '                End If
    '                rs.Close()
    '                vFilter = ""
    '            Case "EBE" 'Exceptions - Budget Exceed
    '                'vPrevDateS = DateAdd(DateInterval.Day, -1, CDate(txtDateE.Text))

    '                vFilter += "a where a.Status_Cd in (4,5,6,7) and exists (select Doc_Id from dm_document where " & _
    '                    "Status_Cd in (4,5,6,7) and a.Doc_Id=dm_document.Doc_Id) and " & _
    '                    "TranDate between '" & vPrevDateE & " 15:00:00' and '" & vPrevDateE & " 23:59:59' " & _
    '                    "and Remarks like 'Budget Exceeded |%'"

    '                'vFilter += " where Status_Cd in (4,5,6,7) and Remarks like 'Budget Exceeded |%' and " & _
    '                '    "TranDate between '" & vPrevDate & " 00:00:00' and '" & vPrevDate & " 23:59:59'"
    '                cm.CommandText = vSql & vFilter
    '                'Response.Write(cm.CommandText)

    '                rs = cm.ExecuteReader
    '                If rs.Read Then
    '                    vData_N1 += "<td class='labelBC'>" & rs("vCount") & "</td>"
    '                End If
    '                rs.Close()
    '                vFilter = ""
    '            Case "EO" 'Exception - Others

    '                'vPrevDateS = DateAdd(DateInterval.Day, -1, CDate(txtDateE.Text))

    '                vFilter += "a where a.Status_Cd in (4,5,6,7) and exists (select Doc_Id from dm_document where " & _
    '                    "Status_Cd in (4,5,6,7) and a.Doc_Id=dm_document.Doc_Id) and " & _
    '                    "TranDate between '" & vPrevDateE & " 15:00:00' and '" & vPrevDateE & " 23:59:59' " & _
    '                    "and Remarks like 'No Response w/in 24 hrs |%'"

    '                'vFilter += " where Status_Cd in (4,5,6,7) and Remarks like 'No Response w/in 24 hrs |%' and " & _
    '                '    "TranDate between '" & vPrevDate & " 00:00:00' and '" & vPrevDate & " 23:59:59'"
    '                cm.CommandText = vSql & vFilter

    '                rs = cm.ExecuteReader
    '                If rs.Read Then
    '                    vData_N1 += "<td class='labelBC'>" & rs("vCount") & "</td>"
    '                End If

    '                rs.Close()
    '                vFilter = ""
    '        End Select
    '    Next
    '    vData_N1 += "</tr>"


    '    c.Close()
    '    c.Dispose()
    '    cm.Dispose()

    'End Sub

    'Private Sub GetAfter_4PM_PreviousDay()
    '    Dim c As New SqlClient.SqlConnection(connStr)
    '    Dim cm As New SqlClient.SqlCommand
    '    Dim rs As SqlClient.SqlDataReader
    '    Dim vSql As String = ""
    '    Dim vFilter As String = ""
    '    'Dim vPrevDate As Date = DateAdd(DateInterval.Day, -1, CDate(txtStartDate.Value))

    '    'Dim vPrevDateS As Date = Format(CDate(txtDateS.Text), "yyyy-MM-dd")
    '    Dim vPrevDateE As Date = DateAdd(DateInterval.Day, -1, CDate(txtDateE.Text))

    '    cm.Connection = c
    '    c.Open()

    '    vSql += "select count(distinct(Doc_Id)) as vCount from dm_ledger "
    '    vData_N2 += "<tr><td class='labelBL' height='22px'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;After 3 PM (Previous day)</td>"

    '    For Each t As String In vRowId
    '        Select Case t
    '            Case "Invoices"

    '                'vFilter += " where Date_Uploaded between '" & vPrevDate & " 15:00:00' and '" & vPrevDate & " 23:59:59' and Status_Cd=1"
    '                vFilter += "a where a.Status_Cd =1 and exists (select Doc_Id from dm_document where " & _
    '                    "Status_Cd not in (16,19,20) and a.Doc_Id=dm_document.Doc_Id) and " & _
    '                    "TranDate between '" & vPrevDateE & " 15:00:00' and '" & vPrevDateE & " 23:59:59'"

    '                '"and a.Doc_Id not in (select distinct Doc_Id from dm_ledger b where b.Status_Cd=1 and exists " & _
    '                '    "(select Doc_Id from dm_document where Status_Cd not in (16,19,20) and b.Doc_Id=dm_document.Doc_Id) " & _
    '                '    "and b.TranDate between '" & vPrevDate & " 15:00:00' and '" & vPrevDate & " 23:59:59') "

    '                cm.CommandText = vSql & vFilter
    '                'Response.Write(cm.CommandText)
    '                rs = cm.ExecuteReader
    '                If rs.Read Then
    '                    vData_N2 += "<td class='labelBC'>" & rs("vCount") & "</td>"
    '                    txtInvTotal.Text = rs("vCount") + txtInvTotal.Text
    '                End If
    '                rs.Close()
    '                vFilter = ""

    '            Case "HDE" 'Help Desk (Email)
    '                vFilter += " where Status_Cd=99 "
    '                cm.CommandText = vSql & vFilter

    '                rs = cm.ExecuteReader
    '                If rs.Read Then
    '                    vData_N2 += "<td class='labelBC'>" & rs("vCount") & "</td>"
    '                End If
    '                rs.Close()
    '                vFilter = ""
    '            Case "HDP" 'Help Desk (Phone)
    '                vFilter += " where Status_Cd=99 "
    '                cm.CommandText = vSql & vFilter

    '                rs = cm.ExecuteReader
    '                If rs.Read Then
    '                    vData_N2 += "<td class='labelBC'>" & rs("vCount") & "</td>"
    '                End If
    '                rs.Close()
    '                vFilter = ""
    '            Case "EBE" 'Exceptions - Budget Exceed
    '                vFilter += "a where a.Status_Cd in (4,5,6,7) and exists (select Doc_Id from dm_document where " & _
    '                    "Status_Cd in (4,5,6,7) and a.Doc_Id=dm_document.Doc_Id) and " & _
    '                    "TranDate between '" & vPrevDateE & " 15:00:00' and '" & vPrevDateE & " 23:59:59' " & _
    '                    "and Remarks like 'Budget Exceeded |%'"

    '                'vFilter += " where Status_Cd in (4,5,6,7) and TranDate between '" & vPrevDate & " 16:00:00' and '" & vPrevDate & _
    '                '    " 23:59:59' and Remarks like 'Budget Exceeded |%'"
    '                cm.CommandText = vSql & vFilter
    '                'Response.Write(cm.CommandText)

    '                rs = cm.ExecuteReader
    '                If rs.Read Then
    '                    vData_N2 += "<td class='labelBC'>" & rs("vCount") & "</td>" '
    '                End If
    '                rs.Close()
    '                vFilter = ""
    '            Case "EO" 'Exception - Others

    '                vFilter += "a where a.Status_Cd in (4,5,6,7) and exists (select Doc_Id from dm_document where " & _
    '                    "Status_Cd in (4,5,6,7) and a.Doc_Id=dm_document.Doc_Id) and " & _
    '                    "TranDate between '" & vPrevDateE & " 15:00:00' and '" & vPrevDateE & " 23:59:59' " & _
    '                    "and Remarks like 'No Response w/in 24 hrs |%'"

    '                'vFilter += " where Status_Cd in (4,5,6,7) and TranDate between '" & vPrevDate & " 16:00:00' and '" & vPrevDate & _
    '                '    " 23:59:59' and Remarks like 'No Response w/in 24 hrs |%'"
    '                cm.CommandText = vSql & vFilter

    '                rs = cm.ExecuteReader
    '                If rs.Read Then
    '                    vData_N2 += "<td class='labelBC'>" & rs("vCount") & "</td>" '
    '                End If
    '                rs.Close()
    '                vFilter = ""
    '        End Select
    '    Next
    '    vData_N2 += "</tr>"


    '    c.Close()
    '    c.Dispose()
    '    cm.Dispose()

    'End Sub

    'Private Sub GetBefore_12_Noon()
    '    Dim c As New SqlClient.SqlConnection(connStr)
    '    Dim cm As New SqlClient.SqlCommand
    '    Dim rs As SqlClient.SqlDataReader
    '    Dim vSql As String = ""
    '    Dim vFilter As String = ""

    '    cm.Connection = c
    '    c.Open()

    '    vSql += "select count(distinct(Doc_Id)) as vCount from dm_ledger "
    '    vData_N3 += "<tr><td class='labelBL' height='22px'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Before 12 Noon</td>"

    '    For Each t As String In vRowId
    '        Select Case t
    '            Case "Invoices"

    '                'vFilter += " where Date_Uploaded between '" & Format(CDate(txtStartDate.Value), "yyyy-MM-dd") & " 00:00:00' and '" & _
    '                '    Format(CDate(txtStartDate.Value), "yyyy-MM-dd") & " 11:59:59' and Status_Cd=1"

    '                vFilter += "a where a.Status_Cd =1 and exists (select Doc_Id from dm_document where " & _
    '                    "Status_Cd not in (16,19,20) and a.Doc_Id=dm_document.Doc_Id) and " & _
    '                    "TranDate between '" & _
    '                        Format(CDate(txtDateE.Text), "yyyy-MM-dd") & " 00:00:00' and '" & _
    '                        Format(CDate(txtDateE.Text), "yyyy-MM-dd") & " 11:59:59'"

    '                cm.CommandText = vSql & vFilter

    '                rs = cm.ExecuteReader

    '                If rs.Read Then
    '                    vData_N3 += "<td class='labelBC'>" & rs("vCount") & "</td>"
    '                    txtInvTotal.Text = rs("vCount") + txtInvTotal.Text
    '                End If
    '                rs.Close()
    '                vFilter = ""

    '            Case "HDE" 'Help Desk (Email)
    '                vFilter += " where Status_Cd=99 "
    '                cm.CommandText = vSql & vFilter

    '                rs = cm.ExecuteReader
    '                If rs.Read Then
    '                    vData_N3 += "<td class='labelBC'>" & rs("vCount") & "</td>"
    '                End If
    '                rs.Close()
    '                vFilter = ""
    '            Case "HDP" 'Help Desk (Phone)
    '                vFilter += " where Status_Cd=99 "
    '                cm.CommandText = vSql & vFilter

    '                rs = cm.ExecuteReader
    '                If rs.Read Then
    '                    vData_N3 += "<td class='labelBC'>" & rs("vCount") & "</td>"
    '                End If
    '                rs.Close()
    '                vFilter = ""
    '            Case "EBE" 'Exceptions - Budget Exceed

    '                vFilter += "a where a.Status_Cd in (4,5,6,7) and exists (select Doc_Id from dm_document where " & _
    '                    "Status_Cd in (4,5,6,7) and a.Doc_Id=dm_document.Doc_Id) and " & _
    '                    "TranDate between '" & _
    '                        Format(CDate(txtDateE.Text), "yyyy-MM-dd") & " 00:00:00' and '" & _
    '                        Format(CDate(txtDateE.Text), "yyyy-MM-dd") & " 11:59:59' and Remarks like 'Budget Exceeded |%'"

    '                'vFilter += " where Status_Cd in (4,5,6,7) and exists (select Doc_Id from dm_document where " & _
    '                '    "Status_Cd not in (16,19,20) and a.Doc_Id=dm_document.Doc_Id) and TranDate between '" & _
    '                '        Format(CDate(txtStartDate.Value), "yyyy-MM-dd") & " 00:00:00' and '" & _
    '                '        Format(CDate(txtStartDate.Value), "yyyy-MM-dd") & " 11:59:59' and Remarks like 'Budget Exceeded |%'"
    '                cm.CommandText = vSql & vFilter

    '                rs = cm.ExecuteReader
    '                If rs.Read Then
    '                    vData_N3 += "<td class='labelBC'>" & rs("vCount") & "</td>"
    '                End If
    '                rs.Close()
    '                vFilter = ""
    '            Case "EO" 'Exception - Others
    '                vFilter += "a where a.Status_Cd in (4,5,6,7) and exists (select Doc_Id from dm_document where " & _
    '                    "Status_Cd in (4,5,6,7) and a.Doc_Id=dm_document.Doc_Id) and " & _
    '                    "TranDate between '" & _
    '                        Format(CDate(txtDateE.Text), "yyyy-MM-dd") & " 00:00:00' and '" & _
    '                        Format(CDate(txtDateE.Text), "yyyy-MM-dd") & " 11:59:59' and Remarks like 'No Response w/in 24 hrs |%'"

    '                'vFilter += " where Status_Cd in (4,5,6,7) and TranDate between '" & Format(CDate(txtStartDate.Value), "yyyy-MM-dd") & " 00:00:00' and '" & _
    '                '    Format(CDate(txtStartDate.Value), "yyyy-MM-dd") & " 11:59:59' and Remarks like 'No Response w/in 24 hrs |%'"
    '                cm.CommandText = vSql & vFilter

    '                rs = cm.ExecuteReader
    '                If rs.Read Then
    '                    vData_N3 += "<td class='labelBC'>" & rs("vCount") & "</td>"
    '                End If
    '                rs.Close()
    '                vFilter = ""
    '        End Select
    '    Next
    '    vData_N3 += "</tr>"


    '    c.Close()
    '    c.Dispose()
    '    cm.Dispose()

    'End Sub

    'Private Sub Get12_Noon_4_PM()
    '    Dim c As New SqlClient.SqlConnection(connStr)
    '    Dim cm As New SqlClient.SqlCommand
    '    Dim rs As SqlClient.SqlDataReader
    '    Dim vSql As String = ""
    '    Dim vFilter As String = ""

    '    cm.Connection = c
    '    c.Open()

    '    vSql += "select count(distinct(Doc_Id)) as vCount from dm_ledger "
    '    vData_N5 += "<tr><td class='labelBL' height='22px'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;12 Noon - 3 PM</td>"

    '    For Each t As String In vRowId
    '        Select Case t
    '            Case "Invoices"

    '                'vFilter += " where Date_Uploaded between '" & Format(CDate(txtStartDate.Value), "yyyy-MM-dd") & " 12:00:00' and '" & _
    '                '    Format(CDate(txtStartDate.Value), "yyyy-MM-dd") & " 14:59:59' and Status_Cd=1"

    '                vFilter += "a where a.Status_Cd =1 and exists (select Doc_Id from dm_document where " & _
    '                    "Status_Cd not in (16,19,20) and a.Doc_Id=dm_document.Doc_Id) and " & _
    '                    "TranDate between '" & _
    '                        Format(CDate(txtDateE.Text), "yyyy-MM-dd") & " 12:00:00' and '" & _
    '                        Format(CDate(txtDateE.Text), "yyyy-MM-dd") & " 14:59:59'"


    '                cm.CommandText = vSql & vFilter
    '                rs = cm.ExecuteReader

    '                If rs.Read Then
    '                    vData_N5 += "<td class='labelBC'>" & rs("vCount") & "</td>"
    '                    txtInvTotal.Text = rs("vCount") + txtInvTotal.Text
    '                End If
    '                rs.Close()
    '                vFilter = ""

    '            Case "HDE" 'Help Desk (Email)
    '                vFilter += " where Status_Cd=99 "
    '                cm.CommandText = vSql & vFilter

    '                rs = cm.ExecuteReader
    '                If rs.Read Then
    '                    vData_N5 += "<td class='labelBC'>" & rs("vCount") & "</td>"
    '                End If
    '                rs.Close()
    '                vFilter = ""
    '            Case "HDP" 'Help Desk (Phone)
    '                vFilter += " where Status_Cd=99 "
    '                cm.CommandText = vSql & vFilter

    '                rs = cm.ExecuteReader
    '                If rs.Read Then
    '                    vData_N5 += "<td class='labelBC'>" & rs("vCount") & "</td>"
    '                End If
    '                rs.Close()
    '                vFilter = ""
    '            Case "EBE" 'Exceptions - Budget Exceed
    '                vFilter += "a where a.Status_Cd in (4,5,6,7) and exists (select Doc_Id from dm_document where " & _
    '                    "Status_Cd in (4,5,6,7) and a.Doc_Id=dm_document.Doc_Id) and " & _
    '                    "TranDate between '" & _
    '                        Format(CDate(txtDateE.Text), "yyyy-MM-dd") & " 12:00:00' and '" & _
    '                        Format(CDate(txtDateE.Text), "yyyy-MM-dd") & " 14:59:59' and Remarks like 'Budget Exceeded |%'"

    '                'vFilter += " where Status_Cd =7 and TranDate between '" & Format(CDate(txtStartDate.Value), "yyyy-MM-dd") & " 12:00:00' and '" & _
    '                '    Format(CDate(txtStartDate.Value), "yyyy-MM-dd") & " 15:59:59' and Remarks like 'Budget Exceeded |%'"
    '                cm.CommandText = vSql & vFilter

    '                rs = cm.ExecuteReader
    '                If rs.Read Then
    '                    vData_N5 += "<td class='labelBC'>" & rs("vCount") & "</td>"
    '                End If
    '                rs.Close()
    '                vFilter = ""
    '            Case "EO" 'Exception - Others
    '                vFilter += "a where a.Status_Cd in (4,5,6,7) and exists (select Doc_Id from dm_document where " & _
    '                    "Status_Cd in (4,5,6,7) and a.Doc_Id=dm_document.Doc_Id) and " & _
    '                    "TranDate between '" & _
    '                        Format(CDate(txtDateE.Text), "yyyy-MM-dd") & " 12:00:00' and '" & _
    '                        Format(CDate(txtDateE.Text), "yyyy-MM-dd") & " 14:59:59' and Remarks like 'No Response w/in 24 hrs |%'"

    '                'vFilter += " where Status_Cd in (4,5,6,7) and TranDate between '" & Format(CDate(txtStartDate.Value), "yyyy-MM-dd") & " 12:00:00' and '" & _
    '                '    Format(CDate(txtStartDate.Value), "yyyy-MM-dd") & " 15:59:59' and Remarks like 'No Response w/in 24 hrs |%'"
    '                cm.CommandText = vSql & vFilter

    '                rs = cm.ExecuteReader
    '                If rs.Read Then
    '                    vData_N5 += "<td class='labelBC'>" & rs("vCount") & "</td>"
    '                End If
    '                rs.Close()
    '                vFilter = ""
    '        End Select
    '    Next
    '    vData_N5 += "</tr>"

    '    c.Close()
    '    c.Dispose()
    '    cm.Dispose()
    'End Sub

    'Private Sub Void_documents()
    '    Dim c As New SqlClient.SqlConnection(connStr)
    '    Dim cm As New SqlClient.SqlCommand
    '    Dim rs As SqlClient.SqlDataReader
    '    Dim vSql As String = ""
    '    Dim vFilter As String = ""

    '    cm.Connection = c
    '    c.Open()

    '    vSql += "select count(*) as vCount from dm_document "
    '    vData_N10 += "<tr><td class='labelBL' height='22px'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Void Documents</td>"

    '    For Each t As String In vRowId
    '        Select Case t
    '            Case "Invoices"

    '                vFilter += " where Date_Assigned between '" & _
    '                    Format(CDate(txtDateE.Text), "yyyy-MM-dd") & " 00:00:00' and '" & _
    '                    Format(CDate(txtDateE.Text), "yyyy-MM-dd") & " 23:59:59' and Status_Cd =16 "
    '                cm.CommandText = vSql & vFilter
    '                rs = cm.ExecuteReader

    '                If rs.Read Then
    '                    vData_N10 += "<td class='labelBC_r'>(" & rs("vCount") & ")</td>"
    '                    txtInvTotal.Text = txtInvTotal.Text - rs("vCount")
    '                End If
    '                rs.Close()
    '                vFilter = ""

    '            Case "HDE" 'Help Desk (Email)
    '                vFilter += " where Status_Cd=99 "
    '                cm.CommandText = vSql & vFilter

    '                rs = cm.ExecuteReader
    '                If rs.Read Then
    '                    vData_N10 += "<td class='labelBC'>" & rs("vCount") & "</td>"
    '                End If
    '                rs.Close()
    '                vFilter = ""
    '            Case "HDP" 'Help Desk (Phone)
    '                vFilter += " where Status_Cd=99 "
    '                cm.CommandText = vSql & vFilter

    '                rs = cm.ExecuteReader
    '                If rs.Read Then
    '                    vData_N10 += "<td class='labelBC'>" & rs("vCount") & "</td>"
    '                End If
    '                rs.Close()
    '                vFilter = ""
    '            Case "EBE" 'Exceptions - Budget Exceed
    '                vFilter += " where Date_Assigned between '" & _
    '                    Format(CDate(txtDateE.Text), "yyyy-MM-dd") & " 00:00:00' and '" & _
    '                    Format(CDate(txtDateE.Text), "yyyy-MM-dd") & " 23:59:59' and Status_Cd =16 and exists " & _
    '                    "(select Doc_Id from dm_ledger where Status_Cd in (4,5,6,7) and dm_ledger.Doc_Id=dm_document.Doc_Id )"

    '                cm.CommandText = vSql & vFilter

    '                rs = cm.ExecuteReader
    '                If rs.Read Then
    '                    vData_N10 += "<td class='labelBC'>" & rs("vCount") & "</td>"
    '                End If
    '                rs.Close()
    '                vFilter = ""
    '            Case "EO" 'Exception - Others
    '                vFilter += " where Date_Assigned between '" & _
    '                    Format(CDate(txtDateE.Text), "yyyy-MM-dd") & " 00:00:00' and '" & _
    '                    Format(CDate(txtDateE.Text), "yyyy-MM-dd") & " 23:59:59' and Status_Cd =16 and exists " & _
    '                    "(select Doc_Id from dm_ledger where Status_Cd in (4,5,6,7) and dm_ledger.Doc_Id=dm_document.Doc_Id )"

    '                cm.CommandText = vSql & vFilter

    '                rs = cm.ExecuteReader
    '                If rs.Read Then
    '                    vData_N10 += "<td class='labelBC'>" & rs("vCount") & "</td>"
    '                End If
    '                rs.Close()
    '                vFilter = ""
    '        End Select
    '    Next
    '    vData_N4 += "</tr>"


    '    c.Close()
    '    c.Dispose()
    '    cm.Dispose()

    'End Sub

    'Private Sub GetExceptions_Current()
    '    Dim c As New SqlClient.SqlConnection(connStr)
    '    Dim cm As New SqlClient.SqlCommand
    '    Dim rs As SqlClient.SqlDataReader
    '    Dim vSql As String = ""
    '    Dim vFilter As String = ""

    '    cm.Connection = c
    '    c.Open()

    '    vSql += "select count(*) as vCount from dm_document "
    '    vData_N4 += "<tr><td class='labelBL' height='22px'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Exceptions (Current)</td>"

    '    For Each t As String In vRowId
    '        Select Case t
    '            Case "Invoices"

    '                vFilter += " where Date_Assigned between '" & _
    '                    Format(CDate(txtDateE.Text), "yyyy-MM-dd") & " 00:00:00' and '" & _
    '                    Format(CDate(txtDateE.Text), "yyyy-MM-dd") & " 23:59:59' and Status_Cd in (4,5,6,7) "
    '                cm.CommandText = vSql & vFilter
    '                rs = cm.ExecuteReader

    '                If rs.Read Then
    '                    vData_N4 += "<td class='labelBC_r'>(" & rs("vCount") & ")</td>"
    '                    txtInvTotal.Text = txtInvTotal.Text - rs("vCount")
    '                End If
    '                rs.Close()
    '                vFilter = ""

    '            Case "HDE" 'Help Desk (Email)
    '                vFilter += " where Status_Cd=99 "
    '                cm.CommandText = vSql & vFilter

    '                rs = cm.ExecuteReader
    '                If rs.Read Then
    '                    vData_N4 += "<td class='labelBC'>" & rs("vCount") & "</td>"
    '                End If
    '                rs.Close()
    '                vFilter = ""
    '            Case "HDP" 'Help Desk (Phone)
    '                vFilter += " where Status_Cd=99 "
    '                cm.CommandText = vSql & vFilter

    '                rs = cm.ExecuteReader
    '                If rs.Read Then
    '                    vData_N4 += "<td class='labelBC'>" & rs("vCount") & "</td>"
    '                End If
    '                rs.Close()
    '                vFilter = ""
    '            Case "EBE" 'Exceptions - Budget Exceed
    '                vFilter += " where Status_Cd=99 "
    '                cm.CommandText = vSql & vFilter

    '                rs = cm.ExecuteReader
    '                If rs.Read Then
    '                    vData_N4 += "<td class='labelBC'>" & rs("vCount") & "</td>"
    '                End If
    '                rs.Close()
    '                vFilter = ""
    '            Case "EO" 'Exception - Others
    '                vFilter += " where Status_Cd=99 "
    '                cm.CommandText = vSql & vFilter

    '                rs = cm.ExecuteReader
    '                If rs.Read Then
    '                    vData_N4 += "<td class='labelBC'>" & rs("vCount") & "</td>"
    '                End If
    '                rs.Close()
    '                vFilter = ""
    '        End Select
    '    Next
    '    vData_N4 += "</tr>"


    '    c.Close()
    '    c.Dispose()
    '    cm.Dispose()
    'End Sub

    'Private Sub GetProcessed_As_of_12_noon()
    '    Dim c As New SqlClient.SqlConnection(connStr)
    '    Dim cm As New SqlClient.SqlCommand
    '    Dim rs As SqlClient.SqlDataReader
    '    Dim vSql As String = ""
    '    Dim vFilter As String = ""

    '    cm.Connection = c
    '    c.Open()

    '    vSql += "select count(distinct(Doc_Id)) as vCount from dm_ledger a where a.Status_Cd in (13,14) "
    '    vData_N6 += "<tr><td class='labelBL' height='22px'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Processed (As of 11:59am)</td>"

    '    For Each t As String In vRowId
    '        Select Case t
    '            Case "Invoices"
    '                'vFilter += " and Date_Assigned between '" & Format(CDate(txtStartDate.Value), "yyyy-MM-dd") & " 00:00:00' and '" & _
    '                vFilter += "and exists (select User_Id from user_list where Position='Team Leader' and user_list.User_Id = a.CreatedBy ) and " & _
    '                    "exists (select Doc_Id from dm_document where Status_Cd not in (16,19,20) and a.Doc_Id=dm_document.Doc_Id) " & _
    '                    "and TranDate between '" & _
    '                        Format(CDate(txtDateE.Text), "yyyy-MM-dd") & " 00:00:00' and '" & _
    '                        Format(CDate(txtDateE.Text), "yyyy-MM-dd") & " 11:59:59' " & _
    '                    "and a.Doc_Id not in " & _
    '                    "(select distinct Doc_Id from dm_ledger b where  " & _
    '                    "b.Status_Cd in (13,14) and exists " & _
    '                    "(select Doc_Id from dm_document where Status_Cd not in (16,19,20) and b.Doc_Id=dm_document.Doc_Id) " & _
    '                    "and b.TranDate between '" & _
    '                        Format(CDate(txtDateE.Text), "yyyy-MM-dd") & " 12:00:00' and '" & _
    '                        Format(CDate(txtDateE.Text), "yyyy-MM-dd") & " 23:59:59') "

    '                cm.CommandText = vSql & vFilter
    '                'Response.Write(cm.CommandText)
    '                rs = cm.ExecuteReader

    '                If rs.Read Then
    '                    vData_N6 += "<td class='labelBC_r'>(" & rs("vCount") & ")</td>"
    '                    txtInvTotal.Text = txtInvTotal.Text - rs("vCount")
    '                End If
    '                rs.Close()
    '                vFilter = ""

    '            Case "HDE" 'Help Desk (Email)
    '                vFilter += " "
    '                cm.CommandText = vSql & vFilter

    '                rs = cm.ExecuteReader
    '                If rs.Read Then
    '                    vData_N6 += "<td class='labelBC'>0</td>" '" & rs("vCount") & "
    '                End If
    '                rs.Close()
    '                vFilter = ""
    '            Case "HDP" 'Help Desk (Phone)
    '                vFilter += " "
    '                cm.CommandText = vSql & vFilter

    '                rs = cm.ExecuteReader
    '                If rs.Read Then
    '                    vData_N6 += "<td class='labelBC'>0</td>" '" & rs("vCount") & "
    '                End If
    '                rs.Close()
    '                vFilter = ""
    '            Case "EBE" 'Exceptions - Budget Exceed
    '                vFilter += " "
    '                cm.CommandText = vSql & vFilter

    '                rs = cm.ExecuteReader
    '                If rs.Read Then
    '                    vData_N6 += "<td class='labelBC'>0</td>" '" & rs("vCount") & "
    '                End If
    '                rs.Close()
    '                vFilter = ""
    '            Case "EO" 'Exception - Others
    '                vFilter += " "
    '                cm.CommandText = vSql & vFilter

    '                rs = cm.ExecuteReader
    '                If rs.Read Then
    '                    vData_N6 += "<td class='labelBC'>0</td>" '" & rs("vCount") & "
    '                End If
    '                rs.Close()
    '                vFilter = ""
    '        End Select
    '    Next
    '    vData_N6 += "</tr>"


    '    c.Close()
    '    c.Dispose()
    '    cm.Dispose()
    'End Sub

    'Private Sub GetProcessed_After_12_noon()
    '    Dim c As New SqlClient.SqlConnection(connStr)
    '    Dim cm As New SqlClient.SqlCommand
    '    Dim rs As SqlClient.SqlDataReader
    '    Dim vSql As String = ""
    '    Dim vFilter As String = ""

    '    cm.Connection = c
    '    c.Open()

    '    vSql += "select count(distinct(Doc_Id)) as vCount from dm_ledger where Status_Cd in (13,14) "
    '    vData_N7 += "<tr><td class='labelBL' height='22px'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Processed After 12 noon</td>"

    '    For Each t As String In vRowId
    '        Select Case t
    '            Case "Invoices"

    '                vFilter += "and exists (select User_Id from user_list where Position='Team Leader' and user_list.User_Id = dm_ledger.CreatedBy ) " & _
    '                    "and exists (select Doc_Id from dm_document where Status_Cd not in (16,19,20) " & _
    '                    "and dm_ledger.Doc_Id=dm_document.Doc_Id) and TranDate between '" & _
    '                        Format(CDate(txtDateE.Text), "yyyy-MM-dd") & " 12:00:00' and '" & _
    '                        Format(CDate(txtDateE.Text), "yyyy-MM-dd") & " 23:59:59'"
    '                cm.CommandText = vSql & vFilter

    '                'Response.Write(cm.CommandText)
    '                rs = cm.ExecuteReader

    '                If rs.Read Then
    '                    vData_N7 += "<td class='labelBC_r'>(" & rs("vCount") & ")</td>"
    '                    txtInvTotal.Text = txtInvTotal.Text - rs("vCount")
    '                End If
    '                rs.Close()
    '                vFilter = ""

    '            Case "HDE" 'Help Desk (Email)
    '                vFilter += " "
    '                cm.CommandText = vSql & vFilter

    '                rs = cm.ExecuteReader
    '                If rs.Read Then
    '                    vData_N7 += "<td class='labelBC'>0</td>" '" & rs("vCount") & "
    '                End If
    '                rs.Close()
    '                vFilter = ""
    '            Case "HDP" 'Help Desk (Phone)
    '                vFilter += " "
    '                cm.CommandText = vSql & vFilter

    '                rs = cm.ExecuteReader
    '                If rs.Read Then
    '                    vData_N7 += "<td class='labelBC'>0</td>" '" & rs("vCount") & "
    '                End If
    '                rs.Close()
    '                vFilter = ""
    '            Case "EBE" 'Exceptions - Budget Exceed
    '                vFilter += " "
    '                cm.CommandText = vSql & vFilter

    '                rs = cm.ExecuteReader
    '                If rs.Read Then
    '                    vData_N7 += "<td class='labelBC'>0</td>" '" & rs("vCount") & "
    '                End If
    '                rs.Close()
    '                vFilter = ""
    '            Case "EO" 'Exception - Others
    '                vFilter += " "
    '                cm.CommandText = vSql & vFilter

    '                rs = cm.ExecuteReader
    '                If rs.Read Then
    '                    vData_N7 += "<td class='labelBC'>0</td>" '" & rs("vCount") & "
    '                End If
    '                rs.Close()
    '                vFilter = ""
    '        End Select
    '    Next
    '    vData_N7 += "</tr>"


    '    c.Close()
    '    c.Dispose()
    '    cm.Dispose()
    'End Sub

    'Private Sub GetDouble_Send_Wrong_Send_JV_Cancelled_For_GL()
    '    Dim c As New SqlClient.SqlConnection(connStr)
    '    Dim cm As New SqlClient.SqlCommand
    '    Dim rs As SqlClient.SqlDataReader
    '    Dim vSql As String = ""
    '    Dim vFilter As String = ""

    '    cm.Connection = c
    '    c.Open()

    '    vSql += "select count(*) as vCount from dm_document "
    '    vData_N8 += "<tr><td class='labelBL' height='22px'>&nbsp;<b>Double send / Wrong Send (JV) / Cancelled / For GL</b></td>"

    '    For Each t As String In vRowId
    '        Select Case t
    '            Case "Invoices"

    '                vFilter += " where Date_Assigned between '" & _
    '                    Format(CDate(txtDateE.Text), "yyyy-MM-dd") & " 00:00:00' and '" & _
    '                    Format(CDate(txtDateE.Text), "yyyy-MM-dd") & " 23:59:59' and Status_Cd in (19,20) "
    '                cm.CommandText = vSql & vFilter
    '                rs = cm.ExecuteReader

    '                If rs.Read Then
    '                    vData_N8 += "<td class='labelBC_r'>(" & rs("vCount") & ")</td>"
    '                    txtInvTotal.Text = txtInvTotal.Text - rs("vCount")
    '                End If
    '                rs.Close()
    '                vFilter = ""

    '            Case "HDE" 'Help Desk (Email)
    '                vFilter += " where Status_Cd=99 "
    '                cm.CommandText = vSql & vFilter

    '                rs = cm.ExecuteReader
    '                If rs.Read Then
    '                    vData_N8 += "<td class='labelBC'>" & rs("vCount") & "</td>"
    '                End If
    '                rs.Close()
    '                vFilter = ""
    '            Case "HDP" 'Help Desk (Phone)
    '                vFilter += " where Status_Cd=99 "
    '                cm.CommandText = vSql & vFilter

    '                rs = cm.ExecuteReader
    '                If rs.Read Then
    '                    vData_N8 += "<td class='labelBC'>" & rs("vCount") & "</td>"
    '                End If
    '                rs.Close()
    '                vFilter = ""
    '            Case "EBE" 'Exceptions - Budget Exceed
    '                vFilter += " where Status_Cd=99 "
    '                cm.CommandText = vSql & vFilter

    '                rs = cm.ExecuteReader
    '                If rs.Read Then
    '                    vData_N8 += "<td class='labelBC'>" & rs("vCount") & "</td>"
    '                End If
    '                rs.Close()
    '                vFilter = ""
    '            Case "EO" 'Exception - Others
    '                vFilter += " where Status_Cd=99 "
    '                cm.CommandText = vSql & vFilter

    '                rs = cm.ExecuteReader
    '                If rs.Read Then
    '                    vData_N8 += "<td class='labelBC'>" & rs("vCount") & "</td>"
    '                End If
    '                rs.Close()
    '                vFilter = ""
    '        End Select
    '    Next
    '    vData_N8 += "</tr>"


    '    c.Close()
    '    c.Dispose()
    '    cm.Dispose()
    'End Sub

    'Private Sub Balance_for_Today()
    '    Dim c As New SqlClient.SqlConnection(connStr)
    '    Dim cm As New SqlClient.SqlCommand
    '    Dim rs As SqlClient.SqlDataReader
    '    Dim vSql As String = ""
    '    Dim vFilter As String = ""

    '    cm.Connection = c
    '    c.Open()

    '    vSql += "select count(*) as vCount from dm_document "
    '    vData_N9 += "<tr><td class='labelBL' height='22px'>&nbsp;<b>Balance for Today</b></td>"

    '    For Each t As String In vRowId
    '        Select Case t
    '            Case "Invoices"
    '                vData_N9 += "<td class='labelBC'>" & txtInvTotal.Text & "</td>"

    '            Case "HDE" 'Help Desk (Email)
    '                vData_N9 += "<td class='labelBC'>0</td>"

    '            Case "HDP" 'Help Desk (Phone)
    '                vData_N9 += "<td class='labelBC'>0</td>"

    '            Case "EBE" 'Exceptions - Budget Exceed
    '                vData_N9 += "<td class='labelBC'>0</td>"

    '            Case "EO" 'Exception - Others
    '                vData_N9 += "<td class='labelBC'>0</td>"

    '        End Select
    '    Next
    '    vData_N8 += "</tr>"


    '    c.Close()
    '    c.Dispose()
    '    cm.Dispose()
    'End Sub

    ''Protected Sub cmdRefresh_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdRefresh.Click

    ''If txtDateS.Text.Trim <> "" Then
    ''    If Not IsDate(txtDateS.Text) Then
    ''        vScript = "alert('Invalid date and time format in Date from field')"
    ''        Exit Sub
    ''    End If

    ''    If txtDateE.Text.Trim = "" Then
    ''        vScript = "alert('Invalid date and time format in Date To field')"
    ''        Exit Sub
    ''    End If

    ''End If

    ''If txtDateE.Text.Trim <> "" And txtDateS.Text.Trim <> "" Then
    ''    If Not IsDate(txtDateE.Text) Then
    ''        vScript = "alert('Invalid date and time format in Date to field')"
    ''        Exit Sub
    ''    End If

    ''    If CDate(txtDateS.Text) > CDate(txtDateE.Text) Then
    ''        vScript = "alert('From Date should be earlier than To Date')"
    ''        Exit Sub
    ''    End If

    ''    If txtDateS.Text = "" Then
    ''        vScript = "alert('Invalid date and time format in Date From field')"
    ''        Exit Sub
    ''    End If

    ''ElseIf (txtDateE.Text.Trim <> "" And txtDateS.Text.Trim = "") Or _
    ''        (txtDateE.Text.Trim = "" And txtDateS.Text.Trim <> "") Then
    ''    vScript = "alert('You should put valid date values for both From date and To Date fields.');"
    ''    Exit Sub
    ''End If

    ''BuildRecords()
    ''End Sub

    Protected Sub cmdReturn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.Click
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub cmbMonth_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbMonth.SelectedIndexChanged
        cmbDay.Items.Clear()
        For iCtr = 1 To CDate(cmbMonth.SelectedIndex + 2 & "/1/" & cmbYr.SelectedIndex).AddDays(-1).Day
            cmbDay.Items.Add(iCtr)
        Next iCtr

        Dim vDate As Date = CDate(cmbYr.SelectedValue & "/" & cmbMonth.SelectedValue & "/" & cmbDay.SelectedValue)
        tranDate.Text = vDate

    End Sub

    Protected Sub cmbYr_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbYr.SelectedIndexChanged
        cmbDay.Items.Clear()
        For iCtr = 1 To CDate(cmbMonth.SelectedIndex + 2 & "/1/" & cmbYr.SelectedIndex).AddDays(-1).Day
            cmbDay.Items.Add(iCtr)
        Next iCtr

        Dim vDate As Date = CDate(cmbYr.SelectedValue & "/" & cmbMonth.SelectedValue & "/" & cmbDay.SelectedValue)
        tranDate.Text = vDate
    End Sub

    Protected Sub cmbDay_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbDay.SelectedIndexChanged
        Dim vDate As Date = CDate(cmbYr.SelectedValue & "/" & cmbMonth.SelectedValue & "/" & cmbDay.SelectedValue)
        tranDate.Text = vDate
    End Sub
End Class
