﻿Imports denaro.fis
Partial Class assign
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Dim vSender As String = ""
    Dim vReceipient As String = ""
    Dim vDoc_Status As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            vScript = "alert('Your login session has expired. Please re-login again.'); window.close();"
            Exit Sub
        End If
        If Not IsPostBack Then
            Dim c As New SqlClient.SqlConnection(connStr)
            Dim cm As New SqlClient.SqlCommand
            Dim rs As SqlClient.SqlDataReader

            cm.Connection = c
            c.Open()

            pnlTrans.Visible = False
            chkGR.Visible = False
            If Request.Item("s") = 2 Then
                cm.CommandText = "select GRed_By_Client from dm_category where Category_Id=" & Request.Item("catgId")
                Try
                    rs = cm.ExecuteReader
                    If rs.Read Then
                        txtIsGred.Text = rs("GRed_By_Client")
                    End If
                    rs.Close()

                Catch ex As SqlClient.SqlException
                    vScript = "alert('Error occurred while trying to access the Document Status table. Error is: " & _
                        ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                Finally
                    c.Dispose()
                    cm.Dispose()
                End Try
            Else
                txtIsGred.Text = 99
            End If

            If txtIsGred.Text = 1 And Request.Item("currStatus") = 1 Then
                vDoc_Status = 17
            End If

            chkGR.Visible = Val(vDoc_Status) = 17    'for GR
            DataRefresh()
        End If
    End Sub

    Private Sub DataRefresh()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim da As SqlClient.SqlDataAdapter
        Dim ds As New DataSet
        Try
            da = New SqlClient.SqlDataAdapter("select User_Id,Fullname from user_list where POSMenus like 'Active%' and DeptCd like '%" & Session("uid") & "%'", c)


            'Response.Write("select User_Id,Fullname from user_list where POSMenus like 'Active%' and DeptCd like '%" & Session("uid") & "%'")

            da.Fill(ds, "users")
            tblUser.DataSource = ds.Tables("users")
            tblUser.DataBind()
            da.Dispose()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to retrieve list of users. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            ds.Dispose()
            c.Dispose()
        End Try
    End Sub

    Protected Sub cmdCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        tblUser.Enabled = True
        pnlTrans.Visible = False
        pnlValidate.Visible = False
    End Sub

    Protected Sub tblUser_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles tblUser.PageIndexChanging
        tblUser.PageIndex = e.NewPageIndex
        DataRefresh()
    End Sub

    Protected Sub tblUser_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tblUser.SelectedIndexChanged
        tblUser.Enabled = False
        pnlTrans.Visible = True
        pnlValidate.Visible = True
    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand("select UserPassword,Email from user_list where User_Id='test'", c)
        'Dim cm As New SqlClient.SqlCommand("select UserPassword,Email from user_list where User_Id='" & txtUserid.Text & "'", c)
        'Dim rs As SqlClient.SqlDataReader

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "'); window.close();"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try
        SaveChanges(c)

        'Try
        '    rs = cm.ExecuteReader
        '    If rs.Read Then
        '        If Not IsDBNull(rs("UserPassword")) Then
        '            If rs("UserPassword") <> txtPwd.Text Then
        '                vScript = "alert('Invalid password.');"
        '            Else
        '                'authenticated user, process the change
        '                SaveChanges(c)
        '            End If
        '        Else
        '            vScript = "alert('Userid not authorized.'); window.close();"
        '        End If
        '    Else
        '        vScript = "alert('Userid not authorized.'); window.close();"
        '    End If
        '    rs.Close()
        'Catch ex As SqlClient.SqlException
        '    vScript = "alert('Error occurred while trying to save to database. Error is: " & _
        '        ex.Message.Replace(vbCrLf, "").Replace("'", "") & "'); window.close();"
        'Finally
        '    c.Close()
        '    c.Dispose()
        '    cm.Dispose()
        'End Try

    End Sub

    Private Sub SaveChanges(ByRef c As SqlClient.SqlConnection)
        Dim vMail As New System.Net.Mail.SmtpClient
        Dim cm As New SqlClient.SqlCommand
        Dim cmSrc As New SqlClient.SqlCommand
        Dim rsSrc As SqlClient.SqlDataReader
        Dim vDuration As Single = 0
        Dim vDateStart As Date
        Dim EmailOption As Integer = 0
        Dim status As String = ""
        Dim vNextStatus As String = ""

        If txtIsGred.Text = 1 And Request.Item("currStatus") = 1 Then
            vDoc_Status = IIf(chkGR.Checked, Request.Item("s"), 17)
        Else
            vDoc_Status = Request.Item("s")
        End If

        cm.Connection = c
        cmSrc.Connection = c

        cmSrc.CommandText = "select Descr from dm_document_status where Status_cd=" & Request.Item("s")

        Try
            rsSrc = cmSrc.ExecuteReader
            If rsSrc.Read Then
                status = rsSrc("Descr")
            End If
            rsSrc.Close()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to access the Document Status table. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        End Try

        cmSrc.CommandText = "select EmailOption from glsyscntrl"
        Try
            rsSrc = cmSrc.ExecuteReader
            If rsSrc.Read Then
                EmailOption = rsSrc("EmailOption")
            End If
            rsSrc.Close()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to save changes. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        End Try

        'Sender Email
        cmSrc.CommandText = "select Email from user_list where User_Id='" & Session("uid") & "'"
        Try
            rsSrc = cmSrc.ExecuteReader
            If rsSrc.Read Then
                vSender = IIf(IsDBNull(rsSrc("Email")), "", rsSrc("Email"))
            End If
            rsSrc.Close()

            cmSrc.CommandText = "select * from dm_process where Category_Id='" & Request.Item("catgId") & _
                    "' and PrevStatus_Cd='" & Request.Item("currStatus") & "' and Status_Cd='" & Request.Item("s") & "' "
            rsSrc = cmSrc.ExecuteReader
            If rsSrc.Read Then
                vNextStatus = IIf(IsDBNull(rsSrc("NextStep")), "", "NextStatus='" & rsSrc("NextStep") & "',")
            End If
            rsSrc.Close()



        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to get the Sender Email.  Erros is: " & _
                      ex.Message.Replace(vbCrLf, "").Replace("'", "") & "')"

        End Try

        'Receipient Email
        cmSrc.CommandText = "select Email from user_list where User_Id='" & tblUser.SelectedRow.Cells(0).Text & "'"
        Try
            rsSrc = cmSrc.ExecuteReader
            If rsSrc.Read Then
                vReceipient = IIf(IsDBNull(rsSrc("Email")), "", rsSrc("Email"))
            End If
            rsSrc.Close()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to get the Sender Email.  Erros is: " & _
                      ex.Message.Replace(vbCrLf, "").Replace("'", "") & "')"
        End Try


        'save a copy to the documents notes
        cmSrc.CommandText = "select * from dm_document where Doc_Id=" & Request.Item("id")
        Try
            rsSrc = cmSrc.ExecuteReader
            If rsSrc.Read Then
                vDateStart = rsSrc("Date_Encoded")
                If Not IsDBNull(rsSrc("Date_Assigned")) Then
                    vDateStart = CDate(rsSrc("Date_Assigned"))
                End If

                If Request.Item("s") = "14" Then
                    cm.CommandText = "insert into dm_stockcard (TranDate, CreatedBy, Doc_Id, Qty, Status_Cd, Remarks, User_Id) " & _
                            "values ('" & Format(Now, "yyyy/MM/dd HH:mm:ss") & "', '" & Session("uid") & "', " & rsSrc("Doc_Id") & _
                            ", 1, " & Request.Item("s") & ", 'Created by : " & Session("uid") & "', '" & Session("uid") & "')"
                    cm.ExecuteNonQuery()
                End If

                vDuration = Math.Round(DateDiff(DateInterval.Minute, vDateStart, Now) / 60, 2)
                cm.CommandText = "insert into dm_document_notes (Doc_Id,Notes,Date_Encoded,Encoded_By,Emp_Cd," & _
                    "Date_Start,Date_Finish,Duration,Status_Cd,Transfer_To) values (" & rsSrc("Doc_Id") & ",'" & _
                    IIf(IsDBNull(rsSrc("Contents")), "Assignment", rsSrc("Contents")) & "','" & _
                    Format(CDate(rsSrc("Date_Encoded")), "yyyy/MM/dd HH:mm:ss") & "','" & _
                    rsSrc("Encoded_By") & "','" & IIf(IsDBNull(rsSrc("Emp_Cd")), rsSrc("Encoded_By"), rsSrc("Emp_Cd")) & _
                    "','" & Format(vDateStart, "yyyy/MM/dd HH:mm:ss") & _
                    "','" & Format(Now, "yyyy/MM/dd HH:mm:ss") & "'," & vDuration & "," & rsSrc("Status_Cd") & _
                    ", '" & tblUser.SelectedRow.Cells(0).Text & "' )"
                cm.ExecuteNonQuery()


                'insert to lance table dm_ledger
                cm.CommandText = "insert into dm_ledger (Doc_ID, Status_Cd, Category_Cd, TranDate, CreatedBy, IsAssignTo, Supplier_Cd, Remarks, AgencyCd) " & _
                    "values (" & rsSrc("Doc_Id") & ", " & vDoc_Status & ", " & rsSrc("Category_Id") & ", '" & _
                    Format(Now, "yyyy/MM/dd HH:mm:ss") & "', '" & Session("uid") & "', '" & tblUser.SelectedRow.Cells(0).Text & _
                    "', " & rsSrc("Supplier_Cd") & ", '" & txtNotes.Text & "','" & rsSrc("AgencyCd") & "')"
                'Response.Write(cm.CommandText)
                cm.ExecuteNonQuery()




                'now update the record
                cm.CommandText = "update dm_document set DateModify='" & Now() & "', ModifyBy='" & Session("uid") & _
                    "', Contents='" & txtNotes.Text & "',PrevStatus=Status_Cd," & vNextStatus & "Status_Cd=" & vDoc_Status & _
                    ",Emp_Cd='" & tblUser.SelectedRow.Cells(0).Text & _
                    "',Date_Assigned='" & Format(Now, "yyyy/MM/dd HH:mm:ss") & _
                    "',GRedClient=" & IIf(chkGR.Checked, 1, 0) & _
                    " where Doc_Id=" & rsSrc("Doc_Id")
                cm.ExecuteNonQuery()

            End If
            rsSrc.Close()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to save changes. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            cm.Dispose()
            cmSrc.Dispose()
        End Try

        'Email receipient
        Dim vBody As String = ""
        If EmailOption = 1 Then
            'Response.Write(vSender & " Rece:" & vReceipient)

            With vMail
                If vReceipient <> "" Then
                    vBody = "The Document Id " & vDoc_Status & " was assigned to you by " & Session("uid") & _
                        " for " & status & ". Login to DTS site to view the document. "
                End If

                Try
                    .Send("Document Tracking System", vReceipient, "Notification", vBody)
                Catch ex As Exception
                    vScript = "alert('Successfully Submitted Application but with Error in sending mail to " & _
                        vReceipient & "');" & _
                        "opener.document.getElementById('txtRefreshList').value='refresh'; " & _
                        "opener.document.form1.submit(); window.close();"

                End Try
            End With
        End If
    End Sub
End Class
