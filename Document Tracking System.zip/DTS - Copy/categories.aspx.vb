Imports denaro.fis

Partial Class categories
    Inherits System.Web.UI.Page
    Public vScript As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = Nothing Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If
        If Not IsPostBack Then
            If CanRun(Session("caption"), Request.Item("id")) Then
                DataRefresh()
            Else
                Session("denied") = "1"
                Server.Transfer("main.aspx")
            End If
        End If

        If Not CanRun(Session("caption"), 20) Then
            btnAdd.Enabled = False
        End If
        If Not CanRun(Session("caption"), 21) Then
            btnEdit.Enabled = False
        End If
        If Not CanRun(Session("caption"), 22) Then
            btnDelete.Enabled = False
        End If

        DataRefresh()

    End Sub
    Private Sub DataRefresh()
        Dim c As New sqlclient.sqlConnection(connStr)
        Dim da As sqlclient.sqlDataAdapter
        Dim ds As New DataSet

        da = New SqlClient.SqlDataAdapter("select Category_Id,Descr,GRed_By_Client," & _
                                          "(select Descr from hr_dept_ref where Dept_Cd=In_Charge) as In_Charge from dm_category ORDER BY descr", c)
        
        da.Fill(ds, "keyword")
        tblkeywords.DataSource = ds.Tables("keyword")
        tblkeywords.DataBind()
        da.Dispose()
        ds.Dispose()
        c.Dispose()
    End Sub

    Protected Sub btnClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Session.Remove("kid")
        Session.Remove("vline")
        Session.Remove("kdescr")
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub tblkeywords_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles tblkeywords.PageIndexChanging
        tblkeywords.PageIndex = e.NewPageIndex
        DataRefresh()
    End Sub

    Protected Sub btnEdit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnEdit.Click
        If tblkeywords.SelectedIndex >= 0 Then
            Session("vline") = tblkeywords.SelectedRow.Cells(0).Text
            vScript = "btnAdd_onclick('e');"
        Else
            vScript = "alert('You must first select a record before you can use the Edit command.');"
        End If
    End Sub

    Protected Sub btnDelete_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        If tblkeywords.SelectedIndex >= 0 Then
            Dim c As New SqlClient.SqlConnection
            Dim cm As New SqlClient.SqlCommand

            EventLog(Session("uid"), Request.ServerVariables("REMOTE_ADDR"), "DELETE", "", "", "Category Item " & tblkeywords.SelectedRow.Cells(0).Text & _
                     "-" & CleanVar(tblkeywords.SelectedRow.Cells(1).Text), "Category")

            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c

            cm.CommandText = "DELETE FROM dm_category WHERE Category_Id='" & tblkeywords.SelectedRow.Cells(0).Text & "'"
            cm.ExecuteNonQuery()

            cm.Dispose()
            c.Close()

            vScript = "alert('Record was successfully deleted.');"
            Session.Remove("vline")
            DataRefresh()
            tblkeywords.SelectedIndex = -1
        Else
            vScript = "alert('You must first select a record before you can use the Delete command.');"
        End If
    End Sub

    Protected Sub btnDelete_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnDelete.Init
        'If Session("vline") = "" Then
        '    vScript = "alert('You must first select a record before you can use the Set Properties.');"
        '    Exit Sub
        'End If
        btnDelete.Attributes.Add("onclick", "return ask();")
    End Sub

    Protected Sub btnAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        vScript = "btnAdd_onclick('a');"
    End Sub

    Protected Sub btnSetprop_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSetprop.Click

        If tblkeywords.SelectedIndex >= 0 Then
            vScript = "showprop('addCat','','');"
        Else
            vScript = "alert('You must first select a record before you can use the Set Properties.');"
            Exit Sub
        End If
    End Sub
    Protected Sub tblkeywords_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tblkeywords.SelectedIndexChanged
        Session("vline") = tblkeywords.SelectedRow.Cells(0).Text
    End Sub

    Protected Sub btnLocProp_Click(sender As Object, e As EventArgs) Handles btnLocProp.Click
        'Response.Write(tblkeywords.SelectedRow.Cells(1).Text)

        If tblkeywords.SelectedIndex >= 0 Then
            vScript = "showprop('addLoc'," & tblkeywords.SelectedRow.Cells(0).Text & ",'" & tblkeywords.SelectedRow.Cells(1).Text & "');"
        Else
            vScript = "alert('You must first select a record before you can use the Set Location Properties.');"
            Exit Sub
        End If

    End Sub
End Class
