﻿Imports denaro.fis
Partial Class supplier
    Inherits System.Web.UI.Page
    Public vScript As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = Nothing Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If
        If CanRun(Session("caption"), Request.Item("id")) Then
            DataRefresh()
        Else
            Session("denied") = 1
            Server.Transfer("main.aspx")
        End If

        For iCtr = 1 To 6
            cmbShow.Items.Add(15 * iCtr)
        Next iCtr

        btnAdd.Enabled = CanRun(Session("caption"), 6)
        btnEdit.Enabled = CanRun(Session("caption"), 7)
        btnDelete.Enabled = CanRun(Session("caption"), 8)

    End Sub
    Private Sub DataRefresh()
        Dim c As New sqlclient.sqlConnection(connStr)
        Dim da As sqlclient.sqlDataAdapter
        Dim ds As New DataSet
        Dim vFilter As String = ""


        If txtSearch.Text.Trim <> "" Then
            vFilter = " where suppliername like '%" & txtSearch.Text.Trim & "%'"
        End If

        da = New SqlClient.SqlDataAdapter("SELECT suppliercd,suppliername,contactperson,contactno,faxno,address,ParentDealerCd,Terms " & _
                                      "FROM supplier " & vFilter & " ORDER BY suppliername", c)

        da.Fill(ds, "supplier")
        tblSupplier.DataSource = ds.Tables("supplier")
        tblSupplier.DataBind()

        lblTotalDocs.Text = "<b>Total Documents Retrieved : " & tblSupplier.DataSource.Rows.Count & "</b>"

        da.Dispose()
        ds.Dispose()
        c.Close()
    End Sub

    Protected Sub tblSupplier_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles tblSupplier.PageIndexChanging
        tblSupplier.PageIndex = e.NewPageIndex
        DataRefresh()
    End Sub

    Protected Sub btnEdit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnEdit.Click
        Dim vline As String = tblSupplier.SelectedRow.Cells(0).Text
        If vline <> "" Then
            Session("vline") = vline
            vScript = "btnAdd_onclick();"
        Else
            vScript = "alert('You must first select a record before you can use the Edit command.');"
        End If
    End Sub

    Protected Sub btnDelete_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        If tblSupplier.SelectedIndex >= 0 Then
            Dim c As New sqlclient.sqlConnection
            Dim cm As New sqlclient.sqlCommand

            EventLog(Session("uid"), Request.ServerVariables("REMOTE_ADDR"), "DELETE", "", "", "Supplier " & tblSupplier.SelectedRow.Cells(0).Text & _
                     "-" & tblSupplier.SelectedRow.Cells(1).Text, "Supplier")

            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c
            cm.CommandText = "DELETE FROM supplier WHERE suppliercd='" & tblSupplier.SelectedRow.Cells(0).Text & "'"
            cm.ExecuteNonQuery()
            cm.Dispose()
            c.Close()
            vScript = "alert('Record was successfully deleted.');"
            DataRefresh()
            tblSupplier.SelectedIndex = -1
        Else
            vScript = "alert('You must first select a record before you can use the Delete command.');"
        End If
    End Sub

    Protected Sub btnDelete_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnDelete.Init
        btnDelete.Attributes.Add("onclick", "return ask();")
    End Sub

    Protected Sub btnClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub btnAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        Session("vline") = ""
        vScript = "btnAdd_onclick();"
    End Sub

    
    Protected Sub cmbShow_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbShow.SelectedIndexChanged
        tblSupplier.PageSize = cmbShow.SelectedValue
        DataRefresh()
    End Sub

    Protected Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        DataRefresh()
    End Sub
End Class
