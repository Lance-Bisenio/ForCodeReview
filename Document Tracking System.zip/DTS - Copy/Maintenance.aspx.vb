Imports denaro
Partial Class maintenance
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Dim vClass As String = "odd"

    Dim vRef As String
    Dim vSearchKey As String
    Dim vSearchType As String
    Dim vReturnVal As String
    Dim vSql As String
    Dim vTableName As String
    Dim vDataType As String
    Dim vSortBy As String
    Dim vColFormat As String
    Dim vColTitle As String
    Dim vColFields As String
    Dim vReportName As String
    Dim vFields() As String
    Dim vTitle() As String
    Dim vTypes() As String
    Dim vColor As String
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If
        If Not CanRun(Session("caption"), Request.Item("id")) Then
            Session("denied") = "1"
            Server.Transfer("main.aspx")
            Exit Sub
        End If
        
        Dim c As New sqlclient.sqlconnection(connStr)
        c.Open()
        SYSTEMNAME = "VIEWLOGS"
        Dim cm As New SqlClient.SqlCommand("select SeqId,Label_Caption,SearchKey,SearchType,Return_Val,SqlCmd,SortBy," & _
                "ColFormat,ColTitle,ColFields,Dependencies,RunProg from menu_rights where SystemName='DOCMAN' and Menu_Caption='" & Request.Item("id") & "'", c)

        Dim rs As sqlclient.sqldatareader
        rs = cm.ExecuteReader
        If Not rs.Read Then
            vScript = "alert('Module cannot be found. Please contact your administrator.');"
            rs.Close()
            GoTo skip
        End If
        'lblCaption.Text = "Codeset Maintenance for " & rs("Label_Caption")

        vSearchKey = IIf(IsDBNull(rs("SearchKey")), "", rs("SearchKey"))
        vSearchType = IIf(IsDBNull(rs("SearchType")), "", rs("SearchType"))
        vReturnVal = IIf(IsDBNull(rs("Return_Val")), "", rs("Return_Val"))
        vSql = IIf(IsDBNull(rs("SqlCmd")), "", rs("SqlCmd"))
        vTableName = IIf(IsDBNull(rs("Dependencies")), "", rs("Dependencies"))
        vSortBy = IIf(IsDBNull(rs("SortBy")), "", rs("SortBy"))
        vColFormat = IIf(IsDBNull(rs("ColFormat")), "", rs("ColFormat"))
        vColTitle = IIf(IsDBNull(rs("ColTitle")), "", rs("ColTitle"))
        vColFields = IIf(IsDBNull(rs("ColFields")), "", rs("ColFields"))
        vDataType = IIf(IsDBNull(rs("RunProg")), "", rs("RunProg"))
        vReportName = IIf(IsDBNull(rs("SeqId")), "", rs("SeqId"))
skip:
        c.Close()
        cm.Dispose()
        If Not IsPostBack Then
            lblScrId.Value = Request.Item("id")
            DataRefresh()
        Else
            DataRefresh()
        End If
    End Sub
    Protected Sub cmdReturn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.Click
        Server.Transfer("main.aspx")
    End Sub
    Private Sub DataRefresh()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim da As SqlClient.SqlDataAdapter
        Dim ds As New DataSet
        Dim vFilter As String = " "
        Dim vFields() As String = vColFields.Split("|")
        Dim vFieldName() As String = vColTitle.Split("|")
        Dim vSQLCmd As String = ""

        If txtSearch.Text.Trim() <> "" Then
            vFilter = " where " & vSearchKey & " like '" & _
                txtSearch.Text & "%' "
        End If

        For i As Integer = 0 To UBound(vFields)
            vSQLCmd += vFields(i) & " as [" & vFieldName(i) & "],"
        Next
        If vSQLCmd <> "" Then
            vSQLCmd = Mid(vSQLCmd, 1, Len(vSQLCmd) - 1)
            Try
                da = New SqlClient.SqlDataAdapter("select " & vSQLCmd & " from " & _
                    vTableName & vFilter & vSortBy, c)
                da.Fill(ds, "maintenance")
                tblMaintenance.DataSource = ds.Tables("maintenance")
                tblMaintenance.DataBind()
                da.Dispose()
                ds.Dispose()
                c.Dispose()
            Catch ex As SqlClient.SqlException
                vScript = "alert(""" & ex.Message.Replace(vbCrLf, "").Replace("'", "") & """);"
            End Try
        Else
            vScript = "alert(""Please check the database. No column list is defined. Seek Administrator's assistance."");"
        End If
    End Sub

    Protected Sub tblMaintenance_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles tblMaintenance.PageIndexChanging
        tblMaintenance.PageIndex = e.NewPageIndex
        DataRefresh()
    End Sub

    Protected Sub tblMaintenance_RowCreated(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles tblMaintenance.RowCreated
        'e.Row.CssClass = vClass
        'If vClass = "odd" Then
        '    vClass = "even"
        'Else
        '    vClass = "odd"
        'End If
    End Sub

    Protected Sub cmdDelete_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDelete.Click
        If tblMaintenance.SelectedIndex >= 0 Then

            Dim c As New sqlclient.sqlconnection(connStr)
            Dim cm As New sqlclient.sqlcommand

            cm.Connection = c
            cm.CommandText = "delete from " & vTableName & " where " & vReturnVal & "='" & _
                tblMaintenance.SelectedRow.Cells(1).Text & "'"
            Try
                c.Open()
                cm.ExecuteNonQuery()
                c.Close()
                vScript = "alert('Record successfully deleted.');"
                DataRefresh()
            Catch ex As DataException
                vScript = "alert('An error occurred while trying to delete the selected record. ');"
            End Try
            c.Dispose()
            cm.Dispose()
        Else
            vScript = "alert('Please select item first.');"
        End If
    End Sub

    Protected Sub tblMaintenance_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tblMaintenance.SelectedIndexChanged
        txtvalue.Value = tblMaintenance.SelectedRow.Cells(1).Text.Replace("&amp;", "&")

        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand("select Frozen from " & vTableName & " where " & vReturnVal & "='" & txtvalue.Value & "'", c)
        Dim rs As SqlClient.SqlDataReader
        Dim vFrozen As Boolean = False

        Try
            c.Open()
            rs = cm.ExecuteReader
            If rs.Read Then
                vFrozen = rs("Frozen") = 1
            End If
            rs.Close()
        Catch ex As SqlClient.SqlException
        Finally
            c.Close()
            cm.Dispose()
            c.Dispose()
        End Try
        cmdDelete.Enabled = Not vFrozen
        cmdEdit.Disabled = vFrozen
    End Sub

    Protected Sub cmdSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSearch.Click
        DataRefresh()
    End Sub

    Protected Sub cmdA_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdA.Click, _
        cmdB.Click, cmdC.Click, cmdD.Click, cmdE.Click, cmdF.Click, cmdG.Click, cmdH.Click, cmdI.Click, cmdJ.Click, _
        cmdK.Click, cmdL.Click, cmdM.Click, cmdN.Click, cmdO.Click, cmdP.Click, cmdQ.Click, cmdR.Click, cmdS.Click, _
        cmdT.Click, cmdU.Click, cmdV.Click, cmdW.Click, cmdX.Click, cmdY.Click, cmdZ.Click
        txtSearch.Text = CType(sender, WebControls.LinkButton).Text
        DataRefresh()
    End Sub

  
End Class
