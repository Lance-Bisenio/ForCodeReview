﻿Imports denaro.fis
Partial Class batchupload
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Public vDump As String = ""
    Dim iIdx As Integer = 1
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Dim MachineIP = Request.ServerVariables("REMOTE_ADDR")
            Dim vSQL As String = ""
            Dim IsSessionActive As Integer = 0


            vSQL = "select top 1 User_Id from audit where MachineId='" & MachineIP & "' and " _
                & "TranDate between '" & Format(Now, "yyyy-MM-dd") & " 00:00' and '" & Format(Now, "yyyy-MM-dd") & " 23:59' " _
                & "order by trandate desc"

            Session("uid") = GetRef(vSQL, "")

            vSQL = "select * from user_list where User_Id='" & Session("uid") & "'"

            Dim c As New SqlClient.SqlConnection(connStr)
            Dim cm As New SqlClient.SqlCommand(vSQL, c)
            Dim rs As SqlClient.SqlDataReader

            c.Open()
            rs = cm.ExecuteReader
            If rs.Read Then
                IsSessionActive = 1
                Session("caption") = IIf(IsDBNull(rs("Caption")), "", rs("Caption"))
                Session("userlevel") = IIf(IsDBNull(rs("UserLevel")), 0, rs("UserLevel"))
                Session("agencylist") = IIf(IsDBNull(rs("AgencyCd")), "", rs("AgencyCd"))

                Session("Catglist") = IIf(IsDBNull(rs("CategoryCd")), "", rs("CategoryCd"))
                Session("Statuslist") = IIf(IsDBNull(rs("StatusCd")), "", rs("StatusCd"))
                Session("deptlist") = IIf(IsDBNull(rs("DeptCd")), "", rs("DeptCd"))

                Session("rclist") = IIf(IsDBNull(rs("Rc_Cd")), "", rs("Rc_Cd"))

                Session("sectionlist") = IIf(IsDBNull(rs("SectionCd")), "", rs("SectionCd"))
                Session("divlist") = IIf(IsDBNull(rs("DivCd")), "", rs("DivCd"))
                Session("unitlist") = IIf(IsDBNull(rs("UnitCd")), "", rs("UnitCd"))
                Session("typelist") = IIf(IsDBNull(rs("EmploymentType")), "", rs("EmploymentType"))

                Session("EmpPos") = IIf(IsDBNull(rs("Position")), "", "Position : " & rs("Position"))
                Session("EmpEmail") = IIf(IsDBNull(rs("Email")), "", "Email : " & rs("Email"))
                Session("EmpFullName") = IIf(IsDBNull(rs("FullName")), "", rs("FullName"))

                Session("sessionid") = Session.SessionID

            End If
            rs.Close()
            c.Close()
            c.Dispose()
            cm.Dispose()

            If IsSessionActive = 0 Then
                Server.Transfer("index.aspx")
            End If
        End If

        If Not CanRun(Session("caption"), Request.Item("id")) Then
            Session("denied") = 1
            Server.Transfer("main.aspx")
        End If

        If Not IsPostBack Then
            Dim c As New SqlClient.SqlConnection(connStr)
            Dim cm As New SqlClient.SqlCommand
            Dim rs As SqlClient.SqlDataReader

            Try
                c.Open()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to connect to database. Error is: " _
                    & ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                c.Dispose()
                cm.Dispose()
                Exit Sub
            End Try
            cm.Connection = c

            'cmbYr.Items.Clear()
            'cmbM.Items.Clear()
            'For iCtr = 2011 To Year(Now) + 2
            '    cmbYr.Items.Add(iCtr)
            'Next iCtr
            'cmbYr.SelectedValue = Year(Now)

            'For iCtr = 1 To 12
            '    cmbM.Items.Add(iCtr)
            'Next iCtr
            'cmbM.SelectedValue = Month(Now)

            BuildCombo("select AgencyCd,AgencyName from agency where exists (select User_Id from rights_list where User_Id='" _
                       & Session("uid") & "' and property='agency' and Property_Value=AgencyCd) order by AgencyName", cmbComp)

            BuildCombo("select Category_Id,Descr from dm_Category where exists (select User_Id from rights_list where User_Id='" _
                       & Session("uid") & "' and property='Category' and Property_Value=Category_Id) order by Descr", cmbCatg)

            'cm.CommandText = "select Descr from dm_category where Descr='" & Session("catgid").Replace("_", " ") & "' "
            'cm.CommandText = "select Descr from dm_category where Category_Id=" & Session("catgid")

            'Try
            '    rs = cm.ExecuteReader
            '    If rs.Read Then
            '        lblCategory.Text = IIf(IsDBNull(rs("Descr")), "Unknown", rs("Descr"))
            '    End If
            '    rs.Close()
            '    cm.CommandText = "select UploadPath from glsyscntrl"
            '    rs = cm.ExecuteReader
            '    If rs.Read Then
            '        txtUploadPath.Text = IIf(IsDBNull(rs("UploadPath")), "not yet defined", rs("UploadPath")) & "\" & Session("catgDescr")
            '        'Response.Write(txtUploadPath.Text)
            '    End If
            '    rs.Close()
            'Catch ex As SqlClient.SqlException
            '    vScript = "alert('Error occurred while trying to retrieve records. Error is: " & _
            '        ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            'Finally
            '    c.Close()
            '    c.Dispose()
            '    cm.Dispose()
            'End Try

            cm.CommandText = "select UploadPath from glsyscntrl"
            Try
                rs = cm.ExecuteReader
                If rs.Read Then
                    lblSystemPath.Text = IIf(IsDBNull(rs("UploadPath")), "not yet defined", rs("UploadPath")) & "\"
                    txtUploadPath.Text = cmbComp.SelectedValue
                    'Response.Write(txtUploadPath.Text)
                End If
                rs.Close()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to retrieve records. Error is: " & ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            Finally
                c.Close()
                c.Dispose()
                cm.Dispose()
            End Try
        End If

        If txtRefreshList.Value <> "" Then
            Dim vDir As New IO.DirectoryInfo(txtUploadPath.Text)
            vDump = ""
            iIdx = 1
            GetDir(vDir)
            txtCount.Value = iIdx
        End If
    End Sub

    Protected Sub cmdReturn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.Click
        'Session.Remove("catgid")
        'Server.Transfer("docmgr.aspx")
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub cmdRefresh_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdRefresh.Click
        'Dim vDir As New IO.DirectoryInfo(txtUploadPath.Text & "\" & cmbYr.SelectedValue & "\" & cmbM.SelectedValue)

        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim vDocPath As String = ""

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try
        cm.Connection = c
        cm.CommandText = "select DocPath from dm_category_location where AgencyCd='" & cmbComp.SelectedValue & "' and Category_Id='" & cmbCatg.SelectedValue & "'"

        'lblFilename.Text = cm.CommandText
        Try
            rs = cm.ExecuteReader
            If rs.Read Then
                vDocPath = rs("DocPath")
            End If
            rs.Close()
            
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to retrieve records. Error is: " & ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            c.Dispose()
            cm.Dispose()
        End Try


        'Dim vDir As New IO.DirectoryInfo(Server.MapPath(".") & "\" & lblSystemPath.Text & cmbComp.SelectedValue & "\")
        Dim vDir As New IO.DirectoryInfo(Server.MapPath(".") & vDocPath)

        'vScript = "alert(" & vDir.ToString & ");"

        txtUploadPath.Text = cmbComp.SelectedValue
        lblFilename.Text = ""
        lblFilename.Text = vDir.ToString ' Server.MapPath(".") & vDocPath ' cmbComp.SelectedValue

        vDump = ""
        iIdx = 1

        GetDir(vDir)

        txtCount.Value = iIdx
    End Sub

    Private Sub GetDir(ByVal vDir As IO.DirectoryInfo)
        Dim vSub() As IO.DirectoryInfo = vDir.GetDirectories()
        Dim vFiles() As IO.FileInfo = vDir.GetFiles()
        Dim vAttr As New IO.FileAttributes
        Dim iDocCtr As Integer = 0
        Dim iCtr As Integer

        For iCtr = 0 To UBound(vFiles)
            vAttr = vFiles(iCtr).Attributes
            'vAttr = ""

            If vAttr <> IO.FileAttributes.System Then '+ IO.FileAttributes.Archive Then

                Dim vFilename As String = vFiles(iCtr).FullName
                Dim vExt As String = vFiles(iCtr).Extension

                Try
                    vFilename = Mid(vFilename, InStr(vFilename, "Uploaded"))
                Catch ex As Exception
                    vScript = "alert('Error occurred while trying to retrieve records. Error is: " & ex.Message.Replace(vbCrLf, "").Replace("'", "") & "\n Or the directory you are looking is undefined.');"
                    vDump = "&nbsp;<b style='color:red;'>Invalid Path.</b>"
                    Exit Sub
                End Try

                vFilename = vFilename.Replace("\", "/")
                If Not vFilename.ToLower.Contains("thumbs.db") Then
                    vDump += "<input type='checkbox' id='chk_" & iIdx & "' name='chk_" & iIdx & "' value='" & vFilename _
                        & "' /><a id='vDocItem_" & iIdx & "' onclick='previewfile(""" & vFilename & """);' class='textLinks' style='cursor:pointer;'>" _
                        & "<img src='images/pdf-icon.png' style='width:14x; height:14px; border: 0px;' title='" _
                        & vFilename & "' /> " & vFilename.Substring(9) & "</a><br id='vBrItem_" & iIdx & "' />"
                    iIdx += 1
                    iDocCtr += 1
                End If

            End If
        Next

        lblTotalDocs.Text = "Total Docs Retrieved : " & iDocCtr

        If vDump = "" Then
            'vDump = "&nbsp;<b style='color:red;'>No record found.</b>"
        End If

        For iCtr = 0 To UBound(vSub)
            GetDir(vSub(iCtr))
        Next
    End Sub

 
End Class
