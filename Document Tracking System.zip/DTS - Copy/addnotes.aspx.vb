﻿Imports denaro
Partial Class addnotes
    Inherits System.Web.UI.Page
    Public vscript As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If
        If Not IsPostBack Then
            DataRefresh()
        End If
    End Sub
    Private Sub DataRefresh()
        Dim c As New sqlclient.sqlConnection(connStr)
        Dim cm As New sqlclient.sqlCommand
        Dim rs As sqlclient.sqlDataReader

        txtDocId.Text = Session("docid")

        If Session("notesid") > 0 Then
            Try
                c.Open()
                cm.Connection = c
                cm.CommandText = "select Notes,SubPath from dm_document_notes where notes_id=" & Session("notesid") & " and doc_id=" & Session("docid")
                rs = cm.ExecuteReader
                If rs.Read Then
                    txtNotes.Text = IIf(IsDBNull(rs("Notes")), "", rs("Notes"))
                    txtFiles.Text = IIf(IsDBNull(rs("SubPath")), "", rs("SubPath"))
                End If
                rs.Close()

            Catch ex As sqlclient.sqlException
                vscript = "alert('An error occur while trying to access the database.  Error is:" & _
                               ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            Finally
                c.Dispose()
                cm.Dispose()
                c.Close()
            End Try
        End If
        btnRemoveAttachment.Enabled = txtFiles.Text <> ""
    End Sub
    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Dim c As New sqlclient.sqlConnection(connStr)
        Dim cm As New sqlclient.sqlCommand
        Dim rs As sqlclient.sqlDataReader
        Dim vType As String = ""
        Dim vTargetFilename As String
        Dim lastrec As Integer = 1
        Dim vFilename As String = ""
        Try

            c.Open()
            cm.Connection = c
        Catch ex As sqlclient.sqlException
            vscript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        Try
            If Session("notesid") = 0 Then
                If txtFileUpload.FileName <> "" Then
                    If txtFileUpload.FileName.LastIndexOf(".") >= 0 Then
                        vType = txtFileUpload.FileName.Substring(txtFileUpload.FileName.LastIndexOf("."))
                    End If

                    cm.CommandText = "select top 1 Notes_Id from dm_document_notes order by Notes_Id desc"
                    rs = cm.ExecuteReader
                    If rs.Read Then
                        lastrec = rs("Notes_Id") + 1
                    End If
                    rs.Close()

                    vTargetFilename = Server.MapPath(".") & "\uploaded\" & Session.SessionID & "-" & _
                        Session("uid") & lastrec & IIf(vType <> "", vType, "")

                    txtFileUpload.SaveAs(vTargetFilename)

                    vFilename = "uploaded/" & Session.SessionID & "-" & Session("uid") & lastrec & IIf(vType <> "", vType, "")
                End If

                cm.CommandText = "insert into dm_document_notes(doc_id,notes,date_encoded,encoded_by,SubPath)values(" & _
                              Session("docid") & ",'" & CleanVar(txtNotes.Text) & "','" & Format(Now, "yyyy/MM/dd") & _
                              "','" & Session("uid") & "','" & vFilename & "')"

                EventLog(Session("uid"), Request.ServerVariables("REMOTE_ADDR"), "ADD", "", "", "Adding Notes " & Session("docid") & _
                         "-" & CleanVar(txtNotes.Text), "Notes")

            Else
                vFilename = txtFiles.Text
                If txtFileUpload.FileName <> "" Then
                    If txtFiles.Text <> "" Then
                        vTargetFilename = Server.MapPath(".") & "\" & txtFiles.Text.Replace("/", "\")
                    Else
                        If txtFileUpload.FileName.LastIndexOf(".") >= 0 Then
                            vType = txtFileUpload.FileName.Substring(txtFileUpload.FileName.LastIndexOf("."))
                        End If

                        vTargetFilename = Server.MapPath(".") & "\uploaded\" & Session.SessionID & "-" & _
                            Session("uid") & Session("notesid") & IIf(vType <> "", vType, "")
                        vFilename = "uploaded/" & Session.SessionID & "-" & Session("uid") & Session("notesid") & IIf(vType <> "", vType, "")
                    End If

                    txtFileUpload.SaveAs(vTargetFilename)
                    txtFiles.Text = vFilename
                End If

                cm.CommandText = "update dm_document_notes set notes='" & CleanVar(txtNotes.Text) & _
                                 "',SubPath='" & vFilename & "' where doc_id=" & Session("docid") & " and notes_id=" & Session("notesid")

                EventLog(Session("uid"), Request.ServerVariables("REMOTE_ADDR"), "EDIT", "", "", "Editing Notes " & Session("docid") & _
                         "-" & CleanVar(txtNotes.Text), "Notes")

            End If
            'Response.Write(cm.CommandText)
            cm.ExecuteNonQuery()
            vscript = "alert('Record successfully saved');window.opener.document.form1.submit();"
        Catch ex As sqlclient.sqlException
            vscript = "alert('An error occur while trying to connect to the database. Error is " & _
                      ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            c.Dispose()
            cm.Dispose()
            btnRemoveAttachment.Enabled = txtFiles.Text <> ""
        End Try
    End Sub

    Protected Sub btnClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Session("notesid") = 0
        vscript = "window.opener.document.form1.submit();self.close();"
    End Sub

    Protected Sub btnRemoveAttachment_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnRemoveAttachment.Click
        If txtFiles.Text <> "" Then

            Dim c As New sqlclient.sqlConnection(connStr)
            Dim cm As New sqlclient.sqlCommand

            Dim vfilename As String = Server.MapPath(".") & "\" & txtFiles.Text.Replace("/", "\")

            Try
                IO.File.Delete(vfilename)
            Catch ex As IO.IOException
                vscript = "alert('Cant delete that file.');"
            End Try

            cm.Connection = c
            cm.CommandText = "update dm_document_notes set SubPath=NULL where Notes_Id=" & Session("notesid")
            Try
                c.Open()
                cm.ExecuteNonQuery()
                btnRemoveAttachment.Enabled = False
                txtFiles.Text = ""
                vscript = "alert('uploaded file successfully removed');window.form1.submit();window.opener.document.form1.submit();"
            Catch ex As sqlclient.sqlException
                vscript = "alert('An error occur while trying to access the database.  Error is " & _
                ex.Message.Replace("'", vbCrLf).Replace("'", "") & "');"

            Finally
                c.Dispose()
                cm.Dispose()
                c.Close()
            End Try
        End If
    End Sub
End Class
