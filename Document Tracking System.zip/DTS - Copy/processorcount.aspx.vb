﻿Imports denaro.fis
Partial Class processorcount
    Inherits System.Web.UI.Page
    Public vHeader_A As String = ""
    Public vHeader_B As String = ""
    Public vHeader_C As String = ""
    Public vData As String = ""
    Public vscript As String

    Dim vSupp As String = ""
    Dim vTime() As String = {"7:30 - 9:00 AM", "9:00 - 10:00 AM", "10:00 - 11:00 AM", "11:00 - 12:00 PM", "12:00 - 1:00 PM", _
                             "1:00 - 2:00 PM", "2:00 - 3:00 PM", "3:00 - 4:00 PM", "4:00 - 5:00 PM", "5:00 - 6:00 PM (OT)", _
                             "6:00 - 7:00 PM (OT)", "7:00 - 8:00 PM (OT)", "8:00 - 9:00 PM (OT)", "9:00 - 10:00 PM (OT)", _
                             "10:00 - 11:00 PM (OT)"}

    Dim vTags() As String = {"Act", "GR", "1-3", "4-6", "7-9", "10+", "Diff"}

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If

        If Not IsPostBack Then
            StartDate.Value = Format(Now(), "MM/dd/yyyy")

            BuildHeaders()
            BuildCombo("select SupplierCd,  SupplierName from supplier order by SupplierName ", cmdCompList)
            cmdCompList.Items.Add("All")
            cmdCompList.SelectedValue = "All"
        End If
    End Sub

    Private Sub BuildHeaders()

        For i As Integer = 0 To 13
            vHeader_C += "<th class='titleBar' style='border: solid 1px #8b8b8a;' colspan='7'>7</th>"
            vHeader_A += "<th class='titleBar' style='border: solid 1px #8b8b8a;' colspan='7'>" & vTime(i) & "</th>"
        Next

        vHeader_B += "<th class='titleBar' style='width: 30px; border: solid 1px #8b8b8a;'>Act</th>"
        vHeader_B += "<th class='titleBar' style='width: 30px; border: solid 1px #8b8b8a;'>GR</th>"

        For i1 As Integer = 0 To 13
            For i As Integer = 0 To 6
                vHeader_B += "<th class='titleBar' style='width: 30px; border: solid 1px #8b8b8a;'>" & vTags(i) & "</th>"
            Next
        Next
        'vHeader_B += "<th class='titleBar' style='width: 45px; border: solid 1px #8b8b8a;'>Act</th>"
        'vHeader_B += "<th class='titleBar' style='width: 45px; border: solid 1px #8b8b8a;'>GR</th>"

    End Sub

    Private Sub BuildRecords()
        Dim c As New SqlClient.SqlConnection(connStr)

        If StartDate.Value = "" Then
            vscript = "alert('Please select Date.')"
            Exit Sub
        End If

        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim cm_a As New SqlClient.SqlCommand
        'Dim rs_a As SqlClient.SqlDataReader
        Dim cm_b As New SqlClient.SqlCommand
        'Dim rs_b As SqlClient.SqlDataReader

        Dim vAct As Integer = 0
        Dim vDiff As Integer = 0

        Dim vTotalAct As Integer = 0
        Dim vTotalRG As Integer = 0

        Dim vMaxTotalAct As Integer = 0
        Dim vMaxTotalRG As Integer = 0

        Dim iRows As Integer = 0
        Dim iSW As Integer = 0
        Dim vTotal As Integer = 0

        Dim vRange() As String = {"between 1 and 3", "between 4 and 6", "between 7 and 9", " >= 10"}

        Dim vS_Time() As String = {"07:30:00", "09:00:00", "10:00:00", "11:00:00", "12:00:00", "13:00:00", "14:00:00", "15:00:00", "16:00:00", _
                                   "17:00:00", "18:00:00", "19:00:00", "20:00:00", "21:00:00", "22:00:00", "23:00:00"}
        Dim vE_Time() As String = {"08:59:59", "09:59:59", "10:59:59", "11:59:59", "12:59:59", "13:59:59", "14:59:59", "15:59:59", "16:59:59", _
                                   "17:59:59", "18:59:59", "19:59:59", "20:59:59", "21:59:59", "22:59:59", "23:59:59"}

        c.Open()
        cm.Connection = c
        cm_b.Connection = c
        cm_a.Connection = c

        If cmdCompList.SelectedValue <> "All" Then
            vSupp = " and Supplier_Cd=" & cmdCompList.SelectedValue
        End If

        Dim vTranDate As Date = Format(CDate(StartDate.Value), "yyyy-MM-dd")

        cm.CommandText += "select User_Id, "
        For i As Integer = 8 To 21

            cm.CommandText += "(select count(distinct Doc_Id) from dm_ledger a where a.Status_Cd=10 and exists  " & _
                "(select Doc_Id from dm_document where Status_Cd not in (16,19,20) and a.Doc_Id=dm_document.Doc_Id) and  " & _
                    "TranDate between '" & vTranDate & "  " & Format(IIf(i = 8, 7, i), "00") & ":00:00' and '" & _
                        vTranDate & "  " & Format(i, "00") & ":59:59' and a.Doc_Id not in  " & _
                    "(select distinct Doc_Id from dm_ledger b where b.Status_Cd=10 and exists  " & _
                    "(select Doc_Id from dm_document where Status_Cd not in (16,19,20) and b.Doc_Id=dm_document.Doc_Id) and  " & _
                    "b.TranDate between '" & vTranDate & "  " & Format(i + 1, "00") & ":00:00' and '" & _
                        vTranDate & "  23:59:59') and User_Id=CreatedBy) as Act_" & i & ", "

            cm.CommandText += "(select count(distinct Doc_Id) from dm_ledger a where a.Status_Cd=18 and exists  " & _
                "(select Doc_Id from dm_document where Status_Cd not in (16,19,20) and a.Doc_Id=dm_document.Doc_Id) and  " & _
                    "TranDate between '" & vTranDate & "  " & Format(IIf(i = 8, 7, i), "00") & ":00:00' and '" & _
                        vTranDate & "  " & Format(i, "00") & ":59:59' and a.Doc_Id not in  " & _
                    "(select distinct Doc_Id from dm_ledger b where b.Status_Cd=18 and exists  " & _
                    "(select Doc_Id from dm_document where Status_Cd not in (16,19,20) and b.Doc_Id=dm_document.Doc_Id) and  " & _
                    "b.TranDate between '" & vTranDate & "  " & Format(i + 1, "00") & ":00:00' and '" & _
                        vTranDate & "  23:59:59') and User_Id=CreatedBy) as Gr_" & i & ", "

            cm.CommandText += "(select count(distinct Doc_Id) from dm_ledger a where a.Status_Cd=10 and exists  " & _
                "(select Doc_Id from dm_document where Status_Cd not in (16,19,20) and LineItem between 1 and 3 and a.Doc_Id=dm_document.Doc_Id) and  " & _
                    "TranDate between '" & vTranDate & "  " & Format(IIf(i = 8, 7, i), "00") & ":00:00' and '" & _
                        vTranDate & "  " & Format(i, "00") & ":59:59' and a.Doc_Id not in  " & _
                    "(select distinct Doc_Id from dm_ledger b where b.Status_Cd=10 and exists  " & _
                    "(select Doc_Id from dm_document where Status_Cd not in (16,19,20) and LineItem between 1 and 3 " & _
                        "and b.Doc_Id=dm_document.Doc_Id) and  " & _
                    "b.TranDate between '" & vTranDate & "  " & Format(i + 1, "00") & ":00:00' and '" & _
                        vTranDate & "  23:59:59') and User_Id=CreatedBy) as LNum_1_3" & i & ", "

            cm.CommandText += "(select count(distinct Doc_Id) from dm_ledger a where a.Status_Cd=10 and exists  " & _
                "(select Doc_Id from dm_document where Status_Cd not in (16,19,20) and LineItem between 4 and 6 and a.Doc_Id=dm_document.Doc_Id) and  " & _
                    "TranDate between '" & vTranDate & "  " & Format(IIf(i = 8, 7, i), "00") & ":00:00' and '" & _
                        vTranDate & "  " & Format(i, "00") & ":59:59' and a.Doc_Id not in  " & _
                    "(select distinct Doc_Id from dm_ledger b where b.Status_Cd=10 and exists  " & _
                    "(select Doc_Id from dm_document where Status_Cd not in (16,19,20) and LineItem between 4 and 6 " & _
                        "and b.Doc_Id=dm_document.Doc_Id) and  " & _
                    "b.TranDate between '" & vTranDate & "  " & Format(i + 1, "00") & ":00:00' and '" & _
                        vTranDate & "  23:59:59') and User_Id=CreatedBy) as LNum_4_6_" & i & ", "

            cm.CommandText += "(select count(distinct Doc_Id) from dm_ledger a where a.Status_Cd=10 and exists  " & _
                "(select Doc_Id from dm_document where Status_Cd not in (16,19,20) and LineItem between 7 and 9 and a.Doc_Id=dm_document.Doc_Id) and  " & _
                    "TranDate between '" & vTranDate & "  " & Format(IIf(i = 8, 7, i), "00") & ":00:00' and '" & _
                        vTranDate & "  " & Format(i, "00") & ":59:59' and a.Doc_Id not in  " & _
                    "(select distinct Doc_Id from dm_ledger b where b.Status_Cd=10 and exists  " & _
                    "(select Doc_Id from dm_document where Status_Cd not in (16,19,20) and LineItem between 4 and 6 " & _
                        "and b.Doc_Id=dm_document.Doc_Id) and  " & _
                    "b.TranDate between '" & vTranDate & "  " & Format(i + 1, "00") & ":00:00' and '" & _
                        vTranDate & "  23:59:59') and User_Id=CreatedBy) as LNum_7_9_" & i & ", "

            cm.CommandText += "(select count(distinct Doc_Id) from dm_ledger a where a.Status_Cd=10 and exists  " & _
                "(select Doc_Id from dm_document where Status_Cd not in (16,19,20) and LineItem >=10 and a.Doc_Id=dm_document.Doc_Id) and  " & _
                    "TranDate between '" & vTranDate & "  " & Format(IIf(i = 8, 7, i), "00") & ":00:00' and '" & _
                        vTranDate & "  " & Format(i, "00") & ":59:59' and a.Doc_Id not in  " & _
                    "(select distinct Doc_Id from dm_ledger b where b.Status_Cd=10 and exists  " & _
                    "(select Doc_Id from dm_document where Status_Cd not in (16,19,20) and LineItem >=10 " & _
                        "and b.Doc_Id=dm_document.Doc_Id) and  " & _
                    "b.TranDate between '" & vTranDate & "  " & Format(i + 1, "00") & ":00:00' and '" & _
                        vTranDate & "  23:59:59') and User_Id=CreatedBy) as LNum_10_" & i & ", "
        Next



        cm.CommandText += "Fullname from user_list where Position='Processor' and POSMenus like '" & _
            cmbEmpStatus.SelectedValue & "%' order by LineUp, FullName"
        'Response.Write(cm.CommandText)

        Dim x As Integer = 0
        Dim iCtr As Integer = 1
        Dim vBTotal() As Integer = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, _
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, _
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, _
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}

        rs = cm.ExecuteReader
        vData = ""

        vData += "<tr>" & _
            "<td class='labelBR' style='height:25px;'><b>Total : </b>&nbsp;</td>" & _
            "<td class='labelBC' style='height:25px; background-color: #f6fafb;'><b>%vTtlAct%</b>&nbsp;</td>" & _
            "<td class='labelBC' style='height:25px; background-color: #f6fafb;'><b>%vTtlRG%</b>&nbsp;</td>"

        For i As Integer = 1 To 98
            vData += "<td class='labelBC' style='height:25px;'><b>" & vBTotal(i) & "</b></td>" '" & vBTotal(i) & "
        Next

        'vData += "<td class='labelBC' style='height:25px;'><b>" & vMaxTotalAct & "</b></td>"
        'vData += "<td class='labelBC' style='height:25px;'><b>" & vMaxTotalRG & "</b></td>"

        vData = vData.Replace("%vTtlAct%", vMaxTotalAct)
        vData = vData.Replace("%vTtlRG%", vMaxTotalRG)

        vData += "<tr>"

        rs.Close()
        c.Close()
        c.Dispose()
        cm.Dispose()
    End Sub

    Private Sub BuildData(ByVal sender As Object)
        Dim vCol As Integer = 0
        Dim vName As String = sender

        For i As Integer = 0 To 13
            vHeader_A += "<th class='titleBar' style='width: 45px; border: solid 1px #8b8b8a;'>" & vTime(i) & "</th>"
        Next
    End Sub

    Private Sub BuildTotals()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader

        Dim vS_Time() As String = {"07:30:00", "09:00:00", "10:00:00", "11:00:00", "12:00:00", "13:00:00", "14:00:00", "15:00:00", "16:00:00", _
                                   "17:00:00", "18:00:00", "19:00:00", "20:00:00", "21:00:00", "22:00:00", "23:00:00"}
        Dim vE_Time() As String = {"08:59:59", "09:59:59", "10:59:59", "11:59:59", "12:59:59", "13:59:59", "14:59:59", "15:59:59", "16:59:59", _
                                   "17:59:59", "18:59:59", "19:59:59", "20:59:59", "21:59:59", "22:59:59", "23:59:59"}

        If cmdCompList.SelectedValue <> "All" Then
            vSupp = " and Supplier_Cd=" & cmdCompList.SelectedValue
        End If

        c.Open()
        cm.Connection = c

        vData += "<tr>"
        vData += "<td class='labelBR' style='height:25px;'><b>Total :&nbsp;</b></td>"

        For i As Integer = 1 To 14
            cm.CommandText = ""
            

            cm.CommandText = "select COUNT(*) vCount from dm_ledger where Status_Cd=10 and TranDate between '" & _
                    Format(CDate(StartDate.Value), "yyyy-MM-dd") & " " & vS_Time(i) & "' and '" & _
                    Format(CDate(StartDate.Value), "yyyy-MM-dd") & " " & vE_Time(i) & "' " & vSupp & " and " & _
                    "exists (select Doc_Id from dm_document where Status_Cd in (12,14,15) and dm_document.Doc_Id=dm_ledger.Doc_Id )"
            'Response.Write(cm.CommandText & "<br>")
            rs = cm.ExecuteReader
            If rs.Read() Then
                vData += "<td class='labelBC' style='padding:5px; color: #" & _
                    IIf(rs("vCount") = 0, "e9e9e9", "000000") & "'>" & rs("vCount") & "</td>"
            End If
            rs.Close()


            vData += "<td class='labelBC' style='height:25px;'>2</td>"
            vData += "<td class='labelBC' style='height:25px;'>3</td>"
            vData += "<td class='labelBC' style='height:25px;'>4</td>"
            vData += "<td class='labelBC' style='height:25px;'>5</td>"
            vData += "<td class='labelBC' style='height:25px;'>6</td>"
            vData += "<td class='labelBC' style='height:25px;'></td>"
        Next

        vData += "</tr>"

        c.Close()
        c.Dispose()
        cm.Dispose()
        'pnlRetrieving.Visible = False
    End Sub

    Protected Sub cmdRefresh_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdRefresh.Click
        'pnlRetrieving.Visible = True
        BuildHeaders()
        'BuildRecords()
        'pnlRetrieving.Visible = False
    End Sub

    Protected Sub cmdReturn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.Click
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub cmdReload_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReload.Click
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim vEmpStatus As String = ""

        If StartDate.Value = "" Then
            StartDate.Value = Format(Now(), "MM/dd/yyyy")
        End If

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vscript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        If cmbEmpStatus.SelectedValue <> "All" Then
            vEmpStatus = " and POSMenus like '" & cmbEmpStatus.SelectedValue & "%' "
        End If

        cm.Connection = c
        cm.CommandText = "select User_Id from user_list where Position ='Processor' " & vEmpStatus & " order by LineUp"

        Try
            rs = cm.ExecuteReader
            txtProcessorList.Value = ""
            Do While rs.Read
                txtProcessorList.Value += rs("User_Id") & ","
            Loop
            rs.Close()

            If txtProcessorList.Value <> "" Then
                txtProcessorList.Value = Mid(txtProcessorList.Value, 1, Len(txtProcessorList.Value) - 1)
            End If
        Catch ex As SqlClient.SqlException
            vscript = "alert('Error occurred while trying to retrieve documents.  Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            cm.Dispose()
            c.Dispose()

            BuildHeaders()
            vscript = "getData();"
        End Try
    End Sub
End Class
