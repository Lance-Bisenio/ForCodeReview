﻿Imports System.Data
Imports System.ComponentModel
Imports System.Media
Imports HelperClass
Partial Class DECIPHER
    Inherits System.Web.UI.Page
    Dim vSQL As String = ""
    Public PublicData As String = ""
    Public PublicQuestList As String = ""

    Private Sub DECIPHER_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            BuildCombo("select Id, Descr from tblDecipher order by Descr", CmdTopic)
        End If
    End Sub

    Private Sub GetQuestionList()
        Dim c As New SqlClient.SqlConnection
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader

        c.ConnectionString = ConnStr

        Try
            c.Open()
            cm.Connection = c
        Catch ex As SqlClient.SqlException
            'vScript = "alert('Error occurred while trying to connect to Host Database.');"
            Exit Sub
        End Try


        vSQL = "select Id, Descr, QuestId, OrderBy, " _
            & "Display1, Display2, Display3, Display4, Display5," _
            & "Ans1, Ans2, Ans3, Ans4, Ans5," _
            & "SoundFilePath, SoundFilePath1, SoundFilePath2, SoundFilePath3, SoundFilePath4, SoundFilePath5," _
            & "InterVal1,InterVal2,InterVal3,InterVal4,InterVal5,InterValMain " _
            & "from tblDecipher " _
            & "where Id=" & CmdTopic.SelectedValue & " order by ID "

        'Response.Write(vSQL)
        cm.CommandText = vSQL

        rs = cm.ExecuteReader
        Do While rs.Read

            PublicData += "<tr>"
            PublicData += "<td>" & rs("Display1") & "</td>"
            PublicData += "<td>" & rs("Ans1") & "</td>"
            PublicData += "<td>" & rs("SoundFilePath1") & "</td>"
            PublicData += "<td>" & rs("InterVal1") & "</td>"
            PublicData += "</tr>"

            PublicData += "<tr>"
            PublicData += "<td>" & rs("Display2") & "</td>"
            PublicData += "<td>" & rs("Ans2") & "</td>"
            PublicData += "<td>" & rs("SoundFilePath2") & "</td>"
            PublicData += "<td>" & rs("InterVal2") & "</td>"
            PublicData += "</tr>"

            PublicData += "<tr>"
            PublicData += "<td>" & rs("Display3") & "</td>"
            PublicData += "<td>" & rs("Ans3") & "</td>"
            PublicData += "<td>" & rs("SoundFilePath3") & "</td>"
            PublicData += "<td>" & rs("InterVal3") & "</td>"
            PublicData += "</tr>"

            PublicData += "<tr>"
            PublicData += "<td>" & rs("Display4") & "</td>"
            PublicData += "<td>" & rs("Ans4") & "</td>"
            PublicData += "<td>" & rs("SoundFilePath4") & "</td>"
            PublicData += "<td>" & rs("InterVal4") & "</td>"
            PublicData += "</tr>"

            PublicData += "<tr>"
            PublicData += "<td>" & rs("Display5") & "</td>"
            PublicData += "<td>" & rs("Ans5") & "</td>"
            PublicData += "<td>" & rs("SoundFilePath5") & "</td>"
            PublicData += "<td>" & rs("InterVal5") & "</td>"
            PublicData += "</tr>"

            TxtMainDescr.Text = rs("Descr")
            TxtOrder.Text = rs("OrderBy")
            TxtIntMain.Text = rs("InterValMain")

            TxtDescr1.Text = rs("Display1")
            TxtDescr2.Text = rs("Display2")
            TxtDescr3.Text = rs("Display3")
            TxtDescr4.Text = rs("Display4")
            TxtDescr5.Text = rs("Display5")

            TxtIsAns1.Text = rs("Ans1")
            TxtIsAns2.Text = rs("Ans2")
            TxtIsAns3.Text = rs("Ans3")
            TxtIsAns4.Text = rs("Ans4")
            TxtIsAns5.Text = rs("Ans5")

            TxtInterval1.Text = rs("InterVal1")
            TxtInterval2.Text = rs("InterVal2")
            TxtInterval3.Text = rs("InterVal3")
            TxtInterval4.Text = rs("InterVal4")
            TxtInterval5.Text = rs("InterVal5")

            Session("ItemId") = rs("QuestId")
        Loop

        rs.Close()


        vSQL = "select Id, Descr, QuestId, OrderBy " _
            & "from tblDecipher " _
            & "order by OrderBy "

        'Response.Write(vSQL)
        cm.CommandText = vSQL

        rs = cm.ExecuteReader
        Do While rs.Read
            PublicQuestList += "<tr>"
            PublicQuestList += "<td>" & rs("Descr") & "</td>"
            PublicQuestList += "<td>" & rs("OrderBy") & "</td>"
            PublicQuestList += "</tr>"
        Loop
        rs.Close()

        c.Close()
        c.Dispose()
        cm.Dispose()

    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        GetQuestionList()
        BtnEdit.Disabled = False
        BtnDelete.Disabled = False

    End Sub

    Private Sub BtnQuesSubmit_ServerClick(sender As Object, e As EventArgs) Handles BtnQuesSubmit.ServerClick
        Dim BatchNo As String = Format(Now, "MMddyyyyHHmmss")
        Dim TargetPathMain As String = ""
        Dim TargetPath1 As String = ""
        Dim TargetPath2 As String = ""
        Dim TargetPath3 As String = ""
        Dim TargetPath4 As String = ""
        Dim TargetPath5 As String = ""

        vSQL = "insert into tblDecipher (Descr, QuestId, OrderBy, " _
            & "Display1, Display2, Display3, Display4, Display5," _
            & "Ans1, Ans2, Ans3, Ans4, Ans5," _
            & "InterVal1,InterVal2,InterVal3,InterVal4,InterVal5,InterValMain) values (" _
            & "'" & TxtMainDescr.Text.Replace("'", "*") & "','" & BatchNo & "', '" & TxtOrder.Text & "'," _
            & "'" & TxtDescr1.Text.Replace("'", "*") & "','" & TxtDescr2.Text.Replace("'", "*") & "'," _
            & "'" & TxtDescr3.Text.Replace("'", "*") & "','" & TxtDescr4.Text.Replace("'", "*") & "','" & TxtDescr5.Text.Replace("'", "*") & "'," _
            & "'" & TxtIsAns1.Text & "','" & TxtIsAns2.Text & "','" & TxtIsAns3.Text & "','" & TxtIsAns4.Text & "','" & TxtIsAns5.Text & "'," _
            & "'" & TxtInterval2.Text & "','" & TxtInterval2.Text & "','" & TxtInterval3.Text & "','" & TxtInterval4.Text & "','" & TxtInterval5.Text & "','" & TxtIntMain.Text & "')"
        CreateRecords(vSQL)
        Response.Write(vSQL)

        If VOMain.FileName <> "" Then
            TargetPathMain = Server.MapPath(".") & "\Uploaded\VoiceFile\" & BatchNo & "-0.wav"
            VOMain.SaveAs(TargetPathMain)
            vSQL = "update tblDecipher set SoundFilePath='" & TargetPathMain & "' where QuestId='" & BatchNo & "'"
            CreateRecords(vSQL)
        End If

        If VOF1.FileName <> "" Then
            TargetPath1 = Server.MapPath(".") & "\Uploaded\VoiceFile\" & BatchNo & "-1.wav"
            VOF1.SaveAs(TargetPath1)
            vSQL = "update tblDecipher set SoundFilePath1='" & TargetPath1 & "' where QuestId='" & BatchNo & "'"
            CreateRecords(vSQL)
        End If

        If VOF2.FileName <> "" Then
            TargetPath2 = Server.MapPath(".") & "\Uploaded\VoiceFile\" & BatchNo & "-2.wav"
            VOF2.SaveAs(TargetPath2)
            vSQL = "update tblDecipher set SoundFilePath2='" & TargetPath2 & "' where QuestId='" & BatchNo & "'"
            CreateRecords(vSQL)
        End If

        If VOF3.FileName <> "" Then
            TargetPath3 = Server.MapPath(".") & "\Uploaded\VoiceFile\" & BatchNo & "-3.wav"
            VOF3.SaveAs(TargetPath3)
            vSQL = "update tblDecipher set SoundFilePath3='" & TargetPath3 & "' where QuestId='" & BatchNo & "'"
            CreateRecords(vSQL)
        End If

        If VOF4.FileName <> "" Then
            TargetPath4 = Server.MapPath(".") & "\Uploaded\VoiceFile\" & BatchNo & "-4.wav"
            VOF4.SaveAs(TargetPath4)
            vSQL = "update tblDecipher set SoundFilePath4='" & TargetPath4 & "' where QuestId='" & BatchNo & "'"
            CreateRecords(vSQL)
        End If

        If VOF5.FileName <> "" Then
            TargetPath5 = Server.MapPath(".") & "\Uploaded\VoiceFile\" & BatchNo & "-5.wav"
            VOF5.SaveAs(TargetPath5)
            vSQL = "update tblDecipher set SoundFilePath5='" & TargetPath5 & "' where QuestId='" & BatchNo & "'"
            CreateRecords(vSQL)
        End If

        BuildCombo("select Id, Descr from tblDecipher order by Descr", CmdTopic)
    End Sub

    Private Sub BtnQuesUpdate_ServerClick(sender As Object, e As EventArgs) Handles BtnQuesUpdate.ServerClick
        Dim BatchNo As String = Session("ItemId")
        Dim TargetPathMain As String = ""
        Dim TargetPath1 As String = ""
        Dim TargetPath2 As String = ""
        Dim TargetPath3 As String = ""
        Dim TargetPath4 As String = ""
        Dim TargetPath5 As String = ""

        vSQL = "update tblDecipher set " _
            & "Descr='" & TxtMainDescr.Text.Replace("'", "*") & "', " _
            & "OrderBy='" & TxtOrder.Text & "', " _
            & "Display1='" & TxtDescr1.Text.Replace("'", "*") & "', " _
            & "Display2='" & TxtDescr2.Text.Replace("'", "*") & "', " _
            & "Display3='" & TxtDescr3.Text.Replace("'", "*") & "', " _
            & "Display4='" & TxtDescr4.Text.Replace("'", "*") & "', " _
            & "Display5='" & TxtDescr5.Text.Replace("'", "*") & "', " _
            & "Ans1='" & TxtIsAns1.Text & "', " _
            & "Ans2='" & TxtIsAns2.Text & "', " _
            & "Ans3='" & TxtIsAns3.Text & "', " _
            & "Ans4='" & TxtIsAns4.Text & "', " _
            & "Ans5='" & TxtIsAns5.Text & "', " _
            & "InterVal1='" & TxtInterval1.Text & "', " _
            & "InterVal2='" & TxtInterval2.Text & "', " _
            & "InterVal3='" & TxtInterval3.Text & "', " _
            & "InterVal4='" & TxtInterval4.Text & "', " _
            & "InterVal5='" & TxtInterval5.Text & "', " _
            & "InterValMain='" & TxtIntMain.Text & "' " _
            & "where QuestId='" & BatchNo & "'"

        CreateRecords(vSQL)
        'Response.Write(vSQL)

        If VOMain.FileName <> "" Then
            TargetPathMain = Server.MapPath(".") & "\Uploaded\VoiceFile\" & BatchNo & "-0.wav"
            VOMain.SaveAs(TargetPathMain)
            vSQL = "update tblDecipher set SoundFilePath='" & TargetPathMain & "' where QuestId='" & BatchNo & "'"
            CreateRecords(vSQL)
        End If

        If VOF1.FileName <> "" Then
            TargetPath1 = Server.MapPath(".") & "\Uploaded\VoiceFile\" & BatchNo & "-1.wav"
            VOF1.SaveAs(TargetPath1)
            vSQL = "update tblDecipher set SoundFilePath1='" & TargetPath1 & "' where QuestId='" & BatchNo & "'"
            CreateRecords(vSQL)
        End If

        If VOF2.FileName <> "" Then
            TargetPath2 = Server.MapPath(".") & "\Uploaded\VoiceFile\" & BatchNo & "-2.wav"
            VOF2.SaveAs(TargetPath2)
            vSQL = "update tblDecipher set SoundFilePath2='" & TargetPath2 & "' where QuestId='" & BatchNo & "'"
            CreateRecords(vSQL)
        End If

        If VOF3.FileName <> "" Then
            TargetPath3 = Server.MapPath(".") & "\Uploaded\VoiceFile\" & BatchNo & "-3.wav"
            VOF3.SaveAs(TargetPath3)
            vSQL = "update tblDecipher set SoundFilePath3='" & TargetPath3 & "' where QuestId='" & BatchNo & "'"
            CreateRecords(vSQL)
        End If

        If VOF4.FileName <> "" Then
            TargetPath4 = Server.MapPath(".") & "\Uploaded\VoiceFile\" & BatchNo & "-4.wav"
            VOF4.SaveAs(TargetPath4)
            vSQL = "update tblDecipher set SoundFilePath4='" & TargetPath4 & "' where QuestId='" & BatchNo & "'"
            CreateRecords(vSQL)
        End If

        If VOF5.FileName <> "" Then
            TargetPath5 = Server.MapPath(".") & "\Uploaded\VoiceFile\" & BatchNo & "-5.wav"
            VOF5.SaveAs(TargetPath5)
            vSQL = "update tblDecipher set SoundFilePath5='" & TargetPath5 & "' where QuestId='" & BatchNo & "'"
            CreateRecords(vSQL)
        End If

        BuildCombo("select Id, Descr from tblDecipher order by Descr", CmdTopic)
    End Sub
    'tblDecipher
End Class
