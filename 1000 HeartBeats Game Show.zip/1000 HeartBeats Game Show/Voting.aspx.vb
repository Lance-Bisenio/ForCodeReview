﻿Imports System.Data
Imports HelperClass
Partial Class Voting
    Inherits System.Web.UI.Page
    Dim vSQL As String = ""
    Public vTblData As String = ""

    Private Sub Voting_Load(sender As Object, e As EventArgs) Handles Me.Load
        LblCon1.Text = "Contestant Number 1<br>Belinda Hermoso Tayko"
        LblCon2.Text = "Contestant Number 2<br>Luis Miguel Sampol"
        LblCon3.Text = "Contestant Number 3<br>Carlo Gabriel Legaspi"

        LblJudge1.Text = "Lea<br>Salonga"
        LblJudge2.Text = "Martin<br>Rievera"
        LblJudge3.Text = "Yeng<br>Constantino"
        LblJudge4.Text = "Arnel<br>Pineda"
        LblJudge5.Text = "Sarah<br>Geronimo"

        BtnJudge1.Enabled = False
        BtnJudge2.Enabled = False
        BtnJudge3.Enabled = False
        BtnJudge4.Enabled = False
        BtnJudge5.Enabled = False

    End Sub

    Private Sub BtnCon1_Click(sender As Object, e As EventArgs) Handles BtnCon1.Click
        LblSelected.Text = LblCon1.Text.Replace("Contestant Number 1<br>", "").Trim

        GetScore()
    End Sub

    Private Sub BtnCon2_Click(sender As Object, e As EventArgs) Handles BtnCon2.Click
        LblSelected.Text = LblCon2.Text.Replace("Contestant Number 2<br>", "").Trim
        GetScore()
    End Sub

    Private Sub BtnCon3_Click(sender As Object, e As EventArgs) Handles BtnCon3.Click
        LblSelected.Text = LblCon3.Text.Replace("Contestant Number 3<br>", "").Trim
        GetScore()
    End Sub

    Private Sub BtnJudge1_Click(sender As Object, e As EventArgs) Handles BtnJudge1.Click
        If BtnJudge1.Text = "YES" Then
            vSQL = "insert into tblVoting (ContestantCode,JudgeCode,Name,Active,Score,GroupCode) values " _
            & "('" & LblSelected.Text & "','" & LblJudge1.Text.Replace("<br>", " ") & "','" & LblSelected.Text & "',1,1,'Group 1')"
            BtnJudge1.Text = "NO"
            BtnJudge1.CssClass = "btn btn-danger"

        Else
            vSQL = "delete from tblVoting where " _
                & "ContestantCode='" & LblSelected.Text & "' and " _
                & "JudgeCode='" & LblJudge1.Text.Replace("<br>", " ") & "' and GroupCode='Group 1'"
            BtnJudge1.Text = "YES"
            BtnJudge1.CssClass = "btn btn-success"
        End If


        CreateRecords(vSQL)
        GetScore()
    End Sub

    Private Sub BtnJudge2_Click(sender As Object, e As EventArgs) Handles BtnJudge2.Click
        If BtnJudge2.Text = "YES" Then
            vSQL = "insert into tblVoting (ContestantCode,JudgeCode,Name,Active,Score,GroupCode) values " _
            & "('" & LblSelected.Text & "','" & LblJudge2.Text.Replace("<br>", " ") & "','" & LblSelected.Text & "',1,1,'Group 1')"

            BtnJudge2.Text = "NO"
            BtnJudge2.CssClass = "btn btn-danger"

        Else
            vSQL = "delete from tblVoting where " _
                & "ContestantCode='" & LblSelected.Text & "' and " _
                & "JudgeCode='" & LblJudge2.Text.Replace("<br>", " ") & "' and GroupCode='Group 1'"
            BtnJudge2.Text = "YES"
            BtnJudge2.CssClass = "btn btn-success"
        End If

        CreateRecords(vSQL)
        GetScore()
    End Sub

    Private Sub BtnJudge3_Click(sender As Object, e As EventArgs) Handles BtnJudge3.Click
        If BtnJudge3.Text = "YES" Then
            vSQL = "insert into tblVoting (ContestantCode,JudgeCode,Name,Active,Score,GroupCode) values " _
            & "('" & LblSelected.Text & "','" & LblJudge3.Text.Replace("<br>", " ") & "','" & LblSelected.Text & "',1,1,'Group 1')"

            BtnJudge3.Text = "NO"
            BtnJudge3.CssClass = "btn btn-danger"

        Else
            vSQL = "delete from tblVoting where " _
                & "ContestantCode='" & LblSelected.Text & "' and " _
                & "JudgeCode='" & LblJudge3.Text.Replace("<br>", " ") & "' and GroupCode='Group 1'"
            BtnJudge3.Text = "YES"
            BtnJudge3.CssClass = "btn btn-success"
        End If

        CreateRecords(vSQL)
        GetScore()
    End Sub

    Private Sub BtnJudge4_Click(sender As Object, e As EventArgs) Handles BtnJudge4.Click
        If BtnJudge4.Text = "YES" Then
            vSQL = "insert into tblVoting (ContestantCode,JudgeCode,Name,Active,Score,GroupCode) values " _
            & "('" & LblSelected.Text & "','" & LblJudge4.Text.Replace("<br>", " ") & "','" & LblSelected.Text & "',1,1,'Group 1')"

            BtnJudge4.Text = "NO"
            BtnJudge4.CssClass = "btn btn-danger"

        Else
            vSQL = "delete from tblVoting where " _
                & "ContestantCode='" & LblSelected.Text & "' and " _
                & "JudgeCode='" & LblJudge4.Text.Replace("<br>", " ") & "' and GroupCode='Group 1'"
            BtnJudge4.Text = "YES"
            BtnJudge4.CssClass = "btn btn-success"
        End If
        CreateRecords(vSQL)
        GetScore()
    End Sub

    Private Sub BtnJudge5_Click(sender As Object, e As EventArgs) Handles BtnJudge5.Click
        If BtnJudge5.Text = "YES" Then
            vSQL = "insert into tblVoting (ContestantCode,JudgeCode,Name,Active,Score,GroupCode) values " _
            & "('" & LblSelected.Text & "','" & LblJudge5.Text.Replace("<br>", " ") & "','" & LblSelected.Text & "',1,1,'Group 1')"

            BtnJudge5.Text = "NO"
            BtnJudge5.CssClass = "btn btn-danger"

        Else
            vSQL = "delete from tblVoting where " _
                & "ContestantCode='" & LblSelected.Text & "' and " _
                & "JudgeCode='" & LblJudge5.Text.Replace("<br>", " ") & "' and GroupCode='Group 1'"
            BtnJudge5.Text = "YES"
            BtnJudge5.CssClass = "btn btn-success"
        End If
        CreateRecords(vSQL)
        GetScore()
    End Sub


    Private Sub GetScore()

        BtnJudge1.Enabled = True
        BtnJudge2.Enabled = True
        BtnJudge3.Enabled = True
        BtnJudge4.Enabled = True
        BtnJudge5.Enabled = True

        Dim c As New SqlClient.SqlConnection
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim ControllerList As String = ""
        Dim vPoints As Integer = 0
        c.ConnectionString = ConnStr

        Try
            c.Open()
            cm.Connection = c
        Catch ex As SqlClient.SqlException
            ScriptManager.RegisterStartupScript(Me, Page.GetType, "Script", "alert('Error occurred while trying to connect to Host Database.');", True)
            Exit Sub
        End Try

        ' =============================================================================
        ' Property_Value='1000' is the Document Controller
        ' =============================================================================
        vSQL = "select ContestantCode,JudgeCode,Name,Active,Score,GroupCode from tblVoting where ContestantCode='" & LblSelected.Text & "'"

        cm.CommandText = vSQL
        rs = cm.ExecuteReader
        Do While rs.Read
            vTblData += "<tr>" _
                            & "<td>" & rs("JudgeCode") & "</td>" _
                            & "<td>" & rs("GroupCode") & "</td>" _
                            & "<td>" & rs("Score") & "</td>" _
                        & "</tr>"
            vPoints += rs("Score")
        Loop
        rs.Close()

        vTblData += "<tr>" _
                            & "<td></td>" _
                            & "<td><b>Total:</b></td>" _
                            & "<td><b>" & vPoints & "</b></td>" _
                        & "</tr>"

        c.Close()
        c.Dispose()
        cm.Dispose()

    End Sub
End Class
