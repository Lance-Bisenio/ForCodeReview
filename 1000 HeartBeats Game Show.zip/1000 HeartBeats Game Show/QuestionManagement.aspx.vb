﻿
Partial Class QuestionManagement
    Inherits System.Web.UI.Page
    Public vData As String = ""

    Private Sub QuestionManagement_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not IsPostBack Then

        End If
    End Sub
End Class
