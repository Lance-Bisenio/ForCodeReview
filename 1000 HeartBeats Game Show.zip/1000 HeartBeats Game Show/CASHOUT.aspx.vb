﻿Imports System.Data
Imports System.ComponentModel
Imports System.Media
Imports HelperClass
Partial Class CASHOUT
    Inherits System.Web.UI.Page
    Public vData As String = ""
    Dim vSQL As String = ""

    Private Sub CASHOUT_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            'BuildCombo("select Id, Description from tblGameCategoryHdr order by Description", CmdGroupType)
            'CmdGroupType.Items.Add("New")
            'CmdGroupType.SelectedValue = "New"
            DataRefresh()
            BtnQuestAdd.Disabled = True
            BtnQuestEdit.Disabled = True
            BtnQuestDel.Disabled = True
        End If
        VoiceFile.Src = "#"
    End Sub
    Private Sub BtnSave_ServerClick(sender As Object, e As EventArgs) Handles BtnSave.ServerClick
        Dim SysId As Int64 = Format(Now(), "MMddyyyyHHmmss")
        Dim TargetFilename As String = Server.MapPath(".") & "\Uploaded\VoiceFile\" & SysId & ".wav"

        If TxtSoundFileTopic.FileName <> "" Then
            TxtSoundFileTopic.SaveAs(TargetFilename)
        End If

        vSQL = "insert into tblGameCategoryHdr (Description,Remarks,CategoryId,Opt1,Opt2,SoundFilePath) values ('" _
            & TxtDescr.Text.Trim.Replace("'", "*") & "','" _
            & TxtRemarks.Text.Trim & "',99,'" _
            & TxtOpt1.Text.Trim & "','" _
            & TxtOpt2.Text.Trim & "','" & IIf(TxtSoundFileTopic.FileName = "", "", TargetFilename) & "')"

        CreateRecords(vSQL)
        DataRefresh()

        ScriptManager.RegisterStartupScript(Me, Page.GetType, "Script", "alert('Successfully saved');", True)
    End Sub
    Private Sub BtnUpdate_ServerClick(sender As Object, e As EventArgs) Handles BtnUpdate.ServerClick
        'Dim TargetFilename As String

        Dim SysId As Int64 = Format(Now(), "MMddyyyyHHmmss")
        Dim TargetFilename As String = Server.MapPath(".") & "\Uploaded\VoiceFile\" & SysId & ".wav"
        TxtSoundFileTopic.SaveAs(TargetFilename)

        vSQL = "update tblGameCategoryHdr set " _
                & "Description='" & TxtDescr.Text.Trim.Trim.Replace("&amp;", "").Replace("'", "*") & "', " _
                & "Remarks='" & TxtRemarks.Text.Trim.Trim.Replace("&amp;", "") & "'," _
                & "Opt1 ='" & TxtOpt1.Text.Trim & "', " _
                & "Opt2 ='" & TxtOpt2.Text.Trim & "' "

        If TxtSoundFileTopic.FileName <> "" Then
            vSQL += ",SoundFilePath='" & TargetFilename & "' "
            TxtSoundFileTopic.SaveAs(TargetFilename)
        End If
        'IsUsed='" & TxtQuesActive.Text.Trim & "' 
        vSQL += "where Id=" & TblTopic.SelectedRow.Cells(0).Text.Replace("&nbsp;", "")

        'Response.Write(vSQL)
        'SoundFilePath ='" & TargetFilename & "', 
        CreateRecords(vSQL)
        DataRefresh()

        ScriptManager.RegisterStartupScript(Me, Page.GetType, "Script", "alert('Successfully saved');", True)
    End Sub

    Private Sub DataRefresh()
        Dim c As New SqlClient.SqlConnection
        Dim da As SqlClient.SqlDataAdapter
        Dim ds As New DataSet

        vSQL = "select Id, Description, Remarks, Opt1, Opt2, 
            SUBSTRING(SoundFilePath,0,25) + '...' as Sounds, SoundFilePath 
            from tblGameCategoryHdr WHERE CategoryId=99  order by Id"

        'Response.Write(vSQL)
        c.ConnectionString = ConnStr
        da = New SqlClient.SqlDataAdapter(vSQL, c)

        da.Fill(ds, "TblGroup")
        TblTopic.DataSource = ds.Tables("TblGroup")
        TblTopic.DataBind()
        'lblTotal.Text = "<b>Total Employee Retrieved : " & tbl_EmpMaster.DataSource.Rows.Count & "</b>"

        da.Dispose()
        ds.Dispose()
        c.Dispose()

    End Sub

    Private Sub GetQuestionList()
        Dim c As New SqlClient.SqlConnection
        Dim da As SqlClient.SqlDataAdapter
        Dim ds As New DataSet

        vSQL = "select Id, Description, IsUsed, OrderBy, BatchNo, QuestId, SoundFilePath, Orderby,
            (select top 1 DefaultAnswer from tblQuestiondtl where QuestionId=QuestId  order by Id asc) as AnswerOpt1,
            (select top 1 DefaultAnswer from tblQuestiondtl where QuestionId=QuestId  order by Id desc) as AnswerOpt2
            from tblQuestionHdr " _
            & "where BatchNo=" & TblTopic.SelectedRow.Cells(0).Text & " order by tblQuestionHdr.Orderby"


        c.ConnectionString = ConnStr
        da = New SqlClient.SqlDataAdapter(vSQL, c)

        da.Fill(ds, "GridQuestionList")
        TblQuestionList.DataSource = ds.Tables("GridQuestionList")
        TblQuestionList.DataBind()
        'lblTotal.Text = "<b>Total Employee Retrieved : " & tbl_EmpMaster.DataSource.Rows.Count & "</b>"

        da.Dispose()
        ds.Dispose()
        c.Dispose()

    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        DataRefresh()
        BtnEdit.Disabled = True
        BtnDelete.Disabled = True
        TblTopic.SelectedIndex = -1
        TblQuestionList.SelectedIndex = -1

        BtnQuestAdd.Disabled = True
        BtnQuestEdit.Disabled = True
        BtnQuestDel.Disabled = True
    End Sub

    Private Sub TblTOpic_SelectedIndexChanged(sender As Object, e As EventArgs) Handles TblTopic.SelectedIndexChanged
        BtnEdit.Disabled = False
        BtnDelete.Disabled = False

        TxtDescr.Text = CleanVarSpecialChar(TblTopic.SelectedRow.Cells(1).Text)
        TxtRemarks.Text = CleanVarSpecialChar(TblTopic.SelectedRow.Cells(2).Text)
        TxtOpt1.Text = TblTopic.SelectedRow.Cells(3).Text.Replace("&nbsp;", "")
        TxtOpt2.Text = TblTopic.SelectedRow.Cells(4).Text.Replace("&nbsp;", "")

        lblOpt1.Text = TblTopic.SelectedRow.Cells(3).Text.Replace("&nbsp;", "")
        lblOpt2.Text = TblTopic.SelectedRow.Cells(4).Text.Replace("&nbsp;", "")
        RdoQuesOpt1.Checked = False
        RdoQuesOpt2.Checked = False
        TblQuestionList.SelectedIndex = -1

        BtnQuestAdd.Disabled = False
        BtnQuestEdit.Disabled = True
        BtnQuestDel.Disabled = True
        GetQuestionList()
    End Sub

    Private Sub BtnDeleteTopic_ServerClick(sender As Object, e As EventArgs) Handles BtnDeleteTopic.ServerClick
        vSQL = "delete from tblGameCategoryHdr where Id=" & TblTopic.SelectedRow.Cells(0).Text

        CreateRecords(vSQL)

        DataRefresh()

        ScriptManager.RegisterStartupScript(Me, Page.GetType, "Script", "alert('Successfully deleted');", True)
    End Sub

    Private Sub BtnQuesSubmit_ServerClick(sender As Object, e As EventArgs) Handles BtnQuesSubmit.ServerClick
        Dim SysId As Int64 = Format(Now(), "MMddyyyyHHmmss")
        Dim TargetFilename As String = Server.MapPath(".") & "\Uploaded\VoiceFile\" & SysId & ".wav"

        If TxtQuesSoundFile.FileName <> "" Then
            TxtQuesSoundFile.SaveAs(TargetFilename)
        End If

        vSQL = "insert into tblQuestionHdr (Description,CategoryId,OrderBy,BatchNo,Remarks,QuestId,SoundFilePath,IsUsed) values ('" _
          & TxtQuesDetails.Text.Trim.Replace("'", "*") & "',1,'" _
          & IIf(TxtQuesOrderBy.Text.Trim = 0, 99, TxtQuesOrderBy.Text.Trim) & "'," _
          & TblTopic.SelectedRow.Cells(0).Text.Replace("&nbsp;", "") & ",'" _
          & TxtQuesRemarks.Text.Trim & "'," & SysId & ",'" _
          & IIf(TxtQuesSoundFile.FileName <> "", TargetFilename, "") & "','" & TxtQuesActive.Text.Trim & "')"


        CreateRecords(vSQL)

        vSQL = "insert into tblQuestionDtl (QuestionId, AnsDescription, Remarks, DefaultAnswer) values ('" _
          & SysId & "','" _
          & lblOpt1.Text.Trim.Replace("'", "*") & "',''," _
          & IIf(RdoQuesOpt1.Checked = True, 1, 0) & ")"
        'Response.Write(vSQL)
        CreateRecords(vSQL)

        vSQL = "insert into tblQuestionDtl (QuestionId, AnsDescription, Remarks, DefaultAnswer) values ('" _
          & SysId & "','" _
          & lblOpt2.Text.Trim.Replace("'", "*") & "',''," _
          & IIf(RdoQuesOpt2.Checked = True, 1, 0) & ")"

        CreateRecords(vSQL)

        GetQuestionList()

        TxtQuesDetails.Text = ""
        TxtQuesOrderBy.Text = 0
        TxtQuesRemarks.Text = ""
        RdoQuesOpt1.Checked = False
        RdoQuesOpt2.Checked = False

        ScriptManager.RegisterStartupScript(Me, Page.GetType, "Script", "alert('Successfully saved');", True)
    End Sub

    Private Sub TblQuestionList_SelectedIndexChanged(sender As Object, e As EventArgs) Handles TblQuestionList.SelectedIndexChanged
        BtnQuestEdit.Disabled = False
        BtnQuestDel.Disabled = False

        If TblQuestionList.SelectedRow.Cells(6).Text.Trim.Replace("&nbsp;", "") <> "" Then
            If TblQuestionList.SelectedRow.Cells(6).Text.Replace("&nbsp;", "") = 1 Then
                RdoQuesOpt1.Checked = True
                RdoQuesOpt2.Checked = False
            End If
        End If

        If TblQuestionList.SelectedRow.Cells(7).Text.Trim.Replace("&nbsp;", "") <> "" Then
            If TblQuestionList.SelectedRow.Cells(7).Text.Replace("&nbsp;", "") = 1 Then
                RdoQuesOpt1.Checked = False
                RdoQuesOpt2.Checked = True
            End If
        End If

        TxtQuesOrderBy.Text = TblQuestionList.SelectedRow.Cells(8).Text.Trim.Replace("&nbsp;", "")
        TxtQuesActive.Text = TblQuestionList.SelectedRow.Cells(9).Text.Trim.Replace("&nbsp;", "")

        TxtQuesDetails.Text = CleanVarSpecialChar(TblQuestionList.SelectedRow.Cells(1).Text)
        VoiceFile.Src = "#"

    End Sub



    Private Sub wavPlayer_LoadCompleted(ByVal sender As Object, ByVal e As AsyncCompletedEventArgs)
        CType(sender, System.Media.SoundPlayer).Play()
    End Sub

    Private Sub BtnQuesUpdate_ServerClick(sender As Object, e As EventArgs) Handles BtnQuesUpdate.ServerClick
        Dim QId As Int64 = TblQuestionList.SelectedRow.Cells(4).Text

        Dim TargetFilename As String = Server.MapPath(".") & "\Uploaded\VoiceFile\" & QId & ".wav"


        vSQL = "update tblQuestionHdr set 
            Description='" & TxtQuesDetails.Text.Trim.Replace("'", "*") & "', 
            OrderBy='" & TxtQuesOrderBy.Text.Trim & "',
            BatchNo=" & TblTopic.SelectedRow.Cells(0).Text.Replace("&nbsp;", "") & ",
            Remarks='" & TxtQuesRemarks.Text.Trim & "',"

        If TxtQuesSoundFile.FileName <> "" Then
            vSQL += "SoundFilePath='" & TargetFilename & "',"
            TxtQuesSoundFile.SaveAs(TargetFilename)
        End If

        vSQL += "IsUsed='" & TxtQuesActive.Text.Trim & "' where QuestId='" & QId & "'"


        CreateRecords(vSQL)

        vSQL = "delete from tblQuestionDtl where QuestionId=" & QId
        CreateRecords(vSQL)

        vSQL = "insert into tblQuestionDtl (QuestionId, AnsDescription, Remarks, DefaultAnswer) values ('" _
          & QId & "','" _
          & lblOpt1.Text.Trim.Replace("'", "*") & "',''," _
          & IIf(RdoQuesOpt1.Checked = True, 1, 0) & ")"
        CreateRecords(vSQL)

        vSQL = "insert into tblQuestionDtl (QuestionId, AnsDescription, Remarks, DefaultAnswer) values ('" _
          & QId & "','" _
          & lblOpt2.Text.Trim.Replace("'", "*") & "',''," _
          & IIf(RdoQuesOpt2.Checked = True, 1, 0) & ")"
        CreateRecords(vSQL)
        GetQuestionList()

        ScriptManager.RegisterStartupScript(Me, Page.GetType, "Script", "alert('Successfully saved');", True)
    End Sub

    Private Sub TblQuestionList_PageIndexChanging(sender As Object, e As GridViewPageEventArgs) Handles TblQuestionList.PageIndexChanging
        TblQuestionList.PageIndex = e.NewPageIndex
        TblQuestionList.SelectedIndex = -1
        GetQuestionList()
    End Sub

    Private Sub TblTopic_PageIndexChanging(sender As Object, e As GridViewPageEventArgs) Handles TblTopic.PageIndexChanging
        TblTopic.PageIndex = e.NewPageIndex
        TblTopic.SelectedIndex = -1
        DataRefresh()
    End Sub

    Private Sub BtnSubmitQuesDel_ServerClick(sender As Object, e As EventArgs) Handles BtnSubmitQuesDel.ServerClick
        Dim QId As Int64 = TblQuestionList.SelectedRow.Cells(4).Text
        vSQL = "delete from tblQuestionDtl where QuestionId=" & QId
        CreateRecords(vSQL)
        vSQL = "delete from tblQuestionHdr where QuestId=" & QId
        CreateRecords(vSQL)
        GetQuestionList()

        ScriptManager.RegisterStartupScript(Me, Page.GetType, "Script", "alert('Successfully deleted');", True)
    End Sub

    Private Sub BtnPreview_ServerClick(sender As Object, e As EventArgs) Handles BtnPreview.ServerClick
        Dim VFileServerPath As String = ""

        vSQL = "select top 1 VoiceFileServerPath from tblGameConfiguration"
        VFileServerPath = GetRef(vSQL, "")

        VoiceFile.Src = TblTopic.SelectedRow.Cells(6).Text.ToString.Replace(VFileServerPath, "")
    End Sub

    Private Sub BtnQuesPreview_ServerClick(sender As Object, e As EventArgs) Handles BtnQuesPreview.ServerClick
        Dim VFileServerPath As String = ""
        vSQL = "select top 1 VoiceFileServerPath from tblGameConfiguration"
        VFileServerPath = GetRef(vSQL, "")

        VoiceFile.Src = TblQuestionList.SelectedRow.Cells(5).Text.ToString.Replace(VFileServerPath, "")
    End Sub
End Class
