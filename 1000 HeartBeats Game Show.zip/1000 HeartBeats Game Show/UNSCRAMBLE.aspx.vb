﻿Imports System.Data
Imports HelperClass
Imports System.Net
Partial Class UNSCRAMBLE
    Inherits System.Web.UI.Page
    Public vData As String = ""
    Dim vSQL As String = ""

    Private Sub UNSCRAMBLE_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            DataRefresh()
        End If
    End Sub
    Private Sub DataRefresh()
        Dim c As New SqlClient.SqlConnection
        Dim da As SqlClient.SqlDataAdapter
        Dim ds As New DataSet

        vSQL = "select Id,TopDesc,MidDesc,BotDesc,
            Display1,Display2,Display3,Display4,Display5,
            Ans1,Ans2,Ans3,Ans4,Ans5,
            Clue1,Clue2,Clue3,Clue4,Clue5,
            QuestId,SoundFilePath,CreatedBy,DateCreated,SoundFilePath  
            from tblUnscrable order by Id"

        'Response.Write(vSQL)
        c.ConnectionString = ConnStr
        da = New SqlClient.SqlDataAdapter(vSQL, c)

        da.Fill(ds, "TblGrid")
        TblTopic.DataSource = ds.Tables("TblGrid")
        TblTopic.DataBind()
        'lblTotal.Text = "<b>Total Employee Retrieved : " & tbl_EmpMaster.DataSource.Rows.Count & "</b>"

        da.Dispose()
        ds.Dispose()
        c.Dispose()

    End Sub

    Private Sub BtnSave_ServerClick(sender As Object, e As EventArgs) Handles BtnSave.ServerClick
        Dim SysId As Int64 = Format(Now(), "MMddyyyyHHmmss")
        Dim TargetFilename As String = Server.MapPath(".") & "\Uploaded\VoiceFile\" & SysId & ".wav"

        vSQL = "insert into tblUnscrable 
            (TopDesc,
            Display1,Display2,Display3,Display4,Display5,
            Ans1,Ans2,Ans3,Ans4,Ans5,
            Clue1,
            QuestId,SoundFilePath,CreatedBy,DateCreated,IsUsed) values (
            '" & TxtDescr1.Text.Trim.Replace("&amp;", "").Replace("'", "*") & "',
            '" & TxtDis1.Text.Trim & "',
            '" & TxtDis2.Text.Trim & "',
            '" & TxtDis3.Text.Trim & "',
            '" & TxtDis4.Text.Trim & "',
            '" & TxtDis5.Text.Trim & "',
            '" & TxtAns1.Text.Trim & "',
            '" & TxtAns2.Text.Trim & "',
            '" & TxtAns3.Text.Trim & "',
            '" & TxtAns4.Text.Trim & "',
            '" & TxtAns5.Text.Trim & "',
            '" & TxtClue1.Text & "', 
            '" & SysId & "',
            '" & IIf(FileUpload1.FileName <> "", TargetFilename, "") & "',
            'Admin',
            '" & Format(Now, "MM-dd-yyyy") & "',0)"

        CreateRecords(vSQL)
        'Response.Write(vSQL)

        If FileUpload1.FileName <> "" Then
            FileUpload1.SaveAs(TargetFilename)
        End If
        DataRefresh()
        ScriptManager.RegisterStartupScript(Me, Page.GetType, "Script", "alert('Successfully saved');", True)
    End Sub

    Private Sub BtnUpdate_ServerClick(sender As Object, e As EventArgs) Handles BtnUpdate.ServerClick
        Dim SysId As Int64 = Format(Now(), "MMddyyyyHHmmss")
        Dim TargetFilename As String = Server.MapPath(".") & "\Uploaded\VoiceFile\" & SysId & ".mp3"

        vSQL = "update tblUnscrable set
            TopDesc='" & TxtDescr1.Text.Trim.Replace("&amp;", "").Replace("'", "*") & "',
            Display1='" & TxtDis1.Text.Trim & "',
            Display2='" & TxtDis2.Text.Trim & "',
            Display3='" & TxtDis3.Text.Trim & "',
            Display4='" & TxtDis4.Text.Trim & "',
            Display5='" & TxtDis5.Text.Trim & "',
            Ans1='" & TxtAns1.Text.Trim & "',
            Ans2='" & TxtAns2.Text.Trim & "',
            Ans3='" & TxtAns3.Text.Trim & "',
            Ans4='" & TxtAns4.Text.Trim & "',
            Ans5='" & TxtAns5.Text.Trim & "',
            Clue1='" & TxtClue1.Text & "' "



        If FileUpload1.FileName <> "" Then
            vSQL += ",SoundFilePath='" & IIf(FileUpload1.FileName <> "", TargetFilename, "") & "' "
        End If

        vSQL += "where QuestId =" & TblTopic.SelectedRow.Cells(0).Text


        'Response.Write(vSQL)

        CreateRecords(vSQL)
        DataRefresh()

        If FileUpload1.FileName <> "" Then
            FileUpload1.SaveAs(TargetFilename)
        End If
        TblTopic.SelectedIndex = -1
        ScriptManager.RegisterStartupScript(Me, Page.GetType, "Script", "alert('Successfully saved');", True)
    End Sub

    Private Sub BtnDelete_ServerClick(sender As Object, e As EventArgs) Handles BtnDelete.ServerClick
        Dim QId As Int64 = TblTopic.SelectedRow.Cells(0).Text

        vSQL = "delete from tblUnscrable where QuestId=" & QId
        CreateRecords(vSQL)

        DataRefresh()
        TblTopic.SelectedIndex = -1
        ScriptManager.RegisterStartupScript(Me, Page.GetType, "Script", "alert('Successfully deleted');", True)
    End Sub

    Private Sub BtnQuesPreview_ServerClick(sender As Object, e As EventArgs) Handles BtnQuesPreview.ServerClick
        Dim VFileServerPath As String = ""

        vSQL = "select top 1 VoiceFileServerPath from tblGameConfiguration"
        VFileServerPath = GetRef(vSQL, "")

        VoiceFile.Src = TblTopic.SelectedRow.Cells(13).Text.ToString.Replace(VFileServerPath, "")

        'VoiceFile.Src = TblTopic.SelectedRow.Cells(16).Text.ToString.Replace("D:\Project\DNET\HeartBeats\WebApp\", "") '"Uploaded\VoiceFile\1032021162227.mp3"
    End Sub

    Private Sub btnSearch_Load(sender As Object, e As EventArgs) Handles btnSearch.Load
        DataRefresh()
    End Sub

    Private Sub TblTopic_SelectedIndexChanged(sender As Object, e As EventArgs) Handles TblTopic.SelectedIndexChanged
        BtnEdit.Disabled = False
        BtnDelete.Disabled = False

        TxtDescr1.Text = CleanVarSpecialChar(TblTopic.SelectedRow.Cells(1).Text)

        TxtDis1.Text = TblTopic.SelectedRow.Cells(2).Text.Replace("&nbsp;", "")
        TxtDis2.Text = TblTopic.SelectedRow.Cells(3).Text.Replace("&nbsp;", "")
        TxtDis3.Text = TblTopic.SelectedRow.Cells(4).Text.Replace("&nbsp;", "")
        TxtDis4.Text = TblTopic.SelectedRow.Cells(5).Text.Replace("&nbsp;", "")
        TxtDis5.Text = TblTopic.SelectedRow.Cells(6).Text.Replace("&nbsp;", "")

        TxtAns1.Text = TblTopic.SelectedRow.Cells(7).Text.Replace("&nbsp;", "")
        TxtAns2.Text = TblTopic.SelectedRow.Cells(8).Text.Replace("&nbsp;", "")
        TxtAns3.Text = TblTopic.SelectedRow.Cells(9).Text.Replace("&nbsp;", "")
        TxtAns4.Text = TblTopic.SelectedRow.Cells(10).Text.Replace("&nbsp;", "")
        TxtAns5.Text = TblTopic.SelectedRow.Cells(11).Text.Replace("&nbsp;", "")
        TxtClue1.Text = TblTopic.SelectedRow.Cells(12).Text.Replace("&nbsp;", "")

        DataRefresh()
        VoiceFile.Src = ""

    End Sub

    Private Sub TblTopic_PageIndexChanging(sender As Object, e As GridViewPageEventArgs) Handles TblTopic.PageIndexChanging
        TblTopic.PageIndex = e.NewPageIndex
        TblTopic.SelectedIndex = -1
        DataRefresh()
    End Sub
End Class
