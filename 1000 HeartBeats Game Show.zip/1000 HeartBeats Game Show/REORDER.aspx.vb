﻿Imports System.Data
Imports System.ComponentModel
Imports System.Media
Imports HelperClass
Partial Class REORDER
    Inherits System.Web.UI.Page
    Public vData As String = ""
    Dim vSQL As String = ""

    Private Sub REORDER_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            DataRefresh()
        End If
    End Sub

    Private Sub DataRefresh()
        Dim c As New SqlClient.SqlConnection
        Dim da As SqlClient.SqlDataAdapter
        Dim ds As New DataSet

        vSQL = "select Id,TopDesc,MidDesc,BotDesc,
            Display1,Display2,Display3,Display4,Display5,Display6,
            Ans1,Ans2,Ans3,Ans4,Ans5,Ans6,
            QuestId,SoundFilePath,CreatedBy,DateCreated,SoundFilePath  
            from tblReorder order by Id"

        'Response.Write(vSQL)
        c.ConnectionString = ConnStr
        da = New SqlClient.SqlDataAdapter(vSQL, c)

        da.Fill(ds, "TblGroup")
        TblTopic.DataSource = ds.Tables("TblGroup")
        TblTopic.DataBind()
        'lblTotal.Text = "<b>Total Employee Retrieved : " & tbl_EmpMaster.DataSource.Rows.Count & "</b>"

        da.Dispose()
        ds.Dispose()
        c.Dispose()

    End Sub

    Private Sub BtnSave_ServerClick(sender As Object, e As EventArgs) Handles BtnSave.ServerClick
        Dim SysId As Int64 = Format(Now(), "MMddyyyyHHmmss")
        Dim TargetFilename As String = Server.MapPath(".") & "\Uploaded\VoiceFile\" '& SysId & ".wav"

        vSQL = "insert into tblReorder 
            (TopDesc,MidDesc,BotDesc,
            Display1,Display2,Display3,Display4,Display5,Display6,
            Ans1,Ans2,Ans3,Ans4,Ans5,Ans6,
            QuestId,SoundFilePath,CreatedBy,DateCreated,
            SoundFilePath1,SoundFilePath2,SoundFilePath3,
            InterVal1,InterVal2,InterVal3,InterVal4) values (
            '" & TxtDescr1.Text.Trim.Replace("'", "*") & "',
            '" & TxtDescr2.Text.Trim.Replace("'", "*") & "',
            '" & TxtDescr3.Text.Trim.Replace("'", "*") & "',
            '" & TxtDis1.Text.Trim.Replace("'", "*") & "',
            '" & TxtDis2.Text.Trim.Replace("'", "*") & "',
            '" & TxtDis3.Text.Trim.Replace("'", "*") & "',
            '" & TxtDis4.Text.Trim.Replace("'", "*") & "',
            '" & TxtDis5.Text.Trim.Replace("'", "*") & "',
            '" & TxtDis6.Text.Trim.Replace("'", "*") & "',
            '" & TxtAns1.Text.Trim.Replace("'", "*") & "',
            '" & TxtAns2.Text.Trim.Replace("'", "*") & "',
            '" & TxtAns3.Text.Trim.Replace("'", "*") & "',
            '" & TxtAns4.Text.Trim.Replace("'", "*") & "',
            '" & TxtAns5.Text.Trim.Replace("'", "*") & "',
            '" & TxtAns6.Text.Trim.Replace("'", "*") & "',
            '" & SysId & "',
            '" & IIf(FileUpload1.FileName <> "", TargetFilename & SysId & "-0.wav", "") & "',
            'Admin','" & Format(Now, "MM-dd-yyyy") & "',
            '" & IIf(VOF1.FileName <> "", TargetFilename & SysId & "-1.wav", "") & "',
            '" & IIf(VOF2.FileName <> "", TargetFilename & SysId & "-2.wav", "") & "',
            '" & IIf(VOF3.FileName <> "", TargetFilename & SysId & "-3.wav", "") & "',
            '" & TxtInt1.Text.Trim & "',
            '" & TxtInt2.Text.Trim & "',
            '" & TxtInt3.Text.Trim & "',
            '" & TxtInt0.Text.Trim & "')"

        'Response.Write(vSQL)
        CreateRecords(vSQL)

        If FileUpload1.FileName <> "" Then
            FileUpload1.SaveAs(TargetFilename & SysId & "-0.wav")
        End If

        If VOF1.FileName <> "" Then
            VOF1.SaveAs(TargetFilename & SysId & "-1.wav")
        End If

        If VOF2.FileName <> "" Then
            VOF2.SaveAs(TargetFilename & SysId & "-2.wav")
        End If

        If VOF3.FileName <> "" Then
            VOF3.SaveAs(TargetFilename & SysId & "-3.wav")
        End If

        DataRefresh()
        ScriptManager.RegisterStartupScript(Me, Page.GetType, "Script", "alert('Successfully saved');", True)
    End Sub


    Private Sub TblTopic_SelectedIndexChanged(sender As Object, e As EventArgs) Handles TblTopic.SelectedIndexChanged
        BtnEdit.Disabled = False
        BtnDelete.Disabled = False

        TxtDescr1.Text = CleanVarSpecialChar(TblTopic.SelectedRow.Cells(1).Text)
        TxtDescr2.Text = CleanVarSpecialChar(TblTopic.SelectedRow.Cells(2).Text)
        TxtDescr3.Text = CleanVarSpecialChar(TblTopic.SelectedRow.Cells(3).Text)

        TxtDis1.Text = CleanVarSpecialChar(TblTopic.SelectedRow.Cells(4).Text)
        TxtDis2.Text = CleanVarSpecialChar(TblTopic.SelectedRow.Cells(5).Text)
        TxtDis3.Text = CleanVarSpecialChar(TblTopic.SelectedRow.Cells(6).Text)
        TxtDis4.Text = CleanVarSpecialChar(TblTopic.SelectedRow.Cells(7).Text)
        TxtDis5.Text = CleanVarSpecialChar(TblTopic.SelectedRow.Cells(8).Text)
        TxtDis6.Text = CleanVarSpecialChar(TblTopic.SelectedRow.Cells(9).Text)

        TxtAns1.Text = CleanVarSpecialChar(TblTopic.SelectedRow.Cells(10).Text)
        TxtAns2.Text = CleanVarSpecialChar(TblTopic.SelectedRow.Cells(11).Text)
        TxtAns3.Text = CleanVarSpecialChar(TblTopic.SelectedRow.Cells(12).Text)
        TxtAns4.Text = CleanVarSpecialChar(TblTopic.SelectedRow.Cells(13).Text)
        TxtAns5.Text = CleanVarSpecialChar(TblTopic.SelectedRow.Cells(14).Text)
        TxtAns6.Text = CleanVarSpecialChar(TblTopic.SelectedRow.Cells(15).Text)

        DataRefresh()
        VoiceFile.Src = ""

    End Sub

    Private Sub BtnUpdate_ServerClick(sender As Object, e As EventArgs) Handles BtnUpdate.ServerClick
        Dim SysId As Int64 = Format(Now(), "MMddyyyyHHmmss")
        Dim TargetFilename As String = ""

        If FileUpload1.FileName <> "" Then
            TargetFilename = Server.MapPath(".") & "\Uploaded\VoiceFile\"
        End If

        vSQL = "update tblReorder set
            TopDesc='" & TxtDescr1.Text.Trim.Replace("'", "*") & "',
            MidDesc='" & TxtDescr2.Text.Trim.Replace("'", "*") & "',
            BotDesc='" & TxtDescr3.Text.Trim.Replace("'", "*") & "',
            Display1='" & TxtDis1.Text.Trim & "',
            Display2='" & TxtDis2.Text.Trim & "',
            Display3='" & TxtDis3.Text.Trim & "',
            Display4='" & TxtDis4.Text.Trim & "',
            Display5='" & TxtDis5.Text.Trim & "',
            Display6='" & TxtDis6.Text.Trim & "',
            Ans1='" & TxtAns1.Text.Trim & "',
            Ans2='" & TxtAns2.Text.Trim & "',
            Ans3='" & TxtAns3.Text.Trim & "',
            Ans4='" & TxtAns4.Text.Trim & "',
            Ans5='" & TxtAns5.Text.Trim & "',
            Ans6='" & TxtAns6.Text.Trim & "',
            InterVal1='" & TxtInt1.Text.Trim & "', 
            InterVal2='" & TxtInt2.Text.Trim & "', 
            InterVal3='" & TxtInt3.Text.Trim & "', 
            InterVal4='" & TxtInt0.Text.Trim & "' "

        If FileUpload1.FileName <> "" Then
            vSQL += ",SoundFilePath='" & TargetFilename & SysId & "-0.wav" & "' "
        End If

        If VOF1.FileName <> "" Then
            vSQL += ",SoundFilePath1='" & TargetFilename & SysId & "-1.wav" & "' "
        End If
        If VOF2.FileName <> "" Then
            vSQL += ",SoundFilePath2='" & TargetFilename & SysId & "-2.wav" & "' "
        End If
        If VOF3.FileName <> "" Then
            vSQL += ",SoundFilePath3='" & TargetFilename & SysId & "-3.wav" & "' "
        End If


        vSQL += "where 
            QuestId=" & TblTopic.SelectedRow.Cells(0).Text

        'Response.Write(vSQL)
        CreateRecords(vSQL)
        DataRefresh()

        'If FileUpload1.FileName <> "" Then
        '    FileUpload1.SaveAs(TargetFilename)
        'End If

        If FileUpload1.FileName <> "" Then
            FileUpload1.SaveAs(TargetFilename & SysId & "-0.wav")
        End If

        If VOF1.FileName <> "" Then
            VOF1.SaveAs(TargetFilename & SysId & "-1.wav")
        End If

        If VOF2.FileName <> "" Then
            VOF2.SaveAs(TargetFilename & SysId & "-2.wav")
        End If

        If VOF3.FileName <> "" Then
            VOF3.SaveAs(TargetFilename & SysId & "-3.wav")
        End If


        TblTopic.SelectedIndex = -1
        ScriptManager.RegisterStartupScript(Me, Page.GetType, "Script", "alert('Successfully saved');", True)
    End Sub


    Private Sub BtnDeleteTopic_ServerClick(sender As Object, e As EventArgs) Handles BtnDeleteTopic.ServerClick
        Dim QId As Int64 = TblTopic.SelectedRow.Cells(0).Text

        vSQL = "delete from tblReorder where QuestId=" & QId
        CreateRecords(vSQL)

        DataRefresh()
        TblTopic.SelectedIndex = -1
        ScriptManager.RegisterStartupScript(Me, Page.GetType, "Script", "alert('Successfully deleted');", True)
    End Sub

    Private Sub BtnQuesPreview_ServerClick(sender As Object, e As EventArgs) Handles BtnQuesPreview.ServerClick

        Dim VFileServerPath As String = ""

        vSQL = "select top 1 VoiceFileServerPath from tblGameConfiguration"
        VFileServerPath = GetRef(vSQL, "")

        VoiceFile.Src = TblTopic.SelectedRow.Cells(16).Text.ToString.Replace(VFileServerPath, "")

        'VoiceFile.Src = TblTopic.SelectedRow.Cells(16).Text.ToString.Replace("D:\Project\DNET\HeartBeats\WebApp\", "") '"Uploaded\VoiceFile\1032021162227.mp3"
    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        DataRefresh()
    End Sub

    Private Sub TblTopic_PageIndexChanged(sender As Object, e As GridViewPageEventArgs) Handles TblTopic.PageIndexChanging
        TblTopic.PageIndex = e.NewPageIndex
        TblTopic.SelectedIndex = -1
        DataRefresh()
    End Sub
End Class
