﻿Imports System.Data
Imports HelperClass
Partial Class ContestantMaint
    Inherits System.Web.UI.Page
    Dim vSQL As String = ""
    Private Sub ContestantMaint_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            GetContestantList()
        End If
    End Sub

    Private Sub BtnSubmitSave_ServerClick(sender As Object, e As EventArgs) Handles BtnSubmitSave.ServerClick
        Dim EmpCode As Int64 = Format(Now(), "MMddyyyyHHmmss")

        If TxtFName.Text.Trim = "" Or TxtMidName.Text.Trim = "" Or TxtLastName.Text.Trim = "" Then
            ScriptManager.RegisterStartupScript(Me, Page.GetType, "Script", "alert('Please complete the contestant full name'); OperModal();", True)
            Exit Sub
        End If

        vSQL = "insert into tblEmployees (EmployeeCode,FirstName, MiddleName, LastName, EmailAddress, AddressLocal, MobileNo) values (" _
                & "'" & EmpCode & "'," _
                & "'" & TxtFName.Text.Trim & "'," _
                & "'" & TxtMidName.Text.Trim & "'," _
                & "'" & TxtLastName.Text.Trim & "'," _
                & "'" & TxtEmail.Text.Trim & "'," _
                & "'" & TxtAddress.Text.Trim & "'," _
                & "'" & TxtMobile.Text.Trim & "')"

        CreateRecords(vSQL)
        GetContestantList()

        ScriptManager.RegisterStartupScript(Me, Page.GetType, "Script", "alert('Successfully saved');", True)
    End Sub

    Private Sub GetContestantList()
        Dim c As New SqlClient.SqlConnection
        Dim da As SqlClient.SqlDataAdapter
        Dim ds As New DataSet
        Dim vFilter As String = ""
        Dim vTableName As String = ""
        Dim vSQL As String = ""

        c.ConnectionString = ConnStr
        vSQL = "select EmployeeCode,FirstName, MiddleName, LastName, EmailAddress, AddressLocal, MobileNo " _
            & "from tblEmployees " _
            & " " _
            & "order by LastName "
        'Response.Write(vSQL)

        da = New SqlClient.SqlDataAdapter(vSQL, c)

        da.Fill(ds, "tblContestantList")
        tblContestantList.DataSource = ds.Tables("tblContestantList")
        tblContestantList.DataBind()

        da.Dispose()
        ds.Dispose()
    End Sub

    Private Sub BtnReload_Click(sender As Object, e As EventArgs) Handles BtnReload.Click
        GetContestantList()
    End Sub

    Private Sub tblContestantList_SelectedIndexChanged(sender As Object, e As EventArgs) Handles tblContestantList.SelectedIndexChanged
        GetContestantList()
        BtnAdd.Disabled = False
        BtnEdit.Disabled = True
        BtnDelete.Disabled = True
        tblContestantList.SelectedIndex = -1
    End Sub

    Private Sub tblDocumentType_PageIndexChanging(sender As Object, e As GridViewPageEventArgs) Handles tblContestantList.PageIndexChanging
        tblContestantList.PageIndex = e.NewPageIndex
        tblContestantList.SelectedIndex = -1
        GetContestantList()
    End Sub


End Class
