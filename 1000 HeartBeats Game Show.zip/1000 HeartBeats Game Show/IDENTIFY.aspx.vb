﻿Imports System.Data
Imports HelperClass
Partial Class IDENTIFY
    Inherits System.Web.UI.Page
    Public vData As String = ""
    Dim vSQL As String = ""
    Private Sub IDENTIFY_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            DataRefresh()
        End If
    End Sub
    Private Sub DataRefresh()
        Dim c As New SqlClient.SqlConnection
        Dim da As SqlClient.SqlDataAdapter
        Dim ds As New DataSet

        vSQL = "select Id,TopDesc,
            Display1,Display2,Display3,Display4,Display5,Display6,Display7,Display8,
            Ans1,Ans2,Ans3,Ans4,Ans5,Ans6,Ans7,Ans8,
            QuestId,SoundFilePath,CreatedBy,DateCreated,SoundFilePath  
            from tblIdentify order by Id"

        'Response.Write(vSQL)
        c.ConnectionString = ConnStr
        da = New SqlClient.SqlDataAdapter(vSQL, c)

        da.Fill(ds, "TblGroup")
        TblTopic.DataSource = ds.Tables("TblGroup")
        TblTopic.DataBind()
        'lblTotal.Text = "<b>Total Employee Retrieved : " & tbl_EmpMaster.DataSource.Rows.Count & "</b>"

        da.Dispose()
        ds.Dispose()
        c.Dispose()

    End Sub

    Private Sub BtnSave_ServerClick(sender As Object, e As EventArgs) Handles BtnSave.ServerClick
        Dim SysId As Int64 = Format(Now(), "MMddyyyyHHmmss")
        Dim TargetFilename As String = Server.MapPath(".") & "\Uploaded\VoiceFile\" & SysId & ".wav"

        vSQL = "insert into tblIdentify 
            (TopDesc,
            Display1,Display2,Display3,Display4,Display5,Display6,Display7,Display8,
            Ans1,Ans2,Ans3,Ans4,Ans5,Ans6,Ans7,Ans8,
            QuestId,SoundFilePath,CreatedBy,DateCreated) values (
            '" & TxtDescr1.Text.Trim.Replace("'", "*") & "',
            '" & TxtDis1.Text.Trim.Replace("'", "*") & "',
            '" & TxtDis2.Text.Trim.Replace("'", "*") & "',
            '" & TxtDis3.Text.Trim.Replace("'", "*") & "',
            '" & TxtDis4.Text.Trim.Replace("'", "*") & "',
            '" & TxtDis5.Text.Trim.Replace("'", "*") & "',
            '" & TxtDis6.Text.Trim.Replace("'", "*") & "',
            '" & TxtDis7.Text.Trim.Replace("'", "*") & "',
            '" & TxtDis8.Text.Trim.Replace("'", "*") & "',
            '" & TxtAns1.Text.Trim.Replace("'", "*") & "',
            '" & TxtAns2.Text.Trim.Replace("'", "*") & "',
            '" & TxtAns3.Text.Trim.Replace("'", "*") & "',
            '" & TxtAns4.Text.Trim.Replace("'", "*") & "',
            '" & TxtAns5.Text.Trim.Replace("'", "*") & "',
            '" & TxtAns6.Text.Trim.Replace("'", "*") & "',
            '" & TxtAns7.Text.Trim.Replace("'", "*") & "',
            '" & TxtAns8.Text.Trim.Replace("'", "*") & "',
            '" & SysId & "',
            '" & IIf(FileUpload1.FileName <> "", TargetFilename, "") & "',
            'Admin',
            '" & Format(Now, "MM-dd-yyyy") & "')"

        'Response.Write(vSQL)
        CreateRecords(vSQL)

        If FileUpload1.FileName <> "" Then
            FileUpload1.SaveAs(TargetFilename)
        End If
        DataRefresh()
        ScriptManager.RegisterStartupScript(Me, Page.GetType, "Script", "alert('Successfully saved');", True)
    End Sub

    Private Sub BtnUpdate_ServerClick(sender As Object, e As EventArgs) Handles BtnUpdate.ServerClick
        Dim SysId As Int64 = Format(Now(), "MMddyyyyHHmmss")
        Dim TargetFilename As String = ""

        If FileUpload1.FileName <> "" Then
            TargetFilename = Server.MapPath(".") & "\Uploaded\VoiceFile\" & SysId & ".wav"
        End If

        vSQL = "update tblIdentify set
            TopDesc='" & TxtDescr1.Text.Trim.Replace("&amp;", "").Replace("'", "*") & "',
            Display1='" & TxtDis1.Text.Trim & "',
            Display2='" & TxtDis2.Text.Trim & "',
            Display3='" & TxtDis3.Text.Trim & "',
            Display4='" & TxtDis4.Text.Trim & "',
            Display5='" & TxtDis5.Text.Trim & "',
            Display6='" & TxtDis6.Text.Trim & "',
            Display7='" & TxtDis7.Text.Trim & "',
            Display8='" & TxtDis8.Text.Trim & "',
            Ans1='" & TxtAns1.Text.Trim & "',
            Ans2='" & TxtAns2.Text.Trim & "',
            Ans3='" & TxtAns3.Text.Trim & "',
            Ans4='" & TxtAns4.Text.Trim & "',
            Ans5='" & TxtAns5.Text.Trim & "',
            Ans6='" & TxtAns6.Text.Trim & "',
            Ans7='" & TxtAns7.Text.Trim & "',
            Ans8='" & TxtAns8.Text.Trim & "'"

        If FileUpload1.FileName <> "" Then
            vSQL += ",SoundFilePath='" & IIf(FileUpload1.FileName <> "", TargetFilename, "") & "' "
        End If

        vSQL += "where 
            QuestId=" & TblTopic.SelectedRow.Cells(0).Text

        'Response.Write(vSQL)
        CreateRecords(vSQL)
        DataRefresh()

        If FileUpload1.FileName <> "" Then
            FileUpload1.SaveAs(TargetFilename)
        End If
        TblTopic.SelectedIndex = -1
        ScriptManager.RegisterStartupScript(Me, Page.GetType, "Script", "alert('Successfully saved');", True)
    End Sub

    Private Sub TblTopic_SelectedIndexChanged(sender As Object, e As EventArgs) Handles TblTopic.SelectedIndexChanged
        BtnEdit.Disabled = False
        BtnDelete.Disabled = False

        TxtDescr1.Text = CleanVarSpecialChar(TblTopic.SelectedRow.Cells(1).Text)

        TxtDis1.Text = TblTopic.SelectedRow.Cells(2).Text.Replace("&nbsp;", "")
        TxtDis2.Text = TblTopic.SelectedRow.Cells(3).Text.Replace("&nbsp;", "")
        TxtDis3.Text = TblTopic.SelectedRow.Cells(4).Text.Replace("&nbsp;", "")
        TxtDis4.Text = TblTopic.SelectedRow.Cells(5).Text.Replace("&nbsp;", "")
        TxtDis5.Text = TblTopic.SelectedRow.Cells(6).Text.Replace("&nbsp;", "")
        TxtDis6.Text = TblTopic.SelectedRow.Cells(7).Text.Replace("&nbsp;", "")
        TxtDis7.Text = TblTopic.SelectedRow.Cells(8).Text.Replace("&nbsp;", "")
        TxtDis8.Text = TblTopic.SelectedRow.Cells(9).Text.Replace("&nbsp;", "")

        TxtAns1.Text = TblTopic.SelectedRow.Cells(10).Text.Replace("&nbsp;", "")
        TxtAns2.Text = TblTopic.SelectedRow.Cells(11).Text.Replace("&nbsp;", "")
        TxtAns3.Text = TblTopic.SelectedRow.Cells(12).Text.Replace("&nbsp;", "")
        TxtAns4.Text = TblTopic.SelectedRow.Cells(13).Text.Replace("&nbsp;", "")
        TxtAns5.Text = TblTopic.SelectedRow.Cells(14).Text.Replace("&nbsp;", "")
        TxtAns6.Text = TblTopic.SelectedRow.Cells(15).Text.Replace("&nbsp;", "")
        TxtAns7.Text = TblTopic.SelectedRow.Cells(16).Text.Replace("&nbsp;", "")
        TxtAns8.Text = TblTopic.SelectedRow.Cells(17).Text.Replace("&nbsp;", "")

        DataRefresh()
        VoiceFile.Src = ""

    End Sub

    Private Sub BtnDeleteTopic_ServerClick(sender As Object, e As EventArgs) Handles BtnDeleteTopic.ServerClick
        Dim QId As Int64 = TblTopic.SelectedRow.Cells(0).Text

        vSQL = "delete from tblIdentify where QuestId=" & QId
        CreateRecords(vSQL)
        'Response.Write(vSQL)

        DataRefresh()
        TblTopic.SelectedIndex = -1
        ScriptManager.RegisterStartupScript(Me, Page.GetType, "Script", "alert('Successfully deleted');", True)
    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        DataRefresh()
    End Sub

    Private Sub BtnQuesPreview_ServerClick(sender As Object, e As EventArgs) Handles BtnQuesPreview.ServerClick

        Dim VFileServerPath As String = ""

        vSQL = "select top 1 VoiceFileServerPath from tblGameConfiguration"
        VFileServerPath = GetRef(vSQL, "")

        VoiceFile.Src = TblTopic.SelectedRow.Cells(14).Text.ToString.Replace(VFileServerPath, "")

        'VoiceFile.Src = TblTopic.SelectedRow.Cells(16).Text.ToString.Replace("D:\Project\DNET\HeartBeats\WebApp\", "") '"Uploaded\VoiceFile\1032021162227.mp3"
    End Sub

    Private Sub TblQuestionList_PageIndexChanging(sender As Object, e As GridViewPageEventArgs) Handles TblTopic.PageIndexChanging
        TblTopic.PageIndex = e.NewPageIndex
        TblTopic.SelectedIndex = -1
        DataRefresh()
    End Sub
End Class
