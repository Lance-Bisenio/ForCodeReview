﻿Imports System.Data
Imports HelperClass
Partial Class GroupMaint
    Inherits System.Web.UI.Page
    Public vData As String = ""
    Dim vSQL As String = ""

    Private Sub GroupMaint_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            DataRefresh()
        End If
    End Sub

    Private Sub DataRefresh()
        Dim c As New SqlClient.SqlConnection
        Dim da As SqlClient.SqlDataAdapter
        Dim ds As New DataSet
        Dim vFilter As String = ""
        Dim vTableName As String = "PowerBill_Generated"
        Dim vColSource As String = ""

        vColSource = ""

        vSQL = "select * from tblGroup order by Name"

        'Response.Write(vSQL)
        c.ConnectionString = connStr
        da = New SqlClient.SqlDataAdapter(vSQL, c)

        da.Fill(ds, "TblGroup")
        TblGroup.DataSource = ds.Tables("TblGroup")
        TblGroup.DataBind()
        'lblTotal.Text = "<b>Total Employee Retrieved : " & tbl_EmpMaster.DataSource.Rows.Count & "</b>"

        da.Dispose()
        ds.Dispose()
        c.Dispose()

    End Sub

    Private Sub BtnSubmitSave_ServerClick(sender As Object, e As EventArgs) Handles BtnSubmitSave.ServerClick
        Dim Gcode As String = Format(Now, "MMddyyyHHmmss")

        If TxtGroupName.Text.Trim = "" Then
            ScriptManager.RegisterStartupScript(Me, Page.GetType, "Script", "alert('Please enter group desction'); $('#EarningsForm').modal();", True)
            Exit Sub
        End If

        vSQL = "insert into tblGroup (Code,Name,Active,Ranking,ClientId) values " _
            & "('" & Gcode & "','" & TxtGroupName.Text.Trim & "',1,0,0)"

        CreateRecords(vSQL)
        ScriptManager.RegisterStartupScript(Me, Page.GetType, "Script", "alert('Successfully saved');", True)
        DataRefresh()
    End Sub

    Private Sub TblGroup_SelectedIndexChanged(sender As Object, e As EventArgs) Handles TblGroup.SelectedIndexChanged
        ContestantList()
    End Sub

    Private Sub BtnDelete_ServerClick(sender As Object, e As EventArgs) Handles BtnDelete.ServerClick
        vSQL = "delete from tblGroup where Code='" & TblGroup.SelectedRow.Cells(1).Text & "'"
        Response.Write(vSQL)
        CreateRecords(vSQL)
        ScriptManager.RegisterStartupScript(Me, Page.GetType, "Script", "alert('Successfully deleted');", True)
        DataRefresh()
    End Sub

    Private Sub ContestantList()

        Dim cm As New SqlClient.SqlCommand
        Dim c As New SqlClient.SqlConnection
        Dim rs As SqlClient.SqlDataReader
        Dim vCheck As String = ""
        c.ConnectionString = ConnStr

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            'vScript = "alert('Error occurred while trying to connect to database. Error code 101; Error is: " & ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        cm.Connection = c

        vSQL = "select Id, EmployeeCode, FullName, " _
        & "(select count(EmpCode) as Ctr from tblEnployeeGroup where " _
            & "EmpCode=EmployeeCode and GCode='" & TblGroup.SelectedRow.Cells(0).Text & "' ) as Active " _
        & "from tblEmployees order by FullName"

        'Response.Write(vSQL)
        cm.CommandText = vSQL '"select MenuId, Label from tblMenus"
        rs = cm.ExecuteReader

        Do While rs.Read
            'If Session("SelectAll") = "Yes" Then
            '    vCheck = " checked='checked' "
            'Else

            'End If

            If rs("Active") > 0 Then
                vCheck = " checked='checked' "
            End If

            vData += "<div Class='checkbox'><label>"
            vData += "<input type='checkbox' id='" & rs("EmployeeCode") & "' name='" & rs("EmployeeCode") & "' " & vCheck & "> " & rs(2)
            vData += "</label></div>"

            If Request.Item(rs("EmployeeCode")) = "on" And Session("IsSave") = "Yes" Then
                vSQL = "delete from tblEnployeeGroup where " _
                    & "GCode='" & TblGroup.SelectedRow.Cells(0).Text & "' and " _
                    & "EmpCode='" & rs("EmployeeCode") & "'"
                CreateRecords(vSQL)

                vSQL = "insert into tblEnployeeGroup (GCode, EmpCode, OrderBy) values (" _
                    & "'" & TblGroup.SelectedRow.Cells(0).Text & "','" & rs("EmployeeCode") & "',0)"
                CreateRecords(vSQL)

            End If

            If Request.Item(rs("EmployeeCode")) = "" And Session("IsSave") = "Yes" Then
                vSQL = "delete from tblEnployeeGroup where " _
                    & "GCode='" & TblGroup.SelectedRow.Cells(0).Text & "' and " _
                    & "EmpCode='" & rs("EmployeeCode") & "'"


                CreateRecords(vSQL)
            End If


            vCheck = ""
        Loop
        rs.Close()

        cm.Dispose()
        c.Close()

        If Session("IsSave") = "Yes" Then
            ScriptManager.RegisterStartupScript(Me, Page.GetType, "Script", "alert('Successfully saved');", True)
            Session("IsSave") = ""
            vData = ""
            ContestantList()
        End If

    End Sub

    Private Sub BtnAddtoGroup_Click(sender As Object, e As EventArgs) Handles BtnAddtoGroup.Click
        Session("IsSave") = "Yes"
        ContestantList()
    End Sub
End Class
