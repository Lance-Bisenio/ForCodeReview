﻿Imports System.Data
Imports HelperClass
Partial Class KEEPUP
    Inherits System.Web.UI.Page
    Public vData As String = ""
    Public vOrderBy As String = ""
    Dim vSQL As String = ""

    Dim SeqCode As String = ""

    Private Sub KEEPUP_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            DataRefresh()
            GetProfileList()
            'SequenceList()
            Session("IsSave") = ""
        End If
    End Sub

    Private Sub GetSequenceList()
        Dim c As New SqlClient.SqlConnection
        Dim da As SqlClient.SqlDataAdapter
        Dim ds As New DataSet

        vSQL = "select QTypeId,SCode,Descr,OrderBy from tblKeepUPSequenceHdr " _
            & "where QTypeId=" & TblProfile.SelectedRow.Cells(0).Text.Replace("&nbsp;", "") _
            & "order by OrderBy"

        'Response.Write(vSQL)
        c.ConnectionString = ConnStr
        da = New SqlClient.SqlDataAdapter(vSQL, c)

        da.Fill(ds, "SequenceList")
        TblSequenceList.DataSource = ds.Tables("SequenceList")
        TblSequenceList.DataBind()
        'lblTotal.Text = "<b>Total Employee Retrieved : " & tbl_EmpMaster.Data



        da.Dispose()
        ds.Dispose()
        c.Dispose()

    End Sub

    Private Sub GetProfileList()
        Dim c As New SqlClient.SqlConnection
        Dim da As SqlClient.SqlDataAdapter
        Dim ds As New DataSet

        vSQL = "select QType, Descr from tblKeepUPHdr order by Descr"

        'Response.Write(vSQL)
        c.ConnectionString = ConnStr
        da = New SqlClient.SqlDataAdapter(vSQL, c)

        da.Fill(ds, "TblProfile")
        TblProfile.DataSource = ds.Tables("TblProfile")
        TblProfile.DataBind()
        'lblTotal.Text = "<b>Total Employee Retrieved : " & tbl_EmpMaster.Data

        da.Dispose()
        ds.Dispose()
        c.Dispose()

    End Sub

    Private Sub DataRefresh()
        Dim c As New SqlClient.SqlConnection
        Dim da As SqlClient.SqlDataAdapter
        Dim ds As New DataSet

        vSQL = "select Id,TopDesc,
            Display1,Ans1,IsUsed,OrderBy,
            QuestId,SoundFilePath,CreatedBy,DateCreated,SoundFilePath,QType,SType
            from tblKeepUP "

        If SeqCode <> "" Then
            vSQL += "where SType='" & TblSequenceList.SelectedRow.Cells(0).Text.Replace("&nbsp;", "") & "' "
        End If

        vSQL += " order by SType, OrderBy"
        'Response.Write(vSQL)


        c.ConnectionString = ConnStr
        da = New SqlClient.SqlDataAdapter(vSQL, c)

        da.Fill(ds, "TblGroup")
        TblTopic.DataSource = ds.Tables("TblGroup")
        TblTopic.DataBind()
        'lblTotal.Text = "<b>Total Employee Retrieved : " & tbl_EmpMaster.DataSource.Rows.Count & "</b>"

        da.Dispose()
        ds.Dispose()
        c.Dispose()

    End Sub

    Private Sub BtnSave_ServerClick(sender As Object, e As EventArgs) Handles BtnSave.ServerClick
        Dim SysId As Int64 = Format(Now(), "MMddyyyyHHmmss")
        Dim TargetFilename As String = Server.MapPath(".") & "\Uploaded\VoiceFile\" & SysId & ".wav"

        vSQL = "insert into tblKeepUP 
            (TopDesc,Display1,Ans1,QuestId,SoundFilePath,CreatedBy,DateCreated,OrderBy, IsUsed,SType) values ('" _
            & TxtDescr.Text.Trim.Replace("'", "*") & "','" _
            & TxtDis1.Text.Trim.Replace("'", "*") & "','" _
            & TxtAns.Text.Trim.Replace("'", "*") & "','" _
            & SysId & "','" _
            & IIf(FileUpload1.FileName <> "", TargetFilename, "") & "','Admin','" _
            & Format(Now, "MM-dd-yyyy") & "'," _
        & IIf(TxtOrderBy.Text.Trim = "", 0, TxtOrderBy.Text.Trim) & "," _
        & IIf(TxtUsed.Text.Trim = "", 0, TxtUsed.Text.Trim) & ",'" & TxtGroup.Text.Trim & "')"
        'Response.Write(vSQL)
        CreateRecords(vSQL)

        If FileUpload1.FileName <> "" Then
            FileUpload1.SaveAs(TargetFilename)
        End If
        DataRefresh()

        TxtDescr.Text = ""
        TxtDis1.Text = ""
        TxtAns.Text = ""

        ScriptManager.RegisterStartupScript(Me, Page.GetType, "Script", "alert('Successfully saved');", True)
    End Sub

    Private Sub BtnUpdate_ServerClick(sender As Object, e As EventArgs) Handles BtnUpdate.ServerClick
        Dim SysId As Int64 = Format(Now(), "MMddyyyyHHmmss")
        Dim TargetFilename As String = ""

        If FileUpload1.FileName <> "" Then
            TargetFilename = Server.MapPath(".") & "\Uploaded\VoiceFile\" & SysId & ".wav"
        End If

        vSQL = "update tblKeepUP set
            TopDesc='" & TxtDescr.Text.Trim & "',
            Display1='" & TxtDis1.Text.Trim & "',
            OrderBy=" & TxtOrderBy.Text.Trim & ", 
            IsUsed=" & TxtUsed.Text.Trim & ",
            SType='" & TxtGroup.Text.Trim & "',
            Ans1='" & TxtAns.Text.Trim & "' "

        If FileUpload1.FileName <> "" Then
            vSQL += ",SoundFilePath='" & IIf(FileUpload1.FileName <> "", TargetFilename, "") & "' "
        End If

        vSQL += "where QuestId=" & TblTopic.SelectedRow.Cells(0).Text

        'Response.Write(vSQL)
        CreateRecords(vSQL)
        DataRefresh()

        If FileUpload1.FileName <> "" Then
            FileUpload1.SaveAs(TargetFilename)
        End If
        TblTopic.SelectedIndex = -1

        TxtDescr.Text = ""
        TxtDis1.Text = ""
        TxtAns.Text = ""
        ScriptManager.RegisterStartupScript(Me, Page.GetType, "Script", "alert('Successfully saved');", True)
    End Sub

    Private Sub TblTopic_SelectedIndexChanged(sender As Object, e As EventArgs) Handles TblTopic.SelectedIndexChanged
        BtnEdit.Disabled = False
        BtnDelete.Disabled = False

        TxtDescr.Text = TblTopic.SelectedRow.Cells(2).Text.Replace("&nbsp;", "")
        TxtDis1.Text = TblTopic.SelectedRow.Cells(1).Text.Replace("&nbsp;", "")
        TxtAns.Text = TblTopic.SelectedRow.Cells(3).Text.Replace("&nbsp;", "")
        TxtUsed.Text = TblTopic.SelectedRow.Cells(5).Text.Replace("&nbsp;", "")
        TxtOrderBy.Text = TblTopic.SelectedRow.Cells(6).Text.Replace("&nbsp;", "")
        TxtGroup.Text = TblTopic.SelectedRow.Cells(7).Text.Replace("&nbsp;", "")

        'DataRefresh()
        VoiceFile.Src = ""

    End Sub

    Private Sub BtnDeleteTopic_ServerClick(sender As Object, e As EventArgs) Handles BtnDeleteTopic.ServerClick
        Dim QId As Int64 = TblTopic.SelectedRow.Cells(0).Text

        vSQL = "delete from tblKeepUP where QuestId=" & QId
        CreateRecords(vSQL)

        DataRefresh()
        TblTopic.SelectedIndex = -1
        ScriptManager.RegisterStartupScript(Me, Page.GetType, "Script", "alert('Successfully deleted');", True)
    End Sub

    Private Sub BtnQuesPreview_ServerClick(sender As Object, e As EventArgs) Handles BtnQuesPreview.ServerClick

        Dim VFileServerPath As String = ""

        vSQL = "select top 1 VoiceFileServerPath from tblGameConfiguration"
        VFileServerPath = GetRef(vSQL, "")

        VoiceFile.Src = TblTopic.SelectedRow.Cells(4).Text.ToString.Replace(VFileServerPath, "")

        'VoiceFile.Src = TblTopic.SelectedRow.Cells(16).Text.ToString.Replace("D:\Project\DNET\HeartBeats\WebApp\", "") '"Uploaded\VoiceFile\1032021162227.mp3"
    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        DataRefresh()
    End Sub

    Private Sub TblTopic_PageIndexChanging(sender As Object, e As GridViewPageEventArgs) Handles TblTopic.PageIndexChanging
        TblTopic.PageIndex = e.NewPageIndex
        TblTopic.SelectedIndex = -1
        DataRefresh()
    End Sub

    Private Sub BtnProfileSave_ServerClick(sender As Object, e As EventArgs) Handles BtnProfileSave.ServerClick
        Dim SysId As Integer = 0

        SysId = GetRef("select top 1 QType from tblKeepUPHdr order by QType desc", "") + 5

        vSQL = "insert into tblKeepUPHdr (QType,Descr) values (" & SysId & ",'" & TxtProfileDescr.Text.Trim & "')"
        CreateRecords(vSQL)

        GetProfileList()

        TxtProfileDescr.Text = ""

        ScriptManager.RegisterStartupScript(Me, Page.GetType, "Script", "alert('Successfully saved');", True)
    End Sub

    Private Sub TblProfile_SelectedIndexChanged(sender As Object, e As EventArgs) Handles TblProfile.SelectedIndexChanged
        BtnProfileEdit.Disabled = False
        BtnProfileDel.Disabled = False
        TxtProfileDescr.Text = TblProfile.SelectedRow.Cells(1).Text.Replace("&nbsp;", "")
        SequenceList()
        GetSequenceList()
        TblSequenceList.SelectedIndex = -1
    End Sub

    Private Sub BtnNewProfileDel_ServerClick(sender As Object, e As EventArgs) Handles BtnProfileDel.ServerClick
        vSQL = "delete from tblKeepUPHdr " _
           & "where Qtype=" & TblProfile.SelectedRow.Cells(0).Text.Replace("&nbsp;", "")
        CreateRecords(vSQL)

        GetProfileList()

        DataRefresh()
        TblProfile.SelectedIndex = -1
        ScriptManager.RegisterStartupScript(Me, Page.GetType, "Script", "alert('Successfully deleted');", True)
    End Sub

    Private Sub BtnProfileUpdate_ServerClick(sender As Object, e As EventArgs) Handles BtnProfileUpdate.ServerClick
        vSQL = "update tblKeepUPHdr set Descr='" & TxtProfileDescr.Text.Trim.Replace("'", "*") & "' " _
            & "where Qtype=" & TblProfile.SelectedRow.Cells(0).Text.Replace("&nbsp;", "")
        CreateRecords(vSQL)
        GetProfileList()

        TxtProfileDescr.Text = ""

        'ScriptManager.RegisterStartupScript(Me, Page.GetType, "Script", "alert('Successfully saved');", True)
        Session("IsSave") = "Yes"
        SequenceList()
        Session("IsSave") = ""
    End Sub

    Private Sub SequenceList()
        'Session("IsSave") = ""
        Dim c As New SqlClient.SqlConnection
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader

        Dim cmsub As New SqlClient.SqlCommand
        Dim rssub As SqlClient.SqlDataReader

        Dim vCheck As String = ""
        Dim OrderNo As Integer = 0
        c.ConnectionString = ConnStr

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            'vScript = "alert('Error occurred while trying to connect to database. Error code 101; Error is: " & ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        cm.Connection = c
        cmsub.Connection = c

        If Session("IsSave") = "Yes" Then
            vSQL = "delete from tblKeepUPSequenceHdr where " _
                               & "QTypeId='" & TblProfile.SelectedRow.Cells(0).Text & "' "
            CreateRecords(vSQL)
        End If


        vSQL = "select Distinct(SType) as STypeCode from tblKeepUP order by SType"

        'Response.Write(vSQL)
        cm.CommandText = vSQL '"select MenuId, Label from tblMenus"
        rs = cm.ExecuteReader

        Do While rs.Read
            OrderNo += 10

            'If Session("SelectAll") = "Yes" Then
            '    vCheck = " checked='checked' "
            'Else

            'End If
            'If rs("Active") > 0 Then
            '    vCheck = " checked='checked' "
            'End If
            'Response.Write(Request.Item(rs("STypeCode")))

            vData += "<div class='row'><div class='col-sm-3'>" _
                & "<input type='text' class='form-control form-control-sm col-sm-8' " _
                & "id='txt" & rs("STypeCode") & "' name='txt" & rs("STypeCode") & "' value='" & OrderNo & "'></div>"

            vData += "<div class='col-sm-9'><div class='form-check-inline' >" _
                & "<label><input type='checkbox' id='" & rs("STypeCode") & "' name='" & rs("STypeCode") & "' " & vCheck & ">&nbsp;" _
                & "Sequence " & rs("STypeCode") & "</label></div></div></div>"



            'vData += "<div Class='form-check-inline'>" _
            '    & "<div class='row'>&nbsp;</div>"
            'vData += "<div class='col-sm-6'><div Class='checkbox'><label>" _
            '    & "<input type='checkbox' id='" & rs("STypeCode") & "' name='" & rs("STypeCode") & "' " & vCheck & "> Sequence " & rs("STypeCode")
            'vData += "</label></div></div></div></div>"

            If Session("IsSave") = "Yes" Then
                If Request.Item(rs("STypeCode")) = "on" Then
                    vSQL = "insert into tblKeepUPSequenceHdr (QTypeId, SCode, Descr, OrderBy) values (" _
                        & "'" & TblProfile.SelectedRow.Cells(0).Text & "','" & rs("STypeCode") & "','" & rs("STypeCode") & "'," & Request.Item("txt" & rs("STypeCode")) & ")"
                    CreateRecords(vSQL)
                End If
            End If


            vCheck = ""
        Loop
        rs.Close()

        cm.Dispose()
        c.Close()

        If Session("IsSave") = "Yes" Then
            ScriptManager.RegisterStartupScript(Me, Page.GetType, "Script", "alert('Successfully saved');", True)
            Session("IsSave") = ""
            vData = ""

        End If

        Session("IsSave") = ""
    End Sub

    Private Sub TblSequenceList_SelectedIndexChanged(sender As Object, e As EventArgs) Handles TblSequenceList.SelectedIndexChanged
        Session("SeqCode") = TblSequenceList.SelectedRow.Cells(0).Text
        SeqCode = TblSequenceList.SelectedRow.Cells(0).Text
        DataRefresh()
        SeqCode = ""
    End Sub

    Private Sub TblProfile_PageIndexChanging(sender As Object, e As GridViewPageEventArgs) Handles TblProfile.PageIndexChanging
        TblProfile.PageIndex = e.NewPageIndex
        TblProfile.SelectedIndex = -1
        GetProfileList()
    End Sub

    Private Sub BtnClear_Click(sender As Object, e As EventArgs) Handles BtnClear.Click
        Session.Clear()
    End Sub

    Private Sub BtnReset_Click(sender As Object, e As EventArgs) Handles BtnReset.Click
        vSQL = "update tblKeepUP set IsUsed=0 where SType='" & TblSequenceList.SelectedRow.Cells(0).Text & "'"
        CreateRecords(vSQL)

        SeqCode = TblSequenceList.SelectedRow.Cells(0).Text
        DataRefresh()
        SeqCode = ""
        TblTopic.SelectedIndex = -1

    End Sub
End Class
