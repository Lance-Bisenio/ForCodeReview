﻿
Partial Class AccessDenied
    Inherits System.Web.UI.Page

End Class
