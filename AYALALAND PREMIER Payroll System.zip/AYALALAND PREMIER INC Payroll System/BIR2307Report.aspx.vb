﻿
Partial Class BIR2307Report
    Inherits System.Web.UI.Page

End Class
