Imports denaro
Partial Class philhealth_er2
    Inherits System.Web.UI.Page
    Dim c As New sqlclient.sqlconnection
    Public vScript As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Session("returnaddr") = "philhealth_er2.aspx"
            Server.Transfer("index.aspx")
        End If
        If Not IsPostBack Then
            If Not CanRun(Session("caption"), Request.Item("id")) Then
                Session("denied") = "1"
                Server.Transfer("main.aspx")
                Exit Sub
            End If

            lblCaption.Text = "Philhealth Report of Employee Members (ER2)"
            BuildCombo("select Rc_Cd, Descr from rc where Rc_Cd in ('" & _
                Session("rclist").ToString.Replace(",", "','") & "') order by Descr ", cmbRC)
            BuildCombo("select AgencyCd,AgencyName from agency where Agencycd in ('" & _
                Session("agencylist").ToString.Replace(",", "','") & "') order by AgencyName", cmbOfc)
            BuildCombo("select Div_Cd,Descr from hr_div_ref where Div_Cd in ('" & _
                Session("divlist").ToString.Replace(",", "','") & "') order by Descr", cmbDiv)
            BuildCombo("select Dept_Cd,Descr from hr_dept_ref where Dept_Cd in ('" & _
                Session("deptlist").ToString.Replace(",", "','") & "') order by Descr", cmbDept)
            BuildCombo("select Section_Cd,Descr from hr_section_ref where Section_Cd in ('" & _
                Session("sectionlist").ToString.Replace(",", "','") & "') order by Descr", cmbSection)
            BuildCombo("select Unit_Cd,Descr from hr_unit_ref where Unit_Cd in ('" & _
                Session("unitlist").ToString.Replace(",", "','") & "') order by Descr", cmbUnit)
            BuildCombo("select EmploymentType,Descr from hr_employment_type where EmploymentType in ('" & _
                Session("typelist").ToString.Replace(",", "','") & "') order by Descr", cmbEmpType)
            cmbRC.Items.Add("All")
            cmbRC.SelectedValue = "All"
            cmbDiv.Items.Add("All")
            cmbDiv.SelectedValue = "All"
            cmbDept.Items.Add("All")
            cmbDept.SelectedValue = "All"
            cmbSection.Items.Add("All")
            cmbSection.SelectedValue = "All"
            cmbUnit.Items.Add("All")
            cmbUnit.SelectedValue = "All"
            'cmbOfc.Items.Add("All")
            'cmbOfc.SelectedValue = "All"
            cmbEmpType.Items.Add("All Types")
            cmbEmpType.SelectedValue = "All Types"
            cmbMonth.SelectedValue = Now.Month
            Session("letter") = "A"

            Dim iCtr As Integer = 0
            For iCtr = Now.Year - 2 To Now.Year + 2
                cmbYear.Items.Add(iCtr)
            Next iCtr
            cmbYear.SelectedValue = Now.Year

            DataRefresh(Session("letter"))
        End If
    End Sub

    Private Sub SetLetters(ByVal pLetter As String)
        Select Case LCase(pLetter)
            Case "a"
                cmdA.Visible = True
            Case "b"
                cmdB.Visible = True
            Case "c"
                cmdC.Visible = True
            Case "d"
                cmdD.Visible = True
            Case "e"
                cmdE.Visible = True
            Case "f"
                cmdF.Visible = True
            Case "g"
                cmdG.Visible = True
            Case "h"
                cmdH.Visible = True
            Case "i"
                cmdI.Visible = True
            Case "j"
                cmdJ.Visible = True
            Case "k"
                cmdK.Visible = True
            Case "l"
                cmdL.Visible = True
            Case "m"
                cmdM.Visible = True
            Case "n"
                cmdN.Visible = True
            Case "o"
                cmdO.Visible = True
            Case "p"
                cmdP.Visible = True
            Case "q"
                cmdQ.Visible = True
            Case "r"
                cmdR.Visible = True
            Case "s"
                cmdS.Visible = True
            Case "t"
                cmdT.Visible = True
            Case "u"
                cmdU.Visible = True
            Case "v"
                cmdV.Visible = True
            Case "w"
                cmdW.Visible = True
            Case "x"
                cmdX.Visible = True
            Case "y"
                cmdY.Visible = True
            Case "z"
                cmdZ.Visible = True
        End Select
    End Sub
    Private Sub DataRefresh(ByVal pLetter As String)

        Dim cm As New sqlclient.sqlcommand
        Dim dr As sqlclient.sqldatareader
        Dim da As sqlclient.sqldataadapter
        Dim ds As New DataSet
        Dim vSQL As String = ""
        Dim vFilter As String = ""
        Dim vLtrFilter As String = ""
        c.ConnectionString = connStr

        vFilter = " and " & cmbType.SelectedValue & " like '" & pLetter & "%' "
        Select Case Val(cmbStatus.SelectedValue)
            Case 1  'active employees only
                vFilter += " and Date_Resign is null AND Date_Retired IS NULL AND DateHold IS NULL AND DateDismissed IS NULL "
                vLtrFilter += " and Date_Resign is null AND Date_Retired IS NULL AND DateHold IS NULL AND DateDismissed IS NULL "
            Case 0  'inactive employees only
                vFilter += " and (Date_Resign is not null OR Date_Retired IS NOT NULL OR DateHold IS NOT NULL OR DateDismissed IS NOT NULL) "
                vLtrFilter += " and (Date_Resign is not null OR Date_Retired IS NOT NULL OR DateHold IS NOT NULL OR DateDismissed IS NOT NULL) "
        End Select


        vFilter += " and Agency_Cd='" & cmbOfc.SelectedValue & "' "
        vLtrFilter += " and Agency_Cd='" & cmbOfc.SelectedValue & "' "

        If cmbRC.SelectedValue <> "All" Then   'filter by cost center
            vFilter += " and Rc_Cd='" & cmbRC.SelectedValue & "' "
            vLtrFilter += " and Rc_Cd='" & cmbRC.SelectedValue & "' "
        Else
            vFilter += " and Rc_Cd in ('" & Session("rclist").ToString.Replace(",", "','") & "') "
            vLtrFilter += " and Rc_Cd in ('" & Session("rclist").ToString.Replace(",", "','") & "') "
        End If
        If cmbDiv.SelectedValue <> "All" Then      'filter by division
            vFilter += " and Divcd='" & cmbDiv.SelectedValue & "' "
            vLtrFilter += " and Divcd='" & cmbDiv.SelectedValue & "' "
        Else
            vFilter += " and DivCd in ('" & Session("divlist").ToString.Replace(",", "','") & "') "
            vLtrFilter += " and DivCd in ('" & Session("divlist").ToString.Replace(",", "','") & "') "
        End If
        If cmbDept.SelectedValue <> "All" Then  'filter by departments
            vFilter += " and DeptCd='" & cmbDept.SelectedValue & "' "
            vLtrFilter += " and DeptCd='" & cmbDept.SelectedValue & "' "
        Else
            vFilter += " and DeptCd in ('" & Session("deptlist").ToString.Replace(",", "','") & "') "
            vLtrFilter += " and DeptCd in ('" & Session("deptlist").ToString.Replace(",", "','") & "') "
        End If
        If cmbSection.SelectedValue <> "All" Then 'filter by section
            vFilter += " and SectionCd='" & cmbSection.SelectedValue & "' "
            vLtrFilter += " and SectionCd='" & cmbSection.SelectedValue & "' "
        Else
            vFilter += " and SectionCd in ('" & Session("sectionlist").ToString.Replace(",", "','") & "') "
            vLtrFilter += " and SectionCd in ('" & Session("sectionlist").ToString.Replace(",", "','") & "') "
        End If
        If cmbUnit.SelectedValue <> "All" Then  'filter by units
            vFilter += " and UnitCd='" & cmbUnit.SelectedValue & "' "
            vLtrFilter += " and UnitCd='" & cmbUnit.SelectedValue & "' "
        Else
            vFilter += " and UnitCd in ('" & Session("unitlist").ToString.Replace(",", "','") & "') "
            vLtrFilter += " and UnitCd in ('" & Session("unitlist").ToString.Replace(",", "','") & "') "
        End If
        If cmbEmpType.SelectedValue <> "All Types" Then 'filter by employment types
            vFilter += " and EmploymentType='" & cmbEmpType.SelectedValue & "' "
            vLtrFilter += " and EmploymentType='" & cmbEmpType.SelectedValue & "' "
        Else
            vFilter += " and EmploymentType in ('" & Session("typelist").ToString.Replace(",", "','") & "') "
            vLtrFilter += " and EmploymentType in ('" & Session("typelist").ToString.Replace(",", "','") & "') "
        End If
        vSQL = "select Emp_Cd,Emp_Lname,Emp_Fname,Emp_Mname,Position, Rate_Month,Start_Date," & _
            "PhicNo,Sss_No,Gsis_No from py_emp_master,py_position_ref where  " & _
            "py_emp_master.Pos_Cd=py_position_ref.Pos_Cd and month(Start_Date)=" & cmbMonth.SelectedValue & _
             " and year(Start_Date)='" & cmbYear.SelectedValue & "' " & vFilter & " order by Emp_Lname,Emp_Fname,Emp_Mname"
        Session("sql") = "select Emp_Cd,Emp_Lname,Emp_Fname,Emp_Mname,Position, Rate_Month,Start_Date," & _
            "PhicNo,Sss_No,Gsis_No from py_emp_master,py_position_ref where  " & _
            "py_emp_master.Pos_Cd=py_position_ref.Pos_Cd and month(Start_Date)=" & cmbMonth.SelectedValue & _
            " and year(Start_Date)='" & cmbYear.SelectedValue & "' " & vLtrFilter & " order by Emp_Lname,Emp_Fname,Emp_Mname"

        da = New sqlclient.sqldataadapter(vSQL, c)
        da.Fill(ds, "EMP")

        tblEmp.DataSource = ds.Tables("EMP")
        tblEmp.DataBind()
        da.Dispose()
        ds.Dispose()

        c.Open()
        cm.Connection = c
        cm.CommandText = "select distinct substring(Emp_Lname,1,1) as Letters from py_emp_master, " & _
            "py_position_ref where py_emp_master.Pos_Cd=py_position_ref.Pos_Cd and month(Start_Date)=" & _
            cmbMonth.SelectedValue & " and year(Start_Date)='" & cmbYear.SelectedValue & "' " & vLtrFilter
        '        Response.Write(cm.CommandText)
        dr = cm.ExecuteReader
        EnableAll(False)
        Do While dr.Read
            SetLetters(dr("Letters"))
        Loop
        dr.Close()
        cm.Dispose()
        c.Close()
    End Sub

    Private Sub cmdA_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdA.Click, _
        cmdB.Click, cmdC.Click, cmdD.Click, cmdE.Click, cmdF.Click, cmdG.Click, cmdH.Click, cmdI.Click, _
        cmdJ.Click, cmdK.Click, cmdL.Click, cmdM.Click, cmdN.Click, cmdO.Click, cmdP.Click, cmdQ.Click, _
        cmdR.Click, cmdS.Click, cmdT.Click, cmdU.Click, cmdV.Click, cmdW.Click, cmdX.Click, cmdY.Click, cmdZ.Click
        Session("letter") = CType(sender, LinkButton).Text
        tblEmp.SelectedIndex = -1
        tblEmp.PageIndex = 0
        DataRefresh(Session("letter"))
    End Sub
    Private Sub EnableAll(Optional ByVal pState As Boolean = False)
        cmdA.Visible = pState : cmdB.Visible = pState : cmdC.Visible = pState : cmdD.Visible = pState
        cmdE.Visible = pState : cmdF.Visible = pState : cmdG.Visible = pState : cmdH.Visible = pState
        cmdI.Visible = pState : cmdJ.Visible = pState : cmdK.Visible = pState : cmdL.Visible = pState
        cmdM.Visible = pState : cmdN.Visible = pState : cmdO.Visible = pState : cmdP.Visible = pState
        cmdQ.Visible = pState : cmdR.Visible = pState : cmdS.Visible = pState : cmdT.Visible = pState
        cmdU.Visible = pState : cmdV.Visible = pState : cmdW.Visible = pState : cmdX.Visible = pState
        cmdY.Visible = pState : cmdZ.Visible = pState
    End Sub

    Private Sub cmdRefresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdRefresh.Click
        tblEmp.SelectedIndex = -1
        tblEmp.PageIndex = 0
        If txtSearch.Text.Trim <> "" Then
            Session("letter") = txtSearch.Text
        End If
        DataRefresh(Session("letter"))
    End Sub

    Protected Sub tblEmp_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles tblEmp.PageIndexChanging
        tblEmp.PageIndex = e.NewPageIndex
        DataRefresh(Session("letter"))
    End Sub

    Protected Sub cmdReturn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.Click
        Session.Remove("sql")
        Session.Remove("ofc")
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub cmdPrintEMR_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdPrintEMR.Click
        Session("ofc") = cmbOfc.SelectedValue
        'Server.Transfer("philhealth_er2_printt.aspx")
        vScript = "win=window.open('philhealth_er2_printt.aspx','win','toolbar=no,location=no,width=900,height=500,top=50,left=60');"
    End Sub
End Class
