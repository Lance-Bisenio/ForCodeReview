Imports denaro

Partial Class letterref
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Dim c As New SqlClient.SqlConnection
    Public vLetter As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Session("uid") = "" Then
                Session("returnaddr") = "letterref.aspx"
                Server.Transfer("index.aspx")
            End If

            If Not CanRun(Session("caption"), Request.Item("id")) Then
                Session("denied") = "1"
                Server.Transfer("main.aspx?")
                Exit Sub
            End If
            lblCaption.Text = "Letter template editor"
            DataRefresh()
        End If
    End Sub

    Protected Sub cmdReturn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.Click
        Session.Remove("mode")
        Session.Remove("lettercd")
        Server.Transfer("main.aspx")
    End Sub
    Private Sub DataRefresh()
        Dim da As sqlclient.sqldataadapter
        Dim ds As New DataSet

        c.ConnectionString = connStr
        da = New sqlclient.sqldataadapter("select Letter_Cd,Letter_Name," & _
            "Last_Date_Updated as DateUpdated from hr_letter_hdr order by Letter_Cd", c)
        da.Fill(ds, "letter")
        tblLetter.DataSource = ds.Tables("letter")
        tblLetter.DataBind()

        da.Dispose()
        ds.Dispose()

    End Sub

    Protected Sub tblLetter_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles tblLetter.PageIndexChanging
        tblLetter.PageIndex = e.NewPageIndex
        DataRefresh()
    End Sub

    Protected Sub cmdAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdAdd.Click
        Session("mode") = "a"
        Server.Transfer("modifyletter.aspx")
    End Sub

    Protected Sub cmdEdit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdEdit.Click
        If tblLetter.SelectedIndex <> -1 And tblLetter.SelectedIndex <= tblLetter.Rows.Count Then
            Session("mode") = "e"
            Session("lettercd") = tblLetter.SelectedRow.Cells(0).Text
            Server.Transfer("modifyletter.aspx")
        Else
            vScript = "alert('You must first select a letter template to edit.');"
        End If
    End Sub

    Protected Sub cmdDel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDel.Click
        If tblLetter.SelectedIndex <> -1 And tblLetter.SelectedIndex <= tblLetter.Rows.Count Then
            Dim cm As New sqlclient.sqlcommand

            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c

            cm.CommandText = "delete from hr_letter_dtl where Letter_Cd='" & tblLetter.SelectedRow.Cells(0).Text & "'"
            cm.ExecuteNonQuery()

            cm.CommandText = "delete from hr_letter_hdr where Letter_Cd='" & tblLetter.SelectedRow.Cells(0).Text & "'"
            cm.ExecuteNonQuery()

            vScript = "alert('Record was successfully deleted.');"

            c.Close()
            c.Dispose()

            DataRefresh()
        Else
            vScript = "alert('You must first select a letter template to delete.');"
        End If
    End Sub

    Protected Sub tblLetter_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tblLetter.SelectedIndexChanged
        Dim cm As New sqlclient.sqlcommand
        Dim dr As sqlclient.sqldatareader

        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c
        cm.CommandText = "select Letter_Content from hr_letter_hdr where Letter_Cd='" & _
            tblLetter.SelectedRow.Cells(0).Text & "'"
        dr = cm.ExecuteReader
        If dr.Read Then
            txtContent.Text = dr("Letter_Content")
            vLetter = dr("Letter_Content")
        End If
        dr.Close()
        c.Close()
        cm.Dispose()
    End Sub

    Protected Sub cmdMacro_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdMacro.Click
        If tblLetter.SelectedIndex <> -1 And tblLetter.SelectedIndex <= tblLetter.Rows.Count Then
            Session("lettercd") = tblLetter.SelectedRow.Cells(0).Text & "=>" & _
                tblLetter.SelectedRow.Cells(1).Text
            vScript = "win=window.open('letterdtl.aspx','win','toolbar=no,scrollbar=yes,width=800,height=600,top=100,left=100'); win.focus();"
            Dim cm As New SqlClient.SqlCommand
            Dim dr As SqlClient.SqlDataReader

            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c
            cm.CommandText = "select Letter_Content from hr_letter_hdr where Letter_Cd='" & _
                tblLetter.SelectedRow.Cells(0).Text & "'"
            dr = cm.ExecuteReader
            If dr.Read Then
                txtContent.Text = dr("Letter_Content")
                vLetter = dr("Letter_Content")
            End If
            dr.Close()
            c.Close()
            cm.Dispose()
        Else
            vScript = "alert('You must first select a letter template to view.');"
        End If
    End Sub
End Class
