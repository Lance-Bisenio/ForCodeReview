﻿Imports denaro.fis
Partial Class checknac
    Inherits System.Web.UI.Page
    Public vReturn As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim NACconnStr As String = System.Configuration.ConfigurationManager.AppSettings.Get("NACconnstr")
        Dim vRegTerminals As String = System.Configuration.ConfigurationManager.AppSettings.Get("terminals")
        Dim vReadMode As String = System.Configuration.ConfigurationManager.AppSettings.Get("readmode")
        Dim vLogIn As String = System.Configuration.ConfigurationManager.AppSettings.Get("login")
        Dim vLogOut As String = System.Configuration.ConfigurationManager.AppSettings.Get("logout")
        Dim vStepOut As String = System.Configuration.ConfigurationManager.AppSettings.Get("stepout")
        Dim vStepIn As String = System.Configuration.ConfigurationManager.AppSettings.Get("stepin")

        Dim c As New SqlClient.SqlConnection(NACconnStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim vData As String = ""

        cm.Connection = c

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vReturn = "error"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        'get top 5 logins
        cm.CommandText = "select Top 6 UserId,TransactionTime,(select name from ngac_userinfo where id=userid) as Name " & _
            "from ngac_authlog where userid is not null and authresult = 0 "
        If vReadMode = 0 Then   'use function keys
            cm.CommandText += " and TerminalId in (" & vRegTerminals & ") and FunctionKey=" & vLogIn
        Else                    'use terminals
            cm.CommandText += " and TerminalId in (" & vLogIn & ")"
        End If

        cm.CommandText += " order by TransactionTime desc"

        Try
            rs = cm.ExecuteReader
            Do While rs.Read
                vData += rs("UserId") & "-" & rs("Name") & "-" & rs("TransactionTime") & "~"
            Loop
            rs.Close()
        Catch ex As SqlClient.SqlException
            vReturn = "error"
            GoTo skip
        End Try

        If vData <> "" Then vData = Mid(vData, 1, Len(vData) - 1) & "|"

        'get top 5 logouts
        cm.CommandText = "select Top 6 UserId,TransactionTime,(select name from ngac_userinfo where id=userid) as Name " & _
            "from ngac_authlog where userid is not null and authresult = 0 "
        If vReadMode = 0 Then   'use function keys
            cm.CommandText += " and TerminalId in (" & vRegTerminals & ") and FunctionKey=" & vLogOut
        Else                    'use terminals
            cm.CommandText += " and TerminalId in (" & vLogOut & ")"
        End If

        cm.CommandText += " order by TransactionTime desc"

        Try
            rs = cm.ExecuteReader
            Do While rs.Read
                vData += rs("Userid") & "-" & rs("Name") & "-" & rs("TransactionTime") & "~"
            Loop
            rs.Close()
            If vData <> "" Then vData = Mid(vData, 1, Len(vData) - 1)
            vReturn = vData
        Catch ex As SqlClient.SqlException
            vReturn = "error"
        End Try
skip:
        c.Close()
        c.Dispose()
        cm.Dispose()
    End Sub
End Class
