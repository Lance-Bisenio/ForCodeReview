Imports denaro
Partial Class massupdateincent
    Inherits System.Web.UI.Page
    Public vScript As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If
        If Not CanRun(Session("caption"), Request.Item("id")) Then
            Session("denied") = "1"
            Server.Transfer("main.aspx")
            Exit Sub
        End If

        If Not IsPostBack Then 'now build the reference code
            Dim PayCd_Days As String = ""
            Dim PayCd_Days_one() As String
            Dim dr As sqlclient.sqldatareader
            Dim cm As New sqlclient.sqlcommand
            Dim c As New sqlclient.sqlconnection(connStr)

            lblCaption.Text = "Mass Update Incentives and Other Income"
            BuildCombo("select Rc_Cd,Descr from rc where exists (select User_Id from rights_list where User_Id='" & _
                    Session("uid") & "' and property='rc' and Property_Value=Rc_Cd) order by Descr", cmbRC)
            BuildCombo("select AgencyCd,AgencyName from agency where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='agency' and Property_Value=AgencyCd) order by AgencyName", cmbOfc)
            BuildCombo("select Div_Cd,Descr from hr_div_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='division' and Property_Value=Div_Cd) order by Descr", cmbDiv)
            BuildCombo("select Dept_Cd,Descr from hr_dept_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='department' and Property_Value=Dept_Cd) order by Descr", cmbDept)
            BuildCombo("select Section_Cd,Descr from hr_section_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='section' and Property_Value=Section_Cd) order by Descr", cmbSection)
            BuildCombo("select Unit_Cd,Descr from hr_unit_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='unit' and Property_Value=Unit_Cd) order by Descr", cmbUnit)
            BuildCombo("select EmploymentType,Descr from hr_employment_type where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='employmenttype' and Property_Value=EmploymentType) order by Descr", cmbSecurity)

            BuildCombo("select Incentive_Cd,Descr from py_other_incentvs order by Descr", cmbIncent)
            cmbRC.Items.Add("All")
            cmbRC.SelectedValue = "All"
            cmbOfc.Items.Add("All")
            cmbOfc.SelectedValue = "All"
            cmbDiv.Items.Add("All")
            cmbDiv.SelectedValue = "All"
            cmbDept.Items.Add("All")
            cmbDept.SelectedValue = "All"
            cmbSection.Items.Add("All")
            cmbSection.SelectedValue = "All"
            cmbUnit.Items.Add("All")
            cmbUnit.SelectedValue = "All"
            cmbSecurity.Items.Add("All")
            cmbSecurity.SelectedValue = "All"

            c.ConnectionString = connStr

            Try
                c.Open()
            Catch ex As sqlclient.sqlexception
                vScript = "alert('Error occurred while trying to connect to SQL Server. Error is: " & _
                    ex.Message.Replace(vbCrLf, "\n") & "');"
                cm.Dispose()
                c.Dispose()
                Exit Sub
            End Try

            cm.Connection = c
            cm.CommandText = "Select * from py_pay_mode where Pay_Cd='SM'"

            Try
                dr = cm.ExecuteReader
                If dr.Read Then
                    PayCd_Days = IIf(IsDBNull(dr("Days")), "", dr("Days"))
                    PayCd_Days_one = PayCd_Days.Split(",")
                    cmbFreq.Items.Add(New ListItem("Every 1st Period", PayCd_Days_one(1) - 1))
                    cmbFreq.Items.Add(New ListItem("Every 2nd Period", IIf(PayCd_Days_one(0) - 1 = 0, 30, PayCd_Days_one(0) - 1)))
                End If
                dr.Close()
            Catch ex As sqlclient.sqlexception
                vScript = "alert('Error occurred while trying to retrieve the Payment Mode reference table. Error is: " & _
                    ex.Message.Replace(vbCrLf, "\n") & "');"
            Finally
                c.Close()
                c.Dispose()
                cm.Dispose()
            End Try
        End If
    End Sub
    Protected Sub DataRefresh()
        If txtFrom.Text.Trim = "" Then
            vScript = "alert('You must first enter the posting date since the system will base the years of duration from this date.');"
            Exit Sub
        End If
        If Not IsDate(txtFrom.Text) Then
            vScript = "alert('You must enter a valid date format.  Use the MM/DD/YYYY format for the field.');"
            Exit Sub
        End If

        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim dr As SqlClient.SqlDataReader

        Dim vFilter As String = " where Start_Date is not null and Date_Resign is null "

        If cmbRC.SelectedValue <> "All" Then   'filter by cost center
            vFilter += " and Rc_Cd='" & cmbRC.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='rc' and Property_Value=Rc_Cd) "
        End If

        If cmbOfc.SelectedValue <> "All" Then        'filter by office/agency
            vFilter += " and Agency_Cd='" & cmbOfc.SelectedValue & "' "
        Else
            vFilter += "  and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='agency' and Property_Value=Agency_Cd) "
        End If
        If cmbDiv.SelectedValue <> "All" Then      'filter by division
            vFilter += " and Divcd='" & cmbDiv.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='division' and Property_Value=DivCd) "
        End If
        If cmbDept.SelectedValue <> "All" Then  'filter by departments
            vFilter += " and DeptCd='" & cmbDept.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='department' and Property_Value=DeptCd) "
        End If
        If cmbSection.SelectedValue <> "All" Then 'filter by section
            vFilter += " and SectionCd='" & cmbSection.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='section' and Property_Value=SectionCd) "
        End If
        If cmbUnit.SelectedValue <> "All" Then  'filter by units
            vFilter += " and UnitCd='" & cmbUnit.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='unit' and Property_Value=UnitCd) "
        End If
        If cmbSecurity.SelectedValue <> "All" Then 'filter by employment types
            vFilter += " and EmploymentType='" & cmbSecurity.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='employmenttype' and Property_Value=EmploymentType) "
        End If

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to SQL Server. Error in line 131: " & _
                ex.Message.Replace(vbCrLf, "\n") & "');"
            cm.Dispose()
            c.Dispose()
            Exit Sub
        End Try

        cm.Connection = c
        cm.CommandText = "select Emp_Cd,(Emp_Lname+', '+Emp_Fname) as EmpName,Start_Date from py_emp_master " & _
            vFilter & " order by Emp_Lname,Emp_Fname,Emp_Mname"
        chkEmp.Items.Clear()
        Dim vyears As Decimal

        Try
            dr = cm.ExecuteReader
            Do While dr.Read
                vyears = DateDiff(DateInterval.Year, CDate(dr("Start_Date")), CDate(txtFrom.Text))
                If vyears >= Val(txtYearsOfService.Text) Then
                    chkEmp.Items.Add(dr("Emp_Cd") & "=>" & dr("EmpName") & "--" & dr("Start_Date") & "--" & vyears)
                End If
            Loop
            dr.Close()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying retrieve Employee masterlist. Error in line 146: " & _
                ex.Message.Replace(vbCrLf, "\n") & "');"
        Finally
            cm.Dispose()
            c.Close()
            c.Dispose()
        End Try
    End Sub

    Protected Sub cmdRefresh_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdRefresh.Click
        DataRefresh()
    End Sub

    Protected Sub cmdSelect_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSelect.Click
        SetChk(True)
    End Sub
    Private Sub SetChk(ByVal pState As Boolean)
        Dim iCtr As Integer
        For iCtr = 0 To chkEmp.Items.Count - 1
            chkEmp.Items(iCtr).Selected = pState
        Next iCtr
    End Sub

    Protected Sub cmdDeselect_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDeselect.Click
        SetChk(False)
    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        If txtFrom.Text <> "" And Not IsDate(txtFrom.Text) Then
            vScript = "alert('Invalid date format in From Date field.');"
            Exit Sub
        End If
        If txtTo.Text <> "" And Not IsDate(txtTo.Text) Then
            vScript = "alert('Invalid date format in To Date field.');"
            Exit Sub
        End If
        If txtValue.Text = "" Then
            vScript = "alert('You must enter a number in Value field.');"
            Exit Sub
        End If
        If txtValue.Text <> "" And Not IsNumeric(txtValue.Text) Then
            vScript = "alert('You must enter a valid number in Value field.');"
            Exit Sub
        End If
        txtValue.Text = txtValue.Text.Replace(",", "")
        If Val(txtValue.Text) = 0 Then
            vScript = "alert('Value field should not be zero.');"
            Exit Sub
        End If

        Dim c As New sqlclient.sqlconnection(connStr)
        Dim cm As New sqlclient.sqlcommand
        Dim dr As sqlclient.sqldatareader
        Dim vStr As String = ""
        Dim iCtr As Integer
        Dim vValue As Double

        For iCtr = 0 To chkEmp.Items.Count - 1
            If chkEmp.Items(iCtr).Selected Then
                vStr += ExtractData(chkEmp.Items(iCtr).Text) & "','"
            End If
        Next iCtr
        If vStr = "" Then
            vScript = "alert('You must first select at least one employee to continue...');"
            Exit Sub
        Else
            vStr = "'" & vStr.Substring(0, vStr.Length - 2)
        End If

        Try
            c.Open()
        Catch ex As sqlclient.sqlexception
            vScript = "alert('Error occurred while trying to connect to SQL Server. Error in line # 223: " & _
                ex.Message.Replace(vbCrLf, "\n") & "');"
            cm.Dispose()
            c.Dispose()
            Exit Sub
        End Try

        cm.Connection = c
        'clean-up any existing record 
        cm.CommandText = "delete from py_incentives_dtl where Incentive_Cd='" & _
            cmbIncent.SelectedValue & "' and Emp_Cd in (" & vStr & ")"

        If txtFrom.Text = "" Then
            cm.CommandText += " and FromDate is null "
        Else
            cm.CommandText += " and FromDate='" & Format(CDate(txtFrom.Text), "yyyy/MM/dd") & "' "
        End If
        If txtTo.Text = "" Then
            cm.CommandText += " and ToDate is null "
        Else
            cm.CommandText += " and ToDate='" & Format(CDate(txtTo.Text), "yyyy/MM/dd") & "' "
        End If

        Try
            cm.ExecuteNonQuery()
        Catch ex As sqlclient.sqlexception
            vScript = "alert('Error occurred while cleaning-up the Incentives Ledger. Error in line 234: " & _
                ex.Message.Replace(vbCrLf, "\n") & "');"
            c.Close()
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        vStr = ""
        For iCtr = 0 To chkEmp.Items.Count - 1
            If chkEmp.Items(iCtr).Selected Then
                If rdoMode.SelectedValue = "0" Then        'by amount
                    vValue = Val(txtValue.Text)
                Else                                        'by percent
                    Select Case rdoMode.SelectedValue
                        Case 1  'by percentage of monthy basic rate
                            'get Monthly Salary from employee master file
                            cm.CommandText = "select Rate_Month as Rate from py_emp_master where Emp_Cd='" & _
                                ExtractData(chkEmp.Items(iCtr).Text) & "'"
                        Case 2  'by percentage of daily rate
                            'get Monthly Salary from employee master file
                            cm.CommandText = "select Rate_Day as Rate from py_emp_master where Emp_Cd='" & _
                                ExtractData(chkEmp.Items(iCtr).Text) & "'"
                    End Select

                    Try
                        dr = cm.ExecuteReader
                        vValue = 0
                        If dr.Read Then
                            vValue = (Val(txtValue.Text) / 100) * dr("Rate")
                        End If
                        dr.Close()
                    Catch ex As sqlclient.sqlException
                        vScript = "alert('Error occurred while trying to retrieve Salary Rate of employee " & _
                            chkEmp.Items(iCtr).Text & ". Error is: " & ex.Message.Replace(vbCrLf, "\n") & "');"
                        c.Close()
                        c.Dispose()
                        cm.Dispose()
                        Exit Sub
                    End Try
                End If

                cm.CommandText = "insert into py_incentives_dtl (Incentive_Cd,Emp_Cd,Incentive_Amt,FreqCd,FromDate,ToDate) values ('" & _
                      cmbIncent.SelectedValue & "','" & _
                      ExtractData(chkEmp.Items(iCtr).Text) & "'," & _
                      vValue & "," & cmbFreq.SelectedValue & ","

                If txtFrom.Text = "" Then
                    cm.CommandText += "null,"
                Else
                    cm.CommandText += "'" & Format(CDate(txtFrom.Text), "yyyy/MM/dd") & "',"
                End If
                If txtTo.Text = "" Then
                    cm.CommandText += "null)"
                Else
                    cm.CommandText += "'" & Format(CDate(txtTo.Text), "yyyy/MM/dd") & "')"
                End If

                Try
                    cm.ExecuteNonQuery()
                    vScript = "alert('Changes were successfully saved. You may go to incentives menu to check the values.');"
                Catch ex As system.exception
                    vScript = "alert('Error occurred while trying to insert the record of Employee " & _
                        chkEmp.Items(iCtr).Text & ". Error is: " & ex.Message.Replace(vbCrLf, "\n") & "');"
                    c.Close()
                    c.Dispose()
                    cm.Dispose()
                    Exit Sub
                End Try
            End If
        Next iCtr
        cm.Dispose()
        c.Close()
        c.Dispose()
        SetChk(False)
    End Sub

    Protected Sub cmdReturn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.Click
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub vldPage_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles vldPage.ServerValidate
        If Not IsDate(txtFrom.Text) Then
            vScript = "alert('Invalid date format in Starting cut off date.');"
            args.IsValid = False
            Exit Sub
        End If
        If Not IsDate(txtTo.Text) Then
            vScript = "alert('Invalid date format in Ending cut off date.');"
            args.IsValid = False
            Exit Sub
        End If
        args.IsValid = True
    End Sub
End Class
