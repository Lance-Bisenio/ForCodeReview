Imports denaro
Partial Class applicantskills
    Inherits System.Web.UI.Page
    Dim c As New sqlclient.sqlconnection
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If

        If Not IsPostBack Then
            Dim cRef As New sqlclient.sqlconnection(connStr)
            Dim cm As New sqlclient.sqlcommand
            Dim cmRef As New sqlclient.sqlcommand
            Dim dr As sqlclient.sqldatareader
            Dim drRef As sqlclient.sqldatareader
            lblCaption.Text = "Applicant's Skills"
            c.ConnectionString = connStr
            c.Open()
            cRef.Open()
            cm.Connection = c
            cmRef.Connection = cRef
            cm.CommandText = "select * from hr_applicant_master where ApplicantNo=" & _
                Session("applicantno")
            dr = cm.ExecuteReader
            If dr.Read Then
                txtTraining.Text = IIf(IsDBNull(dr("Self_Trainings")), "", dr("Self_Trainings"))
                txtSkills.Text = IIf(IsDBNull(dr("Skills")), "", dr("Skills"))
                cmRef.CommandText = "select Descr from hr_language_ref where LanguageCd in ('" & _
                    IIf(IsDBNull(dr("LanguageCd")), "", dr("LanguageCd").ToString.Replace(",", "','")) & _
                    "') order by Descr"
                drRef = cmRef.ExecuteReader
                Do While drRef.Read
                    lstLanguage.Items.Add(drRef("Descr"))
                Loop
                drRef.Close()
                cmRef.CommandText = "select Descr from hr_dialect_ref where DialectCd in ('" & _
                    IIf(IsDBNull(dr("DialectCd")), "", dr("DialectCd").ToString.Replace(",", "','")) & _
                    "') order by Descr"
                drRef = cmRef.ExecuteReader
                Do While drRef.Read
                    lstDialect.Items.Add(drRef("Descr"))
                Loop
                drRef.Close()
            End If
            dr.Close()
            cm.Dispose()
            cmRef.Dispose()
            cRef.Close()
            cRef.Dispose()
            c.Close()
        End If
    End Sub
End Class
