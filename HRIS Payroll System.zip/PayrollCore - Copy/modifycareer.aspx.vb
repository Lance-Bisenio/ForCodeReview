Imports denaro
Partial Class modifycareer
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Dim c As New sqlclient.sqlconnection
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If
        If Not IsPostBack Then
            BuildCombo("select Rc_Cd,Descr from rc order by Descr", cmbRc)
            BuildCombo("select AgencyCd,AgencyName from agency order by AgencyName", cmbOffice)
            BuildCombo("select Div_Cd,Descr from hr_div_ref order by Descr", cmbDiv)
            BuildCombo("select Dept_Cd,Descr from hr_dept_ref order by Descr", cmbDept)
            BuildCombo("select Section_Cd,Descr from hr_section_ref order by Descr", cmbSection)
            BuildCombo("select Unit_Cd,Descr from hr_unit_ref order by Descr", cmbUnit)
            BuildCombo("select Pos_Cd,Position from py_position_ref order by Position", cmbPos)
            BuildCombo("select Grade_Cd,Descr from py_grade order by Descr", cmbGrade)
            BuildCombo("select EmploymentType,Descr from hr_employment_type order by Descr", cmbType)
            Dim cm As New sqlclient.sqlcommand
            Dim dr As sqlclient.sqldatareader
            txtEmpCd.Text = Session("empid")
            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c
            cm.CommandText = "select Emp_Lname,Emp_Fname from py_emp_master where Emp_Cd='" & txtEmpCd.Text & "'"
            dr = cm.ExecuteReader
            lblCaption.Text = "Add/Modify Career History for "
            If dr.Read Then
                lblCaption.Text += dr("Emp_Lname") & ", " & dr("Emp_Fname")
            End If
            dr.Close()

            If Session("mode") = "e" Or Session("mode") = "v" Then
                cm.CommandText = "select * from hr_emp_career_movement where Emp_Cd='" & txtEmpCd.Text & _
                    "' and From_Date='" & Format(CDate(Session("seqid")), "yyyy/MM/dd") & "'"
                dr = cm.ExecuteReader
                If dr.Read Then
                    txtFrom.Text = IIf(IsDBNull(dr("From_Date")), "", dr("From_Date"))
                    txtTo.Text = IIf(IsDBNull(dr("To_Date")), "", dr("To_Date"))
                    txtSalary.Text = IIf(IsDBNull(dr("Salary_Amt")), "0", dr("Salary_Amt"))
                    txtACA.Text = IIf(IsDBNull(dr("Aca")), 0, dr("Aca"))
                    txtRATA.Text = IIf(IsDBNull(dr("Rata")), 0, dr("Rata"))
                    txtPERA.Text = IIf(IsDBNull(dr("Pera")), 0, dr("Pera"))
                    txtMeal.Text = IIf(IsDBNull(dr("MealAllow")), 0, dr("MealAllow"))
                    txtRemarks.Text = IIf(IsDBNull(dr("Remarks")), "", dr("Remarks"))
                    cmbRc.SelectedValue = IIf(IsDBNull(dr("Rc_Cd")), "99", dr("Rc_Cd")) & "'"
                    cmbOffice.SelectedValue = IIf(IsDBNull(dr("Office_Cd")), "99", dr("Office_Cd")) & "'"
                    cmbDiv.SelectedValue = IIf(IsDBNull(dr("Div_Cd")), "99", dr("Div_Cd")) & "'"
                    cmbDept.SelectedValue = IIf(IsDBNull(dr("Dept_Cd")), "99", dr("Dept_Cd")) & "'"
                    cmbSection.SelectedValue = IIf(IsDBNull(dr("Section_Cd")), "99", dr("Section_Cd")) & "'"
                    cmbUnit.SelectedValue = IIf(IsDBNull(dr("Unit_Cd")), "99", dr("Unit_Cd")) & "'"
                    cmbPos.SelectedValue = IIf(IsDBNull(dr("Position_Cd")), "99", dr("Position_Cd"))
                    cmbGrade.SelectedValue = IIf(IsDBNull(dr("GradeCd")), "99", dr("GradeCd"))
                    cmbType.SelectedValue = IIf(IsDBNull(dr("EmploymentType")), "99", dr("EmploymentType"))
                End If
                dr.Close()
                If Session("mode") = "v" Then 'freeze fields
                    txtFrom.ReadOnly = True
                    txtTo.ReadOnly = True
                    txtSalary.ReadOnly = True
                    txtRemarks.ReadOnly = True
                    txtACA.ReadOnly = True
                    txtRATA.ReadOnly = True
                    txtPERA.ReadOnly = True
                    txtMeal.ReadOnly = True
                    cmbRc.Enabled = False
                    cmbOffice.Enabled = False
                    cmbDiv.Enabled = False
                    cmbDept.Enabled = False
                    cmbSection.Enabled = False
                    cmbUnit.Enabled = False
                    cmbPos.Enabled = False
                    cmbGrade.Enabled = False
                    cmbType.Enabled = False
                End If
            End If
            cm.Dispose()
            c.Close()
        End If
    End Sub

    Protected Sub cmdCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        Session.Remove("empid")
        Session.Remove("seqid")
        'If Session("mode") = "v" Then
        Session.Remove("mode")
        vScript = "window.close();"
        'Else
        'Session.Remove("mode")
        'Server.Transfer("emp.aspx")
        'End If
    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        If Page.IsValid Then
            Dim cm As New sqlclient.sqlcommand
            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c
            If Session("mode") = "e" Then 'edit mode
                cm.CommandText = "update hr_emp_career_movement set From_Date='" & _
                    Format(CDate(txtFrom.Text), "yyyy/MM/dd") & _
                    "',To_Date='" & Format(CDate(txtTo.Text), "yyyy/MM/dd") & _
                    "',Salary_Amt=" & txtSalary.Text & _
                    ",Aca=" & txtACA.Text & _
                    ",Rata=" & txtRATA.Text & _
                    ",Pera=" & txtPERA.Text & _
                    ",Remarks='" & txtRemarks.Text & _
                    "',Rc_Cd='" & cmbRc.SelectedValue & _
                    "',Office_Cd='" & cmbOffice.SelectedValue & _
                    "',Div_Cd='" & cmbDiv.SelectedValue & _
                    "',Dept_Cd='" & cmbDept.SelectedValue & _
                    "',Section_Cd='" & cmbSection.SelectedValue & _
                    "',Unit_Cd='" & cmbUnit.SelectedValue & _
                    "',Position_Cd='" & cmbPos.SelectedValue & _
                    "',GradeCd='" & cmbGrade.SelectedValue & _
                    "',EmploymentType='" & cmbType.SelectedValue & _
                    "' where Emp_Cd='" & txtEmpCd.Text & "' and From_Date='" & _
                    Format(CDate(Session("seqid")), "yyyy/MM/dd") & "'"
            Else                          'add mode
                cm.CommandText = "insert into hr_emp_career_movement (Emp_Cd,From_Date,To_Date,Salary_Amt," & _
                    "Aca,Rata,Pera,Remarks,Rc_Cd,Office_Cd,Div_Cd,Dept_Cd,Section_Cd,Unit_Cd,Position_Cd," & _
                    "GradeCd,EmploymentType) values ('" & _
                    txtEmpCd.Text & "','" & Format(CDate(txtFrom.Text), "yyyy/MM/dd") & "','" & _
                    Format(CDate(txtTo.Text), "yyyy/MM/dd") & "'," & txtSalary.Text & _
                    "," & txtACA.Text & "," & txtRATA.Text & "," & txtPERA.Text & ",'" & txtRemarks.Text & _
                    "','" & cmbRc.SelectedValue & "','" & _
                    cmbOffice.SelectedValue & "','" & cmbDiv.SelectedValue & _
                    "','" & cmbDept.SelectedValue & "','" & _
                    cmbSection.SelectedValue & "','" & cmbUnit.SelectedValue & _
                    "','" & cmbPos.SelectedValue & "','" & cmbGrade.SelectedValue & "','" & _
                    cmbType.Text & "')"
            End If
            cm.ExecuteNonQuery()
            vScript = "alert('Changes where successfully saved.');"
        End If
    End Sub

    Protected Sub vldDate_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles vldDate.ServerValidate
        vldDate.ErrorMessage = "Invalid date format."
        If txtFrom.Text = "" Then
            vScript = "alert('From date field should not be empty.');"
            args.IsValid = False
            Exit Sub
        End If
        If txtTo.Text = "" Then
            vScript = "alert('To date field should not be empty.');"
            args.IsValid = False
            Exit Sub
        End If
        If Not IsDate(txtFrom.Text) Then
            vScript = "alert('The From date field has an invalid date format.');"
            args.IsValid = False
            Exit Sub
        End If
        If Not IsDate(txtTo.Text) Then
            vScript = "alert('The To date field has an invalid date format.');"
            args.IsValid = False
            Exit Sub
        End If
        If txtSalary.Text = "" Then
            vScript = "alert('Annual salary field should not be empty.');"
            vldDate.ErrorMessage = "Annual salary field should not be empty."
            args.IsValid = False
            Exit Sub
        End If
        If Not IsNumeric(txtSalary.Text) Then
            vScript = "alert('Annual salary field has an invalid numeric format.');"
            vldDate.ErrorMessage = "Annual salary field has an invalid numeric format."
            args.IsValid = False
            Exit Sub
        End If
        If Not IsNumeric(txtACA.Text) Then
            vScript = "alert('ECOLA field has an invalid numeric format.');"
            vldDate.ErrorMessage = "ECOLA field has an invalid numeric format."
            args.IsValid = False
            Exit Sub
        End If
        If Not IsNumeric(txtRATA.Text) Then
            vScript = "alert('Transpo Allowance field has an invalid numeric format.');"
            vldDate.ErrorMessage = "Transpo Allowance field has an invalid numeric format."
            args.IsValid = False
            Exit Sub
        End If
        If Not IsNumeric(txtPERA.Text) Then
            vScript = "alert('OT/Tempo Allowance field has an invalid numeric format.');"
            vldDate.ErrorMessage = "OT/Tempo Allowance field has an invalid numeric format."
            args.IsValid = False
            Exit Sub
        End If
        args.IsValid = True
    End Sub
End Class
