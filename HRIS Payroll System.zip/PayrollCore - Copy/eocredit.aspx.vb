﻿Imports denaro.fis
Partial Class eocredit
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Or Session("uid") = Nothing Then
            vScript = "alert('Your login session has expired. Please re-login again.'); window.close();"
            Exit Sub
        End If

        If Not IsPostBack Then
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY: VIC GATCHALIAN                                ''
            '' DATE MODIFIED: 1/3/2013                                    ''
            '' PURPOSE: TO ADD FILTERS TO THE LIST OF EMPLOYEES ELIGIBLE  ''
            ''          FOR 1 DAY CREDIT IN LIEU OF HOLIDAY               ''
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            Dim c As New SqlClient.SqlConnection(connStr)
            Dim cm As New SqlClient.SqlCommand
            Dim rs As SqlClient.SqlDataReader

            Try
                c.Open()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to connect to databse. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                c.Dispose()
                Exit Sub
            End Try

            BuildCombo("select Rc_Cd,Descr from rc where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='rc' and Property_Value=Rc_Cd) order by Descr", cmbRC, c)
            BuildCombo("select AgencyCd,AgencyName from agency where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='agency' and Property_Value=AgencyCd) order by AgencyName", cmbOfc, c)
            BuildCombo("select Div_Cd,Descr from hr_div_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='division' and Property_Value=Div_Cd) order by Descr", cmbDiv, c)
            BuildCombo("select Dept_Cd,Descr from hr_dept_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='department' and Property_Value=Dept_Cd) order by Descr", cmbDept, c)
            BuildCombo("select Section_Cd,Descr from hr_section_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='section' and Property_Value=Section_Cd) order by Descr", cmbSection, c)
            BuildCombo("select Unit_Cd,Descr from hr_unit_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='unit' and Property_Value=Unit_Cd) order by Descr", cmbUnit, c)
            BuildCombo("select Leave_Cd,Descr from py_leave_ref order by Descr", cmbCreditTo, c)

            cm.Connection = c

            cm.CommandText = "select EmploymentType from hr_employment_type where EmploymentType in ('" & _
                Session("typelist").ToString.Replace(",", "','") & "')"
            Try
                rs = cm.ExecuteReader
                Do While rs.Read
                    txtRank.Text += rs("EmploymentType") & ","
                Loop
                rs.Close()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to retrieve list of Rank rights. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            Finally
                c.Close()
                c.Dispose()
                cm.Dispose()
            End Try

            If txtRank.Text.Trim <> "" Then
                txtRank.Text = Mid(txtRank.Text, 1, Len(txtRank.Text) - 1)
            End If

            cmbRC.Items.Add("All")
            cmbOfc.Items.Add("All")
            cmbDiv.Items.Add("All")
            cmbDept.Items.Add("All")
            cmbSection.Items.Add("All")
            cmbUnit.Items.Add("All")

            cmbRC.SelectedValue = "All"
            cmbOfc.SelectedValue = "All"
            cmbDiv.SelectedValue = "All"
            cmbDept.SelectedValue = "All"
            cmbSection.SelectedValue = "All"
            cmbUnit.SelectedValue = "All"
            If cmbCreditTo.Items.Count > 0 Then
                cmbCreditTo.SelectedValue = "EO"
            End If

            txtFrom.Text = Format(Now.Month, "00") & "/01/" & Format(Now.Year, "0000")
            txtTo.Text = Format(Now, "MM/dd/yyyy")
            ''''''''''''''''  END OF MODIFICATION '''''''''''''''''''''''''''''''''''
            DataRefresh()
        Else
            txtRank.Text = Request.Form("txtRank")
        End If
    End Sub

    Protected Sub cmdSelectAll_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSelectAll.Click
        Dim i As Integer

        For i = 0 To chkEmp.Items.Count - 1
            chkEmp.Items(i).Selected = True
        Next
    End Sub

    Protected Sub cmdDeselect_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDeselect.Click
        Dim i As Integer

        For i = 0 To chkEmp.Items.Count - 1
            chkEmp.Items(i).Selected = False
        Next
    End Sub

    Protected Sub cmdProcess_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdProcess.Click
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader

        Dim vData() As String
        Dim i As Integer
        Dim vTmp() As String
        Dim vNumber As Integer = 1
        Dim vAppNo As String = ""

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        cm.Connection = c

        For i = 0 To chkEmp.Items.Count - 1
            If chkEmp.Items(i).Selected Then
                vData = chkEmp.Items(i).Value.Split("~")

                cm.CommandText = "select TOP 1 ApplicationNo from hr_leave_application where Emp_Cd='" & vData(0) & _
                    "' order by ApplicationNo desc "
                rs = cm.ExecuteReader
                vNumber = 1
                If rs.Read Then
                    vTmp = rs("ApplicationNo").ToString.Split("-")
                    vNumber = Val(vTmp(1)) + 1
                End If
                rs.Close()
                vAppNo = vData(0) & "-" & Format(vNumber, "00000")

                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY:  VIC GATCHALIAN                                      ''
                '' DATE MODIFIED: 1/3/2013                                           ''
                '' PURPOSE: TO CONVERT THE "CREDIT TO" FIELD FROM CONSTANT VALUE     ''
                ''          TO USER SELECTED VALUE.                                  ''
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                ''''''''''''''''''''' OLD CODE  '''''''''''''''''''''''''''''''''''''''
                'cm.CommandText = "insert into hr_leave_application (TranDate,LeaveCd,Emp_Cd,DaysLeave,StartDate,EndDate,Reason," & _
                '    "ApprovedBy,DateApproved,Remarks,Void,Paid,Posted,BreakHrs,CreditTo,ApplicationNo,ShiftCd) values ('" & _
                '    Format(Now, "yyyy/MM/dd") & "','OT','" & vData(0) & "',8,'" & vData(1) & " 00:00:00','" & _
                '    vData(1) & " 23:59:59','Restday in lieu of holiday','SYSTEM initiated by " & Session("uid") & _
                '    "','" & Format(Now, "yyyy/MM/dd") & "','System Approved',0,1,1,0,'HO','" & vAppNo & "','RD')"
                ''''''''''''''''''''' END OLD CODE ''''''''''''''''''''''''''''''''''''
                cm.CommandText = "insert into hr_leave_application (TranDate,LeaveCd,Emp_Cd,DaysLeave,StartDate,EndDate,Reason," & _
                    "ApprovedBy,DateApproved,Remarks,Void,Paid,Posted,BreakHrs,CreditTo,ApplicationNo,ShiftCd) values ('" & _
                    Format(Now, "yyyy/MM/dd") & "','OT','" & vData(0) & "',8,'" & vData(1) & " 00:00:00','" & _
                    vData(1) & " 23:59:59','Restday in lieu of holiday','SYSTEM initiated by " & Session("uid") & _
                    "','" & Format(Now, "yyyy/MM/dd") & "','System Approved',0,1,1,0,'" & cmbCreditTo.SelectedValue & _
                    "','" & vAppNo & "','RD')"
                ''''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''''

                Try
                    cm.ExecuteNonQuery()
                Catch ex As SqlClient.SqlException
                    vScript = "alert('Error occurred while trying to save changes. Error is: " & ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                    Exit For
                End Try
            End If
        Next
        c.Close()
        c.Dispose()
        cm.Dispose()
        DataRefresh()
    End Sub
    Private Sub DataRefresh()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' DATE MODIFIED: 1/3/2013                            ''
        '' MODIFIED BY: VIC GATCHALIAN                        ''
        '' PURPOSE: TO INCLUDE THE FILTER SELECTION           ''
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        Dim vFilter As String = ""

        If cmbRC.SelectedValue <> "All" Then   'filter by cost center
            vFilter += " and Rc_Cd='" & cmbRC.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='rc' and Property_Value=Rc_Cd) "
        End If

        If cmbOfc.SelectedValue <> "All" Then        'filter by office/agency
            vFilter += " and Agency_Cd='" & cmbOfc.SelectedValue & "' "
        Else
            vFilter += "  and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='agency' and Property_Value=Agency_Cd) "
        End If
        If cmbDiv.SelectedValue <> "All" Then      'filter by division
            vFilter += " and Divcd='" & cmbDiv.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='division' and Property_Value=DivCd) "
        End If
        If cmbDept.SelectedValue <> "All" Then  'filter by departments
            vFilter += " and DeptCd='" & cmbDept.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='department' and Property_Value=DeptCd) "
        End If
        If cmbSection.SelectedValue <> "All" Then 'filter by section
            vFilter += " and SectionCd='" & cmbSection.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='section' and Property_Value=SectionCd) "
        End If
        If cmbUnit.SelectedValue <> "All" Then  'filter by units
            vFilter += " and UnitCd='" & cmbUnit.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='unit' and Property_Value=UnitCd) "
        End If
        vFilter += " and EmploymentType in ('" & txtRank.Text.Replace(",", "','") & "') "
        '''''''''''''''' END OF MODIFICATION '''''''''''''''''''

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        cm.Connection = c

        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                                        ''
        '' DATE MODIFIED: 1/3/2013                                             ''
        '' PURPOSE: TO INCLUDE THE FILTER SELECTION OF THE USER                ''
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '''''''''''''''''''''''' OLD CODE '''''''''''''''''''''''''''''''''''''''
        'cm.CommandText = "select Emp_Cd,Date_Sched,(select Emp_Lname+', '+Emp_Fname from py_emp_master where " & _
        '    "py_emp_master.Emp_Cd=py_emp_time_sched.Emp_Cd) as Name from py_emp_time_sched where ShiftCd='RD' and Date_Sched in " & _
        '    "(select Holy_Date from py_holiday where Holy_Date=Date_Sched) and Date_Sched not in " & _
        '    "(select StartDate from hr_leave_application where StartDate=Date_Sched and LeaveCd='OT' " & _
        '    "and Void=0 and DateApproved is Not null and py_emp_time_sched.Emp_Cd=hr_leave_application.Emp_Cd) " & _
        '    " order by Date_Sched desc, Emp_Cd"
        '''''''''''''''''''''''' END OLD CODE ''''''''''''''''''''''''''''''''''
        cm.CommandText = "select Emp_Cd,Date_Sched,(select Emp_Lname+', '+Emp_Fname from py_emp_master where " & _
            "py_emp_master.Emp_Cd=py_emp_time_sched.Emp_Cd) as Name from py_emp_time_sched where ShiftCd='RD' and Date_Sched in " & _
            "(select Holy_Date from py_holiday where Holy_Date=Date_Sched) and Date_Sched not in " & _
            "(select StartDate from hr_leave_application where StartDate=Date_Sched and LeaveCd='OT' " & _
            "and Void=0 and DateApproved is Not null and py_emp_time_sched.Emp_Cd=hr_leave_application.Emp_Cd) " & _
            "and Emp_Cd in (select Emp_Cd from py_emp_master where Date_Resign is null " & vFilter & _
            ") and Date_Sched between '" & Format(CDate(txtFrom.Text), "yyyy/MM/dd") & _
            "' and '" & Format(CDate(txtTo.Text), "yyyy/MM/dd") & "' order by Date_Sched desc, Emp_Cd"
        '''''''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''

        Try
            chkEmp.Items.Clear()
            rs = cm.ExecuteReader
            Do While rs.Read
                chkEmp.Items.Add(New ListItem(rs("Emp_Cd") & "=>" & rs("Name") & "=>" & Format(CDate(rs("Date_Sched")), "MM/dd/yyyy"), _
                    rs("Emp_Cd") & "~" & Format(CDate(rs("Date_Sched")), "yyyy/MM/dd")))
            Loop
            rs.Close()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while tyring to retrieve data. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            c.Dispose()
            cm.Dispose()
        End Try

        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                       ''
        '' DATE MODIFIED: 1/3/2013                            ''
        '' PURPOSE: TO DISABLE THE BUTTONS IF THE LIST IS     ''
        ''          EMPTY.                                    ''
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        cmdSelectAll.Enabled = chkEmp.Items.Count > 0
        cmdDeselect.Enabled = cmdSelectAll.Enabled
        cmdProcess.Enabled = cmdSelectAll.Enabled
        '''''''''''''' END OF MODIFICATION '''''''''''''''''''''
    End Sub

    Protected Sub cmdRefresh_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdRefresh.Click
        DataRefresh()
    End Sub

    Protected Sub txtFrom_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtFrom.Init
        txtFrom.Attributes.Add("onfocus", "showCalendarControl(this);")
    End Sub

    Protected Sub txtTo_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtTo.Init
        txtTo.Attributes.Add("onfocus", "showCalendarControl(this);")
    End Sub
End Class
