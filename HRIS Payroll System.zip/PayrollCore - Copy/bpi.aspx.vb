﻿Imports denaro.fis
Partial Class bpi
    Inherits System.Web.UI.Page
    Public vResponse As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            vResponse = "expired"
            Exit Sub
        End If

        Dim vCutOff As Date = CDate(Request.Form("cutoff"))
        Dim vEndCutOff As Date = CDate(Request.Form("cutoffE"))
        Dim vPayOut As Date = CDate(Request.Form("payout"))
        Dim vCredit As Date = CDate(Request.Form("credit"))
        Dim vAcctType As String = Request.Form("acct")
        Dim vBank As String = Request.Form("bank")
        Dim vRc As String = Request.Form("rc")
        Dim vAgency As String = Request.Form("agency")
        Dim vDiv As String = Request.Form("div")
        Dim vRank As String = Request.Form("rank")
        Dim vStatus As String = Request.Form("stat")


        Dim vCompanyName As String = vAgency
        Dim vGrandTotal As Decimal
        Dim iCtr As Integer
        Dim vErr As String = ""
        Dim vPreparedBy As String = ""
        Dim vApprovedBy As String = ""
        Dim vPosition As String = "Unknown"
        Dim vPositionApproved As String = "Unknown"
        Dim vFilter As String
        Dim vDump As String = ""
        Dim vCompanyCd As String
        Dim vBranchCd As String = ""
        Dim vBankCd As String = ""
        Dim vBatchNo As String = "01"
        Dim vAcctNo As String = ""
        Dim vCompanyAcctNo As String = ""
        Dim vTotal As Decimal = 0
        Dim vMax As Decimal = 0
        Dim vHash As String = ""
        Dim vAmt As Decimal = 0
        Dim iCountHash As Double = 0
        Dim iAcctHash As Double = 0
        Dim iCountAcctHash As Double = 0

        Dim vClass As String = "odd"
        Dim vData As New StringBuilder

        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader


        vFilter = " where PayDate='" & Format(vPayOut, "yyyy/MM/dd") & "' and FromDate='" & _
            Format(vCutOff, "yyyy/MM/dd") & "' and ToDate='" & Format(vEndCutOff, "yyyy/MM/dd") & "' "
        Select Case vAcctType
            Case "SA", "CA"
                vFilter += " and Report_No is not null and Report_No<>'' "
                'filter by bank code
                vFilter += " and BankCd='" & vBank & "' and BankType='" & vAcctType & "' "
            Case "BOTH"
                vFilter += " and Report_No is not null and Report_No<>'' and BankCd='" & vBank & "' "
            Case Else
                vFilter += " and (Report_No is null or Report_No='') "
        End Select

        If vRc <> "All" Then   'filter by cost center
            vFilter += " and Rc_Cd='" & vRc & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='rc' and Property_Value=Rc_Cd) "
        End If

        If vAgency <> "All" Then        'filter by office/agency
            vFilter += " and Agency_Cd='" & vAgency & "' "
        Else
            vFilter += "  and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='agency' and Property_Value=Agency_Cd) "
        End If
        If vDiv <> "All" Then      'filter by division
            vFilter += " and Divcd='" & vDiv & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='division' and Property_Value=DivCd) "
        End If
        If vRank <> "All" Then 'filter by employment types
            vFilter += " and EmploymentType in ('" & vRank.Replace(",", "','") & "') "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='employmenttype' and Property_Value=EmploymentType) "
        End If

        If Val(Session("userlevel")) = 0 Then    'ensure that only non-confidential employees are retrieved even user has access to confidential general info
            vFilter += " and exists (select Emp_Cd from py_emp_master where Confidential=0 and py_emp_master.Emp_Cd=py_report.Emp_Cd) "
        End If

        vData.Remove(0, vData.Length)
        vData.AppendLine("<html>")
        vData.AppendLine("<title>Bank Advise Report</title>")
        vData.AppendLine("<link rel='stylesheet' href='../redtheme/red.css' type='text/css' />")
        vData.AppendLine("<body><center>")

        cm.Connection = c
        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vResponse = "error"
            vData.AppendLine(ex.Message)
            GoTo dump
        End Try

        Try
            cm.CommandText = "select AgencyName from agency where AgencyCd='" & vAgency & "'"
            rs = cm.ExecuteReader
            If rs.Read Then
                vCompanyName = rs("AgencyName")
            End If
            rs.Close()
            cm.CommandText = "select CompanyCd,Company_Name,BranchCd,BankCd,Attention,AttentionPos,BankAcctNo,BatchNo " & _
                "  from glsyscntrl where AgencyCd='" & vAgency & "'"
            rs = cm.ExecuteReader
            vCompanyCd = vAgency        'set initial value
            vApprovedBy = "Unknown"
            vPositionApproved = "Unknown"
            vAcctNo = "unknown"
            If rs.Read Then
                vCompanyCd = IIf(IsDBNull(rs("CompanyCd")), "Unknown Company", rs("CompanyCd"))
                vBranchCd = IIf(IsDBNull(rs("BranchCd")), "Unknown Branch", rs("BranchCd"))
                vBankCd = IIf(IsDBNull(rs("BankCd")), "Unknown Bank", rs("BankCd"))
                vCompanyName = IIf(IsDBNull(rs("Company_Name")), "", Mid(rs("Company_Name"), 1, 40))
                vCompanyName += Space(40 - Len(vCompanyName))
                vApprovedBy = IIf(IsDBNull(rs("Attention")), "Unknown", rs("Attention"))
                vPositionApproved = IIf(IsDBNull(rs("AttentionPos")), "Unknown", rs("AttentionPos"))
                vAcctNo = IIf(IsDBNull(rs("BankAcctNo")), "Unknown", rs("BankAcctNo"))
                vAcctNo = vAcctNo.Replace("-", "")
                vCompanyAcctNo = vAcctNo
                vBatchNo = IIf(IsDBNull(rs("BatchNo")), "", rs("BatchNo"))
            End If
            rs.Close()

            'get total amount and ceiling amount 
            cm.CommandText = "select MAX(Amount_Per) as CeilingAmt, SUM(Amount_Per) as TotalAmt from py_report " & vFilter & _
               " and Amount_Per is not null and Amount_Per > 0 "

            Select Case vStatus
                Case 0  'inactive
                    cm.CommandText += " and Emp_Status='R' "
                Case 1  'active
                    cm.CommandText += " and Emp_Status not in ('R','HOLD') "
                Case 2  'hold
                    cm.CommandText += " and Emp_Status='HOLD' "
            End Select
            
            rs = cm.ExecuteReader
            If rs.Read Then
                vMax = IIf(IsDBNull(rs("CeilingAmt")), 0, rs("CeilingAmt"))
                vTotal = IIf(IsDBNull(rs("TotalAmt")), 0, rs("TotalAmt"))
            End If
            rs.Close()



            vData.AppendLine("<h2>Bank Advise Report for " & vCompanyName & "</h2>")
            vData.AppendLine("<h3>Employees " & IIf(vAcctType = "NA", "without", "with") & " Account Numbers" & "</h3><r/>")

            vData.AppendLine("<table border='1' style='border-collapse:collapse; width:420px;' class='mainGridView'><tr>" & _
                            "<td class='labelR'>Company Code:&nbsp;</td><td class='labelL'>&nbsp;" & vCompanyCd & "</td></tr>" & _
                            "<tr><td class='labelR'>Company Account #:&nbsp;</td><td class='labelL'>&nbsp;" & vCompanyAcctNo & "</td></tr>" & _
                            "<tr><td class='labelR'>Payroll Date:&nbsp;</td><td class='labelL'>&nbsp;" & vPayOut & "</td></tr>" & _
                            "<tr><td class='labelR'>Pay Amount:&nbsp;</td><td class='labelL'>&nbsp;" & Format(vTotal, "##,###,##0.00") & "</td></tr>" & _
                            "<tr><td class='labelR'>Batch Number:&nbsp;</td><td class='labelL'>&nbsp;" & vBatchNo & "</td></tr>" & _
                            "<tr><td class='labelR'>Ceiling Amount:&nbsp;</td><td class='labelL'>&nbsp;" & _
                            Format(vMax, "##,###,##0.00") & "</td></tr></table><br/>")

            vData.AppendLine("<table border='1' style='border-collapse:collapse; width:420px;' class='mainGridView'><tr class='titleBar'>" & _
                "<th>Employee Account Number</th>" & _
                "<th>Employee Name</th>" & _
                "<th>Transaction Amount</th>" & _
                "<th>Horizontal Hash</th></tr>")

            vGrandTotal = 0
            iCtr = 1
            cm.CommandText = "select FullName,Position from user_list where User_Id='" & Session("uid") & "'"
            rs = cm.ExecuteReader
            vPreparedBy = Session("uid")
            vPosition = "Uknown"
            If rs.Read Then
                vPreparedBy = IIf(IsDBNull(rs("FullName")), Session("uid"), rs("FullName"))
                vPosition = IIf(IsDBNull(rs("Position")), "Unknown", rs("Position"))
            End If
            rs.Close()

            cm.CommandText = "select Name,Report_No,Amount_Per,Emp_Cd from py_report " & vFilter & _
               " and Amount_Per is not null and Amount_Per > 0 "

            Select Case vStatus
                Case 0  'inactive
                    cm.CommandText += " and Emp_Status='R' "
                Case 1  'active
                    cm.CommandText += " and Emp_Status not in ('R','HOLD') "
                Case 2  'hold
                    cm.CommandText += " and Emp_Status='HOLD' "
            End Select
            cm.CommandText += " order by Name"

            rs = cm.ExecuteReader
            iCountAcctHash = 0
            iCountHash = 0
            iCtr = 0
          
            vDump = "H" & Mid(vCompanyCd, 1, 5) & Format(vCredit.Month, "00") & _
                           Format(vCredit.Day, "00") & Format((vCredit.Year - 2000), "00") & _
                           vBatchNo & "1" & Mid(vCompanyAcctNo, 1, 10) & Mid(vBranchCd, 1, 3) & Format(vMax * 100, "000000000000") & _
                           Format(vTotal * 100, "000000000000") & "1" & Space(75) & vbCrLf

            Do While rs.Read
                vAcctNo = IIf(IsDBNull(rs("Report_No")), "", rs("Report_No")).ToString.Replace("-", "")
                vAmt = rs("Amount_Per")
                iAcctHash = 0

                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY: VIC GATCHALIAN                          ''
                '' DATE MODIFIED:  2/21/2012                            ''
                '' PURPOSE: TO UPDATE THE NEW ACCOUNT HASH              ''
                ''          AS PER RELEASE OF BPI                       ''
                '''''''''''''''' OLD CODE ''''''''''''''''''''''''''''''''
                'For iLoop As Integer = 1 To 10
                '    iAcctHash += Int(Mid(vAcctNo, iLoop, 1))
                'Next iLoop
                '''''''''''''''' END OLD CODE ''''''''''''''''''''''''''''

                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY:  VIC GATCHALIAN                           ''
                '' DATE MODIFIED: 2/21/2012                               ''
                '' PURPOSE: TO UPDATE THE NEW HASH COMPUTATION FORMAT     ''
                ''          ISSUED BY BPI                                 ''
                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '''''''''''''''''' OLD CODE ''''''''''''''''''''''''''''''''
                'vHash = Math.Round(((Int(Mid(vAcctNo, 5, 1)) + _
                '        Int(Mid(vAcctNo, 6, 1))) * vAmt) + _
                '        ((Int(Mid(vAcctNo, 7, 1)) + _
                '        Int(Mid(vAcctNo, 8, 1))) * vAmt) + _
                '        ((Int(Mid(vAcctNo, 9, 1)) + _
                '        Int(Mid(vAcctNo, 10, 1))) * vAmt), 2)
                '''''''''''''''''' END OLD CODE ''''''''''''''''''''''''''''
                vHash = Math.Round((Int(Mid(vAcctNo, 5, 2)) * vAmt) + _
                        (Int(Mid(vAcctNo, 7, 2)) * vAmt) + _
                        (Int(Mid(vAcctNo, 9, 2)) * vAmt), 2)
                '''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''


                vData.AppendLine("<tr class='" & vClass & "'>" & _
                    "<td class='labelC'>" & vAcctNo & _
                    "</td><td class='labelL'>" & rs("Name") & _
                    "</td><td class='labelR'>" & Format(vAmt, "###,##0.00") & _
                    "</td><td class='labelR'>" & vHash & "</td></tr>")

                vDump += "D" & Mid(vCompanyCd, 1, 5) & Format(vCredit.Month, "00") & _
                   Format(vCredit.Day, "00") & Format((vCredit.Year - 2000), "00") & _
                   vBatchNo & "3" & Mid(vAcctNo, 1, 10) & Format(rs("Amount_Per") * 100, "000000000000") & _
                   Format(vHash * 100, "000000000000") & Space(79) & vbCrLf

                iCountHash += vHash
                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY:  VIC GATCHALIAN                             ''
                '' DATE MODIFIEDBy 2/21/2012                                ''
                '' PURPOSE: TO SYNCHRONIZE WITH THE NEW BPI FORMAT          ''
                ''          COMPUTATION                                     ''
                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '''''''''''''''''' OLD CODE ''''''''''''''''''''''''''''''''''
                'iCountAcctHash += iAcctHash
                '''''''''''''''''' END OLD CODE ''''''''''''''''''''''''''''''
                iCountAcctHash += Val(vAcctNo)
                '''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''

                vGrandTotal += rs("Amount_Per")
                iCtr += 1

                vClass = IIf(vClass = "odd", "even", "odd")
            Loop
            rs.Close()

            vDump += "T" & Mid(vCompanyCd, 1, 5) & Format(vCredit.Month, "00") & _
                  Format(vCredit.Day, "00") & Format(vCredit.Year - 2000, "00") & _
                  vBatchNo & "2" & Mid(vCompanyAcctNo, 1, 10) & Format(iCountAcctHash, "000000000000000") & _
                  Format(vGrandTotal * 100, "000000000000000") & _
                  Format(iCountHash * 100, "000000000000000000") & _
                  Format(iCtr, "00000") & Space(50)

            vData.AppendLine("<tr class='titleBar'><td class='labelR'>" & Format(iCountAcctHash, "###,##0") & "</td>" & _
                "<td class='labelC'>&nbsp;</td>" & _
                "<td class='labelR'>" & Format(vGrandTotal, "###,##0.00") & "</td>" & _
                "<td class='labelR'>" & Format(iCountHash, "#,###,##0.00") & "</td></tr>" & _
                "</table><br/>Record Count: " & Format(iCtr, "#,##0") & "<br/>")

            vData.AppendLine("<br/><table border='0' class='mainGridView'><tr valign='top'><td class='labelL'>Prepared By:<br/><br/><br/><br/></td>" & _
                "<td></td><td class='labelL'>Approved By:</td></tr>")
            vData.AppendLine("<tr><td class='labelL'>_________________________</td><td>&nbsp;&nbsp;&nbsp;</td>" & _
                "<td class='labelL'>______________________</td></tr>" & _
                 "<tr><td class='labelL'>" & vPreparedBy & "</td><td></td><td class='labelL'>" & vApprovedBy & "</td></tr>" & _
                 "<tr><td class='labelL'>" & vPosition & "</td><td></td><td class='labelL'>" & vPositionApproved & "</td></tr></table>")
            
        Catch ex As SqlClient.SqlException
            vResponse = "error"
            vData.AppendLine(ex.Message)
            GoTo dump
        End Try
dump:
        vData.AppendLine("</center></body>")
        vData.AppendLine("</html>")
        Try
            IO.File.WriteAllText(Server.MapPath(".") & "\downloads\" & Session.SessionID & "-bankadvise.html", vData.ToString)
            IO.File.WriteAllText(Server.MapPath(".") & "\downloads\" & Session.SessionID & "-bankadvise.txt", vDump)
            vResponse = "downloads/" & Session.SessionID & "-bankadvise.html~" & _
                "downloads/" & Session.SessionID & "-bankadvise.txt"
        Catch ex As System.Exception
            vResponse = "error"
        Finally
            c.Close()
            cm.Dispose()
            c.Dispose()
        End Try
    End Sub
End Class
