﻿Imports denaro.fis
Partial Class import
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Public vError As String = ""
    Public vDetail As String = ""
    Public vSummary As String = ""
    Public vDetailProd As String = ""
    Dim vMsgLog As String = ""



End Class


'Partial Class import
'    Inherits System.Web.UI.Page
'    Public vScript As String = ""
'    Public vError As String = ""
'    Public vDetail As String = ""
'    Public vSummary As String = ""
'    Public vDetailProd As String = ""
'    Dim vMsgLog As String = ""

'    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
'        If Session("uid") = "" Then
'            Server.Transfer("index.aspx")
'            Exit Sub
'        End If

'        If Not CanRun(Session("caption"), Request.Item("id")) Then
'            Session("denied") = "1"
'            Server.Transfer("main.aspx")
'            Exit Sub
'        End If

'        If Not IsPostBack Then
'            lblCaption.Text = "Import Utility"
'            Dim c As New SqlClient.SqlConnection(connStr)
'            Dim cm As New SqlClient.SqlCommand
'            Dim rs As SqlClient.SqlDataReader

'            Try
'                c.Open()
'            Catch ex As SqlClient.SqlException
'                vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
'                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
'                c.Dispose()
'                cm.Dispose()
'                Exit Sub
'            End Try

'            cm.Connection = c
'            Try
'                cm.CommandText = "select count(*) from py_emp_master"
'                rs = cm.ExecuteReader
'                rs.Read()
'                lblMaster.Text = "0"
'                If Not IsDBNull(rs(0)) Then
'                    lblMaster.Text = Format(rs(0), "##,###,##0")
'                End If
'                rs.Close()
'            Catch ex As SqlClient.SqlException
'                vScript = "alert('Error occurred while trying to retrieve employee master file. Error is: " & _
'                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
'            Finally
'                c.Close()
'                c.Dispose()
'                cm.Dispose()
'            End Try
'            'DataRefresh()
'            cmdClear.Visible = False
'        End If
'    End Sub

'    Private Sub DataRefresh()
'        Dim c As New SqlClient.SqlConnection(connStr)
'        Dim da As SqlClient.SqlDataAdapter
'        Dim ds As New DataSet
'        Dim vCond As String = ""

'        If rdoFilter.SelectedValue <> "all" Then
'            If rdoFilter.SelectedValue <> "resigned" Then
'                vCond = " where Ecard='" & rdoFilter.SelectedValue & "'"
'            Else
'                vCond = " where Date_Resign is not null and exists " & _
'                    "(select py_emp_master.Emp_Cd from py_emp_master where py_emp_master.Emp_Cd=" & _
'                    "import_emp_master.Emp_Cd and py_emp_master.Date_Resign is null) "
'            End If
'        End If

'        lblFilter.Text = rdoFilter.SelectedValue

'        If txtSearch.Text <> "" Then
'            lblFilter.Text += " - Filtered"
'            If vCond <> "" Then
'                vCond += " and "
'            Else
'                vCond += " where "
'            End If
'            vCond += cmbType.SelectedValue & "='" & txtSearch.Text & "' "
'        End If

'        Try
'            da = New SqlClient.SqlDataAdapter("select * from " & rdoOption.SelectedValue & _
'                vCond & " order by Emp_Lname,Emp_Fname", c)

'            da.Fill(ds, "temp")
'            tblTmpEmp.DataSource = ds.Tables("temp")
'            tblTmpEmp.DataBind()
'        Catch ex As SqlClient.SqlException
'            vScript = "alert('An error has occurred while trying to retrieve Temporary employee master file. Error is: " & _
'                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
'        Finally
'            'lblImport.Text = Format(ds.Tables("temp").Rows.Count, "##,###,##0")
'            c.Dispose()
'            'da.Dispose()
'            ds.Dispose()
'        End Try
'    End Sub

'    Protected Sub cmdUpload_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdUpload.Click
'        Dim vIndex As Integer = 0
'        vIndex = rdoOption.SelectedIndex

'        If cmdBrowse.FileName = "" Then
'            vScript = "alert('You must first supply a file to upload by clicking the Browse button.');"
'            Exit Sub
'        End If

'        Dim vType As String = ""

'        If cmdBrowse.FileName.Contains(".") Then
'            vType = Mid(cmdBrowse.FileName, cmdBrowse.FileName.LastIndexOf(".") + 1)
'        End If

'        Dim vFilename As String = Server.MapPath(".") & "\uploaded\" & Session.SessionID & vType

'        Try
'            cmdBrowse.SaveAs(vFilename)
'        Catch ex As IO.IOException
'            vScript = "alert('An error has occurred while trying to upload the file. Error is: " & _
'                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
'            Exit Sub
'        End Try

'        Select Case rdoOption.SelectedValue

'            Case "earnings"
'                UploadEarnings(vFilename)           'Onetime Earnings

'            Case "deductions"
'                UploadDeductions(vFilename)         'Onetime Deductions

'            Case "attendance"
'                UploadAttendance(vFilename)         'Attendance Template
'                cmdEmpTimeLog.Visible = True

'            Case "import_emp_master", "wfh"      '201 masterfile
'                ProcessUpload(rdoOption.SelectedValue, vFilename, rdoOption.SelectedValue)
'                If vIndex = 1 Then 'work from home, pop-up addtional loader
'                    vScript = "wfhwin=window.open('importwhf.aspx','wfh','top=100,left=100,width=500,height=150,resizable=yes,toolbar=no,scrollbars=yes,status=yes'); wfhwin.focus();"
'                    Exit Sub
'                End If
'                vScript = "winexcept = window.open('importexception.aspx','except','toolbar=no,scrollbars=yes,resizable=yes,top=10,left=100,width=640,height=480'); " & _
'                    "winexcept.focus();"

'                'Case "loans"
'                '    UploadLoans(vFilename)              'Upload Loans
'                '    cmdLoanConfirm.Visible = True
'                'Case "PRODPAY"
'                'UploadProdPay(vFilename)            'Productivity Pay Exemption
'                'Case "wfhlogs"
'                'UploadWFHLogs(vFilename)            'Work from Home Payfile
'                'cmdEmpTimeLog.Visible = True
'                'Case "wfhearnings"
'                'UploadDailyEarnings(vFilename)      'Work from Home Daily Earnings
'                'cmdEmpTimeLog.Visible = True
'                'Case "sbose"
'                'UploadSalaries(vFilename)
'        End Select
'    End Sub

'    'Private Sub UploadWFHLogs(ByVal pFilename As String)
'    '    Dim c As New SqlClient.SqlConnection(connStr)
'    '    Dim cm As New SqlClient.SqlCommand

'    '    Dim cmRef As New SqlClient.SqlCommand
'    '    Dim rsRef As SqlClient.SqlDataReader
'    '    Dim vTranDate As String = ""
'    '    Dim vBasic As String = ""

'    '    Dim vContents() As String
'    '    Dim vFields() As String
'    '    Dim vSql As String
'    '    Dim i As Integer

'    '    cm.Connection = c
'    '    cmRef.Connection = c

'    '    Try
'    '        c.Open()
'    '    Catch ex As SqlClient.SqlException
'    '        vScript = "alert('Error has occurred while trying to connect to database. Error is: " & _
'    '            ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
'    '        c.Dispose()
'    '        cm.Dispose()
'    '        Exit Sub
'    '    End Try

'    '    Try
'    '        vContents = IO.File.ReadAllLines(pFilename)
'    '    Catch ex As IO.FileLoadException
'    '        vScript = "alert('Error reading uploaded file. Error is: " & _
'    '            ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
'    '        c.Dispose()
'    '        cm.Dispose()
'    '        Exit Sub
'    '    End Try

'    '    vError = ""

'    '    For i = vContents.GetLowerBound(0) + 1 To vContents.GetUpperBound(0)
'    '        vFields = vContents(i).Split(txtFieldSeparator.Text)
'    '        Try
'    '            If vFields(0) = "" Then
'    '                vError += "Error in Row " & i + 1 & ": Employee ID is empty. Record skipped.<br/>"
'    '            Else
'    '                If vFields(1) = "" Or (vFields(1) <> "" And Not IsDate(vFields(1))) Then
'    '                    vError += "Error in Row " & i + 1 & ": Invalid date format. Record skipped.<br/>"
'    '                Else

'    '                    vTranDate = vFields(1)
'    '                    cmRef.CommandText = "select * from hr_emp_career_movement where Emp_Cd = '" & vFields(0) & "' " & _
'    '                        "and From_Date >= '" & Format(CDate(vTranDate), "yyyy/MM/dd 00:00:00") & "' " & _
'    '                        "and To_Date <= '" & Format(CDate(vTranDate), "yyyy/MM/dd 00:00:00") & "' "

'    '                    rsRef = cmRef.ExecuteReader
'    '                    If rsRef.HasRows Then
'    '                        vBasic = vFields(2) & "_TRN"
'    '                    Else
'    '                        vBasic = vFields(2)
'    '                    End If
'    '                    rsRef.Close()

'    '                    vSql = "delete from import_emp_time_log where Emp_Cd='" & vFields(0) & _
'    '                        "' and TranDate='" & Format(CDate(vFields(1)), "yyyy/MM/dd") & "' and TranCd='" & vBasic & "'"
'    '                    cm.CommandText = vSql
'    '                    cm.ExecuteNonQuery()

'    '                    'now insert the new record
'    '                    'vSql = "insert into import_emp_time_log (Emp_Cd,TranDate,TranCd,Hrs_Rendered,AmtConv,Reason," & _
'    '                    '    "Frozen,EffectivityDate) values ('" & _
'    '                    '    vFields(0) & "','" & Format(CDate(vFields(1)), "yyyy/MM/dd") & "','" & vBasic & "',0," & _
'    '                    '    Val(vFields(4)) & ",'',0,'" & _
'    '                    '    Format(CDate(vFields(1)), "yyyy/MM/dd") & "')"
'    '                    'cm.CommandText = vSql
'    '                    'cm.ExecuteNonQuery()
'    '                End If
'    '            End If
'    '        Catch ex as system.exception
'    '            vError += "Error in Row " & i & ": " & _
'    '                ex.Message.Replace(vbCrLf, "").Replace("'", "") & ". Record skipped.<br/>"
'    '        End Try
'    '    Next

'    '    vScript = "alert('Work from home payfile database successfully loaded.');"
'    '    c.Close()
'    '    c.Dispose()
'    '    cm.Dispose()
'    '    divError.Visible = vError <> ""
'    '    CreateCSVFile()
'    '    RefreshWFHLogs()
'    'End Sub

'    'Private Sub UploadDailyEarnings(ByVal pFilename As String)
'    '    Dim c As New SqlClient.SqlConnection(connStr)
'    '    Dim cm As New SqlClient.SqlCommand

'    '    Dim cmRef As New SqlClient.SqlCommand
'    '    Dim rsRef As SqlClient.SqlDataReader

'    '    Dim vContents() As String
'    '    Dim vFields() As String
'    '    Dim vSql As String
'    '    Dim i As Integer
'    '    Dim vTranDate As String = ""
'    '    Dim vHrs_Rendered As String = ""
'    '    Dim vBasic As String = ""

'    '    cm.Connection = c
'    '    cmRef.Connection = c

'    '    Try
'    '        c.Open()
'    '    Catch ex As SqlClient.SqlException
'    '        vScript = "alert('Error has occurred while trying to connect to database. Error is: " & _
'    '            ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
'    '        c.Dispose()
'    '        cm.Dispose()
'    '        Exit Sub
'    '    End Try

'    '    Try
'    '        vContents = IO.File.ReadAllLines(pFilename)
'    '    Catch ex As IO.FileLoadException
'    '        vScript = "alert('Error reading uploaded file. Error is: " & _
'    '            ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
'    '        c.Dispose()
'    '        cm.Dispose()
'    '        Exit Sub
'    '    End Try

'    '    vError = ""

'    '    For i = vContents.GetLowerBound(0) + 1 To vContents.GetUpperBound(0)
'    '        vFields = vContents(i).Split(txtFieldSeparator.Text)

'    '        Try
'    '            If vFields(0) = "" Then
'    '                vError += "Error in Row " & i + 1 & ": Employee ID is empty. Record skipped.<br/>"
'    '            Else

'    '                If Not IsDate(vFields(4)) Then
'    '                    vTranDate = vFields(5)
'    '                    vHrs_Rendered = vFields(6)
'    '                Else
'    '                    vTranDate = vFields(4)
'    '                    vHrs_Rendered = vFields(5)
'    '                End If

'    '                'search vtrandate in hr_emp_career_movement if falls between fromdate and todate of each employee.
'    '                'if found, change trancd = 'BASIC_TRN', if no record, trancd='BASIC'

'    '                cmRef.CommandText = "select * from hr_emp_career_movement where Emp_Cd = '" & vFields(0) & "' " & _
'    '                    "and From_Date >= '" & Format(CDate(vTranDate), "yyyy/MM/dd 00:00:00") & "' " & _
'    '                    "and To_Date <= '" & Format(CDate(vTranDate), "yyyy/MM/dd 00:00:00") & "' "

'    '                rsRef = cmRef.ExecuteReader
'    '                If rsRef.HasRows Then
'    '                    vBasic = "BASIC_TRN"
'    '                Else
'    '                    vBasic = "BASIC"
'    '                End If
'    '                rsRef.Close()

'    '                vSql = "delete from import_emp_time_log where Emp_Cd='" & vFields(0) & "' and TranDate='" & _
'    '                        Format(CDate(vTranDate), "yyyy/MM/dd") & "' and TranCd like 'BASIC%'"

'    '                cm.CommandText = vSql
'    '                cm.ExecuteNonQuery()

'    '                vSql = "insert into import_emp_time_log (Emp_Cd, TranDate, TranCd, Hrs_Rendered, AmtConv, Reason, Frozen, EffectivityDate) " & _
'    '                        "values ('" & vFields(0) & "', '" & Format(CDate(vTranDate), "yyyy/MM/dd 00:00:00") & "', '" & vBasic & "', '" & vHrs_Rendered & "', " & _
'    '                        "'" & vFields(14) & "', 'UPLOADED', 0, '" & Format(CDate(vTranDate), "yyyy/MM/dd 00:00:00") & "')"

'    '                cm.CommandText = vSql
'    '                cm.ExecuteNonQuery()

'    '            End If
'    '        Catch ex as system.exception
'    '            vError += "Error in Row " & i & ": " & _
'    '                ex.Message.Replace(vbCrLf, "").Replace("'", "") & ". Record skipped.<br/>"
'    '        End Try
'    '    Next

'    '    vScript = "alert('Work from Home Daily Earnings database successfully loaded.');"
'    '    c.Close()
'    '    c.Dispose()
'    '    cm.Dispose()
'    '    cmRef.Dispose()
'    '    divError.Visible = vError <> ""
'    '    CreateCSVFile()
'    '    RefreshWFHLogs()
'    'End Sub

'    Private Sub UploadAttendance(ByVal pFilename As String)
'        Dim c As New SqlClient.SqlConnection(connStr)
'        Dim cm As New SqlClient.SqlCommand
'        Dim cmRef As New SqlClient.SqlCommand
'        Dim rsRef As SqlClient.SqlDataReader

'        Dim vTranDate As String = ""
'        Dim vBasic As String = ""

'        Dim vContents() As String
'        Dim vFields() As String
'        Dim vRemarks As String = ""
'        Dim vSql As String
'        'Dim vAmount As Decimal
'        Dim i As Integer

'        cm.Connection = c
'        cmRef.Connection = c
'        Try
'            c.Open()
'        Catch ex As SqlClient.SqlException
'            vScript = "alert('Error has occurred while trying to connect to database. Error is: " & _
'                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
'            c.Dispose()
'            cm.Dispose()
'            cmRef.Dispose()
'            Exit Sub
'        End Try

'        Try
'            vContents = IO.File.ReadAllLines(pFilename)
'        Catch ex As IO.FileLoadException
'            vScript = "alert('Error reading uploaded file. Error is: " & _
'                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
'            c.Dispose()
'            cm.Dispose()
'            cmRef.Dispose()
'            Exit Sub
'        End Try

'        vError = ""

'        vSql = "delete from import_emp_time_log"
'        cm.CommandText = vSql
'        cm.ExecuteNonQuery()

'        For i = vContents.GetLowerBound(0) + 1 To vContents.GetUpperBound(0)
'            vFields = vContents(i).Split(txtFieldSeparator.Text)
'            Try
'                If vFields(0) = "" Then
'                    vError += "Error in Row " & i + 1 & ": Employee ID is empty. Record skipped.<br/>"
'                Else
'                    If vFields(1) = "" Or (vFields(1) <> "" And Not IsDate(vFields(1))) Then
'                        vError += "Error in Row " & i + 1 & ": Invalid date format. Record skipped.<br/>"
'                    Else

'                        'vTranDate = vFields(1)
'                        'cmRef.CommandText = "select * from hr_emp_career_movement where Emp_Cd = '" & vFields(0) & "' " & _
'                        '    "and From_Date >= '" & Format(CDate(vTranDate), "yyyy/MM/dd 00:00:00") & "' " & _
'                        '    "and To_Date <= '" & Format(CDate(vTranDate), "yyyy/MM/dd 00:00:00") & "' "

'                        'rsRef = cmRef.ExecuteReader
'                        'If rsRef.HasRows Then
'                        '    vBasic = vFields(2) & "_TRN"
'                        'Else
'                        '    vBasic = vFields(2)
'                        'End If
'                        'rsRef.Close()

'                        vSql = "insert into import_emp_time_log (Emp_Cd, Agency_Cd, Tran_Date, Time_In, Time_Out, Time_OutDate, Reason) " & _
'                            " values ('" & vFields(0) & "', '', '" & vFields(1) & "', '" & vFields(2) & _
'                            "', '" & vFields(3) & "','" & vFields(4) & "','')"
'                        cm.CommandText = vSql
'                        cm.ExecuteNonQuery()

'                        'get rate per day
'                        'vAmount = 0
'                        'cmRef.CommandText = "select Rate_Day from py_emp_master where Emp_Cd='" & vFields(0) & "'"
'                        'rsRef = cmRef.ExecuteReader
'                        'If rsRef.Read Then
'                        '    vAmount = Val(vFields(3)) * (rsRef("Rate_Day") / 8)
'                        'End If
'                        'rsRef.Close()

'                        'now insert the new record
'                        'If vFields.GetUpperBound(0) < 4 Then
'                        '    vRemarks = ""
'                        'Else
'                        '    vRemarks = vFields(4).Replace("'", "")
'                        'End If
'                        'zvSql = "insert into import_emp_time_log (Emp_Cd, TranDate, TranCd, Hrs_Rendered, AmtConv, Reason," & _
'                        '    "Frozen, EffectivityDate) values ('" & _
'                        '    vFields(0) & "','" & Format(CDate(vFields(1)), "yyyy/MM/dd") & "','" & vBasic & _
'                        '    "'," & Val(vFields(3)) & "," & vAmount & ",'" & vRemarks & "',0,'" & _
'                        '    Format(CDate(vFields(1)), "yyyy/MM/dd") & "')"
'                        'cm.CommandText = vSql
'                        'cm.ExecuteNonQuery()
'                    End If
'                End If
'            Catch ex As System.Exception
'                vError += "Error in Row " & i & ": " & _
'                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & ". Record skipped.<br/>"
'            End Try
'        Next

'        vScript = "alert('Attendance Template successfully loaded.');"
'        c.Close()
'        c.Dispose()
'        cm.Dispose()
'        cmRef.Dispose()
'        divError.Visible = vError <> ""
'        CreateCSVFile()
'        RefreshLogs()
'    End Sub

'    Private Sub UploadDeductions(ByVal pFilename As String)
'        Dim c As New SqlClient.SqlConnection(connStr)
'        Dim cm As New SqlClient.SqlCommand
'        Dim cmA As New SqlClient.SqlCommand
'        Dim rs As SqlClient.SqlDataReader

'        Dim vValid As Boolean
'        Dim vContents() As String
'        Dim vFields() As String
'        Dim vRemarks As String = ""
'        Dim i As Integer

'        cm.Connection = c
'        cmA.Connection = c
'        Try
'            c.Open()
'        Catch ex As SqlClient.SqlException
'            vScript = "alert('Error has occurred while trying to connect to database. Error is: " & _
'                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
'            c.Dispose()
'            cm.Dispose()
'            Exit Sub
'        End Try

'        Try
'            vContents = IO.File.ReadAllLines(pFilename)
'        Catch ex As IO.FileLoadException
'            vScript = "alert('Error reading uploaded file. Error is: " & _
'                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
'            c.Dispose()
'            cm.Dispose()
'            Exit Sub
'        End Try

'        vError = ""

'        cm.CommandText = "delete from import_loan_hdr"
'        cm.ExecuteNonQuery()

'        For i = vContents.GetLowerBound(0) + 1 To vContents.GetUpperBound(0)
'            vFields = vContents(i).Split(txtFieldSeparator.Text)
'            Try

'                If vFields(3) = "" Or Not IsDate(vFields(3)) Then
'                    vError += "Error in Row " & i + 1 & ": Invalid Date. Record skipped. <br/>"
'                Else
'                    'vSql = "delete from import_loan_hdr where Emp_Cd='" & _
'                    '    vFields(0) & "' and Loan_Cd='" & _
'                    '    vFields(1) & "' and Loan_Date='" & _
'                    '    Format(CDate(vFields(3)), "yyyy/MM/dd") & "'"

'                    'cm.CommandText = vSql
'                    'cm.ExecuteNonQuery()

'                    'now insert the new record
'                    'If vFields.GetUpperBound(0) < 7 Then
'                    '    vRemarks = ""
'                    'Else
'                    '    vRemarks = vFields(7).Replace("'", "")
'                    'End If
'                    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
'                    '' MODIFIED BY:  VIC GATCHALIAN                                            ''
'                    '' DATE MODIFIED:  2/16/2012                                               ''
'                    '' PURPOSE:  TO TRAP WHETHER THE CODE IS EXISTING IN THE REFERENCE TABLE   ''
'                    ''           OR NOT.  IF NOT EXISTING, CHECK THE SETTING IF NEW CODES ARE  ''
'                    ''           ALLOWED TO BE INSERTED AUTOMATICALLY OR NOT.                  ''
'                    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
'                    ''''''''''''''''''''''''' OLD CODE ''''''''''''''''''''''''''''''''''''''''''
'                    'vSql = "insert into import_loan_hdr (Emp_Cd,Loan_Cd,Loan_Date,Start_Date,Active," & _
'                    '    "MonthlyAmort,Amt_Bal,Int_Rate,Amt_Loan,Amt_Paid,DocNo,ProdDescr," & _
'                    '    "Recurring,Month_To_Pay,End_Date) values ('" & _
'                    '    vFields(0) & "','" & vFields(1) & "','" & Format(CDate(vFields(3)), "yyyy/MM/dd") & _
'                    '    "','" & Format(CDate(vFields(3)), "yyyy/MM/dd") & "',1," & Val(vFields(2)) & _
'                    '    "," & Val(vFields(2)) & ",0," & Val(vFields(2)) & _
'                    '    ",0,'','Uploaded by " & Session("uid") & " on " & Now() & "',0,1,'" & _
'                    '    Format(CDate(vFields(3)), "yyyy/MM/dd") & "')"

'                    'cm.CommandText = vSql
'                    'cm.ExecuteNonQuery()
'                    ''''''''''''''''''''''''' END OLD CODE ''''''''''''''''''''''''''''''''''''''
'                    vValid = False  'default to invalid code 

'                    'CHECK if the employee code exists in the masterfile database
'                    cm.CommandText = "select Date_Resign from py_emp_master where Emp_Cd='" & _
'                        vFields(0) & "'"
'                    rs = cm.ExecuteReader
'                    If rs.Read Then 'employee id exists
'                        If IsDBNull(rs("Date_Resign")) Then 'employee is active
'                            vValid = True
'                        Else 'employee is already resigned
'                            vError += "Error in Row " & i + 1 & ": Employee ID: " & vFields(0) & " is already resigned. Record skipped. <br/>"
'                            vValid = False
'                            rs.Close()
'                            GoTo skip
'                        End If
'                    Else    'invalid employee id
'                        vError += "Error in Row " & i + 1 & ": Employee ID: " & vFields(0) & " does not exist. Record skipped. <br/>"
'                        vValid = False
'                        rs.Close()
'                        GoTo skip
'                    End If
'                    rs.Close()

'                    cm.CommandText = "select 1 from py_loan_ref where Loan_Cd='" & _
'                        vFields(1) & "'"
'                    rs = cm.ExecuteReader
'                    If Not rs.Read Then 'code is new, trap the validity parameter
'                        If Not chkAutoAddCode.Checked Then
'                            vError += "Error in Row " & i + 1 & ": Invalid Loan Code: " & vFields(1) & ". Record skipped. <br/>"
'                            vValid = False
'                        Else    'consider valid code since auto-add is enabled 
'                            vValid = True
'                        End If
'                    Else    'loan code is valid
'                        vValid = True
'                    End If
'                    rs.Close()

'skip:
'                    If vValid Then
'                        cm.CommandText = "insert into import_loan_hdr (Emp_Cd,Loan_Cd,Loan_Date,Start_Date,Active," & _
'                            "MonthlyAmort,Amt_Bal,Int_Rate,Amt_Loan,Amt_Paid,DocNo,ProdDescr," & _
'                            "Recurring,Month_To_Pay,End_Date) values ('" & _
'                            vFields(0) & "','" & vFields(1) & "','" & Format(CDate(vFields(3)), "yyyy/MM/dd") & _
'                            "','" & Format(CDate(vFields(3)), "yyyy/MM/dd") & "',1," & Val(vFields(2)) & _
'                            "," & Val(vFields(2)) & ",0," & Val(vFields(2)) & _
'                            ",0,'','Uploaded by " & Session("uid") & " on " & Now() & "',0,1,'" & _
'                            Format(CDate(vFields(3)), "yyyy/MM/dd") & "')"
'                        cm.ExecuteNonQuery()
'                        cmdLoanConfirm.Visible = True
'                        cmdClear.Visible = True
'                        vScript = "alert('Onetime deductions successfully loaded.');"

'                    End If
'                    ''''''''''''''''''''' END OF MODIFCATION ''''''''''''''''''''''''''''''''''''
'                End If
'            Catch ex As System.Exception
'                vError += "Error in Row test " & i & ": " & _
'                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & ". Record skipped.<br/>"
'            End Try
'        Next


'        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
'        '' MODIFIED BY:  VIC GATCHALIAN                                             ''
'        '' DATE MODIFIED:  2/16/2012                                                ''
'        '' PURPOSE:  TO CHECK THE PARAMETER IF NEW CODES SHOULD BE ADDED            ''
'        ''           AUTOMATICALLY OR NOT                                           ''
'        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
'        '''''''''''''''''''''''''''' OLD CODE ''''''''''''''''''''''''''''''''''''''''
'        'cm.CommandText = "select distinct Loan_Cd from import_loan_hdr where not exists " & _
'        '    "(select Loan_Cd from py_loan_ref where py_loan_ref.Loan_Cd=import_loan_hdr.Loan_Cd)"
'        'rs = cm.ExecuteReader

'        'Do While rs.Read
'        '    cmA.CommandText = "insert into py_loan_ref (Loan_Cd, Loan_Name) values ('" & rs("Loan_Cd") & "', '" & rs("Loan_Cd") & "')"
'        '    cmA.ExecuteNonQuery()
'        '    vMsgLog += "New Deduction code " & rs("Loan_Cd") & "  has been added to the reference. " & vbCrLf
'        'Loop
'        'rs.Close()
'        'IO.File.WriteAllText(Server.MapPath(".") & "\downloads\" & Session.SessionID & "-Deduction_import.txt", vMsgLog)


'        'vScript = "winlog = window.open('downloads/" & Session.SessionID & _
'        '        "-Deduction_import.txt','winlog','toolbar=no,resizable=yes,top=10,left=100,width=640,height=480'); winlog.focus();"
'        '''''''''''''''''''''''''''' END OLD CODE ''''''''''''''''''''''''''''''''''''
'        If chkAutoAddCode.Checked Then
'            cm.CommandText = "select distinct Loan_Cd from import_loan_hdr where not exists " & _
'                "(select Loan_Cd from py_loan_ref where py_loan_ref.Loan_Cd=import_loan_hdr.Loan_Cd)"
'            rs = cm.ExecuteReader

'            Do While rs.Read
'                cmA.CommandText = "insert into py_loan_ref (Loan_Cd, Loan_Name) values ('" & rs("Loan_Cd") & "', '" & rs("Loan_Cd") & "')"
'                cmA.ExecuteNonQuery()
'                vMsgLog += "New Deduction code " & rs("Loan_Cd") & "  has been added to the reference. " & vbCrLf
'            Loop
'            rs.Close()
'            IO.File.WriteAllText(Server.MapPath(".") & "\downloads\" & Session.SessionID & "-Deduction_import.txt", vMsgLog)

'            vScript += "winlog = window.open('downloads/" & Session.SessionID & _
'                    "-Deduction_import.txt','winlog','toolbar=no,resizable=yes,top=10,left=100,width=640,height=480'); winlog.focus();"
'        End If
'        ''''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''''''''''''

'        c.Close()
'        c.Dispose()
'        cm.Dispose()
'        divError.Visible = vError <> ""
'        CreateCSVFile()
'        RefreshDeductions()
'    End Sub

'    Private Sub UploadEarnings(ByVal pFilename As String)
'        Dim c As New SqlClient.SqlConnection(connStr)
'        Dim cm As New SqlClient.SqlCommand
'        Dim cmA As New SqlClient.SqlCommand
'        Dim rs As SqlClient.SqlDataReader

'        Dim vValid As Boolean
'        Dim vContents() As String
'        Dim vFields() As String
'        Dim vRemarks As String = ""
'        Dim i As Integer

'        cm.Connection = c
'        cmA.Connection = c
'        Try
'            c.Open()
'        Catch ex As SqlClient.SqlException
'            vScript = "alert('Error has occurred while trying to connect to database. Error is: " & _
'                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
'            c.Dispose()
'            cm.Dispose()
'            Exit Sub
'        End Try

'        Try
'            vContents = IO.File.ReadAllLines(pFilename)
'        Catch ex As IO.FileLoadException
'            vScript = "alert('Error reading uploaded file. Error is: " & _
'                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
'            c.Dispose()
'            cm.Dispose()
'            Exit Sub
'        End Try

'        vError = ""

'        cm.CommandText = "delete from import_py_incentives_dtl"
'        cm.ExecuteNonQuery()

'        For i = vContents.GetLowerBound(0) + 1 To vContents.GetUpperBound(0)
'            vFields = vContents(i).Split(txtFieldSeparator.Text)
'            Try

'                If vFields(3) = "" Or Not IsDate(vFields(3)) Then
'                    vError += "Error in Row " & i + 1 & ": Invalid Date. Record skipped. <br/>"
'                Else

'                    vValid = False  'default to invalid code 

'                    'CHECK if the employee code exists in the masterfile database
'                    cm.CommandText = "select Date_Resign from py_emp_master where Emp_Cd='" & _
'                        vFields(0) & "'"
'                    rs = cm.ExecuteReader
'                    If rs.Read Then 'employee id exists
'                        If IsDBNull(rs("Date_Resign")) Then 'employee is active
'                            vValid = True
'                        Else 'employee is already resigned
'                            vError += "Error in Row " & i + 1 & ": Employee ID: " & vFields(0) & " is already resigned. Record skipped. <br/>"
'                            vValid = False
'                            rs.Close()
'                            GoTo skip
'                        End If
'                    Else    'invalid employee id
'                        vError += "Error in Row " & i + 1 & ": Employee ID: " & vFields(0) & " does not exist. Record skipped. <br/>"
'                        vValid = False
'                        rs.Close()
'                        GoTo skip
'                    End If
'                    rs.Close()

'                    cm.CommandText = "select 1 from py_other_incentvs where Incentive_Cd='" & _
'                        vFields(1) & "'"
'                    rs = cm.ExecuteReader
'                    If Not rs.Read Then 'code is new, trap the validity parameter
'                        If Not chkAutoAddCode.Checked Then
'                            vError += "Error in Row 1 " & i + 1 & ": Invalid Incentive Code: " & vFields(1) & ". Record skipped. <br/>"
'                            vValid = False
'                        Else    'consider valid code since auto-add is enabled 
'                            vValid = True
'                        End If
'                    Else    'loan code is valid
'                        vValid = True
'                    End If
'                    rs.Close()
'skip:
'                    If vValid Then
'                        cm.CommandText = "insert into import_py_incentives_dtl (Emp_Cd, Incentive_Cd, Incentive_Amt, FromDate, ToDate," & _
'                            "Recurring, FreqCd, DateUploaded) values ('" & _
'                            vFields(0) & "','" & vFields(1) & "','" & Val(vFields(2)) & "','" & _
'                            Format(CDate(vFields(3)), "yyyy/MM/dd") & _
'                            "','" & Format(CDate(vFields(3)), "yyyy/MM/dd") & _
'                            "',0,0, '" & Format(Now(), "yyyy/MM/dd hh:mm:ss") & "')"
'                        cm.ExecuteNonQuery()
'                        cmdLoanConfirm.Visible = True
'                        cmdClear.Visible = True
'                        vScript = "alert('Onetime Incentives successfully loaded.');"
'                    End If
'                End If
'            Catch ex As System.Exception
'                vError += "Error in Row " & i & ": " & _
'                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & ". Record skipped.<br/>"
'                cmdLoanConfirm.Visible = False
'            End Try
'        Next

'        If chkAutoAddCode.Checked Then
'            cm.CommandText = "select distinct Incentive_Cd from import_py_incentives_dtl where not exists " & _
'                "(select Incentive_Cd from py_other_incentvs where py_other_incentvs.Incentive_Cd=import_loan_hdr.Incentive_Cd)"
'            rs = cm.ExecuteReader

'            Do While rs.Read
'                cmA.CommandText = "insert into py_other_incentvs (Incentive_Cd, Descr) values ('" & rs("Incentive_Cd") & "', '" & rs("Incentive_Cd") & "')"
'                cmA.ExecuteNonQuery()
'                vMsgLog += "New Incentive code " & rs("Loan_Cd") & "  has been added to the reference. " & vbCrLf
'            Loop
'            rs.Close()
'            IO.File.WriteAllText(Server.MapPath(".") & "\downloads\" & Session.SessionID & "-Incentive_import.txt", vMsgLog)

'            vScript += "winlog = window.open('downloads/" & Session.SessionID & _
'                    "-Deduction_import.txt','winlog','toolbar=no,resizable=yes,top=10,left=100,width=640,height=480'); winlog.focus();"
'        End If


'        c.Close()
'        c.Dispose()
'        cm.Dispose()
'        divError.Visible = vError <> ""
'        CreateCSVFile()
'        RefreshEarnings()
'        'RefreshDeductions()
'    End Sub

'    ''Private Sub UploadProdPay(ByVal pFilename As String)
'    ''    Dim c As New SqlClient.SqlConnection(connStr)
'    ''    Dim cm As New SqlClient.SqlCommand
'    ''    Dim cmRef As New SqlClient.SqlCommand
'    ''    Dim rsRef As SqlClient.SqlDataReader
'    ''    Dim vContents() As String
'    ''    Dim vFields() As String
'    ''    Dim vAmount As Decimal
'    ''    Dim vSql As String
'    ''    Dim i As Integer

'    ''    cm.Connection = c
'    ''    cmRef.Connection = c
'    ''    Try
'    ''        c.Open()
'    ''    Catch ex As SqlClient.SqlException
'    ''        vScript = "alert('Error has occurred while trying to connect to database. Error is: " & _
'    ''            ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
'    ''        c.Dispose()
'    ''        cm.Dispose()
'    ''        cmRef.Dispose()
'    ''        Exit Sub
'    ''    End Try

'    ''    Try
'    ''        vContents = IO.File.ReadAllLines(pFilename)
'    ''    Catch ex As IO.FileLoadException
'    ''        vScript = "alert('Error reading uploaded file. Error is: " & _
'    ''            ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
'    ''        c.Dispose()
'    ''        cm.Dispose()
'    ''        cmRef.Dispose()
'    ''        Exit Sub
'    ''    End Try

'    ''    vError = ""

'    ''    For i = vContents.GetLowerBound(0) + 1 To vContents.GetUpperBound(0)
'    ''        vFields = vContents(i).Split(txtFieldSeparator.Text)
'    ''        Try
'    ''            If vFields(0) = "" Then
'    ''                vError += "Error in Row " & i + 1 & ": Employee ID is empty. Record skipped.<br/>"
'    ''            Else

'    ''                vSql = "delete from py_incentives_dtl where Incentive_Cd='PRODPAY' and FromDate >='" & _
'    ''                    Format(CDate(txtStartDate.Text), "yyyy/MM/dd") & "' and ToDate <='" & _
'    ''                    Format(CDate(txtEndDate.Text), "yyyy/MM/dd") & "' and Emp_Cd='" & _
'    ''                    vFields(0) & "'"
'    ''                cm.CommandText = vSql
'    ''                cm.ExecuteNonQuery()

'    ''                vAmount = 0
'    ''                'If Val(vFields(1)) = 1 Then
'    ''                'get amount from py_emp_master
'    ''                'cmRef.CommandText = "select Aca from py_emp_master where Emp_Cd='" & _
'    ''                '    vFields(0) & "'"

'    ''                cmRef.CommandText = "select Incentive_Amt from py_incentives_dtl where Emp_Cd='" & _
'    ''                    vFields(0) & "' and Incentive_Cd='PRODPAY' and Recurring=1"

'    ''                rsRef = cmRef.ExecuteReader
'    ''                If rsRef.Read Then
'    ''                    If Not IsDBNull(rsRef("Incentive_Amt")) Then
'    ''                        vAmount = 0
'    ''                        If vFields(1) <> 0 Then   'productivity is half only
'    ''                            vAmount = (rsRef("Incentive_Amt") / 2) * -1
'    ''                        Else
'    ''                            vAmount = rsRef("Incentive_Amt") * -1
'    ''                        End If
'    ''                    End If
'    ''                End If
'    ''                rsRef.Close()
'    ''                'End If

'    ''                If vAmount <> 0 Then
'    ''                    'now insert the new record
'    ''                    vSql = "insert into py_incentives_dtl (Emp_Cd,Incentive_Cd,Incentive_Amt,FromDate,ToDate," & _
'    ''                        "Recurring,FreqCd) values ('" & _
'    ''                        vFields(0) & "','PRODPAY'," & vAmount & ",'" & Format(CDate(txtStartDate.Text), "yyyy/MM/dd") & _
'    ''                        "','" & Format(CDate(txtEndDate.Text), "yyyy/MM/dd") & _
'    ''                        "',0,0)"
'    ''                    cm.CommandText = vSql
'    ''                    cm.ExecuteNonQuery()
'    ''                End If
'    ''            End If
'    ''        Catch ex as system.exception
'    ''            vError += "Error in Row " & i & ": " & _
'    ''                ex.Message.Replace(vbCrLf, "").Replace("'", "") & ". Record skipped.<br/>"
'    ''        End Try
'    ''    Next
'    ''    txtStartDate.Text = ""
'    ''    txtEndDate.Text = ""

'    ''    vScript = "alert('Productivity Pay successfully loaded.');"
'    ''    c.Close()
'    ''    c.Dispose()
'    ''    cm.Dispose()
'    ''    cmRef.Dispose()
'    ''    divError.Visible = vError <> ""
'    ''    CreateCSVFile()
'    ''    RefreshProdPay()
'    ''End Sub

'    Private Sub UploadLoans(ByVal pFilename As String)
'        Dim c As New SqlClient.SqlConnection(connStr)
'        Dim cm As New SqlClient.SqlCommand
'        Dim cmA As New SqlClient.SqlCommand
'        Dim rs As SqlClient.SqlDataReader

'        Dim vContents() As String
'        Dim vFields() As String
'        Dim vSql As String
'        Dim i As Integer

'        cm.Connection = c
'        cmA.Connection = c

'        Try
'            c.Open()
'        Catch ex As SqlClient.SqlException
'            vScript = "alert('Error has occurred while trying to connect to database. Error is: " & _
'                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
'            c.Dispose()
'            cm.Dispose()
'            Exit Sub
'        End Try

'        Try
'            vContents = IO.File.ReadAllLines(pFilename)
'        Catch ex As IO.FileLoadException
'            vScript = "alert('Error reading uploaded file. Error is: " & _
'                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
'            c.Dispose()
'            cm.Dispose()
'            Exit Sub
'        End Try

'        vError = ""

'        cm.CommandText = "delete from import_loan_hdr"
'        cm.ExecuteNonQuery()

'        For i = vContents.GetLowerBound(0) + 1 To vContents.GetUpperBound(0)
'            vFields = vContents(i).Split(txtFieldSeparator.Text)

'            Try

'                If vFields(3) = "" Or Not IsDate(vFields(3)) Or _
'                    vFields(4) = "" Or Not IsDate(vFields(4)) Then
'                    vError += "Error in Row " & i + 1 & ": Invalid Date. Record skipped.<br/>"
'                Else

'                    'now insert the new record
'                    vSql = "insert into import_loan_hdr (Emp_Cd, Loan_Cd, Loan_Date, Start_Date, Active," & _
'                        "MonthlyAmort, Amt_Bal, Int_Rate, Amt_Loan, Amt_Paid, DocNo, ProdDescr," & _
'                        "Recurring, Month_To_Pay, End_Date) values ('" & _
'                        vFields(0) & "','" & vFields(1) & "','" & Format(CDate(vFields(3)), "yyyy/MM/dd") & _
'                        "','" & Format(CDate(vFields(4)), "yyyy/MM/dd") & "'," & _
'                        IIf(vFields(2).ToUpper = "Y", 1, 0) & "," & Val(vFields(6)) & _
'                        "," & Val(vFields(6)) & ",0," & Val(vFields(5)) & _
'                        ",0,'"

'                    If UBound(vFields) < 15 Then
'                        vSql += ""
'                    Else
'                        vSql += vFields(15).Replace("'", "")
'                    End If
'                    vSql += "','"

'                    If UBound(vFields) < 14 Then
'                        vSql += ""
'                    Else
'                        vSql += vFields(14).Replace("'", "")
'                    End If

'                    'IIf(UBound(vFields) < 14, "", vFields(14).Replace("'", ""))

'                    vSql += "',0," & Val(vFields(8)) & ",'" & _
'                        Format(CDate(vFields(4)).AddMonths(Val(vFields(8))), "yyyy/MM/dd") & "')"

'                    cm.CommandText = vSql
'                    cm.ExecuteNonQuery()

'                End If
'            Catch ex As System.Exception
'                vError += "Error in Row " & i & ": " & _
'                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & ". Record skipped.<br/>"
'            End Try
'        Next

'        'cm.CommandText = "update import_loan_hdr set Amt_Paid = Amt_Loan - Amt_Bal"
'        'cm.ExecuteNonQuery()

'        cm.CommandText = "select distinct Loan_Cd from import_loan_hdr where not exists " & _
'            "(select Loan_Cd from py_loan_ref where py_loan_ref.Loan_Cd=import_loan_hdr.Loan_Cd)"
'        rs = cm.ExecuteReader
'        Do While rs.Read
'            cmA.CommandText = "insert into py_loan_ref (Loan_Cd, Loan_Name) values ('" & rs("Loan_Cd") & "', '" & rs("Loan_Cd") & "')"
'            cmA.ExecuteNonQuery()
'            vMsgLog += "New Loan code " & rs("Loan_Cd") & "  has been added to the reference. " & vbCrLf
'        Loop

'        IO.File.WriteAllText(Server.MapPath(".") & "\downloads\" & Session.SessionID & "-Loan_import.txt", vMsgLog)
'        rs.Close()

'        vScript = "winlog = window.open('downloads/" & Session.SessionID & _
'                "-Loan_import.txt','winlog','toolbar=no,resizable=yes,top=10,left=100,width=640,height=480'); winlog.focus();"

'        vScript += "alert('Loans successfully loaded.');"
'        c.Close()
'        c.Dispose()
'        cm.Dispose()
'        divError.Visible = vError <> ""
'        RefreshLoans()
'    End Sub

'    Private Sub RefreshDeductions()
'        Dim c As New SqlClient.SqlConnection(connStr)
'        Dim cm As New SqlClient.SqlCommand
'        Dim cmRef As New SqlClient.SqlCommand
'        Dim rs As SqlClient.SqlDataReader
'        Dim rsRef As SqlClient.SqlDataReader
'        Dim vClass As String = "odd"
'        Dim vName As String = ""

'        Dim vTtlLoanAmt As Decimal = 0
'        Dim vTtlMPayment As Decimal = 0
'        Dim vTtlLoanBal As Decimal = 0

'        Try
'            c.Open()
'        Catch ex As SqlClient.SqlException
'            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
'                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
'            c.Dispose()
'            cm.Dispose()
'            Exit Sub
'        End Try
'        cm.Connection = c
'        cmRef.Connection = c

'        'refresh the list
'        vDetail = ""
'        cm.CommandText = "select * from import_loan_hdr where Loan_Date=Start_Date and Month_to_Pay=1"

'        Try
'            rs = cm.ExecuteReader
'            Do While rs.Read
'                cmRef.CommandText = "select Emp_Lname,Emp_Fname from py_emp_master where Emp_Cd='" & _
'                    rs("Emp_Cd") & "'"
'                rsRef = cmRef.ExecuteReader
'                vName = "Unknown"
'                If rsRef.Read Then
'                    vName = rsRef("Emp_Lname") & ", " & rsRef("Emp_Fname")
'                End If
'                rsRef.Close()

'                vDetail += "<tr class='" & vClass & "'>" & _
'                    "<td class='labelC'>" & rs("Emp_Cd") & "</td>" & _
'                    "<td class='labelL' style='border-left: solid 1px #8b8b8a;'>&nbsp;" & vName & "</td>" & _
'                    "<td class='labelC' style='border-left: solid 1px #8b8b8a;'>" & rs("Loan_Cd") & "</td>" & _
'                    "<td class='labelC' style='border-left: solid 1px #8b8b8a;'>" & Format(rs("Loan_Date"), "MM/dd/yyyy") & "</td>" & _
'                    "<td class='labelC' style='border-left: solid 1px #8b8b8a;'>" & Format(rs("Start_Date"), "MM/dd/yyyy") & "</td>" & _
'                    "<td class='labelR' style='border-left: solid 1px #8b8b8a;'>" & Format(rs("Amt_Loan"), "##,##0.00") & "&nbsp;</td>" & _
'                    "<td class='labelR' style='border-left: solid 1px #8b8b8a;'>" & Format(rs("MonthlyAmort"), "##,##0.00") & "&nbsp;</td>" & _
'                    "<td class='labelR' style='border-left: solid 1px #8b8b8a;'>" & Format(rs("Amt_Bal"), "##,##0.00") & "&nbsp;</td>" & _
'                    "<td class='labelL' style='border-left: solid 1px #8b8b8a;'>&nbsp;" & rs("ProdDescr") & "</td></tr>"

'                vTtlLoanAmt += rs("Amt_Loan")
'                vTtlMPayment += rs("MonthlyAmort")
'                vTtlLoanBal += rs("Amt_Bal")

'                If vClass = "odd" Then
'                    vClass = "even"
'                Else
'                    vClass = "odd"
'                End If
'            Loop
'            vDetail += "<tr><td colspan='5' style='padding:5px;' class='labelR'><b>Total :<b />&nbsp;" & _
'                "</td><td class='labelR'><b>" & Format(vTtlLoanAmt, "##,##0.00") & _
'                "<b />&nbsp;</td><td class='labelR'><b>" & Format(vTtlMPayment, "##,##0.00") & _
'                "<b />&nbsp;</td><td class='labelR'><b>" & Format(vTtlLoanBal, "##,##0.00") & "<b />&nbsp;</td><td>&nbsp;</td></tr>"


'            rs.Close()
'        Catch ex As SqlClient.SqlException
'            vScript = "alert('Error occurred while retrieving the Loans Ledger. Error is: " & _
'                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
'        Finally
'            c.Close()
'            cm.Dispose()
'            cmRef.Dispose()
'            c.Dispose()
'        End Try

'    End Sub

'    Private Sub RefreshLoans()
'        Dim c As New SqlClient.SqlConnection(connStr)
'        Dim cm As New SqlClient.SqlCommand
'        Dim rs As SqlClient.SqlDataReader
'        Dim vClass As String = "odd"

'        Try
'            c.Open()
'        Catch ex As SqlClient.SqlException
'            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
'                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
'            c.Dispose()
'            cm.Dispose()
'            Exit Sub
'        End Try
'        cm.Connection = c

'        'refresh the list
'        vDetail = ""
'        cm.CommandText = "select * from import_loan_hdr"

'        Try
'            rs = cm.ExecuteReader
'            Do While rs.Read
'                vDetail += "<tr class='" & vClass & "'>" & _
'                    "<td class='labelC'>" & rs("Emp_Cd") & "</td>" & _
'                    "<td class='labelL' style='border-left: solid 1px #8b8b8a;'>&nbsp;" & rs("Loan_Cd") & "</td>" & _
'                    "<td class='labelC' style='border-left: solid 1px #8b8b8a;'>" & Format(rs("Loan_Date"), "MM/dd/yyyy") & "</td>" & _
'                    "<td class='labelC' style='border-left: solid 1px #8b8b8a;'>" & Format(rs("Start_Date"), "MM/dd/yyyy") & "</td>" & _
'                    "<td class='labelR' style='border-left: solid 1px #8b8b8a;'>" & Format(rs("Amt_Loan"), "##,##0.00") & "&nbsp;</td>" & _
'                    "<td class='labelR' style='border-left: solid 1px #8b8b8a;'>" & Format(rs("MonthlyAmort"), "##,##0.00") & "&nbsp;</td>" & _
'                    "<td class='labelR' style='border-left: solid 1px #8b8b8a;'>" & Format(rs("Amt_Bal"), "##,##0.00") & "&nbsp;</td>" & _
'                    "<td class='labelL' style='border-left: solid 1px #8b8b8a;'>&nbsp;" & rs("DocNo") & "</td>" & _
'                    "<td class='labelL' style='border-left: solid 1px #8b8b8a;'>&nbsp;" & rs("ProdDescr") & "</td></tr>"
'            Loop
'            rs.Close()
'        Catch ex As SqlClient.SqlException
'            vScript = "alert('Error occurred while retrieving the Loans Ledger. Error is: " & _
'                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
'        Finally
'            c.Close()
'            cm.Dispose()
'            c.Dispose()
'        End Try

'    End Sub

'    Private Sub ProcessUpload(ByVal pTempTable As String, ByVal pFileName As String, ByVal pCode As String)
'        Dim vHeader() As String
'        Dim vFields() As String
'        Dim vIndeces As String = ""
'        Dim vLink As String = ""
'        Dim vXrefTable As String = ""
'        Dim vSw As Boolean
'        Dim i As Integer
'        Dim j As Integer
'        Dim c As New SqlClient.SqlConnection(connStr)
'        Dim cm As New SqlClient.SqlCommand
'        Dim rs As SqlClient.SqlDataReader
'        Dim cmRef As New SqlClient.SqlCommand
'        Dim rsRef As SqlClient.SqlDataReader

'        Dim cmXRef As New SqlClient.SqlCommand
'        Dim rsXRef As SqlClient.SqlDataReader

'        Dim cmYRef As New SqlClient.SqlCommand
'        'Dim rsYRef As sqlclient.sqlDataReader

'        Dim vSQL As String = ""
'        Dim vSqlContent As String = ""

'        Try
'            'now open the file for loading
'            Dim vContent() As String = IO.File.ReadAllLines(pFileName)

'            'get header fields
'            vHeader = vContent(0).Split(txtFieldSeparator.Text)

'            'create sql statement
'            Try
'                c.Open()
'            Catch ex As SqlClient.SqlException
'                vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
'                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
'                c.Dispose()
'                cm.Dispose()
'                cmRef.Dispose()
'                cmXRef.Dispose()
'                cmYRef.Dispose()
'                Exit Sub
'            End Try

'            cm.Connection = c
'            cmRef.Connection = c
'            cmXRef.Connection = c
'            cmYRef.Connection = c

'            vSQL = "select * from _db where TempTable='" & pCode & "' and TableKey is not null"
'            Response.Write(vSQL)
'            cm.CommandText = vSQL

'            Exit Sub



'            Try
'                rs = cm.ExecuteReader
'                vSQL = "insert into " & pTempTable & " ("
'                vSw = False
'                Do While rs.Read
'                    vSQL += rs("TableKey") & ","
'                    vXrefTable = rs("TableName")
'                    If rs("IndexKey") = 1 Then
'                        vLink += rs("TableKey") & ","
'                    End If
'                    vSw = True
'                Loop
'                rs.Close()
'            Catch ex As SqlClient.SqlException
'                vScript = "alert('Error occurred while trying build SQL script. Error is: " & _
'                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
'                c.Close()
'                c.Dispose()
'                cm.Dispose()
'                cmRef.Dispose()
'                cmXRef.Dispose()
'                cmYRef.Dispose()
'                Exit Sub
'            End Try

'            If vSw Then
'                vSQL = vSQL.Substring(0, vSQL.Length - 1) & ") values ("
'                If vLink <> "" Then
'                    vLink = vLink.Substring(0, vLink.Length - 1)
'                End If
'            Else
'                vSQL = ""
'                vScript = "alert('File uploaded is invalid for this type of option.');"
'                c.Close()
'                c.Dispose()
'                cm.Dispose()
'                cmRef.Dispose()
'                cmXRef.Dispose()
'                cmYRef.Dispose()
'                Exit Sub
'            End If
'            Session("xreftable") = vXrefTable
'            Session("temptable") = pTempTable
'            Session("key") = vLink
'            'delete temporary table content
'            cm.CommandText = "delete from import_emp_master"
'            cm.ExecuteNonQuery()

'            'now insert uploaded file to temp table
'            For i = vContent.GetLowerBound(0) + 1 To vContent.GetUpperBound(0)
'                vFields = vContent(i).Split(txtFieldSeparator.Text)
'                vSqlContent = ""
'                cm.CommandText = "select * from _db where TempTable='" & pCode & "' and TableKey is not null"

'                rs = cm.ExecuteReader
'                Do While rs.Read
'                    vSw = False
'                    If Not IsDBNull(rs("FactKey")) Then
'                        For j = vHeader.GetLowerBound(0) To vHeader.GetUpperBound(0)
'                            If vHeader(j) = rs("FactKey") Then
'                                vSw = True
'                                Exit For
'                            End If
'                        Next
'                        If vSw Then 'index was found
'                            If vHeader(j).ToUpper = "GNDR" Then
'                                If vFields(j) = "M" Then vFields(j) = 1 Else vFields(j) = 0
'                            End If
'                            If rs("Required") = 1 And vFields(j) = "" Then  'get default values
'                                Select Case rs("Condition").ToString
'                                    Case "STRING"
'                                        vSqlContent += "'" & rs("DefaultValue") & "',"
'                                    Case "NUMERIC"
'                                        vSqlContent += Val(rs("DefaultValue")) & ","
'                                    Case "DATE"
'                                        vSqlContent += "'" & Format(Now, "yyyy/MM/dd") & "',"
'                                End Select
'                            Else    'field is not required
'                                Select Case rs("Condition").ToString
'                                    Case "STRING"
'                                        vSqlContent += "'" & Trim(vFields(j).Replace("'", "")) & "',"
'                                    Case "NUMERIC"
'                                        If vFields(j) <> "" And IsNumeric(vFields(j)) Then
'                                            vSqlContent += Val(vFields(j)) & ","
'                                        Else
'                                            vSqlContent += "0,"
'                                        End If
'                                    Case "DATE"
'                                        If vFields(j) <> "" And IsDate(vFields(j)) Then
'                                            vSqlContent += "'" & Format(CDate(vFields(j)), "yyyy/MM/dd") & "',"
'                                        Else
'                                            vSqlContent += "null,"
'                                        End If
'                                End Select
'                            End If
'                        Else 'index was not found, use defaults
'                            Select Case rs("Condition").ToString
'                                Case "STRING"
'                                    If Not IsDBNull(rs("DefaultValue")) Then
'                                        vSqlContent += "'" & rs("DefaultValue") & "',"
'                                    Else
'                                        vSqlContent += "'',"
'                                    End If
'                                Case "NUMERIC"
'                                    If Not IsDBNull(rs("DefaultValue")) Then
'                                        vSqlContent += Val(rs("DefaultValue")) & ","
'                                    Else
'                                        vSqlContent += "0,"
'                                    End If
'                                Case "DATE"
'                                    vSqlContent += "'" & Format(Now, "yyyy/MM/dd") & "',"
'                            End Select
'                        End If
'                    Else
'                        If rs("Required") = 1 Then
'                            Select Case rs("Condition").ToString
'                                Case "STRING"
'                                    vSqlContent += "'" & rs("DefaultValue") & "',"
'                                Case "NUMERIC"
'                                    vSqlContent += Val(rs("DefaultValue")) & ","
'                                Case "DATE"
'                                    vSqlContent += "'" & Format(Now, "yyyy/MM/dd") & "',"
'                            End Select
'                        Else
'                            Select Case rs("Condition").ToString
'                                Case "STRING"
'                                    If Not IsDBNull(rs("DefaultValue")) Then
'                                        vSqlContent += "'" & rs("DefaultValue") & "',"
'                                    Else
'                                        vSqlContent += "'',"
'                                    End If
'                                Case "NUMERIC"
'                                    If Not IsDBNull(rs("DefaultValue")) Then
'                                        vSqlContent += Val(rs("DefaultValue")) & ","
'                                    Else
'                                        vSqlContent += "0,"
'                                    End If
'                                Case "DATE"
'                                    vSqlContent += "'" & Format(Now, "yyyy/MM/dd") & "',"
'                            End Select
'                        End If
'                    End If
'                Loop
'                rs.Close()
'                vSqlContent = vSqlContent.Substring(0, vSqlContent.Length - 1) & ")"
'                cm.CommandText = vSQL & vSqlContent
'                Try
'                    cm.ExecuteNonQuery()
'                Catch ex As SqlClient.SqlException
'                    'Response.Write("Error in row " & i & " of the text file. <br/>")
'                    vError += "Error in row " & i & " - " & ex.Message.Replace(vbCrLf, "") & "<br/>"
'                End Try
'            Next

'            'determine the status of each record

'            Dim vVL_MaxCredit As String = ""
'            Dim vSL_MaxCredit As String = ""
'            Dim vEmp_Cd As String = ""
'            'Dim vDateReg As Date

'            'cmXRef.CommandText = "update import_emp_master set Emp_Status='Regular' where Emp_Status='FR'"
'            'cmXRef.ExecuteNonQuery()
'            'cmXRef.CommandText = "update import_emp_master set Emp_Status='Probationa' where Emp_Status='FP'"
'            'cmXRef.ExecuteNonQuery()
'            'cmXRef.CommandText = "update import_emp_master set Emp_Status = 'Separated' where Date_Resign is not null"
'            'cmXRef.ExecuteNonQuery()
'            'cmXRef.CommandText = "update import_emp_master set Tax_Cd='S' where Tax_Cd ='' "
'            'cmXRef.ExecuteNonQuery()

'            cm.CommandText = "select * from " & pTempTable
'            rs = cm.ExecuteReader
'            Do While rs.Read
'                cmXRef.CommandText = "select * from " & vXrefTable & " where " & vLink & "='" & _
'                    rs(vLink) & "'"

'                rsXRef = cmXRef.ExecuteReader
'                If rsXRef.HasRows Then

'                    rsXRef.Read()
'                    'compare each field if there are changes
'                    cmRef.CommandText = "select TableKey from _db where TempTable='" & _
'                        pCode & "' and TableKey is not null"
'                    rsRef = cmRef.ExecuteReader
'                    vSw = False

'                    Do While rsRef.Read
'                        If Not IsDBNull(rs(rsRef("TableKey"))) And _
'                            Not IsDBNull(rsXRef(rsRef("TableKey"))) Then
'                            If rs(rsRef("TableKey")) <> rsXRef(rsRef("TableKey")) Then  'field value was changed
'                                vSw = True
'                                Exit Do
'                            End If
'                        Else
'                            If (IsDBNull(rs(rsRef("TableKey"))) And Not IsDBNull(rsXRef(rsRef("TableKey")))) Or _
'                               (Not IsDBNull(rs(rsRef("TableKey"))) And IsDBNull(rsXRef(rsRef("TableKey")))) Then
'                                vSw = True
'                                Exit Do
'                            End If
'                        End If
'                    Loop
'                    rsRef.Close()
'                    If vSw Then
'                        cmRef.CommandText = "update " & pTempTable & " set Ecard='modified' where " & _
'                            vLink & "='" & rs(vLink) & "'"
'                    Else
'                        cmRef.CommandText = "update " & pTempTable & " set Ecard='unchanged' where " & _
'                            vLink & "='" & rs(vLink) & "'"
'                    End If
'                Else
'                    cmRef.CommandText = "update " & pTempTable & " set Ecard='new' where " & _
'                        vLink & "='" & rs(vLink) & "'"
'                End If
'                rsXRef.Close()
'                cmRef.ExecuteNonQuery()
'            Loop
'            rs.Close()
'            c.Close()
'        Catch ex As SqlClient.SqlException
'            vScript = "alert('An error has occurred while trying to upload the file. Error is: " & _
'                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
'        Finally

'            c.Dispose()
'            cm.Dispose()
'            cmRef.Dispose()
'            cmYRef.Dispose()
'            cmXRef.Dispose()
'            DataRefresh()
'            divError.Visible = vError <> ""
'        End Try
'        CreateCSVFile()
'    End Sub

'    Protected Sub cmdExit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdExit.Click
'        Server.Transfer("main.aspx")
'    End Sub

'    Protected Sub tblTmpEmp_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles tblTmpEmp.PageIndexChanging
'        tblTmpEmp.PageIndex = e.NewPageIndex
'        DataRefresh()
'    End Sub

'    Protected Sub cmdValidate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdValidate.Click
'        Dim c As New SqlClient.SqlConnection(connStr)
'        Dim cm As New SqlClient.SqlCommand
'        Dim rs As SqlClient.SqlDataReader

'        Dim cmA As New SqlClient.SqlCommand
'        Dim rsA As SqlClient.SqlDataReader

'        Dim cmB As New SqlClient.SqlCommand
'        'Dim rsB As sqlclient.sqlDataReader

'        Dim vMsgLog As String = ""
'        Dim vData As String = ""
'        Dim vFields As String = ""
'        Dim vDaysmonth As Decimal = 0
'        Dim vTable As String = ""
'        Dim i As Integer = 0
'        'Dim vFromDate As Date
'        'Dim vToDate As Date
'        Dim vVL_MaxCredit As String = ""
'        Dim vSL_MaxCredit As String = ""

'        Try
'            c.Open()
'        Catch ex As SqlClient.SqlException
'            vScript = "alert('Error occurred while trying to connect to the database. Error is: " & _
'                ex.Message.Replace("'", "").Replace(vbCrLf, "") & "');"
'            c.Dispose()
'            cm.Dispose()
'            Exit Sub
'        End Try

'        cm.Connection = c
'        cmA.Connection = c
'        cmB.Connection = c



'        cm.CommandText = "select MaxCredit from py_leave_ref where Leave_Cd = 'VL'"
'        rs = cm.ExecuteReader
'        If rs.Read Then
'            vVL_MaxCredit = rs("MaxCredit")
'        End If
'        rs.Close()

'        cm.CommandText = "select MaxCredit from py_leave_ref where Leave_Cd = 'SL'"
'        rs = cm.ExecuteReader
'        If rs.Read Then
'            vSL_MaxCredit = rs("MaxCredit")
'        End If
'        rs.Close()

'        cm.CommandText = "select dates_to_month from py_syscntrl"
'        rs = cm.ExecuteReader
'        If rs.Read Then
'            vDaysmonth = rs("dates_to_month")
'        End If
'        rs.Close()

'        cm.CommandText = "select TableName from _db where TempTable='" & rdoOption.SelectedValue & "'"
'        Try
'            rs = cm.ExecuteReader
'            If rs.Read Then
'                vTable = rs("TableName")
'            End If
'            rs.Close()
'            'insert new records
'            cm.CommandText = "insert into " & vTable & _
'                "(Emp_Cd,BarcodeId,Emp_Fname,Emp_Mname,Emp_Lname,Pos_Cd,Rate_Day,Emp_Address,Emp_Tel," & _
'                "Emp_Email,Res_Cert,Pera,Rate_Month,Sss_No,Gsis_No,Pagibig_No,Tin,User_Id,Pay_Cd,Grade_Cd,Agency_Cd," & _
'                "Tax_Cd,Aca,Start_Date,Rata,Allow_Aca,Allow_Pera,Allow_Pagibig,Allow_Life,Allow_Retire,Allow_Insurance," & _
'                "Allow_WithTax,Allow_Rata,Allow_medicare,Allow_Bonus,Allow_Cash,Allow_Cloth,Allow_Sick,Allow_Vac,Allow_Sss," & _
'                "Allow_Overtime,Apply_Holy_Rate,Apply_Night_Rate,Allow_Vac_Deduct,Emp_Status,Allow_Req_Hrs,Allow_Reg_Timein," & _
'                "Rate_Year,Apply_Holiday,Bday,Male,Date_Resign,Acct_No,Civil_Cd,DateDismissed,DateSuspended,Datehold,Bank_Code," & _
'                "Bank_Type,Allow_Cola,FixedTax,FixedPagibig_Emp,FixedPagibig_Emr,FixedHealth_Emp,FixedHealth_Emr,FixedSSS_Emp," & _
'                "FixedSSS_Emr,Ecard,Rc_Cd,MealALlow,ALlow_UnionDues,Fir,Pin,SUpervisorCd,EmailPwd,Confidential,Nickname,Date_Retired," & _
'                "Prov_Address,Skills,Self_Trainings,BirthPlace,Height,weight,SpouseName,ChildrenNo,ReligionCd,DialectCd,LanguageCd," & _
'                "BloodType,CountryCd,EmergencyCOntactPerson,CitizenCd,EmergencyContactNo,Req_Hrs_Day,OtherInfo,Spouse_Lname," & _
'                "Spouse_Fname,Spouse_Mname,Spouse_Occupation,Spouse_Emr,Spouse_Bus_Addr,Spouse_Tel,Father_Lname,Father_Fname," & _
'                "Father_Mname,Mother_Lname,Mother_Fname,Mother_Mname,PhicNo,DivCd,DeptCd,SectionCd,UnitCd,EmploymentType," & _
'                "Approving,Noting,DateRegularized,Rehired,Old_Id,BapEnrolled,City,DistingMark,EmergencyAddress," & _
'                "EmergencyEmail,EmergencyRelation,EyeColor,FatherAddress,FatherAlive,FatherBday,FatherContact,FatherDeathCause," & _
'                "FatherOcc,Frequency,FunctionTruncated,GracePeriod,HairColor,MacOprtd,MaxOtAmount,MinOtHours,MobileNo," & _
'                "MotherAddress,MotherAlive,MotherBday,MotherContact,MotherDeathCause,MotherOcc,ProvCd,RegionCd,ResCertDateIssued," & _
'                "ResCertPlaceIssued,Spouse_Prov,SpouseAddress,SpouseProvAddress,Zip) " & _
'                "select Emp_Cd,BarcodeId,Emp_Fname,Emp_Mname,Emp_Lname,Pos_Cd,Rate_Day,Emp_Address,Emp_Tel," & _
'                "Emp_Email,Res_Cert,Pera,Rate_Month,Sss_No,Gsis_No,Pagibig_No,Tin,User_Id,Pay_Cd,Grade_Cd,Agency_Cd," & _
'                "Tax_Cd,Aca,Start_Date,Rata,Allow_Aca,Allow_Pera,Allow_Pagibig,Allow_Life,Allow_Retire,Allow_Insurance," & _
'                "Allow_WithTax,Allow_Rata,Allow_medicare,Allow_Bonus,Allow_Cash,Allow_Cloth,Allow_Sick,Allow_Vac,Allow_Sss," & _
'                "Allow_Overtime,Apply_Holy_Rate,Apply_Night_Rate,Allow_Vac_Deduct,Emp_Status,Allow_Req_Hrs,Allow_Reg_Timein," & _
'                "Rate_Year,Apply_Holiday,Bday,Male,Date_Resign,Acct_No,Civil_Cd,DateDismissed,DateSuspended,Datehold,Bank_Code," & _
'                "Bank_Type,Allow_Cola,FixedTax,FixedPagibig_Emp,FixedPagibig_Emr,FixedHealth_Emp,FixedHealth_Emr,FixedSSS_Emp," & _
'                "FixedSSS_Emr,Ecard,Rc_Cd,MealALlow,ALlow_UnionDues,Fir,Pin,SUpervisorCd,EmailPwd,Confidential,Nickname,Date_Retired," & _
'                "Prov_Address,Skills,Self_Trainings,BirthPlace,Height,weight,SpouseName,ChildrenNo,ReligionCd,DialectCd,LanguageCd," & _
'                "BloodType,CountryCd,EmergencyCOntactPerson,CitizenCd,EmergencyContactNo,Req_Hrs_Day,OtherInfo,Spouse_Lname," & _
'                "Spouse_Fname,Spouse_Mname,Spouse_Occupation,Spouse_Emr,Spouse_Bus_Addr,Spouse_Tel,Father_Lname,Father_Fname," & _
'                "Father_Mname,Mother_Lname,Mother_Fname,Mother_Mname,PhicNo,DivCd,DeptCd,SectionCd,UnitCd,EmploymentType," & _
'                "Approving,Noting,DateRegularized,Rehired,Old_Id,BapEnrolled,City,DistingMark,EmergencyAddress," & _
'                "EmergencyEmail,EmergencyRelation,EyeColor,FatherAddress,FatherAlive,FatherBday,FatherContact,FatherDeathCause," & _
'                "FatherOcc,Frequency,FunctionTruncated,GracePeriod,HairColor,MacOprtd,MaxOtAmount,MinOtHours,MobileNo," & _
'                "MotherAddress,MotherAlive,MotherBday,MotherContact,MotherDeathCause,MotherOcc,ProvCd,RegionCd,ResCertDateIssued," & _
'                "ResCertPlaceIssued,Spouse_Prov,SpouseAddress,SpouseProvAddress,Zip from import_emp_master " & _
'                "where Ecard='new'"
'            cm.ExecuteNonQuery()


'            ' ==================================================================================================================
'            ' Create Leave ledger to the Py Emp Ledger leave Code (VL,SL)

'            'cm.CommandText = "select py_emp_master.Emp_Cd,py_emp_master.Emp_Status as Py_Status, " & _
'            '    "import_emp_master.Emp_status as Imp_Status, " & _
'            '    "import_emp_master.Date_Resign " & _
'            '    "from py_emp_master,import_emp_master where py_emp_master.emp_Cd=import_emp_master.emp_cd " & _
'            '    "and py_emp_master.emp_status<>import_emp_master.emp_status and import_emp_master.Emp_Status='Regular'"
'            'rs = cm.ExecuteReader
'            'If rs.Read Then

'            '    If rs("Imp_Status") = "Regular" And rs("Imp_Status") <> rs("Py_Status") Then
'            '        cmA.CommandText = "select Emp_Cd from py_emp_leave where Emp_Cd ='" & rs("Emp_Cd") & "' and Leave_Cd = 'VL'"
'            '        rsA = cmA.ExecuteReader
'            '        If rsA.Read Then
'            '            cmB.CommandText = "update py_emp_leave set Credit='" & vVL_MaxCredit & "', " & _
'            '                "Balance = '" & vVL_MaxCredit & "', LastUpdate ='" & Format(Now(), "yyyy/MM/dd 00:00:00") & "' " & _
'            '                "Where Emp_Cd='" & rs("Emp_Cd") & "' and Leave_Cd ='VL' "
'            '            cmB.ExecuteNonQuery()
'            '        Else
'            '            cmB.CommandText = "insert into py_emp_leave (Emp_Cd, Leave_Cd, Credit, Balance, LastUpdate) values (" & _
'            '                "'" & rs("Emp_Cd") & "', 'VL', '" & vVL_MaxCredit & "', '" & vVL_MaxCredit & "', " & _
'            '                "'" & Format(Now(), "yyyy/MM/dd 00:00:00") & "')"
'            '            cmB.ExecuteNonQuery()
'            '        End If
'            '        rsA.Close()

'            '        cmA.CommandText = "select Emp_Cd from py_emp_leave where Emp_Cd ='" & rs("Emp_Cd") & "' and Leave_Cd = 'SL'"
'            '        rsA = cmA.ExecuteReader
'            '        If rsA.Read Then
'            '            cmB.CommandText = "update py_emp_leave set Credit='" & vSL_MaxCredit & "', " & _
'            '                "Balance = '" & vSL_MaxCredit & "', LastUpdate ='" & Format(Now(), "yyyy/MM/dd 00:00:00") & "' " & _
'            '                "Where Emp_Cd='" & rs("Emp_Cd") & "' and Leave_Cd ='SL' "
'            '            cmB.ExecuteNonQuery()
'            '        Else
'            '            cmB.CommandText = "insert into py_emp_leave (emp_Cd, Leave_Cd, Credit, Balance, LastUpdate) values (" & _
'            '                "'" & rs("Emp_Cd") & "', 'SL', '" & vSL_MaxCredit & "', '" & vSL_MaxCredit & "', " & _
'            '                "'" & Format(Now(), "yyyy/MM/dd 00:00:00") & "')"
'            '            cmB.ExecuteNonQuery()
'            '        End If
'            '        rsA.Close()
'            '    End If
'            'End If
'            'rs.Close()

'            ' ==================================================================================================================
'            ' Check other reference if exist. if not insert new record code and descr

'            cm.CommandText = "select distinct Rc_Cd from import_emp_master where not exists " & _
'                "(select Rc_Cd from rc where rc.Rc_Cd=import_emp_master.Rc_Cd)"
'            rs = cm.ExecuteReader
'            Do While rs.Read
'                cmB.CommandText = "insert into rc (Rc_Cd, Descr) values ('" & rs("Rc_Cd") & "', '" & rs("Rc_Cd") & "')"
'                cmB.ExecuteNonQuery()
'                vMsgLog += "New Country code " & rs("Rc_Cd") & "  has been added to the reference. " & vbCrLf
'            Loop
'            rs.Close()

'            cm.CommandText = "select distinct Agency_Cd from import_emp_master where not exists " & _
'                "(select AgencyCd from agency where AgencyCd=Agency_Cd)"
'            rs = cm.ExecuteReader
'            Do While rs.Read
'                cmB.CommandText = "insert into agency (AgencyCd, AgencyName) values ('" & rs("Agency_Cd") & "', '" & rs("Agency_Cd") & "')"
'                cmB.ExecuteNonQuery()
'                vMsgLog += "New Call Site code " & rs("Agency_Cd") & " has been added to the reference. " & vbCrLf
'            Loop

'            rs.Close()

'            cm.CommandText = "select distinct DivCd from import_emp_master where not exists " & _
'                "(select Div_Cd from hr_div_ref where Div_Cd=DivCd)"
'            rs = cm.ExecuteReader
'            Do While rs.Read
'                cmB.CommandText = "insert into hr_div_ref (Div_Cd, Descr) values ('" & rs("DivCd") & "', '" & rs("DivCd") & "')"
'                cmB.ExecuteNonQuery()
'                vMsgLog += "New Location code " & rs("DivCd") & " has been added to the reference. " & vbCrLf
'            Loop
'            rs.Close()

'            cm.CommandText = "select distinct DeptCd from import_emp_master where not exists " & _
'                "(select Dept_Cd from hr_dept_ref where Dept_Cd=DeptCd)"
'            rs = cm.ExecuteReader
'            Do While rs.Read
'                cmB.CommandText = "insert into hr_dept_ref (Dept_Cd, Descr) values ('" & rs("DeptCd") & "', '" & rs("DeptCd") & "')"
'                cmB.ExecuteNonQuery()
'                vMsgLog += "New Department code " & rs("DeptCd") & " has been added to the reference. " & vbCrLf
'            Loop
'            rs.Close()

'            cm.CommandText = "select distinct SectionCd from import_emp_master where not exists " & _
'                "(select Section_Cd from hr_section_ref where Section_Cd=SectionCd)"
'            rs = cm.ExecuteReader
'            Do While rs.Read
'                cmB.CommandText = "insert into hr_section_ref (Section_Cd, Descr) values ('" & rs("SectionCd") & "', '" & rs("SectionCd") & "')"
'                cmB.ExecuteNonQuery()
'                vMsgLog += "New Team # code " & rs("SectionCd") & " has been added to the reference. " & vbCrLf
'            Loop
'            rs.Close()

'            cm.CommandText = "select distinct UnitCd from import_emp_master where not exists " & _
'                "(select Unit_Cd from hr_unit_ref where Unit_Cd=UnitCd)"
'            rs = cm.ExecuteReader
'            Do While rs.Read
'                cmB.CommandText = "insert into hr_unit_ref (Unit_Cd, Descr) values ('" & rs("UnitCd") & "', '" & rs("UnitCd") & "')"
'                cmB.ExecuteNonQuery()
'                vMsgLog += "New Product # code " & rs("UnitCd") & " has been added to the reference.  " & vbCrLf
'            Loop
'            rs.Close()

'            cm.CommandText = "select distinct Emp_Status from import_emp_master where not exists " & _
'                "(select Status_Code from py_employee_stat where Status_Code=Emp_Status)"
'            rs = cm.ExecuteReader
'            Do While rs.Read
'                cmB.CommandText = "insert into py_employee_stat (Status_Code, Descr) values ('" & rs("Emp_Status") & "', '" & rs("Emp_Status") & "' )"
'                cmB.ExecuteNonQuery()
'                vMsgLog += "New Employment Status code " & rs("Emp_Status") & " has been added to the reference. " & vbCrLf
'            Loop
'            rs.Close()
'            'write to log file
'            IO.File.WriteAllText(Server.MapPath(".") & "\downloads\" & Session.SessionID & "-201_import.txt", vMsgLog)


'            ' '' ==================================================================================================================
'            ' '' Create movement of the Salary or Salary ledger

'            'cm.CommandText = "select py_emp_master.Emp_Cd," & _
'            '    "py_emp_master.Rate_Month," & _
'            '    "py_emp_master.Agency_Cd," & _
'            '    "py_emp_master.DeptCd, " & _
'            '    "py_emp_master.DivCd," & _
'            '    "py_emp_master.SectionCd," & _
'            '    "py_emp_master.Pos_Cd," & _
'            '    "py_emp_master.MealAllow," & _
'            '    "py_emp_master.UNitCd,  " & _
'            '    "py_emp_master.Rc_Cd," & _
'            '    "py_emp_master.Aca," & _
'            '    "py_emp_master.Rata," & _
'            '    "py_emp_master.Pera," & _
'            '    "py_emp_master.Tax_Cd, " & _
'            '    "py_emp_master.Emp_Status," & _
'            '    "py_emp_master.EmploymentType," & _
'            '    "py_emp_master.Grade_Cd," & _
'            '    "import_emp_master.EffectivityDate as ToDate, " & _
'            '    "py_emp_master.EffectivityDate as FromDate, " & _
'            '    "import_emp_master.Rate_Month " & _
'            '    "from py_emp_master,import_emp_master where py_emp_master.emp_Cd=import_emp_master.emp_cd  " & _
'            '    "and py_emp_master.Rate_Month<>import_emp_master.Rate_Month and import_emp_master.Rate_Month <> 0 and " & _
'            '    "import_emp_master.Ecard in ('modified','new')"

'            'rs = cm.ExecuteReader
'            'Do While rs.Read
'            '    If IsDBNull(rs("FromDate")) Then
'            '        vFromDate = CDate(Now.Year & "/1/1")
'            '    Else
'            '        vFromDate = rs("FromDate")
'            '    End If
'            '    If IsDBNull(rs("ToDate")) Then
'            '        vToDate = Now
'            '    Else
'            '        vToDate = rs("ToDate")
'            '    End If

'            '    cmA.CommandText = "insert into hr_emp_career_movement (Emp_Cd, From_Date, Remarks, Salary_Amt, To_Date, " & _
'            '        "Office_Cd, Dept_Cd, Div_Cd, Section_Cd, Position_Cd, MealAllow, Unit_Cd, Rc_Cd, Aca, Rata, Pera, TaxCd, Emp_Status, " & _
'            '        "EmploymentType, RecommendedBy, DateRecommended, PreparedBy, DatePrepared, ApprovedBy, DateApproved, Nature, GradeCd ) " & _
'            '        "values ('" & rs("Emp_Cd") & "','" & Format(vFromDate, "yyyy/MM/dd") & "', 'Uploaded', '" & rs("Rate_Month") & "', '" & _
'            '        Format(vToDate, "yyyy/MM/dd") & "'," & _
'            '        "'" & rs("Agency_Cd") & "', '" & rs("DeptCd") & "', '" & rs("DivCd") & "', '" & rs("SectionCd") & "', '" & rs("Pos_Cd") & "', "
'            '    If IsDBNull(rs("MealAllow")) Then
'            '        cmA.CommandText += "0"
'            '    Else
'            '        cmA.CommandText &= Val(rs("MealAllow"))
'            '    End If
'            '    cmA.CommandText += ", '" & rs("UNitCd") & "', '" & rs("Rc_Cd") & "',"
'            '    If IsDBNull(rs("Aca")) Then
'            '        cmA.CommandText += "0,"
'            '    Else
'            '        cmA.CommandText &= Val(rs("Aca")) & ","
'            '    End If
'            '    If IsDBNull(rs("Rata")) Then
'            '        cmA.CommandText += "0,"
'            '    Else
'            '        cmA.CommandText &= Val(rs("Rata")) & ","
'            '    End If
'            '    If IsDBNull(rs("Pera")) Then
'            '        cmA.CommandText += "0,"
'            '    Else
'            '        cmA.CommandText &= Val(rs("Pera")) & ","
'            '    End If

'            '    cmA.CommandText += "'" & rs("Tax_Cd") & "', '" & rs("Emp_Status") & "', '" & rs("EmploymentType") & "', 'SYSTEM', '" & _
'            '        Format(Now(), "yyyy/MM/dd HH:mm") & "', 'SYSTEM', " & _
'            '        "'" & Format(Now(), "yyyy/MM/dd HH:mm") & "','SYSTEM', '" & _
'            '        Format(Now(), "yyyy/MM/dd HH:mm") & "', 'Change of Salary', '" & rs("Grade_Cd") & "')"

'            '    cmA.ExecuteNonQuery()
'            'Loop
'            'rs.Close()

'            ' ==================================================================================================================
'            ' Update Rate Year, Rate Month, Rate Day

'            cm.CommandText = "select TableKey FROM _db where TableKey is not null"
'            rs = cm.ExecuteReader
'            'vData = "update import_emp_master," & vTable & " set "
'            vData = "update " & vTable & " set "
'            Do While rs.Read
'                vData += vTable & "." & rs("TableKey") & "=(select top 1 import_emp_master." & rs("TableKey") & _
'                    " from import_emp_master where import_emp_master.Emp_Cd=" & vTable & ".Emp_Cd) , "
'            Loop
'            vData = vData.Substring(0, vData.Length - 2) & " where " & vTable & _
'                ".Emp_Cd in (select import_emp_master.Emp_Cd from import_emp_master where " & _
'                "import_emp_master.Ecard='modified' and import_emp_master.Rate_Month > 0)"

'            'first execution update only employee master with rate_month > 0
'            cmA.CommandText = vData
'            Try
'                cmA.ExecuteNonQuery()
'            Catch ex As System.Exception
'                Response.Write("Error in line 1596: " & cmA.CommandText & "<br/>")
'            End Try

'            'second execution update only employee master with rate_month = 0, remove rate_month field.
'            cmA.CommandText = vData.Replace("import_emp_master.Rate_Month > 0", "import_emp_master.Rate_Month = 0")

'            Try
'                cmA.ExecuteNonQuery()
'            Catch ex As System.Exception
'                Response.Write("Error in line 1605: " & cmA.CommandText & "<br/>")
'            End Try


'            'third execution, synchronize the rate/year and rate/day fields
'            cmA.CommandText = "update py_emp_master set Rate_Year = Rate_Month * 12, Rate_Day = Rate_Month / " & vDaysmonth
'            cmA.ExecuteNonQuery()
'            rs.Close()

'            ' ======================================================================================================
'            ' search each import master to check for incentive eligibility

'            'cm.CommandText = "select * from import_emp_master where Ecard <> 'new'"
'            'rs = cm.ExecuteReader
'            'Do While rs.Read
'            '    cmA.CommandText = "select * from hr_comp_ben where Recurring = 1 and " & _
'            '        "(Pos_Cd = '*' or Pos_Cd like '%" & rs("Pos_Cd") & "%') and " & _
'            '        "(Agency_Cd = '*' or Agency_Cd like '%" & rs("Agency_Cd") & "%') and " & _
'            '        "(Rc_Cd = '*' or Rc_Cd like '%" & rs("Rc_Cd") & "%') and " & _
'            '        "(Emp_Status = '*' or Emp_Status like '%" & rs("Emp_Status") & "%') "

'            '    rsA = cmA.ExecuteReader
'            '    Do While rsA.Read
'            '        cmB.CommandText = "delete from py_incentives_dtl where Incentive_Cd = '" & rsA("Incentive_Cd") & "' and " & _
'            '            "Emp_Cd='" & rs("Emp_Cd") & "' and Incentive_Amt = '" & rsA("Amount") & "' "
'            '        cmB.ExecuteNonQuery()

'            '        cmB.CommandText = "insert into py_incentives_dtl (Incentive_Cd, Incentive_Amt, Emp_Cd, Recurring, FreqCd) " & _
'            '           "values ('" & rsA("Incentive_Cd") & "', '" & rsA("Amount") & "', '" & rs("Emp_Cd") & "', " & _
'            '           "'" & rsA("Recurring") & "', '" & rsA("Freq_Cd") & "')"
'            '        cmB.ExecuteNonQuery()
'            '    Loop
'            '    rsA.Close()
'            'Loop
'            'rs.Close()

'            ' end search
'            ' ======================================================================================================

'            cm.CommandText = "delete from import_emp_master"
'            'cm.ExecuteNonQuery()

'            vScript = "winlog = window.open('downloads/" & Session.SessionID & _
'                "-201_import.txt','winlog','toolbar=no,resizable=yes,top=10,left=100,width=640,height=480'); winlog.focus();"
'            vScript += "alert('Records successfully validated and synchronized with the master table.');"
'        Catch ex As SqlClient.SqlException
'            vScript = "alert('Error occurred while trying to process the request. Error is: " & _
'                ex.Message.Replace("'", "").Replace(vbCrLf, "") & "');"
'        Finally
'            c.Close()
'            cm.Dispose()
'            cmA.Dispose()
'            cmB.Dispose()
'            DataRefresh()
'        End Try
'    End Sub

'    Protected Sub rdoFilter_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rdoFilter.SelectedIndexChanged
'        DataRefresh()
'    End Sub

'    Protected Sub tblTmpEmp_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tblTmpEmp.SelectedIndexChanged
'        Dim vTempTable As String = ""

'        Select Case rdoOption.SelectedIndex
'            Case 0, 1
'                vTempTable = rdoOption.Items(0).Value
'        End Select
'        Session("selected") = tblTmpEmp.SelectedRow.Cells(0).Text
'        If Session("temptable") = "" Then
'            Session("temptable") = vTempTable
'        End If
'        If Session("key") = "" Then
'            Session("key") = "Emp_Cd"
'        End If

'        If Session("xreftable") = "" Then
'            Dim c As New SqlClient.SqlConnection(connStr)
'            Dim cm As New SqlClient.SqlCommand("select TableName from _db where TempTable='" & vTempTable & "' limit 1", c)
'            Dim rs As SqlClient.SqlDataReader

'            Try
'                c.Open()
'                rs = cm.ExecuteReader
'                If rs.Read Then
'                    Session("xreftable") = rs("TableName")
'                End If
'                rs.Close()
'                c.Close()
'                c.Dispose()
'                cm.Dispose()
'            Catch ex As SqlClient.SqlException
'                vScript = "alert('An error has occurred while trying to retrieve the config table. Error is: " & _
'                    ex.Message.Replace("'", "").Replace(vbCrLf, "") & "');"
'                c.Dispose()
'                cm.Dispose()
'                Exit Sub
'            End Try
'        End If
'        vScript = "viewwin=window.open('importview.aspx','viewwin','top=0,left=100,width=800,height=600,scrollbars=yes,toolbar=no,resizable=yes');viewwin.focus();"
'    End Sub

'    Protected Sub cmdSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSearch.Click
'        DataRefresh()
'    End Sub

'    Protected Sub rdoOption_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles rdoOption.Init
'        rdoOption.Attributes.Add("click", "document.getElementById('divWait').style.visibility='visible';")
'    End Sub

'    Protected Sub rdoOption_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rdoOption.SelectedIndexChanged
'        divError.Visible = False
'        cmdview.Visible = False
'        Select Case rdoOption.SelectedValue
'            Case "import_emp_master", "wfh1"
'                pnlLoans.Visible = False
'                pnlProdPay.Visible = False
'                pnlOnetimeDed.Visible = False
'                pnlLogs.Visible = False
'                pnlwfhlogs.Visible = False
'                pnl201.Visible = True
'                cmdEmpTimeLog.Visible = False
'                cmdLoanConfirm.Visible = False
'                'Case "loans"
'                '    pnl201.Visible = False
'                '    pnlProdPay.Visible = False
'                '    pnlOnetimeDed.Visible = False
'                '    pnlLogs.Visible = False
'                '    pnlwfhlogs.Visible = False
'                '    pnlLoans.Visible = True
'                '    cmdEmpTimeLog.Visible = False
'                '    RefreshLoans()
'            Case "earnings"
'                pnl201.Visible = False
'                pnlLoans.Visible = False
'                pnlOnetimeDed.Visible = False
'                pnlLogs.Visible = False
'                pnlwfhlogs.Visible = False
'                pnlProdPay.Visible = True
'                cmdLoanConfirm.Visible = False
'                cmdEmpTimeLog.Visible = False
'                cmdview.Visible = True
'                RefreshEarnings()
'            Case "deductions"
'                pnl201.Visible = False
'                pnlLoans.Visible = False
'                pnlProdPay.Visible = False
'                pnlLogs.Visible = False
'                pnlwfhlogs.Visible = False
'                pnlOnetimeDed.Visible = True
'                cmdEmpTimeLog.Visible = False
'                cmdview.Visible = True
'                RefreshDeductions()
'            Case "attendance"
'                pnl201.Visible = False
'                pnlLoans.Visible = False
'                pnlProdPay.Visible = False
'                pnlOnetimeDed.Visible = False
'                pnlwfhlogs.Visible = False
'                pnlLogs.Visible = True
'                cmdEmpTimeLog.Visible = False
'                cmdLoanConfirm.Visible = False
'                'Case "wfhlogs", "wfhearnings"
'                '    pnl201.Visible = False
'                '    pnlLoans.Visible = False
'                '    pnlProdPay.Visible = False
'                '    pnlOnetimeDed.Visible = False
'                '    pnlLogs.Visible = False
'                '    pnlwfhlogs.Visible = True
'                '    cmdLoanConfirm.Visible = False
'                '    cmdEmpTimeLog.Visible = False
'        End Select
'        vScript = "document.getElementById('divWait').style.visibility='hidden';"
'    End Sub

'    'Protected Sub cmdRefreshProd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdRefreshProd.Click
'    '    Select Case rdoOption.SelectedValue
'    '        Case "PRODPAY"
'    '            RefreshProdPay()
'    '        Case "earnings"
'    '            RefreshEarnings()
'    '    End Select

'    'End Sub

'    Private Sub RefreshEarnings()
'        'If txtStartDate.Text.Trim = "" Then
'        '    vScript = "alert('Start Date should not be empty!');"
'        '    Exit Sub
'        'End If
'        'If txtEndDate.Text.Trim = "" Then
'        '    vScript = "alert('Ending Date should not be empty!');"
'        '    Exit Sub
'        'End If
'        'If txtStartDate.Text <> "" And Not IsDate(txtStartDate.Text) Then
'        '    vScript = "alert('Invalid date format in Starting cut off date. Please correct the error and try again.');"
'        '    Exit Sub
'        'End If
'        'If txtEndDate.Text <> "" And Not IsDate(txtEndDate.Text) Then
'        '    vScript = "alert('Invalid date format in Ending cut off date. Please correct the error and try again.');"
'        '    Exit Sub
'        'End If

'        Dim c As New SqlClient.SqlConnection(connStr)
'        Dim cm As New SqlClient.SqlCommand
'        Dim rs As SqlClient.SqlDataReader
'        Dim vClass As String = "odd"
'        Dim vCond As String = ""
'        Dim vStartDate As String = ""
'        Dim vEndDate As String = ""
'        Dim vTtlInc_Amt As Decimal = 0

'        Try
'            c.Open()
'        Catch ex As SqlClient.SqlException
'            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
'                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
'            c.Dispose()
'            cm.Dispose()
'            Exit Sub
'        End Try
'        cm.Connection = c

'        'refresh the list
'        vDetailProd = ""

'        'vCond = " where FromDate >='" & Format(CDate(txtStartDate.Text), "yyyy/MM/dd") & "' " & _
'        '        " and ToDate <='" & Format(CDate(txtEndDate.Text), "yyyy/MM/dd") & "' "

'        cm.CommandText = "select Emp_Cd,Incentive_Amt,(select Emp_Lname+', '+Emp_Fname from py_emp_master " & _
'            " where py_emp_master.Emp_Cd=import_py_incentives_dtl.Emp_Cd) as Emp_Name,FromDate,ToDate,Incentive_Cd from import_py_incentives_dtl "
'        'vCond

'        Try
'            rs = cm.ExecuteReader
'            Do While rs.Read
'                If Not IsDBNull(rs("FromDate")) Then
'                    vStartDate = Format(rs("FromDate"), "MM/dd/yyyy")
'                Else
'                    vStartDate = "&nbsp;"
'                End If
'                If Not IsDBNull(rs("ToDate")) Then
'                    vEndDate = Format(rs("ToDate"), "MM/dd/yyyy")
'                Else
'                    vEndDate = "&nbsp;"
'                End If

'                vDetailProd += "<tr class='" & vClass & "'>" & _
'                    "<td class='labelC'>" & rs("Emp_Cd") & "</td>" & _
'                    "<td class='labelL' style='border-left: solid 1px #8b8b8a;'>&nbsp;" & rs("Emp_Name") & "</td>" & _
'                    "<td class='labelL' style='border-left: solid 1px #8b8b8a;'>&nbsp;" & rs("Incentive_Cd") & "</td>" & _
'                    "<td class='labelR' style='border-left: solid 1px #8b8b8a;'>" & Format(rs("Incentive_Amt"), "##,##0.00") & "&nbsp;</td>" & _
'                    "<td class='labelC' style='border-left: solid 1px #8b8b8a;'>" & vStartDate & "</td>" & _
'                    "<td class='labelC' style='border-left: solid 1px #8b8b8a;'>" & vEndDate & "</td></tr>"

'                vTtlInc_Amt += rs("Incentive_Amt")
'                If vClass = "odd" Then
'                    vClass = "even"
'                Else
'                    vClass = "odd"
'                End If
'            Loop
'            rs.Close()

'            vDetailProd += "<tr><td colspan='3' style='padding:5px;' class='labelR'><b>Total :<b />&nbsp;" & _
'                "</td><td class='labelR'><b>" & Format(vTtlInc_Amt, "##,##0.00") & _
'                "<b />&nbsp;</td><td class='labelR' colspan='3' ></td></tr>"

'        Catch ex As SqlClient.SqlException
'            vScript = "alert('Error occurred while retrieving the Incentives. Error is: " & _
'                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
'        Finally
'            c.Close()
'            cm.Dispose()
'            c.Dispose()
'        End Try
'        'DownloadCSVFiles()
'    End Sub

'    ''Private Sub RefreshProdPay()
'    ''    If txtStartDate.Text <> "" And Not IsDate(txtStartDate.Text) Then
'    ''        vScript = "alert('Invalid date format in Starting cut off date. Please correct the error and try again.');"
'    ''        Exit Sub
'    ''    End If
'    ''    If txtEndDate.Text <> "" And Not IsDate(txtEndDate.Text) Then
'    ''        vScript = "alert('Invalid date format in Ending cut off date. Please correct the error and try again.');"
'    ''        Exit Sub
'    ''    End If

'    ''    Dim c As New SqlClient.SqlConnection(connStr)
'    ''    Dim cm As New SqlClient.SqlCommand
'    ''    Dim rs As SqlClient.SqlDataReader
'    ''    Dim vClass As String = "odd"
'    ''    Dim vCond As String = ""
'    ''    Dim vStartDate As String = ""
'    ''    Dim vEndDate As String = ""

'    ''    Try
'    ''        c.Open()
'    ''    Catch ex As SqlClient.SqlException
'    ''        vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
'    ''            ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
'    ''        c.Dispose()
'    ''        cm.Dispose()
'    ''        Exit Sub
'    ''    End Try
'    ''    cm.Connection = c

'    ''    'refresh the list
'    ''    vDetailProd = ""
'    ''    If txtStartDate.Text <> "" Then
'    ''        vCond = " and FromDate >='" & Format(CDate(txtStartDate.Text), "yyyy/MM/dd") & "' "
'    ''    End If
'    ''    If txtEndDate.Text <> "" Then
'    ''        vCond += " and ToDate <='" & Format(CDate(txtEndDate.Text), "yyyy/MM/dd") & "' "
'    ''    End If
'    ''    cm.CommandText = "select Emp_Cd,Incentive_Amt,(select concat(Emp_Lname,', ',Emp_Fname) from py_emp_master " & _
'    ''        " where py_emp_master.Emp_Cd=py_incentives_dtl.Emp_Cd) as Emp_Name,FromDate,ToDate,Incentive_Cd from py_incentives_dtl " & _
'    ''        " where Incentive_Cd='PRODPAY' " & vCond
'    ''    Try
'    ''        rs = cm.ExecuteReader
'    ''        Do While rs.Read
'    ''            If Not IsDBNull(rs("FromDate")) Then
'    ''                vStartDate = Format(rs("FromDate"), "MM/dd/yyyy")
'    ''            Else
'    ''                vStartDate = "&nbsp;"
'    ''            End If
'    ''            If Not IsDBNull(rs("ToDate")) Then
'    ''                vEndDate = Format(rs("ToDate"), "MM/dd/yyyy")
'    ''            Else
'    ''                vEndDate = "&nbsp;"
'    ''            End If

'    ''            vDetailProd += "<tr class='" & vClass & "'>" & _
'    ''                "<td class='labelC'>" & rs("Emp_Cd") & "</td>" & _
'    ''                "<td class='labelL' style='border-left: solid 1px #8b8b8a;'>" & rs("Emp_Name") & "</td>" & _
'    ''                "<td class='labelL' style='border-left: solid 1px #8b8b8a;'>" & rs("Incentive_Cd") & "</td>" & _
'    ''                "<td class='labelR' style='border-left: solid 1px #8b8b8a;'>" & Format(rs("Incentive_Amt"), "##,##0.00") & "</td>" & _
'    ''                "<td class='labelC' style='border-left: solid 1px #8b8b8a;'>" & vStartDate & "</td>" & _
'    ''                "<td class='labelC' style='border-left: solid 1px #8b8b8a;'>" & vEndDate & "</td></tr>"
'    ''        Loop
'    ''        rs.Close()
'    ''    Catch ex As SqlClient.SqlException
'    ''        vScript = "alert('Error occurred while retrieving the Incentives. Error is: " & _
'    ''            ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
'    ''    Finally
'    ''        c.Close()
'    ''        cm.Dispose()
'    ''        c.Dispose()
'    ''    End Try
'    ''    DownloadCSVFiles()
'    ''End Sub

'    Protected Sub cmdRefreshLogs_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdRefreshLogs.Click
'        RefreshLogs()
'    End Sub

'    Private Sub RefreshWFHLogs()
'        If txtFromLogs.Text <> "" And Not IsDate(txtFromLogs.Text) Then
'            vScript = "alert('Invalid date format in Starting date. Please correct the error and try again.');"
'            Exit Sub
'        End If
'        If txtToLogs.Text <> "" And Not IsDate(txtToLogs.Text) Then
'            vScript = "alert('Invalid date format in Ending date. Please correct the error and try again.');"
'            Exit Sub
'        End If

'        Dim c As New SqlClient.SqlConnection(connStr)
'        Dim cm As New SqlClient.SqlCommand
'        Dim rs As SqlClient.SqlDataReader
'        Dim vClass As String = "odd"
'        Dim vCond As String = ""
'        Dim vStartDate As String = ""
'        Dim vEndDate As String = ""
'        Dim vFilter As String = ""

'        Try
'            c.Open()
'        Catch ex As SqlClient.SqlException
'            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
'                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
'            c.Dispose()
'            cm.Dispose()
'            Exit Sub
'        End Try
'        cm.Connection = c

'        'refresh the list
'        vDetailProd = ""
'        'If txtStartDate.Text <> "" Then
'        '    vCond = " and TranDate >='" & Format(CDate(txtStartDate.Text), "yyyy/MM/dd") & "' "
'        'End If
'        'If txtEndDate.Text <> "" Then
'        '    vCond += " and TranDate <='" & Format(CDate(txtEndDate.Text), "yyyy/MM/dd") & "' "
'        'End If

'        If rdoOption.Text = "wfhlogs" Then
'            vFilter = "TranCd like 'WFH_171%' "
'        Else
'            vFilter = "TranCd like 'BASIC%' "
'        End If

'        cm.CommandText = "select Emp_Cd,TranDate,TranCd,(select concat(Emp_Lname,', ',Emp_Fname) from py_emp_master " & _
'            " where py_emp_master.Emp_Cd=import_emp_time_log.Emp_Cd) as Emp_Name,Hrs_Rendered,AmtConv,Reason " & _
'            "from import_emp_time_log where " & vFilter & _
'            vCond

'        Try
'            rs = cm.ExecuteReader
'            Do While rs.Read
'                vDetail += "<tr class='" & vClass & "'>" & _
'                    "<td class='labelC' style='border-left: solid 1px #8b8b8a;'>" & rs("Emp_Cd") & "</td>" & _
'                    "<td class='labelL' style='border-left: solid 1px #8b8b8a;'>&nbsp;" & rs("Emp_Name") & "</td>" & _
'                    "<td class='labelC' style='border-left: solid 1px #8b8b8a;'>" & Format(rs("TranDate"), "MM/dd/yyyy") & "</td>" & _
'                    "<td class='labelC' style='border-left: solid 1px #8b8b8a;'>" & rs("TranCd") & "</td>" & _
'                    "<td class='labelR' style='border-left: solid 1px #8b8b8a;'>" & Format(rs("AmtConv"), "###,##0.00") & "&nbsp;</td>" & _
'                    "<td class='labelL' style='border-left: solid 1px #8b8b8a;'>&nbsp;" & rs("Reason") & "</td></tr>"
'            Loop
'            rs.Close()
'        Catch ex As SqlClient.SqlException
'            vScript = "alert('Error occurred while retrieving the Incentives. Error is: " & _
'                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
'        Finally
'            c.Close()
'            cm.Dispose()
'            c.Dispose()
'        End Try

'    End Sub

'    Private Sub RefreshLogs()
'        If txtFromLogs.Text <> "" And Not IsDate(txtFromLogs.Text) Then
'            vScript = "alert('Invalid date format in Starting date. Please correct the error and try again.');"
'            Exit Sub
'        End If
'        If txtToLogs.Text <> "" And Not IsDate(txtToLogs.Text) Then
'            vScript = "alert('Invalid date format in Ending date. Please correct the error and try again.');"
'            Exit Sub
'        End If

'        Dim c As New SqlClient.SqlConnection(connStr)
'        Dim cm As New SqlClient.SqlCommand
'        Dim rs As SqlClient.SqlDataReader
'        Dim vClass As String = "odd"
'        Dim vCond As String = ""
'        Dim vStartDate As String = ""
'        Dim vEndDate As String = ""

'        Try
'            c.Open()
'        Catch ex As SqlClient.SqlException
'            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
'                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
'            c.Dispose()
'            cm.Dispose()
'            Exit Sub
'        End Try
'        cm.Connection = c

'        'refresh the list
'        vDetailProd = ""
'        'If txtStartDate.Text <> "" Then
'        '    vCond = " and TranDate >='" & Format(CDate(txtStartDate.Text), "yyyy/MM/dd") & "' "
'        'End If
'        'If txtEndDate.Text <> "" Then
'        '    vCond += " and TranDate <='" & Format(CDate(txtEndDate.Text), "yyyy/MM/dd") & "' "
'        'End If

'        cm.CommandText = "select Emp_Cd, Tran_Date, Time_In, Time_Out, Time_OutDate, " & _
'            "(select Emp_Lname from py_emp_master where py_emp_master.Emp_Cd=import_emp_time_log.Emp_Cd) as Lname, " & _
'            "(select Emp_Fname from py_emp_master where py_emp_master.Emp_Cd=import_emp_time_log.Emp_Cd) as Fname, " & _
'            "Reason " & _
'            "from import_emp_time_log "

'        Try
'            rs = cm.ExecuteReader
'            Do While rs.Read
'                vDetail += "<tr class='" & vClass & "'>" & _
'                    "<td class='labelC'>" & rs("Emp_Cd") & "</td>" & _
'                    "<td class='labelL' style='border-left: solid 1px #8b8b8a;'>&nbsp;" & rs("Lname") & ", " & rs("Fname") & "</td>" & _
'                    "<td class='labelC' style='border-left: solid 1px #8b8b8a;'>" & Format(rs("Tran_Date"), "MM/dd/yyyy") & "</td>" & _
'                    "<td class='labelC' style='border-left: solid 1px #8b8b8a;'>" & rs("Time_In") & "</td>" & _
'                    "<td class='labelC' style='border-left: solid 1px #8b8b8a;'>" & rs("Time_Out") & "</td>" & _
'                    "<td class='labelC' style='border-left: solid 1px #8b8b8a;'>" & Format(rs("Time_OutDate"), "MM/dd/yyyy") & "</td>" & _
'                    "<td class='labelL' style='border-left: solid 1px #8b8b8a;'>&nbsp;" & rs("Reason") & "</td></tr>"
'            Loop
'            rs.Close()
'        Catch ex As SqlClient.SqlException
'            vScript = "alert('Error occurred while retrieving the Incentives. Error is: " & _
'                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
'        Finally
'            c.Close()
'            cm.Dispose()
'            c.Dispose()
'        End Try

'    End Sub

'    Protected Sub cmdwfhRefresh_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdwfhRefresh.Click
'        RefreshWFHLogs()
'    End Sub

'    Protected Sub cmdLoanConfirm_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdLoanConfirm.Click

'        Select Case rdoOption.SelectedValue
'            Case "deductions"
'                Confirm_Ontime_Deductions()
'            Case "earnings"
'                Confirm_Ontime_Earnings()
'        End Select

'    End Sub

'    Private Sub Confirm_Ontime_Deductions()
'        Dim c As New SqlClient.SqlConnection(connStr)
'        Dim cm As New SqlClient.SqlCommand
'        Dim rs As SqlClient.SqlDataReader
'        Dim vBatchNo As Integer = 0

'        Try
'            c.Open()
'        Catch ex As SqlClient.SqlException
'            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
'                ex.Message.Replace("'", "").Replace(vbCrLf, "") & "');"
'            c.Dispose()
'            cm.Dispose()
'            Exit Sub
'        End Try

'        cm.Connection = c

'        Try
'            cm.CommandText = "select MAX(BatchNo) as LastCount from py_incentives_dtl "
'            rs = cm.ExecuteReader
'            If rs.Read Then
'                If IsDBNull(rs("LastCount")) Then
'                    vBatchNo = 1
'                Else
'                    vBatchNo = rs("LastCount") + 1
'                End If
'            End If
'            rs.Close()

'            cm.CommandText = "select distinct(BatchNo) from py_incentives_dtl where BatchNo='" & vBatchNo & "'"
'            rs = cm.ExecuteReader
'            If rs.Read Then
'                If Not IsDBNull(rs("BatchNo")) Then
'                    vBatchNo = vBatchNo + 1
'                End If
'            End If
'            rs.Close()

'            cm.CommandText = "delete from py_loan_hdr where exists " & _
'                "(select Emp_Cd from import_loan_hdr where import_loan_hdr.Emp_Cd=py_loan_hdr.Emp_Cd and " & _
'                "import_loan_hdr.Loan_Cd=py_loan_hdr.Loan_Cd " & _
'                "and import_loan_hdr.Loan_Date=py_loan_hdr.Loan_Date " & _
'                "and import_loan_hdr.Start_Date=py_loan_hdr.Start_Date " & _
'                "and import_loan_hdr.Amt_Loan=py_loan_hdr.Amt_Loan) "
'            cm.ExecuteNonQuery()

'            cm.CommandText = "insert into py_loan_hdr (Emp_Cd, Loan_Cd, Amt_Bal, Amt_Loan, Amt_Paid, Loan_Date, " & _
'                "Start_Date, Int_Rate, Month_to_Pay, Active, ProdDescr, Monthly, MonthlyAmort, " & _
'                "Recurring, End_Date, PaymentsMade, FreqCd, DateUploaded, UploadedBy, BatchNo) " & _
'                "select Emp_Cd, Loan_Cd, Amt_Bal, Amt_Loan, Amt_Paid, Loan_Date, Start_Date,  " & _
'                "Int_Rate, Month_to_Pay, Active, ProdDescr, Monthly, MonthlyAmort, " & _
'                "Recurring, End_Date, PaymentsMade, FreqCd, '" & Format(Now, "yyyy/MM/dd") & _
'                "', '" & Session("uid") & "', '" & vBatchNo & "' from import_loan_hdr"
'            cm.ExecuteNonQuery()

'            cm.CommandText = "delete from import_loan_hdr"
'            cm.ExecuteNonQuery()
'            vScript = "alert('Records successfully validated and synchronized.');"
'            RefreshLoans()
'            'CreateCSVFile()
'            'DownloadCSVFiles()
'        Catch ex As SqlClient.SqlException
'            vScript = "alert('An error has occurred while trying to retrieve the config table. Error is: " & _
'                ex.Message.Replace("'", "").Replace(vbCrLf, "") & "');"
'        Finally
'            c.Close()
'            cm.Dispose()
'            c.Dispose()
'        End Try
'    End Sub

'    Private Sub Confirm_Ontime_Earnings()
'        Dim c As New SqlClient.SqlConnection(connStr)
'        Dim cm As New SqlClient.SqlCommand
'        Dim rs As SqlClient.SqlDataReader
'        Dim vBatchNo As Integer

'        Try
'            c.Open()
'        Catch ex As SqlClient.SqlException
'            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
'                ex.Message.Replace("'", "").Replace(vbCrLf, "") & "');"
'            c.Dispose()
'            cm.Dispose()
'            Exit Sub
'        End Try

'        cm.Connection = c

'        Try
'            cm.CommandText = "select MAX(batchno) as LastCount from py_incentives_dtl "
'            rs = cm.ExecuteReader
'            If rs.Read Then
'                If IsDBNull(rs("LastCount")) Then
'                    vBatchNo = 1
'                Else
'                    vBatchNo = rs("LastCount") + 1
'                End If
'            End If
'            rs.Close()

'            cm.CommandText = "select distinct(BatchNo) from py_incentives_dtl where BatchNo='" & vBatchNo & "'"
'            rs = cm.ExecuteReader
'            If rs.Read Then
'                If Not IsDBNull(rs("BatchNo")) Then
'                    vBatchNo = vBatchNo + 1
'                End If
'            End If
'            rs.Close()

'            cm.CommandText = "delete from py_incentives_dtl where exists " & _
'                "(select Emp_Cd from import_py_incentives_dtl where import_py_incentives_dtl.Emp_Cd=py_incentives_dtl.Emp_Cd " & _
'                "and import_py_incentives_dtl.Incentive_Cd=py_incentives_dtl.Incentive_Cd " & _
'                "and import_py_incentives_dtl.Incentive_Amt=py_incentives_dtl.Incentive_Amt " & _
'                "and import_py_incentives_dtl.FromDate=py_incentives_dtl.FromDate " & _
'                "and import_py_incentives_dtl.ToDate=py_incentives_dtl.ToDate) "
'            cm.ExecuteNonQuery()

'            cm.CommandText = "insert into py_incentives_dtl (Emp_Cd, Incentive_Cd, Incentive_Amt, FromDate, ToDate," & _
'                "Recurring, FreqCd, DateUploaded, UploadedBy, BatchNo) " & _
'                "select Emp_Cd, Incentive_Cd, Incentive_Amt, FromDate, ToDate," & _
'                "Recurring, FreqCd, '" & Format(Now, "yyyy/MM/dd") & "', '" & _
'                Session("uid") & "', '" & vBatchNo & "' from import_py_incentives_dtl"
'            cm.ExecuteNonQuery()

'            cm.CommandText = "delete from import_py_incentives_dtl"
'            cm.ExecuteNonQuery()

'            cmdClear.Visible = False
'            cmdLoanConfirm.Visible = False

'            vScript = "alert('Records successfully validated and synchronized.');"
'            RefreshLoans()
'            'CreateCSVFile()
'            'DownloadCSVFiles()
'        Catch ex As SqlClient.SqlException
'            vScript = "alert('An error has occurred while trying to retrieve the config table. Error is: " & _
'                ex.Message.Replace("'", "").Replace(vbCrLf, "") & "');"
'        Finally
'            c.Close()
'            cm.Dispose()
'            c.Dispose()
'        End Try
'    End Sub

'    Protected Sub cmdEmpTimeLog_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdEmpTimeLog.Click

'        Dim c As New SqlClient.SqlConnection(connStr)
'        Dim cm As New SqlClient.SqlCommand
'        Dim cmExec As New SqlClient.SqlCommand
'        Dim rs As SqlClient.SqlDataReader

'        cm.Connection = c
'        cmExec.Connection = c
'        Try
'            c.Open()
'        Catch ex As SqlClient.SqlException
'            vScript = "alert('Error has occurred while trying to connect to database. Error is: " & _
'                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
'            c.Dispose()
'            cm.Dispose()
'            cmExec.Dispose()
'            Exit Sub
'        End Try

'        'cm.CommandText = "delete from py_emp_time_log where exists " & _
'        '    "(select Emp_Cd from import_emp_time_log where import_emp_time_log.Emp_Cd=py_emp_time_log.Emp_Cd " & _
'        '    "and import_emp_time_log.TranDate=py_emp_time_log.TranDate " & _
'        '    "and import_emp_time_log.TranCd=py_emp_time_log.TranCd)"
'        'cm.ExecuteNonQuery()

'        'cm.CommandText = "insert into py_emp_time_log select * from import_emp_time_log"
'        'cm.ExecuteNonQuery()

'        cm.CommandText = "select * from import_emp_time_log"
'        rs = cm.ExecuteReader
'        Do While rs.Read

'            cmExec.CommandText = "delete from py_time_log where Emp_Cd='" & _
'                rs("Emp_Cd") & "' and Tran_Date='" & Format(rs("Tran_Date"), "yyyy/MM/dd") & "' "
'            cmExec.ExecuteNonQuery()

'            cmExec.CommandText = "insert into py_time_log (Emp_Cd, Tran_Date, Time_In, Time_Out, Time_OutDate, Reason) " & _
'                " values ('" & rs("Emp_Cd") & "', '" & rs("Tran_Date") & "', '" & rs("Time_In") & _
'                "', '" & rs("Time_Out") & "','" & rs("Time_OutDate") & "','Uploaded using Import Utility')"
'            cmExec.ExecuteNonQuery()

'            'cmExec.CommandText = "insert into hr_leave_application (TranDate,LeaveCd,Emp_Cd,DaysLeave,StartDate,EndDate,Reason,ApprovedBy," & _
'            '    "DateApproved,Remarks,Void,Paid,Posted,ApplicationNo,Status) values ('" & Format(Now, "yyyy/MM/dd") & _
'            '    "','" & rs("TranCd") & "','" & rs("Emp_Cd") & "'," & rs("Hrs_Rendered") / 8 & ",'" & Format(rs("TranDate"), "yyyy/MM/dd") & _
'            '    "','" & Format(rs("TranDate"), "yyyy/MM/dd") & "','Sync from WFC Logs','" & Session("uid") & "','" & _
'            '    Format(Now, "yyyy/MM/dd") & "','',0,1,1,'" & rs("Emp_Cd") & "-" & rs("TranCd") & Format(rs("TranDate"), "yyyyMMdd") & "','Approved')"
'            'cmExec.ExecuteNonQuery()
'        Loop
'        rs.Close()

'        cm.CommandText = "delete from import_emp_time_log"
'        cm.ExecuteNonQuery()

'        c.Close()
'        c.Dispose()
'        cm.Dispose()
'        cmExec.Dispose()
'        divError.Visible = vError <> ""

'        vScript = "alert( '" & rdoOption.SelectedItem.Text & " successfully loaded.');"
'        cmdEmpTimeLog.Visible = False
'        If rdoOption.Text = "attendance" Then
'            RefreshLogs()
'            'Else
'            '    RefreshWFHLogs()
'        End If
'        DownloadCSVFiles()

'    End Sub

'    Private Sub DownloadCSVFiles()
'        vStatusMessage.Text = rdoOption.SelectedItem.Text & " successfully loaded."
'        vScript = "CSVDownload('open')"
'    End Sub

'    Private Sub CreateCSVFile()
'        Dim i As Integer = 0
'        Dim vSQL As String = ""
'        Dim c As New SqlClient.SqlConnection(connStr)
'        Dim ds As New DataSet
'        Dim vDump As New StringBuilder
'        Dim vTmpStr As String = ""

'        Select Case rdoOption.SelectedValue
'            Case "import_emp_master", "wfh"
'                vSQL = "select * from py_emp_master"        '201 masterfile 'Work from home 201
'            Case "loans"
'                vSQL = "select * from py_loan_hdr"          'Upload Loans
'            Case "PRODPAY"
'                vSQL = "select * from py_incentives_dtl"        'Productivity Pay Exemption
'            Case "earnings"
'                vSQL = "select * from py_incentives_dtl"        'Onetime Earnings
'            Case "deductions"
'                vSQL = "select * from import_loan_hdr"          'Onetime Deductions
'            Case "attendance"
'                vSQL = "select * from import_emp_time_log"      'Attendance Template
'            Case "wfhlogs"
'                vSQL = "select * from import_emp_time_log"      'Work from Home Payfile
'            Case "wfhearnings"
'                vSQL = "select * from import_emp_time_log"      'Work from Home Daily Earnings
'        End Select

'        Dim da As New SqlClient.SqlDataAdapter(vSQL, c)
'        da.Fill(ds, "t")

'        For i = 0 To ds.Tables("t").Columns.Count - 1
'            vTmpStr += ds.Tables("t").Columns(i).ColumnName & ","
'        Next

'        vTmpStr = Mid(vTmpStr, 1, Len(vTmpStr) - 1)
'        vDump.AppendLine(vTmpStr)

'        For i = 0 To ds.Tables("t").Rows.Count - 1
'            vTmpStr = ""
'            For j = 0 To ds.Tables("t").Columns.Count - 1
'                vTmpStr += """" & ds.Tables("t").Rows(i).Item(j).ToString & ""","
'            Next
'            vTmpStr = Mid(vTmpStr, 1, Len(vTmpStr) - 1)
'            vDump.AppendLine(vTmpStr)
'        Next

'        IO.File.WriteAllText(Server.MapPath(".") & "\downloads\" & Session("uid") & "-Import-" & rdoOption.SelectedItem.Text & _
'            ".csv", vDump.ToString)
'        c.Dispose()
'        da.Dispose()
'        ds.Dispose()

'    End Sub

'    Protected Sub cmdDumpCSV_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDumpCSV.Click
'        vScript = "CSVDownload('close'); " & _
'            "wincsv=window.open('downloads/" & Session("uid") & "-Import-" & _
'            rdoOption.SelectedItem.Text & ".csv','wincsv','toolbar=no,top=10,left=100'); wincsv.focus();"
'    End Sub

'    Protected Sub cmdDump_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDump.Click
'        CreateCSVFile()
'    End Sub

'    Protected Sub cmdClear_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdClear.Click

'        Dim c As New SqlClient.SqlConnection(connStr)
'        Dim cm As New SqlClient.SqlCommand

'        cm.Connection = c
'        Try
'            c.Open()
'        Catch ex As SqlClient.SqlException
'            vScript = "alert('Error has occurred while trying to connect to database. Error is: " & _
'                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
'            c.Dispose()
'            cm.Dispose()
'            Exit Sub
'        End Try

'         Select rdoOption.SelectedValue
'            Case "earnings" 'Onetime Earnings
'                cm.CommandText = "delete from import_py_incentives_dtl"
'                cm.ExecuteNonQuery()
'                cmdLoanConfirm.Visible = False
'                cmdClear.Visible = False

'            Case "deductions" 'Onetime Deductions
'                cm.CommandText = "delete from import_loan_hdr"
'                cm.ExecuteNonQuery()
'                cmdLoanConfirm.Visible = False
'                cmdClear.Visible = False
'        End Select

'        c.Close()
'        c.Dispose()
'        cm.Dispose()
'    End Sub

'    Protected Sub cmdview_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdview.Click
'        Select Case rdoOption.SelectedValue
'            Case "earnings" 'Onetime Earnings
'                vScript = "ViewPop('Earnings');"

'            Case "deductions" 'Onetime Deductions
'                vScript = "ViewPop('Deductions');"
'        End Select

'    End Sub
'End Class
