﻿Imports denaro.fis
Partial Class emailaudit
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Session("uid") = "" Or Session("uid") = Nothing Then
            vScript = "alert('Your session has expired. Please re-login again to continue.');window.location='login.aspx';"
            Exit Sub
        End If

        If Not CanRun(Session("caption"), Request.Item("id")) Then
            Session("denied") = "1"
            Server.Transfer("main.aspx")
            Exit Sub
        End If

        txtFrom.Text = Request.Form("txtFrom")
        txtTo.Text = Request.Form("txtTo")

        If Not IsPostBack Then
            txtFrom.Text = Format(Now.Month, "00") & "/01/" & Format(Now.Year, "0000")
            txtTo.Text = Format(Now, "MM/dd/yyyy")
            DataRefresh()
        End If
    End Sub
    Private Sub DataRefresh()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim ds As New DataSet
        Dim vFilter As String = " where TransDate between '" & txtFrom.Text & " 00:00:00' and '" & _
            txtTo.Text & " 23:59:59' "

        If rdoStatus.SelectedValue <> "All" Then
            vFilter += " and Failed=" & rdoStatus.SelectedValue
        End If

        If txtSearch.Text.Trim <> "" Then
            If cmbSearchBy.SelectedValue = "All" Then
                vFilter += " and (ApplicationNo like '%" & txtSearch.Text & "%' or " & _
                    "FromEmail like '%" & txtSearch.Text & "%' or " & _
                    "ToEmail like '%" & txtSearch.Text & "%' or " & _
                    "Subject like '%" & txtSearch.Text & "%' or " & _
                    "ErrorMsg like '%" & txtSearch.Text & "%') "
            Else
                vFilter += " and " & cmbSearchBy.SelectedValue & " like '%" & txtSearch.Text & "%' "
            End If
        End If

        Dim da As New SqlClient.SqlDataAdapter("select * from email_queue " & vFilter & " order by TransDate Desc", c)

        da.Fill(ds, "email")
        tblEmail.DataSource = ds.Tables("email")
        tblEmail.DataBind()

        da.Dispose()
        ds.Dispose()
        c.Dispose()
    End Sub

    Protected Sub cmdClose_Click(sender As Object, e As EventArgs) Handles cmdClose.Click
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub cmdSearch_Click(sender As Object, e As EventArgs) Handles cmdSearch.Click
        DataRefresh()
    End Sub

    Protected Sub tblEmail_PageIndexChanging(sender As Object, e As GridViewPageEventArgs) Handles tblEmail.PageIndexChanging
        tblEmail.PageIndex = e.NewPageIndex
        DataRefresh()
    End Sub

    Protected Sub tblEmail_SelectedIndexChanged(sender As Object, e As EventArgs) Handles tblEmail.SelectedIndexChanged
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        cm.Connection = c
        cm.CommandText = "select Message from email_queue where ApplicationNo='" & _
            tblEmail.SelectedRow.Cells(1).Text & "' and TransDate='" & _
            tblEmail.SelectedRow.Cells(0).Text & "' and FromEmail='" & _
            tblEmail.SelectedRow.Cells(2).Text & "' and ToEmail='" & _
            tblEmail.SelectedRow.Cells(3).Text & "'"
        Try
            rs = cm.ExecuteReader
            If rs.Read Then
                txtMsg.Text = rs("Message")
            End If
            rs.Close()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to retrieve record. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            cm.Dispose()
            c.Dispose()
        End Try
    End Sub

    Protected Sub txtFrom_Init(sender As Object, e As EventArgs) Handles txtFrom.Init
        txtFrom.Attributes.Add("onfocus", "showCalendarControl(this)")
    End Sub

    Protected Sub txtTo_Init(sender As Object, e As EventArgs) Handles txtTo.Init
        txtTo.Attributes.Add("onfocus", "showCalendarControl(this)")
    End Sub

End Class
