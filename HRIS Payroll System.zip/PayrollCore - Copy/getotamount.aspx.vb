Imports denaro.fis
Partial Class getotamount
    Inherits System.Web.UI.Page
    Public vReturn As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            vReturn = "expired"
            Exit Sub
        End If

        Dim vHrs As Decimal = Val(Request.Form("h"))
        Dim vId As String = Request.Form("id")
        Dim c As New sqlclient.sqlconnection(connStr)
        Dim cm As New sqlclient.sqlcommand
        Dim rs As sqlclient.sqldatareader
        Dim vAmount As Decimal = 0
        Dim vMultiplier As Decimal = 0

        Try
            c.Open()
            Try
                cm.Connection = c
                cm.CommandText = "select MaxOtAmount,MinOtHours,Frequency,Aca,FractionTruncated,CalcMethod " & _
                    "from py_emp_master where Emp_Cd='" & vId & "'"
                rs = cm.ExecuteReader
                If rs.Read Then
                    If rs("CalcMethod") = 2 Then                        'employee OT Allowance is based on per cut off basic
                        If vHrs < rs("MinOtHours") Then                     'check if Hours is still less than Required Min. OT
                            vHrs = 0
                        End If
                        If vHrs > 0 Then                                    'check frequency of hours accredited
                            vHrs = vHrs / rs("Frequency")
                            If rs("FractionTruncated") Then
                                vHrs = Math.Floor(vHrs)
                            End If
                        End If
                        vAmount = rs("Aca") * vHrs                          ' calculate OT Allowance
                        vAmount = Math.Min(vAmount, rs("MaxOtAmount"))      'set whichever is the lower amount
                    End If
                End If
                rs.Close()
                vReturn = vAmount
            Catch ex As system.exception
                vReturn = "0"
            Finally
                c.Close()
                cm.Dispose()
                c.Dispose()
            End Try
        Catch ex As system.exception
            vReturn = "0"
        End Try

    End Sub
End Class
