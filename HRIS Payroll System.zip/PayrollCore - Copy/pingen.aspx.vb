Imports denaro
Partial Class pingen
    Inherits System.Web.UI.Page
    Dim c As New sqlclient.sqlconnection
    Public vScript As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Session("returnaddr") = "incentives.aspx"
            Server.Transfer("index.aspx")
            Exit Sub
        End If
        If Not IsPostBack Then
            If Not CanRun(Session("caption"), Request.Item("id")) Then
                Session("denied") = "1"
                Server.Transfer("main.aspx")
                Exit Sub
            End If
            lblcaption.text = "Generate PIN codes for Kiosk Access"
            BuildCombo("select Rc_Cd, Descr from rc order by Descr", cmbRC)
            BuildCombo("select AgencyCd,AgencyName from agency order by AgencyName", cmbOfc)
            BuildCombo("select Div_Cd,Descr from hr_div_ref order by Descr", cmbDiv)
            BuildCombo("select Dept_Cd,Descr from hr_dept_ref order by Descr", cmbDept)
            BuildCombo("select Section_Cd,Descr from hr_section_ref order by Descr", cmbSection)
            BuildCombo("select Unit_Cd,Descr from hr_unit_ref order by Descr", cmbUnit)
            cmbRC.Items.Add("All")
            cmbRC.SelectedValue = "All"
            cmbOfc.Items.Add("All")
            cmbOfc.SelectedValue = "All"
            cmbDiv.Items.Add("All")
            cmbDiv.SelectedValue = "All"
            cmbDept.Items.Add("All")
            cmbDept.SelectedValue = "All"
            cmbSection.Items.Add("All")
            cmbSection.SelectedValue = "All"
            cmbUnit.Items.Add("All")
            cmbUnit.SelectedValue = "All"
            DataRefresh()
        End If
    End Sub
    Protected Sub DataRefresh(Optional ByVal pList As String = "")
        Dim cm As New SqlClient.SqlCommand
        Dim dr As SqlClient.SqlDataReader
        Dim vFilter As String = " where Date_Resign is null and Date_Retired is null and DateHold is null " & _
            "and DateSuspended is null "
        Dim vSql As String = ""

        If cmbRC.SelectedValue <> "All" Then   'filter by cost center
            vFilter += " and Rc_Cd='" & cmbRC.SelectedValue & "' "
        End If
        If cmbOfc.SelectedValue <> "All" Then        'filter by office/agency
            vFilter += " and Agency_Cd='" & cmbOfc.SelectedValue & "' "
        End If
        If cmbDiv.SelectedValue <> "All" Then      'filter by division
            vFilter += " and Divcd='" & cmbDiv.SelectedValue & "' "
        End If
        If cmbDept.SelectedValue <> "All" Then  'filter by departments
            vFilter += " and DeptCd='" & cmbDept.SelectedValue & "' "
        End If
        If cmbSection.SelectedValue <> "All" Then 'filter by section
            vFilter += " and SectionCd='" & cmbSection.SelectedValue & "' "
        End If
        If cmbUnit.SelectedValue <> "All" Then  'filter by units
            vFilter += " and UnitCd='" & cmbUnit.SelectedValue & "' "
        End If
        Session("filter") = vFilter
        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c
        cm.CommandText = "select Emp_Cd,Emp_Lname+', '+Emp_Fname as Name,Pin,Confidential " & _
            "from py_emp_master " & vFilter & _
            " order by Emp_Lname,Emp_Fname,Emp_Mname"
        dr = cm.ExecuteReader
        chkEmp.Items.Clear()
        Do While dr.Read
            If (dr("Confidential") = 1 And Session("userlevel") = 1) Or dr("Confidential") = 0 Then
                If pList.Contains(dr("Emp_Cd")) Then
                    chkEmp.Items.Add(New ListItem("<label style='color:red;'>" & dr("Emp_Cd") & "=>" & dr("Name") & "-->" & IIf(IsDBNull(dr("Pin")), "", dr("Pin")) & "</label>", dr("Emp_Cd")))
                Else
                    chkEmp.Items.Add(New ListItem(dr("Emp_Cd") & "=>" & dr("Name") & "-->" & IIf(dr("Pin").ToString.Length > 0, "RESTRICTED", ""), dr("Emp_Cd")))
                End If
            End If
        Loop
        dr.Close()
        cm.Dispose()
        c.Close()
    End Sub

    Protected Sub cmdRefresh_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdRefresh.Click
        DataRefresh()
    End Sub

    Protected Sub cmdReturn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.Click
        Session.Remove("filter")
        Session.Remove("reportname")
        Session.Remove("returnaddr")
        Server.Transfer("main.aspx")
    End Sub
    Private Sub SetState(ByVal pState As Boolean)
        Dim iCtr As Integer

        For iCtr = 0 To chkEmp.Items.Count - 1
            chkEmp.Items(iCtr).Selected = pState
        Next iCtr
    End Sub
    Protected Sub cmdSelect_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSelect.Click
        SetState(True)
    End Sub

    Protected Sub cmdDeselect_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDeselect.Click
        SetState(False)
    End Sub

    Protected Sub cmdGenerate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdGenerate.Click
        Dim cm As New sqlclient.sqlcommand
        Dim cmExec As New sqlclient.sqlcommand
        Dim dr As sqlclient.sqldatareader
        Dim vId As String = ""
        Dim vEmpList As String = ""
        Dim vList As String = ""
        Dim iCtr As Integer
        Dim conn As New sqlclient.sqlconnection(connStr)

        For iCtr = 0 To chkEmp.Items.Count - 1
            If chkEmp.Items(iCtr).Selected Then
                vEmpList += "'" & chkEmp.Items(iCtr).Value & "',"
                vList += chkEmp.Items(iCtr).Value & ","
            End If
        Next iCtr
        If vEmpList <> "" Then
            vEmpList = vEmpList.Substring(0, vEmpList.Length - 1)
            vList = vList.Substring(0, vList.Length - 1)
        Else
            vScript = "alert('You must first select at least one employee before proceeding this task.');"
            Exit Sub
        End If
        c.ConnectionString = connStr
        c.Open()
        conn.Open()

        cm.Connection = c
        cmExec.Connection = conn
        cm.CommandText = "select Emp_Cd from py_emp_master " & Session("filter") & " and Emp_Cd in (" & _
            vEmpList & ")"
        dr = cm.ExecuteReader
        Do While dr.Read
            vId = dr("Emp_Cd")
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:  VIC GATCHALIAN                                   ''
            '' DATE MODIFIED: 4/8/2013                                        ''
            '' PURPOSE: TO ADD THE RESETFAIL FIELD AS PART OF RESETTING THE   ''
            ''          VALUE.                                                ''
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '''''''''''''''''''''' OLD CODE ''''''''''''''''''''''''''''''''''''
            'cmExec.CommandText = "update py_emp_master set Pin='" & Math.Abs(vId.GetHashCode) & _
            '    "', LogInFail = 0, PinExpiry='" & Format(Now, "yyyy/MM/dd") & "' where Emp_Cd='" & vId & "'"
            '''''''''''''''''''''' END OLD CODE ''''''''''''''''''''''''''''''''
            cmExec.CommandText = "update py_emp_master set Pin='" & Math.Abs(vId.GetHashCode) & _
                "', LogInFail = 0, ResetFail=0,PinExpiry='" & Format(Now, "yyyy/MM/dd") & _
                "' where Emp_Cd='" & vId & "'"
            '''''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''

            cmExec.ExecuteNonQuery()
        Loop
        dr.Close()
        cm.Dispose()
        cmExec.Dispose()
        c.Close()
        conn.Close()

        vScript = "alert('Create of PIN codes were successfully generated.');"
        DataRefresh(vEmpList)
    End Sub
End Class
