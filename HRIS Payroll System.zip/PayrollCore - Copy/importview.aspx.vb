﻿Imports denaro.fis
Partial Class importview
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Public vDetail As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            vScript = "alert('Your login session has expired. Please re-login again.'); window.close();"
            Exit Sub
        End If
        If Not IsPostBack Then
            Dim c As New Odbc.OdbcConnection(connStr)
            Dim cm As New Odbc.OdbcCommand
            Dim cmXRef As New Odbc.OdbcCommand
            Dim cmDB As New Odbc.OdbcCommand
            Dim rsDB As Odbc.OdbcDataReader
            Dim rsXRef As Odbc.OdbcDataReader
            Dim rs As Odbc.OdbcDataReader
            Dim vClass As String
            Dim vCurrValue As String = ""
            Dim vNewValue As String = ""

            Try
                c.Open()
            Catch ex As Odbc.OdbcException
                vScript = "alert('An error has occurred while trying to connect to database. Error is: " & _
                    ex.Message.Replace("'", "").Replace(vbCrLf, "") & "');"
                cm.Dispose()
                cmDB.Dispose()
                cmXRef.Dispose()
                c.Dispose()
                Exit Sub
            End Try

            cm.Connection = c
            cmXRef.Connection = c
            cmDB.Connection = c
            Try
                cm.CommandText = "select * from " & Session("temptable") & " where " & Session("key") & "='" & _
                    Session("selected") & "'"
                cmXRef.CommandText = "select * from " & Session("xreftable") & " where " & Session("key") & "='" & _
                    Session("selected") & "'"
                rs = cm.ExecuteReader
                rsXRef = cmXRef.ExecuteReader
                If rs.HasRows Then rs.Read()
                If rsXRef.HasRows Then rsXRef.Read()
                cmDB.CommandText = "select * from _db where TempTable='" & Session("temptable") & "' and TableKey is not null"
                rsDB = cmDB.ExecuteReader
                vDetail = ""
                vClass = "odd"
                Do While rsDB.Read
                    If rsXRef.HasRows Then
                        If Not IsDBNull(rsXRef(rsDB("TableKey"))) Then
                            vCurrValue = rsXRef(rsDB("TableKey"))
                        Else
                            vCurrValue = "null"
                        End If
                    Else
                        vCurrValue = "&nbsp;"
                    End If

                    If Not IsDBNull(rs(rsDB("TableKey"))) Then
                        vNewValue = rs(rsDB("TableKey"))
                    Else
                        vNewValue = "null"
                    End If

                    vDetail += "<tr class='" & IIf(vCurrValue <> vNewValue, "activeBar", vClass) & _
                        "'><td class='labelL'>" & rsDB("TableKey") & "</td>" & _
                        "<td class='labelL'>" & vCurrValue & "</td>" & _
                        "<td class='labelL'>" & vNewValue & "</td></tr>"
                    vClass = IIf(vClass = "odd", "even", "odd")
                Loop
                rsDB.Close()
                rs.Close()
                rsXRef.Close()
            Catch ex As Odbc.OdbcException
                vScript = "alert('An error has occurred while trying to retrieve the record.  Error is: " & _
                    ex.Message.Replace("'", "").Replace(vbCrLf, "") & "');"
            Finally
                c.Close()
                cm.Dispose()
                cmXRef.Dispose()
                cmDB.Dispose()
                c.Dispose()
            End Try
        End If
    End Sub
End Class
