﻿Imports denaro
Partial Class latefile
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Public vData As String = ""
    

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If

        If Not CanRun(Session("caption"), Request.Item("id")) Then
            Session("denied") = "1"
            Server.Transfer("main.aspx")
            Exit Sub
        End If

        If Not IsPostBack Then
            lblCaption.Text = "Generate Payroll"

            cmbMonth.SelectedValue = Now.Month

            Dim c As New SqlClient.SqlConnection(connStr)
            Dim cm As New SqlClient.SqlCommand
            'Dim dr As SqlClient.SqlDataReader

            Try
                c.Open()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to connect to SQL Server. Error is: " & _
                    ex.Message.Replace(vbCrLf, "\n").Replace("'", "\'") & "');"
                c.Dispose()
                cm.Dispose()
                Exit Sub
            End Try
            BuildCombo("select Pay_Cd,Payment from py_pay_mode order by Payment", cmbPayMode, c)

            'BuildCombo("select Status_Code,Descr from py_employee_stat order by Descr", cmbEmpStatus, c)
            'BuildCombo("select Rc_Cd,Descr from rc where exists (select User_Id from rights_list where User_Id='" & _
            '    Session("uid") & "' and property='rc' and Property_Value=Rc_Cd) order by Descr", cmbRC, c)
            'BuildCombo("select AgencyCd,AgencyName from agency where exists (select User_Id from rights_list where User_Id='" & _
            '    Session("uid") & "' and property='agency' and Property_Value=AgencyCd) order by AgencyName", cmbOfc, c)
            'BuildCombo("select Div_Cd,Descr from hr_div_ref where exists (select User_Id from rights_list where User_Id='" & _
            '    Session("uid") & "' and property='division' and Property_Value=Div_Cd) order by Descr", cmbDiv, c)
            'BuildCombo("select Dept_Cd,Descr from hr_dept_ref where exists (select User_Id from rights_list where User_Id='" & _
            '    Session("uid") & "' and property='department' and Property_Value=Dept_Cd) order by Descr", cmbDept, c)
            'BuildCombo("select Section_Cd,Descr from hr_section_ref where exists (select User_Id from rights_list where User_Id='" & _
            '    Session("uid") & "' and property='section' and Property_Value=Section_Cd) order by Descr", cmbSection, c)
            'BuildCombo("select Unit_Cd,Descr from hr_unit_ref where exists (select User_Id from rights_list where User_Id='" & _
            '    Session("uid") & "' and property='unit' and Property_Value=Unit_Cd) order by Descr", cmbUnit, c)
            'BuildCombo("select EmploymentType,Descr from hr_employment_type where exists (select User_Id from rights_list where User_Id='" & _
            '    Session("uid") & "' and property='employmenttype' and Property_Value=EmploymentType) order by Descr", cmbEmpType, c)

            'cmbRC.Items.Add("All")
            'cmbRC.SelectedValue = "All"
            'cmbOfc.Items.Add("All")
            'cmbOfc.SelectedValue = "All"
            'cmbDiv.Items.Add("All")
            'cmbDiv.SelectedValue = "All"
            'cmbDept.Items.Add("All")
            'cmbDept.SelectedValue = "All"
            'cmbSection.Items.Add("All")
            'cmbSection.SelectedValue = "All"
            'cmbUnit.Items.Add("All")
            'cmbUnit.SelectedValue = "All"
            'cmbEmpType.Items.Add("All")
            'cmbEmpType.SelectedValue = "All"
            'cmbEmpStatus.Items.Add("All")
            'cmbEmpStatus.SelectedValue = "All"
        End If

    End Sub

    Protected Sub cmbMonth_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbMonth.SelectedIndexChanged
        SetStartCutOff()
    End Sub

    Private Sub SetStartCutOff()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim dr As SqlClient.SqlDataReader
        Dim vCutOff As String = ""
        Dim vDays() As String
        Dim iCtr As Integer

        Try
            c.Open()
        Catch ex As sqlclient.sqlexception
            vScript = "alert('Error occurred while trying to connect to SQL Server. Error in line 223: " & _
                ex.Message.Replace(vbCrLf, "\n").Replace("'", "\'") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        cm.Connection = c
        cm.CommandText = "select * from py_pay_mode where Pay_Cd='" & cmbPayMode.SelectedValue & "'"

        Try
            dr = cm.ExecuteReader
            If dr.Read Then
                Session("divisor") = IIf(IsDBNull(dr("Divisor")), 1, dr("Divisor"))
                Session("index") = "1"
                vCutOff = IIf(IsDBNull(dr("Days")), "", dr("Days"))
                cmbFrom.Items.Clear()
                cmbTo.Items.Clear()
                vDays = vCutOff.Split(",")
                For iCtr = 0 To vDays.Length - 1
                    cmbFrom.Items.Add(cmbMonth.SelectedValue & "/" & vDays(iCtr) & "/" & Now.Year)
                    cmbFrom.Items.Add(cmbMonth.SelectedValue & "/" & vDays(iCtr) & "/" & Now.Year - 1)
                Next iCtr
            End If
            dr.Close()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to analyze cut-off periods. Error is: " & _
                ex.Message.Replace(vbCrLf, "\n").Replace("'", "\'") & "');"
        Finally
            cm.Dispose()
            c.Close()
            c.Dispose()
            SetEndCutOff()
        End Try
    End Sub

    Protected Sub cmbPayMode_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbPayMode.SelectedIndexChanged
        SetStartCutOff()
    End Sub

    Private Sub SetEndCutOff()
        Dim vDate As Date
        Dim vTo As Date
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim dr As SqlClient.SqlDataReader
        Dim vWorkingDays As Boolean = True
        Dim iDate As Date
        Dim iWeekEnds As Integer = 0

        cmbTo.Items.Clear()
        If cmbFrom.Items.Count > 2 Then
            vDate = CDate(cmbFrom.SelectedValue)
            If cmbFrom.SelectedIndex + 2 > cmbFrom.Items.Count - 1 Then
                vTo = CDate(cmbFrom.Items((cmbFrom.SelectedIndex + 2) - cmbFrom.Items.Count).Text)
            Else
                vTo = CDate(cmbFrom.Items(cmbFrom.SelectedIndex + 2).Text)
            End If
            If vTo.Day < vDate.Day Then
                vTo = vTo.AddMonths(1)
            End If
        Else
            vTo = CDate(cmbFrom.SelectedValue).AddMonths(1)
        End If
        ''''''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''''''''

        cmbTo.Items.Add(vTo.AddDays(-1))
        'cmdStart.Enabled = True

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to SQL Server. Error in line 307: " & _
                ex.Message.Replace(vbCrLf, "\n").Replace("'", "\'") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        cm.Connection = c
        cm.CommandText = "select WorkingDays_Only from glsyscntrl"
        dr = cm.ExecuteReader
        If dr.Read Then
            vWorkingDays = IIf(IsDBNull(dr("WorkingDays_Only")), True, dr("WorkingDays_Only"))
        End If
        dr.Close()
        cm.CommandText = "select Days,CreditDay from py_pay_mode where Pay_Cd='" & cmbPayMode.SelectedValue & "'"
        Try
            dr = cm.ExecuteReader
            If dr.Read() Then
                Dim vCutOff = dr("Days").ToString.Split(",")
                Dim vCredit = dr("CreditDay").ToString.Split(",")
                Dim vDay = CDate(cmbFrom.SelectedValue).Day
                Dim iCtr As Integer
                Dim vMonth As Integer = 0
                Dim vYear As Integer = 0

                For iCtr = 0 To UBound(vCutOff)
                    If vCutOff(iCtr) = vDay Then
                        If CDate(cmbTo.SelectedValue).Month = 12 And CDate(cmbTo.SelectedValue).Day >= 30 Then
                            vMonth = 0
                            vYear = CDate(cmbTo.SelectedValue).Year + 1
                        Else
                            vMonth = CDate(cmbTo.SelectedValue).Month
                            vYear = CDate(cmbTo.SelectedValue).Year
                        End If
                        txtPayDate.Text = Format(vMonth + _
                            IIf(CDate(cmbTo.SelectedValue).Day < vCredit(iCtr), 0, 1), "00") & "/" & Format(Val(vCredit(iCtr)), "00") & "/" & _
                            Format(vYear, "0000")
                        If vCredit(iCtr) = 30 Then
                            txtPayDate.Text = MonthEND(CDate(Mid(txtPayDate.Text, 1, 2) & "/1/" & Mid(txtPayDate.Text, 7)))
                        End If
                        Exit For
                    End If
                Next iCtr
            End If
            dr.Close()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to analyze the ending cut-off periods. Error is: " & _
                ex.Message.Replace(vbCrLf, "\n").Replace("'", "\'") & "');"
        Finally
            cm.Dispose()
            c.Close()
            c.Dispose()
            iDate = CDate(cmbFrom.SelectedValue)
            Do While iDate <= CDate(cmbTo.SelectedValue)
                If iDate.DayOfWeek = DayOfWeek.Sunday Or (iDate.DayOfWeek = DayOfWeek.Saturday And Not vWorkingDays) Then
                    iWeekEnds += 1
                End If
                iDate = DateAdd(DateInterval.Day, 1, iDate)
            Loop
            Session("ActualDays") = Math.Abs(DateDiff(DateInterval.Day, CDate(cmbFrom.SelectedValue), CDate(cmbTo.SelectedValue)) + 1 - iWeekEnds)
            Session("WeekEnds") = iWeekEnds
           
        End Try
    End Sub

    Protected Sub cmbFrom_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbFrom.SelectedIndexChanged
        Select Case cmbFrom.SelectedIndex + 1
            Case 1, 2
                Session("index") = 1
            Case Else
                Session("index") = 2
        End Select
        SetEndCutOff()
    End Sub


    Protected Sub cmdRefresh_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdRefresh.Click

        If cmbFrom.SelectedValue = "" Then
            vScript = "alert('Please select Starting Cut-off ');"
            Exit Sub
        End If

        Dim vFrom As Date
        Dim vTo As Date


        If cmbFrom.Visible Then
            vFrom = CDate(cmbFrom.SelectedValue)
            vTo = CDate(cmbTo.SelectedValue)
        Else
            If Not IsDate(txtStartDate.Text) Then
                vScript = "alert('Please enter a valid Starting cut off date.');"
                Exit Sub
            End If
            If Not IsDate(txtEndDate.Text) Then
                vScript = "alert('Please enter a valid Ending cut off date.');"
                Exit Sub
            End If
            If Not IsDate(txtPayDate.Text) Then
                vScript = "alert('Please enter a valid Payout date.');"
                Exit Sub
            End If
            vFrom = CDate(txtStartDate.Text)
            vTo = CDate(txtEndDate.Text)
        End If

        Dim c As New SqlClient.SqlConnection(connStr)

        Dim cm As New SqlClient.SqlCommand
        Dim cmRef As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim rsRef As SqlClient.SqlDataReader
        Dim vWithRecords As Boolean = False
        Dim vCtr As Integer = 1
        Dim vClass As String = "odd"
        Dim vFilter As String = ""
        Dim vCreditTo As String = ""

        txtTranID.Value = ""

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "\n").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        cm.Connection = c
        cmRef.Connection = c

        vFilter = "and ((ApprovedBy is not null and DateApproved is not null and RecommendedBy is null) or " & _
            " (ApprovedBy is not null and DateApproved is not null and RecommendedBy is not null and DateRecommended is not null and NotedBy is null) or " & _
            " (ApprovedBy is not null and DateApproved is not null and RecommendedBy is not null and DateRecommended is not null and NotedBy is not null and DateNoted is not null))"

        cm.CommandText = "select Emp_Cd,Emp_Lname,Emp_Fname from py_emp_master order by Emp_Lname,Emp_Fname"
        Try
            rs = cm.ExecuteReader

            Do While rs.Read
                vWithRecords = False
                'check availability
                cmRef.CommandText = "select count(*) from hr_leave_application where void=0 and Paid=1 and EffectivityDate between '" & _
                    Format(CDate(cmbFrom.SelectedValue), "yyyy/MM/dd") & "' and '" & _
                    Format(CDate(cmbTo.SelectedValue), "yyyy/MM/dd") & "' and Emp_Cd='" & rs("Emp_Cd") & "'" & vFilter
                '"((ApprovedBy is not null and DateApproved is not null and RecommendedBy is null) or " & _
                '" (ApprovedBy is not null and DateApproved is not null and RecommendedBy is not null and DateRecommended is not null and NotedBy is null) or " & _
                '" (ApprovedBy is not null and DateApproved is not null and RecommendedBy is not null and DateRecommended is not null and NotedBy is not null and DateNoted is not null))"
                rsRef = cmRef.ExecuteReader
                rsRef.Read()
                If IsDBNull(rsRef(0)) Then
                    rsRef.Close()
                    cmRef.CommandText = "select count(*)  from py_time_log where EffectivityDate between '" & _
                        Format(CDate(cmbFrom.SelectedValue), "yyyy/MM/dd") & "' and '" & _
                        Format(CDate(cmbTo.SelectedValue), "yyyy/MM/dd") & "' and Emp_Cd='" & rs("Emp_Cd") & "' "
                    rsRef = cmRef.ExecuteReader
                    rsRef.Read()
                    If IsDBNull(rsRef(0)) Then
                        rsRef.Close()
                        cmRef.CommandText = "select count(*) from py_emp_time_sched where EffectivityDate between '" & _
                            Format(CDate(cmbFrom.SelectedValue), "yyyy/MM/dd") & "' and '" & _
                            Format(CDate(cmbTo.SelectedValue), "yyyy/MM/dd") & "' and Emp_Cd='" & rs("Emp_Cd") & "'"
                        rsRef = cmRef.ExecuteReader
                        rsRef.Read()
                        vWithRecords = Not IsDBNull(rsRef(0))
                    Else
                        vWithRecords = True
                    End If
                Else
                    vWithRecords = True
                End If
                rsRef.Close()

                If vWithRecords Then    'dump records
                    '======================================================================================================================================
                    'get leave and OT late application
                    '======================================================================================================================================
                    cmRef.CommandText = "select * from hr_leave_application where void=0 and Paid=1 and EffectivityDate between '" & _
                        Format(CDate(cmbFrom.SelectedValue), "yyyy/MM/dd") & "' and '" & _
                        Format(CDate(cmbTo.SelectedValue), "yyyy/MM/dd") & "' and Emp_Cd='" & rs("Emp_Cd") & "'" & vFilter

                    rsRef = cmRef.ExecuteReader
                    Do While rsRef.Read

                        vCreditTo = rsRef("LeaveCd") & IIf(rsRef("LeaveCd") = "OT", "=>" & rsRef("CreditTo"), "")

                        If vCreditTo <> "OT=>EO" Then
                            txtTranID.Value += rsRef("Id") & ","

                            vData += "<tr class='" & vClass & "' ><td class='labelC'>" & vCtr & "</td>" & _
                                "<td class='labelC' style='padding:5px; color: #000000;'>" & _
                                    "<input type='checkbox' id='chk_leave_" & rsRef("Id") & "' name='chk_leave_" & rsRef("Id") & "' checked='checked'/>" & _
                                "</td>" & _
                                "<td class='labelC' style='padding:5px;'>" & rs("Emp_Cd") & "</td>" & _
                                "<td class='labelL' style='padding:5px;'>" & rs("Emp_Lname") & ", " & rs("Emp_Fname") & "</td>" & _
                                "<td class='labelC' style='padding:5px;'>" & vCreditTo & "</td>" & _
                                "<td class='labelC' style='padding:5px;'>" & rsRef("DaysLeave") & " " & IIf(rsRef("LeaveCd") = "OT", "hh", "dd") & "</td>" & _
                                "<td class='labelC' style='padding:5px;'>" & Format(CDate(rsRef("TranDate")), "MM/dd/yyyy HH:mm:ss") & "</td>" & _
                                "<td class='labelC' style='padding:5px;'>" & rsRef("ApplicationNo") & "</td>" & _
                                "<td class='labelC' style='padding:5px;'>" & Format(CDate(rsRef("StartDate")), "MM/dd/yyyy" & IIf(rsRef("LeaveCd") = "OT", " HH:mm:ss", "")) & "</td>" & _
                                "<td class='labelC' style='padding:5px;'>" & Format(CDate(rsRef("EndDate")), "MM/dd/yyyy" & IIf(rsRef("LeaveCd") = "OT", " HH:mm:ss", "")) & "</td>" & _
                                "<td class='labelC' style='padding:5px;'>" & Format(CDate(rsRef("EffectivityDate")), "MM/dd/yyyy") & "</td>" & _
                                "<td class='labelC' style='padding:5px;'>" & rsRef("ApprovedBy") & "</td>" & _
                                "<td class='labelC' style='padding:5px;'>" & Format(CDate(rsRef("DateApproved")), "MM/dd/yyyy HH:mm:ss") & "</td>"
                            If Not IsDBNull(rsRef("RecommendedBy")) Then
                                vData += "<td class='labelC' style='padding:5px;'>" & rsRef("RecommendedBy") & "</td>" & _
                                    "<td class='labelC' style='padding:5px;'>" & Format(CDate(rsRef("DateRecommended")), "MM/dd/yyyy HH:mm:ss") & "</td>"
                                If Not IsDBNull(rsRef("NotedBy")) Then
                                    vData += "<td class='labelC' style='padding:5px;'>" & rsRef("NotedBy") & "</td>" & _
                                        "<td class='labelC' style='padding:5px;'>" & Format(CDate(rsRef("DateNoted")), "MM/dd/yyyy HH:mm:ss") & "</td>"
                                Else
                                    vData += "<td class='labelC' style='padding:5px;'>&nbsp;</td>" & _
                                        "<td class='labelC' style='padding:5px;'>&nbsp;</td>"
                                End If
                            Else
                                vData += "<td class='labelC' style='padding:5px;'>&nbsp;</td>" & _
                                    "<td class='labelC' style='padding:5px;'>&nbsp;</td>" & _
                                    "<td class='labelC' style='padding:5px;'>&nbsp;</td>" & _
                                    "<td class='labelC' style='padding:5px;'>&nbsp;</td>"
                            End If
                            vData += "</tr>"
                            vClass = IIf(vClass = "odd", "even", "odd")
                            vCtr += 1
                        End If
                    Loop
                    rsRef.Close()

                    '======================================================================================================================================
                    'get late filed DTR correction
                    '======================================================================================================================================
                    cmRef.CommandText = "select * from py_time_log where EffectivityDate between '" & _
                        Format(CDate(cmbFrom.SelectedValue), "yyyy/MM/dd") & "' and '" & _
                        Format(CDate(cmbTo.SelectedValue), "yyyy/MM/dd") & "' and Emp_Cd='" & rs("Emp_Cd") & "'" & _
                        "and ((ApprovedBy is not null and Date_Approved is not null)) "
                    rsRef = cmRef.ExecuteReader
                    Do While rsRef.Read

                        txtTranID.Value += rsRef("Id") & ","
                        vData += "<tr class='" & vClass & "' ><td class='labelC'>" & vCtr & "</td>" & _
                            "<td class='labelC' style='padding:5px; color: #000000;'>" & _
                                "<input type='checkbox' id='chk_leave_" & rsRef("Id") & "' name='chk_leave_" & rsRef("Id") & "' checked='checked'/>" & _
                            "</td>" & _
                            "<td class='labelC' style='padding:5px;'>" & rs("Emp_Cd") & "</td>" & _
                            "<td class='labelL' style='padding:5px;'>" & rs("Emp_Lname") & ", " & rs("Emp_Fname") & "</td>" & _
                            "<td class='labelC' style='padding:5px;'>DTR</td>" & _
                            "<td class='labelC' style='padding:5px;'></td>" & _
                            "<td class='labelC' style='padding:5px;'>" & Format(CDate(rsRef("Tran_Date")), "MM/dd/yyyy HH:mm:ss") & "</td>" & _
                            "<td class='labelC' style='padding:5px;'>" & rsRef("Id") & "</td>" & _
                            "<td class='labelC' style='padding:5px;'></td>" & _
                            "<td class='labelC' style='padding:5px;'></td>" & _
                            "<td class='labelC' style='padding:5px;'>" & Format(CDate(rsRef("EffectivityDate")), "MM/dd/yyyy") & "</td>" & _
                            "<td class='labelC' style='padding:5px;'>" & rsRef("ApprovedBy") & "</td>" & _
                            "<td class='labelC' style='padding:5px;'>" & Format(CDate(rsRef("Date_Approved")), "MM/dd/yyyy HH:mm:ss") & "</td>"

                        vData += "<td class='labelC' style='padding:5px;'>&nbsp;</td>" & _
                            "<td class='labelC' style='padding:5px;'>&nbsp;</td>" & _
                            "<td class='labelC' style='padding:5px;'>&nbsp;</td>" & _
                            "<td class='labelC' style='padding:5px;'>&nbsp;</td>"

                        vData += "</tr>"
                        vClass = IIf(vClass = "odd", "even", "odd")
                        vCtr += 1
                    Loop
                    rsRef.Close()

                    '======================================================================================================================================
                    'get late filed shift change 
                    '======================================================================================================================================
                    cmRef.CommandText = "select * from py_emp_time_sched where EffectivityDate between '" & _
                        Format(CDate(cmbFrom.SelectedValue), "yyyy/MM/dd") & "' and '" & _
                        Format(CDate(cmbTo.SelectedValue), "yyyy/MM/dd") & "' and Emp_Cd='" & rs("Emp_Cd") & "' " & _
                        "and ((ApprovedBy is not null and DateApproved is not null and RecommendedBy is null) or " & _
                        "(ApprovedBy is not null and DateApproved is not null and RecommendedBy is not null and DateRecommended is not null and NotedBy is null) or " & _
                        "(ApprovedBy is not null and DateApproved is not null and RecommendedBy is not null and DateRecommended is not null and NotedBy is not null and DateNoted is not null))"

                    rsRef = cmRef.ExecuteReader
                    Do While rsRef.Read

                        txtTranID.Value += rsRef("Id") & ","
                        vData += "<tr class='" & vClass & "' ><td class='labelC'>" & vCtr & "</td>" & _
                            "<td class='labelC' style='padding:5px; color: #000000;'>" & _
                                "<input type='checkbox' id='chk_shift_change_" & rsRef("Id") & "' name='chk_SC_" & rsRef("Id") & "' checked='checked'/>" & _
                            "</td>" & _
                            "<td class='labelC' style='padding:5px;'>" & rs("Emp_Cd") & "</td>" & _
                            "<td class='labelL' style='padding:5px;'>" & rs("Emp_Lname") & ", " & rs("Emp_Fname") & "</td>" & _
                            "<td class='labelC' style='padding:5px;'>Change Shift</td>" & _
                            "<td class='labelC' style='padding:5px;'>" & Format(CDate(rsRef("TransDate")), "MM/dd/yyyy HH:mm:ss") & "</td>" & _
                            "<td class='labelC' style='padding:5px;'></td>" & _
                            "<td class='labelC' style='padding:5px;'></td>" & _
                            "<td class='labelC' style='padding:5px;'></td>" & _
                            "<td class='labelC' style='padding:5px;'>" & Format(CDate(rsRef("EffectivityDate")), "MM/dd/yyyy") & "</td>" & _
                            "<td class='labelC' style='padding:5px;'>" & rsRef("ApprovedBy") & "</td>" & _
                            "<td class='labelC' style='padding:5px;'>" & Format(CDate(rsRef("DateApproved")), "MM/dd/yyyy HH:mm:ss") & "</td>"

                        If Not IsDBNull(rsRef("RecommendedBy")) Then
                            vData += "<td class='labelC' style='padding:5px;'>" & rsRef("RecommendedBy") & "</td>" & _
                                "<td class='labelC' style='padding:5px;'>" & Format(CDate(rsRef("DateRecommended")), "MM/dd/yyyy HH:mm:ss") & "</td>"
                            If Not IsDBNull(rsRef("NotedBy")) Then
                                vData += "<td class='labelC' style='padding:5px;'>" & rsRef("NotedBy") & "</td>" & _
                                    "<td class='labelC' style='padding:5px;'>" & Format(CDate(rsRef("DateNoted")), "MM/dd/yyyy HH:mm:ss") & "</td>"
                            Else
                                vData += "<td class='labelC' style='padding:5px;'>&nbsp;</td>" & _
                                    "<td class='labelC' style='padding:5px;'>&nbsp;</td>"
                            End If
                        Else
                            vData += "<td class='labelC' style='padding:5px;'>&nbsp;</td>" & _
                                "<td class='labelC' style='padding:5px;'>&nbsp;</td>" & _
                                "<td class='labelC' style='padding:5px;'>&nbsp;</td>" & _
                                "<td class='labelC' style='padding:5px;'>&nbsp;</td>"
                        End If
                        vData += "</tr>"
                        vClass = IIf(vClass = "odd", "even", "odd")
                        vCtr += 1
                    Loop
                    rsRef.Close()

                End If
            Loop
            rs.Close()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to read to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "\n").Replace("'", "") & "');"
        Finally
            c.Close()
            cm.Dispose()
            cmRef.Dispose()
            c.Dispose()
        End Try
    End Sub
End Class
