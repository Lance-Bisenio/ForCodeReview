Imports denaro
Partial Class modifyloan
    Inherits System.Web.UI.Page
    Public vScript As String = ""
  
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            vScript = "alert('Your login session has expired. Please re-login again.'); window.close();"
            Exit Sub
        End If

        If Not IsPostBack Then
            Dim c As New SqlClient.SqlConnection(connStr)
            Dim cm As New SqlClient.SqlCommand
            Dim dr As SqlClient.SqlDataReader
            Dim vMode As String = ""
            Dim vLoanDate As String = ""
            Dim vFreq As String = ""

            lblCaption.Text = "Add/Modify Loan or Deduction"

            cm.Connection = c

            vMode = Session("mode")
            txtLoanType.Text = Session("loancd")

            Try
                c.Open()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to connect to SQL Server. Error is: " & _
                    ex.Message.Replace(vbCrLf, "\n").Replace("'", "") & "');"
                c.Dispose()
                cm.Dispose()
                Exit Sub
            End Try

            BuildCombo("select CurrCd,CurrName from currency_ref order by CurrName", cmbSrcCurr, c)
            BuildCombo("select CurrCd,CurrName from currency_ref order by CurrName", cmbTargetCurr, c)

            If vMode = "e" Or Session("mode") = "v" Then 'edit or view mode
                cm.CommandText = "select * from py_loan_hdr where Id=" & Session("tid")

                Try
                    dr = cm.ExecuteReader
                    If dr.Read Then
                        txtEmp.Text = dr("Emp_Cd")
                        txtEmpName.Text = GetName(txtEmp.Text)
                        txtStartDate.Text = IIf(IsDBNull(dr("Start_Date")), "", dr("Start_Date"))
                        txtLoanDate.Text = dr("Loan_Date")
                        vLoanDate = dr("Loan_Date")
                        txtLoanAmt.Text = IIf(IsDBNull(dr("Amt_Loan")), "0", dr("Amt_Loan"))
                        txtRemarks.Text = IIf(IsDBNull(dr("ProdDescr")), "", dr("ProdDescr"))
                        txtInterest.Text = IIf(IsDBNull(dr("Int_Rate")), "0", dr("Int_Rate"))
                        txtNoOfPayments.Text = IIf(IsDBNull(dr("Month_to_Pay")), "0", dr("Month_to_Pay"))

                        txtAmtPaid.Text = IIf(IsDBNull(dr("Amt_Paid")), "0", dr("Amt_Paid"))

                        txtBal.Text = IIf(IsDBNull(dr("Amt_Bal")), "0", dr("Amt_Bal"))
                        txtMonthly.Text = IIf(IsDBNull(dr("MonthlyAmort")), 0, dr("MonthlyAmort"))
                        chkRecurring.Checked = IIf(IsDBNull(dr("Recurring")), False, dr("Recurring"))
                        txtDocNo.Text = IIf(IsDBNull(dr("DocNo")), "", dr("DocNo"))
                        txtEndDate.Text = IIf(IsDBNull(dr("End_Date")), "", dr("End_Date"))
                        vFreq = IIf(IsDBNull(dr("FreqCd")), 0, dr("FreqCd"))
                        txtTrueLoanDate.Value = txtLoanDate.Text
                        cmbSrcCurr.SelectedValue = dr("SrcCurrCd")
                        cmbTargetCurr.SelectedValue = dr("TargetCurrCd")
                    End If
                    dr.Close()
                    'synchronize total amount paid
                    cm.CommandText = "select sum(Amt_Paid) from py_loan_dtl where Emp_Cd='" & _
                        txtEmp.Text & "' and Loan_Cd='" & txtLoanType.Text & "' and Loan_Date='" & _
                        Format(CDate(vLoanDate), "yyyy/MM/dd") & "' and Amt_Paid is not null"

                    dr = cm.ExecuteReader
                    If dr.Read Then

                        'txtAmtPaid.Text = IIf(IsDBNull(dr(0)), 0, dr(0)) & " x"
                        txtDetailAmtPaid.Value = txtAmtPaid.Text
                    End If
                    dr.Close()
                Catch ex As SqlClient.SqlException
                    vScript = "alert('Error occurred while trying to retrieve Loan Ledger. Error is: " & _
                        ex.Message.Replace(vbCrLf, "\n").Replace("'", "") & "');"
                Finally
                    txtEmp.Enabled = False
                    cmdSearch.Disabled = True
                    If vMode = "v" Then 'freeze fields
                        txtLoanDate.ReadOnly = True
                        txtStartDate.ReadOnly = True
                        txtLoanAmt.ReadOnly = True
                        txtRemarks.ReadOnly = True
                        txtInterest.ReadOnly = True
                        txtNoOfPayments.ReadOnly = True
                        txtAmtPaid.ReadOnly = True
                        txtBal.ReadOnly = True
                        txtMonthly.ReadOnly = True
                        txtDocNo.ReadOnly = True
                        cmbFreq.Enabled = False
                        chkRecurring.Enabled = False
                        cmbSrcCurr.Enabled = False
                        cmbTargetCurr.Enabled = False
                    End If
                    c.Close()
                    c.Dispose()
                    cm.Dispose()
                    GeneratePayModes()
                    cmbFreq.SelectedValue = vFreq
                End Try
            End If
        End If
    End Sub
    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        If Page.IsValid Then
            Dim c As New SqlClient.SqlConnection(connStr)
            Dim cmRef As New SqlClient.SqlCommand
            Dim cm As New SqlClient.SqlCommand
            Dim vNoPay As String = txtNoOfPayments.Text
            Dim vAmt As Decimal = CDbl(txtLoanAmt.Text)
            Dim vAmort As Decimal = CDbl(txtMonthly.Text)
            Dim vCtr As Integer = 0
            Dim vPayDate As Date = Nothing
            Dim vType As Boolean = False
            Dim I As Integer = 1

            vType = IIf(vPayDate.Day < 15, True, False)

            Try
                c.Open()
            Catch ex As sqlclient.sqlexception
                vScript = "alert('Error occurred while trying to connect to SQL Server. Error is: " & _
                    ex.Message.Replace(vbCrLf, "\n").Replace("'", "") & "');"
                c.Dispose()
                cm.Dispose()
                cmRef.Dispose()
                Exit Sub
            End Try

            cm.Connection = c
            cmRef.Connection = c
            If Session("mode") = "e" Then 'edit mode
                cm.CommandText = "update py_loan_hdr set Amt_Bal=" & txtBal.Text & _
                    ",Amt_Loan=" & txtLoanAmt.Text & _
                    ",Amt_Paid=" & txtAmtPaid.Text & _
                    ",Loan_Date='" & Format(CDate(txtLoanDate.Text), "yyyy/MM/dd") & _
                    "',Start_Date='" & Format(CDate(txtStartDate.Text), "yyyy/MM/dd") & _
                    "',Int_Rate=" & txtInterest.Text & _
                    ",Month_to_Pay=" & txtNoOfPayments.Text & _
                    ",ProdDescr='" & txtRemarks.Text.Replace("'", "").Replace("""", "") & _
                    "',MonthlyAmort=" & txtMonthly.Text & _
                    ",Recurring=" & IIf(chkRecurring.Checked, 1, 0) & _
                    ",FreqCd=" & cmbFreq.SelectedValue & _
                    ",SrcCurrCd='" & cmbSrcCurr.SelectedValue & _
                    "',TargetCurrCd='" & cmbTargetCurr.SelectedValue & _
                    "',DocNo='" & txtDocNo.Text & _
                    "',End_Date='" & Format(CDate(txtEndDate.Text), "yyyy/MM/dd") & _
                    "' where Id=" & Session("tid")
            Else 'add mode
                cm.CommandText = "insert into py_loan_hdr (Emp_Cd,Loan_Cd,Amt_Bal,Amt_Loan,Amt_Paid," & _
                    "Loan_Date,Start_Date,Int_Rate,Month_to_Pay,ProdDescr,MonthlyAmort,Recurring," & _
                    "Active,FreqCd,DocNo,End_Date,SrcCurrCd,TargetCurrCd) " & "values ('" & txtEmp.Text & "','" & _
                    txtLoanType.Text & "'," & txtBal.Text & _
                    "," & txtLoanAmt.Text & "," & txtAmtPaid.Text & ",'" & _
                    Format(CDate(txtLoanDate.Text), "yyyy/MM/dd") & "','" & _
                    Format(CDate(txtStartDate.Text), "yyyy/MM/dd") & "'," & _
                    txtInterest.Text & "," & txtNoOfPayments.Text & ",'" & _
                    txtRemarks.Text.Replace("'", "").Replace("""", "") & "'," & txtMonthly.Text & "," & _
                    IIf(chkRecurring.Checked, 1, 0) & ",1," & cmbFreq.SelectedValue & _
                    ",'" & txtDocNo.Text & "','" & Format(CDate(txtEndDate.Text), "yyyy/MM/dd") & _
                    "','" & cmbSrcCurr.SelectedValue & "','" & cmbTargetCurr.SelectedValue & "')"
            End If

            Try
                cm.ExecuteNonQuery()
                '''''''' update amortization loan schedule
                vScript = "syncAmort('" & txtEmp.Text & "','" & txtLoanType.Text & "','" & _
                    Format(CDate(txtLoanDate.Text), "yyyy/MM/dd") & "');"
            Catch ex As sqlclient.sqlexception
                vScript = "alert('Error occurred while updating/inserting Loan Ledger. Error is: " & _
                    ex.Message.Replace(vbCrLf, "\n").Replace("'", "") & "');"
                c.Close()
                cm.Dispose()
                c.Dispose()
            End Try
        End If
    End Sub

    Protected Sub vldDate_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles vldDate.ServerValidate
        vldDate.ErrorMessage = "Invalid date format."
        If txtLoanDate.Text = "" Then
            vScript = "alert('Loan date field should not be empty.');"
            args.IsValid = False
            Exit Sub
        End If
        If Not IsDate(txtLoanDate.Text) Then
            vScript = "alert('The Loan date field has an invalid date format.');"
            args.IsValid = False
            Exit Sub
        End If
        If txtStartDate.Text = "" Then
            vScript = "alert('Start Date of payment field should not be empty.');"
            vldDate.ErrorMessage = "Start Date of payment field should not be empty."
            args.IsValid = False
            Exit Sub
        End If
        If Not IsDate(txtStartDate.Text) Then
            vScript = "alert('Start Date of payment field has an invalid date format.');"
            vldDate.ErrorMessage = "Start Date of payment field has an invalid date format."
            args.IsValid = False
            Exit Sub
        End If
        If txtNoOfPayments.Text = "" Then
            vScript = "alert('# of payment field should not be empty.');"
            vldDate.ErrorMessage = "# of payment field should not be empty."
            args.IsValid = False
            Exit Sub
        End If
        If Not IsNumeric(txtNoOfPayments.Text) Then
            vScript = "alert('# of payment field should be numeric.');"
            vldDate.ErrorMessage = "# of payment field should be numeric."
            args.IsValid = False
            Exit Sub
        End If
        If txtInterest.Text = "" Then
            vScript = "alert('Interest Amount field should not be empty.');"
            vldDate.ErrorMessage = "Interest Amount field should not be empty."
            args.IsValid = False
            Exit Sub
        End If
        If Not IsNumeric(txtInterest.Text) Then
            vScript = "alert('Interest Amount field has an invalid numeric format.');"
            vldDate.ErrorMessage = "Interest Amount field has an invalid numeric format."
            args.IsValid = False
            Exit Sub
        End If
        If txtBal.Text = "" Then
            vScript = "alert('Balance field should not be empty.');"
            vldDate.ErrorMessage = "Balance field should not be empty."
            args.IsValid = False
            Exit Sub
        End If
        If txtLoanAmt.Text = "" Then
            vScript = "alert('Loan Amount field should not be empty.');"
            vldDate.ErrorMessage = "Loan Amount field should not be empty."
            args.IsValid = False
            Exit Sub
        End If
        If Not IsNumeric(txtLoanAmt.Text) Then
            vScript = "alert('Loan Amount field should be numeric.');"
            vldDate.ErrorMessage = "Loan Amount field should be numeric."
            args.IsValid = False
            Exit Sub
        End If
        If txtAmtPaid.Text = "" Then
            vScript = "alert('Amount paid field should not be empty.');"
            vldDate.ErrorMessage = "Amount paid field should not be empty."
            args.IsValid = False
            Exit Sub
        End If
        If Not IsNumeric(txtAmtPaid.Text) Then
            vScript = "alert('Amount paid field should be numeric.');"
            vldDate.ErrorMessage = "Amount paid field should be numeric."
            args.IsValid = False
            Exit Sub
        End If
        If txtMonthly.Text = "" Then
            vScript = "alert('Monthly Amortization field should not be empty.');"
            vldDate.ErrorMessage = "Monthly Amortization field should not be empty."
            args.IsValid = False
            Exit Sub
        End If
        If Not IsNumeric(txtMonthly.Text) Then
            vScript = "alert('Monthly Amortization field should be numeric.');"
            vldDate.ErrorMessage = "Monthly Amortization field should be numeric."
            args.IsValid = False
            Exit Sub
        End If

        If Val(cmbFreq.SelectedValue) = -1 Then
            vScript = "alert('You must first select from the list.');"
            vldDate.ErrorMessage = "You must first select from the list of frequency."
            args.IsValid = False
            Exit Sub
        End If
        If Not IsDate(txtEndDate.Text) Then
            vScript = "alert('End Date should not be empty.');"
            vldDate.ErrorMessage = "End Date should not be empty."
            args.IsValid = False
            Exit Sub
        End If
        args.IsValid = True
    End Sub

    Protected Sub txtLoanAmt_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtLoanAmt.Init
        txtLoanAmt.Attributes.Add("onblur", "compute();")
    End Sub

    Protected Sub txtInterest_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtInterest.Init
        txtInterest.Attributes.Add("onblur", "compute();")
    End Sub

    Protected Sub txtAmtPaid_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtAmtPaid.Init
        txtAmtPaid.Attributes.Add("onblur", "compute();")
    End Sub

    Protected Sub txtBal_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtBal.Init
        txtBal.Attributes.Add("onblur", "computeamtpaid();")
    End Sub

    Protected Sub txtNoOfPayments_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtNoOfPayments.Init
        txtNoOfPayments.Attributes.Add("onblur", "computeamort();")
    End Sub

    Protected Sub cmbFreq_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbFreq.SelectedIndexChanged
        If txtStartDate.Text = "" Or Not IsDate(txtStartDate.Text) Then
            vScript = "alert('Please enter a valid start date first.');"
            Exit Sub
        End If

        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                                               ''
        '' DATE MODIFIED: 2/16/2012                                                   ''
        '' PURPOSE:  TO SYNCHRONIZE THE CUT OFF DATES IN THE SELECTION INSTEAD OF THE ''
        ''           GENERIC LABEL "1ST OR 2ND PERIOD"                                ''
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        ''''''''''''''''''''''''''  OLD CODE '''''''''''''''''''''''''''''''''''''''''''
        'Select Case cmbFreq.SelectedValue
        '    Case "15"       'every 1st period
        '        txtEndDate.Text = CDate(txtEndDate.Text).AddMonths(Val(txtNoOfPayments.Text) - 1).Month & _
        '            "/" & cmbFreq.SelectedIndex & "/" & CDate(txtEndDate.Text).Year
        '    Case "30"       'every 2nd period
        '        txtEndDate.Text = DateAdd(DateInterval.Month, Val(txtNoOfPayments.Text), CDate(txtStartDate.Text))
        '        txtEndDate.Text = MonthEND(CDate(txtEndDate.Text))
        '    Case "0"       'every payroll
        '        txtEndDate.Text = DateAdd(DateInterval.Month, Val(txtNoOfPayments.Text) / 2, CDate(txtStartDate.Text))
        '    Case Else
        '        vScript = "alert('Please select method of deduction whether every payroll, every 1st period, or every 2nd period');"
        'End Select
        '''''''''''''''''''''''''''' END OLD CODE ''''''''''''''''''''''''''''''''''''''
        If cmbFreq.SelectedValue = -1 Then
            vScript = "alert('Please select method of deduction whether every payroll, every 1st period, or every 2nd period');"
        Else
            If Val(cmbFreq.SelectedValue) = 0 Then 'selected cut off is every payroll
                txtEndDate.Text = DateAdd(DateInterval.Month, Val(txtNoOfPayments.Text) / 2, CDate(txtStartDate.Text))
            ElseIf Val(cmbFreq.SelectedValue) >= 28 And Val(cmbFreq.SelectedValue) <= 31 Then
                'selected cut off is end of the month, re-align the data to the proper monthend depending on the selected month
                txtEndDate.Text = DateAdd(DateInterval.Month, Val(txtNoOfPayments.Text), CDate(txtStartDate.Text))
                txtEndDate.Text = MonthEND(CDate(txtEndDate.Text))
            Else    'select cut off is not end of the month
                txtEndDate.Text = CDate(txtStartDate.Text).AddMonths(Val(txtNoOfPayments.Text) - 1)
                txtEndDate.Text = CDate(txtEndDate.Text).Month & "/" & cmbFreq.SelectedValue & "/" & CDate(txtEndDate.Text).Year
            End If
        End If
        '''''''''''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''''''
    End Sub

    Protected Sub chkRecurring_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkRecurring.CheckedChanged
        If chkRecurring.Checked = True Then
            Me.lblEndDate.Visible = False
            Me.lblStart.Visible = False
            Me.txtStartDate.Visible = False
            Me.txtEndDate.Visible = False
        Else
            Me.lblEndDate.Visible = True
            Me.lblStart.Visible = True
            Me.txtStartDate.Visible = True
            Me.txtEndDate.Visible = True
        End If
    End Sub

    Protected Sub txtMonthly_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtMonthly.Init
        txtMonthly.Attributes.Add("onblur", "computenopayment();")
    End Sub

    Private Sub GeneratePayModes()
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALAIN                                  ''
        '' DATE MODIFIED: 2/11/2012                                      ''
        '' PURPOSE:  TO GET THE CUT OFF PERIODS OF THE RETRIEVED         ''
        ''           PAYMENT MODE ASSOCIATED TO THE EMPLOYEE             ''
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        Dim vPayCd As String = ""
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader

        cm.Connection = c

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace("'", "").Replace(vbCrLf, "") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        'get employee's payment mode
        cm.CommandText = "select Pay_Cd from py_emp_master where Emp_Cd='" & txtEmp.Text & "'"
        rs = cm.ExecuteReader
        vPayCd = ""
        If rs.Read Then
            vPayCd = rs("Pay_Cd")
        End If
        rs.Close()

        cmbFreq.Items.Clear()
        cmbFreq.Items.Add(New ListItem("Please select from the list...", -1))
        'GET THE CUT OFF DATES OF THE SELECTED PAY MODE             
        cm.CommandText = "select Days from py_pay_mode where Pay_Cd='" & vPayCd & "'"
        rs = cm.ExecuteReader
        If rs.Read Then
            Dim vDays() As String
            Dim i As Integer

            vDays = rs("Days").ToString.Split(",")
            'If UBound(vDays) > 0 Then   'selected payment mode has more than 1 cut off periods, include "Every Payroll" option
            cmbFreq.Items.Add(New ListItem("Every Payroll", 0))
            ' End If

            'now add the cut off period(s)
            For i = 0 To UBound(vDays)
                If vDays(i) - 1 <= 0 Then
                    cmbFreq.Items.Add(New ListItem("Every 30th cut-off", 30))
                Else
                    cmbFreq.Items.Add(New ListItem("Every " & vDays(i) - 1 & " cut-off", vDays(i) - 1))
                End If
            Next
        Else
            vScript = "alert('Payment Mode of the employee does not have any corresponding cut off dates. " & _
                "Please correct it under Payment Mode Reference module.');"
        End If
        rs.Close()
        c.Close()
        cm.Dispose()
        c.Dispose()
        '''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''''
    End Sub

    Protected Sub txtEmp_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtEmp.TextChanged
        Page.Validate()
        GeneratePayModes()
    End Sub

    Protected Sub CustomValidator1_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles CustomValidator1.ServerValidate
        If txtEmp.Text.Trim.Length = 0 Then
            args.IsValid = False
            CustomValidator1.ErrorMessage = "Employee Id should not be blank."
            vScript = "alert('Employee Id should not be blank.');"
            Exit Sub
        End If
        args.IsValid = True

        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to SQL Server. Error is: " & _
                ex.Message.Replace(vbCrLf, "\n").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        cm.Connection = c
        cm.CommandText = "SELECT (Emp_Lname+', '+Emp_Fname) AS Name FROM py_emp_master WHERE Emp_Cd = '" & _
            txtEmp.Text.Trim.Replace("'", "").Replace(";", "") & "'"

        Try
            rs = cm.ExecuteReader
            If Not rs.Read Then                
                txtEmp.Text = ""
                vScript = "document.form1.txtEmp.focus();alert('Invalid employee number.');"
                args.IsValid = False
                CustomValidator1.ErrorMessage = "Invalid employee Id"
                vScript = "alert('Invalid employee Id.');"
            Else
                txtEmpName.Text = IIf(IsDBNull(rs("Name")), "No Name", rs("Name"))
                vScript = ""
            End If
            rs.Close()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to retrieve the Employee Master file. Erros is: " & _
                ex.Message.Replace(vbCrLf, "\n").Replace("'", "") & "');"
        Finally
            c.Close()
            cm.Dispose()
            c.Dispose()
        End Try
    End Sub

    Protected Sub cmdUpload_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdUpload.Click
        vScript = "win=window.open('uploaddoc.aspx?id=" & txtEmp.Text & _
            "','win','top=250,left=250,height=150,width=280'); win.focus();"
    End Sub
End Class
