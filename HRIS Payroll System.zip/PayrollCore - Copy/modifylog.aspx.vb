
Imports denaro
Partial Class modifylog
    Inherits System.Web.UI.Page

    Public vScript As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            'Session("returnaddr") = "dailylog.aspx"
            'Server.Transfer("index.aspx")
            vScript = "alert('Your login session has expired.'); window.close();"
            Exit Sub
        End If
        If Not IsPostBack Then
            Dim c As New SqlClient.SqlConnection(connStr)
            Dim cm As New SqlClient.SqlCommand
            Dim cmref As New SqlClient.SqlCommand
            Dim dr As SqlClient.SqlDataReader = Nothing
            Dim drref As SqlClient.SqlDataReader = Nothing
            Dim vEmpId As String = ""
            Dim vTxnDate As Date
            

            lblCaption.Text = "Add/Modify Daily Time Log"
            'c.ConnectionString = connStr
            c.Open()

            Session.Remove("id")
            If Session("tdate") = "" And Request.Item("vModify") = "" Then 'add mode
                txtTranDate.Text = Format(Now, "short date")
                txtTranDate.ReadOnly = False
                txtOutDate.Text = Format(Now, "short date")
                cmbInHr.SelectedValue = Now.Hour
                cmbInMin.SelectedValue = Now.Minute
                cmbOutHr.SelectedValue = Now.Hour
                cmbOutMin.SelectedValue = Now.Minute
                Session("oldval") = "Emp Id=" & _
                    "|Trans. Date=" & txtTranDate.Text & _
                    "|Shift Cd=" & _
                    "|Start Time=" & _
                    "|End Time=" & _
                    "|Actual In=" & _
                    "|Actual Out=" & _
                    "|Remarks=" & _
                    "|EarlyOut="
            Else 'edit mode
                If Session("empid") = "" Then
                    vEmpId = Request.Item("vEmpCode")
                    vTxnDate = Request.Item("vDate")
                    Session("vModify") = Request.Item("vModify")
                Else
                    vEmpId = Session("empid")
                    vTxnDate = Session("tdate")
                End If

                txtTranDate.Text = vTxnDate
                txtTranDate.ReadOnly = True
                cm.Connection = c
                cmref.Connection = c

                cm.CommandText = "select Tran_Date,Emp_Cd,Time_In,Time_Out,Time_OutDate,Hrs_Worked," & _
                    "BrkHrs,Reason,Id, ShiftCd, EarlyOut from py_time_log where Emp_Cd='" & vEmpId & _
                    "' and Tran_Date='" & Format(CDate(vTxnDate), "yyyy/MM/dd") & "'"
                dr = cm.ExecuteReader

                If dr.Read Then
                    chkEarlyOut.Checked = dr("EarlyOut") = 1
                    BuildCombo("select ShiftCd, Descr from py_shift ShiftCd order by Descr", cmbShift, c)
                    cmbShift.SelectedValue = dr("ShiftCd")
                    Session("ShiftCd") = dr("ShiftCd")

                    cmref.CommandText = "select Start_Time, End_Time from py_shift where ShiftCd ='" & dr("ShiftCd") & "'"
                    drref = cmref.ExecuteReader
                    If drref.Read Then
                        txtSchedIn.Text = drref("Start_Time")
                        txtSchedOut.Text = drref("End_Time")
                    End If
                    drref.Close()
                    cmref.Dispose()


                    Dim vIn As Date = Nothing
                    Dim vOut As Date = Nothing

                    Session("id") = dr("Id")
                    If IsDBNull(dr("Time_In")) Then
                        vIn = Nothing
                    Else
                        If dr("Time_In") = "" Then
                            vIn = Nothing
                        Else
                            vIn = dr("Time_In")
                        End If
                    End If

                    If IsDBNull(dr("Time_Out")) Then
                        vOut = Nothing
                    Else
                        If dr("Time_Out") = "" Then
                            vOut = Nothing
                        Else
                            vOut = dr("Time_Out")
                        End If
                    End If

                    chkAbsent.Checked = IsDBNull(dr("Time_In")) And IsDBNull(dr("Time_Out"))

                    txtEmp.Text = PointData("select Emp_Cd,Emp_Lname+', '+Emp_Fname as name from " & _
                        "py_emp_master where Date_Resign is null and Date_Retired is null and DateHold is null " & _
                        "and DateDismissed is null and DateSuspended is null and Emp_Cd='" & vEmpId & "'")

                    txtTranDate.Text = dr("Tran_Date")
                    txtOutDate.Text = IIf(IsDBNull(dr("Time_OutDate")), "", dr("Time_OutDate"))
                    txtBrkHr.Text = IIf(IsDBNull(dr("BrkHrs")), 0, dr("BrkHrs"))


                    If IsDBNull(dr("Time_In")) Then
                        cmbInHr.SelectedValue = "00"
                        cmbInMin.SelectedValue = "00"
                    Else
                        cmbInHr.SelectedValue = Format(IIf(vIn.Hour > 12, vIn.Hour - 12, IIf(vIn.Hour = 0, 12, vIn.Hour)), "00")
                        cmbInMin.SelectedValue = Format(vIn.Minute, "00")
                        rdoTimeInAM.SelectedValue = IIf(vIn.Hour > 11, "PM", "AM")
                    End If
                    If IsDBNull(dr("Time_Out")) Then
                        cmbOutHr.SelectedValue = "00"
                        cmbOutMin.SelectedValue = "00"
                    Else
                        cmbOutHr.SelectedValue = Format(IIf(vOut.Hour > 12, vOut.Hour - 12, IIf(vOut.Hour = 0, 12, vOut.Hour)), "00")
                        cmbOutMin.SelectedValue = Format(vOut.Minute, "00")
                        rdoTimeOutAM.SelectedValue = IIf(vOut.Hour > 11, "PM", "AM")
                    End If
                    txtRemarks.Text = IIf(IsDBNull(dr("Reason")), "", dr("Reason"))

                    Session("oldval") = "Emp Id=" & vEmpId & _
                        "|Trans. Date=" & txtTranDate.Text & _
                        "|Shift Cd=" & cmbShift.SelectedValue & _
                        "|Start Time=" & txtSchedIn.Text & _
                        "|End Time=" & txtSchedOut.Text & _
                        "|Actual In=" & cmbInHr.SelectedValue & ":" & cmbInMin.SelectedValue & rdoTimeInAM.SelectedValue & _
                        "|Actual Out=" & cmbOutHr.SelectedValue & ":" & cmbOutMin.SelectedValue & rdoTimeOutAM.SelectedValue & _
                        "|Remarks=" & txtRemarks.Text & _
                        "|EarlyOut=" & chkEarlyOut.Checked
                End If
                dr.Close()
                cm.Dispose()
            End If
            txtEmp.Text = vEmpId
            txtEmpName.Text = GetRef("select Emp_Lname+', '+Emp_Fname as name from " & _
                "py_emp_master where Date_Resign is null and Date_Retired is null and DateHold is null " & _
                "and DateDismissed is null and DateSuspended is null and Emp_Cd='" & vEmpId & "'", vEmpId, c)

            c.Close()
            c.Dispose()
            txtActualOut.Value = Format(Val(cmbOutHr.SelectedValue) + IIf(rdoTimeOutAM.SelectedValue = "PM", 12, 0), "00") & ":" & _
                Format(Val(cmbOutMin.SelectedValue), "00") & ":00"
        End If
    End Sub

    Protected Sub vldTime_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles vldTime.ServerValidate

        If Not IsDate(txtOutDate.Text) Then
            vldTime.ErrorMessage = "Time Out date should be in date format!"
            args.IsValid = False
            Exit Sub
        End If
        vldTime.ErrorMessage = "Time out should be greater than Time In"

        If CDate(txtTranDate.Text & " " & cmbInHr.SelectedValue & ":" & cmbInMin.SelectedValue & ":00 " & rdoTimeInAM.SelectedValue) _
            > CDate(txtOutDate.Text & " " & cmbOutHr.SelectedValue & ":" & cmbOutMin.SelectedValue & ":00 " & rdoTimeOutAM.SelectedValue) Then
            args.IsValid = False
            Exit Sub
        Else
            args.IsValid = True
        End If

        Dim vEmpCd As String = txtEmp.Text

        'check existence of the data
        'If Session("tdate") = "" Or (Session("tdate") <> "" And Session("empid") <> vEmpCd And Session("tdate") <> txtTranDate.Text) Then
        '    Dim cm As New sqlclient.sqlcommand
        '    Dim dr As sqlclient.sqldatareader

        '    c.ConnectionString = connStr
        '    c.Open()
        '    cm.Connection = c
        '    cm.CommandText = "select Emp_Cd from py_time_log where Emp_cd='" & vEmpCd & _
        '        "' and Tran_Date='" & Format(CDate(txtTranDate.Text), "yyyy/MM/dd") & "'"
        '    dr = cm.ExecuteReader
        '    If dr.HasRows Then
        '        vldTime.ErrorMessage = ""
        '        vScript = "alert('Record already exist using Employee: " & txtEmp.Text & _
        '            " and Date In: " & txtTranDate.Text & "');"
        '        args.IsValid = False
        '    Else
        '        args.IsValid = True
        '    End If
        '    dr.Close()
        '    cm.Dispose()
        '    c.Close()
        'End If
    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click

        If Not IsDate(Me.txtTranDate.Text) Then
            vScript = "alert('Invalid Date In. Please enter a valid date');"
            Exit Sub
        End If

        If Not IsDate(Me.txtOutDate.Text) Then
            vScript = "alert('Invalid Time Out Date. Please enter a valid date');"
            Exit Sub
        End If

        Dim vInNow As String = cmbInHr.SelectedValue & ":" & cmbInMin.SelectedValue & ":00 " & rdoTimeInAM.SelectedValue
        Dim vOutNow As String = cmbOutHr.SelectedValue & ":" & cmbOutMin.SelectedValue & ":00 " & rdoTimeOutAM.SelectedValue

        vInNow = Format(CDate(vInNow), "HH:mm")
        vOutNow = Format(CDate(vOutNow), "HH:mm")

        If Page.IsValid Then
            Dim vName As String = txtEmpName.Text
            Dim vIn As String = cmbInHr.SelectedValue & ":" & cmbInMin.SelectedValue & ":00"
            Dim vOut As String = cmbOutHr.SelectedValue & ":" & cmbOutMin.SelectedValue & ":00"
            Dim vHrs As Single = 0
            Dim vSQL As String = ""
            Dim c As New SqlClient.SqlConnection
            Dim cm As New sqlclient.sqlcommand
            Dim vExQry As String = ""

            If chkAbsent.Checked Then
                vHrs = 0
                vIn = ""
                vOut = ""
            Else
                vHrs = DateDiff(DateInterval.Minute, CDate(txtTranDate.Text & " " & vInNow), CDate(txtOutDate.Text & " " & vOutNow)) / 60
            End If

            If Not txtRemarks.Text.Contains("Edited:") Then
                txtRemarks.Text = "Edited:" & txtRemarks.Text
            End If
            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c

            If Session("ModShift") = "yes" Then
                'clean record first
                vSQL = "delete from py_emp_time_sched where Emp_Cd='" & txtEmp.Text & "' and Date_Sched = '" & _
                        Format(CDate(txtTranDate.Text), "yyyy/MM/dd") & "'"
                cm.CommandText = vSQL
                cm.ExecuteNonQuery()

                'update employee time schedule
                If txtSchedOut.Text.Trim <> "" Then
                    vSQL = "insert into py_emp_time_sched (Emp_Cd,Date_Sched,ShiftCd,Start_Time,End_Time) values ('" & _
                        txtEmp.Text & "','" & Format(CDate(txtTranDate.Text), "yyyy/MM/dd") & "','" & _
                        cmbShift.SelectedValue & "','" & txtSchedIn.Text & "',"

                    If CDate(txtSchedOut.Text) < CDate(txtSchedIn.Text) Then
                        vSQL += "'" & txtSchedOut.Text & "')"
                    Else
                        vSQL += "'" & txtSchedOut.Text & "')"
                    End If
                    cm.CommandText = vSQL
                    cm.ExecuteNonQuery()
                End If

                vExQry = ", ShiftCd='" & cmbShift.SelectedValue & "', "

                If txtSchedIn.Text.Trim = "" Then
                    vExQry += "Sched_In='', Sched_Out='' "
                Else
                    vExQry += "Sched_In='" & Format(CDate(txtTranDate.Text), "yyyy/MM/dd") & " " & txtSchedIn.Text & "', "
                    If CDate(txtSchedOut.Text) < CDate(txtSchedIn.Text) Then
                        vExQry += "Sched_Out='" & Format(CDate(txtTranDate.Text).AddDays(1), "yyyy/MM/dd") & " " & txtSchedOut.Text & "' "
                    Else
                        vExQry += "Sched_Out='" & Format(CDate(txtTranDate.Text), "yyyy/MM/dd") & " " & txtSchedOut.Text & "' "
                    End If
                End If
            End If

            'If Session("vModify") = "Modify" Then
            '    vSQL = "update py_time_log set Time_In=" & IIf(chkAbsent.Checked, "null", "'" & vInNow & "'") & _
            '        ",Time_Out=" & IIf(chkAbsent.Checked, "null", "'" & vOutNow & "'") & _
            '        ",Time_OutDate=" & IIf(chkAbsent.Checked, "null", "'" & Format(CDate(txtOutDate.Text), "yyyy/MM/dd") & "'") & _
            '        ",Hrs_Worked=" & IIf(chkAbsent.Checked, 0, vHrs) & _
            '        ",Reason='" & txtRemarks.Text.Replace("'", "") & "' " & vExQry & " where " & _
            '        "Tran_Date='" & txtTranDate.Text & "' and Emp_Cd=" & txtEmp.Text

            'Else
            If Session("tdate") <> "" Or Session("vModify") = "Modify" Then  'edit mode
                'vSQL = "update py_time_log set Time_In=" & IIf(chkAbsent.Checked, "null", "'" & vInNow & "'") & _
                '    ",Time_Out=" & IIf(chkAbsent.Checked, "null", "'" & vOutNow & "'") & _
                '    ",Time_OutDate=" & IIf(chkAbsent.Checked, "null", "'" & Format(CDate(txtOutDate.Text), "yyyy/MM/dd") & "'") & _
                '    ",Hrs_Worked=" & IIf(chkAbsent.Checked, 0, vHrs) & _
                '    ",Reason='" & txtRemarks.Text.Replace("'", "") & "' where Id=" & Session("empid")
                If chkEarlyOut.Checked Then
                    txtRemarks.Text = "Early Out. Original Logout is: " & txtActualOut.Value & vbNewLine & _
                        txtRemarks.Text
                End If
                vSQL = "update py_time_log set EarlyOut=" & IIf(chkEarlyOut.Checked, 1, 0) & _
                    ",Time_In=" & IIf(chkAbsent.Checked, "null", "'" & vInNow & "'") & _
                    ",Time_Out=" & IIf(chkAbsent.Checked, "null", "'" & vOutNow & "'") & _
                    ",Time_OutDate=" & IIf(chkAbsent.Checked, "null", "'" & Format(CDate(txtOutDate.Text), "yyyy/MM/dd") & "'") & _
                    ",Hrs_Worked=" & IIf(chkAbsent.Checked, 0, vHrs) & _
                    ",Reason='" & txtRemarks.Text.Replace("'", "") & "'" & _
                    IIf(chkEarlyOut.Checked, ",OrgTimeOut='" & txtActualOut.Value & "' ", " ") & vExQry & _
                    " where Emp_Cd='" & txtEmp.Text & _
                    "' and Tran_Date='" & Format(CDate(txtTranDate.Text), "yyyy/MM/dd") & "'"
            Else
                vSQL = "insert into py_time_log (EarlyOut,Tran_Date,Emp_Cd,Emp_Name,Time_In,Time_Out,Time_OutDate,Hrs_Worked," & _
                    "BrkHrs,Reason,Type,ShiftCd,Sched_In,Sched_Out" & IIf(chkEarlyOut.Checked, ",OrgTimeOut", "") & _
                    ") values (" & IIf(chkEarlyOut.Checked, 1, 0) & ",'" & Format(CDate(txtTranDate.Text), "yyyy/MM/dd") & "','" & _
                    txtEmp.Text & "','" & vName & "'," & IIf(chkAbsent.Checked, "null", "'" & vInNow & "'") & "," & _
                    IIf(chkAbsent.Checked, "null", "'" & vOutNow & "'") & "," & _
                    IIf(chkAbsent.Checked, "null", "'" & Format(CDate(txtOutDate.Text), "yyyy/MM/dd") & "'") & "," & _
                    IIf(chkAbsent.Checked, "null", vHrs) & "," & IIf(chkAbsent.Checked, "null", txtBrkHr.Text) & _
                    ",'" & txtRemarks.Text.Replace("'", "") & "','99','" & cmbShift.SelectedValue & "',"
                If txtSchedIn.Text.Trim = "" Then
                    vSQL += "'',''"
                Else
                    If CDate(txtSchedOut.Text) < CDate(txtSchedIn.Text) Then
                        vSQL += "'" & Format(CDate(txtTranDate.Text), "yyyy/MM/dd") & " " & txtSchedIn.Text & "', " & _
                            "'" & Format(CDate(txtTranDate.Text).AddDays(1), "yyyy/MM/dd") & " " & txtSchedOut.Text & "'"
                    Else
                        vSQL += "'" & Format(CDate(txtTranDate.Text), "yyyy/MM/dd") & " " & txtSchedIn.Text & "', " & _
                            "'" & Format(CDate(txtTranDate.Text), "yyyy/MM/dd") & " " & txtSchedOut.Text & "'"
                    End If
                End If
                If chkEarlyOut.Checked Then
                    vSQL += ",'" & txtActualOut.Value & "'"
                End If
                vSQL += ")"
            End If
            'End If

            cm.CommandText = vSQL
            cm.ExecuteNonQuery()
            vScript = "alert('Record successfully saved! Click the Refresh/View button again to refresh the page.');"

            If Session("tdate") = "" Then 'add mode 
                txtTranDate.Text = DateAdd(DateInterval.Day, 1, CDate(txtTranDate.Text))
                txtOutDate.Text = txtTranDate.Text
                txtRemarks.Text = ""
                txtBrkHr.Text = 0
            End If

            Session("newval") = "Emp Id=" & txtEmp.Text & _
                "|Trans. Date=" & txtTranDate.Text & _
                "|Shift Cd=" & cmbShift.SelectedValue & _
                "|Start Time=" & txtSchedIn.Text & _
                "|End Time=" & txtSchedOut.Text & _
                "|Actual In=" & cmbInHr.SelectedValue & ":" & cmbInMin.SelectedValue & rdoTimeInAM.SelectedValue & _
                "|Actual Out=" & cmbOutHr.SelectedValue & ":" & cmbOutMin.SelectedValue & rdoTimeOutAM.SelectedValue & _
                "|Remarks=" & txtRemarks.Text & _
                "|EarlyOut=" & IIf(chkEarlyOut.Checked, "yes", "no")
            EventLog(Session("uid"), Request.ServerVariables("REMOTE_ADDR"), IIf(Session("vModify") = "Modify", "MODIFY", "ADD"), _
                Session("oldval"), Session("newval"), "Employee ID: " & txtEmp.Text & _
                " Time Log was modified", "Daily Log", c)

            cm.Dispose()
            c.Close()
            c.Dispose()
            Session.Remove("Id")
            Session.Remove("tdate")
            Session.Remove("empid")
            Session.Remove("vModify")
            Session.Remove("ModShift")
            Session.Remove("ShiftCd")
            Session.Remove("oldval")
            Session.Remove("newval")
            'vScript += " window.opener.location.reload(true);"
            vScript += "self.close();"
        End If
    End Sub
    Protected Sub txtTranDate_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtTranDate.Init
        txtTranDate.Attributes.Add("onblur", "document.getElementById('txtOutDate').value = this.value;")
    End Sub

    Protected Sub cmbShift_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbShift.SelectedIndexChanged
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader

        Session("ModShift") = "yes"

        c.Open()
        cm.Connection = c

        cm.CommandText = "select Start_Time, End_Time from py_shift where ShiftCd ='" & cmbShift.SelectedItem.Value & "'"

        Try
            rs = cm.ExecuteReader
            If rs.Read Then
                txtSchedIn.Text = IIf(IsDBNull(rs("Start_Time")), "", rs("Start_Time"))
                txtSchedOut.Text = IIf(IsDBNull(rs("End_Time")), "", rs("End_Time"))
            End If
        Catch ex As SqlClient.SqlException
            c.Close()
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try
        rs.Close()
        cm.Dispose()
        c.Close()
    End Sub
    Protected Sub chkEarlyOut_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkEarlyOut.Init
        chkEarlyOut.Attributes.Add("onclick", "early();")
    End Sub
End Class
