Imports denaro
Partial Class modifyresult
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Dim c As New sqlclient.sqlconnection
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Session("returnaddr") = "trainingresults.aspx"
            Server.Transfer("index.aspx")
        End If
        If Not IsPostBack Then
            lblcaption.text = "Modify training results"
            Dim cm As New sqlclient.sqlcommand
            Dim dr As sqlclient.sqldatareader
            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c
            cm.CommandText = "select Result from hr_seminar_ref where Seminar_No='" & Session("semno") & "'"
            dr = cm.ExecuteReader
            If dr.Read Then
                txtResult.Text = IIf(IsDBNull(dr("Result")), "", dr("Result"))
            End If
            dr.Close()
            cm.Dispose()
            c.Close()
        End If
    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        Dim cm As New sqlclient.sqlcommand

        txtResult.Text = txtResult.Text.Replace("'", "")
        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c
        cm.CommandText = "update hr_seminar_ref set Result='" & txtResult.Text & _
            "' where Seminar_No='" & Session("semno") & "'"
        cm.ExecuteNonQuery()
        cm.Dispose()
        c.Close()
        vScript = "alert('Changes were successfully saved. After closing this window, clickt the seminar again to view the changes.'); window.close();"
    End Sub
End Class
