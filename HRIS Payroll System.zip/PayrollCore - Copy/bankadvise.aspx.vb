Imports denaro
Partial Class bankadvise
    Inherits System.Web.UI.Page
    Public vScript As String = ""

    Public vSrc As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If

        txtRank.Text = Request.Form("txtRank")
        If Not IsPostBack Then
            If Not CanRun(Session("caption"), Request.Item("id")) Then
                Session("denied") = "1"
                Server.Transfer("main.aspx")
                Exit Sub
            End If
            lblCaption.Text = "Print and download Bank Advise"
            'BuildCombo("select distinct CAST(MONTH(FromDate) as VARCHAR) + '/' + CAST(DAY(FromDate) AS VARCHAR) + " & _
            '    "'/' + CAST(YEAR(FromDate) AS VARCHAR) as FromDate," & _
            '    "CAST(MONTH(FromDate) AS VARCHAR) + '/' + CAST(DAY(FromDate) AS VARCHAR) + '/' + CAST(YEAR(FromDate) AS VARCHAR) + " & _
            '    "'-'+CAST(MONTH(ToDate) AS VARCHAR) + '/' + CAST(DAY(ToDate) AS VARCHAR) + '/' + CAST(YEAR(ToDate) AS VARCHAR) AS Descr " & _
            '    "from py_report where YEAR(PayDate)=" & Now.Year & " order by FromDate desc", cmbCutOff)
            BuildCombo("select distinct CAST(MONTH(FromDate) AS VARCHAR) + '/' + CAST(DAY(FromDate) AS VARCHAR) + '/' + CAST(YEAR(FromDate) AS VARCHAR) + " & _
                "'-'+CAST(MONTH(ToDate) AS VARCHAR) + '/' + CAST(DAY(ToDate) AS VARCHAR) + '/' + CAST(YEAR(ToDate) AS VARCHAR) as FromDate," & _
                "CAST(MONTH(FromDate) AS VARCHAR) + '/' + CAST(DAY(FromDate) AS VARCHAR) + '/' + CAST(YEAR(FromDate) AS VARCHAR) + " & _
                "'-'+CAST(MONTH(ToDate) AS VARCHAR) + '/' + CAST(DAY(ToDate) AS VARCHAR) + '/' + CAST(YEAR(ToDate) AS VARCHAR) AS Descr " & _
                "from py_report where YEAR(PayDate)=" & Now.Year & " order by FromDate desc", cmbCutOff)
            BuildCombo("select Bank_Code,Bank_Name from bank_codes", cmbBank)
            BuildCombo("select Rc_Cd,Descr from rc where exists (select User_Id from rights_list where User_Id='" & _
                    Session("uid") & "' and property='rc' and Property_Value=Rc_Cd) order by Descr", cmbRC)
            BuildCombo("select AgencyCd,AgencyName from agency where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='agency' and Property_Value=AgencyCd) order by AgencyName", cmbOffice)
            BuildCombo("select Div_Cd,Descr from hr_div_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='division' and Property_Value=Div_Cd) order by Descr", cmbDiv)
            'BuildCombo("select EmploymentType,Descr from hr_employment_type where exists (select User_Id from rights_list where User_Id='" & _
            'Session("uid") & "' and property='employmenttype' and Property_Value=EmploymentType) order by Descr", cmbType)
            'BuildCombo("select Status_Code,Descr from py_employee_stat order by Descr", cmbStatus)

            cmbRC.Items.Add("All")
            cmbDiv.Items.Add("All")
            'cmbType.Items.Add("All")
            cmbRC.SelectedValue = "All"
            cmbOffice.Items.Add("All")
            cmbOffice.SelectedValue = "All"
            'cmbType.SelectedValue = "All"
            cmbDiv.SelectedValue = "All"

            GetPayDate()
        End If
    End Sub
    Private Sub GetPayDate()
        If cmbCutOff.Items.Count > 0 Then
            Dim c As New SqlClient.SqlConnection
            Dim cm As New SqlClient.SqlCommand
            Dim dr As SqlClient.SqlDataReader
            Dim vDates() As String = cmbCutOff.SelectedItem.ToString.Split("-")

            txtFrom.Value = vDates(0)
            txtTo.Value = vDates(1)
            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c
            'cm.CommandText = "select PayDate from py_report where FromDate='" & _
            '    Format(CDate(cmbCutOff.SelectedValue), "yyyy/MM/dd") & "'"
            cm.CommandText = "select PayDate from py_report where FromDate='" & _
                Format(CDate(vDates(0)), "yyyy/MM/dd") & "' and ToDate='" & _
                Format(CDate(vDates(1)), "yyyy/MM/dd") & "'"
            dr = cm.ExecuteReader
            If dr.Read Then
                txtPayDate.Text = Format(dr("PayDate"), "MM/dd/yyyy")
                txtCreditDate.Text = txtPayDate.Text
            End If
            dr.Close()
            cm.Dispose()
            c.Close()
            c.Dispose()
        End If
    End Sub

    Protected Sub cmbCutOff_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbCutOff.SelectedIndexChanged
        GetPayDate()
    End Sub

    Protected Sub cmdReturn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.Click
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub cmdSetup_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSetup.Click
        If cmbOffice.SelectedValue <> "All" Then
            Session("ofc") = cmbOffice.SelectedValue
            vScript = "editwin=window.open('setupadvise.aspx','empwin','toolbar=no,location=no,width=400,height=200,top=100,left=100');"
        Else
            vScript = "alert('You must first select an Company to continue.');"
        End If
    End Sub

    Protected Sub cmdRefresh_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdRefresh.Click
        Dim vRc As String = ""
        Dim vOfc As String = ""
        Dim vDiv As String = ""
        Dim vSecurity As String = ""
        Dim vEmpList As String = ""
        Dim vDump As String = ""
        Dim vCompanyCd As String = ""
        Dim vBranchCd As String = ""
        Dim vBatchNo As String = ""
        Dim vQuery As String = ""
        Dim vFilename As String = ""

        If txtPayDate.Text = "" Then
            vScript = "alert('Please select cut-off period first.');"
            Exit Sub
        End If

        If cmbRC.SelectedValue <> "All" Then
            vRc = " and {report.Rc_Cd}='" & cmbRC.SelectedValue & "'"
            vQuery = " and Rc_Cd='" & cmbRC.SelectedValue & "'"
        Else
            vRc = " and {report.Rc_Cd} in ('" & Session("rclist") & "')"
            vQuery = " and Rc_Cd in ('" & Session("rclist").ToString.Replace(",", "','") & "') "
        End If
        If cmbOffice.SelectedValue <> "All" Then
            vOfc = " and {report.Agency_Cd}='" & cmbOffice.SelectedValue & "'"
            '                "' and {syscntrl.AgencyCd}='" & cmbOffice.selectedvalue & "'"
            vQuery += " and Agency_Cd='" & cmbOffice.SelectedValue & "'"
        Else
            vOfc = " and {report.Agency_Cd} in ('" & Session("agencylist") & "')"
            vQuery += " and Agency_Cd in ('" & Session("agencylist").ToString.Replace(",", "','") & "') "
        End If

        Dim c As New SqlClient.SqlConnection
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim vType As String = ""
        'If cmbType.SelectedValue <> "All" Then
        'vType = " and EmploymentType='" & cmbType.SelectedValue & "'"
        'Else
        'vType = " and EmploymentType in ('" & _
        'Session("typelist").ToString.Replace(",", "','") & "') "
        'End If
        If cmbDiv.SelectedValue <> "All" Then
            vDiv = " and DivCd='" & cmbDiv.SelectedValue & "'"
        Else
            vDiv = " and DivCd in ('" & _
                Session("divlist").ToString.Replace(",", "','") & "') "
        End If
        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c
        cm.CommandText = "select CompanyCd,BranchCd from glsyscntrl "
        If cmbOffice.SelectedValue <> "All" Then
            cm.CommandText += " where AgencyCd='" & cmbOffice.SelectedValue & "'"
        Else
            'cm.CommandText += " where AgencyCd in ('" & Session("agencylist").ToString.Replace(",", "','") & "')"
            'cm.CommandText += " limit 1"
        End If
        rs = cm.ExecuteReader
        If rs.Read Then
            If IsDBNull(rs(0)) Or rs(0) = "" Then
                vScript = "alert('Company Code is not yet defined. Please click the setup button.');"
                rs.Close()
                cm.Dispose()
                c.Close()
                Exit Sub
            End If
            vCompanyCd = rs(0)
            'If IsDBNull(rs(1)) Or rs(1) = "" Then
            If IsDBNull(rs(1)) Then
                vScript = "alert('Originating Branch code is not yet defined. Please click the setup button.');"
                rs.Close()
                cm.Dispose()
                c.Close()
                Exit Sub
            End If
            vBranchCd = rs(1)
        End If
        rs.Close()
        cm.CommandText = "select BatchNo from py_syscntrl"
        rs = cm.ExecuteReader
        If rs.Read Then
            If IsDBNull(rs(0)) Or rs(0) = "" Then
                vScript = "alert('Batch No is not yet defined. Please click the setup button.');"
                rs.Close()
                cm.Dispose()
                c.Close()
                Exit Sub
            End If
            vBatchNo = rs(0)
        End If
        rs.Close()
        If rdoType.SelectedValue <> "NA" Then
            cm.CommandText = "select Emp_Cd from py_emp_master where Date_Resign is null and " & _
                "DateSuspended is null and DateHold is null and Date_Retired is null and Bank_Type='" & _
                 rdoType.SelectedValue & "'" & vType & vDiv
        Else    'no accounts
            cm.CommandText = "select Emp_Cd from py_emp_master where Date_Resign is null and " & _
                "DateSuspended is null and DateHold is null and Date_Retired is null and " & _
                "(Acct_No='' or Acct_No is null) " & vType & vDiv
        End If

        rs = cm.ExecuteReader
        Do While rs.Read
            vEmpList += rs("Emp_Cd") & ","
        Loop
        rs.Close()
        cm.Dispose()

        If vEmpList <> "" Then
            vEmpList = Mid(vEmpList, 1, vEmpList.Length - 1)
        End If
        'vSecurity = " and {report.Emp_Cd} in ('" & vEmpList & "')"
        'start dumping the record to disk ''''''''''''''''''''
        'Select Case rdoType.SelectedValue
        '    Case "SA"
        '        Select Case cmbBank.SelectedValue
        '            Case "RCBC"
        '                vDump = GenSA(vQuery, vEmpList, vCompanyCd, vBranchCd)
        '            Case "BDO"
        '                vDump = BDOAdvise(vQuery, vEmpList)
        '            Case "BPI"
        '                vDump = BPIAdvise()
        '        End Select
        '    Case "CA"
        '        Select Case cmbBank.SelectedValue
        '            Case "RCBC"
        '                vDump = GenCA(vQuery, vEmpList, vCompanyCd, vBranchCd)
        '            Case "BDO"
        '                vDump = BDOAdvise(vQuery, vEmpList)
        '            Case "BPI"
        '                vDump = BPIAdvise()
        '        End Select
        'End Select
        c.Close()
        c.Dispose()
        ''''''''''''''' write to file ''''''''''''''''''''''''
        vFilename = vCompanyCd & IIf(rdoType.SelectedValue = "SA", "PS", "PC") & _
            Format(CDate(txtPayDate.Text).Month, "00") & _
            Format(CDate(txtPayDate.Text).Day, "00") & _
            vBatchNo & ".txt"
        IO.File.WriteAllText(Server.MapPath("") & "\downloads\" & vFilename, vDump)
        '''''''''''''''''' end write '''''''''''''''''''''''''
        'lnkDownload.NavigateUrl = "downloads/" & vFilename
        'lnkDownload.Visible = True

        Try
            'rptSource.Report.FileName = "reports/bankadvise.rpt"
            ''rpt.SelectionFormula = "{report.PayDate}=#" & Format(CDate(txtPayDate.Text), "yyyy/MM/dd") & _
            ''    "# " & vRc & vOfc & vSecurity
            'rpt.SelectionFormula = "{report.PayDate}=#" & Format(CDate(txtPayDate.Text), "yyyy/MM/dd") & _
            '    "# "
            'rpt.RefreshReport()
        Catch ex As IO.IOException
            vScript = "alert('Error occurred! Error Code: " & ex.Message & "');"
        End Try
    End Sub
    '    Private Function BPIAdvise() As String
    '        Dim c As New SqlClient.SqlConnection(connStr)
    '        Dim cm As New SqlClient.SqlCommand
    '        Dim rs As SqlClient.SqlDataReader
    '        Dim vType As String = ""
    '        Dim vBr As String = ""
    '        Dim iGrndTot As Decimal = 0
    '        Dim vAmt As Decimal = 0
    '        Dim vHash As Double = 0
    '        Dim iAcctHash As Double = 0
    '        Dim vEmpAcctNo As String = 0
    '        Dim iCountHash As Double = 0
    '        Dim iCountAcctHash As Double = 0
    '        Dim iCount As Integer = 0
    '        Dim iCtr As Integer = 0
    '        Dim vDate As Date = CDate(txtPayDate.Text)
    '        Dim vMax As Decimal = 0
    '        Dim vTotal As Decimal = 0
    '        Dim vDateNow As Date = Now
    '        Dim vData As String = ""
    '        Dim vPrn As New VSPrinter8Lib.VSPrinter
    '        Dim vpdf As New VSPDF8Lib.VSPDF8
    '        Dim vFormat As String = ""
    '        Dim vCompany As String = ""
    '        Dim vCompCd As String = ""
    '        Dim vAcctNo As String = ""

    '        'variables used for downloading to text files
    '        Dim vStr As String = ""
    '        Dim vHdr As String = ""

    '        c.Open()
    '        cm.Connection = c

    '        cm.CommandText = "SELECT MAX(Amount_Per), SUM(Amount_Per) FROM py_report WHERE " & _
    '                         "PayDate='" & vDate & "'"
    '        rs = cm.ExecuteReader
    '        If rs.Read Then
    '            vMax = IIf(IsDBNull(rs(0)), 0, rs(0))
    '            vTotal = IIf(IsDBNull(rs(1)), 0, rs(1))
    '        End If
    '        rs.Close()

    '        With vPrn

    '            cm.CommandText = "SELECT Company_Name,CompanyCd FROM GLSYSCNTRL WHERE AgencyCd='" & _
    '                cmbOffice.SelectedValue & "'"
    '            rs = cm.ExecuteReader
    '            If rs.Read Then
    '                vCompany = IIf(IsDBNull(rs(0)), "Unknown", rs(0))
    '                vCompCd = IIf(IsDBNull(rs("COMPANYCD")), "", rs("COMPANYCD"))
    '            End If
    '            rs.Close()

    '            cm.CommandText = "SELECT BankAcctNo FROM PY_SYSCNTRL"
    '            rs = cm.ExecuteReader
    '            If rs.Read Then
    '                vAcctNo = IIf(IsDBNull(rs("BankAcctNo")), "Unknown", rs("BankAcctNo"))
    '            End If
    '            rs.Close()

    '            .Orientation = VSPrinter8Lib.OrientationSettings.orPortrait
    '            .FontName = "Arial"
    '            .FontSize = 12
    '            .Action = VSPrinter8Lib.ActionSettings.paStartDoc
    '            .FontBold = True
    '            .TextAlign = VSPrinter8Lib.TextAlignSettings.taCenterBottom
    '            .Paragraph = vCompany & vbCrLf
    '            .FontSize = 10
    '            vFormat = ">2000|<3700|>2000|<2700;"
    '            vData = "Company Code:|" & vCompCd & "|Comp. Acct. #.:|" & vAcctNo & ";" & _
    '                       "Payroll Date:|" & Format(vDateNow, "SHORT DATE") & _
    '                       "|Payroll Amount:|" & Format(vTotal, "##,##0.00") & ";" & _
    '                       "Batch Number:|01|Ceiling Amount:|" & Format(vMax, "##,##0.00") & ";"
    '            .TableBorder = VSPrinter8Lib.TableBorderSettings.tbNone
    '            .Table = vFormat & vData
    '            .Text = vbCrLf
    '            vFormat = "<3467|>3467|>3466;"
    '            vData = "Emp. Acct. Nos.|Transaction Amount|Horizontal Hash;"
    '            .TextAlign = VSPrinter8Lib.TextAlignSettings.taCenterBottom
    '            .TableBorder = VSPrinter8Lib.TableBorderSettings.tbBottom
    '            .Table = vFormat & vData
    '            .TableBorder = VSPrinter8Lib.TableBorderSettings.tbNone
    '            .FontBold = False

    '            iCountHash = 0
    '            iGrndTot = 0
    '            iCountAcctHash = 0
    '            iCount = 0
    '            vData = ""

    '            vStr = "H10335" & Format(Month(vDateNow), "00") & _
    '               Format(Day(vDateNow), "00") & Format(2000 - Year(vDateNow), "00") & _
    '               "0111921103359192" & Format(vMax * 100, "000000000000") & _
    '               Format(vTotal * 100, "000000000000") & "1" & Space(75)

    '            cm.CommandText = "SELECT Bank_Type, Bank_Code, Acct_No,Amount_Per " & _
    '                             "FROM py_emp_master, py_report WHERE py_emp_master.Emp_Cd=py_report.Emp_Cd AND " & _
    '                             "Date_Resign IS NULL AND Acct_No IS NOT NULL AND Acct_No != '' AND PayDate='" & vDate & "' " & _
    '                             "ORDER BY Bank_Type, Bank_Code, Acct_No"
    '            rs = cm.ExecuteReader

    '            Do While rs.Read
    '                vAmt = Math.Round(rs("AMOUNT_PER"), 2)
    '                vEmpAcctNo = Replace(rs("acct_no"), "-", "")
    '                iAcctHash = 0

    '                If vEmpAcctNo.Length < 10 Then
    '                    vScript = "alert('Invalid account number : " & vEmpAcctNo & "');"
    '                    Return ""
    '                    GoTo Here 'exit
    '                End If

    '                For iCtr = 1 To 10
    '                    iAcctHash = iAcctHash + Int(Mid(vEmpAcctNo, iCtr, 1))
    '                Next iCtr
    '                vHash = Math.Round(((Int(Mid(vEmpAcctNo, 5, 1)) + _
    '                        Int(Mid(vEmpAcctNo, 6, 1))) * vAmt) + _
    '                        ((Int(Mid(vEmpAcctNo, 7, 1)) + _
    '                        Int(Mid(vEmpAcctNo, 8, 1))) * vAmt) + _
    '                        ((Int(Mid(vEmpAcctNo, 9, 1)) + _
    '                        Int(Mid(vEmpAcctNo, 10, 1))) * vAmt), 2)

    '                vData = vData & rs("ACCT_NO") & "|" & Format(rs("AMOUNT_PER"), "##,##0.00") & _
    '                        "|" & Format(vHash, "###,##0.00") & ";"

    '                vStr = "D10335" & Format(Month(vDateNow), "00") & _
    '                   Format(Day(vDateNow), "00") & Format(2000 - Year(vDateNow), "00") & _
    '                   "013" & vEmpAcctNo & Format(rs("AMOUNT_PER") * 100, "000000000000") & _
    '                   Format(vHash * 100, "000000000000") & Space(79)

    '                iCountHash = iCountHash + vHash
    '                iGrndTot = iGrndTot + vAmt
    '                iCountAcctHash = iCountAcctHash + iAcctHash
    '                iCount = iCount + 1
    '            Loop
    '            rs.Close()
    '            vStr = "T10335" & Format(Month(vDateNow), "00") & _
    '                  Format(Day(vDateNow), "00") & Format(Year(vDateNow) - 2000, "00") & _
    '                  "0121921103359" & Format(iCountAcctHash, "000000000000000") & _
    '                  Format(iGrndTot * 100, "000000000000000") & _
    '                  Format(iCountHash, "000000000000000000") & _
    '                  Format(iCount, "00000") & Space(50)

    '            .Table = vFormat & vData
    '            .FontBold = True
    '            vData = ";;" & Format(iCountAcctHash, "###,##0") & "|" & Format(iGrndTot, "###,##0.00") & "|" & _
    '               Format(iCountHash, "#,###,##0.00") & ";" & Format(iCount, "#,##0")
    '            .Table = vFormat & vData
    '            .FontBold = False
    '            .TextAlign = VSPrinter8Lib.TextAlignSettings.taCenterBottom
    '            vFormat = "^3000|^3000|^3000;;;;;;;;"

    '            vData = "_____________________||_____________________;" & _
    '               "Prepared By||Approved By;"

    '            .Table = vFormat & vData
    '            .Action = VSPrinter8Lib.ActionSettings.paEndDoc
    '        End With
    '        vpdf.ConvertDocument(vPrn, Server.MapPath("") & "\downloads\" & Session.SessionID & "-bankadvise.pdf")
    '        vPrn = Nothing
    '        vpdf = Nothing
    '        vSrc = "downloads/" & Session.SessionID & "-bankadvise.pdf"
    '        Return vStr
    'Here:
    '        c.Close()
    '        c.Dispose()
    '        cm.Dispose()
    '    End Function
    'Private Function BDOAdvise(ByVal pQuery As String, ByVal pEmpList As String) As String
    '    Dim c As New SqlClient.SqlConnection(connStr)
    '    Dim cm As New SqlClient.SqlCommand
    '    Dim dr As SqlClient.SqlDataReader
    '    Dim vDump As String = ""
    '    Dim vAmount As Decimal = 0

    '    If txtPayDate.Text = "" Then
    '        vScript = "alert('Please select cut-off period first.');"
    '        cm.Dispose()
    '        c.Close()
    '        c.Dispose()
    '        Return ""
    '        Exit Function
    '    End If

    '    c.Open()
    '    cm.Connection = c
    '    cm.CommandText = "select PayDate,Rc_Cd,Agency_Cd,Name, Emp_Cd, Report_No as AcctNo, " & _
    '        "Amount_per from py_report where PayDate='" & Format(CDate(txtPayDate.Text), "yyyy/MM/dd") & _
    '        "' " & pQuery & " and Emp_Cd in ('" & pEmpList.Replace(",", "','") & "') order by Name"
    '    dr = cm.ExecuteReader
    '    Do While dr.Read
    '        vDump += Format(Val(dr("AcctNo").ToString.Substring(0, 10)), "0000000000") & Space(6)
    '        vAmount = dr("Amount_Per")
    '        vDump += Format(vAmount, "######0.00") & vbCrLf
    '    Loop
    '    dr.Close()
    '    cm.Dispose()
    '    c.Close()
    '    c.Dispose()
    '    BDOAdvise = vDump
    'End Function
    Private Function GenSA(ByVal pQuery As String, ByVal pEmpList As String, ByVal pCompCd As String, ByVal pBranchCd As String) As String
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim dr As SqlClient.SqlDataReader
        Dim vDump As String = ""
        Dim vAmount As Decimal = 0
        Dim vHash As Decimal = 0
        Dim vTotal As Decimal = 0
        Dim vTrailerHash As Decimal = 0


        If txtPayDate.Text = "" Then
            vScript = "alert('Please select cut-off period first.');"
            cm.Dispose()
            c.Close()
            c.Dispose()
            Return ""
            Exit Function
        End If

        c.Open()
        cm.Connection = c
        cm.CommandText = "select PayDate,Rc_Cd,Agency_Cd,Name, Emp_Cd, Report_No as AcctNo, " & _
            "Amount_per from py_report where PayDate='" & Format(CDate(txtPayDate.Text), "yyyy/MM/dd") & _
            "' " & pQuery & " and Emp_Cd in ('" & pEmpList.Replace(",", "','") & "') order by Name"
        dr = cm.ExecuteReader
        Do While dr.Read
            vHash += Val(dr("AcctNo"))
            vTotal += Int(dr("Amount_Per"))
            vTrailerHash += Int(dr("Amount_Per")) * Val(Mid(dr("AcctNo"), 5))
            vDump += "01001"
            If Val(Mid(dr("AcctNo"), 2, 3)) <> 0 Then
                vDump += Mid(dr("AcctNo"), 2, 3) & "000"
            Else
                vDump += "001000"
            End If
            vDump += Format(Val(dr("AcctNo")), "00000000000000") & "801110"
            vAmount = dr("Amount_Per") * 100
            vDump += Format(vAmount, "000000000000000")
            vDump += Format(CDate(txtPayDate.Text).Month, "00") & _
                Format(CDate(txtCreditDate.Text).Day, "00") & _
                Format(CDate(txtCreditDate.Text).Year - 2000, "00") & "0" & Space(25) & "00001" & _
                Space(10) & pBranchCd & Space(4) & vbCrLf
        Loop
        vTotal = vTotal
        vDump += "H" & Format(vHash, "00000000000000000000") & _
            Format(vTotal, "00000000000000000000") & Format(vTrailerHash, "00000000000000000000")
        dr.Close()
        cm.Dispose()
        c.Close()
        c.Dispose()
        GenSA = vDump
    End Function
    Private Function GenCA(ByVal pQuery As String, ByVal pEmpList As String, ByVal pCompCd As String, ByVal pBranchCd As String) As String
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim dr As SqlClient.SqlDataReader
        Dim vDump As String = ""
        Dim vAmount As Decimal = 0
        Dim vHash As Decimal = 0
        Dim vTotal As Decimal = 0
        Dim vTrailerHash As Decimal = 0

        If txtPayDate.Text = "" Then
            vScript = "alert('Please select cut-off period first.');"
            cm.Dispose()
            c.Close()
            c.Dispose()
            Return ""
            Exit Function
        End If

        c.Open()
        cm.Connection = c
        cm.CommandText = "select PayDate,Rc_Cd,Agency_Cd,Name, Emp_Cd, Report_No as AcctNo, " & _
            "Amount_per from py_report where PayDate='" & Format(CDate(txtPayDate.Text), "yyyy/MM/dd") & _
            "' " & pQuery & " and Emp_Cd in ('" & pEmpList.Replace(",", "','") & "') order by Name"
        dr = cm.ExecuteReader
        Do While dr.Read
            vHash += Val(dr("AcctNo"))
            vTotal += Int(dr("Amount_Per"))
            vTrailerHash += Int(dr("Amount_Per")) * Val(Mid(dr("AcctNo"), 5))
            vDump += "01001"
            If Val(Mid(dr("AcctNo"), 2, 3)) <> 0 Then
                vDump += Mid(dr("AcctNo"), 2, 3) & "0000"
            Else
                vDump += "0010000"
            End If
            vDump += Format(Val(dr("AcctNo")), "0000000000") & "800001" & Space(7) & "0114"
            vAmount = dr("Amount_Per") * 100
            vDump += Format(vAmount, "000000000000000") & "000000000000001" & Space(23) & pBranchCd & Space(4) & _
                vbCrLf
        Loop
        vTotal = vTotal
        vDump += "H" & Format(vHash, "00000000000000000000") & _
            Format(vTotal, "00000000000000000000") & Format(vTrailerHash, "00000000000000000000")
        dr.Close()
        cm.Dispose()
        c.Close()
        c.Dispose()
        GenCA = vDump
    End Function
End Class
