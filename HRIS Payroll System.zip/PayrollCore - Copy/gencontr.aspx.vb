﻿Imports denaro.fis
Partial Class gencontr
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            vScript = "alert('Your login session has expired. Please re-login again.'); window.close();"
            Exit Sub
        End If

        If Not IsPostBack Then
            Dim c As New sqlclient.sqlConnection(connStr)
            Dim cm As New sqlclient.sqlCommand
            Dim rs As sqlclient.sqlDataReader
            Dim vAgency As String = ""

            Try
                c.Open()
            Catch ex As sqlclient.sqlException
                vScript = "alert('An error has occurred while trying to connect to the database. Error is: " & _
                    ex.Message.Replace("'", "").Replace(vbCrLf, "") & "');"
                c.Dispose()
                cm.Dispose()
                Exit Sub
            End Try
            cm.Connection = c
            cm.CommandText = "select Agency_Cd,Male,Emp_Lname,Emp_Fname,Emp_Mname,Sss_No,PhicNo,PagIbig_No,Tin " & _
                "from py_emp_master where Emp_Cd='" & Session("empcd") & "'"
            Try
                rs = cm.ExecuteReader
                If rs.Read Then
                    If rs("Male") = 1 Then
                        lblName.Text = "Mr. "
                    Else
                        lblName.Text = "Ms. "
                    End If
                    lblName.Text += rs("Emp_Fname") & " " & rs("Emp_Mname") & " " & rs("Emp_Lname")
                    Select Case Request.Item("r").ToString
                        Case "SSS"
                            If Not IsDBNull(rs("Sss_No")) Then
                                If rs("Sss_No") <> "" Then
                                    lblIdNo.Text = "SSS no. " & rs("Sss_No")
                                Else
                                    lblIdNo.Text = "Unknown number"
                                End If
                            Else
                                lblIdNo.Text = "Unknown number"
                            End If
                            lblReport.Text = "SSS"
                        Case "PAGIBIG"
                            If Not IsDBNull(rs("PagIbig_No")) Then
                                If rs("PagIbig_No") <> "" Then
                                    lblIdNo.Text = "PAGIBIG no. " & rs("PagIbig_No")
                                Else
                                    lblIdNo.Text = "Unknown number"
                                End If
                            ElseIf Not IsDBNull(rs("Tin")) Then
                                If rs("Tin") <> "" Then
                                    lblIdNo.Text = "TIN " & rs("Tin")
                                Else
                                    lblIdNo.Text = "Unknown number"
                                End If
                            Else
                                lblIdNo.Text = "Unknown number"
                            End If
                            lblReport.Text = "PAGIBIG"
                        Case "PHIC"
                            If Not IsDBNull(rs("PhicNo")) Then
                                If rs("PhicNo") <> "" Then
                                    lblIdNo.Text = "PHIC no. " & rs("PhicNo")
                                Else
                                    lblIdNo.Text = "Unknown number"
                                End If
                            ElseIf Not IsDBNull(rs("Sss_No")) Then
                                If rs("Sss_No") <> "" Then
                                    lblIdNo.Text = "SSS no. " & rs("Sss_No")
                                Else
                                    lblIdNo.Text = "Unknown number"
                                End If
                            Else
                                lblIdNo.Text = "Unknown number"
                            End If
                            lblReport.Text = "PHIC"
                        Case "TAX"
                            If Not IsDBNull(rs("Tin")) Then
                                If rs("Tin") <> "" Then
                                    lblIdNo.Text = "TIN " & rs("Tin")
                                Else
                                    lblIdNo.Text = "Unknown number"
                                End If
                            Else
                                lblIdNo.Text = "Unknown number"
                            End If
                            lblIdNo.Text = "TIN " & IIf(IsDBNull(rs("Tin")), "Unknown", rs("Tin"))
                            lblReport.Text = "Withholding Tax"
                    End Select
                    vAgency = rs("Agency_Cd")
                Else
                    vScript = "alert('No records retrieved.'); window.close();"
                End If
                rs.Close()

                'get signatory info based on office
                cm.CommandText = "select Attention,Address,AttentionPos,CompLogoPath from glsyscntrl where AgencyCd='" & _
                    vAgency & "'"
                rs = cm.ExecuteReader
                If rs.Read Then
                    lblSignatory.Text = IIf(IsDBNull(rs("Attention")), "Unknown", rs("Attention"))
                    lblPosition.Text = IIf(IsDBNull(rs("AttentionPos")), "Unknown", rs("AttentionPos"))
                    lblFooter.Text = IIf(IsDBNull(rs("Address")), "Unknown Address", rs("Address"))
                    If Not IsDBNull(rs("CompLogoPath")) Then
                        compLogo.ImageUrl = rs("CompLogoPath")
                    End If

                End If
                rs.Close()

                Select Case Request.Item("r").ToString
                    Case "SSS"
                        lblDetail.Text = SSS(c, vAgency)
                    Case "PAGIBIG"
                        lblDetail.Text = PAGIBIG(c, vAgency)
                    Case "PHIC"
                        lblDetail.Text = PHIC(c, vAgency)
                    Case "TAX"
                        lblDetail.Text = TAX(c, vAgency)
                End Select
            Catch ex As sqlclient.sqlException
                vScript = "alert('An error has occurred while trying to retrieve employee information. Error is: " & _
                    ex.Message.Replace("'", "").Replace(vbCrLf, "") & "');"
            Finally
                c.Close()
                c.Dispose()
                cm.Dispose()
            End Try
        End If
    End Sub
    Private Function TAX(ByRef c As sqlclient.sqlConnection, ByVal pAgency As String) As String
        Dim vDump As String = "<table align='center' class='mainGridView' border='0' style='width:80%'><tr class='titleBar'><th class='labelC'>Month</th>" & _
                    "<th class='labelC'>ME-5/OR no.</th><th class='labelC'>Date Paid</th><th class='labelC'>Tax Withheld</th>" & _
                    "</tr>"
        Dim cm As New sqlclient.sqlCommand
        Dim cmRef As New sqlclient.sqlCommand
        Dim rs As sqlclient.sqlDataReader
        Dim rsRef As sqlclient.sqlDataReader
        Dim vYearFr As Integer = Request.Item("y1")
        Dim vYearTo As Integer = Request.Item("y2")
        Dim vStartMonthFr As Integer = Request.Item("m1")
        Dim vStartMonthTo As Integer = Request.Item("m2")
        Dim vEndMonthFr As Integer = Request.Item("m3")
        Dim vEndMonthTo As Integer = Request.Item("m4")
        Dim vSubFilter As String = ""
        Dim vClass As String = "odd"
        Dim i As Integer
        Dim vMonths(12) As String

        vMonths(1) = "January" : vMonths(2) = "February" : vMonths(3) = "March"
        vMonths(4) = "April" : vMonths(5) = "May" : vMonths(6) = "June"
        vMonths(7) = "July" : vMonths(8) = "August" : vMonths(9) = "September"
        vMonths(10) = "October" : vMonths(11) = "November" : vMonths(12) = "December"

        cm.Connection = c
        cmRef.Connection = c

        For i = vYearTo To vYearFr Step -1
            If i = vYearTo Then
                vSubFilter = " and MonthCd between " & vEndMonthFr & " and " & vEndMonthTo
            ElseIf i = vYearFr Then
                vSubFilter = " and MonthCd between " & vStartMonthFr & " and " & vStartMonthTo
            Else
                vSubFilter = ""
            End If

            cm.CommandText = "select * from hr_remittance_or where YearCd=" & i & _
                " and RemitCd='Tax' " & vSubFilter & " and Agency_Cd='" & pAgency & "' order by MonthCd desc"
            rs = cm.ExecuteReader
            If rs.HasRows Then
                vDump += "<tr class='activeBar'><td class='labelL' colspan='4'>" & i & "</td></tr>"
                Do While rs.Read
                    cmRef.CommandText = "select sum(With_Tax) as Tax " & _
                        " from py_report where month(PayDate)=" & rs("MonthCd") & _
                        " and year(PayDate)=" & i & " and Emp_Cd='" & Session("empcd") & "'"
                    rsRef = cmRef.ExecuteReader
                    If rsRef.Read Then
                        vDump += "<tr class='" & vClass & "'><td class='labelL'>" & vMonths(rs("MonthCd")) & _
                            "</td><td class='labelL'>" & rs("OrNo") & "</td><td class='labelR'>" & _
                            Format(rs("DatePaid"), "MM/dd/yyyy") & "</td>"
                        If Not IsDBNull(rsRef("Tax")) Then
                            vDump += "<td class='labelR'>" & Format(rsRef("Tax"), "##,##0.00") & "</td>"
                        Else
                            vDump += "<td class='labelR'>" & Format(0, "##,##0.00") & "</td>"
                        End If
                        vDump += "</tr>"
                    End If
                    rsRef.Close()
                    vClass = IIf(vClass = "odd", "even", "odd")
                Loop
            End If
            rs.Close()
        Next
        vDump += "</table>"
        cm.Dispose()

        Return vDump
    End Function
    Private Function PAGIBIG(ByRef c As sqlclient.sqlConnection, ByVal pAgency As String) As String
        Dim vDump As String = "<table align='center' class='mainGridView' border='0' style='width:80%'><tr class='titleBar'><th class='labelC'>Month</th>" & _
                    "<th class='labelC'>ME-5/OR no.</th><th class='labelC'>Date Paid</th><th class='labelC'>Employee</th>" & _
                    "<th class='labelC'>Employer</th></tr>"
        Dim cm As New sqlclient.sqlCommand
        Dim cmRef As New sqlclient.sqlCommand
        Dim rs As sqlclient.sqlDataReader
        Dim rsRef As sqlclient.sqlDataReader
        Dim vYearFr As Integer = Request.Item("y1")
        Dim vYearTo As Integer = Request.Item("y2")
        Dim vStartMonthFr As Integer = Request.Item("m1")
        Dim vStartMonthTo As Integer = Request.Item("m2")
        Dim vEndMonthFr As Integer = Request.Item("m3")
        Dim vEndMonthTo As Integer = Request.Item("m4")
        Dim vSubFilter As String = ""
        Dim vClass As String = "odd"
        Dim i As Integer
        Dim vMonths(12) As String

        vMonths(1) = "January" : vMonths(2) = "February" : vMonths(3) = "March"
        vMonths(4) = "April" : vMonths(5) = "May" : vMonths(6) = "June"
        vMonths(7) = "July" : vMonths(8) = "August" : vMonths(9) = "September"
        vMonths(10) = "October" : vMonths(11) = "November" : vMonths(12) = "December"

        cm.Connection = c
        cmRef.Connection = c

        For i = vYearTo To vYearFr Step -1
            If i = vYearTo Then
                vSubFilter = " and MonthCd between " & vEndMonthFr & " and " & vEndMonthTo
            ElseIf i = vYearFr Then
                vSubFilter = " and MonthCd between " & vStartMonthFr & " and " & vStartMonthTo
            Else
                vSubFilter = ""
            End If

            cm.CommandText = "select * from hr_remittance_or where YearCd=" & i & _
                " and RemitCd='Pagibig' " & vSubFilter & " and Agency_Cd='" & pAgency & "' order by MonthCd desc"
            rs = cm.ExecuteReader
            If rs.HasRows Then
                vDump += "<tr class='activeBar'><td class='labelL' colspan='5'>" & i & "</td></tr>"
                Do While rs.Read
                    cmRef.CommandText = "select sum(PagIbig_Per) as PagIBIGEmp, sum(PagIbig_Gov) as PagIBIGEmr" & _
                        " from py_report where month(PayDate)=" & rs("MonthCd") & _
                        " and year(PayDate)=" & i & " and Emp_Cd='" & Session("empcd") & "'"
                    rsRef = cmRef.ExecuteReader
                    If rsRef.Read Then
                        vDump += "<tr class='" & vClass & "'><td class='labelL'>" & vMonths(rs("MonthCd")) & _
                            "</td><td class='labelL'>" & rs("OrNo") & "</td><td class='labelR'>" & _
                            Format(rs("DatePaid"), "MM/dd/yyyy") & "</td>"
                        If Not IsDBNull(rsRef("PagIBIGEmp")) Then
                            vDump += "<td class='labelR'>" & Format(rsRef("PagIBIGEmp"), "#,##0.00") & "</td>"
                        Else
                            vDump += "<td class='labelR'>" & Format(0, "#,##0.00") & "</td>"
                        End If
                        If Not IsDBNull(rsRef("PagIBIGEmr")) Then
                            vDump += "<td class='labelR'>" & Format(rsRef("PagIBIGEmr"), "#,##0.00") & "</td>"
                        Else
                            vDump += "<td class='labelR'>" & Format(0, "#,##0.00") & "</td>"
                        End If
                        vDump += "</tr>"
                    End If
                    rsRef.Close()
                    vClass = IIf(vClass = "odd", "even", "odd")
                Loop
            End If
            rs.Close()
        Next
        vDump += "</table>"
        cm.Dispose()

        Return vDump
    End Function
    Private Function PHIC(ByRef c As sqlclient.sqlConnection, ByVal pAgency As String) As String
        Dim vDump As String = "<table align='center' class='mainGridView' border='0' style='width:80%'><tr class='titleBar'><th class='labelC'>Month</th>" & _
            "<th class='labelC'>ME-5/OR no.</th><th class='labelC'>Date Paid</th><th class='labelC'>Employee</th>" & _
            "<th class='labelC'>Employer</th></tr>"
        Dim cm As New sqlclient.sqlCommand
        Dim cmRef As New sqlclient.sqlCommand
        Dim rs As sqlclient.sqlDataReader
        Dim rsRef As sqlclient.sqlDataReader
        Dim vYearFr As Integer = Request.Item("y1")
        Dim vYearTo As Integer = Request.Item("y2")
        Dim vStartMonthFr As Integer = Request.Item("m1")
        Dim vStartMonthTo As Integer = Request.Item("m2")
        Dim vEndMonthFr As Integer = Request.Item("m3")
        Dim vEndMonthTo As Integer = Request.Item("m4")
        Dim vSubFilter As String = ""
        Dim vClass As String = "odd"
        Dim i As Integer
        Dim vMonths(12) As String

        vMonths(1) = "January" : vMonths(2) = "February" : vMonths(3) = "March"
        vMonths(4) = "April" : vMonths(5) = "May" : vMonths(6) = "June"
        vMonths(7) = "July" : vMonths(8) = "August" : vMonths(9) = "September"
        vMonths(10) = "October" : vMonths(11) = "November" : vMonths(12) = "December"

        cm.Connection = c
        cmRef.Connection = c

        For i = vYearTo To vYearFr Step -1
            If i = vYearTo Then
                vSubFilter = " and MonthCd between " & vEndMonthFr & " and " & vEndMonthTo
            ElseIf i = vYearFr Then
                vSubFilter = " and MonthCd between " & vStartMonthFr & " and " & vStartMonthTo
            Else
                vSubFilter = ""
            End If
            cm.CommandText = "select * from hr_remittance_or where YearCd=" & i & _
                " and RemitCd='Philhealth' " & vSubFilter & " and Agency_Cd='" & pAgency & "' order by MonthCd desc"
            rs = cm.ExecuteReader
            If rs.HasRows Then
                vDump += "<tr class='activeBar'><td class='labelL' colspan='5'>" & i & "</td></tr>"
                Do While rs.Read
                    cmRef.CommandText = "select sum(Medicare_Per) as PhicEmp, sum(Medicare_Gov) as PhicEmr" & _
                        " from py_report where month(PayDate)=" & rs("MonthCd") & _
                        " and year(PayDate)=" & i & " and Emp_Cd='" & Session("empcd") & "'"
                    rsRef = cmRef.ExecuteReader

                    If rsRef.Read Then
                        vDump += "<tr class='" & vClass & "'><td class='labelL'>" & vMonths(rs("MonthCd")) & _
                            "</td><td class='labelL'>" & rs("OrNo") & "</td><td class='labelR'>" & _
                            Format(rs("DatePaid"), "MM/dd/yyyy") & "</td>"
                        If Not IsDBNull(rsRef("PhicEmp")) Then
                            vDump += "<td class='labelR'>" & Format(rsRef("PhicEmp"), "#,##0.00") & "</td>"
                        Else
                            vDump += "<td class='labelR'>" & Format(0, "#,##0.00") & "</td>"
                        End If
                        If Not IsDBNull(rsRef("PhicEmr")) Then
                            vDump += "<td class='labelR'>" & Format(rsRef("PhicEmr"), "#,##0.00") & "</td>"
                        Else
                            vDump += "<td class='labelR'>" & Format(0, "#,##0.00") & "</td>"
                        End If
                        vDump += "</tr>"
                    End If
                    rsRef.Close()
                    vClass = IIf(vClass = "odd", "even", "odd")
                Loop
            End If
            rs.Close()
        Next
        vDump += "</table>"
        cm.Dispose()

        Return vDump
    End Function
    Private Function SSS(ByRef c As sqlclient.sqlConnection, ByVal pAgency As String) As String
        Dim vDump As String = "<table align='center' class='mainGridView' border='0' style='width:80%'><tr class='titleBar'><th class='labelC'>Month</th>" & _
           "<th class='labelC'>ME-5/OR no.</th><th class='labelC'>Date Paid</th><th class='labelC'>Employee</th>" & _
           "<th class='labelC'>Employer</th><th class='labelC'>E.C.</th></tr>"
        Dim cm As New sqlclient.sqlCommand
        Dim cmRef As New sqlclient.sqlCommand
        Dim rs As sqlclient.sqlDataReader
        Dim rsRef As sqlclient.sqlDataReader
        Dim vYearFr As Integer = Request.Item("y1")
        Dim vYearTo As Integer = Request.Item("y2")
        Dim vStartMonthFr As Integer = Request.Item("m1")
        Dim vStartMonthTo As Integer = Request.Item("m2")
        Dim vEndMonthFr As Integer = Request.Item("m3")
        Dim vEndMonthTo As Integer = Request.Item("m4")
        Dim vSubFilter As String = ""
        Dim vClass As String = "odd"
        Dim i As Integer
        Dim vMonths(12) As String

        vMonths(1) = "January" : vMonths(2) = "February" : vMonths(3) = "March"
        vMonths(4) = "April" : vMonths(5) = "May" : vMonths(6) = "June"
        vMonths(7) = "July" : vMonths(8) = "August" : vMonths(9) = "September"
        vMonths(10) = "October" : vMonths(11) = "November" : vMonths(12) = "December"

        cm.Connection = c
        cmRef.Connection = c

        For i = vYearTo To vYearFr Step -1
            If i = vYearTo Then
                vSubFilter = " and MonthCd between " & vEndMonthFr & " and " & vEndMonthTo
            ElseIf i = vYearFr Then
                vSubFilter = " and MonthCd between " & vStartMonthFr & " and " & vStartMonthTo
            Else
                vSubFilter = ""
            End If

            cm.CommandText = "select * from hr_remittance_or where YearCd=" & i & _
                " and RemitCd='SSS' " & vSubFilter & " and Agency_Cd='" & pAgency & "' order by MonthCd desc"
            rs = cm.ExecuteReader
            If rs.HasRows Then
                vDump += "<tr class='activeBar'><td class='labelL' colspan='6'>" & i & "</td></tr>"
                Do While rs.Read
                    cmRef.CommandText = "select sum(Sss_Per) as SSSEmp, sum(Sss_Gov) as SSSEmr," & _
                        " sum(Ec) as EC from py_report where month(PayDate)=" & rs("MonthCd") & _
                        " and year(PayDate)=" & i & " and Emp_Cd='" & Session("empcd") & "'"
                    rsRef = cmRef.ExecuteReader
                    If rsRef.Read Then
                        vDump += "<tr class='" & vClass & "'><td class='labelL'>" & vMonths(rs("MonthCd")) & _
                            "</td><td class='labelL'>" & rs("OrNo") & "</td><td class='labelR'>" & _
                            Format(rs("DatePaid"), "MM/dd/yyyy") & "</td>"
                        If Not IsDBNull(rsRef("SSSEmp")) Then
                            vDump += "<td class='labelR'>" & Format(rsRef("SSSEmp"), "#,##0.00") & "</td>"
                        Else
                            vDump += "<td class='labelR'>" & Format(0, "#,##0.00") & "</td>"
                        End If
                        If Not IsDBNull(rsRef("SSSEmr")) Then
                            vDump += "<td class='labelR'>" & Format(rsRef("SSSEmr"), "#,##0.00") & "</td>"
                        Else
                            vDump += "<td class='labelR'>" & Format(0, "#,##0.00") & "</td>"
                        End If
                        If Not IsDBNull(rsRef("EC")) Then
                            vDump += "<td class='labelR'>" & Format(rsRef("EC"), "#,##0.00") & "</td>"
                        Else
                            vDump += "<td class='labelR'>" & Format(0, "#,##0.00") & "</td>"
                        End If
                        vDump += "</tr>"
                    End If
                    rsRef.Close()
                    vClass = IIf(vClass = "odd", "even", "odd")
                Loop
            End If
            rs.Close()
        Next
        vDump += "</table>"
        cm.Dispose()

        Return vDump
    End Function
End Class
