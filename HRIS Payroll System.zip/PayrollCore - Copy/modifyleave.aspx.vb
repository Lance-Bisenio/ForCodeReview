Imports denaro
Partial Class modifyleave
    Inherits System.Web.UI.Page
    Public vScript As String = "window.focus();"
    Dim c As New SqlClient.SqlConnection
    Protected Sub cmdCancel_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCancel.Init
        cmdCancel.Attributes.Add("onclick", "javascript:window.close();")
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Session("returnaddr") = "leavemonitor.aspx"
            Server.Transfer("index.aspx")
        End If
        If Not IsPostBack Then

            lblCaption.Text = "Add/Modify Employee Leaves"
            txtEmpId.Text = Session("empid")
            BuildCombo("select Leave_Cd,Descr from py_leave_ref order by Descr", cmbLeaveType)
            'BuildCombo("select Emp_Cd,Emp_Lname+', '+Emp_Fname as Name from py_emp_master where " & _
            '    "Date_Resign is null and DateHold is null and DateSuspended is null and Date_Retired is null " & _
            '    "order by Emp_Lname,Emp_Fname,Emp_Mname", cmbApprovedBy)
            If Session("tdate") = "" Then    'add new record
                txtApprovedBy.Text = Session("uid") & "=>" & GetName(Session("uid"))
                txtTranDate.Text = Now
                txtStart.Text = Format(Now, "short date")
                txtEnd.Text = txtStart.Text
                txtDateApproved.Text = Format(Now, "MM/dd/yy HH:mm:ss")
                txtDays.Text = "1"

                Session("oldval") = "Emp Id=" & txtEmpId.Text & _
                    "|Date Filed=" & txtTranDate.Text & _
                    "|Leave Code=" & _
                    "|# of Days Leave=" & _
                    "|Start Date=" & _
                    "|End Date=" & _
                    "|Date Approved=" & txtDateApproved.Text & _
                    "|Approved By=" & txtApprovedBy.Text & _
                    "|Remarks="
            Else
                cmbLeaveType.Enabled = False
                Dim cm As New sqlclient.sqlcommand
                Dim dr As sqlclient.sqldatareader

                c.ConnectionString = connStr
                c.Open()
                cm.Connection = c
                cm.CommandText = "select * from hr_leave_application where Emp_Cd='" & _
                    ExtractData(Session("empid")) & "' and TranDate='" & _
                    Session("tdate") & "' and Void=" & Session("void") & " and LeaveCd = '" & _
                    Session("leavetype") & "' and TranDate='" & Session("tdate") & "'"
                dr = cm.ExecuteReader
                If dr.Read Then
                    chkEL.Checked = IIf(dr("EL") = "1", True, False)
                    chkPaid.Checked = IIf(dr("Paid") = "1", True, False)
                    chkLatefiled.Checked = IIf(IsDBNull(dr("EffectivityDate")), False, True)
                    chkLatefiled.Enabled = False
                    lblAppNo.Text = dr("ApplicationNo")
                    lblAppNo1.Visible = True
                    txtEmpId.Text = Session("empid")
                    txtTranDate.Text = dr("TranDate")
                    txtDays.Text = GetRef("SELECT SUM(DaysLeave) FROM hr_leave_application WHERE Emp_Cd='" & dr("Emp_Cd") & "' AND ApplicationNo='" & dr("ApplicationNo") & "'", 0)
                    txtDaysLeave.Value = txtDays.Text
                    txtStart.Text = dr("StartDate")
                    txtEnd.Text = dr("EndDate")
                    txtReason.Text = dr("Reason")
                    txtDateApproved.Text = IIf(IsDBNull(dr("DateApproved")), "", dr("DateApproved"))
                    txtRemarks.Text = IIf(IsDBNull(dr("Remarks")), "", dr("Remarks"))
                    chkPaid.Checked = IIf(IsDBNull(dr("Paid")), False, dr("Paid"))
                    cmbLeaveType.SelectedValue = PointData("select Leave_Cd,Descr from py_leave_ref where Leave_Cd='" & _
                        dr("LeaveCd") & "'")
                    lblVoid.Visible = IIf(dr("Void") = True, True, False)
                    txtApprovedBy.Text = dr("ApprovedBy") & "=>" & GetName(dr("ApprovedBy"))
                    'cmbApprovedBy.SelectedValue = PointData("select Emp_Cd,Emp_Lname+', '+Emp_Fname as Name " & _
                    '    "from py_emp_master where Emp_Cd='" & GetRef("SELECT SupervisorCd FROM py_emp_master WHERE Emp_Cd = '" & dr("Emp_Cd") & "'", dr("Emp_Cd")) & "'")

                    Session("oldval") = "Emp Id=" & txtEmpId.Text & _
                         "|Date Filed=" & txtTranDate.Text & _
                         "|Leave Code=" & cmbLeaveType.SelectedValue & _
                         "|# of Days Leave=" & txtDays.Text & _
                         "|Start Date=" & txtStart.Text & _
                         "|End Date=" & txtEnd.Text & _
                         "|Date Approved=" & txtDateApproved.Text & _
                         "|Approved By=" & txtApprovedBy.Text & _
                         "|Remarks" & txtRemarks.Text
                End If
                dr.Close()
                cm.Dispose()
                c.Close()
                If Session("mode") = "v" Then
                    chkLatefiled.Enabled = False
                    cmdSave.Visible = False
                    txtEmpId.Enabled = False
                    txtTranDate.Enabled = False
                    txtDays.Enabled = False
                    txtStart.Enabled = False
                    txtReason.Enabled = False
                    txtDateApproved.Enabled = False
                    txtRemarks.Enabled = False
                    chkPaid.Enabled = False
                    cmbLeaveType.Enabled = False
                    cmbMonthE.Enabled = False
                    cmbDayE.Enabled = False
                    cmbYearE.Enabled = False
                    chkOffsetTo.Enabled = False
                    'cmbApprovedBy.Enabled = False
                    chkEL.Enabled = False  'Added by rudner 06.29.2009
                End If
            End If

            If cmbLeaveType.SelectedValue = "SL" Then
                chkEL.Visible = True
            Else
                chkEL.Visible = False
            End If
            getLeave()
            checkLateFiled()
        End If
    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        If Page.IsValid Then
            Dim vCreditTo As String = ""

            If chkLatefiled.Checked = True Then
                Dim iV As Integer = 0

                If CDbl(txtDays.Text) > 1 Then
                    vScript = "alert('Number of hours to leave should not be greater than 1 day.');"
                    Exit Sub
                End If

                Do While iV < chkOffsetTo.Items.Count
                    If chkOffsetTo.Items(iV).Selected = True Then
                        vCreditTo += chkOffsetTo.Items(iV).Value & ","
                    End If
                    iV += 1
                Loop

                If vCreditTo <> "" Then
                    vCreditTo = vCreditTo.Substring(0, vCreditTo.Length - 1)
                Else
                    vScript = "alert('Cannot process please select where to offset.');"
                    Exit Sub
                End If
            End If

            Dim cm As New SqlClient.SqlCommand
            Dim rs As SqlClient.SqlDataReader
            Dim cmRef As New SqlClient.SqlCommand
            Dim cmRef2 As New SqlClient.SqlCommand
            Dim rsRef As SqlClient.SqlDataReader
            Dim vId As String = ExtractData(Session("empid"))
            Dim vPaid As Boolean = False
            Dim vDaysLeave As Decimal = 0
            Dim vAppNo As String = ""
            Dim vRc As String = ""
            Dim vAgency As String = ""
            Dim vDays As Decimal = CDbl(txtDays.Text)
            Dim vALeave As Decimal = CDbl(txtDays.Text)
            Dim i As Integer = 1
            Dim vEffectivityDate As Date = Nothing

            If chkLatefiled.Checked = True Then
                vEffectivityDate = cmbYearE.SelectedValue & "/" & cmbMonthE.SelectedValue & "/" & cmbDayE.SelectedValue
            End If

            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c
            cmRef.Connection = c
            cmRef2.Connection = c

            If Session("tdate") <> "" Then 'DELETE FROM 
                cm.CommandText = "DELETE FROM hr_leave_application WHERE Emp_Cd='" & vId & _
                    "' AND TranDate='" & Session("tdate") & "'"
                cm.ExecuteNonQuery()
            End If

            ' If Session("tdate") = "" Then ' add mode
            ' check for the schedule
            cm.CommandText = "select 1 from py_emp_time_sched where Emp_Cd='" & _
                    vId & "' and Date_Sched='" & Format(CDate(txtStart.Text), "yyyy/MM/dd") & "'"
            rs = cm.ExecuteReader
            If rs.Read Then

                'get AppNo
                vAppNo = getAppNo(c, vId)

                ' get RC and Company
                cmRef.CommandText = "SELECT Rc_Cd,Agency_Cd FROM py_emp_master WHERE Emp_Cd = '" & vId & "'"
                rsRef = cmRef.ExecuteReader
                If rsRef.Read Then
                    vRc = IIf(IsDBNull(rsRef("Rc_Cd")), "", rsRef("Rc_Cd"))
                    vAgency = IIf(IsDBNull(rsRef("Agency_Cd")), "", rsRef("Agency_Cd"))
                End If
                rsRef.Close()

                'Get all Sched Days
                cmRef.CommandText = "select Date_Sched from py_emp_time_sched where Emp_Cd='" & _
                    vId & "' and Date_Sched >= '" & CDate(txtStart.Text) & _
                    "' AND NOT EXISTS (SELECT Holy_Date FROM py_holiday WHERE Holy_Date = Date_Sched " & _
                    " AND (Office_Cd LIKE '%*%' OR Office_Cd LIKE '%" & vAgency & _
                    "%') AND (Rc_Cd LIKE '%*%' OR Rc_Cd LIKE '%" & vRc & "%')) "
                rsRef = cmRef.ExecuteReader

                Do While rsRef.Read
                    If cmbLeaveType.SelectedValue = "SAT" Then
                        If CDate(rsRef("Date_Sched")).DayOfWeek = DayOfWeek.Saturday Then
                            'INSERT NEW RECORD
                            cmRef2.CommandText = "insert into hr_leave_application (TranDate,LeaveCd,Emp_Cd,DaysLeave,StartDate,EndDate," & _
                                "Reason,ApprovedBy,DateApproved,Remarks,Paid,Void,Posted,BreakHrs,ApplicationNo" & _
                                IIf(chkLatefiled.Checked, ",CreditTo,EffectivityDate", "") & ") values ('" & _
                                CDate(txtTranDate.Text) & "','" & _
                                cmbLeaveType.SelectedValue & "','" & vId & _
                                "'," & IIf(vALeave >= 1, 1, vALeave) & ",'" & Format(CDate(rsRef("Date_Sched")), "yyyy/MM/dd") & "','" & _
                                Format(CDate(rsRef("Date_Sched")), "yyyy/MM/dd") & "','" & txtReason.Text & "','" & _
                                ExtractData(txtApprovedBy.Text) & "','" & _
                                Format(CDate(txtDateApproved.Text), "yyyy/MM/dd HH:mm:ss") & _
                                "','" & txtRemarks.Text & "'," & IIf(chkPaid.Checked, 1, 0) & ",0,1,0,'" & vAppNo & _
                                IIf(chkLatefiled.Checked, "','" & vCreditTo & "'," & IIf(vEffectivityDate = Nothing, "NULL", "'" & vEffectivityDate & "'") & ")", "')")
                            cmRef2.ExecuteNonQuery()

                            'UPDATE py_time_log_dtl
                            updateLogs(CDate(rsRef("Date_Sched")), vEffectivityDate, IIf(vALeave >= 1, 8, vALeave * 8), c)

                            If i < Math.Ceiling(vDays) Then
                                i += 1
                                vALeave -= 1
                            Else
                                Exit Do
                            End If

                        End If
                    Else
                        'INSERT NEW RECORD
                        cmRef2.CommandText = "insert into hr_leave_application (TranDate,LeaveCd,Emp_Cd,DaysLeave,StartDate,EndDate," & _
                            "Reason,ApprovedBy,DateApproved,Remarks,Paid,Void,Posted,BreakHrs,ApplicationNo,EL" & _
                            IIf(chkLatefiled.Checked, ",CreditTo,EffectivityDate", "") & ") values ('" & _
                            CDate(txtTranDate.Text) & "','" & _
                            cmbLeaveType.SelectedValue & "','" & vId & _
                            "'," & IIf(vALeave >= 1, 1, vALeave) & ",'" & Format(CDate(rsRef("Date_Sched")), "yyyy/MM/dd") & "','" & _
                            Format(CDate(rsRef("Date_Sched")), "yyyy/MM/dd") & "','" & txtReason.Text & "','" & _
                            ExtractData(txtApprovedBy.Text) & "','" & _
                            Format(CDate(txtDateApproved.Text), "yyyy/MM/dd HH:mm:ss") & _
                            "','" & txtRemarks.Text & "'," & IIf(chkPaid.Checked, 1, 0) & ",0,1,0,'" & vAppNo & _
                            "','" & IIf(chkEL.Visible, IIf(chkEL.Checked, 1, 0), 0) & _
                            IIf(chkLatefiled.Checked, "','" & vCreditTo & "'," & IIf(vEffectivityDate = Nothing, "NULL", "'" & vEffectivityDate & "'") & ")", "')")
                        cmRef2.ExecuteNonQuery()

                        'UPDATE py_time_log_dtl
                        If chkPaid.Checked Then
                            updateLogs(CDate(rsRef("Date_Sched")), vEffectivityDate, IIf(vALeave >= 1, 8, vALeave * 8), c)
                        End If

                        If i < Math.Ceiling(vDays) Then
                            i += 1
                            vALeave -= 1
                        Else
                            Exit Do
                        End If
                    End If
                Loop
                rsRef.Close()
            Else
                vScript = "alert('No schedule for this date.');"
                cm.Dispose()
                cmRef.Dispose()
                cmRef2.Dispose()
                c.Close()
                Exit Sub
            End If
            rs.Close()
            'Else                            'edit mode
            '    cm.CommandText = "update hr_leave_application set " & _
            '        "LeaveCd='" & cmbLeaveType.SelectedValue & _
            '        "',Emp_Cd='" & vId & _
            '        "',DaysLeave=" & txtDays.Text & _
            '        ",StartDate='" & Format(CDate(txtStart.Text), "yyyy/MM/dd") & _
            '        "',EndDate='" & Format(CDate(txtEnd.Text), "yyyy/MM/dd") & _
            '        "',Reason='" & txtReason.Text & _
            '        "',Remarks='" & txtRemarks.Text & _
            '        "',Paid=" & IIf(chkPaid.Checked, 1, 0) & _
            '        " where Emp_Cd='" & vId & _
            '        "' and Trandate='" & Session("tdate") & _
            '        "' and Void=" & Session("void") & _
            '        " and StartDate='" & Format(CDate(Session("sdate")), "yyyy/MM/dd") & _
            '        "' and EndDate='" & Format(CDate(Session("edate")), "yyyy/MM/dd") & "'"
            '    cm.ExecuteNonQuery()
            'End If

            If txtDaysLeave.Value <> txtDays.Text Then
                If chkPaid.Checked = True Then ' If paid.
                    If Session("tdate") = "" Then 'add mode
                        cm.CommandText = "UPDATE py_emp_leave SET Balance = Balance - " & CDbl(txtDays.Text) & _
                            " WHERE Emp_Cd='" & vId & "' AND Leave_Cd = '" & cmbLeaveType.SelectedValue & "'"
                    Else

                        cm.CommandText = "UPDATE py_emp_leave SET Balance = " & _
                            IIf(txtDays.Text < txtDaysLeave.Value, "Balance + " & Math.Abs(txtDaysLeave.Value - txtDays.Text), "Balance - " & _
                            Math.Abs(txtDaysLeave.Value - txtDays.Text)) & _
                            " WHERE Emp_Cd='" & vId & _
                            "' AND Leave_Cd = '" & cmbLeaveType.SelectedValue & "'"
                    End If
                    cm.ExecuteNonQuery()

                    cm.CommandText = "UPDATE py_emp_leave SET Used = Credit - Balance WHERE Emp_Cd='" & vId & _
                                     "' AND Leave_Cd = '" & cmbLeaveType.SelectedValue & "'"
                    cm.ExecuteNonQuery()
                End If
            End If

            cmdSave.Enabled = False
            cm.Dispose()
            cmRef.Dispose()
            cmRef2.Dispose()
            c.Close()
            c.Dispose()
            vScript = "alert('Changes were successfuly saved.');window.opener.form1.submit();window.close();"
        End If
    End Sub
    Private Sub updateLogs(ByVal iDate As Date, ByVal vEffectivityDate As Date, ByVal vALeave As Decimal, ByRef c As sqlclient.sqlconnection)
        Dim cm As New sqlclient.sqlcommand
        Dim cmRef As New sqlclient.sqlcommand
        Dim rs As sqlclient.sqldatareader
        Dim vDays As Decimal = vALeave
        Dim vAmount As Decimal = 0
        Dim vRestDay As Boolean = False
        Dim vSQL As String = ""
        Dim vTranCd As String = ""
        Dim vHrs As Decimal = 0
        Dim vAmt As Decimal = 0
        Dim vId As String = ExtractData(txtEmpId.Text)

        cm.Connection = c
        cmRef.Connection = c

        cm.CommandText = "select Emp_Cd from py_time_log where Emp_Cd='" & vId & _
            "' and Tran_Date='" & Format(iDate, "yyyy/MM/dd") & "'"
        rs = cm.ExecuteReader
        If Not rs.HasRows Then  'no record
            vSQL = "insert into py_time_log (Tran_Date,Emp_Cd) values ('" & _
                Format(iDate, "yyyy/MM/dd") & "','" & vId & "')"
        End If
        rs.Close()
        If vSQL <> "" Then
            cm.CommandText = vSQL
            cm.ExecuteNonQuery()
        End If
        If vEffectivityDate = Nothing Then       'current filed application
            'CLEAN RECORD FIRST IN TIME LOG DTL 
            cm.CommandText = "delete from py_time_log_dtl where Emp_Cd='" & _
                vId & "' and TranDate='" & Format(iDate, "yyyy/MM/dd") & _
                "'"
            cm.ExecuteNonQuery()

            cm.CommandText = "insert into py_time_log_dtl (Emp_Cd,TranDate,TranCd,Hrs_Rendered," & _
                "AmtConv,Reason,LateFiled,EffectivityDate) values ('" & vId & "','" & _
                Format(iDate, "yyyy/MM/dd") & "','" & cmbLeaveType.SelectedValue & "'," & vDays & _
                ",0,'Posted-LeaveApp',0,'" & Format(iDate, "yyyy/MM/dd") & "')"
            cm.ExecuteNonQuery()
        Else        'late filed application
            'get records for adjustment
            If chkPaid.Checked = True Then
                'CLEAN RECORD FIRST IN TIME LOG DTL 
                cm.CommandText = "delete from py_time_log_dtl where Emp_Cd='" & _
                    vId & "' and TranDate='" & Format(iDate, "yyyy/MM/dd") & "' AND LateFiled=1"
                cm.ExecuteNonQuery()

                cm.CommandText = "select * from py_time_log_dtl where Emp_cd='" & _
                    vId & "' and CAST(TranDate AS DATE)='" & Format(iDate, "yyyy/MM/dd") & _
                    "' and EffectivityDate=TranDate and Reason='Auto-generated' and " & _
                    "TranCd in (SELECT replace(CreditTo,',',''',''') FROM hr_leave_application " & _
                    "WHERE EffectivityDate IS NOT NULL AND StartDate='" & Format(iDate, "yyyy/MM/dd") & _
                    "' AND Emp_Cd='" & vId & "')"
                rs = cm.ExecuteReader

                Do While rs.Read
                    vTranCd = rs("TranCd")
                    vHrs = rs("Hrs_Rendered") * -1
                    vAmt = rs("AmtConv") * -1
                    cmRef.CommandText = "insert into py_time_log_dtl (Emp_Cd,TranDate,TranCd,Hrs_Rendered," & _
                        "AmtConv,Reason,LateFiled,EffectivityDate) values ('" & vId & "','" & _
                        Format(iDate, "yyyy/MM/dd") & "','" & vTranCd & "'," & vHrs & _
                        "," & vAmt & ",'Posted-LateApp',1,'" & Format(CDate(vEffectivityDate), "yyyy/MM/dd") & "')"
                    cmRef.ExecuteNonQuery()
                Loop
                rs.Close()
            End If
        End If
        cm.Dispose()
        cmRef.Dispose()
    End Sub
    Protected Sub vldTran_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles vldTran.ServerValidate
        If Session("tdate") <> txtTranDate.Text Then        'date has been changed
            Dim cm As New sqlclient.sqlcommand
            Dim dr As sqlclient.sqldatareader

            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c
            cm.CommandText = "select Emp_Cd from hr_leave_application where Emp_Cd='" & _
                ExtractData(txtEmpId.Text) & "' and TranDate='" & _
                Format(CDate(txtTranDate.Text), "yyyy/MM/dd") & "'"
            dr = cm.ExecuteReader
            If dr.Read Then
                vScript = "alert('Record already exist. Please select a different filing date.');"
                args.IsValid = False
            Else
                args.IsValid = True
            End If
            dr.Close()
            cm.Dispose()
            c.Close()
            Exit Sub
        End If
        If Not IsDate(txtDateApproved.Text) Then
            vScript = "alert('Invalid date format in Date Approved field.');"
            args.IsValid = False
            Exit Sub
        End If

        If Not IsDate(txtStart.Text) Then
            vScript = "alert('Invalid date format in Start Date field.');"
            args.IsValid = False
            Exit Sub
        End If

        If Not IsNumeric(txtDays.Text) Then
            vScript = "alert('Days Leave should be numeric.');"
            args.IsValid = False
            Exit Sub
        End If

        If chkLatefiled.Checked = True Then
            If txtDays.Text > 1 Then
                vScript = "alert('Days Leave should not be greater than 1.');"
                args.IsValid = False
                Exit Sub
            End If
        End If
        args.IsValid = True
    End Sub

    Protected Sub cmdCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        Session.Remove("void")
        Session.Remove("tdate")
        Session.Remove("empid")
        Session.Remove("mode")

    End Sub

    Private Function getAppNo(ByRef c As sqlclient.sqlconnection, ByVal vID As String) As String
        Dim cm As New sqlclient.sqlcommand
        Dim rs As sqlclient.sqldatareader
        Dim vAppNo As Integer = 0

        cm.Connection = c
        cm.CommandText = "select count(*) from hr_leave_application where Emp_Cd='" & vID & "'"
        rs = cm.ExecuteReader
        If rs.Read Then
            vAppNo = rs(0) + 1
        End If
        rs.Close()
again:
        cm.CommandText = "select 1 from hr_leave_application where ApplicationNo='" & _
            vID & "-" & Format(vAppNo, "0000") & "'"
        rs = cm.ExecuteReader
        If rs.HasRows Then
            rs.Close()
            vAppNo += 1
            GoTo again
        End If
        rs.Close()

        cm.Dispose()

        Return vID & "-" & Format(vAppNo, "0000")
    End Function

    Protected Sub cmbLeaveType_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbLeaveType.SelectedIndexChanged
        getLeave()
    End Sub
    Private Sub getLeave()
        'Modify by Rj 03/12/09 
        'FOR OB USED
        'Adding of Always paid leave
        Dim vAlwaysPaid As Integer = 0
        Dim cm As New sqlclient.sqlcommand
        Dim rs As sqlclient.sqldatareader
        cm.Connection = c
        c.ConnectionString = connStr
        c.Open()

        cm.CommandText = "SELECT AlwaysPaid FROM py_leave_ref WHERE Leave_Cd = '" & cmbLeaveType.SelectedValue & "'"
        rs = cm.ExecuteReader
        If rs.Read Then
            vAlwaysPaid = rs("AlwaysPaid")
        End If
        rs.Close()

        If vAlwaysPaid > 0 Then
            chkPaid.Checked = True
            chkPaid.Enabled = False
        End If

        If Session("mode") <> "v" And Session("tdate") = "" Then
            txtBalance.Value = 0
            cm.CommandText = "SELECT Balance FROM py_emp_leave WHERE Emp_Cd='" & ExtractData(Session("empid")) & _
                "' AND Leave_Cd='" & cmbLeaveType.SelectedValue & "'"
            rs = cm.ExecuteReader
            If rs.Read Then
                txtBalance.Value = IIf(CDbl(rs(0)) < 0, 0, rs(0))
                If CDbl(rs(0)) <= 0 Then
                    chkPaid.Enabled = False
                Else
                    chkPaid.Enabled = True
                End If
                chkPaid.Checked = False
            Else
                chkPaid.Enabled = False
            End If
            rs.Close()
        End If

        If cmbLeaveType.SelectedValue = "SL" Then
            chkEL.Visible = True
        Else
            chkEL.Visible = False
        End If

        'Modify by Rj 03/12/09 
        'FOR OB USED
        'Adding of Always paid leave
        c.Close()
    End Sub
    Protected Sub chkLatefiled_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkLatefiled.CheckedChanged
        checkLateFiled()
    End Sub
    Private Sub checkLateFiled()
        If chkLatefiled.Checked = True Then
            Dim iCtr As Integer = 0
            cmbMonthE.SelectedValue = Now.Month
            cmbYearE.SelectedValue = Now.Year
            cmbYearE.Items.Clear()
            cmbDayE.Items.Clear()
            trLate.Visible = True
            trLate2.Visible = True
            For iCtr = Now.Year - 1 To Now.Year
                cmbYearE.Items.Add(iCtr)
            Next iCtr
            SetStartCutOff()
            getTimeDtl()
        Else
            trLate.Visible = False
            trLate2.Visible = False
        End If
    End Sub
    Private Sub getTimeDtl()
        Dim cm As New sqlclient.sqlcommand
        Dim rs As sqlclient.sqldatareader
        Dim vDate As String = txtStart.Text

        If IsDate(vDate) Then
            chkOffsetTo.Items.Clear()
            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c
            cm.CommandText = "SELECT TranCd, Hrs_Rendered FROM py_time_log_dtl WHERE TranDate = '" & _
            CDate(vDate) & "' AND Emp_Cd='" & ExtractData(Session("empid")) & "' AND TranCd IN ('ABSENT','UT','TARD') AND LateFiled=0"
            rs = cm.ExecuteReader
            If rs.Read Then
                chkOffsetTo.Items.Add(New ListItem(rs("TranCd") & "=" & rs("Hrs_Rendered"), rs("TranCd")))
                chkOffsetTo.Items(0).Selected = True
                Do While rs.Read
                    chkOffsetTo.Items.Add(New ListItem(rs("TranCd") & "=" & rs("Hrs_Rendered"), rs("TranCd")))
                Loop
            End If
            rs.Close()
            cm.Dispose()
            c.Close()
        End If
    End Sub
    Private Sub SetStartCutOff()
        Dim cm As New sqlclient.sqlcommand
        Dim dr As sqlclient.sqldatareader
        Dim vCutOff As String = ""
        Dim vDays() As String
        Dim iCtr As Integer
        Dim vEday As Integer = 0

        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c
        cm.CommandText = "select * from py_pay_mode"
        dr = cm.ExecuteReader
        If dr.Read Then
            Session("divisor") = IIf(IsDBNull(dr("Divisor")), 1, dr("Divisor"))
            Session("index") = "1"
            vCutOff = IIf(IsDBNull(dr("Days")), "", dr("Days"))
            cmbDayE.Items.Clear()
            vDays = vCutOff.Split(",")
            For iCtr = 0 To vDays.Length - 1
                If iCtr > 0 Then
                    vEday = MonthEND(CDate(cmbMonthE.SelectedValue & "/" & vDays(iCtr - 1) & "/" & cmbYearE.SelectedValue)).Day
                Else
                    vEday = vDays(iCtr + 1) - 1
                End If
                cmbDayE.Items.Add(New ListItem(vDays(iCtr) & "-" & vEday, vDays(iCtr)))
            Next iCtr
        End If
        dr.Close()
        cm.Dispose()
        c.Close()
    End Sub

    Protected Sub cmbMonthE_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbMonthE.SelectedIndexChanged
        SetStartCutOff()
    End Sub

    Protected Sub cmbYearE_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbYearE.SelectedIndexChanged
        SetStartCutOff()
    End Sub

    Protected Sub txtStart_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtStart.TextChanged

        If IsDate(txtStart.Text) Then
            txtEnd.Text = txtStart.Text
            getTimeDtl()
        Else
            vScript = "alert('Invalid date format in Start Date.');"
            Exit Sub
        End If
    End Sub
End Class
