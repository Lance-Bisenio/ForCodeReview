Imports denaro
Partial Class alphalist
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Dim c As New SqlClient.SqlConnection
    Dim cmSysCntrl As New SqlClient.SqlCommand
    Dim rsSysCntrl As SqlClient.SqlDataReader
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Session("returnaddr") = "massupdateincent.aspx"
            Server.Transfer("index.aspx")
        End If
        If Not IsPostBack Then 'now build the reference code
            'If Not CanRun(Session("caption"), Request.Item("id")) Then
            '    Session("denied") = "1"
            '    Server.Transfer("main.aspx")
            '    Exit Sub
            'End If
            lblCaption.Text = "Alphalist download"
            BuildCombo("select AgencyCd,AgencyName from agency where AgencyCd in ('" & _
                Session("agencylist").ToString.Replace(",", "','") & "') order by AgencyName", cmbOfc)
            BuildCombo("select EmploymentType,Descr from hr_employment_type where EmploymentType in ('" & _
                Session("typelist").ToString.Replace(",", "','") & "') order by Descr", cmbSecurity)
            cmbOfc.Items.Add("All Office")
            cmbOfc.SelectedValue = "All Office"
            cmbSecurity.Items.Add("All")
            cmbSecurity.SelectedValue = "All"
            txtPeriod.Text = "12/31/" & Year(Now)
        End If
    End Sub
    Private Sub GetOfcInfo()
        Dim cm As New sqlclient.sqlcommand
        Dim rs As sqlclient.sqldatareader

        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c
        cm.CommandText = "select Tin,TaxBranchCd from glsyscntrl where AgencyCd='" & _
            cmbOfc.SelectedValue & "'"
        rs = cm.ExecuteReader
        If rs.Read Then
            txtTIN.Text = IIf(IsDBNull(rs("Tin")), "", rs("Tin"))
            txtBranchCd.Text = IIf(IsDBNull(rs("TaxBranchCd")), "", rs("TaxBranchCd"))
        Else
            vScript = "alert('Please define the company information first in " & _
                "System Parameters=>Company Information menu.');"
        End If
        rs.Close()

        cm.Dispose()
        c.Close()
    End Sub
    Protected Sub cmdReturn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.Click
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub cmbOfc_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbOfc.SelectedIndexChanged
        If cmbOfc.SelectedValue <> "All Office" Then
            GetOfcInfo()
        Else
            txtBranchCd.Text = ""
            txtTIN.Text = ""
        End If
    End Sub

    Protected Sub cmdRefresh_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdRefresh.Click
        If cmbOfc.SelectedValue <> "All Office" Then
            DataRefresh()
        Else
            vScript = "alert('You must first select a specific Office/Branch');"
        End If
    End Sub
    Private Sub DataRefresh()
        Dim cm As New SqlClient.SqlCommand
        Dim da As SqlClient.SqlDataAdapter
        Dim ds As New DataSet
        Dim vSql As String = ""
        Dim vQry As String = ""

        If cmbReportType.SelectedValue <> "0" Then
            vQry = cmbReportType.SelectedValue
        End If

        If cmbSecurity.SelectedValue <> "All" Then
            vQry += " and exists (select Emp_Cd from py_emp_master where EmploymentType='" & cmbSecurity.SelectedValue & _
            "' and py_emp_master.Emp_Cd=[1604f].Emp_Cd)"
        End If

        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c
        cm.CommandText = "update [1604f] set BranchCd_Emr='" & txtBranchCd.Text & _
            "' where AgencyCd='" & cmbOfc.SelectedValue & _
            "' and ReturnPd='" & Format(CDate(txtPeriod.Text), "yyyy/MM/dd") & "' " & _
            vQry

        cm.ExecuteNonQuery()
        cm.Dispose()
        c.Close()

        vSql = "select * from [1604f] where AgencyCd='" & cmbOfc.SelectedValue & _
            "' and ReturnPd='" & Format(CDate(txtPeriod.Text), "yyyy/MM/dd") & "' " & _
            vQry & " order by Sched_Num,SeqId"

        da = New SqlClient.SqlDataAdapter(vSql, c)
        da.Fill(ds, "1604")

        tbl1604.DataSource = ds.Tables("1604")
        tbl1604.DataBind()
        ds.Dispose()
        da.Dispose()
        If tbl1604.Rows.Count > 0 Then
            Dump()
            vScript = "document.getElementById(""divWait"").style.visibility = ""hidden"";"
        Else
            vScript = "alert('No records retrieved. Click the `Process Alphalist` button first.');"
        End If
    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        If cmbOfc.SelectedValue = "All Office" Then
            vScript = "alert('You must first select an Office/Branch');"
            Exit Sub
        End If

        Dim cm As New sqlclient.sqlCommand
        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c
        Try
            cm.CommandText = "update glsyscntrl set Tin='" & txtTIN.Text & _
                "',TaxBranchCd='" & txtBranchCd.Text & _
                "' where AgencyCd='" & cmbOfc.SelectedValue & "'"
            cm.ExecuteNonQuery()
        Catch ex As sqlclient.sqlException
            vScript = "alert('An error occurred while the system is trying to save the settings. " & _
                "Error code is: " & ex.Message.Replace("'", "") & "');"
            GoTo close
        End Try
        vScript = "alert('Changes were successfully saved');"
close:
        cm.Dispose()
        c.Close()
    End Sub
    Private Function GetNonTaxableSalary(ByVal pNonTaxIncentive As String, ByRef pRef As sqlclient.sqldatareader) As Decimal
        Dim vNTaxIncentive As String() = pNonTaxIncentive.Split(",")
        Dim vTot As Decimal = 0
        Dim iCtr As Integer
        Dim vIdx As Integer

        For iCtr = 0 To UBound(vNTaxIncentive)
            vIdx = GetNumber(vNTaxIncentive(iCtr))
            If vIdx <> 0 Then
                vTot = vTot + IIf(IsDBNull(pRef("Incent" & vIdx)), 0, pRef("Incent" & vIdx))
            End If
        Next iCtr
        GetNonTaxableSalary = vTot
    End Function
    Protected Sub cmdProcess_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdProcess.Click
        'validate each fields first
        If cmbOfc.SelectedValue = "All Office" Then
            vScript = "alert('You must first select an Office/Branch');"
            Exit Sub
        End If
        If Trim(txtTIN.Text) = "" Then
            vScript = "alert('Employers TIN should not be empty.');"
            Exit Sub
        End If
        If Trim(txtBranchCd.Text) = "" Then
            vScript = "alert('RDO code should not be empty.');"
            Exit Sub
        End If
        If txtTIN.Text.Length > 16 Then
            vScript = "alert('TIN should be less 16 characters.');"
            Exit Sub
        End If
        If txtBranchCd.Text.Length > 5 Then
            vScript = "alert('RDO code should be less than 6 characters.');"
            Exit Sub
        End If

        Dim cm As New sqlclient.sqlCommand
        Dim rs As sqlclient.sqlDataReader
        Dim vDump As String = ""
        Dim vNTaxIncentives As String
        Dim vTaxGroup() As Double
        Dim vIncentives() As String
        Dim iCtr As Integer

        c.ConnectionString = connStr
        c.Open()
        cmSysCntrl.Connection = c
        cm.Connection = c

        cmSysCntrl.CommandText = "select * from py_syscntrl"
        rsSysCntrl = cmSysCntrl.ExecuteReader
        rsSysCntrl.Read()

        
        'configure and group the taxable icentives
        'get list of nontax incentives first
        cm.CommandText = "select Incentive_Cd from py_other_incentvs where Taxable=0 and Declared<>0"
        rs = cm.ExecuteReader
        vNTaxIncentives = ""
        Do While rs.Read
            vNTaxIncentives += rs("Incentive_Cd") & ","
        Loop
        rs.Close()
        If vNTaxIncentives <> "" Then
            vNTaxIncentives = Mid(vNTaxIncentives, 1, Len(vNTaxIncentives) - 1)
        End If

        'get list of TAXABLE groups
        cm.CommandText = "select count(distinct MaxTaxExempt) from py_other_incentvs where Taxable <> 0 and " & _
           "MaxTaxExempt is not null and Grouped <> 0"
        rs = cm.ExecuteReader
        If rs.Read Then
            If Not IsDBNull(rs(0)) Then
                ReDim vTaxGroup(rs(0) - 1)
                ReDim vIncentives(rs(0) - 1)
            Else
                vScript = "alert('The system cannot continue because Exemption group is not defined.');"
                rsSysCntrl.Close()
                cmSysCntrl.Dispose()
                c.Close()
                Exit Sub
            End If
        End If
        rs.Close()
        cm.CommandText = "select distinct MaxTaxExempt from py_other_incentvs where Taxable <> 0 and " & _
                   "MaxTaxExempt is not null and Grouped <> 0"
        rs = cm.ExecuteReader
        iCtr = 0
        Do While rs.Read
            vTaxGroup(iCtr) = rs("MaxTaxExempt")
            iCtr += 1
        Loop
        rs.Close()

        'asSIGN LIST OF INCENTIVES FOR EACH GROUP
        For iCtr = 0 To UBound(vTaxGroup)
            cm.CommandText = "select Incentive_Cd from py_other_incentvs where Declared <> 0 and Taxable <> 0 and Grouped <> 0 " & _
               "and MaxTaxExempt=" & vTaxGroup(iCtr) & " order by Incentive_Cd"
            vIncentives(iCtr) = ""
            rs = cm.ExecuteReader
            Do While rs.Read
                vIncentives(iCtr) += rs("Incentive_Cd") & ","
            Loop
            rs.Close()
            If vIncentives(iCtr) <> "" Then
                vIncentives(iCtr) = Mid(vIncentives(iCtr), 1, Len(vIncentives(iCtr)) - 1)
            End If
        Next iCtr

        Dim vDateResign As String = "null"
        Dim cmExec As New sqlclient.sqlCommand
        Dim cmRef As New sqlclient.sqlCommand
        Dim rsRef As sqlclient.sqlDataReader
        Dim iSched(4) As Integer
        Dim iSeq As Integer
        Dim iGrp As Integer
        Dim iCount As Integer = 0
        Dim vStr As String
        Dim vDate As Date = CDate(txtPeriod.Text)
        Dim vTot As Double
        Dim vIdx As Integer
        Dim vTaxableAmt As Double
        Dim vSchedNum As String
        Dim vWithPrevEmployer As Boolean

        'VARIABLES NEEDED FOR 1604
        Dim vSubFiling As String
        Dim vPremium As Double
        Dim vCurrTaxableSalary As Double
        Dim vCurrTaxable13th As Double
        Dim vCurrTaxWithheld As Double
        Dim vCurrNTaxableSalary As Double
        Dim vCurrNTaxable13th As Double
        Dim vCurrMandatory As Double

        Dim vPrevTaxableSalary As Double
        Dim vPrevTaxable13th As Double
        Dim vPrevTaxWithheld As Double
        Dim vPrevNTaxableSalary As Double
        Dim vPrevNTaxable13th As Double
        Dim vPrevMandatory As Double

        Dim vOverUnder As Double
        Dim vTaxDue As Double
        Dim vExempt As Double
        Dim vTaxWithheldDec As Double

        cmRef.Connection = c
        cmExec.Connection = c

        'delete existing 1604f records
        cmExec.CommandText = "delete from [1604f] where AgencyCd='" & cmbOfc.SelectedValue & _
            "' and ReturnPd='" & Format(vDate, "yyyy/MM/dd") & "'"
        cmExec.ExecuteNonQuery()

        'get list of employees for the year
        cm.CommandText = "select * from py_emp_master where Agency_Cd='" & cmbOfc.SelectedValue & _
            "' and (Date_Resign is null or " & _
            "(Date_Resign is not null and year(Date_Resign)=" & vDate.Year & _
            ")) order by Emp_Lname,Emp_Fname"
        iSeq = 1
        iSched(0) = 0 : iSched(1) = 0 : iSched(2) = 0 : iSched(3) = 0
        rs = cm.ExecuteReader
        Do While rs.Read
            'get tax exemption of employee
            cmRef.CommandText = "select Exemption from py_tax_ref where Tax_Cd='" & _
               rs("Tax_Cd") & "'"
            rsRef = cmRef.ExecuteReader
            vExempt = 0
            If rsRef.Read Then
                vExempt = IIf(IsDBNull(rsRef("Exemption")), 0, rsRef("Exemption"))
            End If
            rsRef.Close()
            'GET PREV EMPLOYER'S INCOME
            cmRef.CommandText = "select GrossTaxable,Tax13th,TaxWithHeld,GrossNonTax,NonTax13th,NonTaxSss" & _
               " from py_prev_employer_income where Emp_Cd='" & rs("Emp_Cd") & _
               "' and YearCd=" & vDate.Year
            rsRef = cmRef.ExecuteReader
            vWithPrevEmployer = False
            If rsRef.Read Then
                vWithPrevEmployer = True
                vPrevTaxableSalary = IIf(IsDBNull(rsRef("GrossTaxable")), 0, rsRef("GrossTaxable"))
                vPrevTaxable13th = IIf(IsDBNull(rsRef("Tax13th")), 0, rsRef("Tax13th"))
                vPrevTaxWithheld = IIf(IsDBNull(rsRef("TaxWithHeld")), 0, rsRef("TaxWithHeld"))
                vPrevNTaxableSalary = IIf(IsDBNull(rsRef("GrossNonTax")), 0, rsRef("GrossNonTax"))
                vPrevNTaxable13th = IIf(IsDBNull(rsRef("NonTax13th")), 0, rsRef("NonTax13th"))
                vPrevMandatory = IIf(IsDBNull(rsRef("NonTaxSss")), 0, rsRef("NonTaxSss"))
            Else
                vPrevTaxableSalary = 0
                vPrevTaxable13th = 0
                vPrevTaxWithheld = 0
                vPrevNTaxableSalary = 0
                vPrevNTaxable13th = 0
                vPrevMandatory = 0
            End If
            rsRef.Close()

            'settings for locales/branches that is treated as different company
            'check if employee has payroll from other locale
            '''' the following code is used only for victoria court use wherein the branch is considered
            '''' as another type of company 
            'cmRef.CommandText = "select count(*) from py_report where Emp_Cd='" & rs("Emp_Cd") & _
            '    "' and Agency_Cd<>'" & rs("Agency_Cd") & "' and year(PayDate)=" & vDate.Year
            'rsRef = cmRef.ExecuteReader
            'iCount = 0
            'If rsRef.Read Then
            '    iCount = IIf(IsDBNull(rsRef(0)), 0, rsRef(0))
            'End If
            'rsRef.Close()
            'If iCount > 0 Then 'has income from previous locale, set as previous employer income
            '    vWithPrevEmployer = True
            '    cmRef.CommandText = "select sum(Month_Rate) as Gross, sum(Absent+Tardiness) as Absents," & _
            '       "sum(Ot) as OtTotal, sum(0) as Transpo,sum(Aca+Pera) as Fnd,sum(G1+G2+G3) as OfcOt," & _
            '       "sum(MealAllow) as Meal,sum(Other_Incent1) as Incent1, sum(Other_Incent2) as Incent2," & _
            '       "sum(Other_Incent3) as Incent3, sum(Other_Incent4) as Incent4," & _
            '       "sum(Other_Incent5) as Incent5, sum(Other_Incent6) as Incent6," & _
            '       "sum(Other_Incent7) as Incent7, sum(Other_Incent8) as Incent8," & _
            '       "sum(Other_Incent9) as Incent9, sum(Other_Incent10) as Incent10," & _
            '       "sum(Other_Incent11) as Incent11, sum(Other_Incent12) as Incent12," & _
            '       "sum(Other_Incent13) as Incent13, sum(Other_Incent14) as Incent14," & _
            '       "sum(Other_Incent15) as Incent15, sum(Other_Incent16) as Incent16," & _
            '       "sum(Other_Incent17) as Incent17, sum(Other_Incent18) as Incent18," & _
            '       "sum(Other_Incent19) as Incent19, sum(Other_Incent20) as Incent20," & _
            '       "sum(Other_Incent21) as Incent21, sum(Other_Incent22) as Incent22," & _
            '       "sum(Other_Incent23) as Incent23, sum(Other_Incent24) as Incent24," & _
            '       "sum(Other_Incent25) as Incent25, sum(Other_Incent26) as Incent26," & _
            '       "sum(Other_Incent27) as Incent27, sum(Other_Incent28) as Incent28," & _
            '       "sum(Other_Incent29) as Incent29, sum(Other_Incent30) as Incent30," & _
            '       "sum(Other_Incent31) as Incent31, sum(Other_Incent32) as Incent32," & _
            '       "sum(Other_Incent33) as Intent33, sum(Other_Incent34) as Incent34," & _
            '       "sum(Other_Incent35) as Intent35, sum(Other_Incent36) as Incent36," & _
            '       "sum(Other_Incent37) as Intent37, sum(Other_Incent38) as Incent38," & _
            '       "sum(Other_Incent39) as Intent39, sum(Other_Incent40) as Incent40," & _
            '       "sum(Other_Incent41) as Intent41, sum(Other_Incent42) as Incent42," & _
            '       "sum(Other_Incent43) as Intent43, sum(Other_Incent44) as Incent44," & _
            '       "sum(Other_Incent45) as Intent45, sum(Other_Incent46) as Incent46," & _
            '       "sum(Other_Incent47) as Intent47, sum(Other_Incent48) as Incent48," & _
            '       "sum(Other_Incent49) as Intent49, sum(Other_Incent50) as Incent50," & _
            '       "sum(Other_Incent51) as Intent51, sum(Other_Incent52) as Incent52," & _
            '       "sum(Other_Incent53) as Intent53, sum(Other_Incent54) as Incent54," & _
            '       "sum(Other_Incent55) as Intent55, sum(Other_Incent56) as Incent56," & _
            '       "sum(Other_Incent57) as Intent57, sum(Other_Incent58) as Incent58," & _
            '       "sum(Other_Incent59) as Intent59, sum(Other_Incent60) as Incent60," & _
            '       "sum(With_Tax) as WithTax, sum(Sss_Per) as SssEmp,  " & _
            '       "sum(PagIbig_Per) as PagIbigEmp,sum(Medicare_Per) as MedEmp " & _
            '       "from py_report where year(PayDate)=" & vDate.Year & " and Emp_Cd='" & _
            '       rs("Emp_Cd") & "' and Agency_Cd<>'" & rs("Agency_Cd") & "'"
            '    rsRef = cmRef.ExecuteReader
            '    If rsRef.Read Then
            '        vPrevTaxableSalary += IIf(IsDBNull(rsRef("Gross")), 0, rsRef("Gross")) + _
            '           IIf(IsDBNull(rsRef("Absents")), 0, rsRef("Absents")) + _
            '           IIf(IsDBNull(rsRef("Transpo")), 0, rsRef("Transpo")) + _
            '           IIf(IsDBNull(rsRef("Fnd")), 0, rsRef("Fnd")) + _
            '           IIf(IsDBNull(rsRef("OtTotal")), 0, rsRef("OtTotal")) - _
            '           IIf(IsDBNull(rsRef("OfcOt")), 0, rsRef("OfcOt"))
            '        vPrevTaxWithheld += IIf(IsDBNull(rsRef("WithTax")), 0, rsRef("WithTax"))
            '        vPrevNTaxableSalary += GetNonTaxableSalary(vNTaxIncentives, rsRef)
            '        'vPrevNTaxableSalary += IIf(IsDBNull(rsRef("Meal")), 0, rsRef("Meal"))
            '        vPrevMandatory += IIf(IsDBNull(rsRef("SssEmp")), 0, rsRef("SssEmp")) + _
            '            IIf(IsDBNull(rsRef("PagIbigEmp")), 0, rsRef("PagIbigEmp")) + _
            '            IIf(IsDBNull(rsRef("MedEmp")), 0, rsRef("MedEmp"))
            '        'GET TAXABLE INCOME BY GROUP
            '        Dim vIncent As String()
            '        vCurrTaxable13th = 0
            '        vCurrNTaxable13th = 0
            '        For iGrp = 0 To UBound(vTaxGroup)
            '            vTot = 0
            '            vIncent = vIncentives(iGrp).Split(",")
            '            For iCtr = 0 To UBound(vIncent)
            '                vIdx = GetNumber(vIncent(iCtr))
            '                If vIdx <> 0 Then
            '                    vTot += IIf(IsDBNull(rsRef("Incent" & vIdx)), 0, rsRef("Incent" & vIdx))
            '                End If
            '            Next iCtr
            '            If vTaxGroup(iGrp) <> 30000 Then 'INCLUDE TO TAXABLE SALARY
            '                vPrevTaxableSalary += vTot
            '            Else  'TAXGROUP IS 30000   (THIS IS 13TH MONTH AND OTHER BENEFITS)
            '                If vTot - vTaxGroup(iGrp) < 0 Then
            '                    vPrevNTaxable13th += vTot
            '                    'vCurrTaxable13th = 0
            '                Else
            '                    vPrevNTaxable13th += vTaxGroup(iGrp)
            '                    vPrevTaxable13th += (vTot - vTaxGroup(iGrp))
            '                End If
            '            End If
            '        Next iGrp
            '    End If
            '    rsRef.Close()
            'End If

            'GET DECEMBER TAXWITHHELD
            cmRef.CommandText = "select sum(With_Tax) as TaxDec from py_report where Emp_Cd='" & _
               rs("Emp_Cd") & "' and month(PayDate)=12 and year(PayDate)=" & vDate.Year & _
               " and Agency_Cd='" & rs("Agency_Cd") & "'"
            rsRef = cmRef.ExecuteReader
            vTaxWithheldDec = 0
            If rsRef.Read Then
                vTaxWithheldDec = IIf(IsDBNull(rsRef("TaxDec")), 0, rsRef("TaxDec"))
            End If
            rsRef.Close()

            'get health premiums exemptions
            cmRef.CommandText = "select sum(Amount) as Amt from py_other_premiums where Emp_Id='" & _
                rs("Emp_Cd") & "'"
            rsRef = cmRef.ExecuteReader
            vPremium = 0
            If rsRef.Read Then
                vPremium = IIf(IsDBNull(rsRef("Amt")), 0, rsRef("Amt"))
            End If
            rsRef.Close()

            'GET CURRENT INCOME
            cmRef.CommandText = "select sum(Month_Rate) as Gross, sum(Absent+Tardiness) as Absents," & _
               "sum(Ot) as OtTotal, sum(0) as Transpo,sum(Aca+Pera) as Fnd,sum(G1+G2+G3) as OfcOt," & _
               "sum(MealAllow) as Meal,sum(Other_Incent1) as Incent1, sum(Other_Incent2) as Incent2," & _
               "sum(Other_Incent3) as Incent3, sum(Other_Incent4) as Incent4," & _
               "sum(Other_Incent5) as Incent5, sum(Other_Incent6) as Incent6," & _
               "sum(Other_Incent7) as Incent7, sum(Other_Incent8) as Incent8," & _
               "sum(Other_Incent9) as Incent9, sum(Other_Incent10) as Incent10," & _
               "sum(Other_Incent11) as Incent11, sum(Other_Incent12) as Incent12," & _
               "sum(Other_Incent13) as Incent13, sum(Other_Incent14) as Incent14," & _
               "sum(Other_Incent15) as Incent15, sum(Other_Incent16) as Incent16," & _
               "sum(Other_Incent17) as Incent17, sum(Other_Incent18) as Incent18," & _
               "sum(Other_Incent19) as Incent19, sum(Other_Incent20) as Incent20," & _
               "sum(Other_Incent21) as Incent21, sum(Other_Incent22) as Incent22," & _
               "sum(Other_Incent23) as Incent23, sum(Other_Incent24) as Incent24," & _
               "sum(Other_Incent25) as Incent25, sum(Other_Incent26) as Incent26," & _
               "sum(Other_Incent27) as Incent27, sum(Other_Incent28) as Incent28," & _
               "sum(Other_Incent29) as Incent29, sum(Other_Incent30) as Incent30," & _
               "sum(Other_Incent31) as Incent31, sum(Other_Incent32) as Incent32," & _
               "sum(Other_Incent33) as Intent33, sum(Other_Incent34) as Incent34," & _
               "sum(Other_Incent35) as Intent35, sum(Other_Incent36) as Incent36," & _
               "sum(Other_Incent37) as Intent37, sum(Other_Incent38) as Incent38," & _
               "sum(Other_Incent39) as Intent39, sum(Other_Incent40) as Incent40," & _
               "sum(Other_Incent41) as Intent41, sum(Other_Incent42) as Incent42," & _
               "sum(Other_Incent43) as Intent43, sum(Other_Incent44) as Incent44," & _
               "sum(Other_Incent45) as Intent45, sum(Other_Incent46) as Incent46," & _
               "sum(Other_Incent47) as Intent47, sum(Other_Incent48) as Incent48," & _
               "sum(Other_Incent49) as Intent49, sum(Other_Incent50) as Incent50," & _
               "sum(Other_Incent51) as Intent51, sum(Other_Incent52) as Incent52," & _
               "sum(Other_Incent53) as Intent53, sum(Other_Incent54) as Incent54," & _
               "sum(Other_Incent55) as Intent55, sum(Other_Incent56) as Incent56," & _
               "sum(Other_Incent57) as Intent57, sum(Other_Incent58) as Incent58," & _
               "sum(Other_Incent59) as Intent59, sum(Other_Incent60) as Incent60," & _
               "sum(With_Tax) as WithTax, sum(Sss_Per) as SssEmp,  " & _
               "sum(PagIbig_Per) as PagIbigEmp,sum(Medicare_Per) as MedEmp " & _
               "from py_report where year(PayDate)=" & vDate.Year & " and Emp_Cd='" & _
               rs("Emp_Cd") & "' and Agency_Cd='" & rs("Agency_Cd") & "'"
            rsRef = cmRef.ExecuteReader
            If rsRef.Read Then
                vCurrTaxableSalary = IIf(IsDBNull(rsRef("Gross")), 0, rsRef("Gross")) + _
                   IIf(IsDBNull(rsRef("Absents")), 0, rsRef("Absents")) + _
                   IIf(IsDBNull(rsRef("Transpo")), 0, rsRef("Transpo")) + _
                   IIf(IsDBNull(rsRef("Fnd")), 0, rsRef("Fnd")) + _
                   IIf(IsDBNull(rsRef("OtTotal")), 0, rsRef("OtTotal")) - _
                   IIf(IsDBNull(rsRef("OfcOt")), 0, rsRef("OfcOt"))
                vCurrTaxWithheld = IIf(IsDBNull(rsRef("WithTax")), 0, rsRef("WithTax")) - vTaxWithheldDec
                vCurrMandatory = IIf(IsDBNull(rsRef("SssEmp")), 0, rsRef("SssEmp")) + _
                   IIf(IsDBNull(rsRef("PagibigEmp")), 0, rsRef("PagibigEmp")) + _
                   IIf(IsDBNull(rsRef("MedEmp")), 0, rsRef("MedEmp"))

                'GET NONTAXABLE SALARIES
                vCurrNTaxableSalary = GetNonTaxableSalary(vNTaxIncentives, rsRef)
                'vCurrNTaxableSalary += IIf(IsDBNull(rsRef("Meal")), 0, rsRef("Meal"))
                'GET TAXABLE INCOME BY GROUP
                Dim vIncent As String()
                vCurrTaxable13th = 0
                vCurrNTaxable13th = 0
                For iGrp = 0 To UBound(vTaxGroup)
                    vTot = 0
                    vIncent = vIncentives(iGrp).Split(",")
                    For iCtr = 0 To UBound(vIncent)
                        vIdx = GetNumber(vIncent(iCtr))
                        If vIdx <> 0 Then
                            vTot = vTot + IIf(IsDBNull(rsRef("Incent" & vIdx)), 0, rsRef("Incent" & vIdx))
                        End If
                    Next iCtr
                    If vTaxGroup(iGrp) <> 30000 Then 'INCLUDE TO TAXABLE SALARY
                        vCurrTaxableSalary += vTot
                    Else  'TAXGROUP IS 30000   (THIS IS 13TH MONTH AND OTHER BENEFITS)
                        If vTot - vTaxGroup(iGrp) < 0 Then
                            vCurrNTaxable13th = vTot
                            vCurrTaxable13th = 0
                        Else
                            vCurrNTaxable13th = vTaxGroup(iGrp)
                            vCurrTaxable13th = vTot - vTaxGroup(iGrp)
                        End If
                    End If
                Next iGrp
            End If
            rsRef.Close()

            'GET TAXDUE BasED ON ANNUAL TAX
            vTaxableAmt = vCurrTaxableSalary + vCurrTaxable13th + vPrevTaxableSalary + _
               vPrevTaxable13th - vCurrMandatory - vPrevMandatory - vExempt - vPremium

            'GET TAX TABLE BasED ON GROSS AND ANNUAL TAX
            vStr = "select * from py_tax_table where Freq_Cd = 'ANNUAL' " & _
                 "and Tax_Cd='ANNUAL' and " & vTaxableAmt & " >= Check_Amt order by Check_Amt desc"

            cmRef.CommandText = vStr
            rsRef = cmRef.ExecuteReader
            If rsRef.Read Then
                vTaxDue = rsRef("Add_Amt") + (rsRef("Factor") * (vTaxableAmt - rsRef("Check_Amt")))
            Else  'NEGATIVE
                vTaxDue = 0
            End If
            rsRef.Close()

            vOverUnder = vTaxDue - (vCurrTaxWithheld + vTaxWithheldDec + vPrevTaxWithheld)

            'froilan , February 20, 2010

            Dim vOtherIncentNonTax As Double = Math.Round(vCurrNTaxable13th, 2)
            Dim vPresNonTaxDeMinimis As Double = 0
            Dim vMandatory As Double = Math.Round(vCurrMandatory, 2)
            Dim vSalariesNonTax As Double = Math.Round(vCurrNTaxableSalary, 2)

            Dim vPresTaxableBasicSalary As Double
            Dim vOtherIncentTax As Double = Math.Round(vCurrTaxable13th, 2)
            Dim vSalariesTax As Double = Math.Round(vCurrTaxableSalary - _
                                                    vCurrMandatory, 2)

            Dim vPrevTaxableBasicSalary As Double = vPrevTaxableSalary
            Dim vPrevTaxable13thMonth As Double = Math.Round(vPrevTaxable13th, 2)
            Dim vPrevTaxableSalaries As Double = Math.Round(vPrevTaxableSalary - _
                                                            vPrevMandatory, 2)
            Dim vPrevTotalTaxable As Double = vPrevTaxableBasicSalary + _
                vPrevTaxable13thMonth + vPrevTaxableSalaries

            Dim vPresTotalComp As Double = vPresTaxableBasicSalary + _
                vOtherIncentTax + vSalariesTax

            Dim vHealthPremium As Double = vPremium
            Dim vExemptionAmount As Double = Math.Round(vExempt, 2)

            Dim vPrevNonTax13thMonth As Double = Math.Round(vPrevNTaxable13th, 2)
            Dim vPrevNonTaxDeMinimis As Double = 0
            Dim vPrevNonTaxSSS As Double = Math.Round(vCurrMandatory, 2)
            Dim vPrevNonTaxSalaries As Double = Math.Round(vPrevNTaxableSalary, 2)

            Dim vPrevNonTaxBasicSmw As Double = 0
            Dim vPrevNonTaxHolidayPay As Double = 0
            Dim vPrevNonTaxOvertimePay As Double = 0
            Dim vPrevNonTaxNightDiff As Double = 0
            Dim vPrevNonTaxHazardPay As Double = 0

            Dim vPrevTotalNonTaxCompIncome As Double

            Dim vNonTaxBasicSal As Double = 0
            Dim vPresNonTaxHolidayPay As Double = 0
            Dim vPresNonTaxOvertimePay As Double = 0
            Dim vPresNonTaxNightDiff As Double = 0
            Dim vPresNonTaxHazardPay As Double = 0

            Dim vPrevNonTaxGrossCompIncome As Double = 0
            Dim vPresNonTaxGrossCompIncome As Double = 0
            Dim vPresNonTaxBasicSmwDay As Double = 0
            Dim vPresNonTaxBasicSmwMonth As Double = 0
            Dim vPresNonTaxBasicSmwYear As Double = 0

            Dim vFactorUsed As Double = 0
            Dim vRegionNum As String = ""

            Dim vPresTotalNonTaxCompIncome As Double = vOtherIncentNonTax + _
                vPresNonTaxDeMinimis + vMandatory + vSalariesNonTax


            Dim vTotalTaxableCompIncome As Double = 0
            Dim vTotalNonTaxCompIncome As Double = 0
            Dim vNetTaxableCompIncome As Double = 0

            'end froilan


            'get schedule number
            iCtr = 0
            vSubFiling = ""
            If Not IsDBNull(rs("Date_Resign")) Then     'employee is resigned
                vSchedNum = "D7.1"
                vSubFiling = "N"
                iSched(1) = iSched(1) + 1
                iCtr = iSched(1)

                'by froilan, feb 20, 2010
                vTotalTaxableCompIncome = vPresTaxableBasicSalary + _
                    vOtherIncentTax + vSalariesTax
                vTotalNonTaxCompIncome = vOtherIncentNonTax + _
                    vPresNonTaxDeMinimis + vMandatory + vSalariesNonTax
                vNetTaxableCompIncome = Math.Round( _
                    (vTotalTaxableCompIncome - vHealthPremium - _
                     vExemptionAmount), 2)
            Else    'employee is active
                If vTaxDue = 0 Then 'no tax due
                    vSchedNum = "D7.2"
                    iSched(2) = iSched(2) + 1
                    iCtr = iSched(2)

                    'by froilan
                    vTotalNonTaxCompIncome = vOtherIncentNonTax + _
                        vPresNonTaxDeMinimis + vMandatory + vSalariesNonTax
                    vNetTaxableCompIncome = vPresTaxableBasicSalary - _
                        vSalariesTax - vExemptionAmount - vHealthPremium
                Else    'with tax due payable or refund
                    If vWithPrevEmployer Then   'with previous employer
                        vSchedNum = "D7.4"
                        iSched(4) = iSched(4) + 1
                        iCtr = iSched(4)

                        'froilan
                        vTotalTaxableCompIncome = vPrevTotalTaxable + vPresTotalComp
                        vNetTaxableCompIncome = vTotalTaxableCompIncome - _
                            vExemptionAmount - vHealthPremium
                        vPrevTotalNonTaxCompIncome = vPrevNonTax13thMonth + _
                            vPrevNonTaxDeMinimis + vPrevNonTaxSSS + vPrevNonTaxSalaries
                    Else  'without previous employer
                        vSchedNum = "D7.3"
                        vSubFiling = "N"
                        iSched(3) = iSched(3) + 1
                        iCtr = iSched(3)

                        'by froilan
                        vTotalTaxableCompIncome = vPresTaxableBasicSalary + _
                            vOtherIncentTax + vSalariesTax
                        vTotalNonTaxCompIncome = vOtherIncentNonTax + _
                            vPresNonTaxDeMinimis + vMandatory + vSalariesNonTax
                        vNetTaxableCompIncome = Math.Round( _
                            (vTotalTaxableCompIncome - vHealthPremium - _
                             vExemptionAmount), 2)
                    End If
                End If
            End If

            'froilan

            Dim vGrossCompIncome As Double = vSalariesTax + vOtherIncentTax + _
                vSalariesNonTax + vOtherIncentNonTax + vPrevTaxableSalaries + _
                vPrevTaxable13thMonth + vPrevNonTaxSalaries + vPrevNonTax13thMonth
            'end froilan

            'clean records first
            cmExec.CommandText = "delete from [1604f] where Emp_Cd='" & rs("Emp_Cd") & "'"
            cmExec.ExecuteNonQuery()

            'NOW SAVE EVERYTHING IN THE 1604F TABLE
            vDateResign = "null"
            If Not IsDBNull(rs("Date_Resign")) Then
                vDateResign = "'" & Format(CDate(rs("Date_Resign")), "yyyy/MM/dd") & "'"
            End If

            ' original inssert sql from vic
            'cmExec.CommandText = "insert into 1604f (Ftype_Cd,Tin_Emr,BranchCd_Emr,ReturnPd,Sched_Num,SeqId," & _
            '   "Fname,Lname,Mname,Tin_Emp,BranchCd_Emp,DateHired,DateResigned,Actual_Withheld," & _
            '   "Salaries_Tax,OtherIncent_Tax,TaxWithheld,Salaries_NonTax,OtherIncent_NonTax," & _
            '   "Prev_Taxable_Salaries,Prev_Taxable_13th_Month,Prev_Tax_Withheld,Prev_NonTax_Salaries," & _
            '   "Prev_NonTax_13th_Month,Mandatory,Prev_NonTax_Sss,Variance,TaxWithheld_Dec," & _
            '   "Exemption,TaxDue,Emp_Cd,AgencyCd,Premiums,Tax_Cd,Subs_Filing) values ('1604CF','" & txtTIN.Text & "','" & txtBranchCd.Text & _
            '   "','" & Format(vDate, "yyyy/MM/dd") & "','" & vSchedNum & "'," & iCtr & ",'" & rs("Emp_Fname") & _
            '   "','" & rs("Emp_Lname") & "','" & rs("Emp_Mname") & "','" & rs("Tin") & _
            '   "','" & txtBranchCd.Text & "','" & Format(CDate(rs("Start_Date")), "yyyy/MM/dd") & "'," & _
            '   vDateResign & "," & Math.Round(vCurrTaxWithheld + vTaxWithheldDec + vPrevTaxWithheld, 2) & "," & _
            '   Math.Round(vCurrTaxableSalary - vCurrMandatory, 2) & "," & Math.Round(vCurrTaxable13th, 2) & "," & _
            '   Math.Round(vCurrTaxWithheld, 2) & "," & Math.Round(vCurrNTaxableSalary, 2) & "," & _
            '   Math.Round(vCurrNTaxable13th, 2) & "," & Math.Round(vPrevTaxableSalary - vPrevMandatory, 2) & "," & _
            '   Math.Round(vPrevTaxable13th, 2) & "," & Math.Round(vPrevTaxWithheld, 2) & "," & _
            '   Math.Round(vPrevNTaxableSalary, 2) & "," & Math.Round(vPrevNTaxable13th, 2) & "," & _
            '   Math.Round(vCurrMandatory, 2) & "," & Math.Round(vPrevMandatory, 2) & "," & _
            '   Math.Round(vOverUnder, 2) & "," & Math.Round(vTaxWithheldDec, 2) & "," & _
            '   Math.Round(vExempt, 2) & "," & Math.Round(vTaxDue, 2) & ",'" & rs("Emp_Cd") & "','" & _
            '   cmbOfc.SelectedValue & "'," & vPremium & ",'" & rs("Tax_Cd") & "','" & vSubFiling & "')"

            'by froilan
            Dim sqlInsert As String
            sqlInsert = String.Format("INSERT INTO [1604F] (Ftype_Cd," & _
               "Tin_Emr,BranchCd_Emr,ReturnPd,Sched_Num,SeqId," & _
               "Fname,Lname,Mname,Tin_Emp,BranchCd_Emp," & _
               "DateHired,DateResigned," & _
               "Actual_Withheld," & _
               "Salaries_Tax,OtherIncent_Tax," & _
               "TaxWithheld,Salaries_NonTax," & _
               "OtherIncent_NonTax,Prev_Taxable_Salaries," & _
               "Prev_Taxable_13th_Month,Prev_Tax_Withheld," & _
               "Prev_NonTax_Salaries,Prev_NonTax_13th_Month," & _
               "Mandatory,Prev_NonTax_Sss," & _
               "Variance,TaxWithheld_Dec," & _
               "Exemption,TaxDue,Emp_Cd," & _
               "AgencyCd,Premiums,Tax_Cd,Subs_Filing," & _
               "Net_Taxable_Comp_Income, Gross_Comp_Income," & _
               "Prev_NonTax_De_Minimis,Total_NonTax_Comp_Income," & _
               "Pres_NonTax_De_Minimis,Pres_Taxable_Basic_Salary," & _
               "Total_Taxable_Comp_Income,Prev_Total_NonTax_Comp_Income," & _
               "Pres_Total_NonTax_Comp_Income,Prev_Taxable_Basic_Salary," & _
               "Prev_Total_Taxable,Pres_Total_Comp," & _
               "Prev_NonTax_Basic_Smw,Prev_NonTax_Holiday_Pay," & _
               "Prev_NonTax_Overtime_Pay,Prev_NonTax_Night_Diff," & _
               "Prev_NonTax_Hazard_Pay,Pres_NonTax_Holiday_Pay," & _
               "Pres_NonTax_Overtime_Pay,Pres_NonTax_Night_Diff," & _
               "Pres_NonTax_Hazard_Pay,NonTax_Basic_Sal," & _
               "Prev_NonTax_Gross_Comp_Income, Pres_NonTax_Gross_Comp_Income," & _
               "Pres_NonTax_Basic_Smw_Day,Pres_NonTax_Basic_Smw_Month," & _
               "Pres_NonTax_Basic_Smw_Year,Factor_Used," & _
               "Region_Num) values ('1604CF'," & _
               "'{0}','{1}','{2}','{3}',{4}," & _
               "'{5}','{6}','{7}','{8}','{9}'," & _
               "'{10}',{11}," & _
               "{12}," & _
               "{13},{14}," & _
               "{15},{16}," & _
               "{17},{18}," & _
               "{19},{20}," & _
               "{21},{22}," & _
               "{23},{24}," & _
               "{25},{26}," & _
               "{27},{28},'{29}'," & _
               "'{30}',{31},'{32}','{33}'," & _
               "{34},{35}," & _
               "{36},{37}," & _
               "{38},{39}," & _
               "{40},{41}," & _
               "{42},{43}," & _
               "{44},{45}," & _
               "{46},{47}," & _
               "{48},{49}," & _
               "{50},{51}," & _
               "{52},{53}," & _
               "{54},{55}," & _
               "{56},{57}," & _
               "{58},{59}," & _
               "{60},{61}," & _
               "'{62}'" & _
               ");", _
            txtTIN.Text.Replace("-", ""), txtBranchCd.Text, Format(vDate, "yyyy/MM/dd"), vSchedNum, iCtr, _
            rs("Emp_Fname"), rs("Emp_Lname"), rs("Emp_Mname"), rs("Tin").ToString.Replace("-", ""), txtBranchCd.Text, _
            Format(CDate(rs("Start_Date")), "yyyy/MM/dd"), vDateResign, _
            Math.Round(vCurrTaxWithheld + vTaxWithheldDec + vPrevTaxWithheld, 2), _
            vSalariesTax, vOtherIncentTax, _
            Math.Round(vCurrTaxWithheld, 2), vSalariesNonTax, _
            vOtherIncentNonTax, Math.Round(vPrevTaxableSalary - vPrevMandatory, 2), _
            vPrevTaxable13thMonth, Math.Round(vPrevTaxWithheld, 2), _
            vPrevNonTaxSalaries, vPrevNonTax13thMonth, _
            vMandatory, Math.Round(vCurrMandatory, 2), _
            Math.Round(vOverUnder, 2), Math.Round(vTaxWithheldDec, 2), _
            vExemptionAmount, Math.Round(vTaxDue, 2), rs("Emp_Cd"), _
            cmbOfc.SelectedValue, vHealthPremium, rs("Tax_Cd"), vSubFiling, _
            vNetTaxableCompIncome, vGrossCompIncome, _
            vPrevNonTaxDeMinimis, vTotalNonTaxCompIncome, _
            vPresNonTaxDeMinimis, vPresTaxableBasicSalary, _
            vTotalTaxableCompIncome, vPrevTotalNonTaxCompIncome, _
            vPresTotalNonTaxCompIncome, vPrevTaxableBasicSalary, _
            vPrevTotalTaxable, vPresTotalComp, _
            vPrevNonTaxBasicSmw, vPrevNonTaxHolidayPay, _
            vPrevNonTaxOvertimePay, vPrevNonTaxNightDiff, _
            vPrevNonTaxHazardPay, vPresNonTaxHolidayPay, _
            vPresNonTaxOvertimePay, vPresNonTaxNightDiff, _
            vPresNonTaxHazardPay, vNonTaxBasicSal, _
            vPrevNonTaxGrossCompIncome, vPresNonTaxGrossCompIncome, _
            vPresNonTaxBasicSmwDay, vPresNonTaxBasicSmwMonth, _
            vPresNonTaxBasicSmwYear, vFactorUsed, _
            vRegionNum)

            cmExec.CommandText = sqlInsert

            'end froilan
            Try
                cmExec.ExecuteNonQuery()
            Catch ex As sqlclient.sqlException
                Response.Write("Error: " & ex.Message & "<br/>")
                'Response.Write(cmExec.CommandText)
                Exit Do
            End Try
            iSeq = iSeq + 1
        Loop
        rs.Close()

        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        ''''''''''''       now get employees who are moved to different locale during the year '''''''''
        ''''''''''''      THIS CODE WAS INSERTED FOR VICTORIA COURT POLICY ONLY!               '''''''''
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        'get list of employees for the year
        'cm.CommandText = "select Emp_Cd,Emp_Lname,Emp_Fname,Emp_Mname,Tax_Cd,Start_Date,Tin " & _
        '    "from py_emp_master where Emp_Cd in (" & _
        '    "select distinct Emp_Cd from py_report where Agency_Cd='" & cmbOfc.SelectedValue & _
        '    "' and year(PayDate)=" & vDate.Year & " and Emp_Cd not in " & _
        '    "(select Emp_Cd from py_emp_master where Agency_Cd='" & cmbOfc.SelectedValue & _
        '    "')) order by Emp_Lname,Emp_Fname,Emp_Mname"

        'iSeq = 1
        'rs = cm.ExecuteReader
        'Do While rs.Read
        '    'get last payroll date
        '    cmRef.CommandText = "select ToDate from py_report where Agency_Cd='" & cmbOfc.SelectedValue & _
        '        "' and year(PayDate)=" & vDate.Year & " and Emp_Cd='" & rs("Emp_Cd") & _
        '        "' order by PayDate desc limit 1"
        '    rsRef = cmRef.ExecuteReader
        '    vDateResign = "null"
        '    If rsRef.Read Then
        '        vDateResign = "'" & Format(CDate(rsRef("ToDate")), "yyyy/MM/dd") & "'"
        '    End If
        '    rsRef.Close()

        '    'get tax exemption of employee
        '    cmRef.CommandText = "select Exemption from py_tax_ref where Tax_Cd='" & _
        '       rs("Tax_Cd") & "'"
        '    rsRef = cmRef.ExecuteReader
        '    vExempt = 0
        '    If rsRef.Read Then
        '        vExempt = IIf(IsDBNull(rsRef("Exemption")), 0, rsRef("Exemption"))
        '    End If
        '    rsRef.Close()
        '    'GET PREV EMPLOYER'S INCOME
        '    cmRef.CommandText = "select GrossTaxable,Tax13th,TaxWithHeld,GrossNonTax,NonTax13th,NonTaxSss" & _
        '       " from py_prev_employer_income where Emp_Cd='" & rs("Emp_Cd") & _
        '       "' and YearCd=" & vDate.Year
        '    rsRef = cmRef.ExecuteReader
        '    vWithPrevEmployer = False
        '    If rsRef.Read Then
        '        vWithPrevEmployer = True
        '        vPrevTaxableSalary = IIf(IsDBNull(rsRef("GrossTaxable")), 0, rsRef("GrossTaxable"))
        '        vPrevTaxable13th = IIf(IsDBNull(rsRef("Tax13th")), 0, rsRef("Tax13th"))
        '        vPrevTaxWithheld = IIf(IsDBNull(rsRef("TaxWithHeld")), 0, rsRef("TaxWithHeld"))
        '        vPrevNTaxableSalary = IIf(IsDBNull(rsRef("GrossNonTax")), 0, rsRef("GrossNonTax"))
        '        vPrevNTaxable13th = IIf(IsDBNull(rsRef("NonTax13th")), 0, rsRef("NonTax13th"))
        '        vPrevMandatory = IIf(IsDBNull(rsRef("NonTaxSss")), 0, rsRef("NonTaxSss"))
        '    Else
        '        vPrevTaxableSalary = 0
        '        vPrevTaxable13th = 0
        '        vPrevTaxWithheld = 0
        '        vPrevNTaxableSalary = 0
        '        vPrevNTaxable13th = 0
        '        vPrevMandatory = 0
        '    End If
        '    rsRef.Close()

        '    vTaxWithheldDec = 0

        '    'GET CURRENT INCOME
        '    cmRef.CommandText = "select sum(Month_Rate) as Gross, sum(Absent+Tardiness) as Absents," & _
        '       "sum(Ot) as OtTotal, sum(0) as Transpo,sum(Aca+Pera) as Fnd,sum(G1+G2+G3) as OfcOt," & _
        '       "sum(Other_Incent1) as Incent1, sum(Other_Incent2) as Incent2," & _
        '       "sum(Other_Incent3) as Incent3, sum(Other_Incent4) as Incent4," & _
        '       "sum(Other_Incent5) as Incent5, sum(Other_Incent6) as Incent6," & _
        '       "sum(Other_Incent7) as Incent7, sum(Other_Incent8) as Incent8," & _
        '       "sum(Other_Incent9) as Incent9, sum(Other_Incent10) as Incent10," & _
        '       "sum(Other_Incent11) as Incent11, sum(Other_Incent12) as Incent12," & _
        '       "sum(Other_Incent13) as Incent13, sum(Other_Incent14) as Incent14," & _
        '       "sum(Other_Incent15) as Incent15, sum(Other_Incent16) as Incent16," & _
        '       "sum(Other_Incent17) as Incent17, sum(Other_Incent18) as Incent18," & _
        '       "sum(Other_Incent19) as Incent19, sum(Other_Incent20) as Incent20," & _
        '       "sum(Other_Incent21) as Incent21, sum(Other_Incent22) as Incent22," & _
        '       "sum(Other_Incent23) as Incent23, sum(Other_Incent24) as Incent24," & _
        '       "sum(Other_Incent25) as Incent25, sum(Other_Incent26) as Incent26," & _
        '       "sum(Other_Incent27) as Incent27, sum(Other_Incent28) as Incent28," & _
        '       "sum(Other_Incent29) as Incent29, sum(Other_Incent30) as Incent30," & _
        '       "sum(Other_Incent31) as Incent31, sum(Other_Incent32) as Incent32," & _
        '       "sum(Other_Incent33) as Intent33, sum(Other_Incent34) as Incent34," & _
        '       "sum(Other_Incent35) as Intent35, sum(Other_Incent36) as Incent36," & _
        '       "sum(Other_Incent37) as Intent37, sum(Other_Incent38) as Incent38," & _
        '       "sum(Other_Incent39) as Intent39, sum(Other_Incent40) as Incent40," & _
        '       "sum(Other_Incent41) as Intent41, sum(Other_Incent42) as Incent42," & _
        '       "sum(Other_Incent43) as Intent43, sum(Other_Incent44) as Incent44," & _
        '       "sum(Other_Incent45) as Intent45, sum(Other_Incent46) as Incent46," & _
        '       "sum(Other_Incent47) as Intent47, sum(Other_Incent48) as Incent48," & _
        '       "sum(Other_Incent49) as Intent49, sum(Other_Incent50) as Incent50," & _
        '       "sum(Other_Incent51) as Intent51, sum(Other_Incent52) as Incent52," & _
        '       "sum(Other_Incent53) as Intent53, sum(Other_Incent54) as Incent54," & _
        '       "sum(Other_Incent55) as Intent55, sum(Other_Incent56) as Incent56," & _
        '       "sum(Other_Incent57) as Intent57, sum(Other_Incent58) as Incent58," & _
        '       "sum(Other_Incent59) as Intent59, sum(Other_Incent60) as Incent60," & _
        '       "sum(With_Tax) as WithTax, sum(Sss_Per) as SssEmp,  " & _
        '       "sum(PagIbig_Per) as PagIbigEmp,sum(Medicare_Per) as MedEmp " & _
        '       "from py_report where Agency_Cd='" & cmbOfc.SelectedValue & _
        '       "' and year(PayDate)=" & vDate.Year & " and Emp_Cd='" & rs("Emp_Cd") & "'"

        '    rsRef = cmRef.ExecuteReader
        '    If rsRef.Read Then
        '        vCurrTaxableSalary = IIf(IsDBNull(rsRef("Gross")), 0, rsRef("Gross")) + _
        '           IIf(IsDBNull(rsRef("Absents")), 0, rsRef("Absents")) + _
        '           IIf(IsDBNull(rsRef("Transpo")), 0, rsRef("Transpo")) + _
        '           IIf(IsDBNull(rsRef("Fnd")), 0, rsRef("Fnd")) + _
        '           IIf(IsDBNull(rsRef("OtTotal")), 0, rsRef("OtTotal")) - _
        '           IIf(IsDBNull(rsRef("OfcOt")), 0, rsRef("OfcOt"))
        '        vCurrTaxWithheld = IIf(IsDBNull(rsRef("WithTax")), 0, rsRef("WithTax")) - vTaxWithheldDec
        '        vCurrMandatory = IIf(IsDBNull(rsRef("SssEmp")), 0, rsRef("SssEmp")) + _
        '           IIf(IsDBNull(rsRef("PagibigEmp")), 0, rsRef("PagibigEmp")) + _
        '           IIf(IsDBNull(rsRef("MedEmp")), 0, rsRef("MedEmp"))

        '        'GET NONTAXABLE SALARIES
        '        vCurrNTaxableSalary = GetNonTaxableSalary(vNTaxIncentives, rsRef)

        '        'GET TAXABLE INCOME BY GROUP
        '        Dim vIncent As String()
        '        vCurrTaxable13th = 0
        '        vCurrNTaxable13th = 0
        '        For iGrp = 0 To UBound(vTaxGroup)
        '            vTot = 0
        '            vIncent = vIncentives(iGrp).Split(",")
        '            For iCtr = 0 To UBound(vIncent)
        '                vIdx = GetNumber(vIncent(iCtr))
        '                If vIdx <> 0 Then
        '                    vTot = vTot + IIf(IsDBNull(rsRef("Incent" & vIdx)), 0, rsRef("Incent" & vIdx))
        '                End If
        '            Next iCtr
        '            If vTaxGroup(iGrp) <> 30000 Then 'INCLUDE TO TAXABLE SALARY
        '                vCurrTaxable13th += vTot
        '            Else  'TAXGROUP IS 30000   (THIS IS 13TH MONTH AND OTHER BENEFITS)
        '                If vTot - vTaxGroup(iGrp) < 0 Then
        '                    vCurrNTaxable13th = vTot
        '                    vCurrTaxable13th = 0
        '                Else
        '                    vCurrNTaxable13th = vTaxGroup(iGrp)
        '                    vCurrTaxable13th = vTot - vTaxGroup(iGrp)
        '                End If
        '            End If
        '        Next iGrp
        '    End If
        '    rsRef.Close()

        '    'GET TAXDUE BasED ON ANNUAL TAX
        '    vTaxableAmt = vCurrTaxableSalary + vCurrTaxable13th + vPrevTaxableSalary + _
        '       vPrevTaxable13th - vCurrMandatory - vPrevMandatory - vExempt - vPremium

        '    'GET TAX TABLE BasED ON GROSS AND ANNUAL TAX
        '    vStr = "select * from py_tax_table where Freq_Cd = 'ANNUAL' " & _
        '         "and Tax_Cd='ANNUAL' and " & vTaxableAmt & " >= Check_Amt order by Check_Amt desc"

        '    cmRef.CommandText = vStr
        '    rsRef = cmRef.ExecuteReader
        '    If rsRef.Read Then
        '        vTaxDue = rsRef("Add_Amt") + (rsRef("Factor") * (vTaxableAmt - rsRef("Check_Amt")))
        '    Else  'NEGATIVE
        '        vTaxDue = 0
        '    End If
        '    rsRef.Close()

        '    vOverUnder = vTaxDue - (vCurrTaxWithheld + vTaxWithheldDec + vPrevTaxWithheld)

        '    'set schedule number
        '    vSchedNum = "D7.1"
        '    iSched(1) += 1
        '    iCtr = iSched(1)

        '    'NOW SAVE EVERYTHING IN THE 1604F TABLE
        '    cmExec.CommandText = "insert into 1604f (Ftype_Cd,Tin_Emr,BranchCd_Emr,ReturnPd,Sched_Num,SeqId," & _
        '       "Fname,Lname,Mname,Tin_Emp,BranchCd_Emp,DateHired,DateResigned,Actual_Withheld," & _
        '       "Salaries_Tax,OtherIncent_Tax,TaxWithheld,Salaries_NonTax,OtherIncent_NonTax," & _
        '       "Prev_Taxable_Salaries,Prev_Taxable_13th_Month,Prev_Tax_Withheld,Prev_NonTax_Salaries," & _
        '       "Prev_NonTax_13th_Month,Mandatory,Prev_NonTax_Sss,Variance,TaxWithheld_Dec," & _
        '       "Exemption,TaxDue,Emp_Cd,AgencyCd,Premiums) values ('1604CF','" & txtTIN.Text & "','" & txtBranchCd.Text & _
        '       "','" & Format(vDate, "yyyy/MM/dd") & "','" & vSchedNum & "'," & iCtr & ",'" & rs("Emp_Fname") & _
        '       "','" & rs("Emp_Lname") & "','" & rs("Emp_Mname") & "','" & rs("Tin") & _
        '       "','" & txtBranchCd.Text & "','" & Format(CDate(rs("Start_Date")), "yyyy/MM/dd") & "'," & _
        '       vDateResign & "," & Math.Round(vCurrTaxWithheld + vTaxWithheldDec + vPrevTaxWithheld, 2) & "," & _
        '       Math.Round(vCurrTaxableSalary - vCurrMandatory, 2) & "," & Math.Round(vCurrTaxable13th, 2) & "," & _
        '       Math.Round(vCurrTaxWithheld, 2) & "," & Math.Round(vCurrNTaxableSalary, 2) & "," & _
        '       Math.Round(vCurrNTaxable13th, 2) & "," & Math.Round(vPrevTaxableSalary - vPrevMandatory, 2) & "," & _
        '       Math.Round(vPrevTaxable13th, 2) & "," & Math.Round(vPrevTaxWithheld, 2) & "," & _
        '       Math.Round(vPrevNTaxableSalary, 2) & "," & Math.Round(vPrevNTaxable13th, 2) & "," & _
        '       Math.Round(vCurrMandatory, 2) & "," & Math.Round(vPrevMandatory, 2) & "," & _
        '       Math.Round(vOverUnder, 2) & "," & Math.Round(vTaxWithheldDec, 2) & "," & _
        '       Math.Round(vExempt, 2) & "," & Math.Round(vTaxDue, 2) & ",'" & rs("Emp_Cd") & "','" & _
        '       cmbOfc.SelectedValue & "'," & vPremium & ")"

        '    cmExec.ExecuteNonQuery()
        '    iSeq = iSeq + 1
        'Loop
        'rs.Close()


        vScript = "alert('Process complete!'); document.getElementById('divWait').style.visibility='hidden';"
        '''''''''''' close connections
        rsSysCntrl.Close()
        cmSysCntrl.Dispose()
        cm.Dispose()
        cmExec.Dispose()
        cmRef.Dispose()
        c.Close()
        DataRefresh()
    End Sub

    Private Function GetNumber(ByVal pIncentive As String) As Integer
        Dim iCtr As Integer
        For iCtr = 1 To 30
            If rsSysCntrl("OthIncent" & iCtr & "Cd") = pIncentive Then
                GetNumber = iCtr
                Exit For
            End If
        Next iCtr
    End Function

    Protected Sub cmbReportType_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbReportType.SelectedIndexChanged
        DataRefresh()
    End Sub
    Private Sub Dump()
        Dim cm As New sqlclient.sqlCommand
        Dim rs As sqlclient.sqlDataReader
        Dim vDump As String = ""
        Dim vDateResign As String = ""

        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c
        cm.CommandText = "select * from [1604f] where AgencyCd='" & cmbOfc.SelectedValue & _
            "' and ReturnPd='" & Format(CDate(txtPeriod.Text), "yyyy/MM/dd") & "'"
        rs = cm.ExecuteReader
        Do While rs.Read
            vDateResign = ""
            If Not IsDBNull(rs("DateResigned")) Then
                vDateResign = Format(CDate(rs("DateResigned")), "yyyy/MM/dd")
            End If
            'vDump += rs("Emp_Cd") & "," & rs("Ftype_Cd") & "," & rs("Tin_Emr") & "," & rs("BranchCd_Emr") & _
            '    "," & Format(CDate(rs("ReturnPd")), "MM/dd/yyyy") & "," & rs("Sched_Num") & "," & _
            '    rs("SeqId") & "," & rs("Fname") & "," & rs("Lname") & "," & rs("Mname") & "," & _
            '    rs("Tin_Emp") & "," & rs("BranchCd_Emp") & "," & Format(CDate(rs("DateHired")), "MM/dd/yyyy") & _
            '    "," & vDateResign & "," & rs("Actual_Withheld") & "," & _
            '    rs("Salaries_Tax") & "," & rs("OtherIncent_Tax") & "," & rs("TaxWithheld") & "," & _
            '    rs("Salaries_NonTax") & "," & rs("OtherIncent_NonTax") & "," & rs("Prev_Taxable_Salaries") & _
            '    "," & rs("Prev_Taxable_13th_Month") & "," & rs("Prev_Tax_Withheld") & "," & _
            '    rs("Prev_NonTax_Salaries") & "," & rs("Prev_NonTax_13th_Month") & "," & rs("Mandatory") & "," & _
            '    rs("Prev_NonTax_SSS") & "," & rs("Variance") & "," & rs("TaxWithheld_Dec") & "," & _
            '    rs("Exemption") & "," & rs("TaxDue") & "," & rs("Premiums") & "," & rs("AgencyCd") & vbCrLf


            'froilanv
            vDump += String.Format( _
                "'{0}','{1}','{2}',{3},'{4}',{5},'{6}','{7}','{8}','{9}','{10}'," & _
                "'{11}',{12},{13},'{14}','{15}','{16}','{17}','{18}',{19},{20}," & _
                "{21},{22},{23},{24},{25},{26},{27},{28},{29},{30}," & _
                "{31},{32},{33},{34},{35},{36},{37},{38},{39},{40}," & _
                "{41},{42},{43},{44},{45},{46},{47},{48},{49},{50}," & _
                "{51},{52},{53},{54},{55},{56},{57},{58},{59},{60}," & _
                "{61},{62},{63},{64},{65},{66},{67},{68},{69},{70},{71}", _
                rs("Ftype_Cd"), _
                rs("Tin_Emr"), _
                rs("BranchCd_Emr"), _
                IIf(IsDBNull(rs("ReturnPd")), "null", "{^" & Format(rs("ReturnPd"), "yyyy/MM/dd") & "}"), _
                rs("Sched_Num"), _
                IIf(IsDBNull(rs("SeqId")), 0, rs("SeqId")), _
                "", _
                rs("Fname"), _
                rs("Lname"), _
                rs("Mname"), _
                rs("Tin_Emp"), _
                rs("BranchCd_Emp"), _
                IIf(IsDBNull(rs("DateHired")), "null", "{^" & Format(rs("DateHired"), "yyyy/MM/dd") & "}"), _
                IIf(vDateResign = "", "null", "{^" & vDateResign & "}"), _
                "", _
                "", _
                rs("Region_Num"), _
                rs("Subs_Filing"), _
                rs("Tax_Cd"), _
                IIf(IsDBNull(rs("Factor_Used")), 0, rs("Factor_Used")), _
                IIf(IsDBNull(rs("Actual_Withheld")), 0, rs("Actual_Withheld")), _
                IIf(IsDBNull(rs("Income_Payment")), 0, rs("Income_Payment")), _
                IIf(IsDBNull(rs("Salaries_Tax")), 0, rs("Salaries_Tax")), _
                IIf(IsDBNull(rs("OtherIncent_Tax")), 0, rs("OtherIncent_Tax")), _
                IIf(IsDBNull(rs("TaxWithheld")), 0, rs("TaxWithheld")), _
                IIf(IsDBNull(rs("Salaries_NonTax")), 0, rs("Salaries_NonTax")), _
                IIf(IsDBNull(rs("OtherIncent_NonTax")), 0, rs("OtherIncent_NonTax")), _
                IIf(IsDBNull(rs("Prev_Taxable_Salaries")), 0, rs("Prev_Taxable_Salaries")), _
                IIf(IsDBNull(rs("Prev_Taxable_13th_Month")), 0, rs("Prev_Taxable_13th_Month")), _
                IIf(IsDBNull(rs("Prev_Tax_Withheld")), 0, rs("Prev_Tax_Withheld")), _
                IIf(IsDBNull(rs("Prev_NonTax_Salaries")), 0, rs("Prev_NonTax_Salaries")), _
                IIf(IsDBNull(rs("Prev_NonTax_13th_Month")), 0, rs("Prev_NonTax_13th_Month")), _
                IIf(IsDBNull(rs("Mandatory")), 0, rs("Mandatory")), _
                IIf(IsDBNull(rs("Prev_NonTax_SSS")), 0, rs("Prev_NonTax_SSS")), _
                IIf(IsDBNull(rs("Tax_Rate")), 0, rs("Tax_Rate")), _
                IIf(IsDBNull(rs("Variance")), 0, rs("Variance")), _
                IIf(IsDBNull(rs("TaxWithheld_Dec")), 0, rs("TaxWithheld_Dec")), _
                IIf(IsDBNull(rs("Exemption")), 0, rs("Exemption")), _
                IIf(IsDBNull(rs("TaxDue")), 0, rs("TaxDue")), _
                IIf(IsDBNull(rs("Premiums")), 0, rs("Premiums")), _
                IIf(IsDBNull(rs("Fringe_Benefit")), 0, rs("Fringe_Benefit")), _
                IIf(IsDBNull(rs("Monetary_Value")), 0, rs("Monetary_Value")), _
                IIf(IsDBNull(rs("Net_Taxable_Comp_Income")), 0, rs("Net_Taxable_Comp_Income")), _
                IIf(IsDBNull(rs("Gross_Comp_Income")), 0, rs("Gross_Comp_Income")), _
                IIf(IsDBNull(rs("Prev_NonTax_De_Minimis")), 0, rs("Prev_NonTax_De_Minimis")), _
                IIf(IsDBNull(rs("Prev_Total_NonTax_Comp_Income")), 0, rs("Prev_Total_NonTax_Comp_Income")), _
                IIf(IsDBNull(rs("Prev_Taxable_Basic_Salary")), 0, rs("Prev_Taxable_Basic_Salary")), _
                IIf(IsDBNull(rs("Pres_NonTax_De_Minimis")), 0, rs("Pres_NonTax_De_Minimis")), _
                IIf(IsDBNull(rs("Pres_Taxable_Basic_Salary")), 0, rs("Pres_Taxable_Basic_Salary")), _
                IIf(IsDBNull(rs("Pres_Total_Comp")), 0, rs("Pres_Total_Comp")), _
                IIf(IsDBNull(rs("Prev_Pres_Total_Taxable")), 0, rs("Prev_Pres_Total_Taxable")), _
                IIf(IsDBNull(rs("Pres_Total_NonTax_Comp_Income")), 0, rs("Pres_Total_NonTax_Comp_Income")), _
                IIf(IsDBNull(rs("Prev_NonTax_Gross_Comp_Income")), 0, rs("Prev_NonTax_Gross_Comp_Income")), _
                IIf(IsDBNull(rs("Prev_NonTax_Basic_Smw")), 0, rs("Prev_NonTax_Basic_Smw")), _
                IIf(IsDBNull(rs("Prev_NonTax_Holiday_Pay")), 0, rs("Prev_NonTax_Holiday_Pay")), _
                IIf(IsDBNull(rs("Prev_NonTax_Overtime_Pay")), 0, rs("Prev_NonTax_Overtime_Pay")), _
                IIf(IsDBNull(rs("Prev_NonTax_Night_Diff")), 0, rs("Prev_NonTax_Night_Diff")), _
                IIf(IsDBNull(rs("Prev_NonTax_Hazard_Pay")), 0, rs("Prev_NonTax_Hazard_Pay")), _
                IIf(IsDBNull(rs("Pres_NonTax_Gross_Comp_Income")), 0, rs("Pres_NonTax_Gross_Comp_Income")), _
                IIf(IsDBNull(rs("Pres_NonTax_Basic_Smw_Day")), 0, rs("Pres_NonTax_Basic_Smw_Day")), _
                IIf(IsDBNull(rs("Pres_NonTax_Basic_Smw_Month")), 0, rs("Pres_NonTax_Basic_Smw_Month")), _
                IIf(IsDBNull(rs("Pres_NonTax_Basic_Smw_Year")), 0, rs("Pres_NonTax_Basic_Smw_Year")), _
                IIf(IsDBNull(rs("Pres_NonTax_Holiday_Pay")), 0, rs("Pres_NonTax_Holiday_Pay")), _
                IIf(IsDBNull(rs("Pres_NonTax_Overtime_Pay")), 0, rs("Pres_NonTax_Overtime_Pay")), _
                IIf(IsDBNull(rs("Pres_NonTax_Night_Diff")), 0, rs("Pres_NonTax_Night_Diff")), _
                IIf(IsDBNull(rs("Prev_Pres_Total_Comp_Income")), 0, rs("Prev_Pres_Total_Comp_Income")), _
                IIf(IsDBNull(rs("Pres_NonTax_Hazard_Pay")), 0, rs("Pres_NonTax_Hazard_Pay")), _
                IIf(IsDBNull(rs("Total_NonTax_Comp_Income")), 0, rs("Total_NonTax_Comp_Income")), _
                IIf(IsDBNull(rs("Total_Taxable_Comp_Income")), 0, rs("Total_Taxable_Comp_Income")), _
                IIf(IsDBNull(rs("Prev_Total_Taxable")), 0, rs("Prev_Total_Taxable")), _
                IIf(IsDBNull(rs("Prev_Total_Taxable")), 0, rs("Prev_Total_Taxable")), _
                IIf(IsDBNull(rs("Tax_Basic_Sal")), 0, rs("Tax_Basic_Sal")) _
            ) & vbNewLine
            'end froilan

        Loop
        rs.Close()

        If Dir(Server.MapPath(".") & "\downloads\" & Session.SessionID & "-bir.csv") <> "" Then
            Try
                IO.File.Delete(Server.MapPath(".") & "\downloads\" & Session.SessionID & "-bir.csv")
            Catch ex As IO.IOException
            End Try
        End If
        IO.File.WriteAllText(Server.MapPath(".") & "\downloads\" & Session.SessionID & "-bir.csv", vDump)
        lnkDownload.NavigateUrl = "downloads/" & Session.SessionID & "-bir.csv"

    End Sub

    Protected Sub cmdProcess_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdProcess.Init
        cmdProcess.Attributes.Add("onclick", "javascript:document.getElementById('divWait').style.visibility='visible';")
    End Sub

    Protected Sub tbl1604_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles tbl1604.PageIndexChanging
        tbl1604.PageIndex = e.NewPageIndex
        DataRefresh()
    End Sub

End Class
