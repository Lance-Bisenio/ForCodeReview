﻿Imports denaro.fis
Partial Class editpayroll
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Or Session("uid") = Nothing Then
            vScript = "alert('Your login session has expired. Please re-login again.'); window.close();"
            Exit Sub
        End If

        If Not IsPostBack Then
            Dim c As New SqlClient.SqlConnection(connStr)
            Dim cm As New SqlClient.SqlCommand
            Dim rs As SqlClient.SqlDataReader
            Dim vOtherInc As Decimal = 0
            Dim vOtherDed As Decimal = 0
            Dim iCtr As Integer

            Try
                c.Open()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                c.Dispose()
                cm.Dispose()
                Exit Sub
            End Try

            cm.Connection = c
            cm.CommandText = "select * from py_report where Emp_Cd='" & Request.Item("e") & "' and PayDate='" & _
                Format(CDate(Request.Item("p")), "yyyy/MM/dd") & "'"

            Try
                rs = cm.ExecuteReader
                If rs.Read Then
                    For iCtr = 1 To 60
                        vOtherInc += rs("Other_Incent" & iCtr)
                        vOtherDed += rs("Other_Deduct" & iCtr)
                    Next
                    txtEmpCd.Text = rs("Emp_Cd")
                    txtPayDate.Text = Format(rs("PayDate"), "MM/dd/yyyy")
                    txtEmpName.Text = rs("Name")
                    txtBasic.Text = rs("BasicRate")
                    txtMeal.Text = rs("MealAllow")
                    txtSeniorAllowance.Text = rs("SeniorAllowance")
                    txtACA.Text = rs("Aca")
                    txtRATA.Text = rs("Rata")
                    txtPERA.Text = rs("Pera")
                    txtOT.Text = rs("Ot")
                    txtOthInc.Text = vOtherInc
                    txtTotInc.Text = rs("BasicRate") + rs("MealAllow") + rs("Aca") + rs("Rata") + rs("Pera") + rs("Ot") + vOtherInc
                    txtAbsent.Text = rs("Absent") * -1
                    txtTardy.Text = rs("Tardiness") * -1
                    txtUnionDues.Text = rs("UnionDues")
                    txtTax.Text = rs("With_Tax")
                    txtSSS_Emp.Text = rs("Sss_Per")
                    txtSSS_Emr.Text = rs("Sss_Gov")
                    txtEC.Text = rs("Ec")
                    txtPAGIBIG_Emp.Text = rs("Pagibig_Per")
                    txtPAGIBIG_Emr.Text = rs("Pagibig_Gov")
                    txtPHIC_Emp.Text = rs("Medicare_Per")
                    txtPHIC_Emr.Text = rs("Medicare_Gov")
                    txtGSIS_Emp.Text = rs("Gsis_Per")
                    txtGSIS_Emr.Text = rs("Gsis_Gov")
                    txtOthDed.Text = vOtherDed
                    txtTotDed.Text = (rs("Absent") * -1) + (rs("Tardiness") * -1) + _
                        rs("With_Tax") + rs("Sss_Per") + rs("Pagibig_Per") + rs("Medicare_Per") + _
                        rs("Gsis_Per") + vOtherDed
                    txtNetPay.Text = rs("Amount_Per")

                    Session("otval") = "|A1=" & rs("A1") & _
                        "|A2=" & rs("A2") & _
                        "|A3=" & rs("A3") & _
                        "|A4=" & rs("A4") + rs("NdReg") & _
                        "|B1=" & rs("B1") & _
                        "|B2=" & rs("B2") & _
                        "|B3=" & rs("B3") & _
                        "|B4=" & rs("B4") & _
                        "|C1=" & rs("C1") & _
                        "|C2=" & rs("C2") & _
                        "|C3=" & rs("C3") & _
                        "|C4=" & rs("C4") & _
                        "|D1=" & rs("D1") & _
                        "|D2=" & rs("D2") & _
                        "|D3=" & rs("D3") & _
                        "|D4=" & rs("D4") & _
                        "|E1=" & rs("E1") & _
                        "|E2=" & rs("E2") & _
                        "|E3=" & rs("E3") & _
                        "|E4=" & rs("E4") & _
                        "|F1=" & rs("F1") & _
                        "|F2=" & rs("F2") & _
                        "|F3=" & rs("F3") & _
                        "|F4=" & rs("F4") & _
                        "|G1=" & rs("G1") & _
                        "|G2=" & rs("G2") & _
                        "|G3=" & rs("G3")
                    Session("oldval") = " MealAllow=" & txtMeal.Text & _
                        "|Aca=" & txtACA.Text & _
                        "|Rata=" & txtRATA.Text & _
                        "|Pera=" & txtPERA.Text & _
                        "|Ot=" & txtOT.Text & _
                        Session("otval") & _
                        "|Absent=" & txtAbsent.Text & _
                        "|Tardiness=" & txtTardy.Text & _
                        "|Union Dues=" & txtUnionDues.Text & _
                        "|With_Tax=" & txtTax.Text & _
                        "|Sss_Per=" & txtSSS_Emp.Text & _
                        "|Sss_Gov=" & txtSSS_Emr.Text & _
                        "|Ec=" & txtEC.Text & _
                        "|Pagibig_Per=" & txtPAGIBIG_Emp.Text & _
                        "|Pagibig_Gov=" & txtPAGIBIG_Emr.Text & _
                        "|Medicare_Per=" & txtPHIC_Emp.Text & _
                        "|Medicare_Gov=" & txtPHIC_Emr.Text & _
                        "|Gsis_Per=" & txtGSIS_Emp.Text & _
                        "|Gsis_Gov=" & txtGSIS_Emr.Text & _
                        "|Amount_Per=" & txtNetPay.Text
                Else
                    vScript = "alert('No records retrieved.'); window.close();"
                End If
                rs.Close()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to retrieve the record. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            Finally
                c.Close()
                c.Dispose()
                cm.Dispose()
            End Try
        End If
    End Sub

    Protected Sub txtMeal_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtMeal.Init
        txtMeal.Attributes.Add("onblur", "recompute();")
    End Sub

    Protected Sub txtACA_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtACA.Init
        txtACA.Attributes.Add("onblur", "recompute();")
    End Sub

    Protected Sub txtRATA_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtRATA.Init
        txtRATA.Attributes.Add("onblur", "recompute();")
    End Sub

    Protected Sub txtPERA_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtPERA.Init
        txtPERA.Attributes.Add("onblur", "recompute();")
    End Sub

    Protected Sub txtAbsent_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtAbsent.Init
        txtAbsent.Attributes.Add("onblur", "recompute();")
    End Sub

    Protected Sub txtTardy_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtTardy.Init
        txtTardy.Attributes.Add("onblur", "recompute();")
    End Sub

    Protected Sub txtTax_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtTax.Init
        txtTax.Attributes.Add("onblur", "recompute();")
    End Sub

    Protected Sub txtSSS_Emp_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtSSS_Emp.Init
        txtSSS_Emp.Attributes.Add("onblur", "recompute();")
    End Sub

    Protected Sub txtSSS_Emr_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtSSS_Emr.Init
        txtSSS_Emr.Attributes.Add("onblur", "recompute();")
    End Sub

    Protected Sub txtEC_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtEC.Init
        txtEC.Attributes.Add("onblur", "recompute();")
    End Sub

    Protected Sub txtPAGIBIG_Emp_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtPAGIBIG_Emp.Init
        txtPAGIBIG_Emp.Attributes.Add("onblur", "recompute();")
    End Sub

    Protected Sub txtPAGIBIG_Emr_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtPAGIBIG_Emr.Init
        txtPAGIBIG_Emr.Attributes.Add("onblur", "recompute();")
    End Sub

    Protected Sub txtPHIC_Emp_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtPHIC_Emp.Init
        txtPHIC_Emp.Attributes.Add("onblur", "recompute();")
    End Sub

    Protected Sub txtPHIC_Emr_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtPHIC_Emr.Init
        txtPHIC_Emr.Attributes.Add("onblur", "recompute();")
    End Sub

    Protected Sub txtGSIS_Emp_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtGSIS_Emp.Init
        txtGSIS_Emp.Attributes.Add("onblur", "recompute();")
    End Sub

    Protected Sub txtGSIS_Emr_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtGSIS_Emr.Init
        txtGSIS_Emr.Attributes.Add("onblur", "recompute();")
    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        '''''validate each field to ensure proper numeric value '''''''''''''''''
        If Not IsNumeric(txtMeal.Text) Then
            vScript = "alert('Meal Allowance field should be numeric.');"
            Exit Sub
        End If
        If Not IsNumeric(txtSeniorAllowance.Text) Then
            vScript = "alert('Senior Allowance field should be numeric.');"
            Exit Sub
        End If
        If Not IsNumeric(txtACA.Text) Then
            vScript = "alert('Additional Compensation Allowance (ACA) field should be numeric.');"
            Exit Sub
        End If
        If Not IsNumeric(txtRATA.Text) Then
            vScript = "alert('Representation and Transpo Allowance (RATA) field should be numeric.');"
            Exit Sub
        End If
        If Not IsNumeric(txtPERA.Text) Then
            vScript = "alert('Personal Emergency and Relieve Allowance (PERA) field should be numeric.');"
            Exit Sub
        End If
        If Not IsNumeric(txtAbsent.Text) Then
            vScript = "alert('Absences field should be numeric.');"
            Exit Sub
        End If
        If Not IsNumeric(txtTardy.Text) Then
            vScript = "alert('Tardiness and Undertime field should be numeric.');"
            Exit Sub
        End If
        If Not IsNumeric(txtUnionDues.Text) Then
            vScript = "alert('Union Dues field should be numeric.');"
            Exit Sub
        End If
        If Not IsNumeric(txtTax.Text) Then
            vScript = "alert('Withholding Tax field should be numeric.');"
            Exit Sub
        End If
        If Not IsNumeric(txtSSS_Emp.Text) Then
            vScript = "alert('SSS Employee contribution should be numeric.');"
            Exit Sub
        End If
        If Not IsNumeric(txtSSS_Emr.Text) Then
            vScript = "alert('SSS Employer contribution should be numeric.');"
            Exit Sub
        End If
        If Not IsNumeric(txtEC.Text) Then
            vScript = "alert('EC field should be numeric.');"
            Exit Sub
        End If
        If Not IsNumeric(txtPAGIBIG_Emp.Text) Then
            vScript = "alert('PAGIBIG Employee contribution should be numeric.');"
            Exit Sub
        End If
        If Not IsNumeric(txtPAGIBIG_Emr.Text) Then
            vScript = "alert('PAGIBIG Employer contribution should be numeric.');"
            Exit Sub
        End If
        If Not IsNumeric(txtPHIC_Emp.Text) Then
            vScript = "alert('PHIC Employee contribuiton should be numeric.');"
            Exit Sub
        End If
        If Not IsNumeric(txtPHIC_Emr.Text) Then
            vScript = "alert('PHIC Employer contribuiton should be numeric.');"
            Exit Sub
        End If
        If Not IsNumeric(txtGSIS_Emp.Text) Then
            vScript = "alert('GSIS Employee contribution should be numeric.');"
            Exit Sub
        End If
        If Not IsNumeric(txtGSIS_Emr.Text) Then
            vScript = "alert('GSIS Employer contribution should be numeric.');"
            Exit Sub
        End If

        txtMeal.Text = txtMeal.Text.Replace(",", "")
        txtSeniorAllowance.Text = txtSeniorAllowance.Text.Replace(",", "")
        txtACA.Text = txtACA.Text.Replace(",", "")
        txtRATA.Text = txtRATA.Text.Replace(",", "")
        txtPERA.Text = txtPERA.Text.Replace(",", "")
        txtAbsent.Text = txtAbsent.Text.Replace(",", "")
        txtTardy.Text = txtTardy.Text.Replace(",", "")
        txtUnionDues.Text = txtUnionDues.Text.Replace(",", "")
        txtTax.Text = txtTax.Text.Replace(",", "")
        txtSSS_Emp.Text = txtSSS_Emp.Text.Replace(",", "")
        txtSSS_Emr.Text = txtSSS_Emr.Text.Replace(",", "")
        txtEC.Text = txtEC.Text.Replace(",", "")
        txtPAGIBIG_Emp.Text = txtPAGIBIG_Emp.Text.Replace(",", "")
        txtPAGIBIG_Emr.Text = txtPAGIBIG_Emr.Text.Replace(",", "")
        txtPHIC_Emp.Text = txtPHIC_Emp.Text.Replace(",", "")
        txtPHIC_Emr.Text = txtPHIC_Emr.Text.Replace(",", "")
        txtGSIS_Emp.Text = txtGSIS_Emp.Text.Replace(",", "")
        txtGSIS_Emr.Text = txtGSIS_Emr.Text.Replace(",", "")

        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        cm.Connection = c

        cm.CommandText = "update py_report set MealAllow=" & Val(txtMeal.Text) & _
            ",SeniorAllowance=" & Val(txtSeniorAllowance.Text) & _
            ",Aca=" & Val(txtACA.Text) & _
            ",Rata=" & Val(txtRATA.Text) & _
            ",Pera=" & Val(txtPERA.Text) & _
            ",Ot=" & Val(txtOT.Text) & _
            Session("otval").ToString.Replace("|", ",") & _
            ",Absent=" & Val(txtAbsent.Text) * -1 & _
            ",Tardiness=" & Val(txtTardy.Text) * -1 & _
            ",UnionDues=" & Val(txtUnionDues.Text) & _
            ",With_Tax=" & Val(txtTax.Text) & _
            ",Sss_Per=" & Val(txtSSS_Emp.Text) & _
            ",Sss_Gov=" & Val(txtSSS_Emr.Text) & _
            ",Ec=" & Val(txtEC.Text) & _
            ",Pagibig_Per=" & Val(txtPAGIBIG_Emp.Text) & _
            ",Pagibig_Gov=" & Val(txtPAGIBIG_Emr.Text) & _
            ",Medicare_Per=" & Val(txtPHIC_Emp.Text) & _
            ",Medicare_Gov=" & Val(txtPHIC_Emr.Text) & _
            ",Gsis_Per=" & Val(txtGSIS_Emp.Text) & _
            ",Gsis_Gov=" & Val(txtGSIS_Emr.Text) & _
            ",Amount_Per=" & Val(Request.Form("txtNetPay")) & _
            " where Emp_Cd='" & txtEmpCd.Text & _
            "' and PayDate='" & Format(CDate(txtPayDate.Text), "yyyy/MM/dd") & "'"

        Try
            cm.ExecuteNonQuery()
            Dim vNewVal As String = " MealAllow=" & txtMeal.Text & _
                "|Aca=" & txtACA.Text & _
                "|Rata=" & txtRATA.Text & _
                "|Pera=" & txtPERA.Text & _
                "|Ot=" & txtOT.Text & _
                Session("otval") & _
                "|Absent=" & txtAbsent.Text & _
                "|Tardiness=" & txtTardy.Text & _
                "|Union Dues=" & txtUnionDues.Text & _
                "|With_Tax=" & txtTax.Text & _
                "|Sss_Per=" & txtSSS_Emp.Text & _
                "|Sss_Gov=" & txtSSS_Emr.Text & _
                "|Ec=" & txtEC.Text & _
                "|Pagibig_Per=" & txtPAGIBIG_Emp.Text & _
                "|Pagibig_Gov=" & txtPAGIBIG_Emr.Text & _
                "|Medicare_Per=" & txtPHIC_Emp.Text & _
                "|Medicare_Gov=" & txtPHIC_Emr.Text & _
                "|Gsis_Per=" & txtGSIS_Emp.Text & _
                "|Gsis_Gov=" & txtGSIS_Emr.Text & _
                "|Amount_Per=" & Request.Form("txtNetPay")

            EventLog(Session("uid"), Request.ServerVariables("REMOTE_ADDR"), "EDIT", _
                Session("oldval"), vNewVal, "Employee ID: " & txtEmpCd.Text & " on PayDate: " & txtPayDate.Text & _
                " was edited", "Edit Payroll", c)
            vScript = "alert('Changes were saved successfully. Once this window is closed, click the Refresh/Search button again to reload the data.'); window.close();"
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to save changes. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            cm.Dispose()
            c.Dispose()
        End Try
    End Sub

    Protected Sub txtUnionDues_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtUnionDues.Init
        txtUnionDues.Attributes.Add("onblur", "recompute();")
    End Sub

    Protected Sub txtSeniorAllowance_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtSeniorAllowance.Init
        txtSeniorAllowance.Attributes.Add("onblur", "recompute();")
    End Sub

   
End Class
