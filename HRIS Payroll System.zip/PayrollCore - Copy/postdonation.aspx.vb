Imports System.Data
Imports denaro.fis
Partial Class postdonation
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If

        If Not CanRun(Session("caption"), Request.Item("id")) Then
            Session("denied") = "1"
            Server.Transfer("main.aspx")
            Exit Sub
        End If
        If Not IsPostBack Then
            lblCaption.Text = "Post Donation Announcement"
            Me.lstCategory.SelectedIndex = 0
        End If
        DataRefresh()
    End Sub
    Private Sub DataRefresh()
        Dim c As New sqlclient.sqlconnection(connStr)
        Dim da As New sqlclient.sqlDataAdapter("select * from links where Category='" & lstCategory.SelectedValue & "'", c)
        Dim ds As New DataSet

        da.Fill(ds, "donation")

        tblDonation.DataSource = ds.Tables("donation")
        tblDonation.DataBind()
        c.Dispose()
        da.Dispose()
        ds.Dispose()
        Session("category") = lstCategory.SelectedValue
    End Sub

    Protected Sub cmdClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdClose.Click
        Session.Remove("descr")
        Session.Remove("category")
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub cmdDel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDel.Click
        If tblDonation.SelectedIndex >= 0 And tblDonation.SelectedIndex <= tblDonation.PageSize Then
            Dim c As New sqlclient.sqlconnection(connStr)
            Dim cm As New SqlClient.SqlCommand("delete from links where category='" & _
                lstCategory.SelectedValue & "' and SeqId='" & tblDonation.SelectedRow.Cells(0).Text & "'", c)

            Try
                c.Open()
                cm.ExecuteNonQuery()
                c.Close()
                c.Dispose()
                cm.Dispose()
                vScript = "alert('Record successfully deleted.');"
                DataRefresh()
            Catch ex As sqlclient.sqlException
                vScript = "alert('An erro occurred while trying to delete the record. Error is: " & _
                    ex.Message.Replace("'", "") & "');"
            End Try
        Else
            vScript = "alert('You must first select a record to delete.');"
        End If
    End Sub

    Protected Sub tblDonation_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles tblDonation.PageIndexChanging
        tblDonation.PageIndex = e.NewPageIndex
        DataRefresh()
    End Sub

    Protected Sub tblDonation_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tblDonation.SelectedIndexChanged
        Session("descr") = tblDonation.SelectedRow.Cells(0).Text
        If lstCategory.SelectedValue = "PRIVATE" Then
            lstEmp.Visible = True
            Dim c As New SqlClient.SqlConnection(connStr)
            Dim cm As New SqlClient.SqlCommand
            Dim rs As SqlClient.SqlDataReader
            Dim vList() As String
            Dim iCtr As Integer
            Dim vName As String = ""

            Try
                c.Open()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                c.Dispose()
                cm.Dispose()
                Exit Sub
            End Try

            cm.Connection = c
            cm.CommandText = "select Emp_Cd from links where Category='" & lstCategory.SelectedValue & _
                "' and SeqId='" & tblDonation.SelectedRow.Cells(0).Text & "'"

            Try
                ReDim vList(0)
                lstEmp.Items.Clear()
                rs = cm.ExecuteReader
                If rs.Read Then
                    vList = rs("Emp_Cd").ToString.Split(",")
                End If
                rs.Close()
                For iCtr = 0 To UBound(vList)
                    cm.CommandText = "select Emp_Lname+', '+Emp_Fname from py_emp_master where Emp_Cd='" & _
                        vList(iCtr) & "'"
                    rs = cm.ExecuteReader
                    If rs.Read Then
                        vName = rs(0)
                    End If
                    rs.Close()
                    lstEmp.Items.Add(vList(iCtr) & " -> " & vName)
                Next
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to retrieve records. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            Finally
                c.Close()
                cm.Dispose()
                c.Dispose()
            End Try
        End If
    End Sub

    Protected Sub lstCategory_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles lstCategory.SelectedIndexChanged
        lstEmp.Visible = False
        DataRefresh()
    End Sub
End Class
