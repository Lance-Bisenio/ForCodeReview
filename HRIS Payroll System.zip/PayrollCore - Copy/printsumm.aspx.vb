Imports denaro
Partial Class printsumm
    Inherits System.Web.UI.Page
    Public vscript As String = ""
    Public vSubHeader As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        
        If Session("uid") = "" Then
            Response.Write("Your Login session has expired. Please login again.")
            vscript = "alert('Your Login session has expired. Please login again.'); window.close();"
            Exit Sub
        End If

        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cmRef As New SqlClient.SqlCommand

        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim vStartDate As Date = Session("startdate")
        Dim vEndDate As Date = Session("enddate")
        Dim vFilter As String = Session("filter")
        Dim iCtr As Integer
        Dim vSQL As String = ""
        Dim vBreak As String = ""
        Dim vHeaders As String = ""
        Dim vSub As String = ""
        Dim vTmp As String = ""
        
        Dim vDutyMealsTotal As Decimal = 0
        Dim vCountAll As Decimal = 0
        Dim vDutyMeals As Decimal = 0
        Dim vCount As Decimal = 0
        Dim vName As String = ""

        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY: VIC GATCHALIAN                             ''
        '' DATE MODIFIED: 7/17/2012                                ''
        '' PURPOSE: TO SUPPORT ACCESS TO PERIODIC LOGS AND         ''
        ''          DAILY LOGS                                     ''
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        Session("logmode") = Request.Item("m")
        ''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''

        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY: VIC GATCHALIAN                             ''
        '' DATE MODIFIED: 3/18/2012                                ''
        '' PURPOSE: TO CONVERT THE STRING DATA TYPE TO             ''
        ''          STRINGBUILDER DATA TYPE TO REDUCE MEMORY       ''
        ''          OVERLOAD.                                      ''
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        ''''''''''''''''''' OLD CODE ''''''''''''''''''''''''''''''''
        'Dim vData As String = ""
        ''''''''''''''''''' END OLD CODE ''''''''''''''''''''''''''''
        Dim vData As New StringBuilder
        ''''''''''''''''''' END OF MODIFICATION  ''''''''''''''''''''

        Dim vTimesched_Count As Decimal = 0
        Dim vTimeLog_Count As Decimal = 0
        Dim vMaxRows As Decimal = 0
        Dim vHrs As Decimal = 0
        Dim vHrsForConversion = 0
        Dim txtLateHeader As String = ""
        Dim vOrigSubName = ""
        Dim vRemarks As String = ""     'added by vic on 6/16/2011, to support remarks column in the report
        Dim _1stPass As Integer = 0

        Response.Buffer = True
        If Request.Item("l") = 1 Then
            txtLateHeader = "Late Filed "
        End If

        Response.Write("<br /><br /><p align='center' style='font-size:10pt;font-family:Arial;'><b>")
        Response.Write(txtLateHeader & "Time Log Summary Report<br />")
        If Request.Item("m") = "1" Then
            Response.Write("Posted Date " & Format(vStartDate, "MM/dd/yyyy"))
        Else
            Response.Write("From Cut-off Period " & Format(vStartDate, "MM/dd/yyyy") & " To " & Format(vEndDate, "MM/dd/yyyy"))
        End If

        Response.Write("<br />" & Session("VFILTER"))
        Response.Write("</b></p><br /><br />")

        vSQL = "SELECT SubTitle FROM py_ot_ref WHERE SubTitle IS NOT NULL AND SubTitle <> '' GROUP BY GroupName,SubTitle,Col ORDER BY Col"
        c.Open()
        'cRef.Open()
        cm.Connection = c
        cmRef.Connection = c
        cm.CommandText = vSQL
        rs = cm.ExecuteReader

        If rs.Read Then
            vBreak = rs("SubTitle")
        End If

        iCtr = 1
        vSubHeader = "<th bgcolor='silver' colspan='3'></th>"
        Do While rs.Read
            If vBreak <> rs("SubTitle") Then

                If rs("SubTitle") <> "Officers OT Allowance" Then
                    vSubHeader += "<th bgcolor='silver' style='padding:5px' colspan='" & iCtr & "'>" & vBreak & "</th>"
                    iCtr = 0
                    vBreak = rs("SubTitle")
                End If
                'End Revised Code
            End If
            iCtr += 1
        Loop
        rs.Close()

        vSubHeader += "<th bgcolor='silver' colspan='" & iCtr + 1 & "'>" & vBreak & "</th>"

        vSubHeader += "<tr bgcolor='silver'><th rowspan='2'>Emp Cd</th><th style='width:500px;' rowspan='2'>Name</th><th rowspan='2'>Days Paid</th>" & _
           "</tr><tr valign='top' bgcolor='silver'>"

        Session("vTmp") = ""
        Session("vSub") = ""

        vSQL = "SELECT distinct SubTitle, GroupName, Col FROM py_ot_ref WHERE GroupName IS NOT NULL ORDER BY Col"

        cm.CommandText = vSQL
        rs = cm.ExecuteReader
        Do While rs.Read

            'Revised Code
            If rs("SubTitle") <> "Officers OT Allowance" Then
                vSubHeader += "<th>" & rs("GroupName") & "</th>"
                Session("vTmp") += rs("SubTitle") & "^" & rs("GroupName") & "|"
                Session("vSub") += rs("SubTitle") & "|"

            End If
            'End Revised Code
        Loop
        rs.Close()
        If Session("vTmp") <> "" Then
            Session("vTmp") = Mid(Session("vTmp"), 1, Len(Session("vTmp")) - 1)
        End If
        txtCols.Value = UBound(Session("vSub").ToString.Split("|")) + 1
        vSubHeader += "<th>Remarks</th>"


        '=================================================================================================================
        '========= END Added =============================================================================================
        '=================================================================================================================

        Session("EmpCdList") = ""
        vSQL = "select Emp_Cd,Emp_Lname,Emp_Fname,Emp_Mname,Req_Hrs_Day,Rate_Day from py_emp_master " & _
            vFilter & " order by Emp_Lname,Emp_Fname,Emp_Mname"

        cm.CommandText = vSQL
        rs = cm.ExecuteReader

        Do While rs.Read
            txtEmpCdList.Text += rs("Emp_Cd") & ","
            Session("EmpCdList") += "'" & rs("Emp_Cd") & "',"
        Loop
        rs.Close()

        txtR.Text = Request.Item("r")
        vscript = "getData(" & Request.Item("l") & "," & Request.Item("m") & ");"

        '=================================================================================================================
        '=================================================================================================================

    End Sub
End Class
