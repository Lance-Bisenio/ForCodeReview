Imports denaro
Partial Class pagibigsetup
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Dim c As New sqlclient.sqlconnection
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If
        If Not IsPostBack Then
            Dim cm As New sqlclient.sqlcommand
            Dim dr As sqlclient.sqldatareader

            lblcaption.text = "Pagibig Setup parameters"
            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c
            cm.CommandText = "select PagibigBranchCd,Company_Name,Address,Zip,Phone from " & _
                "glsyscntrl where AgencyCd='" & Session("office") & "'"
            dr = cm.ExecuteReader
            If dr.Read Then
                txtCompanyName.Text = IIf(IsDBNull(dr("Company_Name")), "", dr("Company_Name"))
                txtAddress.Text = IIf(IsDBNull(dr("Address")), "", dr("Address"))
                txtZIP.Text = IIf(IsDBNull(dr("Zip")), "", dr("Zip"))
                txtTel.Text = IIf(IsDBNull(dr("Phone")), "", dr("Phone"))
                txtBranch.Text = IIf(IsDBNull(dr("PagibigBranchcd")), "", dr("PagibigBranchCd"))
            Else
                vScript = "alert('Record not found!');"
            End If
            dr.Close()
            cm.Dispose()
            c.Close()
        End If
    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        Dim cm As New sqlclient.sqlcommand

        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c
        cm.CommandText = "update glsyscntrl set Company_Name='" & txtCompanyName.Text & _
            "',Address='" & txtAddress.Text & _
            "',Zip='" & txtZIP.Text & _
            "',Phone='" & txtTel.Text & _
            "',PagibigBranchCd='" & txtBranch.Text & "' where AgencyCd='" & Session("office") & "'"
        cm.ExecuteNonQuery()
        cm.Dispose()
        c.Close()

        vScript = "alert('Changes have been saved successfully!'); window.close();"
    End Sub
End Class
