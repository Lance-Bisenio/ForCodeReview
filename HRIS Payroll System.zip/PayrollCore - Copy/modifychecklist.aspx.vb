Imports denaro
Partial Class modifychecklist
    Inherits System.Web.UI.Page
    Dim c As New sqlclient.sqlconnection
    Public vScript As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If
        If Not IsPostBack Then
            lblcaption.text = "Add/Modify Document checklist of applicant"
            If Session("mode") = "a" Then
                txtApplicantNo.Text = Session("applicantno")
                txtDocType.Text = Session("doctype")
                txtDateFiled.Text = Format(Now, "MM/dd/yyyy")
                txtUpdatedBy.Text = Session("uid")
            Else            'edit mode
                Dim cm As New sqlclient.sqlcommand
                Dim dr As sqlclient.sqldatareader
                c.ConnectionString = connStr
                c.Open()
                cm.Connection = c
                cm.CommandText = "select * from hr_applicant_checklist where ApplicantNo=" & _
                    Session("applicantno") & " and CheckListCd='" & Session("doctype") & "'"
                dr = cm.ExecuteReader
                If dr.Read Then
                    txtApplicantNo.Text = Session("applicantno")
                    txtDocType.Text = Session("doctype")
                    txtDateFiled.Text = Format(dr("DateFiled"), "MM/dd/yyyy")
                    txtUpdatedBy.Text = dr("UpdatedBy")
                    txtDateSubmitted.Text = Format(dr("DateSubmitted"), "MM/dd/yyyy")
                    txtRemarks.Text = dr("Remarks")
                End If
                dr.Close()
                cm.Dispose()
                c.Close()
            End If
        End If
    End Sub

    Protected Sub vldData_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles vldData.ServerValidate
        If Not IsDate(txtDateSubmitted.Text) Then
            args.IsValid = False
            vScript = "alert('Invalid date format.');"
            Exit Sub
        End If
        args.IsValid = True
    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        If Page.IsValid Then
            Dim cm As New sqlclient.sqlcommand
            If Session("mode") = "a" Then
                cm.CommandText = "insert into hr_applicant_checklist (ApplicantNo,CheckListCd," & _
                    "DateFiled,Remarks,DateSubmitted,UpdatedBy) values (" & _
                    txtApplicantNo.Text & ",'" & txtDocType.Text & "','" & _
                    Format(CDate(txtDateFiled.Text), "yyyy/MM/dd") & "','" & _
                    txtRemarks.Text & "','" & Format(CDate(txtDateSubmitted.Text), "yyyy/MM/dd") & _
                    "','" & txtUpdatedBy.Text & "')"
            Else                'edit mode
                cm.CommandText = "update hr_applicant_checklist set DateSubmitted='" & _
                    Format(CDate(txtDateSubmitted.Text), "yyyy/MM/dd") & _
                    "',Remarks='" & txtRemarks.Text & _
                    "' where ApplicantNo=" & txtApplicantNo.Text & _
                    " and CheckListCd='" & txtDocType.Text & "'"
            End If
            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c
            cm.ExecuteNonQuery()
            c.Close()
            Session.Remove("applicantno")
            Session.Remove("doctype")
            Session.Remove("mode")
            vScript = "alert('Changes were successfully saved.'); window.close();"
        End If
    End Sub
End Class
