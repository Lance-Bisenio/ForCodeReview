Imports denaro
Partial Class modifyletterdtl
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Dim c As New SqlClient.SqlConnection
    Protected Sub cmdReturn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.Click
        Session.Remove("mode")
        Session.Remove("keyword")
        Server.Transfer("letterdtl.aspx")
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            lblCaption.Text = "Add/Modify macro keyword"
            txtLetterCd.Text = Session("lettercd")


            BuildCombo("select column_name, column_name from information_schema.columns where table_name = 'py_emp_master'", cmbKeyword)
            cmbKeyword.Items.Add("Date")
            cmbKeyword.Items.Add("Date and Time")
            cmbKeyword.Items.Add("Time")

            If Session("mode") = "e" Then
                Dim cm As New SqlClient.SqlCommand
                Dim dr As SqlClient.SqlDataReader

                c.ConnectionString = connStr
                c.Open()
                cm.Connection = c

                cm.CommandText = "select * from hr_letter_dtl where Letter_Cd='" & _
                    ExtractData(txtLetterCd.Text) & "' and Find_Var='" & Session("keyword") & "'"
                dr = cm.ExecuteReader
                If dr.Read Then
                    cmbKeyword.SelectedValue = dr("Replace_With")
                    txtReplace.Text = dr("Find_Var")
                End If
                dr.Close()
                cm.Dispose()
                c.Close()
            End If
        End If
    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        Dim cm As New SqlClient.SqlCommand

        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c
        If Session("mode") = "e" Then
            cm.CommandText = "update hr_letter_dtl set Replace_With='" & cmbKeyword.SelectedValue & _
                "',Find_Var='" & txtReplace.Text & _
                "' where Letter_Cd='" & ExtractData(txtLetterCd.Text) & "' and Find_Var='" & _
                Session("keyword") & "'"
        Else
            cm.CommandText = "insert into hr_letter_dtl (Letter_Cd,Replace_With, Find_Var) values ('" & _
                ExtractData(txtLetterCd.Text) & "','" & cmbKeyword.SelectedValue & "','" & txtReplace.Text & "')"
        End If
        cm.ExecuteNonQuery()
        c.Close()
        cm.Dispose()
        vScript = "alert('Changes were successfully saved.');"
        Server.Transfer("letterdtl.aspx")
    End Sub

    Protected Sub cmbKeyword_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbKeyword.SelectedIndexChanged
        If cmbKeyword.SelectedValue = "Date" Then
            txtReplace.Text = "[Date]"
            txtReplace.ReadOnly = True
        End If

        If cmbKeyword.SelectedValue = "Date and Time" Then
            txtReplace.Text = "[DateTime]"
            txtReplace.ReadOnly = True
        End If

        If cmbKeyword.SelectedValue = "Time" Then
            txtReplace.Text = "[Time]"
            txtReplace.ReadOnly = True
        End If
    End Sub
End Class
