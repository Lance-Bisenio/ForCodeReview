Imports denaro.fis
Partial Class cascadeshift
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            lblCaption.Text = "Leave, Overtime and Tardiness Matrix Report"

            cmbYear.Items.Clear()
            For i As Integer = Now.Year - 2 To Now.Year
                cmbYear.Items.Add(i)
            Next
            cmbMonth.SelectedValue = Now.Month
            cmbYear.SelectedValue = Now.Year
            BuildCombo("select Rc_Cd, Descr from rc order by Descr ", cmbRC)
            BuildCombo("select AgencyCd,AgencyName from agency order by AgencyName", cmbOfc)
            BuildCombo("select Div_Cd,Descr from hr_div_ref order by Descr", cmbDiv)
            BuildCombo("select Dept_Cd,Descr from hr_dept_ref order by Descr", cmbDept)
            BuildCombo("select Section_Cd,Descr from hr_section_ref order by Descr", cmbSection)
            BuildCombo("select Unit_Cd,Descr from hr_unit_ref order by Descr", cmbUnit)
            BuildCombo("select EmploymentType,Descr from hr_employment_type order by Descr", cmbEmpType)

            
            cmbRC.Items.Add("All")
            cmbRC.SelectedValue = "All"
            cmbOfc.Items.Add("All")
            cmbOfc.SelectedValue = "All"
            cmbDiv.Items.Add("All")
            cmbDiv.SelectedValue = "All"
            cmbDept.Items.Add("All")
            cmbDept.SelectedValue = "All"
            cmbSection.Items.Add("All")
            cmbSection.SelectedValue = "All"
            cmbUnit.Items.Add("All")
            cmbUnit.SelectedValue = "All"
            cmbEmpType.Items.Add("All")
            cmbEmpType.SelectedValue = "All"
            RefreshCal()
        End If
    End Sub
    Public Sub BuildCombo(ByVal pSql As String, ByRef pCombo As System.Web.UI.WebControls.DropDownList)
        Dim c As New sqlclient.sqlconnection
        Dim cm As New sqlclient.sqlcommand
        Dim rs As sqlclient.sqldatareader

        c.ConnectionString = connStr
        Try
            c.Open()
        Catch ex As sqlclient.sqlexception
            vscript = "alert(""" & ex.Message.Replace(vbCrLf, "") & """);"
            Exit Sub
        End Try

        cm.Connection = c
        cm.CommandText = pSql
        Try
            rs = cm.ExecuteReader
            pCombo.Items.Clear()
            Do While rs.Read
                pCombo.Items.Add(New ListItem(rs(0) & "=>" & IIf(IsDBNull(rs(1)), "null", rs(1)), rs(0)))
            Loop
            rs.Close()
        Catch ex As sqlclient.sqlException
            vScript = "alert(""" & ex.Message.Replace(vbCrLf, "") & """);"
        Finally
            cm.Dispose()
            c.Close()
            c.Dispose()
        End Try
    End Sub

    Protected Sub cmdRefresh_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdRefresh.Click
        Dim c As New sqlclient.sqlConnection(connStr)
        Dim cm As New sqlclient.sqlCommand
        Dim rs As sqlclient.sqlDataReader
        Dim vFilter As String = ""

        If cmbRC.SelectedValue <> "All" Then
            vFilter += " and Rc_Cd='" & cmbRC.SelectedValue & "' "
        End If
        If cmbOfc.SelectedValue <> "All" Then
            vFilter += " and Agency_Cd='" & cmbOfc.SelectedValue & "' "
        End If
        If cmbDiv.SelectedValue <> "All" Then
            vFilter += " and DivCd='" & cmbDiv.SelectedValue & "' "
        End If
        If cmbDept.SelectedValue <> "All" Then
            vFilter += " and DeptCd='" & cmbDept.SelectedValue & "' "
        End If
        If cmbSection.SelectedValue <> "All" Then
            vFilter += " and SectionCd='" & cmbSection.SelectedValue & "' "
        End If
        If cmbUnit.SelectedValue <> "All" Then
            vFilter += " and UnitCd='" & cmbUnit.SelectedValue & "' "
        End If
        If cmbEmpType.SelectedValue <> "All" Then
            vFilter += " and EmploymentType='" & cmbEmpType.SelectedValue & "' "
        End If

        chkEmpList.Items.Clear()

        Try
            c.Open()
        Catch ex As sqlclient.sqlException
            vScript = "alert(""" & ex.Message.Replace(vbCrLf, "") & """);"
            Exit Sub
        End Try

        cm.CommandText = "select Emp_Cd,Emp_Lname,Emp_Fname from py_emp_master where Date_Resign is null " & _
            vFilter & " order by Emp_Lname,Emp_Fname"
        cm.Connection = c
        Try
            rs = cm.ExecuteReader
            txtEmpList.Value = ""
            Do While rs.Read
                chkEmpList.Items.Add(New ListItem(rs("Emp_Cd") & "=>" & rs("Emp_Lname") & ", " & rs("Emp_Fname"), rs("Emp_Cd")))
            Loop
            rs.Close()
            For i As Integer = 0 To chkEmpList.Items.Count - 1
                chkEmpList.Items(i).Selected = True
                txtEmpList.Value += chkEmpList.Items(i).Value & ","
            Next
            txtEmpList.Value = Mid(txtEmpList.Value, 1, txtEmpList.Value.Length - 1)
        Catch ex As System.Exception
            vScript = "alert(""" & ex.Message.Replace(vbCrLf, "") & """);"
        Finally
            c.Close()
            c.Dispose()
            cm.Dispose()
        End Try
    End Sub

    Protected Sub cmdSelect_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSelect.Click
        txtEmpList.Value = ""
        For i As Integer = 0 To chkEmpList.Items.Count - 1
            chkEmpList.Items(i).Selected = True
            txtEmpList.Value += chkEmpList.Items(i).Value & ","
        Next
        txtEmpList.Value = Mid(txtEmpList.Value, 1, txtEmpList.Value.Length - 1)
    End Sub

    Protected Sub cmdDeselect_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDeselect.Click
        txtEmpList.Value = ""
        For i As Integer = 0 To chkEmpList.Items.Count - 1
            chkEmpList.Items(i).Selected = False
        Next
    End Sub

    Protected Sub cmdStart_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdStart.Click
        txtEmpList.Value = ""
        For i As Integer = 0 To chkEmpList.Items.Count - 1
            If chkEmpList.Items(i).Selected Then
                txtEmpList.Value += chkEmpList.Items(i).Value & ","
            End If
        Next
        If txtEmpList.Value <> "" Then
            txtEmpList.Value = Mid(txtEmpList.Value, 1, txtEmpList.Value.Length - 1)
        End If
        'vScript = "processEmp();"
        vScript = "alert('Parameter settings have been set successfully. " & _
            "Click the Start process button to begin cascading the schedules.');"
    End Sub

    Protected Sub cmbMonth_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles _
        cmbMonth.SelectedIndexChanged, cmbYear.SelectedIndexChanged
        
        RefreshCal()
    End Sub
    Private Sub RefreshCal()
        Dim vMonths() As String = {"January", "February", "March", "April", "May", "June", _
                    "July", "August", "September", "October", "November", "December"}
        cal.TodaysDate = cmbMonth.SelectedValue & "/1/" & cmbYear.SelectedValue
        chkMonths.Items.Clear()
        For i As Integer = 1 To 12
            If i <> cmbMonth.SelectedValue Then
                chkMonths.Items.Add(New ListItem(vMonths(i - 1), i))
            End If
        Next
        For i As Integer = 0 To chkMonths.Items.Count - 1
            txtMonths.Value += chkMonths.Items(i).Text & ","
            If i + 1 >= cmbMonth.SelectedValue Then
                chkMonths.Items(i).Selected = True
            End If
        Next
        txtMonths.Value = Mid(txtMonths.Value, 1, txtMonths.Value.Length - 1)
    End Sub
End Class
