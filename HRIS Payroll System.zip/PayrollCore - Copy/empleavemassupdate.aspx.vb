﻿Imports denaro
Partial Class empleavemassupdate
    Inherits System.Web.UI.Page
    Public vScript As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If
        If Not CanRun(Session("caption"), Request.Item("id")) Then
            Session("denied") = "1"
            Server.Transfer("main.aspx")
            Exit Sub
        End If
        txtFilterDate.Text = Request.Form("txtFilterDate")

        If Not IsPostBack Then
            Dim c As New SqlClient.SqlConnection(connStr)
            Try
                c.Open()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                c.Dispose()
                Exit Sub
            End Try

            BuildCombo("select Rc_Cd,Descr from rc where exists (select User_Id from rights_list where User_Id='" & _
                    Session("uid") & "' and property='rc' and Property_Value=Rc_Cd) order by Descr", cmbRC, c)
            BuildCombo("select AgencyCd,AgencyName from agency where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='agency' and Property_Value=AgencyCd) order by AgencyName", cmbOfc, c)
            BuildCombo("select Div_Cd,Descr from hr_div_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='division' and Property_Value=Div_Cd) order by Descr", cmbDiv, c)
            BuildCombo("select Dept_Cd,Descr from hr_dept_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='department' and Property_Value=Dept_Cd) order by Descr", cmbDept, c)
            BuildCombo("select Section_Cd,Descr from hr_section_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='section' and Property_Value=Section_Cd) order by Descr", cmbSection, c)
            BuildCombo("select Unit_Cd,Descr from hr_unit_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='unit' and Property_Value=Unit_Cd) order by Descr", cmbUnit, c)
            BuildCombo("select EmploymentType,Descr from hr_employment_type where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='employmenttype' and Property_Value=EmploymentType) order by Descr", cmbSecurity, c)
            BuildCombo("select Leave_Cd,Descr from py_leave_ref order by Descr", cmbLeaveType, c)

            c.Close()
            c.Dispose()

            cmbRC.Items.Add("All")
            cmbRC.SelectedValue = "All"
            cmbOfc.Items.Add("All")
            cmbOfc.SelectedValue = "All"
            cmbDiv.Items.Add("All")
            cmbDiv.SelectedValue = "All"
            cmbDept.Items.Add("All")
            cmbDept.SelectedValue = "All"
            cmbSection.Items.Add("All")
            cmbSection.SelectedValue = "All"
            cmbUnit.Items.Add("All")
            cmbUnit.SelectedValue = "All"
            cmbSecurity.Items.Add("All")
            cmbSecurity.SelectedValue = "All"

            txtFilterDate.Text = Format(Now, "MM/dd/yyyy")
        End If
    End Sub

    Protected Sub cmdRefresh_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdRefresh.Click
        DataRefresh()
    End Sub

    Protected Sub DataRefresh()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cmRef As New SqlClient.SqlCommand
        Dim dr As SqlClient.SqlDataReader
        Dim drRef As SqlClient.SqlDataReader

        Dim vFilter As String = " where Date_Resign is null "
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                             ''
        '' DATE MODIFIED: 3/26/2013                                 ''
        '' PURPOSE: TO HAVE AN OPTION TO ALSO SHOW EMPLOYEES WITH   ''
        ''          NO EXPIRY DATE AND CUSTOM DATE BOUNDARY.        ''
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        Dim vExpiryFilter As String = ""
        ''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''


        If cmbRC.SelectedValue <> "All" Then   'filter by cost center
            vFilter += " and Rc_Cd='" & cmbRC.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='rc' and Property_Value=Rc_Cd) "
        End If

        If cmbOfc.SelectedValue <> "All" Then        'filter by office/agency
            vFilter += " and Agency_Cd='" & cmbOfc.SelectedValue & "' "
        Else
            vFilter += "  and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='agency' and Property_Value=Agency_Cd) "
        End If
        If cmbDiv.SelectedValue <> "All" Then      'filter by division
            vFilter += " and Divcd='" & cmbDiv.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='division' and Property_Value=DivCd) "
        End If
        If cmbDept.SelectedValue <> "All" Then  'filter by departments
            vFilter += " and DeptCd='" & cmbDept.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='department' and Property_Value=DeptCd) "
        End If
        If cmbSection.SelectedValue <> "All" Then 'filter by section
            vFilter += " and SectionCd='" & cmbSection.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='section' and Property_Value=SectionCd) "
        End If
        If cmbUnit.SelectedValue <> "All" Then  'filter by units
            vFilter += " and UnitCd='" & cmbUnit.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='unit' and Property_Value=UnitCd) "
        End If
        If cmbSecurity.SelectedValue <> "All" Then 'filter by employment types
            vFilter += " and EmploymentType='" & cmbSecurity.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='employmenttype' and Property_Value=EmploymentType) "
        End If

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to SQL Server. Error in line 131: " & _
                ex.Message.Replace(vbCrLf, "\n") & "');"
            cm.Dispose()
            c.Dispose()
            Exit Sub
        End Try

        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                                   ''
        '' DATE MODIFIED: 3/26/2013                                       ''
        '' PURPOSE: TO BUILD THE FILTER FOR GETTING THE EXPIRY DATE       ''
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        vExpiryFilter = " AND (ExpiryDate <= '" & Format(CDate(txtFilterDate.Text), "yyyy/MM/dd") & "'"
        If chkShowEmpty.Checked Then
            vExpiryFilter += " OR ExpiryDate is null"
        End If
        vExpiryFilter += ") "
        ''''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''

        cm.Connection = c
        cmRef.Connection = c
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                                     ''
        '' DATE MODIFIED: 3/26/2013                                         ''
        '' PURPOSE: TO MAKE THE FILTER PARAMETERIC                          ''
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        ''''''''''''''''''''''''''' OLD CODE '''''''''''''''''''''''''''''''''
        'cm.CommandText = "select Emp_Cd,(Emp_Lname+', '+Emp_Fname) as EmpName from py_emp_master " & _
        '    vFilter & " and Emp_Cd in (select Emp_Cd from py_emp_leave where Leave_Cd='" & cmbLeaveType.SelectedValue & _
        '    "' and ExpiryDate < '" & Format(Now, "yyyy/MM/dd") & "') order by Emp_Lname,Emp_Fname,Emp_Mname"
        '''''''''''''''''''''''''' END OLD CODE ''''''''''''''''''''''''''''''
        cm.CommandText = "select Emp_Cd,(Emp_Lname+', '+Emp_Fname) as EmpName," & _
            "(select ExpiryDate from py_emp_leave where py_emp_leave.Emp_Cd=py_emp_master.Emp_Cd and Leave_Cd='" & cmbLeaveType.SelectedValue & _
            "') as ExpiryDate, " & _
            "(select BalanceLastYear from py_emp_leave where py_emp_leave.Emp_Cd=py_emp_master.Emp_Cd and Leave_Cd='" & cmbLeaveType.SelectedValue & _
            "') as BalanceLastYear from py_emp_master " & _
            vFilter & " and Emp_Cd in (select Emp_Cd from py_emp_leave where Leave_Cd='" & cmbLeaveType.SelectedValue & _
            "' " & vExpiryFilter

        If cmbSort.SelectedValue = 0 Then   'sort by name, by date
            cm.CommandText += ") order by Emp_Lname,Emp_Fname,ExpiryDate"
        Else                                'sort by date, by name
            cm.CommandText += ") order by ExpiryDate,Emp_Lname,Emp_Fname"
        End If
        '''''''''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''

        chkEmp.Items.Clear()
        Try
            dr = cm.ExecuteReader
            Do While dr.Read
                'cmRef.CommandText = "select * from py_emp_leave where Emp_Cd='" & dr("Emp_Cd") & _
                '    "' and Leave_Cd='" & cmbLeaveType.SelectedValue & "'"
                'drRef = cmRef.ExecuteReader
                'If drRef.Read Then
                chkEmp.Items.Add(New ListItem(dr("Emp_Cd") & "=>" & dr("EmpName") & " = " & _
                                 dr("BalanceLastYear") & " = " & dr("ExpiryDate"), dr("Emp_Cd")))
                'End If
                ' drRef.Close()
            Loop
            dr.Close()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying retrieve Employee masterlist. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            cm.Dispose()
            cmRef.Dispose()
            c.Close()
            c.Dispose()
        End Try
    End Sub

    
    Private Sub SetChk(ByVal pState As Boolean)
        Dim iCtr As Integer
        For iCtr = 0 To chkEmp.Items.Count - 1
            chkEmp.Items(iCtr).Selected = pState
        Next iCtr
    End Sub
    Protected Sub cmdSelectAll_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSelectAll.Click
        SetChk(True)
    End Sub
    Protected Sub cmdDeselectAll_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDeselectAll.Click
        SetChk(False)
    End Sub

    Protected Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdUpdate.Click
        If txtExtendExpiry.Text <> "" And Not IsDate(txtExtendExpiry.Text) Then
            vScript = "alert('Invalid date format in Extend Leave Expiry.');"
            Exit Sub
        End If
        If chkEmp.Items.Count = 0 Then
            vScript = "alert('Please select an employee first.');"
            Exit Sub
        End If

        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                                        ''
        '' DATE MODIFIED: 3/26/2013                                            ''
        '' PURPOSE: TO ENABLE EMPTY EXPIRY DATE.                               ''
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        Dim vExpiry As String = "null"

        If txtExtendExpiry.Text <> "" Then
            vExpiry = "'" & Format(CDate(txtExtendExpiry.Text), "yyyy/MM/dd") & "'"
        End If
        '''''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''''''


        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to SQL Server. Error in line # 223: " & _
                ex.Message.Replace(vbCrLf, "\n") & "');"
            cm.Dispose()
            c.Dispose()
            Exit Sub
        End Try

        cm.Connection = c

        For iCtr = 0 To chkEmp.Items.Count - 1
            If chkEmp.Items(iCtr).Selected Then
                'cm.CommandText = "update py_emp_leave set ExpiryDate='" & _
                'Format(CDate(txtExtendExpiry.Text), "yyyy/MM/dd") & "',BalanceLastYear=" & _
                'Val(txtNodays.Text) & " where Emp_Cd='" & chkEmp.Items(iCtr).Value & "' and Leave_Cd='" & cmbLeaveType.SelectedValue & "'"

                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY:  VIC GATCHALIAN                                               ''
                '' DATE MODIFIED: 3/26/2013                                                   ''
                '' PURPOSE: TO ALLOW EMPTY EXPIRY DATE.                                       ''
                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                ''''''''''''''''''' OLD CODE '''''''''''''''''''''''''''''''''''''''''''''''''''
                'cm.CommandText = "update py_emp_leave set ExpiryDate='" & _
                'Format(CDate(txtExtendExpiry.Text), "yyyy/MM/dd") & "'" & _
                '" where Emp_Cd='" & chkEmp.Items(iCtr).Value & "' and Leave_Cd='" & cmbLeaveType.SelectedValue & "'"
                '''''''''''''''''''' END OLD CODE ''''''''''''''''''''''''''''''''''''''''''''''
                cm.CommandText = "update py_emp_leave set ExpiryDate=" & vExpiry & _
                    " where Emp_Cd='" & chkEmp.Items(iCtr).Value & "' and Leave_Cd='" & cmbLeaveType.SelectedValue & "'"
                '''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''''''''''''''

                Try
                    cm.ExecuteNonQuery()
                Catch ex As system.exception
                    vScript = "alert('Error occurred while trying to update the record of Employee " & _
                        chkEmp.Items(iCtr).Text & ". Error is: " & ex.Message.Replace(vbCrLf, "\n") & "');"
                    c.Close()
                    c.Dispose()
                    cm.Dispose()
                    Exit Sub
                End Try
            End If
        Next iCtr
        c.Close()
        c.Dispose()
        cm.Dispose()
        vScript = "alert('Selected employee(s) leave is updated.');"
        DataRefresh()
    End Sub

    Protected Sub cmdReturn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.Click
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub txtFilterDate_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtFilterDate.Init
        txtFilterDate.Attributes.Add("onfocus", "showCalendarControl(this)")
    End Sub

End Class
