Imports denaro
Partial Class applicantfamily
    Inherits System.Web.UI.Page
    Dim c As New sqlclient.sqlconnection
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If

        If Not IsPostBack Then
            Dim cm As New sqlclient.sqlcommand
            Dim dr As sqlclient.sqldatareader
            lblcaption.text = "Applicant's Family Background"
            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c
            cm.CommandText = "select * from hr_applicant_master where ApplicantNo=" & _
                Session("applicantno")
            dr = cm.ExecuteReader
            If dr.Read Then
                txtFatherLName.Text = IIf(IsDBNull(dr("Father_Lname")), "", dr("Father_Lname"))
                txtFatherFname.Text = IIf(IsDBNull(dr("Father_Fname")), "", dr("Father_Fname"))
                txtFatherMname.Text = IIf(IsDBNull(dr("Father_Mname")), "", dr("Father_Mname"))
                txtMotherLname.Text = IIf(IsDBNull(dr("Mother_Lname")), "", dr("Mother_Lname"))
                txtMotherFname.Text = IIf(IsDBNull(dr("Mother_Fname")), "", dr("Mother_Fname"))
                txtMotherMname.Text = IIf(IsDBNull(dr("Mother_Mname")), "", dr("Mother_Mname"))
                txtSpouseLname.Text = IIf(IsDBNull(dr("Spouse_Lname")), "", dr("Spouse_Lname"))
                txtSpouseFname.Text = IIf(IsDBNull(dr("Spouse_Fname")), "", dr("Spouse_Fname"))
                txtSpouseMname.Text = IIf(IsDBNull(dr("Spouse_Mname")), "", dr("Spouse_Mname"))
                txtContactName.Text = IIf(IsDBNull(dr("EmergencyContactPerson")), "", dr("EmergencyContactPerson"))
                txtContactNo.Text = IIf(IsDBNull(dr("EmergencyContactNo")), "", dr("EmergencyContactNo"))
                txtRemarks.Text = IIf(IsDBNull(dr("OtherInfo")), "", dr("OtherInfo"))
            End If
            dr.Close()
            cm.Dispose()
            c.Close()
        End If
    End Sub
End Class
