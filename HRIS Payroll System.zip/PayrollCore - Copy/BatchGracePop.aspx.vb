Imports denaro
Partial Class BatchGracePop
    Inherits System.Web.UI.Page
    Public vScript As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            vScript = "alert('You session login has expired. You must re-login to continue.'); window.close();"
            Exit Sub
        End If

        If Not IsPostBack Then
            Me.lblCaption.Text = "Overtime Allowance Set-Up"
            vScript = "var v = window.opener.document.getElementById('txtSelectedEmp').value;document.getElementById('txtEmpCode').value = v;window.opener.document.getElementById('txtSelectedEmp').value='';"
        End If
    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        If txtFrequency.Text.Trim = "" Then
            vScript = "alert('Frequency field should not be empty.');"
            Exit Sub
        End If
        If Not IsNumeric(txtFrequency.Text) Then
            vScript = "alert('Frequency field should be a number.');"
            Exit Sub
        End If
        If txtMax.Text.Trim = "" Then
            vScript = "alert('Maximum OT Amount should not be empty.');"
            Exit Sub
        End If
        If Not IsNumeric(txtMax.Text) Then
            vScript = "alert('Maximum OT Amount should a number.');"
            Exit Sub
        End If

        If Not IsNumeric(txtAca.Text) Then
            vScript = "alert('OT allowance should a number.');"
            Exit Sub
        End If
        If Not IsNumeric(txtRestOtX8.Text) Then
            vScript = "alert('On Regular Days field should a number.');"
            Exit Sub
        End If
        If Not IsNumeric(txtRegOt.Text) Then
            vScript = "alert('On Restdays should a number.');"
            Exit Sub
        End If
        If Not IsNumeric(txtRestOt.Text) Then
            vScript = "alert('On Restdays and/or Holiday (excess of 8hrs). should a number.');"
            Exit Sub
        End If

        Dim c As New sqlclient.sqlconnection(connStr)
        Dim cm As New sqlclient.sqlcommand

        Dim vEmpCd As String = ""
        Dim vFreq As Decimal = txtFrequency.Text
        Dim vMaxAmt As Decimal = txtMax.Text
        Dim Type As Integer = btnType.SelectedValue

        c.Open()
        cm.Connection = c

        vEmpCd = txtEmpCode.Value

        vEmpCd = vEmpCd.Substring(0, vEmpCd.Length - 1)
        vEmpCd = vEmpCd.Replace(",", "','")

        cm.CommandText = "UPDATE py_emp_master SET Frequency=" & vFreq & _
            ", RegOt=" & IIf(rdoRegOtUOM.SelectedValue = "0", Math.Round((txtRegOt.Text / 100), 2), txtRegOt.Text) & _
            ",RegOtUom=" & rdoRegOtUOM.SelectedValue & _
            ", RestOt=" & IIf(rdoRestOtUOM.SelectedValue = "0", Math.Round((txtRestOt.Text / 100), 2), txtRestOt.Text) & _
            ",RestOtUom=" & rdoRestOtUOM.SelectedValue & _
            ", RestOtX8=" & IIf(rdoRestX8OtUOM.SelectedValue = "0", Math.Round((txtRestOtX8.Text / 100), 2), txtRestOtX8.Text) & _
            ",RestOtX8Uom=" & rdoRestX8OtUOM.SelectedValue & _
            ", OtAllowanceType=" & Type & _
            ", MaxOtAmount=" & vMaxAmt & _
            ",FractionTruncated=" & IIf(chkTruncate.Checked, 1, 0) & _
            ",CalcMethod=" & rdoMethod.SelectedValue & _
            ",Aca=" & txtAca.Text & _
            " WHERE Emp_Cd in ('" & vEmpCd & "')"
        Try
            cm.ExecuteNonQuery()
            vScript = "alert('Record successfully saved.');window.opener.document.form1.submit();window.close();"
        Catch ex As sqlclient.sqlException
            vScript = "alert('Saving failed due to: " & ex.Message.Replace(vbCrLf, " ") & "');"
        End Try
        c.Close()
        c.Dispose()
        cm.Dispose()
    End Sub
End Class
