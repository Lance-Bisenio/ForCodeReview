Imports denaro
Partial Class postpayroll
    Inherits System.Web.UI.Page
    Public vScript As String = ""

    Protected Sub cmdReturn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.Click
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Session("returnaddr") = "leavemonitor.aspx"
            Server.Transfer("index.aspx")
            Exit Sub
        End If
        If Not IsPostBack Then
            If Not CanRun(Session("caption"), Request.Item("id")) Then
                Session("denied") = "1"
                Server.Transfer("main.aspx")
                Exit Sub
            End If
            lblcaption.text = "Freeze Generated Payroll"
            BuildCombo("select Rc_Cd,Descr from rc where exists (select User_Id from rights_list where User_Id='" & _
                    Session("uid") & "' and property='rc' and Property_Value=Rc_Cd) order by Descr", cmbRc)
            BuildCombo("select AgencyCd,AgencyName from agency where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='agency' and Property_Value=AgencyCd) order by AgencyName", cmbOfc)
            BuildCombo("select Div_Cd,Descr from hr_div_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='division' and Property_Value=Div_Cd) order by Descr", cmbDiv)
            BuildCombo("select Dept_Cd,Descr from hr_dept_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='department' and Property_Value=Dept_Cd) order by Descr", cmbDept)
            BuildCombo("select Section_Cd,Descr from hr_section_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='section' and Property_Value=Section_Cd) order by Descr", cmbSection)
            BuildCombo("select Unit_Cd,Descr from hr_unit_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='unit' and Property_Value=Unit_Cd) order by Descr", cmbUnit)
            BuildCombo("select EmploymentType,Descr from hr_employment_type where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='employmenttype' and Property_Value=EmploymentType) order by Descr", cmbType)

            cmbRc.Items.Add("All")
            cmbRc.SelectedValue = "All"
            cmbOfc.Items.Add("All")
            cmbOfc.SelectedValue = "All"
            cmbDiv.Items.Add("All")
            cmbDiv.SelectedValue = "All"
            cmbDept.Items.Add("All")
            cmbDept.SelectedValue = "All"
            cmbSection.Items.Add("All")
            cmbSection.SelectedValue = "All"
            cmbUnit.Items.Add("All")
            cmbUnit.SelectedValue = "All"
            cmbType.Items.Add("All")
            cmbType.SelectedValue = "All"

            'cmbYear.Items.Clear()
            'For i As Integer = Now.Year To Now.Year - 5 Step -1
            '    cmbYear.Items.Add(i)
            'Next
            'cmbYear.SelectedValue = Now.Year

            DataRefresh()
        End If
    End Sub
    Private Sub DataRefresh()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim da As SqlClient.SqlDataAdapter
        Dim ds As New DataSet
        Dim vFilter As String = ""

        If cmbRc.SelectedValue <> "All" Then   'filter by cost center
            vFilter += " and Rc_Cd='" & cmbRc.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='rc' and Property_Value=Rc_Cd) "
        End If
        If cmbOfc.SelectedValue <> "All" Then        'filter by office/agency
            vFilter += " and Agency_Cd='" & cmbOfc.SelectedValue & "' "
        Else
            vFilter += "  and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='agency' and Property_Value=Agency_Cd) "
        End If
        If cmbDiv.SelectedValue <> "All" Then      'filter by division
            vFilter += " and Divcd='" & cmbDiv.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='division' and Property_Value=DivCd) "
        End If
        If cmbDept.SelectedValue <> "All" Then  'filter by departments
            vFilter += " and DeptCd='" & cmbDept.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='department' and Property_Value=DeptCd) "
        End If
        If cmbSection.SelectedValue <> "All" Then 'filter by section
            vFilter += " and SectionCd='" & cmbSection.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='section' and Property_Value=SectionCd) "
        End If
        If cmbUnit.SelectedValue <> "All" Then  'filter by units
            vFilter += " and UnitCd='" & cmbUnit.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='unit' and Property_Value=UnitCd) "
        End If

        If cmbType.SelectedValue <> "All" Then
            vFilter += " and EmploymentType='" & cmbType.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='employmenttype' and Property_Value=EmploymentType) "
        End If


        c.ConnectionString = connStr
        da = New sqlclient.sqldataadapter("select distinct FromDate as From_Date," & _
            "ToDate as To_Date,PayDate as Pay_Date " & _
            "from py_report where Posted=0 " & vFilter & " order by PayDate desc", c)
        da.Fill(ds, "report")
        tblList.DataSource = ds.Tables("report")
        tblList.DataBind()

        da = New SqlClient.SqlDataAdapter("select distinct FromDate as From_Date," & _
                    "ToDate as To_Date,PayDate as Pay_Date " & _
                    "from py_report where Posted=1 and Year(PayDate)='" & Format(Now(), "yyyy") & "' " & _
                    vFilter & " order by PayDate desc", c)

        da.Fill(ds, "Unfreeze")
        tblUnFreeze.DataSource = ds.Tables("Unfreeze")
        tblUnFreeze.DataBind()

        ds.Dispose()
        da.Dispose()
        c.Dispose()
        cmdFreeze.Enabled = tblList.SelectedIndex >= 0
        cmdRemove.Enabled = cmdFreeze.Enabled
    End Sub

    Private Sub PostPayroll(ByVal pFrom As Date, ByVal pTo As Date, ByVal pPayDate As Date)
        'Dim cRef As New SqlClient.SqlConnection(connStr)
        'Dim cRef2 As New sqlclient.sqlconnection(connStr)
        'Dim cref3 As New sqlclient.sqlconnection(connStr)
        Dim vMonth As Integer
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cmRef As New SqlClient.SqlCommand
        Dim cmOther As New SqlClient.SqlCommand
        Dim cmExec As New SqlClient.SqlCommand
        Dim drRef As SqlClient.SqlDataReader
        Dim drOther As SqlClient.SqlDataReader
        Dim dr As SqlClient.SqlDataReader
        Dim vStart As Date = Now
        Dim iCtr As Integer
        Dim vFilter As String = ""

        If cmbRc.SelectedValue <> "All" Then   'filter by cost center
            vFilter += " and Rc_Cd='" & cmbRc.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='rc' and Property_Value=Rc_Cd) "
        End If
        If cmbOfc.SelectedValue <> "All" Then        'filter by office/agency
            vFilter += " and Agency_Cd='" & cmbOfc.SelectedValue & "' "
        Else
            vFilter += "  and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='agency' and Property_Value=Agency_Cd) "
        End If
        If cmbDiv.SelectedValue <> "All" Then      'filter by division
            vFilter += " and Divcd='" & cmbDiv.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='division' and Property_Value=DivCd) "
        End If
        If cmbDept.SelectedValue <> "All" Then  'filter by departments
            vFilter += " and DeptCd='" & cmbDept.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='department' and Property_Value=DeptCd) "
        End If
        If cmbSection.SelectedValue <> "All" Then 'filter by section
            vFilter += " and SectionCd='" & cmbSection.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='section' and Property_Value=SectionCd) "
        End If
        If cmbUnit.SelectedValue <> "All" Then  'filter by units
            vFilter += " and UnitCd='" & cmbUnit.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='unit' and Property_Value=UnitCd) "
        End If

        If cmbType.SelectedValue <> "All" Then
            vFilter += " and EmploymentType='" & cmbType.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='employmenttype' and Property_Value=EmploymentType) "
        End If

        c.ConnectionString = connStr

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred whie trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            cmOther.Dispose()
            cmExec.Dispose()
            cmRef.Dispose()
            Exit Sub
        End Try

        'cRef.Open()
        'cRef2.Open()
        'cref3.Open()

        cm.Connection = c
        cmOther.Connection = c
        cmExec.Connection = c
        cmRef.Connection = c

        vMonth = Month(pPayDate)
        cm.CommandText = "select * from py_report where Posted=0 " & vFilter & " and PayDate='" & _
           Format(pPayDate, "yyyy/MM/dd") & "' and FromDate='" & pFrom & "' and ToDate='" & pTo & "'"
        cmOther.CommandText = "select * from py_syscntrl"
        Try
            drOther = cmOther.ExecuteReader
            drOther.Read()
            dr = cm.ExecuteReader
            Do While dr.Read
                For iCtr = 1 To 60
                    If Not IsDBNull(drOther("OthDed" & iCtr & "Cd")) Or _
                       Trim(drOther("OthDed" & iCtr & "Cd")) <> "" Then
                        Dim vMonthlyAmort As Decimal = 0
                        Dim vLoanDate As Date
                        Dim vHeader As Boolean = False

                        'get loan date AND MONTHLY AMORTIZATION
                        cmRef.CommandText = "select Loan_Date,MonthlyAmort from py_loan_hdr where Active<>0 " & _
                            "and Emp_Cd='" & dr("Emp_Cd") & "' and Loan_Cd='" & drOther("OthDed" & iCtr & "Cd") & "'"
                        drRef = cmRef.ExecuteReader

                        If drRef.Read Then
                            vHeader = True
                            'UPDATE LOAN HEADER
                            vMonthlyAmort = drRef("MonthlyAmort")
                            vLoanDate = CDate(drRef("Loan_Date"))
                            cmExec.CommandText = "update py_loan_hdr set Amt_Paid=Amt_Paid + " & dr("Other_Deduct" & _
                                iCtr) & ",Amt_Bal=Amt_Bal - " & dr("Other_Deduct" & iCtr) & _
                               " where Active<>0 and Emp_Cd='" & dr("Emp_Cd") & _
                               "' and Loan_Cd='" & drOther("OthDed" & iCtr & "Cd") & "'"
                            cmExec.ExecuteNonQuery()
                        End If
                        drRef.Close()

                        If vHeader Then
                            cmRef.CommandText = "select 1 from py_loan_dtl where Emp_Cd='" & dr("Emp_Cd") & _
                            "' and Tran_Date='" & Format(pTo, "yyyy/MM/dd") & "' and Loan_Cd='" & _
                            drOther("OthDed" & iCtr & "Cd") & "' "
                            drRef = cmRef.ExecuteReader
                            If Not drRef.Read Then
                                'UPDATE LOAN DETAIL
                                cmExec.CommandText = "insert into py_loan_dtl (Emp_Cd,Tran_Date,Amt_Cost,Loan_Cd," & _
                                    "Paid,Amt_Paid,Date_Paid,Loan_Date,Active) values ('" & dr("Emp_Cd") & "','" & _
                                    Format(pTo, "yyyy/MM/dd") & "'," & vMonthlyAmort & ",'" & _
                                    drOther("OthDed" & iCtr & "Cd") & "',1," & _
                                    dr("Other_Deduct" & iCtr) & ",'" & Format(pTo, "yyyy/MM/dd") & "','" & _
                                    Format(vLoanDate, "yyyy/MM/dd") & "',1)"

                            Else
                                cmExec.CommandText = "update py_loan_dtl set Amt_Cost=" & _
                                    vMonthlyAmort & ",Paid=1,Amt_Paid=" & dr("Other_Deduct" & iCtr) & _
                                    ",Date_Paid='" & Format(pTo, "yyyy/MM/dd") & "' where Emp_Cd='" & dr("Emp_Cd") & _
                                    "' and Tran_date='" & Format(pTo, "yyyy/MM/dd") & "'"
                            End If
                            drRef.Close()
                            cmExec.ExecuteNonQuery()
                        End If
                    End If
                Next iCtr
            Loop
            dr.Close()
            drOther.Close()
            cmOther.Dispose()
            cmExec.Dispose()
            cmRef.Dispose()
            PostRemittance(pPayDate, vFilter)

            cm.CommandText = "update py_report set Posted=1 where Posted=0 and PayDate='" & _
               Format(pPayDate, "yyyy/MM/dd") & "' and FromDate='" & pFrom & "' and ToDate='" & pTo & "' " & vFilter
            cm.ExecuteNonQuery()

            DataRefresh()
            vScript = "alert('Posting of selected period was completed in " & _
                Math.Abs(DateDiff(DateInterval.Minute, vStart, Now)) & " min(s).');"
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred during freezing process. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            cm.Dispose()
            cmOther.Dispose()
            cmExec.Dispose()
            cmRef.Dispose()
            c.Dispose()
        End Try
    End Sub

    Private Sub PostRemittance(ByVal pPayDate As Date, ByVal pFilter As String)
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cmRef As New SqlClient.SqlCommand
        Dim cmExec As New SqlClient.SqlCommand
        Dim cmOther As New SqlClient.SqlCommand
        Dim drOther As SqlClient.SqlDataReader
        Dim dr As SqlClient.SqlDataReader
        Dim drRef As SqlClient.SqlDataReader
        Dim iCtr As Integer
        'Dim cRef As New sqlclient.sqlconnection(connStr)
        'Dim cRef2 As New sqlclient.sqlconnection(connStr)
        'Dim cref3 As New sqlclient.sqlconnection(connStr)

        'cRef.Open()
        'cRef2.Open()
        'cref3.Open()

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cmExec.Dispose()
            cmOther.Dispose()
            Exit Sub
        End Try

        cm.Connection = c
        cmExec.Connection = c
        cmRef.Connection = c
        cmOther.Connection = c
        cmOther.CommandText = "select * from py_syscntrl"
        drOther = cmOther.ExecuteReader
        drOther.Read()
        cm.CommandText = "select Emp_Cd, sum(Sss_Per) as Sss,sum(Sss_Gov) as SssEmr, sum(PagIbig_Per) as PagIbigEmp, " & _
           "sum(PagIbig_Gov) as PagIbigEmr, sum(Medicare_Per) as MedEmp, sum(WITH_TAX) as Tax, " & _
           "sum(Medicare_Gov) as MedEmr, sum(Other_Deduct1) as Ded1," & _
           "sum(Other_Deduct2) as Ded2, sum(Other_Deduct3) as Ded3, sum(Other_Deduct4) as Ded4," & _
           "sum(Other_Deduct5) as Ded5, sum(Other_Deduct6) as Ded6, sum(Other_Deduct7) as Ded7," & _
           "sum(Other_Deduct8) as Ded8, sum(Other_Deduct9) as Ded9, sum(Other_Deduct10) as Ded10," & _
           "sum(Other_Deduct11) as Ded11, sum(Other_Deduct12) as Ded12, sum(Other_Deduct13) as Ded13," & _
           "sum(Other_Deduct14) as Ded14, sum(Other_Deduct15) as Ded15, sum(Other_Deduct16) as Ded16," & _
           "sum(Other_Deduct17) as Ded17, sum(Other_Deduct18) as Ded18, sum(Other_Deduct19) as Ded19," & _
           "sum(Other_Deduct20) as Ded20, sum(Other_Deduct21) as Ded21, sum(Other_Deduct22) as Ded22," & _
           "sum(Other_Deduct23) as Ded23, sum(Other_Deduct24) as Ded24, sum(Other_Deduct25) as Ded25," & _
           "sum(Other_Deduct26) as Ded26, sum(Other_Deduct27) as Ded27, sum(Other_Deduct28) as Ded28," & _
           "sum(Other_Deduct29) as Ded29, sum(Other_Deduct30) as Ded30" & _
           " from py_report where Posted=0 and month(PayDate)=" & _
           pPayDate.Month & " and year(PayDate)=" & pPayDate.Year & " group by Emp_Cd"

        dr = cm.ExecuteReader
        Do While dr.Read
            'INSERT PY_TAX_RemitTANCE
            If Not IsDBNull(dr("Tax")) Or dr("Tax") <> 0 Then
                cmRef.CommandText = "select count(*) from py_tax_Remittance where Emp_Cd='" & _
                   dr("Emp_Cd") & "' and YearCd=" & pPayDate.Year
                drRef = cmRef.ExecuteReader
                drRef.Read()
                If IsDBNull(drRef(0)) Or drRef(0) = 0 Then
                    cmExec.CommandText = "insert into py_tax_Remittance (Emp_Cd,YearCd,Remit" & _
                       pPayDate.Month & ") values ('" & dr("Emp_Cd") & "'," & _
                       pPayDate.Year & "," & IIf(IsDBNull(dr("Tax")), 0, dr("Tax")) & ")"
                Else
                    cmExec.CommandText = "Update py_tax_remittance set Remit" & pPayDate.Month & _
                       "=Remit" & pPayDate.Month & " + " & dr("Tax") & _
                       " where Emp_Cd='" & dr("Emp_Cd") & "' and YearCd=" & pPayDate.Year
                End If
                cmExec.ExecuteNonQuery()
                drRef.Close()
            End If

            'INSERT PY_Sss_RemitTANCE
            If Not IsDBNull(dr("Sss")) Or dr("Sss") <> 0 Then
                cmRef.CommandText = "select count(*) from py_sss_remit where Emp_Cd='" & _
                   dr("Emp_Cd") & "' and YearCd=" & pPayDate.Year
                drRef = cmRef.ExecuteReader()
                drRef.Read()
                If IsDBNull(drRef(0)) Or drRef(0) = 0 Then
                    cmExec.CommandText = "insert into py_sss_remit (Emp_Cd,YearCd,Remit" & _
                       pPayDate.Month & ",TotEmp" & pPayDate.Month & _
                       ") values ('" & dr("Emp_Cd") & "'," & _
                       pPayDate.Year & "," & IIf(IsDBNull(dr("Sss")), 0, dr("Sss")) & _
                       "," & IIf(IsDBNull(dr("SssEmr")), 0, dr("SssEmr")) & ")"

                Else
                    cmExec.CommandText = "update py_sss_remit set Remit" & pPayDate.Month & _
                       "=Remit" & pPayDate.Month & " + " & dr("Sss") & _
                       ",TotEmp" & pPayDate.Month & "=TotEmp" & pPayDate.Month & _
                       " + " & dr("SssEmr") & " where Emp_Cd='" & dr("Emp_Cd") & "' and YearCd=" & pPayDate.Year
                End If
                cmExec.ExecuteNonQuery()
                drRef.Close()
            End If
            'INSERT PY_PAGBIG
            If Not IsDBNull(dr("PagIbigEmp")) Or dr("PagIbigEmp") <> 0 Then
                cmRef.CommandText = "select count(*) from py_PagIbig where Emp_Cd='" & _
                   dr("Emp_Cd") & "' and YearCd=" & pPayDate.Year
                drRef = cmRef.ExecuteReader
                drRef.Read()
                If IsDBNull(drRef(0)) Or drRef(0) = 0 Then
                    cmExec.CommandText = "insert into py_pagibig (Emp_Cd,YearCd,Emp_Remit" & _
                       pPayDate.Month & ",Emr_Remit" & pPayDate.Month & ") values ('" & _
                       dr("Emp_Cd") & "'," & pPayDate.Year & "," & _
                       IIf(IsDBNull(dr("PagIbigEmp")), 0, dr("PagIbigEmp")) & "," & _
                       IIf(IsDBNull(dr("PagIbigEmr")), 0, dr("PagIbigEmr")) & ")"
                Else
                    cmExec.CommandText = "update py_pagibig set Emp_Remit" & pPayDate.Month & _
                       "=Emp_Remit" & pPayDate.Month & " + " & dr("PagIbigEmp") & _
                       ",Emr_Remit" & pPayDate.Month & "=Emr_Remit" & _
                       pPayDate.Month & " + " & dr("PagIbigEmr") & _
                       " where Emp_Cd='" & dr("Emp_Cd") & "' and YearCd=" & pPayDate.Year
                End If
                cmExec.ExecuteNonQuery()
                drRef.Close()
            End If

            'INSERT PY_Medicare
            If Not IsDBNull(dr("MedEmp")) Or dr("MedEmp") <> 0 Then
                cmRef.CommandText = "select count(*) from py_medicare where Emp_Cd='" & _
                   dr("Emp_Cd") & "' and YearCd=" & pPayDate.Year
                drRef = cmRef.ExecuteReader
                drRef.Read()
                If IsDBNull(drRef(0)) Or drRef(0) = 0 Then
                    cmExec.CommandText = "insert into py_medicare (Emp_Cd,YearCd,Emp_Remit" & _
                       pPayDate.Month & ",Emr_Remit" & pPayDate.Month & ") values ('" & _
                       dr("Emp_Cd") & "'," & pPayDate.Year & "," & _
                       IIf(IsDBNull(dr("MedEmp")), 0, dr("MedEmp")) & "," & _
                       IIf(IsDBNull(dr("MedEmr")), 0, dr("MedEmr")) & ")"
                Else
                    cmExec.CommandText = "update py_medicare set Emp_Remit" & pPayDate.Month & _
                       "=Emp_Remit" & pPayDate.Month & " + " & dr("MedEmp") & _
                       ",Emr_Remit" & pPayDate.Month & "=Emr_Remit" & _
                       pPayDate.Month & " + " & dr("MedEmr") & _
                       " where Emp_Cd='" & dr("Emp_Cd") & "' and YearCd=" & pPayDate.Year
                End If
                cmExec.ExecuteNonQuery()
                drRef.Close()
            End If

            'INSERT LOAN RemitTANCE
            For iCtr = 1 To 30
                If (Not IsDBNull(drOther("OthDed" & iCtr & "Cd")) Or _
                   Trim(drOther("OthDed" & iCtr & "Cd")) <> "") And _
                   (Not IsDBNull(dr("Ded" & iCtr)) Or dr("Ded" & iCtr) <> 0) Then
                    cmRef.CommandText = "select count(*) from py_loan_remittance where Emp_Cd='" & _
                       dr("Emp_Cd") & "' and YearCd=" & pPayDate.Year & _
                       " and Loan_Cd='" & drOther("OthDed" & iCtr & "Cd") & "'"
                    drRef = cmRef.ExecuteReader
                    drRef.Read()
                    If IsDBNull(drRef(0)) Or drRef(0) = 0 Then
                        cmExec.CommandText = "insert into py_loan_remittance (Emp_Cd,YearCd,Loan_Cd,Remit" & _
                           pPayDate.Month & ") values ('" & _
                           dr("Emp_Cd") & "'," & pPayDate.Year & ",'" & drOther("OthDed" & iCtr & "Cd") & "'," & _
                           IIf(IsDBNull(dr("Ded" & iCtr)), 0, dr("Ded" & iCtr)) & ")"
                    Else
                        cmExec.CommandText = "update py_loan_remittance set Remit" & pPayDate.Month & _
                           "=Remit" & pPayDate.Month & " + " & dr("Ded" & iCtr) & _
                           " where Emp_Cd='" & dr("Emp_Cd") & "' and YearCd=" & pPayDate.Year & _
                           " and Loan_Cd='" & drOther("OthDed" & iCtr & "Cd") & "'"
                    End If
                    cmExec.ExecuteNonQuery()
                    drRef.Close()
                End If
            Next iCtr
        Loop
        dr.Close()
        drOther.Close()
        cm.CommandText = "Update py_report set RoaPosted=1 " & _
           "where Posted=0 and month(PayDate)=" & pPayDate.Month & _
           " and year(PayDate)=" & pPayDate.Year & " " & pFilter
        cm.ExecuteNonQuery()

        cm.Dispose()
        cmRef.Dispose()
        cmExec.Dispose()
        cmOther.Dispose()
        'cRef.Close()
        'cRef2.Close()
        'cref3.Close()
        'cRef.Dispose()
        'cRef2.Dispose()
        'cref3.Dispose()
        'c.Close()
    End Sub

    Protected Sub cmdFreeze_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdFreeze.Click
        PostPayroll(CDate(tblList.SelectedRow.Cells(0).Text), _
            CDate(tblList.SelectedRow.Cells(1).Text), CDate(tblList.SelectedRow.Cells(2).Text))
    End Sub

    Protected Sub cmdFreeze_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdFreeze.Init
        cmdFreeze.Attributes.Add("onclick", "javascript:document.getElementById('divWait').style.visibility='visible'; ")
    End Sub

    Protected Sub tblList_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tblList.SelectedIndexChanged
        cmdFreeze.Enabled = True
        cmdRemove.Enabled = True
    End Sub

    Protected Sub cmdRefresh_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdRefresh.Click
        DataRefresh()
    End Sub

    Protected Sub cmdRemove_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdRemove.Click
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim vPosted As Boolean = False

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        cm.Connection = c
        cm.CommandText = "select TOP 1 Posted from py_report where FromDate='" & _
            Format(CDate(tblList.SelectedRow.Cells(0).Text), "yyyy/MM/dd") & _
            "' and ToDate='" & Format(CDate(tblList.SelectedRow.Cells(1).Text)) & _
            "' and PayDate='" & Format(CDate(tblList.SelectedRow.Cells(2).Text)) & "'"
        Try
            rs = cm.ExecuteReader
            If rs.Read Then
                vPosted = rs("Posted")
            End If
            rs.Close()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to read register status. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Close()
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        If vPosted Then
            vScript = "alert('Cannot remove register because it was already frozen.');"
            c.Close()
            cm.Dispose()
            c.Dispose()
            Exit Sub
        End If

        cm.CommandText = "delete from py_report where FromDate='" & _
            Format(CDate(tblList.SelectedRow.Cells(0).Text), "yyyy/MM/dd") & _
            "' and ToDate='" & Format(CDate(tblList.SelectedRow.Cells(1).Text)) & _
            "' and PayDate='" & Format(CDate(tblList.SelectedRow.Cells(2).Text)) & "'"

        Try
            cm.ExecuteNonQuery()
            vScript = "alert('Register successfully removed.');"
            DataRefresh()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to delete register. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            c.Dispose()
            cm.Dispose()
        End Try
    End Sub

    Protected Sub cmbUnfreeze_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbUnfreeze.Click
        PostUnFreeze(CDate(tblUnFreeze.SelectedRow.Cells(0).Text), _
                CDate(tblUnFreeze.SelectedRow.Cells(1).Text), CDate(tblUnFreeze.SelectedRow.Cells(2).Text))
    End Sub

    Protected Sub tblUnFreeze_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tblUnFreeze.SelectedIndexChanged
        If tblUnFreeze.SelectedRow.RowIndex = 0 Then
            cmbUnfreeze.Enabled = "true"
        Else
            cmbUnfreeze.Enabled = "false"
            vScript = "alert('Warning you can only unfreeze the current payroll period');"
        End If
    End Sub

    Private Sub PostUnFreeze(ByVal pFrom As Date, ByVal pTo As Date, ByVal pPayDate As Date)    
        Dim vMonth As Integer
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cmRef As New SqlClient.SqlCommand
        Dim cmOther As New SqlClient.SqlCommand
        Dim cmExec As New SqlClient.SqlCommand
        Dim drRef As SqlClient.SqlDataReader
        Dim drOther As SqlClient.SqlDataReader
        Dim dr As SqlClient.SqlDataReader
        Dim vStart As Date = Now
        Dim iCtr As Integer
        Dim vFilter As String = ""

        If cmbRc.SelectedValue <> "All" Then   'filter by cost center
            vFilter += " and Rc_Cd='" & cmbRc.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='rc' and Property_Value=Rc_Cd) "
        End If
        If cmbOfc.SelectedValue <> "All" Then        'filter by office/agency
            vFilter += " and Agency_Cd='" & cmbOfc.SelectedValue & "' "
        Else
            vFilter += "  and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='agency' and Property_Value=Agency_Cd) "
        End If
        If cmbDiv.SelectedValue <> "All" Then      'filter by division
            vFilter += " and Divcd='" & cmbDiv.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='division' and Property_Value=DivCd) "
        End If
        If cmbDept.SelectedValue <> "All" Then  'filter by departments
            vFilter += " and DeptCd='" & cmbDept.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='department' and Property_Value=DeptCd) "
        End If
        If cmbSection.SelectedValue <> "All" Then 'filter by section
            vFilter += " and SectionCd='" & cmbSection.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='section' and Property_Value=SectionCd) "
        End If
        If cmbUnit.SelectedValue <> "All" Then  'filter by units
            vFilter += " and UnitCd='" & cmbUnit.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='unit' and Property_Value=UnitCd) "
        End If

        If cmbType.SelectedValue <> "All" Then
            vFilter += " and EmploymentType='" & cmbType.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='employmenttype' and Property_Value=EmploymentType) "
        End If

        c.ConnectionString = connStr

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred whie trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            cmOther.Dispose()
            cmExec.Dispose()
            cmRef.Dispose()
            Exit Sub
        End Try

        cm.Connection = c
        cmOther.Connection = c
        cmExec.Connection = c
        cmRef.Connection = c

        vMonth = Month(pPayDate)

        vMonth = Month(pPayDate)
        cm.CommandText = "select * from py_report where Posted=0 " & vFilter & " and PayDate='" & _
           Format(pPayDate, "yyyy/MM/dd") & "' and FromDate='" & pFrom & "' and ToDate='" & pTo & "'"
        cmOther.CommandText = "select * from py_syscntrl"
        Try
            drOther = cmOther.ExecuteReader
            drOther.Read()
            dr = cm.ExecuteReader
            Do While dr.Read
                For iCtr = 1 To 60
                    If Not IsDBNull(drOther("OthDed" & iCtr & "Cd")) Or _
                       Trim(drOther("OthDed" & iCtr & "Cd")) <> "" Then
                        Dim vMonthlyAmort As Decimal = 0
                        Dim vLoanDate As Date
                        Dim vHeader As Boolean = False

                        'get loan date AND MONTHLY AMORTIZATION
                        cmRef.CommandText = "select Loan_Date,MonthlyAmort from py_loan_hdr where Active<>0 " & _
                            "and Emp_Cd='" & dr("Emp_Cd") & "' and Loan_Cd='" & drOther("OthDed" & iCtr & "Cd") & "'"
                        drRef = cmRef.ExecuteReader

                        If drRef.Read Then
                            vHeader = True
                            'UPDATE LOAN HEADER
                            vMonthlyAmort = drRef("MonthlyAmort")
                            vLoanDate = CDate(drRef("Loan_Date"))

                            cmExec.CommandText = "update py_loan_hdr set Amt_Paid=Amt_Paid - " & dr("Other_Deduct" & _
                                iCtr) & ",Amt_Bal=Amt_Bal + " & dr("Other_Deduct" & iCtr) & _
                               " where Active<>0 and Emp_Cd='" & dr("Emp_Cd") & _
                               "' and Loan_Cd='" & drOther("OthDed" & iCtr & "Cd") & "'"
                            cmExec.ExecuteNonQuery()
                        End If
                        drRef.Close()

                    End If
                Next iCtr
            Loop
            dr.Close()
            drOther.Close()
            cmOther.Dispose()
            cmExec.Dispose()
            cmRef.Dispose()

            cm.CommandText = "delete from py_loan_dtl where Tran_date='" & _
                Format(pTo, "yyyy/MM/dd") & "' and Date_Paid='" & Format(pTo, "yyyy/MM/dd") & "'"
            cm.ExecuteNonQuery()

            cm.CommandText = "update py_report set Posted=0 where Posted=1 and PayDate='" & _
               Format(pPayDate, "yyyy/MM/dd") & "' and FromDate='" & pFrom & "' and ToDate='" & pTo & "'" & vFilter
            cm.ExecuteNonQuery()

            DataRefresh()
            vScript = "alert('Unfreeze the selected period was completed in " & _
                Math.Abs(DateDiff(DateInterval.Minute, vStart, Now)) & " min(s).');"
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred during freezing process. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            cm.Dispose()
            cmOther.Dispose()
            cmExec.Dispose()
            cmRef.Dispose()
            c.Dispose()
        End Try
    End Sub

    Protected Sub tbltblUnFreeze_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles tblUnFreeze.PageIndexChanging
        tblUnFreeze.PageIndex = e.NewPageIndex
        DataRefresh()
    End Sub
    
End Class
