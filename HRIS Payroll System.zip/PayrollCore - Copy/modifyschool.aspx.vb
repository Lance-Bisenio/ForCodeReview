Imports denaro
Partial Class modifyschool
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Dim c As New sqlclient.sqlconnection
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If
        If Not IsPostBack Then
            Dim cm As New sqlclient.sqlcommand
            Dim dr As sqlclient.sqldatareader
            txtEmpCd.Text = Session("empid")
            BuildCombo("select EducationType,Descr from hr_educational_ref order by Descr", cmbType)
            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c
            cm.CommandText = "select Emp_Lname,Emp_Fname from py_emp_master where Emp_Cd='" & txtEmpCd.Text & "'"
            dr = cm.ExecuteReader
            lblcaption.text = "Add/Modify Scholastic Record for "
            If dr.Read Then
                lblcaption.Text += dr("Emp_Lname") & ", " & dr("Emp_Fname")
            End If
            dr.Close()

            If Session("mode") = "e" Or Session("mode") = "v" Then
                cm.CommandText = "select * from hr_emp_scholastic where Emp_Cd='" & txtEmpCd.Text & _
                    "' and From_Date='" & Format(CDate(Session("seqid")), "yyyy/MM/dd") & "'"
                dr = cm.ExecuteReader
                If dr.Read Then
                    txtFrom.Text = IIf(IsDBNull(dr("From_Date")), "", dr("From_Date"))
                    txtTo.Text = IIf(IsDBNull(dr("To_Date")), "", dr("To_Date"))
                    txtSchool.Text = IIf(IsDBNull(dr("School")), "", dr("School"))
                    txtCourse.Text = IIf(IsDBNull(dr("Course")), "", dr("Course"))
                    txtAccomplishments.Text = IIf(IsDBNull(dr("Accomplishments")), "", dr("Accomplishments"))
                    txtAddress.Text = IIf(IsDBNull(dr("School_Address")), "", dr("School_Address"))
                    txtGrade.Text = IIf(IsDBNull(dr("Final_Grade")), "", dr("Final_Grade"))
                    cmbType.SelectedValue = PointData("select EducationType,Descr from " & _
                        "hr_educational_ref where EducationType='" & _
                        IIf(IsDBNull(dr("Type")), "", dr("Type")) & "'")
                End If
                dr.Close()
                If Session("mode") = "v" Then 'freeze fields
                    txtFrom.ReadOnly = True
                    txtTo.ReadOnly = True
                    txtSchool.ReadOnly = True
                    txtCourse.ReadOnly = True
                    txtAccomplishments.ReadOnly = True
                    txtAddress.ReadOnly = True
                    txtGrade.ReadOnly = True
                    cmbType.Enabled = False
                End If
            End If
            cm.Dispose()
            c.Close()
        End If
    End Sub

    Protected Sub cmdCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        Session.Remove("empid")
        Session.Remove("seqid")
        Session.Remove("mode")
        vScript = "window.close();"
    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        If Page.IsValid Then
            Dim cm As New sqlclient.sqlcommand
            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c
            If Session("mode") = "e" Then 'edit mode
                cm.CommandText = "update hr_emp_scholastic set From_Date='" & _
                    Format(CDate(txtFrom.Text), "yyyy/MM/dd") & _
                    "',To_Date='" & Format(CDate(txtTo.Text), "yyyy/MM/dd") & _
                    "',School='" & txtSchool.Text & _
                    "',Final_Grade=" & txtGrade.Text & _
                    ",Accomplishments='" & txtAccomplishments.Text & _
                    "',School_Address='" & txtAddress.Text & _
                    "',Type='" & cmbType.selectedvalue & _
                    "',Course='" & txtCourse.Text & _
                    "' where Emp_Cd='" & txtEmpCd.Text & "' and From_Date='" & _
                    Format(CDate(Session("seqid")), "yyyy/MM/dd") & "'"
            Else                          'add mode
                cm.CommandText = "insert into hr_emp_scholastic (Emp_Cd,From_Date,To_Date,School," & _
                    "Final_Grade,Accomplishments,School_Address,Type,Course) values ('" & _
                    txtEmpCd.Text & "','" & Format(CDate(txtFrom.Text), "yyyy/MM/dd") & "','" & _
                    Format(CDate(txtTo.Text), "yyyy/MM/dd") & "','" & txtSchool.Text & _
                    "'," & txtGrade.Text & ",'" & txtAccomplishments.Text & _
                    "','" & txtAddress.Text & "','" & cmbType.selectedvalue & "','" & _
                    txtCourse.Text & "')"
            End If
            cm.ExecuteNonQuery()
            vScript = "alert('Changes where successfully saved.');"
        End If
    End Sub

    Protected Sub vldDate_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles vldDate.ServerValidate
        vldDate.ErrorMessage = "Invalid date format."
        If txtFrom.Text = "" Then
            vScript = "alert('From date field should not be empty.');"
            args.IsValid = False
            Exit Sub
        End If
        If txtTo.Text = "" Then
            vScript = "alert('To date field should not be empty.');"
            args.IsValid = False
            Exit Sub
        End If
        If Not IsDate(txtFrom.Text) Then
            vScript = "alert('The From date field has an invalid date format.');"
            args.IsValid = False
            Exit Sub
        End If
        If Not IsDate(txtTo.Text) Then
            vScript = "alert('The To date field has an invalid date format.');"
            args.IsValid = False
            Exit Sub
        End If
        If txtSchool.Text = "" Then
            vScript = "alert('School name field should not be empty.');"
            vldDate.ErrorMessage = "School name field should not be empty."
            args.IsValid = False
            Exit Sub
        End If
        If txtCourse.Text = "" Then
            vScript = "alert('Course field should not be empty.');"
            vldDate.ErrorMessage = "Course field should not be empty."
            args.IsValid = False
            Exit Sub
        End If
        If txtGrade.Text = "" Then
            vScript = "alert('Grade field should not be empty.');"
            vldDate.ErrorMessage = "Grade field should not be empty."
            args.IsValid = False
            Exit Sub
        End If
        If Not IsNumeric(txtGrade.Text) Then
            vScript = "alert('Grade field should be numeric.');"
            vldDate.ErrorMessage = "Grade field should be numeric."
            args.IsValid = False
            Exit Sub
        End If
        args.IsValid = True
    End Sub
End Class
