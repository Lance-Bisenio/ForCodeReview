﻿Imports denaro
Partial Class loanmonitorprint
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Public vHeader As String = ""
    Public vDetails As String = ""
    Public vTitle As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            vScript = "alert('Your login session has expired. Please re-login again.'); window.close();"
            Exit Sub
        End If

        Show_Title()

        If Request.Item("m") = "byFilter" Then
            ShowAll_Loans()
        End If

        If Request.Item("m") = "byEmp" Then
            Show_LoansDetails()
        End If

    End Sub

    Private Sub Show_LoansDetails()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cmSub As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim rsSub As SqlClient.SqlDataReader

        Dim vAmt_Cost As Integer = 0
        Dim vAmt_Paid As Integer = 0
        Dim vPaid As Integer = 0

        Dim vClass As String = "odd"

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            cmSub.Dispose()
            Exit Sub
        End Try

        cm.Connection = c
        cmSub.Connection = c

        cm.CommandText = "select *, " & _
            "(select Emp_FName+' '+Emp_LName from py_emp_master where py_emp_master.Emp_Cd=py_loan_hdr.Emp_cd) as FullName " & _
            "from py_loan_hdr where Id=" & Request.Item("vData")

        Try
            rs = cm.ExecuteReader
            If rs.Read Then
                vHeader = "<tr><td colspan='4' style='Height:10px;'>&nbsp;</td></tr>"
                vHeader += "<tr>"
                vHeader += "<td class='labelR' style='width:150px;'>Employee Code :</td>"
                vHeader += "<td class='labelL' style='width:500px;'><b>" & rs("Emp_Cd") & "</b></td>"
                vHeader += "<td class='labelR' style='width:100px;'>Loan Amount :</td>"
                vHeader += "<td class='labelL'><b>" & Format(rs("Amt_Loan"), "#,##0.00") & "</b></td>"
                vHeader += "</tr>"

                vHeader += "<tr>"
                vHeader += "<td class='labelR'>Employee Name :</td>"
                vHeader += "<td class='labelL'><b>" & rs("FullName") & "</b></td>"
                vHeader += "<td class='labelR'># of Payment :</td>"
                vHeader += "<td class='labelL'><b>" & Format(rs("Month_To_Pay"), "#,##0.00") & "</b></td>"
                vHeader += "</tr>"

                vHeader += "<tr>"
                vHeader += "<td class='labelR'>Loan Date :</td>"
                vHeader += "<td class='labelL'><b>" & rs("Loan_Date") & "</b></td>"
                vHeader += "<td class='labelR'>Int Amount :</td>"
                vHeader += "<td class='labelL'><b>" & Format(rs("Int_Rate"), "#,##0.00") & "</b></td>"
                vHeader += "</tr>"

                vHeader += "<tr>"
                vHeader += "<td class='labelR'>Start of Payment :</td>"
                vHeader += "<td class='labelL'><b>" & rs("Start_Date") & "</b></td>"
                vHeader += "<td class='labelR'>Amount Paid :</td>"
                vHeader += "<td class='labelL'><b>" & Format(rs("Amt_Paid"), "#,##0.00") & "</b></td>"
                vHeader += "</tr>"

                vHeader += "<tr>"
                vHeader += "<td class='labelR'>End of Payment :</td>"
                vHeader += "<td class='labelL'><b>" & rs("End_Date") & "</td>"
                vHeader += "<td class='labelR'>Balance :</td>"
                vHeader += "<td class='labelL'><b>" & Format(rs("Amt_Bal"), "#,##0.00") & "</b></td>"
                vHeader += "</tr>"

                vHeader += "<tr>"
                vHeader += "<td class='labelR'></td>"
                vHeader += "<td class='labelL'></td>"
                vHeader += "<td class='labelR'>Amort. Amount :</td>"
                vHeader += "<td class='labelL'><b>" & Format(rs("MonthlyAmort"), "#,##0.00") & "</b></td>"
                vHeader += "</tr>"
                vHeader += "<tr><td colspan='4'>&nbsp;</td></tr>"

            End If

            vDetails += "<table style='width:90%; border-collapse:collapse;' cellpadding='0' cellspacing='0' border='1'>"
            vDetails += "<tr class='titleBar'>" & _
                "<th><b>Due Date</b></th>" & _
                "<th style='width: 100px; padding: 5px;'><b>Amount Due</b></th>" & _
                "<th style='width: 100px;'><b>Amount Paid</b></th>" & _
                "<th style='width: 100px;'><b>Paid?</b></th>" & _
                "<th style='width: 100px;'><b>Date Paid</b></th>" & _
                "<th style='width: 100px;'><b>Status</b></th>" & _
            "</tr>"

            cmSub.CommandText = "SELECT Emp_Cd,Tran_Date," & _
                " CASE WHEN Paid=1 THEN 'Paid' ELSE 'Unpaid' END AS Paid,round(Amt_Paid,2) AS Amt_Paid," & _
                "Date_Paid,CASE WHEN Active=1 THEN 'Active' ELSE 'Hold' END AS Active " & _
                ",round(Amt_Cost,2) AS Amt_Cost FROM py_loan_dtl WHERE Emp_Cd='" & _
                rs("Emp_Cd") & "' and Loan_Cd='" & _
                rs("Loan_Cd") & "' and Loan_Date='" & _
                Format(CDate(rs("Loan_Date")), "yyyy/MM/dd") & "' ORDER BY Tran_Date ASC"

            rsSub = cmSub.ExecuteReader
            Do While rsSub.Read
                vDetails += "<tr class='" & vClass & "'>"
                vDetails += "<td class='labelBC'>" & rsSub("Tran_Date") & "</td>"
                vDetails += "<td class='labelBR'>" & rsSub("Amt_Cost") & "&nbsp;</td>"
                vDetails += "<td class='labelBR'>" & rsSub("Amt_Paid") & "&nbsp;</td>"
                vDetails += "<td class='labelBC'>" & rsSub("Paid") & "</td>"
                vDetails += "<td class='labelBC'>" & rsSub("Date_Paid") & "</td>"
                vDetails += "<td class='labelBC'>" & rsSub("Active") & "</td></tr>"

                vClass = IIf(vClass = "odd", "even", "odd")

                vAmt_Cost += rsSub("Amt_Cost")
                vAmt_Paid += rsSub("Amt_Paid")

            Loop
            rsSub.Close()
            rs.Close()

            vDetails += "<tr>"
            vDetails += "<td class='labelR' style='Height: 30px;'><b>TOTAL :&nbsp;</b></td>"
            vDetails += "<td class='labelR'><b>" & Format(vAmt_Cost, "###,##0.00") & "&nbsp;</b></td>"
            vDetails += "<td class='labelR'><b>" & Format(vAmt_Paid, "###,##0.00") & "&nbsp;</b></td>"
            vDetails += "<td class='labelC'> </td>"
            vDetails += "<td class='labelC'> </td>"
            vDetails += "<td class='labelC'></td></tr>"

            vDetails += "</table><br><br>"

        Catch ex As SqlClient.SqlException
            'vScript = "alert('An error occurred while trying to retrieve system settings. Error is: " & ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Close()
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        cm.Dispose()
        c.Close()
    End Sub

    Private Sub ShowAll_Loans()

        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cmSub As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        'Dim rsSub As SqlClient.SqlDataReader

        Dim vAmt_Loan As Integer = 0
        Dim vInt_Rate As Integer = 0
        Dim vAmt_Paid As Integer = 0
        Dim vAmt_Bal As Integer = 0
        Dim vAmort As Integer = 0

        Dim vClass As String = "odd"

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            cmSub.Dispose()
            Exit Sub
        End Try

        cm.Connection = c
        cmSub.Connection = c

        vDetails += "<br><table style='width:100%; border-collapse:collapse;' cellpadding='0' cellspacing='0' border='1'>"
        vDetails += "<tr class='titleBar'>" & _
            "<th style='width: 70px;'><b>Trans #</b></th>" & _
            "<th style='width: 70px; padding: 5px;'><b>Emp Id</b></th>" & _
            "<th ><b>Fullname</b></td>" & _
            "<th style='width: 80px;'><b>Loan Date</b></th>" & _
            "<th style='width: 80px;'><b>Start of</br>Payment</b></th>" & _
            "<th style='width: 80px;'><b>End of</br>Payment</b></th>" & _
            "<th style='width: 100px;'><b>Loan Amount</b></th>" & _
            "<th style='width: 100px;'><b># of Payments</b></th>" & _
            "<th style='width: 100px;'><b>Int Amt</b></th>" & _
            "<th style='width: 100px;'><b>Amount Paid</b></th>" & _
            "<th style='width: 100px;'><b>Balance</b></th>" & _
            "<th style='width: 100px;'><b>Amort. Amt.</b></th>" & _
            "<th style='width: 100px;'><b>Frequency</b></th>" & _
        "</tr>"

        cm.CommandText = Session("vPSQL")

        Try
            rs = cm.ExecuteReader
            Do While rs.Read
                vDetails += "<tr class='" & vClass & "'>"
                vDetails += "<td class='labelBC'>" & rs("Id") & "</td>"
                vDetails += "<td class='labelBC'>" & rs("Emp_Cd") & "</td>"
                vDetails += "<td class='labelBL'>&nbsp;" & rs("Name") & "</td>"
                vDetails += "<td class='labelBC'>" & rs("LoanDate") & "</td>"
                vDetails += "<td class='labelBC'>" & rs("StartDate") & "</td>"
                vDetails += "<td class='labelBC'>" & rs("EndDate") & "</td>"
                vDetails += "<td class='labelBR'>" & Format(rs("Amt_Loan"), "###,##0.00") & "&nbsp;</td>"
                vDetails += "<td class='labelBC'>" & rs("Month_To_Pay") & "</td>"
                vDetails += "<td class='labelBR'>" & Format(rs("Int_Rate"), "###,##0.00") & "&nbsp;</td>"
                vDetails += "<td class='labelBR'>" & Format(rs("Amt_Paid"), "###,##0.00") & "&nbsp;</td>"
                vDetails += "<td class='labelBR'>" & Format(rs("Amt_Bal"), "###,##0.00") & "&nbsp;</td>"
                vDetails += "<td class='labelBR'>" & Format(rs("Amort"), "###,##0.00") & "&nbsp;</td>"
                vDetails += "<td class='labelBC'>" & IIf(rs("FreqCd") = "0", "Every Payroll", "Every " & rs("FreqCd") & "th") & "</td></tr>"

                vClass = IIf(vClass = "odd", "even", "odd")

                vAmt_Loan += rs("Amt_Loan")
                vInt_Rate += rs("Int_Rate")
                vAmt_Paid += rs("Amt_Paid")
                vAmt_Bal += rs("Amt_Bal")
                vAmort += rs("Amort")

            Loop
            rs.Close()

            vDetails += "<tr>"
            vDetails += "<td class='labelBR' style='Height: 30px;' colspan='6'><b>TOTAL :&nbsp;</b></td>"
            vDetails += "<td class='labelBR'><b>" & Format(vAmt_Loan, "###,##0.00") & "&nbsp;</b></td>"
            vDetails += "<td class='labelBR'></td>"
            vDetails += "<td class='labelBR'><b>" & Format(vInt_Rate, "###,##0.00") & "&nbsp;</b></td>"
            vDetails += "<td class='labelBR'><b>" & Format(vAmt_Paid, "###,##0.00") & "&nbsp;</b></td>"
            vDetails += "<td class='labelBR'><b>" & Format(vAmt_Bal, "###,##0.00") & "&nbsp;</b></td>"
            vDetails += "<td class='labelBR'><b>" & Format(vAmort, "###,##0.00") & "&nbsp;</b></td>"
            vDetails += "<td class='labelBR'></td></tr>"

            vDetails += "</table><br><br>"
        Catch ex As SqlClient.SqlException
            'vScript = "alert('An error occurred while trying to retrieve system settings. Error is: " & ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Close()
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        cm.Dispose()
        c.Close()
    End Sub

    Private Sub Show_Title()
        vTitle += "<table style='width:100%; border-collapse:collapse;' border='0'>"
        vTitle += "<tr><td class='labelC'><h3>" & Request.Item("t") & "<br>" & Request.Item("lt") & "<br>Date Print " & Now() & "</h3></td></tr>"
        vTitle += "</table>"
    End Sub

End Class
