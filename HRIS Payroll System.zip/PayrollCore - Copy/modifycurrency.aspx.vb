﻿Imports denaro.fis
Partial Class modifycurrency
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            vScript = "alert('Your login session has expired. Please re-login again'); window.close();"
            Exit Sub
        End If
        If Not IsPostBack Then
            lblCaption.Text = "Add/Modify Currency Reference"

            If Request.Item("m") = "e" Then 'edit mode
                Dim c As New SqlClient.SqlConnection(connStr)
                Dim cm As New SqlClient.SqlCommand("select * from currency_ref where CurrCd='" & _
                                                    Session("symbol") & "'", c)
                Dim rs As SqlClient.SqlDataReader

                Try
                    c.Open()
                Catch ex As SqlClient.SqlException
                    vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                        ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                    c.Dispose()
                    cm.Dispose()
                    Exit Sub
                End Try

                Try
                    rs = cm.ExecuteReader
                    If rs.Read Then
                        txtCurrCd.Text = rs("CurrCd")
                        txtDescr.Text = rs("CurrName")
                        txtForex.Text = rs("Forex")
                        txtUpdateDate.Text = Format(rs("LastUpdate"), "MM/dd/yyyy HH:mm:ss")
                        txtUpdatedBy.Text = rs("UpdatedBy")
                    End If
                    rs.Close()
                Catch ex As SqlClient.SqlException
                    vScript = "alert('Error occurred while trying to retrieve record.  Error is: " & _
                        ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                Finally
                    c.Close()
                    c.Dispose()
                    cm.Dispose()
                End Try
            Else
                txtUpdatedBy.Text = Session("uid")
            End If
        End If
    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        If Page.IsValid Then
            Dim c As New SqlClient.SqlConnection(connStr)
            Dim cm As New SqlClient.SqlCommand

            Try
                c.Open()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                c.Dispose()
                cm.Dispose()
                Exit Sub
            End Try

            cm.Connection = c
            Try
                If Request.Item("m") = "e" Then   'edit mode
                    cm.CommandText = "update currency_ref set CurrCd='" & txtCurrCd.Text & _
                        "',CurrName='" & txtDescr.Text & _
                        "',Forex=" & Val(txtForex.Text) & _
                        ",LastUpdate='" & Format(CDate(txtUpdateDate.Text), "yyyy/MM/dd HH:mm:ss") & _
                        "',UpdatedBy='" & Session("uid") & _
                        "' where CurrCd='" & Session("symbol") & "'"
                    cm.ExecuteNonQuery()
                    cm.CommandText = "update currency_ref_hist set CurrCd='" & txtCurrCd.Text & _
                        "' where CurrCd='" & Session("symbol") & "'"
                    cm.ExecuteNonQuery()
                    vScript = "alert('Changes were successfully saved.'); window.close();"
                Else                            'add mode
                    cm.CommandText = "insert into currency_ref (CurrCd,CurrName,Forex,LastUpdate,UpdatedBy) values ('" & _
                        txtCurrCd.Text & "','" & txtDescr.Text & "'," & Val(txtForex.Text) & ",'" & _
                        Format(CDate(txtUpdateDate.Text), "yyyy/MM/dd HH:mm:ss") & "','" & _
                        Session("uid") & "')"
                    cm.ExecuteNonQuery()
                    vScript = "alert('Changes were successfully saved.'); window.close();"
                End If
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to save changes. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            Finally
                c.Close()
                cm.Dispose()
                c.Dispose()
            End Try
        End If
    End Sub

    Protected Sub vldDate_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles vldDate.ServerValidate
        args.IsValid = IsDate(txtUpdateDate.Text)
    End Sub

    Protected Sub vldForex_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles vldForex.ServerValidate
        args.IsValid = IsNumeric(txtForex.Text)
    End Sub
End Class
