Imports denaro
Partial Class modifyleaveref
    Inherits System.Web.UI.Page

    Public vScript As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If

        If Not IsPostBack Then
            Dim c As New SqlClient.SqlConnection(connStr)
            Dim cm As New SqlClient.SqlCommand
            Dim dr As SqlClient.SqlDataReader
            Dim auprevyear As String = ""

            txtEmpCd.Text = Session("empid")
            Try
                c.Open()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                c.Dispose()
                cm.Dispose()
                Exit Sub
            End Try

            cm.Connection = c
            cm.CommandText = "select Emp_Lname,Emp_Fname from py_emp_master where Emp_Cd='" & txtEmpCd.Text & "'"
            dr = cm.ExecuteReader
            lblCaption.Text = "Add/Modify Leave Credits for "
            If dr.Read Then
                lblCaption.Text += dr("Emp_Lname") & ", " & dr("Emp_Fname")
            End If
            dr.Close()
            BuildCombo("select Leave_Cd,Descr from py_leave_ref order by Descr", cmbType, c)

            If Session("mode") = "e" Or Session("mode") = "v" Then
                cm.CommandText = "select * from py_emp_leave where Emp_Cd='" & txtEmpCd.Text & _
                    "' and Leave_Cd='" & Session("seqid") & "'"
                dr = cm.ExecuteReader
                If dr.Read Then
                    If IsDBNull(dr("ExpiryDate")) Then
                        auprevyear = ""
                    Else
                        auprevyear = Format(dr("ExpiryDate"), "MM/dd/yyyy")
                    End If

                    txtCustomCredit.Text = dr("CurrCustomBal")
                    txtCredit.Text = dr("Credit")
                    txtUsed.Text = dr("Used")
                    txtBal.Text = dr("Balance")
                    txtDate.Text = IIf(IsDBNull(dr("LastUpdate")), "", dr("LastUpdate"))
                    cmbType.SelectedValue = dr("Leave_Cd")
                    txtPrevBal.Text = IIf(IsDBNull(dr("BalanceLastYear")), 0, dr("BalanceLastYear"))
                    txtPrevYrExpiry.Text = auprevyear
                    cmbType.Enabled = False
                    '''''''''''''''''''''''''''''''''''''''''''

                    Session("oldval") = "Leave Type=" & Session("seqid") & _
                        "|Custom Current Balance=" & dr("CurrCustomBal") & _
                        "|Current Credit=" & dr("Credit") & _
                        "|Current Used=" & dr("Used") & _
                        "|Current Balance=" & dr("Balance")
                    If IsDBNull(dr("LastUpdate")) Then
                        Session("oldval") += "|Last Update="
                    Else
                        Session("oldval") += "|Last Update=" & Format(dr("LastUpdate"), "yyyy/MM/dd")
                    End If
                    Session("oldval") += "|Balance Previous Year=" & IIf(IsDBNull(dr("BalanceLastYear")), 0, dr("BalanceLastYear")) & _
                        "|Expiry Date Previous Year=" & auprevyear
                    ''''''''''''''''''''''''''''''''''''''''''''
                    CheckLeaveType()
                End If
                dr.Close()
                If Session("mode") = "v" Then 'freeze fields
                    txtCustomCredit.ReadOnly = True
                    txtCredit.ReadOnly = True
                    txtUsed.ReadOnly = True
                    txtBal.ReadOnly = True

                    txtDate.ReadOnly = True
                    cmbType.Enabled = False
                    txtPrevBal.ReadOnly = True
                    txtPrevYrExpiry.ReadOnly = True
                    Session("oldval") = ""
                End If
            End If
            cm.Dispose()
            c.Close()
            c.Dispose()
        End If
    End Sub

    Protected Sub cmdCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        Session.Remove("empid")
        Session.Remove("seqid")
        Session.Remove("mode")
        vScript = "window.close();"
    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        Dim vdidwat As String = ""
        If Page.IsValid Then
            Dim c As New SqlClient.SqlConnection(connStr)
            Dim cm As New SqlClient.SqlCommand
            Dim audateprev As String = ""

            c.ConnectionString = connStr

            Try
                c.Open()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                c.Dispose()
                cm.Dispose()
                Exit Sub
            End Try

            cm.Connection = c

            ''''''''''''''''''''''''''''''''''''''''''''''''''
            audateprev = "null"
            If txtPrevYrExpiry.Text <> "" Then
                If IsDate(txtPrevYrExpiry.Text) Then audateprev = "'" & Format(CDate(txtPrevYrExpiry.Text), "yyyy/MM/dd") & "'"
            End If

            Session("newval") = "Leave Type=" & cmbType.SelectedValue & _
                "|Custom Current Balance=" & txtCustomCredit.Text & _
                "|Current Credit=" & txtCredit.Text & _
                "|Current Used=" & txtUsed.Text & _
                "|Current Balance=" & txtBal.Text & _
                "|Last Update=" & Format(CDate(txtDate.Text), "yyyy/MM/dd") & _
                "|Balance Previous Year=" & Val(txtPrevBal.Text) & _
                "|Expiry Date Previous Year=" & audateprev.Replace("'", "")
            ''''''''''''''''''''''''''''''''''''''''''''

            If Session("mode") = "e" Then 'edit mode
                vdidwat = "EDIT"
                cm.CommandText = "update py_emp_leave set LastUpdate='" & Format(CDate(txtDate.Text), "yyyy/MM/dd") & _
                    "',Credit=" & txtCredit.Text & _
                    ",Used=" & txtUsed.Text & _
                    ",Balance=" & txtBal.Text & _
                    ",CurrCustomBal=" & txtCustomCredit.Text & _
                    ",BalanceLastYear=" & Val(txtPrevBal.Text) & _
                    ",ExpiryDate=" & audateprev & _
                    " where Emp_Cd='" & txtEmpCd.Text & "' and Leave_Cd='" & Session("seqid") & "'"
            Else                          'add mode
                vdidwat = "ADD"
                cm.CommandText = "insert into py_emp_leave (Emp_Cd,Leave_Cd,LastUpdate,Credit,Used," & _
                    "Balance,BalanceLastYear,ExpiryDate,CurrCustomBal) values ('" & txtEmpCd.Text & "','" & cmbType.SelectedValue & _
                    "','" & Format(CDate(txtDate.Text), "yyyy/MM/dd") & "'," & txtCredit.Text & _
                    "," & txtUsed.Text & "," & txtBal.Text & "," & Val(txtPrevBal.Text) & _
                    "," & audateprev & "," & txtCustomCredit.Text & ")"
            End If
            cm.ExecuteNonQuery()
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '''''''''''''''' AUDIT TRAIL '''''''''''''''''''''''''''''''
            '''''''''''''''' Added by: Rudner D. Diaz        '''''''''''
            '''''''''''''''' Date Added: 2/18/2012           '''''''''''
            '''''''''''''''' Reason: To add an audit trail in adding or'
            ''''''''''''''''         editing the leave balance''''''''''
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            EventLog(Session("uid"), Request.ServerVariables("REMOTE_ADDR"), vdidwat, Session("oldval"), Session("newval"), _
                        "Employee ID: " & Session("empid") & " was added/edited the leave", "Leave", c)
            Session.Remove("oldval")
            Session.Remove("newval")
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            Session.Remove("empid")
            Session.Remove("seqid")
            Session.Remove("mode")
            c.Close()
            c.Dispose()
            cm.Dispose()

            vScript = "alert('Changes where successfully saved.'); window.close();"
        End If
    End Sub

    Protected Sub CustomValidator1_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles CustomValidator1.ServerValidate
        args.IsValid = IsDate(txtDate.Text)
        If Not args.IsValid Then
            vScript = "alert('Invalid date format.');"
            Exit Sub
        End If
        If Not IsNumeric(txtCredit.Text) Or Not IsNumeric(txtUsed.Text) Or _
            Not IsNumeric(txtBal.Text) Then
            args.IsValid = False
            vScript = "alert('Invalid numeric format.');"
            Exit Sub
        End If
        If txtPrevBal.Text <> "" Then
            If Not IsNumeric(txtPrevBal.Text) Or Not IsNumeric(txtPrevBal.Text) Or _
            Not IsNumeric(txtPrevBal.Text) Then
                args.IsValid = False
                vScript = "alert('Invalid numeric format.');"
                Exit Sub
            End If
        End If

        If txtPrevYrExpiry.Text <> "" Then
            args.IsValid = IsDate(txtPrevYrExpiry.Text)
            If Not args.IsValid Then
                vScript = "alert('Invalid date formatdfdfd.');"
                Exit Sub
            End If
            args.IsValid = True
        End If
        
    End Sub
    Private Sub CheckLeaveType()

        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        cm.Connection = c

        txtCustomCredit.Enabled = True
        txtCredit.Enabled = True
        txtUsed.Enabled = True
        txtBal.Enabled = True
        txtPrevBal.Enabled = True

        Try
            cm.CommandText = "select AlwaysPaid from py_leave_ref where Leave_Cd='" & cmbType.SelectedValue & "'"
            rs = cm.ExecuteReader
            If rs.Read Then
                txtCustomCredit.Enabled = rs("AlwaysPaid") = 0
                txtCredit.Enabled = txtCustomCredit.Enabled
                txtUsed.Enabled = txtCustomCredit.Enabled
                txtBal.Enabled = txtCustomCredit.Enabled
                txtPrevBal.Enabled = txtCustomCredit.Enabled
                If rs("AlwaysPaid") = 1 Then
                    vScript = "alert('The leave type you selected is set to Always Paid. You can only set the Expiry Date and Last Update Date.');"
                End If
            End If
            rs.Close()

            cm.CommandText = "select 1 from py_leave_table where LeaveCd='" & cmbType.SelectedValue & "'"
            rs = cm.ExecuteReader
            If rs.HasRows Then
                txtCredit.Enabled = False
                txtUsed.Enabled = False
                txtBal.Enabled = False
                vScript = "alert('The leave type you selected is set to automatic computation. You can only set the Custom Leave Balance and Previous Year\'s value.');"
            End If
            rs.Close()

        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to retrieve Leave Record. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            c.Dispose()
            cm.Dispose()
        End Try
    End Sub
    Protected Sub cmbType_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbType.SelectedIndexChanged
        CheckLeaveType()
    End Sub

    Protected Sub txtCredit_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtCredit.Init
        txtCredit.Attributes.Add("onblur", "compute(this)")
    End Sub

    Protected Sub txtUsed_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtUsed.Init
        txtUsed.Attributes.Add("onblur", "compute(this)")
    End Sub

    Protected Sub txtBal_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtBal.Init
        txtBal.Attributes.Add("onblur", "compute(this)")
    End Sub

End Class
