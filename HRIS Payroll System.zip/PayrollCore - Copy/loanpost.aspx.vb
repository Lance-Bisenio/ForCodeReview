Imports System.Data
Imports denaro.fis
Partial Class loanpost
    Inherits System.Web.UI.Page
    Public vDump As String = ""
    Public vScript As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If
        If Not IsPostBack Then
            lblCaption.Text = "List of Loan(s) for posting"
            BuildCombo("select Loan_Cd,Loan_Name from py_loan_ref order by Loan_Name", cmbLoan)
            BuildList("select LoanType, Descr from hr_loan_ref ORDER BY Descr", lstLoan)
            lstLoan.SelectedValue = "All"
            DataRefresh()
        End If
    End Sub
    Private Sub DataRefresh()
        Dim c As New sqlclient.sqlconnection(connStr)
        Dim cm As New sqlclient.sqlcommand
        Dim rs As sqlclient.sqldatareader
        Dim vCount As Integer = 0
        Dim vAmt As Decimal = 0
        Dim vCtr As Integer = 0
        Dim Bg As String = "odd"

        cm.Connection = c
        If lstLoan.SelectedValue = "All" Then
            cm.CommandText = "select SeqId,Emp_Cd,LoanAmt,Amortization,LoanType,NoPayment from hr_loan_application where Synchronized=0 and Void=0 and DateApproved IS NOT NULL"
        Else
            cm.CommandText = "select SeqId,Emp_Cd,LoanAmt,Amortization,LoanType,NoPayment from hr_loan_application where Synchronized=0 and Void=0 and DateApproved IS NOT NULL AND LoanType = '" & lstLoan.SelectedValue & "'"
        End If
        c.Open()
        rs = cm.ExecuteReader
        vDump = ""
        Do While rs.Read
            vDump += "<tr class='" & Bg & "'>"
            vDump += "<td><input type='checkbox' id='" & vCtr & "' value='" & rs("SeqId") & "' /></td>" & _
                    "<td style='width: 117px' align='left'>" & rs("Emp_Cd") & "</td>" & _
                    "<td style='width: 387px' align='left'>" & GetName(rs("Emp_Cd")) & "</td>" & _
                    "<td style='width: 85px'>" & rs("LoanType") & "</td>" & _
                    "<td style='width: 85px'>" & rs("NoPayment") & "</td>" & _
                    "<td style='width: 85px'>" & Format(rs("LoanAmt"), "#0.00") & "</td>" & _
                    "<td style='width: 85px'>" & Format(rs("Amortization"), "#0.00") & "</td>"
            vDump += "</tr>"
            vCtr += 1
            If Bg = "odd" Then
                Bg = "even"
            Else
                Bg = "odd"
            End If
        Loop
        txtCount.Value = vCtr
        rs.Close()
        c.Close()
        cm.Dispose()
        c.Dispose()

    End Sub
    Protected Sub cmdReturn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.Click
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub cmdPost_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdPost.Click
        Dim c As New sqlclient.sqlconnection(connStr)
        Dim cExec As New sqlclient.sqlconnection(connStr)
        Dim cm As New sqlclient.sqlcommand
        Dim cmExec As New sqlclient.sqlcommand
        Dim rs As sqlclient.sqldatareader
        Dim vCount As Integer = 0
        Dim vAmt As Decimal = 0
        Dim vSeqId As String = txtEmp.Value

        If lstLoan.SelectedValue = "All" Then
            vScript = "alert('Please select specific loan type first.');"
            Exit Sub
        End If

        vSeqId = vSeqId.Replace(",", "','")
        vSeqId = vSeqId.Substring(0, vSeqId.Length - 3)

        Try
            c.Open()
            cExec.Open()
            cm.Connection = c
            cmExec.Connection = cExec
            cm.CommandText = "SELECT * FROM hr_loan_application WHERE SeqId in ('" & vSeqId & "')"

            rs = cm.ExecuteReader
            Do While rs.Read
                cmExec.CommandText = "insert into py_loan_hdr (Emp_Cd,Loan_Cd,Amt_Bal,Amt_Loan,Amt_Paid," & _
                    "Loan_Date,Start_Date,Int_Rate,Month_to_Pay,Active,ProdDescr,Monthly,MonthlyAmort,Recurring," & _
                    "End_Date,PaymentsMade,FreqCd,DocNo) values ('" & rs("Emp_Cd") & "','" & _
                    cmbLoan.SelectedValue & "'," & rs("LoanAmt") & "," & rs("LoanAmt") & ",0,'" & Format(rs("TranDate"), "yyyy/MM/dd") & _
                    "','" & Format(rs("StartDate"), "yyyy/MM/dd") & "',0,'" & rs("NoPayment") & "',1,'" & rs("LoanType") & " Loan" & "',0," & _
                    rs("Amortization") & ",0,'" & Format(rs("EndDate"), "yyyy/MM/dd") & "',0,'" & rs("Frequency") & "','.')"
                cmExec.ExecuteNonQuery()

                cmExec.CommandText = "UPDATE hr_loan_application SET Synchronized = 1 WHERE SeqId = '" & rs("SeqId") & "'"
                cmExec.ExecuteNonQuery()
            Loop
            rs.Close()
            c.Close()
            cExec.Close()
            cm.Dispose()
            cmExec.Dispose()
            c.Dispose()
            cExec.Dispose()
            vScript = "alert('Loan successfully posted.');"
            DataRefresh()
            txtEmp.Value = ""
        Catch ex As sqlclient.sqlException
            vScript = "alert('An error ocurred while trying to save your changes. Error is: " & _
                ex.Message.Replace("'", "").Replace(";", "") & "');"
        End Try
    End Sub
    Private Sub BuildList(ByVal pSql As String, ByRef pList As System.Web.UI.WebControls.ListBox)
        Dim c As New sqlclient.sqlconnection
        Dim cm As New sqlclient.sqlcommand
        Dim rs As sqlclient.sqldatareader

        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c
        cm.CommandText = pSql
        rs = cm.ExecuteReader
        pList.Items.Clear()
        pList.Items.Add(New ListItem("All", "All"))
        Do While rs.Read
            pList.Items.Add(New ListItem(rs(0) & "=>" & IIf(IsDBNull(rs(1)), "null", rs(1)), rs(0)))
        Loop
        rs.Close()
        cm.Dispose()
        c.Close()
    End Sub

    Protected Sub lstLoan_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles lstLoan.SelectedIndexChanged
        DataRefresh()
    End Sub
End Class
