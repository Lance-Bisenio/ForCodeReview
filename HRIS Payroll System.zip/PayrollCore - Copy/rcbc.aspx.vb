﻿Imports denaro.fis
Partial Class rcbc
    Inherits System.Web.UI.Page
    Public vResponse As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            vResponse = "expired"
            Exit Sub
        End If

        Dim vCutOff As Date = CDate(Request.Form("cutoff"))
        Dim vPayOut As Date = CDate(Request.Form("payout"))
        Dim vCredit As Date = CDate(Request.Form("credit"))
        Dim vAcctType As String = Request.Form("acct")
        Dim vBank As String = Request.Form("bank")
        Dim vRc As String = Request.Form("rc")
        Dim vAgency As String = Request.Form("agency")
        Dim vDiv As String = Request.Form("div")
        Dim vRank As String = Request.Form("rank")
        Dim vStatus As String = Request.Form("stat")

        Dim vHash As Decimal = 0
        Dim vTrailerHash As Decimal = 0
        Dim vAmount As Decimal = 0
        Dim vAcctNo As String = ""

        Dim vPDF As New VSPDF8Lib.VSPDF8
        Dim vPrn As New VSPrinter8Lib.VSPrinter

        Dim vCompanyName As String = vAgency
        Dim vAddress As String = ""
        Dim vGrandTotal As Decimal
        Dim iCtr As Integer
        Dim vErr As String = ""
        Dim vPreparedBy As String = ""
        Dim vApprovedBy As String = ""
        Dim vPosition As String = "Unknown"
        Dim vPositionApproved As String = "Unknown"
        Dim vFilter As String
        Dim vDump As String = ""
        Dim vCompanyCd As String
        Dim vBranchCd As String = ""
        Dim vBankCd As String = ""
        Dim vBankAcct As String = ""
        Dim vClass As String = "odd"
        Dim vData As New StringBuilder

        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader


        vFilter = " where PayDate='" & Format(vPayOut, "yyyy/MM/dd") & "' and FromDate='" & _
            Format(vCutOff, "yyyy/MM/dd") & "' "
        Select Case vAcctType
            Case "SA", "CA"
                vFilter += " and Report_No is not null and Report_No<>'' "
                'filter by bank code
                vFilter += " and exists (select Emp_Cd from py_emp_master where Bank_Code='" & vBank & "' and Bank_Type='" & _
                    vAcctType & "' and Date_Resign is null) "
            Case Else
                vFilter += " and (Report_No is null or Report_No='') "
        End Select

        If vRc <> "All" Then   'filter by cost center
            vFilter += " and Rc_Cd='" & vRc & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='rc' and Property_Value=Rc_Cd) "
        End If

        If vAgency <> "All" Then        'filter by office/agency
            vFilter += " and Agency_Cd='" & vAgency & "' "
        Else
            vFilter += "  and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='agency' and Property_Value=Agency_Cd) "
        End If
        If vDiv <> "All" Then      'filter by division
            vFilter += " and Divcd='" & vDiv & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='division' and Property_Value=DivCd) "
        End If
        If vRank <> "All" Then 'filter by employment types
            vFilter += " and EmploymentType='" & vRank & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='employmenttype' and Property_Value=EmploymentType) "
        End If

        vData.Remove(0, vData.Length)
        vData.AppendLine("<html>")
        vData.AppendLine("<title>Bank Advise Report</title>")
        vData.AppendLine("<link rel='stylesheet' href='../redtheme/red.css' type='text/css' />")
        vData.AppendLine("<body><center>")

        cm.Connection = c
        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vResponse = "error"
            vData.AppendLine(ex.Message)
            GoTo dump
        End Try

        Try
            cm.CommandText = "select AgencyName from agency where AgencyCd='" & vAgency & "'"
            rs = cm.ExecuteReader
            If rs.Read Then
                vCompanyName = rs("AgencyName")
            End If
            rs.Close()
            cm.CommandText = "select CompanyCd,Company_Name,BranchCd,BankCd,Attention,AttentionPos,Address,BankAcctNo " & _
                "from glsyscntrl where AgencyCd='" & vAgency & "'"
            rs = cm.ExecuteReader
            vCompanyCd = vAgency        'set initial value
            vApprovedBy = "Unknown"
            vPositionApproved = "Unknown"
            If rs.Read Then
                vCompanyCd = IIf(IsDBNull(rs("CompanyCd")), "Unknown Company", rs("CompanyCd"))
                vBranchCd = IIf(IsDBNull(rs("BranchCd")), "Unknown Branch", rs("BranchCd"))
                vBankCd = IIf(IsDBNull(rs("BankCd")), "Unknown Bank", rs("BankCd"))
                vBankAcct = IIf(IsDBNull(rs("BankAcctNo")), "Unknown Account", rs("BankAcctNo"))
                vCompanyName = IIf(IsDBNull(rs("Company_Name")), "", Mid(rs("Company_Name"), 1, 40))
                vCompanyName += Space(40 - Len(vCompanyName))
                vApprovedBy = IIf(IsDBNull(rs("Attention")), "Unknown", rs("Attention"))
                vAddress = IIf(IsDBNull(rs("Address")), "Unknown Address", rs("Address"))
                vPositionApproved = IIf(IsDBNull(rs("AttentionPos")), "Unknown", rs("AttentionPos"))
            End If
            rs.Close()

            vData.AppendLine("<h2>Bank Advise Report for " & vCompanyName & "</h2>")
            vData.AppendLine("<h3>Emloyees " & IIf(vAcctType = "NA", "without", "with") & " Account Numbers" & "</h3>")
            vData.AppendLine("<h4>for the " & vPayOut & " payroll</h4><br/>")

            vData.AppendLine("<table border='1' style='border-collapse:collapse;' class='mainGridView'><tr class='titleBar'>" & _
                "<th class='labelC'>Line No.</th><th class='labelC'>Account Name</th>" & _
                "<th class='labelC'>Account Number</th><th class='labelC'>Credited Amount</th></tr>")

            vGrandTotal = 0
            iCtr = 1
            cm.CommandText = "select FullName,Position from user_list where User_Id='" & Session("uid") & "'"
            rs = cm.ExecuteReader
            vPreparedBy = Session("uid")
            vPosition = "Uknown"
            If rs.Read Then
                vPreparedBy = IIf(IsDBNull(rs("FullName")), Session("uid"), rs("FullName"))
                vPosition = IIf(IsDBNull(rs("Position")), "Unknown", rs("Position"))
            End If
            rs.Close()

            cm.CommandText = "select Name,Report_No,Amount_Per from py_report " & vFilter & _
               " and Amount_Per is not null and Amount_Per > 0 and exists " & _
               "(select Emp_Cd from py_emp_master where py_emp_master.Emp_Cd=py_report.Emp_Cd and " & _
               "Bank_Code='RCBC'"

            Select Case vStatus
                Case 0  'inactive
                    cm.CommandText += " and Date_Resign is not null "
                Case 1  'active
                    cm.CommandText += " and Date_Resign is null and DateHold is null "
                Case 2  'hold
                    cm.CommandText += " and Date_Resign is null and DateHold is not null "
            End Select
            cm.CommandText += ") order by Name"

            rs = cm.ExecuteReader
            vDump = ""
            Do While rs.Read
                vAcctNo = rs("Report_No").ToString.Replace("-", "")
                vHash += Val(vAcctNo)
                vTrailerHash += Int(rs("Amount_Per")) * Val(Mid(rs("Report_No"), 5))
                vDump += "01001"
                If Val(Mid(vAcctNo, 2, 3)) <> 0 Then
                    vDump += Mid(vAcctNo, 2, 3) & "000"
                Else
                    vDump += "001000"
                End If
                vDump += Format(Val(vAcctNo), "00000000000000") & "801110"
                vAmount = rs("Amount_Per") * 100
                vDump += Format(vAmount, "000000000000000")
                vDump += Format(vPayOut.Month, "00") & _
                    Format(vPayOut.Day, "00") & _
                    Format(vPayOut.Year - 2000, "00") & "0" & Space(25) & "00001" & _
                    Space(10) & vBranchCd & Space(4) & vbNewLine

                vData.AppendLine("<tr class='" & vClass & "'><td class='labelR'>" & iCtr & ".</td>" & _
                    "<td class='labelL'>" & rs("Name") & "</td><td class='labelC'>" & IIf(IsDBNull(rs("Report_No")), "", rs("Report_No")) & _
                    "</td><td class='labelR'>" & Format(rs("Amount_Per"), "###,##0.00") & "</td></tr>")

                iCtr += 1
                vGrandTotal += rs("Amount_Per")
                vClass = IIf(vClass = "odd", "even", "odd")
            Loop
            rs.Close()

            vDump += "H" & Format(vHash, "00000000000000000000") & _
                Format(vGrandTotal, "00000000000000000000") & Format(vTrailerHash, "00000000000000000000")


            vPrn.StartDoc()
            vPrn.MarginTop = OneInch * 2
            vPrn.MarginBottom = OneInch
            vPrn.MarginLeft = OneInch / 2
            vPrn.MarginRight = OneInch / 2

            vPrn.Paragraph = Format(Now, "long date") & vbNewLine & vbNewLine
            vPrn.FontBold = True
            vPrn.Paragraph = "RIZAL COMMERCIAL BANKING CORPORATION" & vbNewLine & vbNewLine
            vPrn.FontBold = False
            vPrn.Paragraph = "ATTN: ___________________________________" & vbNewLine & vbNewLine
            vPrn.FontBold = True
            vPrn.Paragraph = vCompanyName
            vPrn.FontBold = False
            vPrn.Paragraph = vAddress & vbNewLine & vbNewLine & vbNewLine
            vPrn.TextAlign = VSPrinter8Lib.TextAlignSettings.taCenterMiddle
            vPrn.FontBold = True
            vPrn.Paragraph = "DEBIT AUTHORIZATION" & vbNewLine
            vPrn.FontBold = False
            vPrn.TextAlign = VSPrinter8Lib.TextAlignSettings.taJustBottom
            vPrn.Text = "This is to authorize "
            vPrn.FontBold = True
            vPrn.FontUnderline = True
            vPrn.Text = "  RIZAL COMMERCIAL BANKING CORPORATION "
            vPrn.FontBold = False
            vPrn.FontUnderline = False
            vPrn.Text = " to debit our Savings Account/Current Account with account number   "
            vPrn.FontBold = True
            vPrn.FontUnderline = True
            vPrn.Text = vBankAcct
            vPrn.FontBold = False
            vPrn.FontUnderline = False
            vPrn.Text = "   the amount of PESOS: " & Num2Words(vGrandTotal) & "  (PHP " & _
                Format(vGrandTotal, "##,###,##0.00") & ") and credit the payroll accounts of our employees." & vbNewLine & vbNewLine & vbNewLine
            vPrn.Paragraph = "Thank You," & vbNewLine & vbNewLine & vbNewLine
            vPrn.Paragraph = "________________________" & vbTab & vbTab & vbTab & vbTab & vbTab & "___________________________"
            vPrn.Paragraph = "  Authorized Signatory  " & vbTab & vbTab & vbTab & vbTab & vbTab & vbTab & "    Authorized Signatory   "
            vPrn.EndDoc()
            vPDF.ConvertDocument(vPrn, Server.MapPath(".") & "\downloads\" & Session.SessionID & "-topcover.pdf")


            vData.AppendLine("<tr class='activeBar'><td colspan='3' class='labelR'>Grand Total:</td>" & _
                "<td class='labelR'>" & Format(vGrandTotal, "###,###,##0.00") & "</td></tr></table><br/<br/>")

            vData.AppendLine("<table border='0' class='mainGridView'><tr valign='top'><td class='labelL'>Prepared By:<br/><br/><br/><br/></td>" & _
                "<td></td><td class='labelL'>Approved By:</td><td class='labelL'>Authorized By:</td></tr>")
            vData.AppendLine("<tr><td class='labelL'>_________________________</td><td>&nbsp;&nbsp;&nbsp;</td>" & _
                "<td class='labelL'>______________________</td><td class='labelL'>______________________</td></tr>" & _
                 "<tr><td class='labelL'>" & vPreparedBy & "</td><td></td><td class='labelL'>" & vApprovedBy & "</td></tr>" & _
                 "<tr><td class='labelL'>" & vPosition & "</td><td></td><td class='labelL'>" & vPositionApproved & "</td><td></td></tr></table>")
            If vDump <> "" Then
                'remove last newline character
                vDump = Mid(vDump, 1, Len(vDump) - 2)
                'dump total lines and total amount
                'vDump += Format(iCtr - 1, "000000") & Format(vGrandTotal * 100, "000000000000000")
            End If
        Catch ex As SqlClient.SqlException
            vResponse = "error"
            vData.AppendLine(ex.Message)
            GoTo dump
        End Try
dump:
        vData.AppendLine("</center></body>")
        vData.AppendLine("</html>")
        Try
            IO.File.WriteAllText(Server.MapPath(".") & "\downloads\" & Session.SessionID & "-bankadvise.html", vData.ToString)
            IO.File.WriteAllText(Server.MapPath(".") & "\downloads\" & Session.SessionID & "-bankadvise.txt", vDump)
            vResponse = "downloads/" & Session.SessionID & "-bankadvise.html~" & _
                "downloads/" & Session.SessionID & "-bankadvise.txt~" & _
                "downloads/" & Session.SessionID & "-topcover.pdf"
        Catch ex As system.exception
            vResponse = "error"
        Finally
            c.Close()
            cm.Dispose()
            c.Dispose()
        End Try
    End Sub
End Class
