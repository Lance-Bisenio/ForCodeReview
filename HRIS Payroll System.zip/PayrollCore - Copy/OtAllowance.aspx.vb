Imports denaro
Imports System.Collections
Partial Class OtAllowance
    Inherits System.Web.UI.Page
    Public vList As String = ""
    Public vScript As String

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        With Me
            If Session("uid") = "" Then
                Server.Transfer("index.aspx")
            End If

            If Not IsPostBack Then
                If Not CanRun(Session("caption"), Request.Item("id")) Then
                    Session("denied") = "1"
                    Server.Transfer("main.aspx")
                    Exit Sub
                End If
                Session.Remove("vList")
                Dim i As Integer = 0
                lblCaption.Text = "OT Allowance Report"
                
                'now build the reference code
                BuildCombo("select Rc_Cd, Descr from rc where Rc_Cd in ('" & _
                    Session("rclist").ToString.Replace(",", "','") & "') order by Descr ", cmbRC)
                BuildCombo("select AgencyCd,AgencyName from agency where Agencycd in ('" & _
                    Session("agencylist").ToString.Replace(",", "','") & "') order by AgencyName", cmbOfc)
                BuildCombo("select Div_Cd,Descr from hr_div_ref where Div_Cd in ('" & _
                    Session("divlist").ToString.Replace(",", "','") & "') order by Descr", cmbDiv)
                BuildCombo("select Dept_Cd,Descr from hr_dept_ref where Dept_Cd in ('" & _
                    Session("deptlist").ToString.Replace(",", "','") & "') order by Descr", cmbDept)
                BuildCombo("select Section_Cd,Descr from hr_section_ref where Section_Cd in ('" & _
                    Session("sectionlist").ToString.Replace(",", "','") & "') order by Descr", cmbSection)
                BuildCombo("select Unit_Cd,Descr from hr_unit_ref where Unit_Cd in ('" & _
                    Session("unitlist").ToString.Replace(",", "','") & "') order by Descr", cmbUnit)
                cmbRC.Items.Add("All")
                cmbRC.SelectedValue = "All"
                cmbOfc.Items.Add("All")
                cmbOfc.SelectedValue = "All"
                cmbDiv.Items.Add("All")
                cmbDiv.SelectedValue = "All"
                cmbDept.Items.Add("All")
                cmbDept.SelectedValue = "All"
                cmbSection.Items.Add("All")
                cmbSection.SelectedValue = "All"
                cmbUnit.Items.Add("All")
                cmbUnit.SelectedValue = "All"
                Session("letter") = "A"

                Dim c As New sqlclient.sqlconnection(connStr)
                Dim cm As New sqlclient.sqlcommand
                Dim rs As sqlclient.sqldatareader

                c.Open()
                cm.Connection = c
                cm.CommandText = "select Days from py_pay_mode where Pay_Cd='SM'"
                rs = cm.ExecuteReader
                Session("dayslist") = ""
                If rs.Read Then
                    Session("dayslist") = rs("Days")
                End If
                rs.Close()
                c.Close()
                cm.Dispose()
                c.Dispose()
                GetPeriods()
            End If

        End With
    End Sub


    Protected Sub cmbMonth_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbMonth.SelectedIndexChanged
        GetPeriods()
    End Sub
    Private Sub GetPeriods()
        Dim vList() As String = Session("dayslist").ToString.Split(",")
        Dim vToCurr(2) As Integer
        Dim vToPrev(2) As Integer

        cmbPeriod.Items.Clear()
        vToCurr(0) = vList(1) - 1
        vToPrev(0) = vToCurr(0)
        If vToCurr(0) = 0 Then
            vToCurr(0) = MonthEND(cmbMonth.SelectedValue & "/1/" & Now.Year).Day
            vToPrev(0) = vToCurr(0)
        End If
        cmbPeriod.Items.Add(cmbMonth.SelectedValue & "/" & vList(0) & "-" & vToCurr(0) & "/" & Now.Year)
        vToCurr(1) = vList(0) - 1
        vToPrev(1) = vToCurr(1)
        If vToCurr(1) = 0 Then
            vToCurr(1) = MonthEND(cmbMonth.SelectedValue & "/1/" & Now.Year).Day
            vToPrev(1) = vToCurr(1)
        End If
        cmbPeriod.Items.Add(cmbMonth.SelectedValue & "/" & vList(1) & "-" & vToCurr(1) & "/" & Now.Year)

        'add previous year's data
        cmbPeriod.Items.Add(cmbMonth.SelectedValue & "/" & vList(0) & "-" & vToPrev(0) & "/" & Now.Year - 1)
        cmbPeriod.Items.Add(cmbMonth.SelectedValue & "/" & vList(1) & "-" & vToPrev(1) & "/" & Now.Year - 1)
    End Sub

    Protected Sub cmdReturn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.Click
        Server.Transfer("main.aspx")
    End Sub
End Class
