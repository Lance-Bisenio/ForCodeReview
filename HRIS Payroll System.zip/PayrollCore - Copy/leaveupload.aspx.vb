Imports denaro.fis
Partial Class leaveupload
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Public vDump As String = ""


    Protected Sub cmdUpload_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdUpload.Click
        Dim vFilename As String = Session.SessionID & "-leavecredits.csv"
        Try
            txtUpload.PostedFile.SaveAs(Server.MapPath(".") & "\downloads\" & vFilename)
            Session("filename") = vFilename
            DigestFile(vFilename)
        Catch ex As IO.IOException
            vScript = "alert('An error has occurred while trying to upload the file.');"
        End Try
        
    End Sub
    Private Sub DigestFile(ByVal vFilename As String)
        Dim sr As IO.StreamReader
        Dim vContent As String = ""
        Dim vLine() As String
        Dim i As Integer = 0
        Dim vItems() As String
        Dim iErrCount As Integer = 0
        Dim vOk As Boolean = True
        Dim c As New sqlclient.sqlconnection(connStr)
        Dim cm As New sqlclient.sqlcommand

        vScript = "alert('Successfully uploaded file.'); document.getElementById('divWait').style.visibility='hidden';"
        sr = IO.File.OpenText(Server.MapPath(".") & "\downloads\" & vFilename)
        vContent = sr.ReadToEnd
        sr.Close()

        vLine = vContent.Split(vbCrLf)

        'validate the files
        For i = 0 To UBound(vLine) - 1
            vItems = vLine(i).Split(",")
            vOk = vItems.Length = 6
            If Not vOk Then
                vScript = "alert('An error has occurred while trying to validate the file. Columns should contain " & _
                    " 6 columns. Correct your data and try again.'); document.getElementById('divWait').style.visibility='hidden';"
                Exit Sub
            End If
        Next

        If vOk Then
            'now dump it to page
            vDump = ""
            For i = 0 To UBound(vLine)
                vItems = vLine(i).Split(",")
                vDump += "<tr>" & _
                    "<td style='height: 21px; background-color: silver'>" & i + 1 & "</td>" & _
                    "<td style='height: 21px'>" & vItems(0) & "</td>" & _
                    "<td style='height: 21px'>" & vItems(1) & "</td>" & _
                    "<td style='height: 21px'>" & vItems(2) & "</td>" & _
                    "<td style='height: 21px'>" & vItems(3) & "</td>" & _
                    "<td style='height: 21px'>" & vItems(4) & "</td>" & _
                    "<td style='height: 21px'>" & vItems(5) & "</td></tr>"
            Next
        End If
    End Sub

    Protected Sub cmdValidate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdValidate.Click
        Dim vFilename As String = Session("filename")
        Dim sr As IO.StreamReader
        Dim vContent As String = ""
        Dim vLine() As String
        Dim i As Integer = 0
        Dim vItems() As String
        Dim iErrCount As Integer = 0
        Dim vOk As Boolean = True
        Dim c As New sqlclient.sqlconnection(connStr)
        Dim cm As New sqlclient.sqlcommand
        Dim rs As sqlclient.sqldatareader

        vScript = "alert('Successfully saved to database.'); document.getElementById('divWait').style.visibility='hidden';"
        sr = IO.File.OpenText(Server.MapPath(".") & "\downloads\" & vFilename)
        vContent = sr.ReadToEnd
        sr.Close()

        vLine = vContent.Split(vbCrLf)
        vDump = ""
        c.Open()
        cm.Connection = c
        For i = 0 To UBound(vLine)
            vItems = vLine(i).Split(",")

            vDump += "<tr>" & _
                "<td style='height: 21px; background-color: silver'>" & i + 1 & "</td>" & _
                "<td style='height: 21px'>" & vItems(0) & "</td>" & _
                "<td style='height: 21px'>" & vItems(1) & "</td>" & _
                "<td style='height: 21px'>" & vItems(2) & "</td>" & _
                "<td style='height: 21px'>" & vItems(3) & "</td>" & _
                "<td style='height: 21px'>" & vItems(4) & "</td>" & _
                "<td style='height: 21px'>" & vItems(5) & "</td></tr>"
            'check if existing
            cm.CommandText = "select 1 from py_emp_leave where Emp_Cd='" & vItems(0).Trim & _
                "' and Leave_Cd='" & vItems(2).Trim & "'"
            rs = cm.ExecuteReader
            If rs.HasRows Then
                cm.CommandText = "update py_emp_leave set LastUpdate='" & Now & "',Credit=" & Val(vItems(3).Trim) & _
                    ",Used=" & Val(vItems(4).Trim) & ",Balance=" & Val(vItems(5).Trim) & _
                    " where Emp_Cd='" & vItems(0).Trim & "' and Leave_Cd='" & vItems(2).Trim & "'"
            Else
                cm.CommandText = "insert into py_emp_leave (Emp_Cd,Leave_Cd,Credit,Used,Balance,LastUpdate) values ('" & _
                    vItems(0).Trim & "','" & vItems(2).Trim & "'," & Val(vItems(3).Trim) & "," & Val(vItems(4).Trim) & _
                    "," & Val(vItems(5).Trim) & ",'" & Now & "')"
            End If
            rs.Close()
            cm.ExecuteNonQuery()
        Next
        c.Close()
        cm.Dispose()
        c.Dispose()
    End Sub

    Protected Sub cmdReturn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.Click
        Session.RemoveAll()
        Server.Transfer("main.aspx")
    End Sub
End Class
