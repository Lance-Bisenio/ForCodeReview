Imports denaro.fis
Partial Class leavelist
    Inherits System.Web.UI.Page
    Public displaydata As String = ""
    Public vScript As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            vScript = "alert('Your login session has expired. Please re-login again.'); window.close();"
            Exit Sub
        End If

        If Session("filter") = "" Then
            vScript = "alert('You must first click the Refresh button before clicking the print button.'); window.close();"
            Exit Sub
        End If
        If Not IsPostBack Then
            DataRefresh()
        End If
    End Sub
    Private Sub DataRefresh()
        Dim markup As String = ""

        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cmRef As New SqlClient.SqlCommand
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim rsRef As SqlClient.SqlDataReader
        Dim vClass As String = "odd"

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            cmRef.Dispose()
            Exit Sub
        End Try

        cm.Connection = c
        cmRef.Connection = c

        Dim vFilter As String = Session("filter")
        markup = "<center><h3>Leave Prooflist<br />as of " & Format(Now, "MM/dd/yyyy") & "<br/>" & Session("vFilterHeader") & "</h3></center>"
        markup += "<table border='1' width='99%' align='center' style='border-collapse:collapse;'>"

        markup += "<tr class='titleBar'><th>Emp Id</th>" & _
            "<th>Employee Name</th>" & _
            "<th>Date Hired</th>" & _
            "<th>Leave Type</th>" & _
            "<th>Prev. Year Bal.</th>" & _
            "<th>Prev. Year Used</th>" & _
            "<th>Prev. Year End Bal.</th>" & _
            "<th>Expiry Date</th>" & _
            "<th>Credits (Days)</th>" & _
            "<th>Used (Days)</th>" & _
            "<th>Balance (Days)</th>" & _
            "<th>Last Update Date</th>" & _
            "<th>Last Transaction(Date Filed-Effectivity Date)</th></tr>"
        Dim cntr As Integer = 0
        Dim datestart As String = ""

        cmRef.CommandText = "select * from hr_dept_ref order by Descr "

        rsRef = cmRef.ExecuteReader
        Do While rsRef.Read

            cm.CommandText = "SELECT Emp_Cd, Emp_Lname,Emp_Fname,Start_Date FROM py_emp_master " & _
                vFilter & " and Start_Date is not null and DeptCd='" & rsRef("Dept_Cd") & "' order by Emp_Lname,Emp_Fname,Emp_Mname"
            rs = cm.ExecuteReader
            If rs.HasRows Then

                markup += "<tr class='activeBar'><td class='labelL' colspan='13'>" & rsRef("Descr") & "</td></tr>"

                Do While rs.Read
                    cntr += 1
                    'markup += "<tr><td colspan='5'><b>" & cntr & ".</b>&nbsp;" & GetName(rs("Emp_Cd")) & "</td></tr>"
                    If Session("vleavetype") <> "" Then
                        Select Case Session("vleavetype")
                            Case "VL"
                                'VL
                                markup += "<tr class='" & vClass & "'><td class='labelL'>" & rs("Emp_Cd") & "</td>" & _
                                    "<td class='labelL'>" & rs("Emp_Lname") & ", " & rs("Emp_Fname") & "</td>"
                                datestart = CDate(rs("Start_Date")).ToString("MM/dd/yyyy")
                                markup += GetLeaveUpdate(rs("Emp_Cd").ToString(), "VL", datestart, c) & "</tr>"
                            Case "SL"
                                'SL
                                markup += "<tr class='" & vClass & "'><td class='labelL'>" & rs("Emp_Cd") & "</td>" & _
                                          "<td class='labelL'>" & rs("Emp_Lname") & ", " & rs("Emp_Fname") & "</td>"
                                datestart = CDate(rs("Start_Date")).ToString("MM/dd/yyyy")
                                markup += GetLeaveUpdate(rs("Emp_Cd").ToString(), "SL", datestart, c) & "</tr>"
                            Case "EO"
                                'EO
                                markup += "<tr class='" & vClass & "'><td class='labelL'>" & rs("Emp_Cd") & "</td>" & _
                                          "<td class='labelL'>" & rs("Emp_Lname") & ", " & rs("Emp_Fname") & "</td>"
                                datestart = CDate(rs("Start_Date")).ToString("MM/dd/yyyy")
                                markup += GetLeaveUpdate(rs("Emp_Cd").ToString(), "EO", datestart, c) & "</tr>"
                        End Select
                    Else
                        ''Retain the original code
                        'VL
                        markup += "<tr class='" & vClass & "'><td class='labelL'>" & rs("Emp_Cd") & "</td>" & _
                            "<td class='labelL'>" & rs("Emp_Lname") & ", " & rs("Emp_Fname") & "</td>"
                        datestart = CDate(rs("Start_Date")).ToString("MM/dd/yyyy")
                        markup += GetLeaveUpdate(rs("Emp_Cd").ToString(), "VL", datestart, c) & "</tr>"

                        'SL
                        vClass = IIf(vClass = "odd", "even", "odd")
                        markup += "<tr class='" & vClass & "'><td class='labelL'>&nbsp;</td>" & _
                            "<td class='labelL'>&nbsp;</td>" & GetLeaveUpdate(rs("Emp_Cd").ToString(), "SL", datestart, c) & "</tr>"

                        'EO
                        vClass = IIf(vClass = "odd", "even", "odd")
                        markup += "<tr class='" & vClass & "'><td class='labelL'>&nbsp;</td>" & _
                            "<td class='labelL'>&nbsp;</td>" & GetLeaveUpdate(rs("Emp_Cd").ToString(), "EO", datestart, c) & "</tr>"
                    End If


                    '''''''Original Code''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                    ''VL
                    'markup += "<tr class='" & vClass & "'><td class='labelL'>" & rs("Emp_Cd") & "</td>" & _
                    '    "<td class='labelL'>" & rs("Emp_Lname") & ", " & rs("Emp_Fname") & "</td>"
                    'datestart = CDate(rs("Start_Date")).ToString("MM/dd/yyyy")
                    'markup += GetLeaveUpdate(rs("Emp_Cd").ToString(), "VL", datestart, c) & "</tr>"

                    ''SL
                    'vClass = IIf(vClass = "odd", "even", "odd")
                    'markup += "<tr class='" & vClass & "'><td class='labelL'>&nbsp;</td>" & _
                    '    "<td class='labelL'>&nbsp;</td>" & GetLeaveUpdate(rs("Emp_Cd").ToString(), "SL", datestart, c) & "</tr>"

                    ''EO
                    'vClass = IIf(vClass = "odd", "even", "odd")
                    'markup += "<tr class='" & vClass & "'><td class='labelL'>&nbsp;</td>" & _
                    '    "<td class='labelL'>&nbsp;</td>" & GetLeaveUpdate(rs("Emp_Cd").ToString(), "EO", datestart, c) & "</tr>"
                Loop
            End If
            rs.Close()
        Loop
        rsRef.Close()

        markup += "</table>"
        displaydata = markup
        c.Close()
        c.Dispose()
        cm.Dispose()
        cmRef.Dispose()
    End Sub
    Private Function GetLeaveUpdate(ByVal emp_cd As String, ByVal LeaveType As String, ByVal DateHired As String, ByRef c As SqlClient.SqlConnection) As String
        Dim markup As String = ""
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim vExpiry As String = ""
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                          ''
        '' DATE MODIFIED: 4/29/2013                              ''
        '' PURPOSE: TO TRAP IF THE LAST UDPATE DATE FIELD IS     ''
        ''          NULL OR NOT TO PREVENT FORMATTING ERROR.     ''
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        Dim vLastUpdate As String = ""
        ''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''

        cm.Connection = c
        cm.CommandText = "SELECT Credit, Balance, Used, LastUpdate,BalanceLastYear,UsedLastYear,ExpiryDate " & _
            "FROM py_emp_leave WHERE Emp_Cd='" & emp_cd & "' AND Leave_Cd='" & LeaveType & "'"

        Try
            rs = cm.ExecuteReader

            If rs.Read Then
                If Not IsDBNull(rs("ExpiryDate")) Then
                    vExpiry = Format(CDate(rs("ExpiryDate")), "MM/dd/yyyy")
                Else
                    vExpiry = "&nbsp;"
                End If
                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY:  VIC GATCHALIAN                         ''
                '' DATE MODIFIED: 4/29/2013                             ''
                '' PURPOSE: TO TRAP THE LAST UPDATE DATE FIELD TO       ''
                ''          PREVENT FORMATTING ERROR.                   ''
                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                ''''''''''''''''''' OLD CODE '''''''''''''''''''''''''''''
                'markup = "<td class='labelC'>" & DateHired & "</td>" & _
                '    "<td class='labelC'>" & LeaveType & "</td>" & _
                '    "<td class='labelR'>" & rs("BalanceLastYear") & "</td>" & _
                '    "<td class='labelR'>" & rs("UsedLastYear") & "</td>" & _
                '    "<td class='labelR'>" & rs("BalanceLastYear") - rs("UsedLastYear") & "</td>" & _
                '    "<td class='labelC'>" & vExpiry & "</td>" & _
                '    "<td class='labelR'>" & rs("Credit") & "</td>" & _
                '    "<td class='labelR'>" & rs("Used") & "</td>" & _
                '    "<td class='labelR'>" & rs("Balance") & "</td>" & _
                '    "<td class='labelC'>" & IIf(IsDBNull(rs("LastUpdate")), "", Format(rs("LastUpdate"), "MM/dd/yyyy")) & "</td>" & _
                '    "<td class='labelL'>" & GetRef("SELECT TOP 1 CAST(TranDate AS VARCHAR)+'-'+CAST(StartDate AS VARCHAR) FROM hr_leave_application WHERE Emp_Cd = '" & _
                '    emp_cd & "' AND LeaveCd='" & LeaveType & "' AND Paid=1 AND Void=0 AND DateApproved IS NOT NULL " & _
                '    "ORDER BY TranDate DESC", "&nbsp;", c) & "</td>"
                ''''''''''''''''''' END OLD CODE ''''''''''''''''''''''''''
                vLastUpdate = "&nbsp;"
                If Not IsDBNull(rs("LastUpdate")) Then
                    vLastUpdate = Format(rs("LastUpdate"), "MM/dd/yyyy")
                End If

                markup = "<td class='labelC'>" & DateHired & "</td>" & _
                    "<td class='labelC'>" & LeaveType & "</td>" & _
                    "<td class='labelR'>" & rs("BalanceLastYear") & "</td>" & _
                    "<td class='labelR'>" & rs("UsedLastYear") & "</td>" & _
                    "<td class='labelR'>" & rs("BalanceLastYear") - rs("UsedLastYear") & "</td>" & _
                    "<td class='labelC'>" & vExpiry & "</td>" & _
                    "<td class='labelR'>" & rs("Credit") & "</td>" & _
                    "<td class='labelR'>" & rs("Used") & "</td>" & _
                    "<td class='labelR'>" & rs("Balance") & "</td>" & _
                    "<td class='labelC'>" & vLastUpdate & "</td>" & _
                    "<td class='labelL'>" & GetRef("SELECT TOP 1 CAST(TranDate AS VARCHAR)+'-'+CAST(StartDate AS VARCHAR) FROM hr_leave_application WHERE Emp_Cd = '" & _
                    emp_cd & "' AND LeaveCd='" & LeaveType & "' AND Paid=1 AND Void=0 AND DateApproved IS NOT NULL " & _
                    "ORDER BY TranDate DESC", "&nbsp;", c) & "</td>"
                ''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''
            Else
                markup = "<td class='labelR'>" & DateHired & "</td><td class='labelL'>" & LeaveType & "</td><td colspan='9' class='labelL'>" & _
                    "No Leave Data found...</td>"
            End If
            rs.Close()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to retrieve leave balances. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            cm.Dispose()
        End Try
        Return markup
    End Function
End Class
