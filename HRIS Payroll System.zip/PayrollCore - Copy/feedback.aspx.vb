﻿Imports denaro.fis
Partial Class feedback
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Or Session("uid") = Nothing Then
            vScript = "alert('Your login session has expired. Please re-login again.'); window.close();"
            Exit Sub
        End If

        If Not IsPostBack Then
            Dim c As New SqlClient.SqlConnection(connStr)
            Dim cm As New SqlClient.SqlCommand
            Dim rs As SqlClient.SqlDataReader

            lblCaption.Text = "Post Reply"
            Try
                c.Open()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error has occurred while trying to connect to database. Error is: " & _
                    ex.Message.Replace("'", "").Replace(vbCrLf, "") & "');"
                c.Dispose()
                cm.Dispose()
                Exit Sub
            End Try

            cm.Connection = c

            txtCatgId.Text = Request.Item("c")
            txtId.Text = Request.Item("e")
            txtDate.Text = Request.Item("d")

            cm.CommandText = "select Descr from hr_feedback_category where CatgId='" & Request.Item("c") & "'"
            Try
                rs = cm.ExecuteReader
                If rs.Read Then
                    lblCatDescr.Text = rs("Descr")
                End If
                rs.Close()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to retrieve Feedback Category. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                c.Close()
                cm.Dispose()
                c.Dispose()
                Exit Sub
            End Try

            cm.CommandText = "select Emp_Lname,Emp_Fname from py_emp_master where Emp_Cd='" & Request.Item("e") & "'"
            Try
                rs = cm.ExecuteReader
                If rs.Read Then
                    txtName.Text = rs("Emp_Lname") & ", " & rs("Emp_Fname")
                End If
                rs.Close()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to retrieve Employee file. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                c.Close()
                cm.Dispose()
                c.Dispose()
                Exit Sub
            End Try

            cm.CommandText = "select Feedback from hr_feedback where Emp_Cd='" & txtId.Text & _
                "' and CatgId='" & txtCatgId.Text & "' and TranDate='" & Format(CDate(txtDate.Text), "yyyy/MM/dd HH:mm:ss") & "'"
            Try
                rs = cm.ExecuteReader
                If rs.Read Then
                    txtFeedback.Text = rs("Feedback")
                End If
                rs.Close()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to retrieve the message. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            Finally
                c.Close()
                cm.Dispose()
                c.Dispose()
            End Try
        End If
    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error has occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try
        cm.Connection = c
        cm.CommandText = "update hr_feedback set Replied='" & txtReply.Text.Replace("'", "''") & _
            "' where Emp_Cd='" & txtId.Text & _
            "' and CatgId='" & txtCatgId.Text & _
            "' and TranDate='" & Format(CDate(txtDate.Text), "yyyy/MM/dd HH:mm:ss") & "'"
        Try
            cm.ExecuteNonQuery()
            vScript = "alert('Reply was successfully saved.'); opener.location.reload(); window.close();"
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to save changes. Error is: " & ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            c.Dispose()
            cm.Dispose()
        End Try
    End Sub
End Class
