Imports denaro.fis
Partial Class processpayroll
    Inherits System.Web.UI.Page
    Public vReturn As String = ""
    Structure GenPayroll      'used in generation of payroll
        Public RC_CD As String
        Public Office As String
        Public DivCd As String
        Public DeptCd As String
        Public SectionCd As String
        Public UnitCd As String
        Public EmploymentType As String
        Public ReportNo As String
        Public EmpId As String
        Public Name As String
        Public Position As String
        Public TaxCd As String
        Public Status As String
        Public BankCd As String
        Public BankType As String
        Public DateResigned As Date
        Public PayCd As String
        Public From As Date
        Public vTo As Date
        Public MonthRate As Decimal
        Public NetAmount As Decimal
        Public ACA As Decimal
        Public RATA As Decimal
        Public PERA As Decimal
        Public Incentives() As Decimal
        Public TAX As Decimal
        Public SSSEmp As Decimal
        Public SSSEmr As Decimal
        Public PagIbigEmp As Decimal
        Public PagIbigEmr As Decimal
        Public MedicareEmp As Decimal
        Public MedicareEmr As Decimal
        Public GSISEmp As Decimal
        Public GSISEmr As Decimal
        Public StateIns As Decimal
        Public XtraHazard As Decimal
        Public Deduct() As Decimal
        Public NormalPay As Boolean
        Public OT As Decimal
        Public OTLegal As Decimal
        Public OTOff As Decimal
        Public OTNight As Decimal
        Public MealAllow As Decimal
        Public SeniorAllow As Decimal    '''' Added By: Rudner Diaz,Jr. 5-17-2012
        Public StartDate As Date         '''' Added By: Rudner Diaz,Jr. 5-17-2012

        'enhancements
        Public ETP As Decimal
        Public A1 As Decimal
        Public A2 As Decimal
        Public B1 As Decimal
        Public B2 As Decimal
        Public B3 As Decimal
        Public B4 As Decimal
        Public C1 As Decimal
        Public C2 As Decimal
        Public C3 As Decimal
        Public C4 As Decimal
        Public D1 As Decimal
        Public D2 As Decimal
        Public D3 As Decimal
        Public D4 As Decimal
        Public E1 As Decimal
        Public E2 As Decimal
        Public E3 As Decimal
        Public E4 As Decimal
        Public F1 As Decimal
        Public F2 As Decimal
        Public F3 As Decimal
        Public F4 As Decimal
        Public G1 As Decimal
        Public G2 As Decimal
        Public G3 As Decimal
        Public G4 As Decimal
        Public NDREG As Decimal
        Public ABSENT As Decimal
        Public BASICRATE As Decimal
        Public TARDINESS As Decimal
        Public UNIONDUES As Decimal
        Public GrossUp As Boolean   'added by vic gatchalian on 6/30/2012 -- to support gross up employees
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                     ''
        '' DATE MODIFIED: 7/3/2012                          ''
        '' PURPOSE: TO SUPPORT MULTI-CURRENCY COMPUTATION   ''
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''
        Public NonDeclaredBenefits() As Decimal
        Public NonDeclaredBenefitsCodes() As String
        Public NonDeclaredBenefitsTargetCurr() As String
        Public NonDeclaredBenefitsSrcCurr() As String
        Public SalaryCurr As String
        Public NetPayCurr As String
        Public AcaSrcCurr As String
        Public AcaTargetCurr As String
        Public RataSrcCurr As String
        Public RataTargetCurr As String
        Public PeraSrcCurr As String
        Public PeraTargetCurr As String
        Public MealSrcCurr As String
        Public MealTargetCurr As String
        Public TaxCurr As String
        Public SssCurr As String
        Public PagIBIGCurr As String
        Public PHICCurr As String
        Public UnionCurr As String
        Public SeniorCurr As String
        Public NotionalTax As Decimal
        Public FBTax As Decimal
        Public NotionalTaxAmount As Decimal
        Public FBTaxAmount As Decimal
        '''''''''''''' END OF MODIFICATION '''''''''''''''''''
    End Structure
    Dim vEmp As GenPayroll
    Dim vTaxGroup() As Decimal
    Dim vTotOthIncent As Decimal
    Dim vTaxableIncent As Decimal
    Dim vMonth As Decimal = 0

    Dim vIncentives() As String
    Dim vIncentiveTaxable() As Decimal
    
    Dim vStatement() As String
    'Dim vDist As Boolean = True
    Dim vDivisor As Decimal
    Dim vDivide As Decimal
    Dim vSQLString As String
    Dim vSQL As String
    Dim vSSSContr(2) As Decimal
    Dim vPagibigContr(2) As Decimal
    Dim vMedicareContr(2) As Decimal
    Dim vDays As Decimal
    Dim vFrom As Date
    Dim vTo As Date
    Dim vPayOut As Date
    Dim vId As String
    Dim vRegularPayroll As Boolean
    Dim vAnnualized As Boolean
    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''
    '' MODIFIED BY:  VIC GATCHALIAN                        ''
    '' DATE MODIFIED: 10/25/2011                           ''
    '' PURPOSE: TO ADD AN OPTION THAT WILL DETERMINE IF    ''
    ''          THE PAYROLL PROCESS WILL AUTO-COMPUTE THE  ''
    ''          ACA, RATA, PERA & MEAL OR NOT.             ''
    '' ''''''''''''''''''''''''''''''''''''''''''''''''''''''
    Dim vAutoComputeACARATAPERAMeal As Boolean
    '''''''''''''''''' END OF MODIFICATION ''''''''''''''''''

    Dim vSeniorTaxable As Boolean = False   ''''Added by: Rudner D. Diaz
    Dim vDistributionMode As Integer
    Dim vAcaProRata As Boolean = False
    Dim vRataProRata As Boolean = False
    Dim vPeraProRata As Boolean = False
    Dim vMealProRata As Boolean = False
    Dim vAcaTaxable As Boolean = False
    Dim vRataTaxable As Boolean = False
    Dim vPeraTaxable As Boolean = False
    Dim vMealTaxable As Boolean = False
    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''
    '' MODIFIED BY:  VIC GATCHALIAN                        ''
    '' DATE MODIFIED: 12/4/2012                            ''
    '' PURPOSE: TO GET IF ACA,RATA,PERA,MEAL WILL DEDUCT   ''
    ''          TARDY AND/OR UNDERTIME                     ''
    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''
    Dim vACADeductTardy As Boolean = False
    Dim vACADeductUT As Boolean = False
    Dim vRATADeductTardy As Boolean = False
    Dim vRATADeductUT As Boolean = False
    Dim vPERADeductTardy As Boolean = False
    Dim vPERADeductUT As Boolean = False
    Dim vMealDeductTardy As Boolean = False
    Dim vMealDeductUT As Boolean = False
    '''''''''''''' END OF MODIFICATION ''''''''''''''''''''''
    Dim vWithSC As Boolean = False
    Dim vHrsRendered As Decimal
    Dim vTardyHrs As Decimal
    Dim vUTHrs As Decimal
    Dim vAbsentHrs As Decimal
    Dim c As New SqlClient.SqlConnection(connStr)

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            vReturn = "expired"
            Exit Sub
        End If

        Const MaxIdx As Integer = 60
        Dim vOthIncent(MaxIdx) As Boolean
        Dim vOthLimit(MaxIdx) As Decimal
        Dim vOthIncentPerc(MaxIdx) As Decimal
        Dim vOthIncent2Basic(MaxIdx) As Boolean
        Dim vOthIncentCd(MaxIdx) As String
        Dim vOthIncentRecurr(MaxIdx) As Boolean
        Dim vOthIncentMode(MaxIdx) As Boolean
        Dim vOthIncentProRated(MaxIdx) As Boolean
        Dim vOthIncentDeductTardy(MaxIdx) As Boolean
        Dim vOthIncentDeductUT(MaxIdx) As Boolean
        Dim vOthDedCd(MaxIdx) As String

        Dim vFixedEmp As Decimal = 0
        Dim vFixedEmr As Decimal = 0
        Dim vTemp As Decimal
        Dim vTemp2 As Decimal
        Dim vEC As Decimal = 0
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                                   ''
        '' DATE MODIFIED: 2/5/2013                                        ''
        '' PURPOSE: TO ADD FIXED TAX AND COMPUTED TAX                     ''
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        Dim vTaxTmpAmt As Decimal = 0
        '''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''

        Dim vTotOthDed As Decimal

        Dim vSenior As Boolean   ''Added by Rudner on 5-16-2012
        Dim vRATA As Boolean
        Dim vACA As Boolean
        Dim vPERA As Boolean
        Dim vMeal As Boolean
        Dim vState As Boolean
        Dim vPagIBIG As Boolean
        Dim vOptional As Boolean
        Dim vGSIS As Boolean
        Dim vSSS As Boolean
        Dim vMedicare As Boolean
        Dim SSSGrossBasis As Boolean = True
        Dim PagIbigGrossBasis As Boolean = True
        Dim PhicGrossBasis As Boolean = True
        Dim vEligibleDays As Decimal = 0
        Dim vTax As Boolean
        Dim vOthDedDist As Boolean
        Dim vName As String
        Dim vMName As String
        Dim vPosition As String
        Dim vCasualCd As String
        Dim vECOLA As Decimal = 0       'supports E-COLA transactions for fastrak use only. modified by vic on 9/26/2011
        Dim vGross As Decimal
        Dim vBasic As Decimal
        Dim vDaysWorked As Decimal = 0
        Dim vDeminimis As Decimal = 0
        Dim vRateHr As Decimal
        Dim vRateDay As Decimal
        Dim vXtra As Decimal
        Dim iCtr As Integer
        Dim iEmp As Integer = 0
        Dim iHoliday As Integer = 0
        Dim vMonthGross As Decimal
        Dim vOT As Decimal
        Dim vTardiness As Decimal
        Dim vUndertime As Decimal
        Dim vAbsents As Decimal
        
        Dim vHrsDay As Decimal
        Dim vTmpGross As Decimal = 0
        Dim vDeduction As Decimal
        Dim vTotalRecords As Integer = 0

        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                                     ''
        '' DATE MODIFIED:  1/18/2012                                        ''
        '' PURPOSE:  TO SUPPORT CUSTOM DEDUCTION FREQUENCY FOR EACH EMPLOYEE''
        ''           FOR TAX, SSS, PAGIBIG AND PHIC                         ''
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        Dim vTaxFreq As Integer = -1
        Dim vSSSFreq As Integer = -1
        Dim vPagIBIGFreq As Integer = -1
        Dim vPHICFreq As Integer = -1
        ''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''''''


        Dim cm As New SqlClient.SqlCommand
        Dim cmRef As New SqlClient.SqlCommand
        Dim dr As SqlClient.SqlDataReader
        Dim drRef As SqlClient.SqlDataReader
        'Dim rs_loan As SqlClient.SqlDataReader
        'Dim cm_loan As New SqlClient.SqlCommand

        vFrom = CDate(Request.Form("s"))
        vTo = CDate(Request.Form("e"))
        vPayOut = CDate(Request.Form("p"))
        vId = Request.Form("id")
        vRegularPayroll = Val(Request.Form("m")) = 1
        vAnnualized = Val(Request.Form("a")) = 1
        vDistributionMode = Val(Request.Form("d"))
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                        ''
        '' DATE MODIFIED: 10/25/2011                           ''
        '' PURPOSE: TO ADD AN OPTION THAT WILL DETERMINE IF    ''
        ''          THE PAYROLL PROCESS WILL AUTO-COMPUTE THE  ''
        ''          ACA, RATA, PERA & MEAL OR NOT.             ''
        '' ''''''''''''''''''''''''''''''''''''''''''''''''''''''
        vAutoComputeACARATAPERAMeal = Val(Request.Form("meal"))
        '''''''''''''''''' END OF MODIFICATION ''''''''''''''''''

        
        'open connection
        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vReturn = ex.Message.Replace("'", "").Replace(vbCrLf, "\n")
            c.Dispose()
            cm.Dispose()
            cmRef.Dispose()
            'cm_loan.Dispose()
            Exit Sub
        End Try

        'configure and group the taxable icentives
        'get list of groups
        cmRef.Connection = c
        cm.Connection = c
        'cm_loan.Connection = c

        cm.CommandText = "select count(distinct MaxtaxExempt) from py_other_incentvs where Taxable <> 0 and " & _
           "MaxTaxExempt is not null and Grouped <> 0"
        dr = cm.ExecuteReader
        dr.Read()
        vTotalRecords = IIf(IsDBNull(dr(0)), 0, dr(0))
        dr.Close()
        If vTotalRecords > 0 Then
            cm.CommandText = "select distinct MaxTaxExempt from py_other_incentvs where Taxable <> 0 and " & _
                "MaxTaxExempt is not null and Grouped <> 0"
            dr = cm.ExecuteReader

            ReDim vTaxGroup(vTotalRecords - 1)
            ReDim vIncentives(vTotalRecords - 1)
            ReDim vIncentiveTaxable(vTotalRecords - 1)
            ReDim vStatement(vTotalRecords - 1)

            iCtr = 0
            Do While dr.Read
                vTaxGroup(iCtr) = dr("MaxTaxExempt")
                iCtr += 1
            Loop
            dr.Close()
            'ASSIGN LIST OF INCENTIVES FOR EACH GROUP
            For iCtr = 0 To UBound(vTaxGroup)
                cm.CommandText = "select Incentive_Cd from py_other_incentvs where Taxable <> 0 and Grouped <> 0 " & _
                   "and MaxTaxExempt=" & vTaxGroup(iCtr) & " order by Incentive_Cd"
                dr = cm.ExecuteReader
                vIncentives(iCtr) = ""
                Do While dr.Read
                    vIncentives(iCtr) += dr("Incentive_Cd") & ","
                Loop
                dr.Close()
                If vIncentives(iCtr) <> "" Then vIncentives(iCtr) = Mid(vIncentives(iCtr), 1, Len(vIncentives(iCtr)) - 1)
            Next iCtr
        Else
            ReDim vTaxGroup(0)
            ReDim vIncentives(0)
            ReDim vStatement(0)
            ReDim vIncentiveTaxable(0)
        End If

        iCtr = 0

        'get system parameters
        cm.CommandText = "select * from py_syscntrl"
        dr = cm.ExecuteReader
        dr.Read()
        vDays = IIf(IsDBNull(dr("Dates_To_Month")), 0, dr("Dates_To_Month"))
        vCasualCd = IIf(IsDBNull(dr("Casual_Cd")), "", dr("Casual_Cd"))
        vHrsDay = IIf(IsDBNull(dr("Hrs_Day")), 8, dr("Hrs_Day"))
        'vDist = dr("DistEvenly")
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        vSenior = Val(IIf(IsDBNull(dr("Senior_Deduct_Day")), 0, dr("Senior_Deduct_Day"))) = 0 Or _
            Val(Session("index")) = Val(IIf(IsDBNull(dr("Senior_Deduct_Day")), 0, dr("Senior_Deduct_Day")))
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        vACA = Val(IIf(IsDBNull(dr("Aca_Deduct_Day")), 0, dr("Aca_Deduct_Day"))) = 0 Or _
            Val(Session("index")) = Val(IIf(IsDBNull(dr("Aca_Deduct_Day")), 0, dr("Aca_Deduct_Day")))
        vPERA = Val(IIf(IsDBNull(dr("Pera_Deduct_Day")), 0, dr("Pera_Deduct_Day"))) = 0 _
            Or Val(Session("index")) = Val(IIf(IsDBNull(dr("Pera_Deduct_Day")), 0, dr("Pera_Deduct_Day")))
        vRATA = Val(IIf(IsDBNull(dr("Rata_Deduct_Day")), 0, dr("Rata_Deduct_Day"))) = 0 _
            Or Val(Session("index")) = Val(IIf(IsDBNull(dr("Rata_Deduct_Day")), 0, dr("Rata_Deduct_Day")))
        vMeal = Val(IIf(IsDBNull(dr("Meal_Deduct_Day")), 0, dr("Meal_Deduct_Day"))) = 0 _
            Or Val(Session("index")) = Val(IIf(IsDBNull(dr("Meal_Deduct_Day")), 0, dr("Meal_Deduct_Day")))
        vState = Val(IIf(IsDBNull(dr("State_Deduct_Day")), 0, dr("State_Deduct_Day"))) = 0 _
            Or Val(Session("index")) = Val(IIf(IsDBNull(dr("State_Deduct_Day")), 0, dr("State_Deduct_Day")))
        vPagIBIG = Val(IIf(IsDBNull(dr("Pag_Deduct_Day")), 0, dr("Pag_Deduct_Day"))) = 0 _
            Or Val(Session("index")) = Val(IIf(IsDBNull(dr("Pag_Deduct_Day")), 0, dr("Pag_Deduct_Day")))
        vOptional = Val(IIf(IsDBNull(dr("Opt_Deduct_Day")), 0, dr("Opt_Deduct_Day"))) = 0 _
            Or Val(Session("index")) = Val(IIf(IsDBNull(dr("Opt_Deduct_Day")), 0, dr("Opt_Deduct_Day")))
        vGSIS = Val(IIf(IsDBNull(dr("Gsis_Deduct_Day")), 0, dr("Gsis_Deduct_Day"))) = 0 _
            Or Val(Session("index")) = Val(IIf(IsDBNull(dr("Gsis_Deduct_Day")), 0, dr("Gsis_Deduct_Day")))
        vSSS = Val(IIf(IsDBNull(dr("Sss_Deduct_Day")), 0, dr("Sss_Deduct_Day"))) = 0 _
            Or Val(Session("index")) = Val(IIf(IsDBNull(dr("Sss_Deduct_Day")), 0, dr("Sss_Deduct_Day")))
        vMedicare = Val(IIf(IsDBNull(dr("Med_Deduct_Day")), 0, dr("Med_Deduct_Day"))) = 0 _
            Or Val(Session("index")) = Val(IIf(IsDBNull(dr("Med_Deduct_Day")), 0, dr("Med_Deduct_Day")))
        vTax = Val(IIf(IsDBNull(dr("Tax_Deduct_Day")), 0, dr("Tax_Deduct_Day"))) = 0 _
            Or Val(Session("index")) = Val(IIf(IsDBNull(dr("Tax_Deduct_Day")), 0, dr("Tax_Deduct_Day")))

        SSSGrossBasis = dr("Sss_Gross_Basis")
        PagIbigGrossBasis = dr("PagIbig_Gross_Basis")
        PhicGrossBasis = dr("Phic_Gross_Basis")
        vDivisor = Session("divisor")
        vAcaTaxable = dr("Aca_Taxable") = 1
        vRataTaxable = dr("Rata_Taxable") = 1
        vPeraTaxable = dr("Pera_Taxable") = 1
        vMealTaxable = dr("Meal_Taxable") = 1
        vAcaProRata = dr("Aca_ProRata") = 1
        vRataProRata = dr("Rata_ProRata") = 1
        vPeraProRata = dr("Pera_ProRata") = 1
        vMealProRata = dr("Meal_ProRata") = 1

        vSeniorTaxable = dr("SeniorAllowTaxable") = 1  ''''Added by Rudner D. Diaz

        If vDivisor = 0 Then vDivisor = 1
        vDivide = vDivisor
        Dim vACADivisor As Integer = IIf(dr("Aca_Deduct_Day") = 0, vDivisor, 1)
        Dim vPERADivisor As Integer = IIf(dr("Pera_Deduct_Day") = 0, vDivisor, 1)
        Dim vRATADivisor As Integer = IIf(dr("Rata_Deduct_Day") = 0, vDivisor, 1)
        Dim vMealDivisor As Integer = IIf(dr("Meal_Deduct_Day") = 0, vDivisor, 1)
        Dim vStateDivisor As Integer = IIf(dr("State_Deduct_Day") = 0, vDivisor, 1)
        Dim vPagIBIGDivisor As Integer = IIf(dr("Pag_Deduct_Day") = 0, vDivisor, 1)
        Dim vOptionalDivisor As Integer = IIf(dr("Opt_Deduct_Day") = 0, vDivisor, 1)
        Dim vGSISDivisor As Integer = IIf(dr("Gsis_Deduct_Day") = 0, vDivisor, 1)
        Dim vSSSDivisor As Integer = IIf(dr("Sss_Deduct_Day") = 0, vDivisor, 1)
        Dim vMedicareDivisor As Integer = IIf(dr("Med_Deduct_day") = 0, vDivisor, 1)

        For iCtr = 1 To MaxIdx
            vOthIncentCd(iCtr) = ""
            vOthIncentProRated(iCtr) = False
            vOthIncentDeductTardy(iCtr) = False
            vOthIncentDeductUT(iCtr) = False
            If Not IsDBNull(dr("OthIncent" & iCtr & "Cd")) Then
                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY:  VIC GATCHALIAN                                 ''
                '' DATE MODIFIED: 3/7/2012                                      ''
                '' PURPOSE: TO EMBED ON THE LIST OF INCENTIVES WHEN MODE IS     ''
                ''          SPECIAL PAYROLL IN ORDER TO ISOLATE RECURRING       ''
                ''          INCENTIVES ON SPECIAL PAYROLL                       ''
                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                ''''''''''''''''  OLD CODE '''''''''''''''''''''''''''''''''''''''
                'cmRef.CommandText = "select * from py_other_incentvs where Incentive_Cd='" & _
                '   dr("OthIncent" & iCtr & "Cd") & "' and SpecialPayroll=" & IIf(vRegularPayroll, 0, 1)
                '''''''''''''''' END OLD CODE ''''''''''''''''''''''''''''''''''''
                If vRegularPayroll Then
                    cmRef.CommandText = "select * from py_other_incentvs where Incentive_Cd='" & _
                        dr("OthIncent" & iCtr & "Cd") & "' and SpecialPayroll=0"
                Else
                    cmRef.CommandText = "select * from py_other_incentvs where Incentive_Cd='" & _
                        dr("OthIncent" & iCtr & "Cd") & "' and SpecialPayroll=1 and Incentive_Cd in ('" & _
                        Request.Form("incent").ToString.Replace(",", "','") & "')"
                End If
                ''''''''''''''''''' END OF MODIFICATION  '''''''''''''''''''''''''

                drRef = cmRef.ExecuteReader
                If drRef.Read Then
                    vOthIncentMode(iCtr) = drRef("SpecialPayroll") = 0
                    vOthIncent(iCtr) = drRef("Taxable")
                    vOthIncent2Basic(iCtr) = drRef("Include2BasicPay") = 1
                    vOthIncentRecurr(iCtr) = 0
                    vOthIncentPerc(iCtr) = drRef("Percentage")
                    vOthIncentProRated(iCtr) = drRef("ProRated") = 1
                    vOthIncentDeductTardy(iCtr) = drRef("DeductTardy") = 1
                    vOthIncentDeductUT(iCtr) = drRef("DeductUT") = 1
                    vOthLimit(iCtr) = IIf(IsDBNull(drRef("MaxTaxExempt")), _
                       0, drRef("MaxTaxExempt"))
                    vOthIncentCd(iCtr) = dr("OthIncent" & iCtr & "Cd")
                    vSQLString = vSQLString & "Other_Incent" & iCtr
                Else
                    vOthIncentCd(iCtr) = ""
                End If
                drRef.Close() 'PY_OTHER_INCENTVS
            End If

            '''''''''''''''' OTHER DEDUCTIONS  ''''''''''''''''''''''''''''
            If Not IsDBNull(dr("OthDed" & iCtr & "Cd")) Then
                vOthDedCd(iCtr) = dr("OthDed" & iCtr & "Cd")
            End If
        Next iCtr
        dr.Close() 'pysyscntrl

        cm.CommandText = "select * from py_emp_master where Emp_Cd='" & vId & "'"
        dr = cm.ExecuteReader
        If dr.Read Then
            iEmp += 1
            'get employee name
            vMName = IIf(IsDBNull(dr("Emp_Mname")), "", dr("Emp_Mname"))
            If vMName <> "" Then
                vMName = Mid(vMName, 1, 1) & "."
            End If
            vName = IIf(IsDBNull(dr("Emp_Lname")), "", dr("Emp_Lname") & ", ") & _
               IIf(IsDBNull(dr("Emp_Fname")), "", dr("Emp_Fname") & " ") & vMName
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:  VIC GATCHALIAN                                    ''
            '' DATE MODIFIED: 6/30/2012                                        ''
            '' PURPOSE: TO SUPPORT EMPLOYEES WITH GROSS-UP FEATURE             ''
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            vEmp.GrossUp = dr("IsNetAmt") = 1
            '''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''''

            '''''''''''''''''''''''''''''''''''''''''''
            '''' MODIFIED BY: VIC GATCHALIAN          '
            '''' DATE MODIFIED: 10/5/2011             '
            '''' PURPOSE: TO DETERMINE IF THE EMPLOYEE'
            ''''     IS A MEMBER FOR SERVICE CHARGE   '
            ''''     OR NOT. IF NOT A MEMBER OF SC,   '
            ''''     THE EMPLOYEE'S ACCRUED INCOME ON '
            ''''     SC IS NOT COUNTED IN CALCULATING '
            ''''     THE ANNUALIZED TAX COMPUTATION   '
            '''''''''''''''''''''''''''''''''''''''''''
            If Not IsDBNull(dr("SCMember")) Then
                vWithSC = dr("ScMember") = 1
            End If
            ''''''''' END OF MODIFICATIONS ''''''''''''

            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:  VIC GATCHALIAN                           ''
            '' DATE MODIFIED:  1/18/2012                              ''
            '' PURPOSE: TO SUPERCEDE THE SYSTEM DEFAULT WHEN THERE    ''
            ''          IS A CUSTOM FREQUENCY SETTING FOR THE EMPLOYEE''
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            If dr("TaxFreq") <> -1 Then 'use custom settings, determine new frequency
                If dr("TaxFreq") = 0 Then
                    vTax = True
                Else
                    'session("Index") may contain values 1=first cut off, or 2=second cut off
                    vTax = dr("TaxFreq") = Val(Session("index"))
                End If
            End If
            If dr("SSSFreq") <> -1 Then 'use custom settings, determine new frequency
                If dr("SSSFreq") = 0 Then
                    vSSS = True
                Else
                    'session("Index") may contain values 1=first cut off, or 2=second cut off
                    vSSS = dr("SSSFreq") = Val(Session("index"))
                End If
            End If
            If dr("PagIBIGFreq") <> -1 Then   'use custom settings, determine new frequency
                If dr("PagIBIGFreq") = 0 Then
                    vPagIBIG = True
                Else
                    'session("Index") may contain values 1=first cut off, or 2=second cut off
                    vPagIBIG = dr("PagIBIGFreq") = Val(Session("index"))
                End If
            End If
            If dr("PHICFreq") <> -1 Then    'use custom settings, determine new frequency
                If dr("PHICFreq") = 0 Then
                    vMedicare = True
                Else
                    'session("Index") may contain values 1=first cut off, or 2=second cut off
                    vMedicare = dr("PHICFreq") = Val(Session("index"))
                End If
            End If
            ''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''

            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:  VIC GATCHALIAN                           ''
            '' DATE MODIFIED: 7/3/2012                                ''
            '' PURPOSE: TO SUPPORT MULTI-CURRENCY                     ''
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            vEmp.SalaryCurr = dr("SalarySrcCurrCd")
            vEmp.NetPayCurr = dr("SalaryTargetCurrCd")
            vEmp.AcaSrcCurr = dr("AcaSrcCurrCd")
            vEmp.AcaTargetCurr = dr("AcaTargetCurrCd")
            vEmp.RataSrcCurr = dr("RataSrcCurrCd")
            vEmp.RataTargetCurr = dr("RataTargetCurrCd")
            vEmp.PeraSrcCurr = dr("PeraSrcCurrCd")
            vEmp.PeraTargetCurr = dr("PeraTargetCurrCd")
            vEmp.MealSrcCurr = dr("MealSrcCurrCd")
            vEmp.MealTargetCurr = dr("MealTargetCurrCd")
            vEmp.TaxCurr = dr("TaxCurrCd")
            vEmp.SssCurr = dr("SssCurrCd")
            vEmp.PagIBIGCurr = dr("PagIBIGCurrcd")
            vEmp.PHICCurr = dr("PHICCurrCd")
            vEmp.UnionCurr = dr("UnionDuesCurrCd")
            vEmp.SeniorCurr = dr("SeniorAllowTargetCurrCd")
            '''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''

            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '''''  Added By :   Rudner D. Diaz, Jr.                                       ''''
            '''''  Date     :   July 7, 2012                                              ''''
            '''''  Reason   :   To support the Gross up type of employee                  ''''
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            vEmp.NotionalTax = dr("NotationalTax")
            vEmp.FBTax = dr("FringeBenifitTax")
            '''''''''''''''END of ADDITION''''''''''''''''''''''''''''''''''''''''''''''''''''

            vEmp.DateResigned = IIf(IsDBNull(dr("Date_Resign")), Nothing, dr("Date_Resign"))
            vEmp.BankCd = IIf(IsDBNull(dr("Bank_Code")), "", dr("Bank_Code"))
            vEmp.BankType = IIf(IsDBNull(dr("Bank_Type")), "SA", dr("Bank_Type"))
            'get position
            vXtra = 0
            vPosition = "Unknown"
            If Not IsDBNull(dr("Pos_Cd")) Then
                cmRef.CommandText = "select Position, Govt_Share from py_position_ref where Pos_Cd='" & _
                   dr("Pos_Cd") & "'"
                drRef = cmRef.ExecuteReader
                If drRef.Read Then
                    vPosition = IIf(IsDBNull(drRef("Position")), "Unknown", drRef("Position"))
                    vXtra = IIf(IsDBNull(drRef("Govt_Share")), 0, drRef("Govt_Share"))
                End If
                drRef.Close() 'PY_POSITION_REF
            End If

            vRateHr = Math.Round(IIf(IsDBNull(dr("Rate_Day")), 0, dr("Rate_Day")) / _
               IIf(IsDBNull(dr("Req_Hrs_Day")), vHrsDay, dr("Req_Hrs_Day")), 2)
            vRateDay = Math.Round(IIf(IsDBNull(dr("Rate_Day")), 0, dr("Rate_Day")), 2)

            'get calculated values
            vAbsents = 0
            vMonth = 0
            vBasic = 0
            vOT = 0
            vEmp.ACA = 0
            vEmp.RATA = 0
            vEmp.PERA = 0
            vEmp.MealAllow = 0

            If vRegularPayroll Then  'normalpayroll
                vEligibleDays = 1
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY:  VIC GATCHALIAN                        ''
                '' DATE MODIFIED: 10/25/2011                           ''
                '' PURPOSE: TO ADD AN OPTION THAT WILL DETERMINE IF    ''
                ''          THE PAYROLL PROCESS WILL AUTO-COMPUTE THE  ''
                ''          ACA, RATA, PERA & MEAL OR NOT.             ''
                '' ''''''''''''''''''''''''''''''''''''''''''''''''''''''
                If vAutoComputeACARATAPERAMeal Then
                    'get allowances
                    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                    '' MODIFIED BY:  VIC GATCHALIAN                                         ''
                    '' DATE MODIFIED: /3/16/2013                                            ''
                    '' PURPOSE: TO MOVE THE CODE PARCEL AFTER THE COMPUTATION OF ELIGIBILITY''
                    ''          DAYS SO THAT PROPER COMPUTATION OF ACA SHALL BE GIVEN FOR   ''
                    ''          DAILY AND NON-DAILY PAID EMPLOYEES.                         ''
                    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                    ''''''''''''''''''''''' OLD CODE '''''''''''''''''''''''''''''''''''''''''
                    'If vRATA Then vEmp.RATA = Math.Round(IIf(IsDBNull(dr("Rata")), 0, dr("Rata")) / vRATADivisor, 2)
                    'If vACA Then vEmp.ACA = Math.Round(IIf(IsDBNull(dr("Aca")), 0, dr("Aca")) / vACADivisor, 2)
                    'If vPERA Then vEmp.PERA = Math.Round(IIf(IsDBNull(dr("Pera")), 0, dr("Pera")) / vPERADivisor, 2)
                    'If vMeal Then vEmp.MealAllow = Math.Round(IIf(IsDBNull(dr("MealAllow")), 0, dr("MealAllow")) / vMealDivisor, 2)
                    '''''''''''''''''''''''' END OLD CODE '''''''''''''''''''''''''''''''''''''

                    If vAcaProRata Or vRataProRata Or vPeraProRata Or vMealProRata Then 'get the number of eligible days
                        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                        '' MODIFIED BY:  VIC GATCHALIAN                                             ''
                        '' DATE MODIFIED: 12/4/2012                                                 ''
                        '' PURPOSE: TO COMPUTE THE PRO-RATED VALUE OF THE ACA,RATA,PERA OR MEAL     ''
                        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                        ''''''''''''''''''''''' OLD CODE '''''''''''''''''''''''''''''''''''''''''''''
                        ''count total number of work schedule for the period
                        'cmRef.CommandText = "select count(*) from py_time_log where Sched_In is not null and Tran_Date between '" & _
                        '    Format(vFrom, "yyyy/MM/dd") & "' and '" & Format(vTo, "yyyy/MM/dd") & _
                        '    "' and Emp_Cd='" & vId & "'"
                        'drRef = cmRef.ExecuteReader
                        'If drRef.Read Then
                        '    If Not IsDBNull(drRef(0)) Then
                        '        vEligibleDays = drRef(0)
                        '    End If
                        'End If
                        'drRef.Close()
                        ''subtract absences, tardiness, and undertime
                        ''cmRef.CommandText = "select count(*) from py_time_log_dtl where Emp_Cd='" & vId & _
                        ''   "' and TranDate between '" & Format(vFrom, "yyyy/MM/dd") & _
                        ''   "' and '" & Format(vTo, "yyyy/MM/dd") & _
                        ''   "' and TranCd not in ('A1','A2','A3','A4','B1','B2','B3','B4','C1','C2','C3','C4'," & _
                        ''   "'D1','D2','D3','D4','E1','E2','E3','E4','F1','F2','F3','F4','G1','G2','G3','G4','TARD')"

                        ''cmRef.CommandText = "select count(*) from py_emp_time_log where Emp_Cd='" & vId & _
                        ''   "' and TranDate between '" & Format(vFrom, "yyyy/MM/dd") & _
                        ''   "' and '" & Format(vTo, "yyyy/MM/dd") & _
                        ''   "' and TranCd not in ('A1','A2','A3','A4','B1','B2','B3','B4','C1','C2','C3','C4'," & _
                        ''   "'D1','D2','D3','D4','E1','E2','E3','E4','F1','F2','F3','F4','G1','G2','G3','G4','TARD','BASIC')"
                        ''count undertime
                        'cmRef.CommandText = "select count(*) from py_time_log_dtl where Emp_Cd='" & vId & _
                        '   "' and TranDate between '" & Format(vFrom, "yyyy/MM/dd") & _
                        '   "' and '" & Format(vTo, "yyyy/MM/dd") & _
                        '   "' and TranCd ='UT'"

                        'drRef = cmRef.ExecuteReader
                        'If drRef.Read Then
                        '    If Not IsDBNull(drRef(0)) Then
                        '        vEligibleDays = vEligibleDays - drRef(0)
                        '    End If
                        'End If
                        'drRef.Close()

                        ''count leaves
                        'cmRef.CommandText = "select count(*) from py_time_log_dtl where Emp_Cd='" & vId & _
                        '   "' and TranDate between '" & Format(vFrom, "yyyy/MM/dd") & _
                        '   "' and '" & Format(vTo, "yyyy/MM/dd") & _
                        '   "' and TranCd in (select Leave_Cd from py_leave_ref where AlwaysPaid=0)"
                        'drRef = cmRef.ExecuteReader
                        'If drRef.Read Then
                        '    If Not IsDBNull(drRef(0)) Then
                        '        vEligibleDays = vEligibleDays - drRef(0)
                        '    End If
                        'End If
                        'drRef.Close()

                        ''count absences
                        'cmRef.CommandText = "select sum(Hrs_Rendered) from py_time_log_dtl where Emp_Cd='" & vId & _
                        '   "' and TranDate between '" & Format(vFrom, "yyyy/MM/dd") & _
                        '   "' and '" & Format(vTo, "yyyy/MM/dd") & _
                        '   "' and TranCd='ABSENT'"
                        'drRef = cmRef.ExecuteReader
                        'If drRef.Read Then
                        '    If Not IsDBNull(drRef(0)) Then
                        '        vEligibleDays = vEligibleDays - Math.Ceiling(drRef(0) / 8)
                        '    End If
                        'End If
                        'drRef.Close()
                        ''''''''''''''''''''''''' END OLD CODE '''''''''''''''''''''''''''''''''''''''''''
                        vEligibleDays = 0   'USE THIS VARIABLE TO COUNT THE HOURS TO BE DEDUCTED INSTEAD

                        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                        '' MODIFIED BY:  VIC GATCHALIAN                                                ''
                        '' DATE MODIFIED: 3/16/2013                                                    ''
                        '' PURPOSE: TO GET THE NUMBER OF ELIGIBLE DAYS OF THE EMPLOYEE IF HE IS DAILY  ''
                        ''          PAID. OTHERWISE USE THE STANDARD MONTHLY RATE ALLOWANCE / DIVISOR  ''
                        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                        If dr("DailyPaid") = 1 Or vEmp.DateResigned <> Nothing Then         'daily paid or paid by piece
                            cmRef.CommandText = "select sum(Hrs_Rendered) from py_emp_time_log where Emp_Cd='" & _
                            dr("Emp_Cd") & "' and TranDate between '" & Format(vFrom, "yyyy/MM/dd") & _
                            "' and '" & Format(vTo, "yyyy/MM/dd") & _
                            "' AND TRANCD='BASIC' and Frozen=0"

                            vDaysWorked = 0
                            Try
                                drRef = cmRef.ExecuteReader
                                If drRef.Read Then
                                    If Not IsDBNull(drRef(0)) Then
                                        vEligibleDays = drRef(0)
                                    End If
                                End If
                                drRef.Close()
                            Catch ex As SqlClient.SqlException
                                vReturn = ex.Message.Replace(vbCrLf, "\n").Replace("'", "")
                            End Try
                        End If
                        ''''''''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''''''''''

                        Dim vTardyHrs As Decimal = 0
                        Dim vUTHrs As Decimal = 0

                        'count tardiness
                        cmRef.CommandText = "select sum(hrs_rendered) from py_emp_time_log where Emp_Cd='" & vId & _
                           "' and TranDate between '" & Format(vFrom, "yyyy/MM/dd") & _
                           "' and '" & Format(vTo, "yyyy/MM/dd") & _
                           "' and TranCd ='TARD'"

                        drRef = cmRef.ExecuteReader
                        If drRef.Read Then
                            If Not IsDBNull(drRef(0)) Then
                                vTardyHrs = drRef(0)
                            End If
                        End If
                        drRef.Close()

                        'count undertime
                        cmRef.CommandText = "select sum(hrs_rendered) from py_emp_time_log where Emp_Cd='" & vId & _
                           "' and TranDate between '" & Format(vFrom, "yyyy/MM/dd") & _
                           "' and '" & Format(vTo, "yyyy/MM/dd") & _
                           "' and TranCd ='UT'"

                        drRef = cmRef.ExecuteReader
                        If drRef.Read Then
                            If Not IsDBNull(drRef(0)) Then
                                vUTHrs = drRef(0)
                            End If
                        End If
                        drRef.Close()

                        'count absences
                        cmRef.CommandText = "select sum(Hrs_Rendered) from py_emp_time_log where Emp_Cd='" & vId & _
                           "' and TranDate between '" & Format(vFrom, "yyyy/MM/dd") & _
                           "' and '" & Format(vTo, "yyyy/MM/dd") & _
                           "' and TranCd='ABSENT'"
                        drRef = cmRef.ExecuteReader
                        If drRef.Read Then
                            If Not IsDBNull(drRef(0)) Then
                                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                                '' MODIFIED BY:  VIC GATCHALIAN                         ''
                                '' DATE MODIFIED: 3/16/2013                             ''
                                '' PURPOSE: TO DEDUCT THE COMPUTED ABSECNES FROM THE    ''
                                ''          COMPUTED ELIGIBLE DAYS IF THE EMPLOYEE IS   ''
                                ''          DAILY PAID. OTHERWISE, USE THE ELIGIBLEDAYS ''
                                ''          VARIABLE TO DEDUCT FROM ACA,RATA,PERA IF THE''
                                ''          EMPLOYEE IS NOT DAILY PAID.                 ''
                                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                                ''''''''''''''''''' OLD CODE '''''''''''''''''''''''''''''
                                'vEligibleDays = drRef(0) / 8
                                ''''''''''''''''''' END OLD CODE '''''''''''''''''''''''''
                                If dr("DailyPaid") = 1 Or vEmp.DateResigned <> Nothing Then         'daily paid or paid by piece
                                    vEligibleDays -= (drRef(0) / 8)
                                Else
                                    vEligibleDays = drRef(0) / 8
                                End If

                                ''''''''''''''''''' END OF MODIFICAITON ''''''''''''''''';

                            End If
                        End If
                        drRef.Close()

                        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                        '' MODIFIED BY:  VIC GATCHALIAN                                         ''
                        '' DATE MODIFIED: 3/16/2013                                             ''
                        '' PURPOSE: TO GET THE ACA, RATA, PERA, MEAL PROPERY FOR DAILY AND      ''
                        ''          NON-DAILY PAID EMPLOYEES.                                   ''
                        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                        If dr("DailyPaid") = 1 Or vEmp.DateResigned <> Nothing Then
                            If vRATA Then vEmp.RATA = Math.Round(IIf(IsDBNull(dr("Rata")), 0, dr("Rata")) / vDays, 2) * vEligibleDays
                            If vACA Then vEmp.ACA = Math.Round(IIf(IsDBNull(dr("Aca")), 0, dr("Aca")) / vDays, 2) * vEligibleDays
                            If vPERA Then vEmp.PERA = Math.Round(IIf(IsDBNull(dr("Pera")), 0, dr("Pera")) / vDays, 2) * vEligibleDays
                            If vMeal Then vEmp.MealAllow = Math.Round(IIf(IsDBNull(dr("MealAllow")), 0, dr("MealAllow")) / vDays, 2) * vEligibleDays

                            If vACADeductTardy Then
                                vEmp.ACA = vEmp.ACA - ((dr("Aca") / vDays) * (vTardyHrs / 8))
                            End If
                            If vACADeductUT Then
                                vEmp.ACA = vEmp.ACA - ((dr("Aca") / vDays) * (vUTHrs / 8))
                            End If

                            If vRATADeductTardy Then
                                vEmp.RATA = vEmp.RATA - ((dr("Rata") / vDays) * (vTardyHrs / 8))
                            End If
                            If vRATADeductUT Then
                                vEmp.RATA = vEmp.RATA - ((dr("Rata") / vDays) * (vUTHrs / 8))
                            End If

                            If vPERADeductTardy Then
                                vEmp.PERA = vEmp.PERA - ((dr("Pera") / vDays) * (vTardyHrs / 8))
                            End If
                            If vPERADeductUT Then
                                vEmp.PERA = vEmp.PERA - ((dr("Pera") / vDays) * (vUTHrs / 8))
                            End If

                            If vMealDeductTardy Then
                                vEmp.MealAllow = vEmp.MealAllow - ((dr("MealAllow") / vDays) * (vTardyHrs / 8))
                            End If
                            If vMealDeductUT Then
                                vEmp.MealAllow = vEmp.MealAllow - ((dr("MealAllow") / vDays) * (vUTHrs / 8))
                            End If
                        Else
                            If vRATA Then vEmp.RATA = Math.Round(IIf(IsDBNull(dr("Rata")), 0, dr("Rata")) / vRATADivisor, 2)
                            If vACA Then vEmp.ACA = Math.Round(IIf(IsDBNull(dr("Aca")), 0, dr("Aca")) / vACADivisor, 2)
                            If vPERA Then vEmp.PERA = Math.Round(IIf(IsDBNull(dr("Pera")), 0, dr("Pera")) / vPERADivisor, 2)
                            If vMeal Then vEmp.MealAllow = Math.Round(IIf(IsDBNull(dr("MealAllow")), 0, dr("MealAllow")) / vMealDivisor, 2)
                            vEmp.ACA = vEmp.ACA - ((vEmp.ACA / (vDays / vACADivisor) * vEligibleDays))
                            vEmp.RATA = vEmp.RATA - ((vEmp.RATA / (vDays / vRATADivisor) * vEligibleDays))
                            vEmp.PERA = vEmp.PERA - ((vEmp.PERA / (vDays / vPERADivisor) * vEligibleDays))
                            vEmp.MealAllow = vEmp.MealAllow - ((vEmp.MealAllow / (vDays / vMealDivisor) * vEligibleDays))
                            If vACADeductTardy Then
                                vEmp.ACA = vEmp.ACA - ((vEmp.ACA / (vDays / vACADivisor) * vTardyHrs))
                            End If
                            If vACADeductUT Then
                                vEmp.ACA = vEmp.ACA - ((vEmp.ACA / (vDays / vACADivisor) * vUTHrs))
                            End If
                            If vRATADeductTardy Then
                                vEmp.RATA = vEmp.RATA - ((vEmp.RATA / (vDays / vRATADivisor) * vTardyHrs))
                            End If
                            If vRATADeductUT Then
                                vEmp.RATA = vEmp.RATA - ((vEmp.RATA / (vDays / vRATADivisor) * vUTHrs))
                            End If
                            If vPERADeductTardy Then
                                vEmp.PERA = vEmp.PERA - ((vEmp.PERA / (vDays / vPERADivisor) * vTardyHrs))
                            End If
                            If vPERADeductUT Then
                                vEmp.PERA = vEmp.PERA - ((vEmp.PERA / (vDays / vPERADivisor) * vUTHrs))
                            End If
                            If vMealDeductTardy Then
                                vEmp.MealAllow = vEmp.MealAllow - ((vEmp.MealAllow / (vDays / vMealDivisor) * vTardyHrs))
                            End If
                            If vMealDeductUT Then
                                vEmp.MealAllow = vEmp.MealAllow - ((vEmp.MealAllow / (vDays / vMealDivisor) * vUTHrs))
                            End If
                        End If
                        '''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''''''''
                        ''''''''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''''''''''''
                    End If
                    '''''''''''''''''''''''''''''''''' OLD CODE
                    'If vMealProRata Then
                    '    vEmp.MealAllow = vEmp.MealAllow * vEligibleDays
                    'End If
                    'If vRataProRata Then
                    '    vEmp.RATA = vEmp.RATA * vEligibleDays
                    'End If
                    'If vAcaProRata Then
                    '    vEmp.ACA = vEmp.ACA * vEligibleDays
                    'End If
                    'If vPeraProRata Then
                    '    vEmp.PERA = vEmp.PERA * vEligibleDays
                    'End If
                    ''''''''''''''''''''''''' END OLD CODE ''''''''''''''''''''''''''''''''''''
                End If
                '''''''''''''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''

                'get OVERTIME
                vEmp.A1 = GetOT("A1", dr("Emp_Cd"))
                If vReturn <> "" Then GoTo jump
                vEmp.A2 = GetOT("A2", dr("Emp_Cd"))
                If vReturn <> "" Then GoTo jump
                vEmp.NDREG = GetOT("A3", dr("Emp_Cd")) + GetOT("A4", dr("Emp_Cd"))
                If vReturn <> "" Then GoTo jump
                vEmp.B1 = GetOT("B1", dr("Emp_Cd"))
                If vReturn <> "" Then GoTo jump
                vEmp.B2 = GetOT("B2", dr("Emp_Cd"))
                If vReturn <> "" Then GoTo jump
                vEmp.B3 = GetOT("B3", dr("Emp_Cd"))
                If vReturn <> "" Then GoTo jump
                vEmp.B4 = GetOT("B4", dr("Emp_Cd"))
                If vReturn <> "" Then GoTo jump
                vEmp.C1 = GetOT("C1", dr("Emp_Cd"))
                If vReturn <> "" Then GoTo jump
                vEmp.C2 = GetOT("C2", dr("Emp_Cd"))
                If vReturn <> "" Then GoTo jump
                vEmp.C3 = GetOT("C3", dr("Emp_Cd"))
                If vReturn <> "" Then GoTo jump
                vEmp.C4 = GetOT("C4", dr("Emp_Cd"))
                If vReturn <> "" Then GoTo jump
                vEmp.D1 = GetOT("D1", dr("Emp_Cd"))
                If vReturn <> "" Then GoTo jump
                vEmp.D2 = GetOT("D2", dr("Emp_Cd"))
                If vReturn <> "" Then GoTo jump
                vEmp.D3 = GetOT("D3", dr("Emp_Cd"))
                If vReturn <> "" Then GoTo jump
                vEmp.D4 = GetOT("D4", dr("Emp_Cd"))
                If vReturn <> "" Then GoTo jump
                vEmp.E1 = GetOT("E1", dr("Emp_Cd"))
                If vReturn <> "" Then GoTo jump
                vEmp.E2 = GetOT("E2", dr("Emp_Cd"))
                If vReturn <> "" Then GoTo jump
                vEmp.E3 = GetOT("E3", dr("Emp_Cd"))
                If vReturn <> "" Then GoTo jump
                vEmp.E4 = GetOT("E4", dr("Emp_Cd"))
                If vReturn <> "" Then GoTo jump
                vEmp.F1 = GetOT("F1", dr("Emp_Cd"))
                If vReturn <> "" Then GoTo jump
                vEmp.F2 = GetOT("F2", dr("Emp_Cd"))
                If vReturn <> "" Then GoTo jump
                vEmp.F3 = GetOT("F3", dr("Emp_Cd"))
                If vReturn <> "" Then GoTo jump
                vEmp.F4 = GetOT("F4", dr("Emp_Cd"))
                If vReturn <> "" Then GoTo jump
                vEmp.G1 = GetOT("G1", dr("Emp_Cd"))
                If vReturn <> "" Then GoTo jump
                vEmp.G2 = GetOT("G2", dr("Emp_Cd"))
                If vReturn <> "" Then GoTo jump
                vEmp.G3 = GetOT("G3", dr("Emp_Cd"))
                If vReturn <> "" Then GoTo jump
                vEmp.G4 = GetOT("G4", dr("Emp_Cd"))
                If vReturn <> "" Then GoTo jump
                vEmp.ABSENT = GetOT("ABSENT", dr("Emp_Cd"))                     'get absent
                vAbsentHrs = vHrsRendered
                If vReturn <> "" Then GoTo jump
                vEmp.ETP += GetOT("ETP", dr("Emp_Cd"))                         'add other extra time pay
                If vReturn <> "" Then GoTo jump
                vTardiness = GetOT("TARD", dr("Emp_Cd"))                        'get tardiness
                vTardyHrs = vHrsRendered
                If vReturn <> "" Then GoTo jump
                vUndertime += GetOT("UT", dr("Emp_Cd"))                         'get undertime
                vUTHrs = vHrsRendered
                If vReturn <> "" Then GoTo jump
                vTardiness += vUndertime

                If vReturn <> "" Then
jump:
                    c.Close()
                    c.Dispose()
                    cm.Dispose()
                    cmRef.Dispose()
                    'cm_loan.Dispose()
                    Exit Sub
                End If

                vOT = vEmp.A1 + vEmp.A2 + _
                   vEmp.B1 + vEmp.B2 + vEmp.B3 + vEmp.B4 + _
                   vEmp.C1 + vEmp.C2 + vEmp.C3 + vEmp.C4 + _
                   vEmp.D1 + vEmp.D2 + vEmp.D3 + vEmp.D4 + _
                   vEmp.E1 + vEmp.E2 + vEmp.E3 + vEmp.E4 + _
                   vEmp.F1 + vEmp.F2 + vEmp.F3 + vEmp.F4 + _
                   vEmp.G1 + vEmp.G2 + vEmp.G3 + vEmp.G4 + vEmp.NDREG
                vEmp.OT = vOT

                vGross = 0
                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY: VIC GATCHALIAN                                            ''
                '' DATE MODIFIED: 3/16/2013                                               ''
                '' PURPOSE: TO USE THE "DAILYPAID" FIELD IN CHECKING IF THE EMPLOYEE IS   ''
                ''          DAILY PAIDOR NOT INSTEAD OF USING THE CASUALCD varialbe       ''
                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '''''''''''''''''  OLD CODE ''''''''''''''''''''''''''''''''''''''''''''''''
                'If dr("Emp_Status") = vCasualCd Or vEmp.DateResigned <> Nothing Then         'daily paid or paid by piece
                ''''''''''''''''' END OLD CODE '''''''''''''''''''''''''''''''''''''''''''''
                If dr("DailyPaid") = 1 Or vEmp.DateResigned <> Nothing Then         'daily paid or paid by piece 
                    ''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''''''''''''''
                    'If dr("Emp_Status") = vCasualCd Or vEmp.DateResigned <> Nothing Then         'daily paid or paid by piece
                    'reset absences to 0
                    'vEmp.ABSENT = 0

                    'count the total number of scheduled days work
                    'cmRef.CommandText = "select count(*) from py_emp_time_sched where Emp_Cd='" & dr("Emp_Cd") & _
                    '    "' and Date_Sched between '" & Format(vFrom, "yyyy/MM/dd") & "' and '" & _
                    '    Format(vTo, "yyyy/MM/dd") & "' " 'and exists " & _
                    '"(select Emp_Cd from py_time_log where Tran_Date=Date_Sched and Emp_Cd='" & _
                    'rs("Emp_Cd") & "' and Time_In is not null)"

                    'drRef = cmRef.ExecuteReader
                    'If drRef.Read Then
                    '    If Not IsDBNull(drRef(0)) Then vDaysWorked = drRef(0)
                    'End If
                    'drRef.Close()

                    'get all holidays
                    'cmRef.CommandText = "select count(Holy_Date) from py_holiday where Official=1 and Holy_Date between '" & _
                    '    Format(vFrom, "yyyy/MM/dd") & "' and '" & Format(vTo, "yyyy/MM/dd") & "'"

                    'drRef = cmRef.ExecuteReader
                    'drRef.Read()
                    'iHoliday = 0
                    'If Not IsDBNull(drRef(0)) Then
                    '    iHoliday = drRef(0)
                    'End If
                    'drRef.Close()

                    'get all absences
                    'cmRef.CommandText = "select count(Hrs_Rendered) from py_time_log_dtl where LateFiled=0 and Emp_Cd='" & _
                    '    dr("Emp_Cd") & "' and TranDate between '" & Format(vFrom, "yyyy/MM/dd") & _
                    '    "' and '" & Format(vTo, "yyyy/MM/dd") & "' and TranCd='ABSENT'"
                    'drRef = cmRef.ExecuteReader
                    'If drRef.Read Then
                    '    If Not IsDBNull(drRef(0)) Then vDays -= (drRef(0) / 8)
                    'End If
                    'drRef.Close()

                    'vGross = GetOT("BASIC", dr("Emp_Cd"))

                    cmRef.CommandText = "select sum(Hrs_Rendered) from py_emp_time_log where Emp_Cd='" & _
                        dr("Emp_Cd") & "' and TranDate between '" & Format(vFrom, "yyyy/MM/dd") & _
                        "' and '" & Format(vTo, "yyyy/MM/dd") & _
                        "' AND TRANCD='BASIC' and Frozen=0"

                    vDaysWorked = 0
                    Try
                        drRef = cmRef.ExecuteReader
                        If drRef.Read Then
                            If Not IsDBNull(drRef(0)) Then
                                vDaysWorked = drRef(0)
                            End If
                        End If
                        drRef.Close()
                        vGross = Math.Round(vDaysWorked * dr("Rate_Day"), 2)
                    Catch ex As SqlClient.SqlException
                        vReturn = ex.Message.Replace(vbCrLf, "\n").Replace("'", "")
                    End Try

                    'cmRef.CommandText = "select sum(Hrs_Rendered) from py_emp_time_log where Emp_Cd='" & _
                    '    dr("Emp_Cd") & "' and TranDate between '" & Format(vFrom, "yyyy/MM/dd") & _
                    '    "' and '" & Format(vTo, "yyyy/MM/dd") & _
                    '    "' AND TRANCD='BASIC' and Frozen=0"

                    'vDaysWorked = 0
                    'Try
                    '    drRef = cmRef.ExecuteReader
                    '    If drRef.Read Then
                    '        If Not IsDBNull(drRef(0)) Then
                    '            vDaysWorked = drRef(0)
                    '        End If
                    '    End If
                    '    drRef.Close()
                    '    vGross = Math.Round(vDaysWorked * dr("Rate_Day"), 2)
                    'Catch ex As SqlClient.SqlException
                    '    vReturn = ex.Message.Replace(vbCrLf, "\n").Replace("'", "")
                    '    Exit Sub
                    'End Try


                    ''get any filed leave application
                    'cmRef.CommandText = "select Hrs_Rendered from py_time_log_dtl where LateFiled=0 and Emp_Cd='" & _
                    '    dr("Emp_Cd") & "' and TranDate between '" & Format(vFrom, "yyyy/MM/dd") & _
                    '    "' and '" & Format(vTo, "yyyy/MM/dd") & "' and (exists (select Leave_Cd from py_leave_ref where Leave_Cd=TranCd) " & _
                    '    " or (TranCd='ABSENT' and Hrs_Rendered < 8))"
                    'drRef = cmRef.ExecuteReader
                    'If drRef.Read Then

                    'End If
                    'drRef.Close()

                    'get number of days work
                    'cmRef.CommandText = "select count(*) from py_time_log where Emp_Cd='" & dr("Emp_Cd") & _
                    '    "' and Tran_Date between '" & Format(vFrom, "yyyy/MM/dd") & "' and '" & _
                    '    Format(vTo, "yyyy/MM/dd") & "' and Time_In is not null and not exists (" & _
                    '    "select Holy_Date from py_holiday where Official=1 and Holy_Date=Tran_Date)"

                    'drRef = cmRef.ExecuteReader
                    'If drRef.Read Then
                    '    If Not IsDBNull(drRef(0)) Then
                    '        vGross = Math.Round((drRef(0) + iHoliday) * dr("Rate_Day"), 2)
                    '    Else
                    '        vGross = 0
                    '    End If
                    'Else
                    '    vGross = 0
                    'End If
                    'drRef.Close()

                    'vBasic = Math.Round(vGross, 2)
                    'vGross = vGross + vTardiness

                    If vReturn <> "" Then GoTo jump
                Else                                         'monthly paid
                    vGross = IIf(IsDBNull(dr("Rate_Month")), 0, dr("Rate_Month")) / vDivide
                End If
                'vBasic = Math.Round(vGross + vEmp.ACA + vEmp.RATA + vEmp.PERA + vEmp.MealAllow, 2)
                vBasic = Math.Round(vGross, 2)
                'vGross = vGross + vEmp.ACA + vEmp.RATA + vEmp.PERA + vEmp.MealAllow + vTardiness + vEmp.ABSENT
                vGross = vGross + vTardiness + vEmp.ABSENT
                vMonth = Math.Round(vGross, 2)
            Else
                'special payroll
                Dim vTmpAbsent As Decimal = GetOT("ABSENT", dr("Emp_Cd"))                       'get absent
                vAbsentHrs = vHrsRendered
                If vReturn <> "" Then GoTo jump
                Dim vTmpTardiness As Decimal = GetOT("TARD", dr("Emp_Cd"))                      'get tardiness
                vTardyHrs = vHrsRendered
                If vReturn <> "" Then GoTo jump
                Dim vTmpUndertime As Decimal = GetOT("UT", dr("Emp_Cd"))                        'get undertime
                vUTHrs = vHrsRendered
                If vReturn <> "" Then GoTo jump
            End If      'payrollmode 

                vEmp.MonthRate = vBasic
                vMonth = vMonth + vOT

                'get one month gross pay (by approximation only)
                vMonthGross = (dr("Rate_Month") / vDivide) + vMonth

                'other incentives
                vTotOthIncent = 0
                vTaxableIncent = 0
                'reset to zeroes
                For iCtr = 0 To UBound(vTaxGroup)
                    vIncentiveTaxable(iCtr) = 0
                Next iCtr
                ReDim vEmp.Incentives(MaxIdx)

                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY:  VIC GATCHALIAN                                    ''
                '' DATE MODIFIED:  7/1/2012                                        ''
                '' PURPOSE: TO RECORD OTHER BENEFITS SUBJECT TO TAX BUT NOT PART   ''
                ''          OF EMPLOYEE'S SALARY                                   ''
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                Dim vTmpIncentList As String = ""
                ReDim vEmp.NonDeclaredBenefitsCodes(0)
                ReDim vEmp.NonDeclaredBenefits(0)
                ReDim vEmp.NonDeclaredBenefitsSrcCurr(0)
                ReDim vEmp.NonDeclaredBenefitsTargetCurr(0)

                For iCtr = 1 To MaxIdx
                    If vOthIncentCd(iCtr) <> "" Then
                        vTmpIncentList += vOthIncentCd(iCtr) & ","
                    End If
                Next
                If vTmpIncentList <> "" Then vTmpIncentList = Mid(vTmpIncentList, 1, Len(vTmpIncentList) - 1)

            cmRef.CommandText = "select count(*) from py_incentives_dtl " & _
                "where Emp_Cd='" & dr("Emp_Cd") & "' and Incentive_Cd in (select Incentive_Cd from py_other_incentvs where " & _
                "Taxable=1 and SpecialPayroll=" & IIf(vRegularPayroll, 0, 1) & _
                " and Incentive_Cd not in ('" & vTmpIncentList.Replace(",", "','") & _
                "')) and ((Fromdate between '" & _
                Format(vFrom, "yyyy/MM/dd") & "' and '" & Format(vTo, "yyyy/MM/dd") & _
                "') or (Recurring<>0 and (FreqCd=0 or FreqCd=" & _
                IIf(vTo.Day = 28 Or vTo.Day = 29 Or vTo.Day = 31, 30, vTo.Day) & _
                ")))"
            Try
                drRef = cmRef.ExecuteReader
                drRef.Read()
                If Not IsDBNull(drRef(0)) Then
                    If drRef(0) > 0 Then
                        ReDim vEmp.NonDeclaredBenefits(drRef(0))
                        ReDim vEmp.NonDeclaredBenefitsCodes(drRef(0))
                        ReDim vEmp.NonDeclaredBenefitsSrcCurr(drRef(0))
                        ReDim vEmp.NonDeclaredBenefitsTargetCurr(drRef(0))
                        drRef.Close()
                        iCtr = 0

                        cmRef.CommandText = "select Incentive_Amt as Amount, Incentive_Cd,SrcCurrCd,TargetCurrCd from py_incentives_dtl " & _
                            "where Emp_Cd='" & dr("Emp_Cd") & "' and Incentive_Cd in (select Incentive_Cd from py_other_incentvs where " & _
                            "Taxable=1 and SpecialPayroll=" & IIf(vRegularPayroll, 0, 1) & " and Incentive_Cd not in ('" & vTmpIncentList.Replace(",", "','") & _
                            "')) and ((Fromdate between '" & _
                            Format(vFrom, "yyyy/MM/dd") & "' and '" & Format(vTo, "yyyy/MM/dd") & _
                            "') or (Recurring<>0 and (FreqCd=0 or FreqCd=" & _
                            IIf(vTo.Day = 28 Or vTo.Day = 29 Or vTo.Day = 31, 30, vTo.Day) & _
                            "))) "

                        drRef = cmRef.ExecuteReader
                        Do While drRef.Read
                            vEmp.NonDeclaredBenefitsCodes(iCtr) = drRef("Incentive_Cd")
                            vEmp.NonDeclaredBenefits(iCtr) = drRef("Amount")
                            vEmp.NonDeclaredBenefitsSrcCurr(iCtr) = drRef("SrcCurrCd")
                            vEmp.NonDeclaredBenefitsTargetCurr(iCtr) = drRef("TargetCurrCd")
                            iCtr += 1
                        Loop
                    End If
                End If
                drRef.Close()
            Catch ex As SqlClient.SqlException
                vReturn = ex.Message.Replace("'", "").Replace(vbCrLf, "\n")
                GoTo jump
                Exit Sub
            End Try
            '''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''''' 

            vTemp = 0

            vDeminimis = 0
            For iCtr = 1 To MaxIdx
                If vOthIncentCd(iCtr) <> "" Then
                    'cmRef.CommandText = "select sum(Incentive_Amt) as v_amts from py_incentives_dtl " & _
                    '   "where Emp_Cd='" & dr("Emp_Cd") & "' and Incentive_Cd='" & _
                    '   vOthIncentCd(iCtr) & "' and (('" & Format(vTo, "yyyy/MM/dd") & _
                    '   "' between FromDate and ToDate) or (Recurring<>0 and (FreqCd=0 or FreqCd=" & _
                    '   IIf(vTo.Day = 28 Or vTo.Day = 29 Or vTo.Day = 31, 30, vTo.Day) & _
                    '   "))) group by Emp_Cd,Incentive_Cd"
                    cmRef.CommandText = "select sum(Incentive_Amt) as v_amts from py_incentives_dtl " & _
                       "where Emp_Cd='" & dr("Emp_Cd") & "' and Incentive_Cd='" & _
                       vOthIncentCd(iCtr) & "' and ((FromDate between '" & _
                       Format(vFrom, "yyyy/MM/dd") & "' and '" & Format(vTo, "yyyy/MM/dd") & _
                       "') or (Recurring<>0 and (FreqCd=0 or FreqCd=" & _
                       IIf(vTo.Day = 28 Or vTo.Day = 29 Or vTo.Day = 31, 30, vTo.Day) & _
                       "))) group by Emp_Cd,Incentive_Cd"

                    Try
                        drRef = cmRef.ExecuteReader
                        vEmp.Incentives(iCtr) = 0
                        Dim vMultiplier As Integer = 1
                        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                        '''''  MODIFIED BY:  VIC GATCHALIAN                           '
                        '''''  DATE MODIFIED: 9/12/2011                               '
                        '''''  PURPOSE: TO USE INCENTIVE 60 AS ETP                    '
                        '''''  EXCEPTIONS: FOR GWI USE ONLY                           '
                        '''''  REQUIREMENTS:  MUST DEFINE CODE ETP IN INCENTIVES      '
                        '''''                 AND DEFINE IT IN INCENTIVES SETTINGS    '
                        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                        If iCtr = MaxIdx Then
                            vEmp.Incentives(iCtr) = vEmp.ETP
                            GoTo skip
                        End If
                        ''''''''''''''''  end modification ''''''''''''''''''''''''''''

                        If drRef.Read Then
                            If Not IsDBNull(drRef("v_amts")) Then
                                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                                ''''  MODIFIED BY: VIC GATCHALIAN                          '
                                ''''  DATE MODIFIED:  9/26/2011                            '
                                ''''  PURPOSE:  TO GET THE VALUE OF ECOLA TO BE INCLUDED   '
                                ''''            AS PART OF THE SSS COMPUTATION             '
                                ''''  EXCEPTIONS:  FOR FASTRAK USE ONLY                    '
                                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                                If vOthIncentCd(iCtr) = "ECOLA" Then
                                    'vECOLA = vEmp.Incentives(iCtr)
                                    vECOLA = Math.Round(drRef("v_amts"), 2)
                                End If

                                If Not vOthIncentProRated(iCtr) Then
                                    vEmp.Incentives(iCtr) = Math.Round(drRef("v_amts"), 2)
                                Else
                                    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                                    '' MODIFIED BY:  VIC GATCHALIAN                             '
                                    '' DATE MODIFIED: 5/24/2012                                 '
                                    '' PURPOSE: TO SEGGREGATE CALCULATION OF PRO-RATED          '
                                    ''          INCENTIVES BASED ON EMPLOYEE STATUS.            '
                                    ''          IF STATUS IS DAILY, CALCULATION IS OF PRO-RATED '
                                    ''          INCENTIVES IS MULTIPLIED ONLY ON ACTUAL DAYS    '
                                    ''          WORKED. OTHERWISE, PRO-RATED INCENTIVES ARE     '
                                    ''          CALCULATED ON INCENTIVE AMOUNT / PAY MODE LESS  '
                                    ''          ABSENCES (AND TARDINESS, UT)                    '
                                    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                                    If dr("Emp_Status") = vCasualCd Or vEmp.DateResigned <> Nothing Then    'daily paid
                                        vEmp.Incentives(iCtr) = (drRef("v_amts") / vDays) * vDaysWorked
                                    Else
                                        vEmp.Incentives(iCtr) = (drRef("v_amts") / 2)   'assumes one month figure, hence, it is needed to divide by 2
                                    End If
                                    ''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''

                                    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                                    '''''  MODIFIED BY:  VIC GATCHALIAN                          '
                                    '''''  DATE MODIFIED: 9/15/2011                              '
                                    '''''  PURPOSE: SEPARATES THE ABSENCES, TARDINESS/UT         '
                                    '''''           DEDUCTIONS FROM THE INCENTIVE AMOUNT         '
                                    '''''  EXCEPTIONS: REQUESTED BY GWI, BUT CAN ALSO BE USED    '
                                    '''''           AS A GENERAL PURPOSE FUNCTION                '
                                    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                                    '''' OLD CODE ''''''''''''''''''''''''''''''''''''''''''''''''
                                    'vEmp.Incentives(iCtr) = (drRef("v_amts") / 2) - (((drRef("v_amts") / vDays) / 8) * vAbsentHrs)
                                    'If vOthIncentDeductTardy(iCtr) Then
                                    '    vEmp.Incentives(iCtr) = vEmp.Incentives(iCtr) - (((drRef("v_amts") / vDays) / 8) * vTardyHrs)
                                    'End If
                                    'If vOthIncentDeductUT(iCtr) Then
                                    '    vEmp.Incentives(iCtr) = vEmp.Incentives(iCtr) - (((drRef("v_amts") / vDays) / 8) * vUTHrs)
                                    'End If
                                    '''''''''''''''  END OLD CODE '''''''''''''''''''''''''''''''
                                    Dim vTmpAbsent As Decimal = 0
                                    Dim vTmpUT As Decimal = 0
                                    Dim vTmpTardy As Decimal = 0


                                    If vAbsentHrs <> 0 Then
                                        vTmpAbsent = ((drRef("v_amts") / vDays) / 8) * vAbsentHrs * -1
                                    End If

                                    If vOthIncentDeductTardy(iCtr) Then
                                        If vTardyHrs <> 0 Then
                                            vTmpTardy += ((drRef("v_amts") / vDays) / 8) * vTardyHrs * -1
                                        End If
                                        'vTardiness += vTmpTardy
                                    End If
                                    If vOthIncentDeductUT(iCtr) Then
                                        If vUTHrs <> 0 Then
                                            vTmpUT = ((drRef("v_amts") / vDays) / 8) * vUTHrs * -1
                                        End If
                                        'vTardiness += vTmpUT
                                    End If

                                    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                                    '' MODIFIED BY:  VIC GATCHALIAN                                 ''
                                    '' DATE MODIFIED:  10/26/2011                                   ''
                                    '' PURPOSE: TO SEGGREGATE THE COMPUTED ABSENCES,UT,&TARDY FROM  ''
                                    ''          COMPUTED INCENTIVES                                 ''
                                    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                                    ''''''''''''''''''''' OLDE CODE ''''''''''''''''''''''''''''''''''
                                    vEmp.Incentives(iCtr) += vTmpAbsent + vTmpTardy + vTmpUT
                                    ''''''''''''''''''''' END ORIGINAL CODE ''''''''''''''''''''''''''
                                    'vEmp.ABSENT += vTmpAbsent
                                    'vMonth += vTmpAbsent + vTardiness
                                    '''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''''''
                                End If
                                'If vEmp.Incentives(iCtr) < 0 Then vEmp.Incentives(iCtr) = 0
                            End If
skip:
                            If vOthIncent(iCtr) Then   'TAXABLE
                                If vAnnualized Then
                                    Dim iGrp As Integer
                                    Dim iLoop As Integer
                                    Dim vIncentList() As String
                                    For iGrp = 0 To UBound(vTaxGroup)
                                        If vTaxGroup(iGrp) = vOthLimit(iCtr) Then
                                            vIncentList = vIncentives(iGrp).Split(",")
                                            For iLoop = 0 To UBound(vIncentList)
                                                If vIncentList(iLoop) = vOthIncentCd(iCtr) Then
                                                    vIncentiveTaxable(iGrp) = vIncentiveTaxable(iGrp) + vEmp.Incentives(iCtr)
                                                    Exit For 'ILOOP
                                                End If
                                            Next iLoop
                                            Exit For 'IGRP
                                        End If
                                        vIncentiveTaxable(iGrp) = vIncentiveTaxable(iGrp) * IIf(vOthIncentPerc(iCtr) = 0, 1, vOthIncentPerc(iCtr))
                                    Next iGrp
                                Else  'use periodical
                                    If vOthLimit(iCtr) > 0 Then
                                        If vEmp.Incentives(iCtr) > vOthLimit(iCtr) Then
                                            vTaxableIncent = vTaxableIncent + _
                                               (vEmp.Incentives(iCtr) - vOthLimit(iCtr))
                                        End If
                                    Else
                                        vTaxableIncent = vTaxableIncent + vEmp.Incentives(iCtr)
                                    End If
                                    vTaxableIncent = vTaxableIncent * IIf(vOthIncentPerc(iCtr) = 0, 1, vOthIncentPerc(iCtr))
                                End If   'annualize
                            End If   'taxable 
                        End If
                        vTotOthIncent = vTotOthIncent + vEmp.Incentives(iCtr)
                        vTemp += (vEmp.Incentives(iCtr) * vMultiplier)
                        drRef.Close() 'PY_INCENTIVES_DTL 
                    Catch ex As SqlClient.SqlException
                        vReturn = ex.Message.Replace("'", "").Replace(vbCrLf, "\n")
                        GoTo jump
                        Exit Sub
                    End Try

                    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                    '' MODIFIED BY:  VIC GATCHALIAN                                   ''
                    '' DATE MODIFIED: 5/23/2012                                       ''
                    '' PURPOSE: TO ADD OTHER INCENTIVES AS PART OF BASIC PAY IF       ''
                    ''          THE INCENTIVES IS TAGGED AS PART OF BASIC PAY FOR     ''
                    ''          SSS, PAGIBIG AND PHIC CALCULATION                     ''
                    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                    If vOthIncent2Basic(iCtr) Then  'include to deminimis
                        vDeminimis += (vEmp.Incentives(iCtr) * 2)
                    End If
                    '''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''''
                End If   'not EMPTY 
            Next iCtr

            vEmp.EmpId = dr("Emp_Cd")
            vEmp.ReportNo = IIf(IsDBNull(dr("Acct_No")), "", dr("Acct_No"))
            vEmp.Status = IIf(IsDBNull(dr("Emp_Status")), "", dr("Emp_Status"))
            vEmp.PayCd = dr("Pay_Cd")
            vEmp.Name = vName

            vEmp.Position = vPosition
            vEmp.TaxCd = IIf(IsDBNull(dr("Tax_Cd")), "Z", dr("Tax_Cd"))
            vEmp.From = vFrom
            vEmp.vTo = vTo
            vEmp.RC_CD = dr("Rc_Cd")
            vEmp.Office = dr("Agency_Cd")
            vEmp.DivCd = dr("DivCd")
            vEmp.DeptCd = dr("DeptCd")
            vEmp.SectionCd = dr("SectionCd")
            vEmp.UnitCd = dr("UnitCd")
            vEmp.EmploymentType = dr("EmploymentType")
            vEmp.NormalPay = vRegularPayroll

            'initialize to zero before computing
            vEmp.XtraHazard = 0
            vEmp.SSSEmp = 0
            vEmp.SSSEmr = 0
            vEmp.PagIbigEmp = 0
            vEmp.PagIbigEmr = 0
            vEmp.MedicareEmp = 0
            vEmp.MedicareEmr = 0
            vEmp.StateIns = 0
            vEmp.GSISEmp = 0
            vEmp.GSISEmr = 0
            vEmp.UNIONDUES = 0

            'vTmpGross = dr("Rate_Month") + vEmp.OT + vTemp - vAbsents - vTardiness 
            'vTmpGross = (vGross + vTotOthIncent) * 2   'original code
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:  VIC GATCHALIAN                                      ''
            '' DATE MODIFIED: 3/27/2012                                          ''
            '' PURPOSE:  TO CHECK IF THERE'S A PREVIOUS GROSS PAY WITHIN THE     ''
            ''           PAYOUT MONTH.  IF THERE'S NONE, MULTIPLY THE CURRENT    ''
            ''           GROSS BY 2 TO ASSUME ONE MONTH PAY.                     ''
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '''''''''''''''''''''  OLD CODE  ''''''''''''''''''''''''''''''''''''''
            'vTmpGross = (vGross + vTotOthIncent + vEmp.ACA + vEmp.RATA + vEmp.PERA + vEmp.MealAllow) * 2
            '''''''''''''''''''''  END OLD CODE '''''''''''''''''''''''''''''''''''

            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:  VIC GATCHALIAN                                      ''
            '' DATE MODIFIED: 4/9/2012                                           ''
            '' PURPOSE: TO FURTHER DETERMINE THE LIST OF TAXABLE INCENTIVES ONLY ''
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            'get taxable incentives 
            Dim vSQLStr As String = ""
            For iCtr = 1 To 60
                If vOthIncent(iCtr) Then
                    vSQLStr += "Other_Incent" & iCtr & "+"
                End If
            Next
            ''''''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''' 
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''' 
            ''''    Modified by     :   Rudner D. Diaz,Jr.                       '' 
            ''''    Date Modified   :   May 16, 2012                             '' 
            ''''    Purpose         :   To include the seniority Allowance       '' 
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''' 
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''' 
            '' MODIFIED BY:  VIC GATCHALIAN                                      '' 
            '' DATE MODIFIED: 5/20/2012                                          '' 
            '' PURPOSE: TO CHECK IF THERE IS A START DATE SET                    '' 
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''' 
            vEmp.SeniorAllow = 0
            If Not IsDBNull(dr("Start_Date")) Then
                vEmp.StartDate = dr("Start_Date")
                Dim vYearofService As Decimal

                If dr("WithSeniorAllow") = 1 And vRegularPayroll Then
                    If vSenior Then
                        vYearofService = DateDiff(DateInterval.Day, vEmp.StartDate, Now) / 365.25
                        cmRef.CommandText = "select Amount from py_senior_allowance where EmploymentType='" & _
                            dr("EmploymentType") & "' and " & Math.Round(vYearofService, 2) & _
                            ">= FromYear and " & Math.Round(vYearofService, 2) & "<= ToYear"
                        drRef = cmRef.ExecuteReader
                        If drRef.Read Then
                            vEmp.SeniorAllow = drRef("Amount")
                        End If
                        drRef.Close()
                    End If
                End If
            End If
            ''''''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''''' 
            '''''''''''''''''''''''END OF MODIFICATION'''''''''''''''''''''''''''''''''''''''''''''''' 
            cmRef.CommandText = "select sum(" & vSQLStr & "BasicRate+OT+Absent+Tardiness) " & _
                " as PrevGross from py_report where Emp_Cd='" & dr("Emp_Cd") & "' and Month(PayDate)=" & _
                vPayOut.Month & " and year(PayDate)=" & vPayOut.Year

            drRef = cmRef.ExecuteReader
            vTmpGross = 0
            'If drRef.Read Then
            '    If Not IsDBNull(drRef("PrevGross")) Then
            '        vTmpGross = drRef("PrevGross")
            '        If vTmpGross = 0 Then
            '            vTmpGross = (vGross + vTotOthIncent + vEmp.ACA + vEmp.RATA + vEmp.PERA + vEmp.MealAllow + vSeniorAmount) * 2
            '        Else
            '            vTmpGross += (vGross + vTotOthIncent + vEmp.ACA + vEmp.RATA + vEmp.PERA + vEmp.MealAllow + vSeniorAmount)   'add current gross
            '        End If
            '    Else
            '        vTmpGross = (vGross + vTotOthIncent + vEmp.ACA + vEmp.RATA + vEmp.PERA + vEmp.MealAllow + vSeniorAmount) * 2
            '    End If
            'Else
            '    vTmpGross = (vGross + vTotOthIncent + vEmp.ACA + vEmp.RATA + vEmp.PERA + vEmp.MealAllow + vSeniorAmount) * 2
            'End If
            If drRef.Read Then
                If Not IsDBNull(drRef("PrevGross")) Then
                    vTmpGross = drRef("PrevGross")
                    '    If vTmpGross = 0 Then
                    '        'vTmpGross = (vGross + vTotOthIncent + vEmp.ACA + vEmp.RATA + vEmp.PERA + vEmp.MealAllow) * 2
                    '        'include the taxable incentives as part of the calculation of SSS,Pagibig, PHIC
                    '        'vTmpGross = (vGross + vOT + vTaxableIncent + vEmp.ACA + vEmp.RATA + vEmp.PERA + vEmp.MealAllow) * 2
                    '        'vTmpGross = (vGross + vOT + vTaxableIncent + vEmp.ACA + vEmp.RATA + vEmp.PERA + vEmp.MealAllow + _
                    '        'IIf(vSeniorTaxable, vEmp.SeniorAllow, 0))
                    '        GoTo currgross
                    '    Else
                    '        'vTmpGross += (vGross + vTotOthIncent + vEmp.ACA + vEmp.RATA + vEmp.PERA + vEmp.MealAllow)   'add current gross
                    '        vTmpGross += (vGross + vOT + vTaxableIncent + vEmp.ACA + vEmp.RATA + vEmp.PERA + vEmp.MealAllow + _
                    '                    IIf(vSeniorTaxable, vEmp.SeniorAllow, 0))   'add current gross
                    '    End If
                    'Else
                    '    'vTmpGross = (vGross + vTotOthIncent + vEmp.ACA + vEmp.RATA + vEmp.PERA + vEmp.MealAllow) * 2
                    '    'vTmpGross = (vGross + vOT + vTaxableIncent + vEmp.ACA + vEmp.RATA + vEmp.PERA + vEmp.MealAllow) * 2
                    '    'vTmpGross = (vGross + vOT + vTaxableIncent + vEmp.ACA + vEmp.RATA + vEmp.PERA + vEmp.MealAllow + _
                    '    'IIf(vSeniorTaxable, vEmp.SeniorAllow, 0))
                    '    GoTo currgross
                End If
                '            Else
                '                'vTmpGross = (vGross + vTotOthIncent + vEmp.ACA + vEmp.RATA + vEmp.PERA + vEmp.MealAllow) * 2
                '                'vTmpGross = (vGross + vOT + vTaxableIncent + vEmp.ACA + vEmp.RATA + vEmp.PERA + vEmp.MealAllow) * 2
                'currgross:
                '                vTmpGross = (vGross + vOT + vTaxableIncent + vEmp.ACA + vEmp.RATA + vEmp.PERA + vEmp.MealAllow + _
                '                             IIf(vSeniorTaxable, vEmp.SeniorAllow, 0))
            End If
            drRef.Close()

            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:  VIC GATCHALIAN                               ''
            '' DATE MODIFIED: 7/2/2013                                    ''
            '' PURPOSE: TO GET THE HALF OF THE MONTHLY RATE IF THE PREV   ''
            ''          GROSS PAY IS 0 TO ASSUME 1 MONTH SALARY.          ''
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            If vTmpGross = 0 Then vTmpGross = (dr("Rate_Month") / vDivisor) + (dr("Aca") / vDivisor)
            ''''''''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''

            'vTmpGross += vGross + vOT + vTaxableIncent + vDeminimis + vECOLA + _
            '    (vEmp.ACA * vACADivisor) + (vEmp.RATA * vRATADivisor) + _
            '                (vEmp.PERA * vPERADivisor) + (vEmp.MealAllow * vMealDivisor)
            vTmpGross += vGross + vOT + vTaxableIncent + vDeminimis + vECOLA + _
                (vEmp.ACA) + (vEmp.RATA) + _
                            (vEmp.PERA) + (vEmp.MealAllow)
                '''''''''''''''''''''  END OF MODIFICATION  '''''''''''''''''''''''''''

            If vRegularPayroll Then     'normal payroll 
                'EXTRA HAZARD PAY
                vEmp.XtraHazard = Math.Round((vXtra * vTmpGross) / vDivisor, 2)

                'SSS SHARE
                vSSSContr(1) = 0
                vSSSContr(2) = 0
                vEC = 0
                vFixedEmp = IIf(IsDBNull(dr("FixedSss_Emp")), 0, dr("FixedSss_Emp"))
                vFixedEmr = IIf(IsDBNull(dr("FixedSss_Emr")), 0, dr("FixedSss_Emr"))

                If vFixedEmp = 0 Then
                    If (SSSGrossBasis And vTmpGross > 0) Or Not SSSGrossBasis Then
                        'cmRef.CommandText = "select * from py_sss_table where " & IIf(SSSGrossBasis, vTmpGross, _
                        '    dr("Rate_Month") + (vEmp.ACA * vACADivisor) + (vEmp.RATA * vRATADivisor) + _
                        '    (vEmp.PERA * vPERADivisor) + (vEmp.MealAllow * vMealDivisor)) & _
                        '   " between Min_Amt and Max_Amt"

                        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                        '''''''   MODIFIED BY:  VIC GATCHALIAN                        ''
                        '''''''   DATE MODIFIED:  9/26/2011                           ''
                        '''''''   REASON FOR CHANGE: IF SSS BASIS OF COMPUTATION IS   ''
                        '''''''          BASIC, INCLUDE THE ACA, RATA, PERA, ECOLA    ''
                        '''''''          AS PART OF BASIC PAY                         ''
                        '''''''   EXCEPTIONS:  FOR FASTRAK USE ONLY                   ''
                        cmRef.CommandText = "select * from py_sss_table where " & IIf(SSSGrossBasis, vTmpGross, _
                            dr("Rate_Month") + vDeminimis + vECOLA + (vEmp.ACA * vACADivisor) + (vEmp.RATA * vRATADivisor) + _
                            (vEmp.PERA * vPERADivisor) + (vEmp.MealAllow * vMealDivisor)) & _
                            " between Min_Amt and Max_Amt"
                        'cmRef.CommandText = "select * from py_sss_table where " & IIf(SSSGrossBasis, vTmpGross, _
                        '    dr("Rate_Month")) & " between Min_Amt and Max_Amt"
                        ''''''''''''''''  END OF MODIFICATION ''''''''''''''''''''''''''

                        drRef = cmRef.ExecuteReader
                        If drRef.Read Then
                            vSSSContr(1) = IIf(IsDBNull(drRef("Emp_Ss")), 0, drRef("Emp_Ss"))
                            vSSSContr(2) = IIf(IsDBNull(drRef("Ss")), 0, drRef("Ss"))
                            vEC = IIf(IsDBNull(drRef("Ec")), 0, drRef("Ec"))
                        End If
                        drRef.Close() 'PY_SSS_TABLE
                    End If
                Else
                    If vTmpGross > 0 Then
                        If vFixedEmp > 0 And vFixedEmp < 1 Then   'USE PERCENTAGE
                            vSSSContr(1) = vTmpGross * vFixedEmp
                            vSSSContr(2) = vTmpGross * vFixedEmr
                        Else  'USE SPECIFIC AMOUNT
                            vSSSContr(1) = vFixedEmp
                            vSSSContr(2) = vFixedEmr
                        End If
                    End If
                End If
                If dr("Allow_Sss") <> 0 And vSSS Then
                    vEmp.SSSEmp = Math.Round(vSSSContr(1) / vSSSDivisor, 2)
                    vEmp.SSSEmr = Math.Round(vSSSContr(2) / vSSSDivisor, 2)
                    If vSSSContr(1) <= 0 Then vEC = 0
                Else
                    vEC = 0
                End If

                'PAGIBIG SHARE FOR GOVT AND PERSONAL
                vPagibigContr(1) = 0
                vPagibigContr(2) = 0
                vFixedEmp = IIf(IsDBNull(dr("FixedPagIbig_Emp")), 0, dr("FixedPagIbig_Emp"))
                vFixedEmr = IIf(IsDBNull(dr("FixedPagIbig_Emr")), 0, dr("FixedPagIbig_Emr"))
                If vFixedEmp = 0 Then
                    If (PagIbigGrossBasis And vTmpGross > 0) Or Not PagIbigGrossBasis Then
                        cmRef.CommandText = "select * from py_deduct"
                        drRef = cmRef.ExecuteReader
                        drRef.Read()
                        vTemp = IIf(IsDBNull(drRef("Pag_Per_Per")), 0, drRef("Pag_Per_Per")) * _
                            IIf(PagIbigGrossBasis, vTmpGross, dr("Rate_Month") + vDeminimis + vEmp.ACA + vEmp.RATA + vEmp.PERA + vEmp.MealAllow)
                        vTemp2 = IIf(IsDBNull(drRef("Pag_Per_Up")), 0, drRef("Pag_Per_Up"))
                        vPagibigContr(1) = (IIf(vTemp > vTemp2, vTemp2, vTemp))
                        vTemp = IIf(IsDBNull(drRef("Pag_Gov_Per")), 0, drRef("Pag_Gov_Per")) * IIf(PagIbigGrossBasis, vTmpGross, _
                            dr("Rate_Month") + vDeminimis + vEmp.ACA + vEmp.RATA + vEmp.PERA + vEmp.MealAllow)
                        vTemp2 = IIf(IsDBNull(drRef("Pag_Gov_Up")), 0, drRef("Pag_Gov_Up"))
                        vPagibigContr(2) = (IIf(vTemp > vTemp2, vTemp2, vTemp))
                        drRef.Close() 'PY_DEDUCT
                    End If
                Else
                    If vTmpGross > 0 Then
                        If vFixedEmp > 0 And vFixedEmp < 1 Then   'USE PERCENTAGE
                            vPagibigContr(1) = vTmpGross * vFixedEmp
                            vPagibigContr(2) = vTmpGross * vFixedEmr
                        Else  'USE SPECIFIC AMOUNT
                            vPagibigContr(1) = vFixedEmp
                            vPagibigContr(2) = vFixedEmr
                        End If
                    End If
                End If
                If dr("Allow_PagIbig") <> 0 And vPagIBIG Then
                    vEmp.PagIbigEmp = Math.Round(vPagibigContr(1) / vPagIBIGDivisor, 2)
                    vEmp.PagIbigEmr = Math.Round(vPagibigContr(2) / vPagIBIGDivisor, 2)
                End If

                'MEDICARE SHARE FOR GOVT AND PERSONAL
                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY:  VIC GATCHALIAN                                   ''
                '' DATE MODIFIED: 6/3/2013                                        ''
                '' PURPOSE: TO EXCLUDE THE ACA AS PART OF THE BASIC PAY           ''
                '' EXCEPTION: FOR FISHERMALL USE ONLY                             ''
                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                'vTmpGross += vGross + vOT + vTaxableIncent + vDeminimis + vECOLA + _
                '    (vEmp.MealAllow * vMealDivisor)
                'vTmpGross -= vEmp.ACA - vECOLA - (dr("Aca") / vDivisor)
                ''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''''''
                
                vMedicareContr(1) = 0
                vMedicareContr(2) = 0
                vFixedEmp = IIf(IsDBNull(dr("FixedHealth_Emp")), 0, dr("FixedHealth_Emp"))
                vFixedEmr = IIf(IsDBNull(dr("FixedHealth_Emr")), 0, dr("FixedHealth_Emr"))
                If vFixedEmp = 0 Then
                    If (PhicGrossBasis And vTmpGross > 0) Or Not PhicGrossBasis Then
                        cmRef.CommandText = "select * from py_philhealth_table where " & _
                        IIf(PhicGrossBasis, vTmpGross, dr("Rate_Month")) & _
                            " between FromAmt and ToAmt"
                        drRef = cmRef.ExecuteReader
                        If drRef.Read Then
                            vMedicareContr(1) = IIf(IsDBNull(drRef("Per_Share")), 0, drRef("Per_Share"))
                            vMedicareContr(2) = IIf(IsDBNull(drRef("Govt_Share")), 0, drRef("Govt_Share"))
                        End If
                        drRef.Close() 'PY_PHILHEALTH_TABLE
                    End If
                Else
                    If vTmpGross > 0 Then
                        If vFixedEmp > 0 And vFixedEmp < 1 Then   'USE PERCENTAGE
                            vMedicareContr(1) = vTmpGross * vFixedEmp
                            vMedicareContr(2) = vTmpGross * vFixedEmr
                        Else  'USE SPECIFIC AMOUNT
                            vMedicareContr(1) = vFixedEmp
                            vMedicareContr(2) = vFixedEmr
                        End If
                    End If
                End If
                If dr("Allow_Medicare") <> 0 And vMedicare Then
                    vEmp.MedicareEmp = Math.Round(vMedicareContr(1) / vMedicareDivisor, 2)
                    vEmp.MedicareEmr = Math.Round(vMedicareContr(2) / vMedicareDivisor, 2)
                End If

                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY:  VIC GATCHALIAN                        ''
                '' DATE MODIFIED: 3/2/2012                             ''
                '' PURPOSE:  TO INCLUDE THE UNION DUES CALCULATION     ''
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                If dr("Allow_UnionDues") = 1 Or dr("UnionValue") <> 0 Then   'employee is  a member of union
                    'get info from union ref
                    cmRef.CommandText = "select * from py_union_ref where UnionCd='" & dr("UnionCd") & "'"
                    drRef = cmRef.ExecuteReader
                    If drRef.Read Then
                        If drRef("FreqCd") = 0 Or (drRef("FreqCd") = vFrom.Day) Then     'if every payroll or specific date=current cut off date
                            If drRef("Mode") = 0 Then   'percentage mode
                                If drRef("Basis") = 0 Then  'based on basic
                                    vEmp.UNIONDUES = (drRef("Value") / 100) * dr("Rate_Month")
                                Else                        'based on gross
                                    vEmp.UNIONDUES = (drRef("Value") / 100) * vEmp.MonthRate
                                End If
                            Else                        'amount mode
                                vEmp.UNIONDUES = drRef("Value")
                            End If
                        End If
                    End If
                    drRef.Close()
                    'Else 'employee is not a union member
                    'now check if employee is a paying non-member union
                    'If dr("UnionValue") <> 0 Then
                    '    'employee is a paying non-union member
                    '    vEmp.UNIONDUES = dr("UnionValue")
                    'End If
                End If

                vEmp.UNIONDUES = Math.Round(vEmp.UNIONDUES, 2)
                '''''''''''''''' END OF MODIFICATION ''''''''''''''''''''

                'GET HEALTH PREMIUMS
                vEmp.GSISEmp = 0
                'cmRef.CommandText = "select Amount from py_other_premiums where Emp_Id='" & vemp.EmpId & _
                '   "'"
                'drRef = cmRef.ExecuteReader
                'If drRef.Read Then
                '    vemp.GSISEmp = IIf(IsDBNull(drRef("Amount")), 0, drRef("Amount"))
                'End If
                'drRef.Close()
                '''''''''''''''''''''''''''' FOR GOVERNMENT USE ONLY ''''''''''''''''''''''''''''''''''
                'STATE INSURANCE GOVT SHARE
                'If dr("Allow_Life") <> 0 And vState And dr("Rate_Month") > 0 Then
                '    cmRef.CommandText = "select * py_deduct"
                '    drRef = cmRef.ExecuteReader
                '    drRef.Read()
                '    vTemp = IIf(IsDBNull(drRef("State_Per")), 0, drRef("State_Per")) * dr("Rate_Month")
                '    vTemp2 = IIf(IsDBNull(drRef("State_Up")), 0, drRef("State_Up"))
                '    vemp.StateIns = Math.Round((IIf(vTemp > vTemp2, vTemp2, vTemp)) / vDivisor, 2)
                '    drRef.Close() 'PY_DEDUCT
                'End If

                'GSIS GOVT AND PERSONAL SHARE
                'If dr("Allow_Retire") <> 0 And vGSIS And dr("Rate_Month") > 0 Then
                '    cmRef.CommandText = "select * from py_gsis_table"
                '    drRef = cmRef.ExecuteReader
                '    drRef.Read()    'first record
                '    vTemp = IIf(vMonth <= drRef("To_Amt"), dr("Rate_Month") * drRef("Personal_Total"), _
                '       drRef("Personal_Total") * drRef("To_Amt"))
                '    drRef.Read()    'next record
                '    vemp.GSISEmp = Math.Round((vTemp + (IIf(dr("Rate_Month") <= drRef("To_Amt"), 0, _
                '       drRef("Personal_Total") * (dr("Rate_Month") - drRef("To_Amt"))))) / vDivisor, 2)
                '    drRef.Read()      'last record
                '    vemp.GSISEmr = Math.Round((dr("Rate_Month") * drRef("Govt_Total")) / vDivisor, 2)
                '    drRef.Close() 'PY_GSIS_TABLE
                'End If
                ''''''''''''''''''''''  END FOR GOVERNMENT USE ONLY '''''''''''''''''''''''''''''''''''''''''
            End If   'normal payroll

                'Withholding tax
                vEmp.TAX = 0
                If dr("Allow_WithTax") <> 0 And vTax Then
                    vFixedEmp = IIf(IsDBNull(dr("FixedTax")), 0, dr("FixedTax"))
                    If vFixedEmp = 0 Then
ComputeTax:
                        If vAnnualized Then
                            ComputeTaxAdj(iEmp)
                            If vReturn <> "" Then GoTo jump
                        Else
                            ComputePeriodicalTax(iEmp, dr("Tax_Cd"), dr("Pay_Cd"))
                            If vReturn <> "" Then GoTo jump
                        End If
                    Else
                        If vFixedEmp > 0 And vFixedEmp < 1 Then   'USE PERCENTAGE
                            vEmp.TAX = Math.Round(dr("Rate_Month") * vFixedEmp, 2)
                        Else  'USE SPECIFIC AMOUNT
                            vEmp.TAX = Math.Round(vFixedEmp, 2)
                        End If

                        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                        '' MODIFIED BY: VIC GATCHALIAN                                ''
                        '' DATE MODIFIED: 2/5/2013                                    ''
                        '' PURPOSE: TO SUPPORT OPTION FOR FIXED TAX APPLIED TO EITHER ''
                        ''          BASIC RATE OR BASIC RATE AND USE TAX TABLE FOR    ''
                        ''          OTHER INCOME AND INCENTIVES.                      ''
                        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                        If dr("FixedTax2BasicOnly") = 1 Then
                            vMonth = 0
                            vTaxTmpAmt = vEmp.TAX
                            GoTo ComputeTax
                        End If
                        ''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''
                    End If

                    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                    '' MODIFIED BY: VIC GATCHALIAN                                ''
                    '' DATE MODIFIED: 2/5/2013                                    ''
                    '' PURPOSE: TO SUPPORT OPTION FOR FIXED TAX APPLIED TO EITHER ''
                    ''          BASIC RATE OR BASIC RATE AND USE TAX TABLE FOR    ''
                    ''          OTHER INCOME AND INCENTIVES.                      ''
                    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                    vEmp.TAX += vTaxTmpAmt
                    ''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''
                End If

                ReDim vEmp.Deduct(MaxIdx)

                'Loans and Deductions
                vTotOthDed = 0
                Dim vSpecialPayroll As Boolean = False
                For iCtr = 1 To MaxIdx
                    vEmp.Deduct(iCtr) = 0
                    vDeduction = 0
                    If vOthDedCd(iCtr) <> "" Then
                        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                        '' MODIFIED BY:  VIC GATCHALIAN                                          ''
                        '' DATE MODIFIED: 5/20/2012                                              ''
                        '' PURPOSE: TO CHECK IF THE DEDUCTION IS ALLOWED DURING SPECIAL PAYROLL  ''
                        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                        vSpecialPayroll = False
                        cmRef.CommandText = "select SpecialPayroll from py_loan_ref where Loan_Cd='" & vOthDedCd(iCtr) & "'"
                        drRef = cmRef.ExecuteReader
                        If drRef.Read Then
                            vSpecialPayroll = drRef("SpecialPayroll")
                        End If
                        drRef.Close() 'PY_LOAN_REF

                        If (vSpecialPayroll And Not vRegularPayroll) Or (vRegularPayroll And Not vSpecialPayroll) Then
                            '''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''''''''''

                            vOthDedDist = False
                            'cmRef.CommandText = "select sum(MonthlyAmort) as Total,sum(Amt_Bal) as Total_Bal,Start_Date " & _
                            '    "from py_loan_hdr where Active <> 0 and (Amt_Bal > 0 or Recurring <> 0) and Emp_Cd='" & _
                            '   dr("Emp_Cd") & "' and Loan_Cd='" & vOthDedCd(iCtr) & "' and Start_Date <= '" & _
                            '   Format(CDate(txtPayDate.Text), "yyyy/MM/dd") & "'"
                            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                            '' MODIFIED BY:  VIC GATCHALIAN                                         ''
                            '' DATE MODIFIED:  2/11/2012                                            ''
                            '' PURPOSE:  TO ENSURE THAT THE DATA IS STILL RETRIEVED WHEN THE        ''
                            ''           "TO DATE" DAY VALUE IS LESS THAN THE "FROM DATE" DAY VALUE ''
                            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                            '''''''''''''''''''''''''' ORIGINAL CODE '''''''''''''''''''''''''''''''''
                            'cmRef.CommandText = "select MonthlyAmort as Total,Amt_Bal as Total_Bal,FreqCd,Recurring,Loan_Date " & _
                            '    "from py_loan_hdr where Active <> 0 and (Amt_Bal > 0 or Recurring=1) and Emp_Cd='" & _
                            '    dr("Emp_Cd") & "' and Loan_Cd='" & vOthDedCd(iCtr) & "' and (FreqCd=0 or FreqCd between " & _
                            '    vFrom.Day & " and " & vTo.Day & ") "
                            '''''''''''''''''''''''''' END ORIGINAL CODE '''''''''''''''''''''''''''''

                            If vTo.Day < vFrom.Day Then
                                cmRef.CommandText = "select MonthlyAmort as Total,Amt_Bal as Total_Bal,FreqCd,Recurring,Loan_Date " & _
                                    "from py_loan_hdr where Start_Date <= '" & Format(vTo, "yyyy/MM/dd") & _
                                    "' and Active <> 0 and (Amt_Bal > 0 or Recurring=1) and Emp_Cd='" & _
                                    dr("Emp_Cd") & "' and Loan_Cd='" & vOthDedCd(iCtr) & "' and (FreqCd=0 or FreqCd=" & vTo.Day & ") "
                            Else
                                cmRef.CommandText = "select MonthlyAmort as Total,Amt_Bal as Total_Bal,FreqCd,Recurring,Loan_Date " & _
                                    "from py_loan_hdr where Start_Date <= '" & Format(vTo, "yyyy/MM/dd") & _
                                    "' and Active <> 0 and (Amt_Bal > 0 or Recurring=1) and Emp_Cd='" & _
                                    dr("Emp_Cd") & "' and Loan_Cd='" & vOthDedCd(iCtr) & "' and (FreqCd=0 or FreqCd between " & _
                                    vFrom.Day & " and " & vTo.Day & ") "
                            End If
                            '''''''''''''''''''''''''' END OF MODIFICATION  ''''''''''''''''''''''''''
                            ' and '" & _
                            'Format(CDate(txtPayDate.Text), "yyyy/MM/dd") & "' >= Start_Date and End_Date >= '" & _
                            'Format(CDate(txtPayDate.Text), "yyyy/MM/dd") & "'"

                            'cmRef.CommandText = "select MonthlyAmort as Total,Amt_Bal as Total_Bal,FreqCd,Recurring,Loan_Date " & _
                            '    "from py_loan_hdr where Active <> 0 and Amt_Bal <> 0 and Emp_Cd='" & _
                            '    dr("Emp_Cd") & "' and Loan_Cd='" & vOthDedCd(iCtr) & "' and Start_Date <='" & _
                            '    Format(vFrom, "yyyy/MM/dd") & "' and End_Date <='" & Format(vTo, "yyyy/MM/dd") & "'"

                            drRef = cmRef.ExecuteReader
                            vEmp.Deduct(iCtr) = 0
                            Do While drRef.Read
                                If drRef("Recurring") <> 0 Then         'fixed deduction

                                    vEmp.Deduct(iCtr) += drRef("Total")
                                Else
                                    'get scedule in loan dtl using empcd,loancd,loandate,trandate
                                    'cm_loan.Connection = c
                                    'cm_loan.CommandText = "Select sum(Amt_Cost) as Amt_Cost from py_loan_dtl where Active<>0 " & _
                                    '    "and Emp_Cd='" & dr("Emp_Cd") & "' and Tran_Date>='" & Format(vFrom, "yyyy/MM/dd") & _
                                    '    "' and Tran_Date<='" & Format(vTo, "yyyy/MM/dd") & "' and Loan_Cd='" & _
                                    '    vOthDedCd(iCtr) & "' and Loan_Date='" & Format(drRef("Loan_Date"), "yyyy/MM/dd") & "'"
                                    'rs_loan = cm_loan.ExecuteReader
                                    'If rs_loan.Read Then
                                    '    If Not IsDBNull(rs_loan("Amt_Cost")) Then
                                    '        vEmp.Deduct(iCtr) += rs_loan("Amt_Cost")
                                    '    End If
                                    'End If
                                    'rs_loan.Close()
                                    'cm_loan.Dispose()
                                    'rs_loan.Close()

                                    '**** Determine if employee's loan balance is less than monthly amortization ****
                                    If drRef("Total") >= drRef("Total_Bal") Then
                                        vEmp.Deduct(iCtr) += drRef("Total_Bal")
                                    Else
                                        vEmp.Deduct(iCtr) += drRef("Total")
                                    End If
                                End If
                            Loop

                            'Do While drRef.Read
                            '    If drRef("Recurring") <> 0 Then         'fixed deduction
                            '        vEmp.Deduct(iCtr) += drRef("Total")
                            '    Else
                            '        'get scedule in loan dtl using empcd,loancd,loandate,trandate
                            '        cm_loan.CommandText = "Select sum(Amt_Cost) as Amt_Cost from py_loan_dtl where Active<>0 and Emp_Cd='" & _
                            '            dr("Emp_Cd") & "' and Tran_Date>='" & Format(vFrom, "yyyy/MM/dd") & "' and Tran_Date<='" & _
                            '            Format(vTo, "yyyy/MM/dd") & "' and Loan_Cd='" & vOthDedCd(iCtr) & "' and Loan_Date='" & _
                            '            Format(drRef("Loan_Date"), "yyyy/MM/dd") & "'"

                            '        rs_loan = cm_loan.ExecuteReader
                            '        If rs_loan.Read Then
                            '            If Not IsDBNull(rs_loan("Amt_Cost")) Then
                            '                vEmp.Deduct(iCtr) += rs_loan("Amt_Cost")
                            '            End If
                            '        End If
                            '        rs_loan.Close()
                            '    End If
                            'Loop
                            drRef.Close()
                        End If
                    End If   'vOthDedCd(iCtr) <> ""
                    vTotOthDed += vEmp.Deduct(iCtr)
                Next iCtr

                'WRITE TO DATABASE
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY:  VIC GATCHALIAN                                    ''
                '' DATE MODIFIED: 5/21/2012                                        ''
                '' PURPOSE: TO ADD THE SERNIORITY ALLOWANCE AS PART OF THE NET PAY ''
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '''''''''''''''''''''' OLD CODE '''''''''''''''''''''''''''''''''''''
                'vTotOthIncent = vTotOthIncent + vEmp.RATA + vEmp.ACA + vEmp.PERA + _
                '   vEmp.MealAllow
                '''''''''''''''''''''' END OLD CODE '''''''''''''''''''''''''''''''''
                vTotOthIncent = vTotOthIncent + vEmp.RATA + vEmp.ACA + vEmp.PERA + _
                   vEmp.MealAllow + vEmp.SeniorAllow
                '''''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''


                'clean record first
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY:  VIC GATCHALIAN                                    ''
                '' DATE MODIFIED: 6/30/2012                                        ''
                '' PURPOSE: TO ADD DETAIL RECORD                                   ''
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                cmRef.CommandText = "delete from py_report_dtl where FromDate='" & Format(vFrom, "yyyy/MM/dd") & _
                    "' and Emp_Cd='" & vEmp.EmpId & "' and PayDate='" & Format(vPayOut, "yyyy/MM/dd") & "'"
                Try
                    cmRef.ExecuteNonQuery()
                Catch ex As SqlClient.SqlException
                    vReturn = ex.Message.Replace("'", "").Replace(vbCrLf, "")
                    GoTo jump
                End Try
                If vEmp.GrossUp Then    'put tax,sss,pagibig,phic and other fringe benefits in detail
                    Try
                        Dim vForex As Decimal = 1
                        Dim vBasicGrossUp As Decimal = 0
                        'check basic pay
                        If vEmp.SalaryCurr <> "PHP" Then
                            cmRef.CommandText = "select Forex from currency_ref where CurrCd='" & vEmp.SalaryCurr & "'"
                            drRef = cmRef.ExecuteReader
                            If drRef.Read Then
                                vForex = drRef("Forex")
                            End If
                            drRef.Close()

                            cmRef.CommandText = "insert into py_report_dtl (Emp_Cd,FromDate,ToDate,PayDate,NormalPayroll," & _
                                "TranType,TranGroup,LineNum,TranCd,TranAmount,TranCurrCd) values ('" & _
                                vEmp.EmpId & "','" & Format(vFrom, "yyyy/MM/dd") & "','" & Format(vTo, "yyyy/MM/dd") & _
                                "','" & Format(vPayOut, "yyyy/MM/dd") & "'," & IIf(vRegularPayroll, 1, 0) & _
                                ",0,'BASIC',1,'BASIC'," & Math.Round(vBasic * vForex, 2) & ",'PHP')"
                            cmRef.ExecuteNonQuery()
                            vBasicGrossUp = Math.Round(vBasic * vForex, 2)
                        End If

                        'other fringe benefits
                        iCtr = 2

                        For iCtr = 0 To UBound(vEmp.NonDeclaredBenefitsCodes)
                            If vEmp.NonDeclaredBenefitsCodes(iCtr) <> "" Then
                                vForex = 1
                                If vEmp.NonDeclaredBenefitsSrcCurr(iCtr) <> "PHP" Then
                                    cmRef.CommandText = "select Forex from currency_ref where CurrCd='" & _
                                        vEmp.NonDeclaredBenefitsSrcCurr(iCtr) & "'"
                                    drRef = cmRef.ExecuteReader
                                    If drRef.Read Then
                                        vForex = drRef("Forex")
                                    End If
                                    drRef.Close()
                                End If
                                cmRef.CommandText = "insert into py_report_dtl (Emp_Cd,FromDate,ToDate,PayDate,NormalPayroll," & _
                                    "TranType,TranGroup,LineNum,TranCd,TranAmount,TranCurrCd) values ('" & _
                                    vEmp.EmpId & "','" & Format(vFrom, "yyyy/MM/dd") & "','" & Format(vTo, "yyyy/MM/dd") & _
                                    "','" & Format(vPayOut, "yyyy/MM/dd") & "'," & IIf(vRegularPayroll, 1, 0) & _
                                    ",0,'NONINC'," & iCtr + 2 & ",'" & vEmp.NonDeclaredBenefitsCodes(iCtr) & _
                                    "'," & Math.Round(vEmp.NonDeclaredBenefits(iCtr) * vForex, 2) & ",'PHP')"
                                cmRef.ExecuteNonQuery()
                            End If
                        Next
                        'insert notional tax
                        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                        '''''  Added By :   Rudner D. Diaz, Jr.                                       ''''
                        '''''  Date     :   July 7, 2012                                              ''''
                        '''''  Reason   :   To support the Gross up type of employee                  ''''
                        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                        If vEmp.NotionalTaxAmount <> 0 Then
                            iCtr += 1
                            cmRef.CommandText = "insert into py_report_dtl(Emp_Cd,FromDate,ToDate,PayDate,NormalPayroll," & _
                                "TranType,TranGroup,LineNum,TranCd,TranAmount,TranCurrCd)values('" & _
                                vEmp.EmpId & "','" & Format(vFrom, "yyyy/MM/dd") & "','" & Format(vTo, "yyyy/MM/dd") & _
                                "','" & Format(vPayOut, "yyyy/MM/dd") & "'," & IIf(vRegularPayroll, 1, 0) & _
                                ",1,'DED'," & iCtr & ",'NotationalTax'," & (vEmp.NotionalTaxAmount * -1) & ",'PHP')"
                            cmRef.ExecuteNonQuery()
                        End If

                        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                        'tax
                        If vEmp.TAX <> 0 Then
                            iCtr += 1
                            cmRef.CommandText = "insert into py_report_dtl (Emp_Cd,FromDate,ToDate,PayDate,NormalPayroll," & _
                                "TranType,TranGroup,LineNum,TranCd,TranAmount,TranCurrCd) values ('" & _
                                vEmp.EmpId & "','" & Format(vFrom, "yyyy/MM/dd") & "','" & Format(vTo, "yyyy/MM/dd") & _
                                "','" & Format(vPayOut, "yyyy/MM/dd") & "'," & IIf(vRegularPayroll, 1, 0) & _
                                ",1,'TAX'," & iCtr & ",'TAX'," & vEmp.TAX & ",'PHP')"
                            cmRef.ExecuteNonQuery()
                            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                            '''''  Added By :   Rudner D. Diaz, Jr.                                       ''''
                            '''''  Date     :   July 7, 2012                                              ''''
                            '''''  Reason   :   To support the Gross up type of employee                  ''''
                            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                            'insert FBT
                            If vEmp.FBTax > 1 Then    ''''' Already in Amount
                                vEmp.FBTaxAmount = vEmp.FBTax
                            Else   '''' In percentage
                                vEmp.FBTaxAmount = vEmp.TAX * vEmp.FBTax
                            End If
                            If vEmp.FBTaxAmount <> 0 Then
                                'insert FB tax
                                iCtr += 1
                                cmRef.CommandText = "insert into py_report_dtl(Emp_Cd,FromDate,ToDate,PayDate,NormalPayroll," & _
                                                "TranType,TranGroup,LineNum,TranCd,TranAmount,TranCurrCd)values('" & _
                                                vEmp.EmpId & "','" & Format(vFrom, "yyyy/MM/dd") & "','" & Format(vTo, "yyyy/MM/dd") & _
                                                "','" & Format(vPayOut, "yyyy/MM/dd") & "'," & IIf(vRegularPayroll, 1, 0) & _
                                                ",1,'DED'," & iCtr & ",'" & "FBTax" & _
                                                "'," & Math.Round(vEmp.FBTaxAmount, 2) & ",'PHP')"
                                cmRef.ExecuteNonQuery()

                                'insert total tax
                                iCtr += 1
                                cmRef.CommandText = "insert into py_report_dtl(Emp_Cd,FromDate,ToDate,PayDate,NormalPayroll," & _
                                                "TranType,TranGroup,LineNum,TranCd,TranAmount,TranCurrCd)values('" & _
                                                vEmp.EmpId & "','" & Format(vFrom, "yyyy/MM/dd") & "','" & Format(vTo, "yyyy/MM/dd") & _
                                                "','" & Format(vPayOut, "yyyy/MM/dd") & "'," & IIf(vRegularPayroll, 1, 0) & _
                                                ",1,'DED'," & iCtr & ",'" & "TOTALTAX" & _
                                                "'," & Math.Round(vEmp.TAX + vEmp.FBTaxAmount, 2) & ",'PHP')"
                                cmRef.ExecuteNonQuery()

                            End If
                        End If


                        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                        'sss employee
                        If vEmp.SSSEmp <> 0 Then
                            iCtr += 1
                            cmRef.CommandText = "insert into py_report_dtl (Emp_Cd,FromDate,ToDate,PayDate,NormalPayroll," & _
                                "TranType,TranGroup,LineNum,TranCd,TranAmount,TranCurrCd) values ('" & _
                                vEmp.EmpId & "','" & Format(vFrom, "yyyy/MM/dd") & "','" & Format(vTo, "yyyy/MM/dd") & _
                                "','" & Format(vPayOut, "yyyy/MM/dd") & "'," & IIf(vRegularPayroll, 1, 0) & _
                                ",1,'CONTR'," & iCtr & ",'SSSEMP'," & vEmp.SSSEmp & ",'PHP')"
                            cmRef.ExecuteNonQuery()
                        End If

                        'sss employer
                        If vEmp.SSSEmr <> 0 Then
                            iCtr += 1
                            cmRef.CommandText = "insert into py_report_dtl (Emp_Cd,FromDate,ToDate,PayDate,NormalPayroll," & _
                                "TranType,TranGroup,LineNum,TranCd,TranAmount,TranCurrCd) values ('" & _
                                vEmp.EmpId & "','" & Format(vFrom, "yyyy/MM/dd") & "','" & Format(vTo, "yyyy/MM/dd") & _
                                "','" & Format(vPayOut, "yyyy/MM/dd") & "'," & IIf(vRegularPayroll, 1, 0) & _
                                ",1,'CONTR'," & iCtr & ",'SSSEMR'," & vEmp.SSSEmr & ",'PHP')"
                            cmRef.ExecuteNonQuery()
                        End If

                        'pagibig employee
                        If vEmp.PagIbigEmp <> 0 Then
                            iCtr += 1
                            cmRef.CommandText = "insert into py_report_dtl (Emp_Cd,FromDate,ToDate,PayDate,NormalPayroll," & _
                                "TranType,TranGroup,LineNum,TranCd,TranAmount,TranCurrCd) values ('" & _
                                vEmp.EmpId & "','" & Format(vFrom, "yyyy/MM/dd") & "','" & Format(vTo, "yyyy/MM/dd") & _
                                "','" & Format(vPayOut, "yyyy/MM/dd") & "'," & IIf(vRegularPayroll, 1, 0) & _
                                ",1,'CONTR'," & iCtr & ",'PAGIBIGEMP'," & vEmp.PagIbigEmp & ",'PHP')"
                            cmRef.ExecuteNonQuery()
                        End If

                        'pagibig employer
                        If vEmp.PagIbigEmr <> 0 Then
                            iCtr += 1
                            cmRef.CommandText = "insert into py_report_dtl (Emp_Cd,FromDate,ToDate,PayDate,NormalPayroll," & _
                                "TranType,TranGroup,LineNum,TranCd,TranAmount,TranCurrCd) values ('" & _
                                vEmp.EmpId & "','" & Format(vFrom, "yyyy/MM/dd") & "','" & Format(vTo, "yyyy/MM/dd") & _
                                "','" & Format(vPayOut, "yyyy/MM/dd") & "'," & IIf(vRegularPayroll, 1, 0) & _
                                ",1,'CONTR'," & iCtr & ",'PAGIBIGEMR'," & vEmp.PagIbigEmr & ",'PHP')"
                            cmRef.ExecuteNonQuery()
                        End If

                        'phic employee
                        If vEmp.MedicareEmp <> 0 Then
                            iCtr += 1
                            cmRef.CommandText = "insert into py_report_dtl (Emp_Cd,FromDate,ToDate,PayDate,NormalPayroll," & _
                                "TranType,TranGroup,LineNum,TranCd,TranAmount,TranCurrCd) values ('" & _
                                vEmp.EmpId & "','" & Format(vFrom, "yyyy/MM/dd") & "','" & Format(vTo, "yyyy/MM/dd") & _
                                "','" & Format(vPayOut, "yyyy/MM/dd") & "'," & IIf(vRegularPayroll, 1, 0) & _
                                ",1,'CONTR'," & iCtr & ",'PHICEMP'," & vEmp.MedicareEmp & ",'PHP')"
                            cmRef.ExecuteNonQuery()
                        End If

                        'phic employer
                        If vEmp.MedicareEmr <> 0 Then
                            iCtr += 1
                            cmRef.CommandText = "insert into py_report_dtl (Emp_Cd,FromDate,ToDate,PayDate,NormalPayroll," & _
                                "TranType,TranGroup,LineNum,TranCd,TranAmount,TranCurrCd) values ('" & _
                                vEmp.EmpId & "','" & Format(vFrom, "yyyy/MM/dd") & "','" & Format(vTo, "yyyy/MM/dd") & _
                                "','" & Format(vPayOut, "yyyy/MM/dd") & "'," & IIf(vRegularPayroll, 1, 0) & _
                                ",1,'CONTR'," & iCtr & ",'PHICEMR'," & vEmp.MedicareEmr & ",'PHP')"
                            cmRef.ExecuteNonQuery()
                        End If
                    Catch ex As SqlClient.SqlException
                        vReturn = ex.Message.Replace("'", "").Replace(vbCrLf, "")
                        GoTo jump
                    End Try
                    vEmp.TAX = 0
                    vEmp.SSSEmp = 0 : vEmp.SSSEmr = 0
                    vEmp.PagIbigEmp = 0 : vEmp.PagIbigEmr = 0
                    vEmp.MedicareEmp = 0 : vEmp.MedicareEmr = 0
                End If
                ''''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''

                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY:  VIC GATCHALIAN                        ''
                '' DATE MODIFIED: 3/2/2012                             ''
                '' PURPOSE:  TO INCLUDE THE UNION DUES CALCULATION     ''
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '''''''''''''''' OLD CODE '''''''''''''''''''''''''''''''
                'vEmp.NetAmount = (vMonth + vTotOthIncent) - _
                '   (vEmp.PagIbigEmp + _
                '   vEmp.MedicareEmp + _
                '   vEmp.TAX + _
                '   vEmp.SSSEmp + _
                '   vEmp.GSISEmp + _
                '   vTotOthDed)
                '''''''''''''''' END OLD CODE ''''''''''''''''''''''''''

                vEmp.NetAmount = (vMonth + vTotOthIncent) - _
                   (vEmp.PagIbigEmp + _
                   vEmp.MedicareEmp + _
                   vEmp.TAX + _
                   vEmp.SSSEmp + _
                   vEmp.GSISEmp + _
                   vEmp.UNIONDUES + _
                   vTotOthDed)
                '''''''''''''''' END OF MODIFICATION '''''''''''''''''''

                'If vEmp.NetAmount < 0 Then
                '    vReturn = "Cannot continue the payroll process because employee " & vEmp.Name & _
                '        " has a negative net pay of " & vEmp.NetAmount
                '    GoTo jump
                'End If

                cmRef.CommandText = "delete from py_report where FromDate='" & Format(vFrom, "yyyy/MM/dd") & _
                    "' and Emp_Cd='" & vEmp.EmpId & "' and PayDate='" & Format(vPayOut, "yyyy/MM/dd") & "'"
                Try
                    cmRef.ExecuteNonQuery()
                Catch ex As SqlClient.SqlException
                    vReturn = ex.Message.Replace("'", "").Replace(vbCrLf, "")
                    GoTo jump
                End Try

                'ADD NEW RECORD TO PY_REPORT
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY:  VIC GATCHALIAN                                    ''
                '' DATE MODIFIED: 3/2/2012                                         ''
                '' PURPOSE: TO EMBED THE COMPUTED UNION DUES                       ''
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '''''''''''''''''''' OLD CODE '''''''''''''''''''''''''''''''''''''''
                'vSQL = "insert into py_report (Report_No,Agency_Cd,Emp_Cd,Name,Position,Emp_Status,Pay_Cd,FromDate," & _
                '   "ToDate,Month_Rate,Amount_Per,Aca,Rata,Pera,With_Tax,Ec,Sss_Per,Sss_Gov,PagIbig_Per," & _
                '   "PagIbig_Gov,Medicare_Per,Medicare_Gov,Gsis_Per,Gsis_Gov,State_Insurance," & _
                '   "Xtra_Hazard,NormalPayroll,Ot,OtLegal,OtOff,OtNd,MealAllow,BasicRate,Tardiness,Rc_Cd," & _
                '   "DivCd,DeptCd,SectionCd,UnitCd,EmploymentType,A1,A2,B1,B2,B3,B4,C1,C2,C3,C4,D1,D2,D3," & _
                '   "D4,E1,E2,E3,E4,F1,F2,F3,F4,G1,G2,G3,G4,NdReg,Absent,PayDate,Tax_Cd,BankCd,BankType,"
                ''''''''''''''''''''' END OLD CODE ''''''''''''''''''''''''''''''''''
                vSQL = "insert into py_report (Report_No,Agency_Cd,Emp_Cd,Name,Position,Emp_Status,Pay_Cd,FromDate,SeniorAllowance," & _
                   "ToDate,Month_Rate,Amount_Per,Aca,Rata,Pera,With_Tax,Ec,Sss_Per,Sss_Gov,PagIbig_Per," & _
                   "PagIbig_Gov,Medicare_Per,Medicare_Gov,Gsis_Per,Gsis_Gov,State_Insurance," & _
                   "Xtra_Hazard,NormalPayroll,Ot,OtLegal,OtOff,OtNd,MealAllow,BasicRate,Tardiness,Rc_Cd," & _
                   "DivCd,DeptCd,SectionCd,UnitCd,EmploymentType,A1,A2,B1,B2,B3,B4,C1,C2,C3,C4,D1,D2,D3," & _
                   "D4,E1,E2,E3,E4,F1,F2,F3,F4,G1,G2,G3,G4,NdReg,Absent,PayDate,Tax_Cd,BankCd,BankType,UnionDues,ProcessedBy,DateProcessed," & _
                   "GrossUp,"
                ''''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''

                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY:  VIC GATCHALIAN                                    ''
                '' DATE MODIFIED: 7/3/2012                                         ''
                '' PURPOSE: TO SAVE MULTI CURRENCY SUPPORT                         ''
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                vSQL += "BasicRateCurrCd,NetPayCurrCd,AcaCurrCd,RataCurrCd,PeraCurrCd,MealAllowCurrCd,TaxCurrCd," & _
                    "SssCurrCd,PagIBIGCurrCd,PHICCurrCd,UnionDuesCurrCd,SeniorAllowCurrCd,"
                ''''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                ' ''Modified By   :    Rudner D. Diaz, Jr                           ''
                ' ''Date          :    July 7, 2012                                 ''
                ' ''Reason        :    Notational and FringeBenifitTax              ''
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                'vSQL += "NotationalTax,FringeBenifitTax,"
                ''''''''''''''''''''END of MOdification''''''''''''''''''''''''''''''

                For iCtr = 1 To MaxIdx
                    vSQL += "Other_Deduct" & iCtr & ",Other_Incent" & iCtr & ","
                Next iCtr
                vSQL = Mid(vSQL, 1, Len(vSQL) - 1) & ") values ("
                With vEmp
                    'ADD NEW RECORD TO PY_REPORT
                    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                    '' MODIFIED BY:  VIC GATCHALIAN                                    ''
                    '' DATE MODIFIED: 3/2/2012                                         ''
                    '' PURPOSE: TO EMBED THE COMPUTED UNION DUES                       ''
                    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                    '''''''''''''''''''' OLD CODE '''''''''''''''''''''''''''''''''''''''
                    'vSQL = vSQL & IIf(.ReportNo = "", "null", "'" & .ReportNo & "'") & ",'" & .Office & "','" & .EmpId & "','" & .Name & "','" & .Position & "','" & _
                    '   .status & "','" & .PayCd & "','" & Format(.From, "yyyy/MM/dd") & "','" & Format(.vTo, "yyyy/MM/dd") & "'," & _
                    '   Math.Round(.MonthRate, 2) & "," & Math.Round(.NetAmount, 2) & "," & Math.Round(.ACA, 2) & "," & Math.Round(.RATA, 2) & "," & _
                    '   Math.Round(.PERA, 2) & "," & Math.Round(.TAX, 2) & "," & Math.Round(vEC, 2) & "," & Math.Round(.SSSEmp, 2) & "," & _
                    '   Math.Round(.SSSEmr, 2) & "," & Math.Round(.PagIbigEmp, 2) & "," & Math.Round(.PagIbigEmr, 2) & "," & _
                    '   Math.Round(.MedicareEmp, 2) & "," & Math.Round(.MedicareEmr, 2) & "," & Math.Round(.GSISEmp, 2) & "," & _
                    '   Math.Round(.GSISEmr, 2) & "," & Math.Round(.StateIns, 2) & "," & Math.Round(.XtraHazard, 2) & "," & _
                    '   IIf(.NormalPay, 1, 0) & "," & Math.Round(.OT, 2) & "," & Math.Round(.OTLegal, 2) & "," & Math.Round(.OTOff, 2) & _
                    '   "," & Math.Round(.OTNight, 2) & "," & Math.Round(.MealAllow, 2) & "," & Math.Round(vBasic, 2) & "," & _
                    '   Math.Round(vTardiness, 2) & ",'" & .RC_CD & "','" & .DivCd & "','" & .DeptCd & _
                    '   "','" & .SectionCd & "','" & .UnitCd & "','" & .EmploymentType & "'," & _
                    '   Math.Round(.A1, 2) & "," & Math.Round(.A2, 2) & "," & _
                    '   Math.Round(.B1, 2) & "," & Math.Round(.B2, 2) & "," & Math.Round(.B3, 2) & "," & Math.Round(.B4, 2) & "," & _
                    '   Math.Round(.C1, 2) & "," & Math.Round(.C2, 2) & "," & Math.Round(.C3, 2) & "," & Math.Round(.C4, 2) & "," & _
                    '   Math.Round(.D1, 2) & "," & Math.Round(.D2, 2) & "," & Math.Round(.D3, 2) & "," & Math.Round(.D4, 2) & "," & _
                    '   Math.Round(.E1, 2) & "," & Math.Round(.E2, 2) & "," & Math.Round(.E3, 2) & "," & Math.Round(.E4, 2) & "," & _
                    '   Math.Round(.F1, 2) & "," & Math.Round(.F2, 2) & "," & Math.Round(.F3, 2) & "," & Math.Round(.F4, 2) & "," & _
                    '   Math.Round(.G1, 2) & "," & Math.Round(.G2, 2) & "," & Math.Round(.G3, 2) & "," & Math.Round(.G4, 2) & "," & _
                    '   Math.Round(.NDREG, 2) & "," & Math.Round(.ABSENT, 2) & ",'" & Format(vPayOut, "yyyy/MM/dd") & _
                    '   "','" & vEmp.TaxCd & "','" & vEmp.BankCd & "','" & vEmp.BankType & "',"
                    ''''''''''''''''''''' END OLD CODE ''''''''''''''''''''''''''''''''''
                    vSQL = vSQL & IIf(.ReportNo = "", "null", "'" & .ReportNo & "'") & ",'" & .Office & "','" & _
                        .EmpId & "','" & .Name & "','" & .Position & "','" & .Status & "','" & .PayCd & "','" & _
                        Format(.From, "yyyy/MM/dd") & "'," & Math.Round(.SeniorAllow, 2) & ",'" & _
                        Format(.vTo, "yyyy/MM/dd") & "'," & Math.Round(.MonthRate, 2) & "," & _
                        Math.Round(.NetAmount, 2) & "," & Math.Round(.ACA, 2) & "," & Math.Round(.RATA, 2) & "," & _
                        Math.Round(.PERA, 2) & "," & Math.Round(.TAX, 2) & "," & Math.Round(vEC, 2) & "," & Math.Round(.SSSEmp, 2) & "," & _
                        Math.Round(.SSSEmr, 2) & "," & Math.Round(.PagIbigEmp, 2) & "," & Math.Round(.PagIbigEmr, 2) & "," & _
                        Math.Round(.MedicareEmp, 2) & "," & Math.Round(.MedicareEmr, 2) & "," & Math.Round(.GSISEmp, 2) & "," & _
                        Math.Round(.GSISEmr, 2) & "," & Math.Round(.StateIns, 2) & "," & Math.Round(.XtraHazard, 2) & "," & _
                        IIf(.NormalPay, 1, 0) & "," & Math.Round(.OT, 2) & "," & Math.Round(.OTLegal, 2) & "," & Math.Round(.OTOff, 2) & _
                        "," & Math.Round(.OTNight, 2) & "," & Math.Round(.MealAllow, 2) & "," & Math.Round(vBasic, 2) & "," & _
                        Math.Round(vTardiness, 2) & ",'" & .RC_CD & "','" & .DivCd & "','" & .DeptCd & _
                        "','" & .SectionCd & "','" & .UnitCd & "','" & .EmploymentType & "'," & _
                        Math.Round(.A1, 2) & "," & Math.Round(.A2, 2) & "," & _
                        Math.Round(.B1, 2) & "," & Math.Round(.B2, 2) & "," & Math.Round(.B3, 2) & "," & Math.Round(.B4, 2) & "," & _
                        Math.Round(.C1, 2) & "," & Math.Round(.C2, 2) & "," & Math.Round(.C3, 2) & "," & Math.Round(.C4, 2) & "," & _
                        Math.Round(.D1, 2) & "," & Math.Round(.D2, 2) & "," & Math.Round(.D3, 2) & "," & Math.Round(.D4, 2) & "," & _
                        Math.Round(.E1, 2) & "," & Math.Round(.E2, 2) & "," & Math.Round(.E3, 2) & "," & Math.Round(.E4, 2) & "," & _
                        Math.Round(.F1, 2) & "," & Math.Round(.F2, 2) & "," & Math.Round(.F3, 2) & "," & Math.Round(.F4, 2) & "," & _
                        Math.Round(.G1, 2) & "," & Math.Round(.G2, 2) & "," & Math.Round(.G3, 2) & "," & Math.Round(.G4, 2) & "," & _
                        Math.Round(.NDREG, 2) & "," & Math.Round(.ABSENT, 2) & ",'" & Format(vPayOut, "yyyy/MM/dd") & _
                        "','" & vEmp.TaxCd & "','" & vEmp.BankCd & "','" & vEmp.BankType & "'," & .UNIONDUES & ",'" & Session("uid") & _
                        "','" & Format(Now, "yyyy/MM/dd HH:mm:ss") & "'," & IIf(vEmp.GrossUp, 1, 0) & ","
                    ''''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''

                    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                    '' MODIFIED BY:  VIC GATCHALIAN                                    ''
                    '' DATE MODIFIED: 7/3/2012                                         ''
                    '' PURPOSE: TO SAVE MULTI CURRENCY SUPPORT                         ''
                    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                    vSQL += "'" & .SalaryCurr & "','" & .NetPayCurr & "','" & .AcaTargetCurr & "','" & _
                        .RataTargetCurr & "','" & .PeraTargetCurr & "','" & .MealTargetCurr & "','" & _
                        .TaxCurr & "','" & .SssCurr & "','" & .PagIBIGCurr & "','" & .PHICCurr & "','" & _
                        .UnionCurr & "','" & .SeniorCurr & "',"
                    ''''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''
                    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                    ' ''Modified By   :    Rudner D. Diaz, Jr                           ''
                    ' ''Date          :    July 7, 2012                                 ''
                    ' ''Reason        :    Notational and FringeBenifitTax              ''
                    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                    'vSQL += Math.Round(.NotionalTaxAmount, 2) & "," & Math.Round(.FBTaxAmount, 2) & ","
                    '''''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''

                    For iCtr = 1 To MaxIdx
                        vSQL = vSQL & Math.Round(.Deduct(iCtr), 2) & "," & Math.Round(.Incentives(iCtr), 2) & ","

                    Next iCtr
                    vSQL = Mid(vSQL, 1, Len(vSQL) - 1) & ")"
                End With
                cmRef.CommandText = vSQL

                Try
                    cmRef.ExecuteNonQuery()
                Catch ex As SqlClient.SqlException
                    vReturn = ex.Message.Replace("'", "").Replace(vbCrLf, "")
                    GoTo jump
                End Try
            End If
        dr.Close()
        cm.Dispose()
        cmRef.Dispose()
        'cm_loan.Dispose()
        c.Close()
        c.Dispose()
        vReturn = "ok"
    End Sub
    Private Sub ComputePeriodicalTax(ByVal iEmp As Integer, ByVal pTaxCd As String, ByVal pPayCd As String)
        Dim vTemp As Decimal = 0
        Dim vTemp1 As Decimal
        Dim cm As New SqlClient.SqlCommand
        Dim dr As SqlClient.SqlDataReader
        Dim vMinWage As Decimal = 0
        Dim vForex As Decimal = 0

        cm.Connection = c
        'vTemp1 = vMonth + vTaxableIncent + vemp.ACA + vemp.RATA + vemp.PERA
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                                    ''
        '' DATE MODIFIED: 5/21/2012                                        ''
        '' PURPOSE: TO ADD THE SENIORITY ALLOWANCE IF IT IS TAXABLE        ''
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '''''''''''''''''''' OLD CODE '''''''''''''''''''''''''''''''''''''''
        'vTemp1 = vMonth + vTaxableIncent 
        '''''''''''''''''''' END OLD CODE '''''''''''''''''''''''''''''''''''
        vTemp1 = vMonth + vTaxableIncent + IIf(vSeniorTaxable, vEmp.SeniorAllow, 0)
        '''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''''

        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                                    ''
        '' DATE MODIFIED: 7/1/2012                                         ''
        '' PURPOSE: TO ADD OTHER FRINGE BENEFITS AS PART OF TAX CALCULATION''
        ''          BUT NOT INCLUDED IN EMPLOYEE'S INCOME.                 ''
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        For ictr As Integer = 0 To UBound(vEmp.NonDeclaredBenefitsCodes)
            If vEmp.NonDeclaredBenefitsCodes(ictr) <> "" Then
                vTemp1 += vEmp.NonDeclaredBenefits(ictr)
            End If
        Next
        ''''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''

        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                                    ''
        '' DATE MODIFIED: 7/3/2012                                         ''
        '' PURPOSE: TO SUPPORT MULTI-CURRENCY                              ''
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        vForex = 1
        If vEmp.TaxCurr <> vEmp.NetPayCurr Then
            cm.CommandText = "select Forex from currency_ref where CurrCd='" & vEmp.NetPayCurr & "'"
            dr = cm.ExecuteReader
            If dr.Read Then
                vForex = dr("Forex")
            End If
            dr.Close()
        End If

        vTemp1 = vTemp1 * vForex

        'deduct notional tax here
        If vEmp.NotionalTax > 1 Then   ''''' already in Amount 
            vEmp.NotionalTaxAmount = vEmp.NotionalTax
        Else   ''''' In Percentage
            vEmp.NotionalTaxAmount = vTemp1 * vEmp.NotionalTax
        End If
        vTemp1 = vTemp1 - Math.Round(vEmp.NotionalTaxAmount, 2)
        ''''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''


        If vAcaTaxable Then
            vTemp1 += vEmp.ACA
        End If
        If vRataTaxable Then
            vTemp1 += vEmp.RATA
        End If
        If vPeraTaxable Then
            vTemp1 += vEmp.PERA
        End If
        If vMealTaxable Then
            vTemp1 += vEmp.MealAllow
        End If

        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY: VIC GATCHALIAN                                         ''
        '' DATE MODIFIED:  1/6/2012                                            ''
        '' PURPOSE: TO SUPPORT NEW GOVERNMENT RULE THAT PAGIBIG CONTRIBUTION   ''
        ''          IN EXCESS OF 100 IS SUBJECT TO TAX                         ''
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        ''''''''''''''''' ORIGINAL CODE '''''''''''''''''''''''''''''''''''''''''
        'vTemp1 = vTemp1 - (vEmp.SSSEmp + vEmp.PagIbigEmp + vEmp.MedicareEmp)
        ''''''''''''''''' END ORIGINAL CODE '''''''''''''''''''''''''''''''''''''

        If vEmp.PagIbigEmp > 100 Then
            vTemp1 = vTemp1 - (vEmp.SSSEmp + 100 + vEmp.MedicareEmp)
        Else
            vTemp1 = vTemp1 - (vEmp.SSSEmp + vEmp.PagIbigEmp + vEmp.MedicareEmp)
        End If
        ''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''''''''''

        cm.Connection = c

        vTemp = 0
        Try
            cm.CommandText = "select MinWageAmount from py_syscntrl"
            dr = cm.ExecuteReader
            If dr.Read Then
                vMinWage = dr("MinWageAmount")
            End If
            dr.Close()

            If vTemp1 > vMinWage Then
                cm.CommandText = "select * from py_tax_table where Freq_Cd='" & pPayCd & _
               "' and Tax_Cd='" & pTaxCd & "' and " & vTemp1 & _
               " >= Check_Amt order by Freq_Cd,Tax_Cd,Seq_No desc"

                dr = cm.ExecuteReader
                If dr.Read Then
                    'get the last record
                    vTemp = (dr("Add_Amt") + (dr("Factor") * (vTemp1 - dr("Check_Amt"))))
                End If
                dr.Close() 'PY_TAX_TABLE
            End If
        Catch ex As SqlClient.SqlException
            vReturn = ex.Message.Replace("'", "").Replace(vbCrLf, "\n")
            vTemp = 0
        Finally
            cm.Dispose()
            vEmp.TAX = Math.Round(vTemp, 2)
            'compute for FBT

        End Try
    End Sub
    Private Sub ComputeTaxAdj(ByVal iEmp As Integer)
        Dim vFixedEmp As Decimal
        Dim vTemp As Decimal
        Dim vTemp2 As Decimal
        Dim vTemp1 As Decimal
        Dim vExempt As Decimal
        Dim vMonths As Integer
        Dim vDistribute As Decimal
        Dim iCtr As Integer
        Dim vPeriod As Integer = 1   'added variable to determine if the current process is 1st period or 2nd period. 9/22/2011 by vic
        Dim vLastBalance As Decimal
        Dim vLastACA As Decimal      'added variable to accrue aca 12/8/06 by vic
        Dim vLastRATA As Decimal     'added variable to accrue rata 12/8/06 by vic
        Dim vLastPERA As Decimal     'added variable to accrue pera 12/8/06 by vic
        Dim vLastMeal As Decimal     'added variable to accrue Meal Allowance 9/19/2011 by vic
        Dim vLastSssEmp As Decimal   'added variable to accrue last SSS 12/11/08 by vic
        Dim vLastHdmfEmp As Decimal  'added variable to accrue last SSS 12/11/08 by vic
        Dim vLastPhicEmp As Decimal  'added variable to accrue last SSS 12/11/08 by vic
        Dim vAddOne As Integer = 0   'added variable to add additional one month accrual for the current pay period 12/11/08 by vic
        Dim vAccrueAmt As Decimal
        Dim vTaxableAmt As Decimal
        Dim vSSS As Decimal
        Dim vPagIBIG As Decimal
        Dim vMedicare As Decimal
        Dim vUnionDues As Decimal
        Dim iGrp As Integer
        Dim vWithTax As Decimal
        Dim vTot As Decimal
        Dim vIndex As Integer
        Dim vPrevGross As Decimal
        Dim vPrevTax As Decimal
        Dim vPrev13Tax As Decimal   'ADDED VARIABLE TO ADD PREV EMPLOYER'S 13TH MONTH TAXABLE 12/8/06 BY VIC
        '''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                  ''
        '' DATE MODIFIED: 1/3/2013                       ''
        '' PURPOSE: TO ADD PREVIOUS EMPLOYER CONTRI.     ''
        '''''''''''''''''''''''''''''''''''''''''''''''''''
        Dim vPrevContr As Decimal = 0
        '''''''''''''' END OF MODIFICAITON ''''''''''''''''

        Dim vCurrTaxable As Decimal
        Dim vAddOtherTaxable As Decimal
        Dim vRatio As Decimal

        Dim cmTax As New SqlClient.SqlCommand
        Dim cmExempt As New SqlClient.SqlCommand
        Dim cmEmp As New SqlClient.SqlCommand
        Dim cm As New SqlClient.SqlCommand

        Dim rsTax As SqlClient.SqlDataReader
        Dim rsExempt As SqlClient.SqlDataReader
        Dim rsEmp As SqlClient.SqlDataReader
        Dim rs As SqlClient.SqlDataReader


        cmTax.Connection = c
        cmExempt.Connection = c
        cmEmp.Connection = c
        cm.Connection = c

        'get net of gross salary of the current period
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                                  ''
        '' DATE MODIFIED: 5/21/2012                                      ''
        '' PURPOSE: TO ADD SENIORITY ALLOWANCE IF IT IS TAXABLE          ''
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '''''''''''''''''''' OLD CODE '''''''''''''''''''''''''''''''''''''
        'vTemp1 = vMonth
        '''''''''''''''''''' END OLD CODE '''''''''''''''''''''''''''''''''
        vTemp1 = vMonth + IIf(vSeniorTaxable, vEmp.SeniorAllow, 0)
        '''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''

        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                                    ''
        '' DATE MODIFIED: 7/1/2012                                         ''
        '' PURPOSE: TO ADD OTHER FRINGE BENEFITS AS PART OF TAX CALCULATION''
        ''          BUT NOT INCLUDED IN EMPLOYEE'S INCOME.                 ''
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        For iCtr = 0 To UBound(vEmp.NonDeclaredBenefitsCodes)
            If vEmp.NonDeclaredBenefitsCodes(iCtr) <> "" Then
                vTemp1 += vEmp.NonDeclaredBenefits(iCtr)
            End If
        Next
        ''''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''

        If vAcaTaxable Then
            vTemp1 += vEmp.ACA
        End If
        If vRataTaxable Then
            vTemp1 += vEmp.RATA
        End If
        If vPeraTaxable Then
            vTemp1 += vEmp.PERA
        End If
        If vMealTaxable Then
            vTemp1 += vEmp.MealAllow
        End If
        
        vTaxableIncent = 0
        For iGrp = 0 To UBound(vTaxGroup)
            vTaxableIncent = vTaxableIncent + vIncentiveTaxable(iGrp)
        Next iGrp
        vTemp1 = vTemp1 + vTaxableIncent - vEmp.SSSEmp - vEmp.PagIbigEmp - vEmp.MedicareEmp - vEmp.UNIONDUES
        vCurrTaxable = vTemp1

        'GET PREVIOUS EMPLOYER'S GROSS,13TH AND TAX
        cm.CommandText = "select * from py_prev_employer_income where Emp_Cd='" & _
           vEmp.EmpId & "' and YearCd=" & vPayOut.Year
        Try
            rs = cm.ExecuteReader
            vPrevGross = 0
            vPrevTax = 0
            If rs.Read Then
                vPrevGross = Math.Round(rs("GrossTaxable"), 2)
                vPrevTax = Math.Round(rs("TaxWithHeld"), 2)

                ''''''''''''''''''''''''''''''''''''''''''
                ''''  MODIFIED BY: VIC GATCHALIAN        '
                ''''  DATE MODIFIED: 9/19/2011           '
                ''''  REASON FOR CHANGE: REMOVED THED    '
                ''''     NON-TAX 13TH MONTH PAY AS PART  '
                ''''     OF THE TAXABLE INCOME           ;
                ''''''''''''''''''''''''''''''''''''''''''
                'vPrev13Tax = Math.Round(rs("Tax13th") + rs("NonTax13th"), 2)   'ADDED BY VIC ON 12/8/06
                '''''''''''' old code ''''''''''''''''''''
                vPrev13Tax = Math.Round(rs("Tax13th"), 2)
                ''''''''''''''''''''''''''''''''''''''''''

                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY:  VIC GATCHALIAN                         ''
                '' DATE MODIFIED: 1/3/2013                              ''
                '' PURPOSE: TO GET THE CONTRIBUTION FROM PREVIOUS EMR   ''
                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                vPrevContr = Math.Round(rs("NonTaxSss"), 2)
                ''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''
            End If
            rs.Close()
        Catch ex As sqlclient.sqlException
            vReturn = ex.Message.Replace(vbCrLf, "\n").Replace("'", "\'")
            c.Close()
            cm.Dispose()
            cmExempt.Dispose()
            cmEmp.Dispose()
            cmTax.Dispose()
            c.Dispose()
            Exit Sub
        End Try

        'GET LAST BALANCE OF BASIC LAST LAST PERIOD PAYROLL GENERATED
        'cm.CommandText = "select sum(Month_Rate),sum(Aca) as Acas,0 as Ratas, sum(Pera) as Peras, " & _
        '   "sum(Sss_Per) as SssEmp,sum(PagIbig_Per) as HdmfEmp,sum(Medicare_Per) as PhicEmp from py_report where Emp_Cd='" & _
        '   vEmp.EmpId & "' and Month(PayDate)=" & vPayOut.Month & " and year(PayDate)=" & vPayOut.Year

        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        ''''''''  MODIFIED BY:  VIC GATCHALIAN                                           '
        ''''''''  DATE MODIFIED:  9/19/2011                                              '
        ''''''''  REASON FOR CHANGE:  ADDED THE MEAL ALLOWANCE FIELD AS PART OF THE      '
        ''''''''                      COMPUTATION                                        '
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        cm.CommandText = "select sum(Month_Rate),sum(Aca) as Acas,0 as Ratas, sum(Pera) as Peras, sum(MealAllow) as Meal," & _
           "sum(Sss_Per) as SssEmp,sum(PagIbig_Per) as HdmfEmp,sum(Medicare_Per) as PhicEmp from py_report where Emp_Cd='" & _
           vEmp.EmpId & "' and Month(PayDate)=" & vPayOut.Month & " and year(PayDate)=" & vPayOut.Year

        vLastBalance = 0
        vLastACA = 0
        vLastRATA = 0
        vLastPERA = 0
        vLastSssEmp = 0
        vLastPhicEmp = 0
        vLastHdmfEmp = 0
        vLastMeal = 0
        Try
            rs = cm.ExecuteReader
            If rs.Read() Then
                If Not IsDBNull(rs(0)) Then vLastBalance = rs(0)
                If Not IsDBNull(rs("Acas")) And vAcaTaxable Then vLastACA = rs("Acas") 'modified by vic on 9/19/2011 by adding the taxability condition 
                If Not IsDBNull(rs("Ratas")) And vRataTaxable Then vLastRATA = rs("Ratas") 'modified by vic on 9/19/2011 by adding the taxability condition 
                If Not IsDBNull(rs("Peras")) And vPeraTaxable Then vLastPERA = rs("Peras") 'modified by vic on 9/19/2011 by adding the taxability condition 
                If Not IsDBNull(rs("Meal")) And vMealTaxable Then vLastMeal = rs("Meal") 'added by vic on 9/19/2011 by adding the taxability condition 
                If Not IsDBNull(rs("SssEmp")) Then vLastSssEmp = rs("SssEmp")
                If Not IsDBNull(rs("HdmfEmp")) Then vLastHdmfEmp = rs("HdmfEmp")
                If Not IsDBNull(rs("PhicEmp")) Then vLastPhicEmp = rs("PhicEmp")
            End If
            rs.Close()
        Catch ex As sqlclient.sqlException
            vReturn = ex.Message.Replace(vbCrLf, "\n").Replace("'", "\'")
            cm.Dispose()
            cmExempt.Dispose()
            cmEmp.Dispose()
            cmTax.Dispose()
            Exit Sub
        End Try

        ''''''''''''''''''''''''''''''''''''''''''''''''''''''
        ''''''' MODIFIED BY: VIC GATCHALIAN                  '
        ''''''' DATE MODIFIED: 9/22/2011                     '
        ''''''' REASON: To determine the payroll period of   '
        '''''''         the current process                  '
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''
        vPeriod = IIf(vLastBalance <> 0, 2, 1)

        'get employee information
        cmEmp.CommandText = "select Rate_Month,Rate_Day,Rate_Year,Aca,Rata,Pera,Allow_Sss,Allow_Pagibig," & _
            "Allow_Medicare,FixedSss_Emp,FixedSss_Emr,FixedHealth_Emp,FixedHealth_Emr," & _
            "FixedPagibig_Emp,FixedPagibig_Emr,Tax_Cd from py_emp_master where Emp_Cd='" & _
            vEmp.EmpId & "'"
        rsEmp = cmEmp.ExecuteReader
        rsEmp.Read()
        vMonths = 12 - vPayOut.Month
        vAccrueAmt = 0
        'CHECK OPTION ACCRUALS OF OTHER INCENTIVES
        'check rata first
        'If lstIncent.ListItems(1).Checked Then 'accrue rata
        '    vAccrueAmt = vAccrueAmt + (rsEmp("RATA") * 2 * vMonths) + _
        '       ((rsEmp("RATA") * 2) - (vemp.RATA + vLastRATA))
        'End If
        ''check ACA
        'If lstIncent.ListItems(2).Checked Then 'accrue ACA
        '    vAccrueAmt = vAccrueAmt + (rsEmp("ACA") * 2 * vMonths) + _
        '       ((rsEmp("ACA") * 2) - (vemp.ACA + vLastACA))
        'End If
        ''CHECK PERA
        'If lstIncent.ListItems(1).Checked Then 'accrue PERA
        '    vAccrueAmt = vAccrueAmt + (rsEmp("PERA") * 2 * vMonths) + _
        '       ((rsEmp("PERA") * 2) - (vemp.PERA + vLastPERA))
        'End If

        ''CHECK FOR OTHER INCENTIVES
        'For iCtr = 4 To lstIncent.ListItems.Count
        '    If lstIncent.ListItems(iCtr).Checked Then
        '        rs.Open("SELECT sum(INCENTIVE_AMT) FROM PY_INCENTIVES_DTL WHERE INCENTIVE_CD='" & _
        '           lstIncent.ListItems(iCtr) & "' AND EMP_CD='" & vemp.EmpId & _
        '           "' AND YEAR([TO])=" & Year(cmbPayDate), CN, adOpenStatic, adLockReadOnly)
        '        If Not IsNull(rs(0)) Then
        '            If Val(lstIncent.ListItems(iCtr).ListSubItems(3)) > 0 Then
        '                vTemp2 = rs(0) - Val(lstIncent.ListItems(iCtr).ListSubItems(3))
        '                If vTemp2 < 0 Then vTemp2 = 0
        '            Else
        '                vTemp2 = rs(0)
        '            End If
        '            vAccrueAmt = vAccrueAmt + vTemp2
        '        End If
        '        rs.Close()
        '    End If
        'Next iCtr


        vTemp2 = 0
        vSSS = 0
        vPagIBIG = 0
        vMedicare = 0
        vUnionDues = 0
        vAccrueAmt = vTemp1

        If vEmp.DateResigned = Nothing Then 'employee is active
            vAccrueAmt += (rsEmp("Rate_Month") * vMonths)
            '''''''''''''''''''''''''''''''''''''''''''''''''''
            '''''''' include assumed SC and assumed BONUS    ''
            '''''''' MODIFIED BY: VIC GATCHALIAN             ''
            '''''''' DATE MODIFIED: 9/21/2011                ''
            '''''''' EXCEPTION: FOR DIAMOND HOTEL USE ONLY   ''
            ''''''''            WORK-AROUND SOLUTION. NEED   ''
            ''''''''            TO BE FIXED.                 ''
            '''''''''''''''''''''''''''''''''''''''''''''''''''
            'If vWithSC Then 'DATE MODIFIED: 10/5/2011 by vic g.
            '    vAccrueAmt += (18000 * (vMonths + IIf(vPeriod = 1, 0.5, 0))) 'ASSUMED SERVICE CHARGE
            'End If
            '''''''''''''  END OF WORK-AROUND '''''''''''''''''

            If (rsEmp("Rate_Month") - (vLastBalance + vEmp.MonthRate)) > 0 Then
                vAccrueAmt += (rsEmp("Rate_Month") - (vLastBalance + vEmp.MonthRate))
            End If

            '''''''''''''''''''''''''''''''''''''''''''''''''''
            '''''   MODIFIED BY: VIC GATCHALIAN               '
            '''''   DATE MODIFIED: 9/19/2011                  '
            '''''   REASON FOR CHANGE:  ADDED THE ACCRUALS    '
            '''''     OF ACA,RATA,PERA,MEAL ALLOWANCE         '
            '''''''''''''''''''''''''''''''''''''''''''''''''''
            If vAcaTaxable Then
                vAccrueAmt += (rsEmp("ACA") * vMonths)
                If rsEmp("ACA") - (vLastACA + vEmp.ACA) > 0 Then
                    vAccrueAmt += (rsEmp("ACA") - (vLastACA + vEmp.ACA))
                End If
            End If
            If vRataTaxable Then
                vAccrueAmt += (rsEmp("RATA") * vMonths)
                If rsEmp("RATA") - (vLastRATA + vEmp.RATA) > 0 Then
                    vAccrueAmt += (rsEmp("RATA") - (vLastRATA + vEmp.RATA))
                End If
            End If
            If vPeraTaxable Then
                vAccrueAmt += (rsEmp("PERA") * vMonths)
                If rsEmp("PERA") - (vLastPERA + vEmp.PERA) > 0 Then
                    vAccrueAmt += (rsEmp("PERA") - (vLastPERA + vEmp.PERA))
                End If
            End If
            If vMealTaxable Then
                vAccrueAmt += (rsEmp("MealAllow") * vMonths)
                If rsEmp("MealAllow") - (vLastMeal + vEmp.MealAllow) > 0 Then
                    vAccrueAmt += (rsEmp("MealAllow") - (vLastMeal + vEmp.MealAllow))
                End If
            End If
            '''''''''''''''''''''''  end modification '''''''''''''''''''''''''''''''''''

            vTaxableAmt += vAccrueAmt

            '''''  get accrued sss contribution ''''''''''
            vAddOne = 0
            vFixedEmp = IIf(IsDBNull(rsEmp("FixedSss_Emp")), 0, rsEmp("FixedSss_Emp"))
            If rsEmp("Allow_Sss") <> 0 Then
                If vFixedEmp = 0 Then   'USE TABLE
                    cm.CommandText = "select Emp_Ss from py_sss_table where " & rsEmp("Rate_Month") & _
                       " between Min_Amt and Max_Amt"
                    rs = cm.ExecuteReader
                    If rs.Read Then
                        vSSS = rs("Emp_ss")
                    End If
                    rs.Close()
                Else
                    If vFixedEmp > 0 And vFixedEmp < 1 Then   'USE PERCENTAGE
                        vSSS = rsEmp("Rate_Month") * vFixedEmp
                    Else  'USE SPECIFIC AMOUNT
                        vSSS = vFixedEmp
                    End If
                End If
                If vLastSssEmp = 0 And vEmp.SSSEmp = 0 Then  'add to accruals for the current month
                    vAddOne = 1
                End If
                vSSS = vSSS * (vMonths + vAddOne)
            End If

            ''''''' get accrued pagibig contribution  '''''''''
            vAddOne = 0
            vFixedEmp = IIf(IsDBNull(rsEmp("FixedPagIbig_Emp")), 0, rsEmp("FixedPagIbig_Emp"))
            If rsEmp("Allow_Pagibig") <> 0 Then
                If vFixedEmp = 0 Then  'USE TABLE
                    cm.CommandText = "select Pag_Per_Per,Pag_Per_Up from py_deduct"
                    rs = cm.ExecuteReader
                    rs.Read()
                    vTemp = IIf(IsDBNull(rs("Pag_Per_Per")), 0, rs("Pag_Per_Per")) * rsEmp("Rate_Month")
                    vTemp2 = IIf(IsDBNull(rs("Pag_Per_Up")), 0, rs("Pag_Per_Up"))
                    vPagIBIG = IIf(vTemp > vTemp2, vTemp2, vTemp)
                    rs.Close()
                Else
                    If vFixedEmp > 0 And vFixedEmp < 1 Then 'USE PERCENTAGE
                        vPagIBIG = rsEmp("Rate_Month") * vFixedEmp
                    Else  'USE SPECIFIC AMOUNT
                        vPagIBIG = vFixedEmp
                    End If
                End If
                If vLastHdmfEmp = 0 And vEmp.PagIbigEmp = 0 Then 'add to accruals for the current month
                    vAddOne = 1
                End If
                vPagIBIG = vPagIBIG * (vMonths + vAddOne)
            End If

            ''''' get accrued phic constribution '''''''''''''''''''
            vAddOne = 0
            vFixedEmp = IIf(IsDBNull(rsEmp("FixedHealth_Emp")), 0, rsEmp("FixedHealth_Emp"))
            If rsEmp("Allow_Medicare") <> 0 Then
                If vFixedEmp = 0 Then   'USE TABLE
                    cm.CommandText = "select Per_Share from py_philhealth_table where " & rsEmp("Rate_Month") & _
                       " between FromAmt and ToAmt"
                    rs = cm.ExecuteReader
                    If rs.Read Then
                        vMedicare = rs("Per_Share")
                    End If
                    rs.Close()
                Else
                    If vFixedEmp > 0 And vFixedEmp < 1 Then 'USE PERCENTAGE
                        vMedicare = rsEmp("Rate_Month") * vFixedEmp
                    Else  'USE SPECIFIC AMOUNT
                        vMedicare = vFixedEmp
                    End If
                End If
                If vLastPhicEmp = 0 And vEmp.MedicareEmp = 0 Then    'add to accruals for the current month
                    vAddOne = 1
                End If
                vMedicare = vMedicare * (vMonths + vAddOne)
            End If

            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:  VIC GATCHALIAN                            ''
            '' DATE MODIFIED: 12/21/2012                               ''
            '' PURPOSE: TO INCLUDE THE CALCULATION OF ACCRUED UNION    ''
            ''          DUES.                                          ''
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            ''''''''''''' get accrued union dues '''''''''''''''''''
            ''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''
        End If 'employee is active

        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                          ''
        '' DATE MODIFIED: 1/3/2013                               ''
        '' PURPOSE: TO ADD THE DEDUCTION OF UNION DUES AND       ''
        ''          CONTRIBUTIONS FROM PREV EMPLOYER             ''
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '''''''''''''''''' OLD CODE '''''''''''''''''''''''''''''''
        'vTaxableAmt = vTaxableAmt - vSSS - vPagIBIG - vMedicare
        '''''''''''''''''' END OLD CODE '''''''''''''''''''''''''''
        vTaxableAmt = vTaxableAmt - vSSS - vPagIBIG - vMedicare - vUnionDues - vPrevContr
        '''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''

        'ADDED CODE SUMMATION FOR ACA AND PERA BY VIC ON 12/8/06
        cm.CommandText = "select sum(Month_Rate) as Gross, sum(Absent+Tardiness) as Absents," & _
              "sum(Aca) as Acas,sum(RATA) as Ratas,sum(Pera) as Peras,sum(MealAllow) as Meal," & _
              "sum(Ot) as OtTotal," & _
              "sum(Other_Incent1) as Incent1, sum(Other_Incent2) AS Incent2," & _
              "sum(Other_Incent3) as Incent3, sum(Other_Incent4) as Incent4," & _
              "sum(Other_Incent5) as Incent5, sum(Other_Incent6) as Incent6," & _
              "sum(Other_Incent7) as Incent7, sum(Other_Incent8) as Incent8," & _
              "sum(Other_Incent9) as Incent9, sum(Other_Incent10) as Incent10," & _
              "sum(Other_Incent11) as Incent11, sum(Other_Incent12) as Incent12," & _
              "sum(Other_Incent13) as Incent13, sum(Other_Incent14) as Incent14," & _
              "sum(Other_Incent15) as Incent15, sum(Other_Incent16) as Incent16," & _
              "sum(Other_Incent17) as Incent17, sum(Other_Incent18) as Incent18," & _
              "sum(Other_Incent19) as Incent19, sum(Other_Incent20) as Incent20," & _
              "sum(Other_Incent21) as Incent21, sum(Other_Incent22) as Incent22," & _
              "sum(Other_Incent23) as Incent23, sum(Other_Incent24) as Incent24," & _
              "sum(Other_Incent25) as Incent25, sum(Other_Incent26) as Incent26," & _
              "sum(Other_Incent27) as Incent27, sum(Other_Incent28) as Incent28," & _
              "sum(Other_Incent29) as Incent29, sum(Other_Incent30) as Incent30," & _
              "sum(Other_Incent31) as Incent31, sum(Other_Incent32) as Incent32," & _
              "sum(Other_Incent33) as Incent33, sum(Other_Incent34) as Incent34," & _
              "sum(Other_Incent35) as Incent35, sum(Other_Incent36) as Incent36," & _
              "sum(Other_Incent37) as Incent37, sum(Other_Incent38) as Incent38," & _
              "sum(Other_Incent39) as Incent39, sum(Other_Incent40) as Incent40," & _
              "sum(Other_Incent41) as Incent41, sum(Other_Incent42) as Incent42," & _
              "sum(Other_Incent43) as Incent43, sum(Other_Incent44) as Incent44," & _
              "sum(Other_Incent45) as Incent45, sum(Other_Incent46) as Incent46," & _
              "sum(Other_Incent47) as Incent47, sum(Other_Incent48) as Incent48," & _
              "sum(Other_Incent49) as Incent49, sum(Other_Incent50) as Incent50," & _
              "sum(Other_Incent51) as Incent51, sum(Other_Incent52) as Incent52," & _
              "sum(Other_Incent53) as Incent53, sum(Other_Incent54) as Incent54," & _
              "sum(Other_Incent55) as Incent55, sum(Other_Incent56) as Incent56," & _
              "sum(Other_Incent57) as Incent57, sum(Other_Incent58) as Incent58," & _
              "sum(Other_Incent59) as Incent59, sum(Other_Incent60) as Incent60," & _
              "sum(SeniorAllowance) as Senior, sum(UnionDues) as Union_Dues," & _
              "sum(With_Tax) as WithTax, sum(Sss_Per) as SssEmp,  " & _
              "sum(Pagibig_Per) as PagibigEmp,sum(Medicare_Per) as MedEmp, " & _
              "sum(Gsis_Per) as GsisEmp,  sum(With_Tax + SSS_Per + PagIbig_Per + " & _
              "Medicare_Per + Gsis_Per) as TotalDeduct from py_report " & _
              "where year(PayDate)=" & vPayOut.Year & _
              " and Emp_Cd='" & vEmp.EmpId & "'"

        rs = cm.ExecuteReader

        vAddOtherTaxable = 0
        If rs.Read Then
            Dim vIncentList() As String
            'GET TAXABLE INCOME BY GROUP
            For iGrp = 0 To UBound(vTaxGroup)
                vTot = 0
                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY:  VIC GATCHALIAN                               ''
                '' DATE MODIFIED: 12/21/2012                                  ''
                '' PURPOSE: TO INCLUDE THE SENIOR ALLOWANCE IF TAX GROUP      ''
                ''          IS ZERO (0)                                       ''
                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                If Val(vTaxGroup(iGrp)) = 0 Then
                    If Not IsDBNull(rs("Senior")) Then
                        vTot = rs("Senior")
                    End If
                End If
                ''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''''
                vIncentList = vIncentives(iGrp).Split(",")
                For iCtr = 0 To UBound(vIncentList)
                    vIndex = GetNumber(vIncentList(iCtr))
                    If vReturn <> "" Then
                        Exit Sub
                    End If
                    If vIndex > 0 Then
                        ''''''''''''''''''''''''''''''''''''''''''''''''''''
                        '''''  MODIFIED BY:  VIC GATCHALIAN                '
                        '''''  DATE MODIFIED: 9/21/2011                    '
                        '''''  EXPLANATION: TO PLUG-IN ASSUMED MID-BONUS   '
                        '''''               AND ASSUMED 13TH MONTH         '
                        '''''  EXCEPTION: FOR DIAMOND USE ONLY WORK-AROUND '
                        ''''''''''''''''''''''''''''''''''''''''''''''''''''
                        ''''''''''' ORIGINAL CODE ''''''''''''''''''''''''''
                        If Not IsDBNull(rs("Incent" & vIndex)) Then
                            vTot += rs("Incent" & vIndex)
                        End If
                        ''''''''''' END ORIGINAL CODE ''''''''''''''''''''''

                        'If vEmp.DateResigned <> Nothing Then
                        '    vTot = vTot + IIf(IsDBNull(rs("Incent" & vIndex)), 0, rs("Incent" & vIndex))
                        'Else
                        '    If vIndex <> 1 And vIndex <> 15 Then 'temporary work-around (1=13th month, 15=mid bonus)
                        '        vTot = vTot + IIf(IsDBNull(rs("Incent" & vIndex)), 0, rs("Incent" & vIndex))
                        '    End If

                        '    If vTaxGroup(iGrp) = 30000 Then
                        '        Dim vBalance As Decimal = 0

                        '        If Not IsDBNull(rs("Incent" & vIndex)) Then
                        '            If rs("Incent" & vIndex) <> 0 Then
                        '                'get the remaining balance and distribute till the rest of the months
                        '                vBalance = rsEmp("Rate_Month") - rs("Incent" & vIndex)
                        '            Else
                        '                vBalance = rsEmp("Rate_Month")
                        '            End If
                        '        Else
                        '            vBalance = rsEmp("Rate_Month")
                        '        End If

                        '        If vIndex = 1 Or vIndex = 15 Then   '13th month and mid-bonus
                        '            vTot = vTot + vBalance
                        '        End If
                        '    End If
                        'End If
                        '''''''''''''''''''' end of modification '''''''''''
                    End If
                Next iCtr

                'THE FOLLOWING CODE ADDS THE ACA AND PERA AS 0 EXEMPTION TAXABLE (FOR GXS USE ONLY)
                '12/8/06
                'If vTaxGroup(iGrp) = 0 Then vTot = vTot + IIf(IsDBNull(rs("Acas")), 0, rs("Acas")) + _
                '   IIf(IsDBNull(rs("Peras")), 0, rs("Peras"))
                'THE FOLLOWING CODE ADDS THE EMPLOYEE'S PREV EMPLOYER'S 13TH MONTH TAXABLE INCOME
                '12/8/06
                If vTaxGroup(iGrp) = 30000 Then vTot = vTot + vPrev13Tax
                If Val(vTaxGroup(iGrp)) > 0 Then
                    If vTot - Val(vTaxGroup(iGrp)) < 0 Then
                        vTot = 0
                    Else
                        vTot = vTot - Val(vTaxGroup(iGrp))
                    End If
                End If
                vAddOtherTaxable = vAddOtherTaxable + vTot
            Next iGrp

            vTaxableAmt += vAddOtherTaxable
            If vAcaTaxable And Not IsDBNull(rs("Acas")) Then
                vTaxableAmt += rs("Acas")
            End If
            If vRataTaxable And Not IsDBNull(rs("Ratas")) Then
                vTaxableAmt += rs("Ratas")
            End If
            If vPeraTaxable And Not IsDBNull(rs("Peras")) Then
                vTaxableAmt += rs("Peras")
            End If
            If vMealTaxable And Not IsDBNull(rs("Meal")) Then
                vTaxableAmt += rs("Meal")
            End If

            vWithTax = IIf(IsDBNull(rs("WithTax")), 0, rs("WithTax"))
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:  VIC GATCHALIAN                                  ''
            '' DATE MODIFIED: 12/21/2012                                     ''
            '' PURPOSE: TO ADD UNION DUES IN THE DEDUCTION LIST              ''
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '''''''''''''''''' OLD CODE '''''''''''''''''''''''''''''''''''''''
            'vTaxableAmt = vTaxableAmt + IIf(IsDBNull(rs("Gross")), 0, rs("Gross")) + _
            '   IIf(IsDBNull(rs("Absents")), 0, rs("Absents")) + _
            '   IIf(IsDBNull(rs("OtTotal")), 0, rs("OtTotal")) - _
            '   (IIf(IsDBNull(rs("SssEmp")), 0, rs("SssEmp")) + _
            '   IIf(IsDBNull(rs("PagibigEmp")), 0, rs("PagibigEmp")) + _
            '   IIf(IsDBNull(rs("MedEmp")), 0, rs("MedEmp")))
            '''''''''''''''''' END OLD CODE '''''''''''''''''''''''''''''''''''
            vTaxableAmt = vTaxableAmt + IIf(IsDBNull(rs("Gross")), 0, rs("Gross")) + _
               IIf(IsDBNull(rs("Absents")), 0, rs("Absents")) + _
               IIf(IsDBNull(rs("OtTotal")), 0, rs("OtTotal")) - _
               (IIf(IsDBNull(rs("SssEmp")), 0, rs("SssEmp")) + _
               IIf(IsDBNull(rs("PagibigEmp")), 0, rs("PagibigEmp")) + _
               IIf(IsDBNull(rs("MedEmp")), 0, rs("MedEmp")) + _
               IIf(IsDBNull(rs("Union_Dues")), 0, rs("Union_Dues")))
            '''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''''
        End If
        rs.Close()

        'get exemption
        cmExempt.CommandText = "select Exemption from py_tax_ref where Tax_Cd='" & rsEmp("Tax_Cd") & "'"
        rsExempt = cmExempt.ExecuteReader
        vExempt = 0
        If rsExempt.Read Then
            vExempt = IIf(IsDBNull(rsExempt("Exemption")), 0, rsExempt("Exemption"))
        End If
        rsExempt.Close()
        rsEmp.Close()


        'get health premiums exemptions
        cmExempt.CommandText = "select sum(Amount) as Amt from py_other_premiums where Emp_Id='" & _
            vEmp.EmpId & "'"
        rsExempt = cmExempt.ExecuteReader
        If rsExempt.Read Then
            vExempt += IIf(IsDBNull(rsExempt("Amt")), 0, rsExempt("Amt"))
        End If
        rsExempt.Close()

        vTaxableAmt = vTaxableAmt + vPrevGross - vExempt

        'GET TAX TABLE BASED ON GROSS AND ANNUAL TAX
        cmTax.CommandText = "select * from py_tax_table where Freq_Cd = 'ANNUAL' " & _
             "and Tax_Cd='ANNUAL' and " & vTaxableAmt & " >= Check_Amt order by Check_Amt desc"
        rsTax = cmTax.ExecuteReader

        If rsTax.Read Then
            vTemp2 = rsTax("Add_Amt") + _
               (rsTax("Factor") * (vTaxableAmt - rsTax("Check_Amt")))
        Else  'NEGATIVE
            vTemp2 = 0
        End If
        vDistribute = 1
        If vDistributionMode = 0 Then     'distribute equally
            'vDistribute = 13 - vPayOut.Month
            vDistribute = 12 - vPayOut.Month
            vRatio = 1

            If vDistribute = 0 Then
                vDistribute = 1
                vRatio = 1
            Else
                vDistribute += IIf(vPeriod = 1, 1, 0.5)
            End If
        ElseIf vDistributionMode = 1 Then 'distribute proportionately
            vDistribute = 1
            If vAccrueAmt + vTaxableIncent + vCurrTaxable > 0 Then
                vRatio = (vCurrTaxable + vTaxableIncent) / (vAccrueAmt + vTaxableIncent + vCurrTaxable)
            Else
                vRatio = 0
            End If
        Else  'do not distribute
            vDistribute = 1
            vDivide = 1
            vRatio = 1
        End If

        'vemp.TAX = Math.Round(((vTemp2 - vWithTax - vPrevTax) * vRatio / vDistribute) / _
        '   IIf(rdoDist.SelectedValue = 0, vDivide, 1), 2)
        vEmp.TAX = ((vTemp2 - vWithTax - vPrevTax) * vRatio) / vDistribute

        vEmp.TAX = Math.Round(vEmp.TAX / vDivide, 2)
        rsTax.Close()

        cmTax.Dispose()
        cmExempt.Dispose()
        cmEmp.Dispose()
        cm.Dispose()
    End Sub
    Private Function GetNumber(ByVal pIncentive As String) As Integer
        Dim iCtr As Integer
        Dim cm As New sqlclient.sqlCommand
        Dim rsSysCntrl As sqlclient.sqlDataReader

        cm.Connection = c
        cm.CommandText = "select * from py_syscntrl"
        rsSysCntrl = cm.ExecuteReader
        GetNumber = 0
        Try
            rsSysCntrl.Read()

            For iCtr = 1 To 60
                If rsSysCntrl("OthIncent" & iCtr & "Cd") = pIncentive Then
                    GetNumber = iCtr
                    Exit For
                End If
            Next iCtr
            rsSysCntrl.Close()
        Catch ex As sqlclient.sqlException
            vReturn = ex.Message.Replace(vbCrLf, "\n").Replace("'", "\'")
            Return 0
        Finally
            cm.Dispose()
        End Try
    End Function

    Private Function GetOT(ByVal pOTCD As String, ByVal pEmpCd As String) As Decimal
        Dim cm As New SqlClient.SqlCommand
        Dim dr As SqlClient.SqlDataReader

        cm.Connection = c
        cm.CommandText = "select sum(AmtConv),sum(Hrs_Rendered) from py_emp_time_log where Emp_Cd='" & _
            pEmpCd & "' and TranDate between '" & Format(vFrom, "yyyy/MM/dd") & _
            "' and '" & Format(vTo, "yyyy/MM/dd") & _
            "' AND TRANCD='" & pOTCD & "' and Frozen=0"
        GetOT = 0

        Try
            dr = cm.ExecuteReader
            vHrsRendered = 0
            If dr.Read Then
                If Not IsDBNull(dr(0)) Then
                    If Not IsDBNull(dr(1)) Then
                        vHrsRendered = Math.Round(dr(1), 2)
                    End If
                    Return Math.Round(dr(0), 2)
                End If
            End If
            dr.Close()
        Catch ex As SqlClient.SqlException
            vReturn = ex.Message.Replace(vbCrLf, "\n").Replace("'", "")
            Return 0
        Finally
            cm.Dispose()
        End Try
    End Function
End Class
