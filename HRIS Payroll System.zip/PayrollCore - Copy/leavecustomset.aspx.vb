﻿Imports denaro
Partial Class leavecustomset
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Public vDetail As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If
        If Not IsPostBack Then
            lblCaption.Text = "Employee Leave Credits"
            BuildCombo("select Rc_Cd,Descr from rc where Rc_Cd in ('" & _
                Session("rclist").ToString.Replace(",", "','") & "') order by Descr", cmbRC)
            BuildCombo("select AgencyCd,AgencyName from agency where AgencyCd in ('" & _
                Session("agencylist").ToString.Replace(",", "','") & "') order by AgencyName", cmbOfc)
            BuildCombo("select Div_Cd,Descr from hr_div_ref where Div_Cd in ('" & _
                Session("divlist").ToString.Replace(",", "','") & "') order by Descr", cmbDiv)
            BuildCombo("select Dept_Cd,Descr from hr_dept_ref where Dept_Cd in ('" & _
                Session("deptlist").ToString.Replace(",", "','") & "') order by Descr", cmbDept)
            BuildCombo("select Section_Cd,Descr from hr_section_ref where Section_Cd in ('" & _
                Session("sectionlist").ToString.Replace(",", "','") & "') order by Descr", cmbSection)
            BuildCombo("select Unit_Cd,Descr from hr_unit_ref where Unit_Cd in ('" & _
                Session("unitlist").ToString.Replace(",", "','") & "') order by Descr", cmbUnit)
            BuildCombo("select Pos_Cd,Position from py_position_ref order by Position", cmbPos)
            BuildCombo("select EmploymentType,Descr from hr_employment_type where EmploymentType in ('" & _
                Session("typelist").ToString.Replace(",", "','") & "')  ORDER BY Descr", cmbRank)
            BuildCombo("select Status_Code,Descr from py_employee_stat order by Descr", cmbStatus)
            'BuildCombo("select Leave_Cd,Descr from py_leave_ref order by Descr", cmbLeave)


            cmbRC.Items.Add("All")
            cmbOfc.Items.Add("All")
            cmbDiv.Items.Add("All")
            cmbDept.Items.Add("All")
            cmbSection.Items.Add("All")
            cmbUnit.Items.Add("All")
            cmbRC.SelectedValue = "All"
            cmbOfc.SelectedValue = "All"
            cmbDiv.SelectedValue = "All"
            cmbDept.SelectedValue = "All"
            cmbSection.SelectedValue = "All"
            cmbUnit.SelectedValue = "All"
            cmbPos.Items.Add("All")
            cmbPos.SelectedValue = "All"
            cmbRank.Items.Add("All")
            cmbRank.SelectedValue = "All"
            cmbStatus.Items.Add("All")
            cmbStatus.SelectedValue = "All"
            txtLeaveType.Text = Request.Item("LvCode")
            txtLeaveType.Enabled = False

        End If
    End Sub

    Protected Sub cmdRefresh_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdRefresh.Click
        DataRefresh()
    End Sub

    Private Sub Datarefresh()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cLeave As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cmLeave As New SqlClient.SqlCommand
        Dim rsLeave As SqlClient.SqlDataReader
        Dim rs As SqlClient.SqlDataReader
        Dim vFilter As String = ""
        Dim iCtr As Integer = 1
        Dim vLastUpdate As String
        Dim vBasis As String = ""
        Dim vFreq As Single
        'Dim vCredit As Single
        Dim vClass As String = "odd"
        Dim vEffectivityMonths As Integer = 0
        Dim vAvailType As String = ""

        If cmbRC.SelectedValue <> "All" Then
            vFilter += "and Rc_Cd='" & cmbRC.SelectedValue & "' "
        Else
            vFilter += " and Rc_Cd in (select Rc_Cd from rc where rc.Rc_Cd in ('" & _
             Session("rclist").ToString.Replace(",", "','") & "')) "
        End If

        If cmbOfc.SelectedValue <> "All" Then
            vFilter += "and Agency_Cd='" & cmbOfc.SelectedValue & "' "
        Else
            vFilter += "and Agency_Cd in (select AgencyCd from agency where AgencyCd in ('" & _
                Session("agencylist").ToString.Replace(",", "','") & "')) "
        End If

        If cmbDiv.SelectedValue <> "All" Then
            vFilter += "and DivCd='" + cmbDiv.SelectedValue & "' "
        Else
            vFilter += "and DivCd in (select Div_Cd from hr_div_ref where Div_Cd in ('" & _
                Session("divlist").ToString.Replace(",", "','") & "')) "
        End If
        If cmbDept.SelectedValue <> "All" Then
            vFilter += "and DeptCd='" & cmbDept.SelectedValue & "' "
        Else
            vFilter += "and DeptCd in (select Dept_Cd from hr_dept_ref where Dept_Cd in ('" & _
                Session("deptlist").ToString.Replace(",", "','") & "')) "
        End If
        If cmbSection.SelectedValue <> "All" Then
            vFilter += "and SectionCd='" & cmbSection.SelectedValue & "' "
        Else
            vFilter += "and SectionCd in (select Section_Cd from hr_section_ref where Section_Cd in ('" & _
                Session("sectionlist").ToString.Replace(",", "','") & "')) "
        End If

        If cmbUnit.SelectedValue <> "All" Then
            vFilter += "and UnitCd='" & cmbUnit.SelectedValue & "' "
        Else
            vFilter += "and UnitCd in (select Unit_Cd from hr_unit_ref where Unit_Cd in ('" & _
                Session("unitlist").ToString.Replace(",", "','") & "')) "
        End If

        If cmbPos.SelectedValue <> "All" Then
            vFilter += " and Pos_Cd='" & cmbPos.SelectedValue & "' "
        End If
        If cmbRank.SelectedValue <> "All" Then
            vFilter += " and EmploymentType='" & cmbRank.SelectedValue & "' "
        Else
            vFilter += "and EmploymentType in (select EmploymentType from hr_employment_type where EmploymentType in ('" & _
                Session("typelist").ToString.Replace(",", "','") & "'))"
        End If
        If cmbStatus.SelectedValue <> "All" Then
            vFilter += " and Emp_Status='" & cmbStatus.SelectedValue & "' "
        End If

        If txtLname.Text <> "" Then
            vFilter += " and Emp_Lname like '" & txtLname.Text & "%' "
        End If


        cLeave.Open()
        c.Open()
        cm.Connection = c
        cmLeave.Connection = cLeave
        cm.CommandText = "select Emp_Cd,Emp_Lname,Emp_Fname from py_emp_master where Date_Resign is null " & _
            vFilter & " order by Emp_Lname,Emp_Fname"
        rs = cm.ExecuteReader
        vDetail = ""
        Do While rs.Read
            If vClass = "odd" Then
                vClass = "even"
            Else
                vClass = "odd"
            End If

            Dim vMaxCredit As Decimal = 99
            Dim vMonthlyCredit As Decimal = 0
            Dim vConversionBasis As String = ""
            Dim vCashLeaveCredit As Decimal = 0
            Dim vCreditFreq As String = ""
            Dim vResetBasis As String = ""
            Dim vEarnedType As String = 0
            Dim vExpiryDate As String = ""

            cmLeave.CommandText = "select * from py_emp_leave where Emp_Cd='" & _
                rs("Emp_Cd") & "' and Leave_Cd='" & txtLeaveType.Text & "'"
            rsLeave = cmLeave.ExecuteReader
            vLastUpdate = ""
            'vCredit = 0


            vBasis = ""
            vFreq = 0

            If rsLeave.Read Then
                If IsDBNull(rsLeave("LastUpdate")) Then
                    vLastUpdate = ""
                Else
                    vLastUpdate = Format(CDate(rsLeave("LastUpdate")), "MM/dd/yyyy")
                End If

                'vCredit = IIf(IsDBNull(rsLeave("CreditableDays")), 0, rsLeave("CreditableDays"))
                vAvailType = IIf(rsLeave("AvailType") = "1", "Date Hired", "Date Regularized")
                vMaxCredit = IIf(IsDBNull(rsLeave("MaxCredit")), 99, rsLeave("MaxCredit"))
                vMonthlyCredit = IIf(IsDBNull("MonthlyCredit"), 0, rsLeave("MonthlyCredit"))
                vCashLeaveCredit = IIf(IsDBNull("CashLeaveCredit"), 0, rsLeave("CashLeaveCredit"))
                vEffectivityMonths = IIf(IsDBNull(rsLeave("EffectivityMonths")), 12, rsLeave("EffectivityMonths"))
                If rsLeave("ConversionBasis") = 0 Then
                    vConversionBasis = "First Of"
                ElseIf rsLeave("ConversionBasis") = 1 Then
                    vConversionBasis = "Excess of"
                End If

                'Credit Frequency
                If rsLeave("CreditFreq") = 1 Then
                    vCreditFreq = "Monthly"
                ElseIf rsLeave("CreditFreq") = 3 Then
                    vCreditFreq = "Quarterly"
                ElseIf rsLeave("CreditFreq") = 6 Then
                    vCreditFreq = "Semi-Annually"
                ElseIf rsLeave("CreditFreq") = 12 Then
                    vCreditFreq = "Annually"
                End If


                'vBasis = IIf(IsDBNull(rsLeave("Basis")), "", rsLeave("Basis"))

                'vFreq = IIf(IsDBNull(rsLeave("Frequency")), 0, rsLeave("Frequency"))

                'Reset Basis
                If rsLeave("ResetBasis") = 0 Then
                    vResetBasis = "Fiscal Year"
                ElseIf rsLeave("ResetBasis") = 1 Then
                    vResetBasis = "Calendar Year"
                ElseIf rsLeave("ResetBasis") = 2 Then
                    vResetBasis = "Anniv. based on Date Hired"
                ElseIf rsLeave("ResetBasis") = 3 Then
                    vResetBasis = "Anniv. based on Date Regularized"
                End If

                'Basis Description
                'If vResetBasis = "0" Then
                '    vBasis = "Fiscal Year"
                'ElseIf vBasis = "1" Then
                '    vBasis = "Calendar Year"
                'ElseIf vBasis = "2" Then
                '    vBasis = "Date Hired"
                'ElseIf vBasis = "3" Then
                '    vBasis = "Regularization Date"
                'End If
                If rsLeave("EarnedType") = 0 Then
                    vEarnedType = "Accrued/Advance Crediting"
                ElseIf rsLeave("EarnedType") = 1 Then
                    vEarnedType = "Earned every 1st day of the month"
                End If

                If IsDBNull(rsLeave("ExpiryDate")) Then
                    vExpiryDate = ""
                Else
                    vExpiryDate = rsLeave("ExpiryDate")
                End If

                '<th align="center"><input type="checkbox" id="chkAll" name="chkAll" onclick="toggle(this);" /></th>
                '                        <th style="width:80px;">EmpID</th>
                '                        <th style="width:130px;">Last Name</th>
                '                        <th>First Name</th>
                '                        <th style="width:75px;">Last<br>Updated</th>


                '                        <th style="width:70px;">Avail Type</th>
                '                        <th style="width:70px;">Maximum Credit</th>
                '                        <th style="width:70px;">Monthly Credit</th>
                '                        <th style="width:70px;">Cash Leave Credit</th>
                '                        <th style="width:70px;">Effectivity</th>
                '                        <th style="width:70px;">Conversion Basis</th>
                '                        <th style="width:70px;">Credit Frequency</th>
                '                        <th style="width:70px;">Reset Basis</th>
                '                        <th style="width:70px;">Availment Type</th>
                '                        <th style="width:70px;">Earned Type</th>
                '                        <th style="width:70px;">Expiry Date</th>

            End If

            rsLeave.Close()
            vDetail += "<tr class='" & vClass & "'><td class='labelBC' ><input type='checkbox' id='chk_" & iCtr & "' name='chk_" & iCtr & _
                "' onclick='toggle();' value='" & rs("Emp_Cd") & "'/></td>" & _
                "<td class='labelBC' align='center'>" & rs("Emp_Cd") & "</td>" & _
                "<td class='labelBL'  align='left'>&nbsp;" & rs("Emp_Lname") & "</td>" & _
                "<td class='labelBL'  align='left'>&nbsp;" & rs("Emp_Fname") & "</td>" & _
                "<td class='labelBC' >" & vLastUpdate & "&nbsp;</td>" & _
                "<td class='labelBR'  align='right'>" & vMaxCredit & "&nbsp;</td>" & _
                "<td class='labelBR'  align='right'>" & vMonthlyCredit & "&nbsp;</td>" & _
                "<td class='labelBR'  align='right'>" & vCashLeaveCredit & "&nbsp;</td>" & _
                "<td class='labelBR'  align='right'>" & vEffectivityMonths & "&nbsp;</td>" & _
                "<td class='labelBR'  align='right'>" & vConversionBasis & "&nbsp;</td>" & _
                "<td class='labelBR'  align='right'>" & vCreditFreq & "&nbsp;</td>" & _
                "<td class='labelBR'  align='right'>" & vResetBasis & "&nbsp;</td>" & _
                "<td class='labelBR'  align='right'>" & vAvailType & "&nbsp;</td>" & _
                "<td class='labelBR'  align='right'>" & vEarnedType & "&nbsp;</td>" & _
                "<td class='labelBR'  align='right'>" & vExpiryDate & "&nbsp;</td>" & _
                "</tr>"
            rsLeave.Close()
            iCtr += 1
        Loop
        rs.Close()
        c.Close()
        cLeave.Close()
        cmLeave.Dispose()
        cLeave.Dispose()
        cm.Dispose()
        c.Dispose()
        txtRows.Value = iCtr - 1
    End Sub

    Protected Sub cmdReturn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.Click
        vScript = "window.close();"
    End Sub
End Class
