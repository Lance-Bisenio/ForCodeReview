Imports denaro
Partial Class generateletter
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Dim c As New sqlclient.sqlconnection
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Session("uid") = "" Then
                Session("returnaddr") = "generateletter.aspx"
                Server.Transfer("index.aspx")
            End If
            If Not CanRun(Session("caption"), Request.Item("id")) Then
                Session("denied") = "1"
                Server.Transfer("main.aspx")
                Exit Sub
            End If
            txtSearch.Text = Request.ServerVariables("aspsessionid")
            lblCaption.Text = "Generate Templated Letter"
            BuildCombo("select Letter_Cd,Letter_Name from hr_letter_hdr order by Letter_Name", cmbLetter)
            BuildCombo("select Rc_Cd, Descr from rc where Rc_Cd in ('" & _
                   Session("rclist").ToString.Replace(",", "','") & "') order by Descr ", cmbRC)
            BuildCombo("select AgencyCd,AgencyName from agency where Agencycd in ('" & _
                Session("agencylist").ToString.Replace(",", "','") & "') order by AgencyName", cmbOfc)
            BuildCombo("select Div_Cd,Descr from hr_div_ref where Div_Cd in ('" & _
                Session("divlist").ToString.Replace(",", "','") & "') order by Descr", cmbDiv)
            BuildCombo("select Dept_Cd,Descr from hr_dept_ref where Dept_Cd in ('" & _
                Session("deptlist").ToString.Replace(",", "','") & "') order by Descr", cmbDept)
            BuildCombo("select Section_Cd,Descr from hr_section_ref where Section_Cd in ('" & _
                Session("sectionlist").ToString.Replace(",", "','") & "') order by Descr", cmbSection)
            BuildCombo("select Unit_Cd,Descr from hr_unit_ref where Unit_Cd in ('" & _
                Session("unitlist").ToString.Replace(",", "','") & "') order by Descr", cmbUnit)
            BuildCombo("select EmploymentType,Descr from hr_employment_type where EmploymentType in ('" & _
                Session("typelist").ToString.Replace(",", "','") & "') order by Descr", cmbEmpType)
            cmbRC.Items.Add("All")
            cmbRC.SelectedValue = "All"
            cmbOfc.Items.Add("All")
            cmbOfc.SelectedValue = "All"
            cmbDiv.Items.Add("All")
            cmbDiv.SelectedValue = "All"
            cmbDept.Items.Add("All")
            cmbDept.SelectedValue = "All"
            cmbSection.Items.Add("All")
            cmbSection.SelectedValue = "All"
            cmbUnit.Items.Add("All")
            cmbUnit.SelectedValue = "All"
            cmbEmpType.Items.Add("All Types")
            cmbEmpType.SelectedValue = "All Types"
            Session("letter") = "A"
            DataRefresh(Session("letter"))
        End If
    End Sub
    Private Sub SetLetters(ByVal pLetter As String)
        Select Case LCase(pLetter)
            Case "a"
                cmdA.Visible = True
            Case "b"
                cmdB.Visible = True
            Case "c"
                cmdC.Visible = True
            Case "d"
                cmdD.Visible = True
            Case "e"
                cmdE.Visible = True
            Case "f"
                cmdF.Visible = True
            Case "g"
                cmdG.Visible = True
            Case "h"
                cmdH.Visible = True
            Case "i"
                cmdI.Visible = True
            Case "j"
                cmdJ.Visible = True
            Case "k"
                cmdK.Visible = True
            Case "l"
                cmdL.Visible = True
            Case "m"
                cmdM.Visible = True
            Case "n"
                cmdN.Visible = True
            Case "o"
                cmdO.Visible = True
            Case "p"
                cmdP.Visible = True
            Case "q"
                cmdQ.Visible = True
            Case "r"
                cmdR.Visible = True
            Case "s"
                cmdS.Visible = True
            Case "t"
                cmdT.Visible = True
            Case "u"
                cmdU.Visible = True
            Case "v"
                cmdV.Visible = True
            Case "w"
                cmdW.Visible = True
            Case "x"
                cmdX.Visible = True
            Case "y"
                cmdY.Visible = True
            Case "z"
                cmdZ.Visible = True
        End Select
    End Sub
    Private Sub DataRefresh(ByVal pLetter As String)

        Dim cm As New sqlclient.sqlcommand
        Dim dr As sqlclient.sqldatareader
        Dim da As sqlclient.sqldataadapter
        Dim ds As New DataSet
        Dim vSQL As String = ""
        Dim vFilter As String = ""
        Dim vLtrFilter As String = ""
        c.ConnectionString = connStr

        vFilter = " where " & cmbType.SelectedValue & " like '" & pLetter & "%' "
        Select Case Val(cmbStatus.SelectedValue)
            Case 1  'active employees only
                vFilter += " and Date_Resign is null "
                vLtrFilter += " where Date_Resign is null "
            Case 0  'inactive employees only
                vFilter += " and Date_Resign is not null "
                vLtrFilter += " where Date_Resign is not null "
        End Select

        If cmbRC.SelectedValue <> "All" Then   'filter by cost center
            vFilter += " and Rc_Cd='" & cmbRC.SelectedValue & "' "
            vLtrFilter += " and Rc_Cd='" & cmbRC.SelectedValue & "' "
        Else
            vFilter += " and Rc_Cd in ('" & Session("rclist").ToString.Replace(",", "','") & "') "
            vLtrFilter += " and Rc_Cd in ('" & Session("rclist").ToString.Replace(",", "','") & "') "
        End If
        If cmbOfc.SelectedValue <> "All" Then        'filter by office/agency
            vFilter += " and Agency_Cd='" & cmbOfc.SelectedValue & "' "
            vLtrFilter += " and Agency_Cd='" & cmbOfc.SelectedValue & "' "
        Else
            vFilter += " and Agency_Cd in ('" & Session("agencylist").ToString.Replace(",", "','") & "') "
            vLtrFilter += " and Agency_Cd in ('" & Session("agencylist").ToString.Replace(",", "','") & "') "
        End If
        If cmbDiv.SelectedValue <> "All" Then      'filter by division
            vFilter += " and Divcd='" & cmbDiv.SelectedValue & "' "
            vLtrFilter += " and Divcd='" & cmbDiv.SelectedValue & "' "
        Else
            vFilter += " and DivCd in ('" & Session("divlist").ToString.Replace(",", "','") & "') "
            vLtrFilter += " and DivCd in ('" & Session("divlist").ToString.Replace(",", "','") & "') "
        End If
        If cmbDept.SelectedValue <> "All" Then  'filter by departments
            vFilter += " and DeptCd='" & cmbDept.SelectedValue & "' "
            vLtrFilter += " and DeptCd='" & cmbDept.SelectedValue & "' "
        Else
            vFilter += " and DeptCd in ('" & Session("deptlist").ToString.Replace(",", "','") & "') "
            vLtrFilter += " and DeptCd in ('" & Session("deptlist").ToString.Replace(",", "','") & "') "
        End If
        If cmbSection.SelectedValue <> "All" Then 'filter by section
            vFilter += " and SectionCd='" & cmbSection.SelectedValue & "' "
            vLtrFilter += " and SectionCd='" & cmbSection.SelectedValue & "' "
        Else
            vFilter += " and SectionCd in ('" & Session("sectionlist").ToString.Replace(",", "','") & "') "
            vLtrFilter += " and SectionCd in ('" & Session("sectionlist").ToString.Replace(",", "','") & "') "
        End If
        If cmbUnit.SelectedValue <> "All" Then  'filter by units
            vFilter += " and UnitCd='" & cmbUnit.SelectedValue & "' "
            vLtrFilter += " and UnitCd='" & cmbUnit.SelectedValue & "' "
        Else
            vFilter += " and UnitCd in ('" & Session("unitlist").ToString.Replace(",", "','") & "') "
            vLtrFilter += " and UnitCd in ('" & Session("unitlist").ToString.Replace(",", "','") & "') "
        End If
        If cmbEmpType.SelectedValue <> "All Types" Then 'filter by employment types
            vFilter += " and EmploymentType='" & cmbEmpType.SelectedValue & "' "
            vLtrFilter += " and EmploymentType='" & cmbEmpType.SelectedValue & "' "
        Else
            vFilter += " and EmploymentType in ('" & Session("typelist").ToString.Replace(",", "','") & "') "
            vLtrFilter += " and EmploymentType in ('" & Session("typelist").ToString.Replace(",", "','") & "') "
        End If
        vSQL = "select Emp_Cd,Emp_Lname,Emp_Fname from py_emp_master " & vFilter & _
            " order by Emp_Lname,Emp_Fname,Emp_Mname"
        da = New sqlclient.sqldataadapter(vSQL, c)
        da.Fill(ds, "EMP")

        tblEmp.DataSource = ds.Tables("EMP")
        tblEmp.DataBind()
        da.Dispose()
        ds.Dispose()

        c.Open()
        cm.Connection = c
        cm.CommandText = "select distinct substring(Emp_Lname,1,1) as Letters from py_emp_master " & vLtrFilter
        dr = cm.ExecuteReader
        EnableAll(False)
        Do While dr.Read
            SetLetters(dr("Letters"))
        Loop
        dr.Close()
        cm.Dispose()
        c.Close()


    End Sub

    Private Sub cmdA_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdA.Click, _
        cmdB.Click, cmdC.Click, cmdD.Click, cmdE.Click, cmdF.Click, cmdG.Click, cmdH.Click, cmdI.Click, _
        cmdJ.Click, cmdK.Click, cmdL.Click, cmdM.Click, cmdN.Click, cmdO.Click, cmdP.Click, cmdQ.Click, _
        cmdR.Click, cmdS.Click, cmdT.Click, cmdU.Click, cmdV.Click, cmdW.Click, cmdX.Click, cmdY.Click, cmdZ.Click
        Session("letter") = CType(sender, LinkButton).Text
        tblEmp.SelectedIndex = -1
        tblEmp.PageIndex = 0
        DataRefresh(Session("letter"))
    End Sub
    Private Sub EnableAll(Optional ByVal pState As Boolean = False)
        cmdA.Visible = pState : cmdB.Visible = pState : cmdC.Visible = pState : cmdD.Visible = pState
        cmdE.Visible = pState : cmdF.Visible = pState : cmdG.Visible = pState : cmdH.Visible = pState
        cmdI.Visible = pState : cmdJ.Visible = pState : cmdK.Visible = pState : cmdL.Visible = pState
        cmdM.Visible = pState : cmdN.Visible = pState : cmdO.Visible = pState : cmdP.Visible = pState
        cmdQ.Visible = pState : cmdR.Visible = pState : cmdS.Visible = pState : cmdT.Visible = pState
        cmdU.Visible = pState : cmdV.Visible = pState : cmdW.Visible = pState : cmdX.Visible = pState
        cmdY.Visible = pState : cmdZ.Visible = pState
    End Sub

    Private Sub cmdRefresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdRefresh.Click
        tblEmp.SelectedIndex = -1
        tblEmp.PageIndex = 0

        DataRefresh(Session("letter"))
    End Sub

    Protected Sub cmdSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSearch.Click
        Session("letter") = txtSearch.Text
        DataRefresh(txtSearch.Text)
    End Sub

    Protected Sub tblEmp_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles tblEmp.PageIndexChanging
        tblEmp.PageIndex = e.NewPageIndex
        DataRefresh(Session("letter"))
    End Sub


    Protected Sub cmdReturn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.Click
        Session.Remove("letter")
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub cmdGenerate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdGenerate.Click
        Dim vEmpcd As String = tblEmp.SelectedRow.Cells(0).Text 'Convert.ToString(tblEmp.SelectedRow.Cells(0).Text)

        'Response.Write(vEmpcd)
        'vScript = "printpage('" & vEmpcd & "', )"

        vScript = "win=window.open('generateletter_print.aspx?vEmpCd=" & vEmpcd & "&letterCd=" & cmbLetter.SelectedValue & _
            "' ,'winprint','toolbar=no,scrollbar=yes,width=1000,height=600,top=100,left=100'); win.focus();"
        'If tblEmp.SelectedIndex >= 0 Then
        '    Dim cRef As New sqlclient.sqlconnection(connStr)
        '    Dim cm As New sqlclient.sqlcommand
        '    Dim cmEmp As New sqlclient.sqlcommand
        '    Dim drEmp As sqlclient.sqldatareader
        '    Dim dr As sqlclient.sqldatareader
        '    Dim vContent As String = ""
        '    Dim vPrn As New VSPrinter8Lib.VSPrinter
        '    Dim vPDF As New VSPDF8Lib.VSPDF8

        '    c.ConnectionString = connStr
        '    c.Open()
        '    cRef.Open()

        '    cm.Connection = c
        '    cmEmp.Connection = cRef

        '    cmEmp.CommandText = "select * from py_emp_master where Emp_Cd='" & _
        '        tblEmp.SelectedRow.Cells(0).Text & "'"
        '    drEmp = cmEmp.ExecuteReader
        '    If drEmp.Read Then
        '        cm.CommandText = "select Letter_Content from hr_letter_hdr where Letter_Cd='" & _
        '            cmbLetter.SelectedValue & "'"
        '        dr = cm.ExecuteReader

        '        If dr.Read Then
        '            vContent = IIf(IsDBNull(dr("Letter_Content")), "", dr("Letter_Content"))
        '        End If
        '        dr.Close()

        '        cm.CommandText = "select * from hr_letter_dtl where Letter_Cd='" & cmbLetter.SelectedValue & "'"
        '        dr = cm.ExecuteReader
        '        Do While dr.Read
        '            Select Case dr("Find_Var").ToString.ToLower
        '                Case "%date%"
        '                    vContent = vContent.Replace(dr("Find_Var"), Format(Now, "MM/dd/yyyy"))
        '                Case "%time%"
        '                    vContent = vContent.Replace(dr("Find_Var"), Format(Now, "HH:mm:ss"))
        '                Case Else
        '                    Try
        '                        vContent = vContent.Replace(dr("Find_Var"), drEmp(dr("Replace_With")))
        '                    Catch
        '                    End Try
        '            End Select
        '        Loop
        '        dr.Close()
        '    End If
        '    drEmp.Close()
        '    cmEmp.Dispose()
        '    cm.Dispose()

        '    cRef.Close()
        '    cRef.Dispose()
        '    c.Close()


        '    vPrn.Orientation = VSPrinter8Lib.OrientationSettings.orPortrait
        '    vPrn.PaperSize = VSPrinter8Lib.PaperSizeSettings.ppr10x14
        '    vPrn.MarginTop = OneInch
        '    vPrn.MarginBottom = OneInch
        '    vPrn.MarginLeft = OneInch / 2
        '    vPrn.MarginRight = OneInch / 2
        '    vPrn.StartDoc()
        '    vPrn.Paragraph = vContent
        '    vPrn.EndDoc()
        '    vPDF.ConvertDocument(vPrn, Server.MapPath(".") & "/downloads/" & Session("sessionid") & ".pdf")

        '    vScript = "document.getElementById('IFRAME1').src = 'downloads/" & Session("sessionid") & ".pdf';"
        '    vPDF = Nothing
        '    vPrn = Nothing
        'Else
        '    vScript = "alert('You must first select an employee.');"
        'End If
    End Sub
End Class
