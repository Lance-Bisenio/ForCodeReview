Imports denaro
Partial Class loanmonitor
    Inherits System.Web.UI.Page
    Public vScript As String = ""


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If
        If Not CanRun(Session("caption"), Request.Item("id")) Then
            Session("denied") = "1"
            Server.Transfer("main.aspx")
            Exit Sub
        End If

        If Not IsPostBack Then
            'build the reference code
            BuildCombo("select Loan_Cd,Loan_Name from py_loan_ref order by Loan_Name", cmbLoan)
            BuildCombo("select Rc_Cd,Descr from rc where exists (select User_Id from rights_list where User_Id='" & _
                    Session("uid") & "' and property='rc' and Property_Value=Rc_Cd) order by Descr", cmbRC)
            BuildCombo("select AgencyCd,AgencyName from agency where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='agency' and Property_Value=AgencyCd) order by AgencyName", cmbOfc)
            BuildCombo("select Div_Cd,Descr from hr_div_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='division' and Property_Value=Div_Cd) order by Descr", cmbDiv)
            BuildCombo("select Dept_Cd,Descr from hr_dept_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='department' and Property_Value=Dept_Cd) order by Descr", cmbDept)
            BuildCombo("select Section_Cd,Descr from hr_section_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='section' and Property_Value=Section_Cd) order by Descr", cmbSection)
            BuildCombo("select Unit_Cd,Descr from hr_unit_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='unit' and Property_Value=Unit_Cd) order by Descr", cmbUnit)
            BuildCombo("select EmploymentType,Descr from hr_employment_type where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='employmenttype' and Property_Value=EmploymentType) order by Descr", cmbType)
            cmbRC.Items.Add("All")
            cmbRC.SelectedValue = "All"
            cmbOfc.Items.Add("All")
            cmbOfc.SelectedValue = "All"
            cmbDiv.Items.Add("All")
            cmbDiv.SelectedValue = "All"
            cmbDept.Items.Add("All")
            cmbDept.SelectedValue = "All"
            cmbSection.Items.Add("All")
            cmbSection.SelectedValue = "All"
            cmbUnit.Items.Add("All")
            cmbUnit.SelectedValue = "All"
            cmbType.Items.Add("All")
            cmbType.SelectedValue = "All"
            lblCaption.Text = "Loan and Other Deductions Monitoring"
        End If
    End Sub

    Protected Sub DataRefresh(ByVal pLetter As String)
        Dim c As New SqlClient.SqlConnection(connStr)

        cmdApprove.Visible = cmbLoanStatus.SelectedValue = 2
        Dim cm As New SqlClient.SqlCommand
        Dim dr As SqlClient.SqlDataReader
        Dim da As SqlClient.SqlDataAdapter
        Dim ds As New DataSet
        Dim vQry As String = ""
        Dim vFilter As String = " and py_loan_hdr.Emp_Cd in (select Emp_Cd from py_emp_master where " & _
            cmbFilter.SelectedValue & " like '" & pLetter & "%' "
        Dim vSql As String = ""

        If cmbRC.SelectedValue <> "All" Then   'filter by cost center
            vFilter += " and Rc_Cd='" & cmbRC.SelectedValue & "' "
            vQry += " and Rc_Cd='" & cmbRC.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='rc' and Property_Value=Rc_Cd) "
            vQry += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='rc' and Property_Value=Rc_Cd) "
        End If
        If cmbOfc.SelectedValue <> "All" Then        'filter by office/agency
            vFilter += " and Agency_Cd='" & cmbOfc.SelectedValue & "' "
            vQry += " and Agency_Cd='" & cmbOfc.SelectedValue & "' "
        Else
            vFilter += "  and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='agency' and Property_Value=Agency_Cd) "
            vQry += "  and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='agency' and Property_Value=Agency_Cd) "
        End If
        If cmbDiv.SelectedValue <> "All" Then      'filter by division
            vFilter += " and Divcd='" & cmbDiv.SelectedValue & "' "
            vQry += " and Divcd='" & cmbDiv.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='division' and Property_Value=DivCd) "
            vQry += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='division' and Property_Value=DivCd) "
        End If
        If cmbDept.SelectedValue <> "All" Then  'filter by departments
            vFilter += " and DeptCd='" & cmbDept.SelectedValue & "' "
            vQry += " and DeptCd='" & cmbDept.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='department' and Property_Value=DeptCd) "
            vQry += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='department' and Property_Value=DeptCd) "
        End If
        If cmbSection.SelectedValue <> "All" Then 'filter by section
            vFilter += " and SectionCd='" & cmbSection.SelectedValue & "' "
            vQry += " and SectionCd='" & cmbSection.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='section' and Property_Value=SectionCd) "
            vQry += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='section' and Property_Value=SectionCd) "
        End If
        If cmbUnit.SelectedValue <> "All" Then  'filter by units
            vFilter += " and UnitCd='" & cmbUnit.SelectedValue & "' "
            vQry += " and UnitCd='" & cmbUnit.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='unit' and Property_Value=UnitCd) "
            vQry += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='unit' and Property_Value=UnitCd) "
        End If

        If cmbType.SelectedValue <> "All" Then
            vFilter += " and EmploymentType='" & cmbType.SelectedValue & "' "
            vQry += " and EmploymentType='" & cmbType.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='employmenttype' and Property_Value=EmploymentType) "
            vQry += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='employmenttype' and Property_Value=EmploymentType) "
        End If

        vSql = "select Id,py_loan_hdr.Emp_Cd,(Emp_Lname+', '+Emp_Fname) as Name,DocNo,Amt_Bal,FreqCd," & _
            "Amt_Loan,Amt_Paid,convert(datetime,Loan_Date,101) as LoanDate,SrcCurrCd,TargetCurrCd," & _
            "convert(datetime,py_loan_hdr.Start_Date,101) as StartDate,Int_Rate,Month_To_Pay,MonthlyAmort as Amort, " & _
            "convert(datetime,py_loan_hdr.End_Date,101) as EndDate from py_loan_hdr,py_emp_master " & _
            "where (" & IIf(cmbLoanStatus.SelectedValue = 3, "Amt_Bal=0", "Amt_Bal > 0") & _
            " or Recurring=1) and py_loan_hdr.Emp_Cd=py_emp_master.Emp_Cd  " & _
            "and Loan_Cd='" & cmbLoan.SelectedValue & "' and Active=" & _
            IIf(cmbLoanStatus.SelectedValue = 2, 0, IIf(cmbLoanStatus.SelectedValue = 3, 1, cmbLoanStatus.SelectedValue)) & _
            IIf(cmbLoanStatus.SelectedValue = 2, " and UploadedBy is not null ", " ") & vFilter & _
            ")" & _
            " order by Emp_Lname,Emp_Fname"

        txtPSql.Text = vSql

        da = New sqlclient.sqlDataAdapter(vSql, c)
        Try
            da.Fill(ds, "EmpMaster")
            tblEmp.DataSource = ds.Tables("EmpMaster")
            tblEmp.DataBind()
            tblEmp.SelectedIndex = -1
        Catch ex As sqlclient.sqlException
            vScript = "alert('Error occurred while binding the SQL Resultset to Grid. Error is: " & _
                ex.Message.Replace(vbCrLf, "\n").Replace("'", "") & "');"
            da.Dispose()
            ds.Dispose()
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        ds.Dispose()
        da.Dispose()

        Try
            c.Open()
        Catch ex As sqlclient.sqlException
            vScript = "alert('Error occurred while trying to connect to SQL Server. Error is: " & _
                ex.Message.Replace(vbCrLf, "\n") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        cm.Connection = c
        cmdDeactivate.Text = IIf(cmbLoanStatus.SelectedValue = "1", "Deactivate Loan", "Reactivate Loan")
        EnableAll(False)
        cm.CommandText = "select distinct substring(Emp_Lname,1,1) as Letters from py_emp_master where " & _
            "Emp_Cd in (select Emp_Cd from py_loan_hdr where Loan_Cd='" & cmbLoan.SelectedValue & _
            "' and Active=" & IIf(cmbLoanStatus.SelectedValue = 2, 0, cmbLoanStatus.SelectedValue) & _
            IIf(cmbLoanStatus.SelectedValue = 2, " and UploadedBy is not null ", " ") & vQry & ")"

        Try
            dr = cm.ExecuteReader
            Do While dr.Read
                SetLetters(dr("Letters"))
            Loop
            dr.Close()
        Catch ex As sqlclient.sqlException
            vScript = "alert('Error occurred while retrieving Loan Ledger. Error in line 162: " & ex.Message.Replace(vbCrLf, "\n") & "');"
        Finally
            c.Close()
            cm.Dispose()
            c.Dispose()
            cmdEdit.Enabled = tblEmp.Rows.Count > 0
            cmdDel.Enabled = cmdEdit.Enabled
            cmdPrintAll.Enabled = cmdEdit.Enabled
            cmdDeactivate.Enabled = cmdEdit.Enabled
            cmdAdd.Enabled = cmbLoanStatus.SelectedValue = 1
            Session("selectedrc") = cmbRC.SelectedValue
            Session("selectedagency") = cmbOfc.SelectedValue
            Session("selecteddiv") = cmbDiv.SelectedValue
            Session("selecteddept") = cmbDept.SelectedValue
            Session("selectedsection") = cmbSection.SelectedValue
            Session("selectedunit") = cmbUnit.SelectedValue
            Session("selectedrank") = cmbType.SelectedValue
        End Try
    End Sub
    Private Sub SetLetters(ByVal pLetter As String)
        Select Case pLetter.ToLower
            Case "a"
                cmdA.Visible = True
            Case "b"
                cmdB.Visible = True
            Case "c"
                cmdC.Visible = True
            Case "d"
                cmdD.Visible = True
            Case "e"
                cmdE.Visible = True
            Case "f"
                cmdF.Visible = True
            Case "g"
                cmdG.Visible = True
            Case "h"
                cmdH.Visible = True
            Case "i"
                cmdI.Visible = True
            Case "j"
                cmdJ.Visible = True
            Case "k"
                cmdK.Visible = True
            Case "l"
                cmdL.Visible = True
            Case "m"
                cmdM.Visible = True
            Case "n"
                cmdN.Visible = True
            Case "o"
                cmdO.Visible = True
            Case "p"
                cmdP.Visible = True
            Case "q"
                cmdQ.Visible = True
            Case "r"
                cmdR.Visible = True
            Case "s"
                cmdS.Visible = True
            Case "t"
                cmdT.Visible = True
            Case "u"
                cmdU.Visible = True
            Case "v"
                cmdV.Visible = True
            Case "w"
                cmdW.Visible = True
            Case "x"
                cmdX.Visible = True
            Case "y"
                cmdY.Visible = True
            Case "z"
                cmdZ.Visible = True
        End Select
    End Sub
    Protected Sub cmdReturn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.Click
        Session.Remove("sql")
        Session.Remove("postdate")
        Session.Remove("fromdate")
        Session.Remove("todate")
        Session.Remove("letter")
        Session.Remove("selectedrc")
        Session.Remove("selectedagency")
        Session.Remove("selecteddiv")
        Session.Remove("selecteddept")
        Session.Remove("selectedsection")
        Session.Remove("selectedunit")
        Session.Remove("selectedrank")
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub cmdA_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdA.Click, _
        cmdB.Click, cmdC.Click, cmdD.Click, cmdE.Click, cmdF.Click, cmdG.Click, cmdH.Click, cmdI.Click, _
       cmdJ.Click, cmdK.Click, cmdL.Click, cmdM.Click, cmdN.Click, cmdO.Click, cmdP.Click, cmdQ.Click, _
       cmdR.Click, cmdS.Click, cmdT.Click, cmdU.Click, cmdV.Click, cmdW.Click, cmdX.Click, cmdY.Click, cmdZ.Click
        Session("letter") = CType(sender, LinkButton).Text
        tblEmp.SelectedIndex = -1
        txtSearch.Text = CType(sender, LinkButton).Text
        DataRefresh(txtSearch.Text)
        getDetail()
    End Sub
    Private Sub EnableAll(Optional ByVal pState As Boolean = True)
        cmdA.Visible = pState : cmdB.Visible = pState : cmdC.Visible = pState : cmdD.Visible = pState
        cmdE.Visible = pState : cmdF.Visible = pState : cmdG.Visible = pState : cmdH.Visible = pState
        cmdI.Visible = pState : cmdJ.Visible = pState : cmdK.Visible = pState : cmdL.Visible = pState
        cmdM.Visible = pState : cmdN.Visible = pState : cmdO.Visible = pState : cmdP.Visible = pState
        cmdQ.Visible = pState : cmdR.Visible = pState : cmdS.Visible = pState : cmdT.Visible = pState
        cmdU.Visible = pState : cmdV.Visible = pState : cmdW.Visible = pState : cmdX.Visible = pState
        cmdY.Visible = pState : cmdZ.Visible = pState
    End Sub

    Protected Sub cmdEdit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdEdit.Click
        If tblEmp.SelectedIndex >= 0 Then
            Session("mode") = "e"
            Session("tid") = tblEmp.SelectedRow.Cells(0).Text
            Session("loancd") = cmbLoan.SelectedValue

            vScript = "editwin=window.open('modifyloan.aspx'," & _
                "'editwin','toolbar=no,location=no,width=600,height=500,top=100,left=100'); editwin.focus();"
        Else
            vScript = "alert('You must first select an employee to edit.');"
        End If
    End Sub

    Protected Sub cmdAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdAdd.Click
        Session("mode") = "a"
        Session("tid") = ""
        Session("loancd") = cmbLoan.SelectedValue
        vScript = "editwin=window.open('modifyloan.aspx'," & _
            "'editwin','toolbar=no,location=no,width=600,height=500,top=100,left=100'); editwin.focus();"
    End Sub

    Protected Sub cmdDel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDel.Click
        If tblEmp.SelectedIndex >= 0 And tblEmp.SelectedIndex <= tblEmp.Rows.Count Then
            Dim cm As New sqlclient.sqlcommand
            Dim c As New sqlclient.sqlconnection(connStr)

            Try
                c.Open()
            Catch ex As sqlclient.sqlexception
                vScript = "alert('Error occurred while trying to connect to SQL Server. Error is: " & _
                    ex.Message.Replace(vbCrLf, "\n").Replace("'", "") & "');"
                c.Dispose()
                cm.Dispose()
                Exit Sub
            End Try

            cm.Connection = c
            cm.CommandText = "delete from py_loan_hdr where Id=" & _
                tblEmp.SelectedRow.Cells(0).Text & " and Loan_Cd='" & _
                cmbLoan.SelectedValue & "'"

            Try
                cm.ExecuteNonQuery()
            Catch ex As sqlclient.sqlexception
                vScript = "alert('Error occurred while trying delete Loan Ledger header. Error is: " & _
                    ex.Message.Replace(vbCrLf, "\n").Replace("'", "") & "');"
                c.Close()
                c.Dispose()
                cm.Dispose()
                Exit Sub
            End Try

            cm.CommandText = "delete from py_loan_dtl where Emp_Cd='" & _
                tblEmp.SelectedRow.Cells(1).Text & "' and Loan_Cd='" & _
                cmbLoan.SelectedValue & "' and Loan_Date='" & _
                Format(CDate(tblEmp.SelectedRow.Cells(4).Text), "yyyy/MM/dd") & "'"

            Try
                cm.ExecuteNonQuery()
            Catch ex As system.exception
                vScript = "alert('Error occurred while trying delete Loan Ledger Amortization Schedule. Error is: " & _
                    ex.Message.Replace(vbCrLf, "\n").Replace("'", "") & "');"
            Finally
                c.Close()
                c.Dispose()
                cm.Dispose()
                DataRefresh(txtSearch.Text)
                getDetail()
            End Try
        Else
            vScript = "alert('You must first select a record.');"
        End If
    End Sub

    Protected Sub tblEmp_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles tblEmp.PageIndexChanging
        tblEmp.PageIndex = e.NewPageIndex
        tblEmp.SelectedIndex = -1
        DataRefresh(txtSearch.Text)
        getDetail()
    End Sub

    Protected Sub cmdDeactivate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDeactivate.Click
        If tblEmp.SelectedIndex <> -1 And tblEmp.SelectedIndex <= tblEmp.Rows.Count Then
            Dim vActive As String = IIf(cmdDeactivate.Text = "Deactivate Loan", 0, 1)     'reverse the state
            Dim cm As New sqlclient.sqlcommand
            Dim c As New sqlclient.sqlconnection(connStr)

            'cm.CommandText = "update py_loan_hdr set Active=" & vActive & " where Loan_Cd='" & _
            '    cmbLoan.SelectedValue & "' and Emp_Cd='" & _
            '    tblEmp.SelectedRow.Cells(0).Text & "' and Loan_Date='" & _
            '    Format(CDate(tblEmp.SelectedRow.Cells(3).Text), "yyyy/MM/dd") & "'"
            cm.CommandText = "update py_loan_hdr set Active=" & vActive & " where Loan_Cd='" & _
               cmbLoan.SelectedValue & "' and Emp_Cd='" & _
               tblEmp.SelectedRow.Cells(1).Text & "' and Id=" & tblEmp.SelectedRow.Cells(0).Text

            Try
                c.Open()
                cm.Connection = c
                cm.ExecuteNonQuery()
                c.Close()
                vScript = "alert('Loan has been " & IIf(vActive = 1, "deactivated", "reactivated") & " successfully');"
            Catch ex As sqlclient.sqlexception
                vScript = "alert('An error occurred while trying to execute your request. Error is: " & _
                    ex.Message.Replace("'", "") & "');"
            Finally
                c.Dispose()
                cm.Dispose()
                DataRefresh(txtSearch.Text)
                getDetail()
            End Try
        Else
            vScript = "alert('You must first select an employee before deactivating/reactivating the loan.');"
        End If
    End Sub

    Protected Sub cmdSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSearch.Click
        DataRefresh(txtSearch.Text)
        getDetail()
    End Sub

    Protected Sub cmdPrint_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdPrint.Click
        Dim vData As String = ""
        vData = tblEmp.SelectedRow.Cells(0).Text
        vScript = "dedwin=window.open('loanmonitorprint.aspx?m=byEmp&vData=" & vData & "','dedwin','location=no,toolber=no,width=950,height=500,scrollbars=yes'); dedwin.focus();"
    End Sub

    Protected Sub cmdApprove_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdApprove.Click
        If tblEmp.SelectedIndex >= 0 And tblEmp.SelectedIndex <= tblEmp.PageSize Then
            Dim c As New sqlclient.sqlconnection(connStr)
            Dim cm As New sqlclient.sqlcommand("update py_loan_hdr set Active=1 where Loan_Cd='" & _
                cmbLoan.SelectedValue & "' and Emp_Cd='" & tblEmp.SelectedRow.Cells(0).Text & _
                "' and Loan_Date='" & Format(CDate(tblEmp.SelectedRow.Cells(3).Text), "yyyy/MM/dd") & _
                "' and Active=0 and UploadedBy is not null", c)
            Try
                c.Open()
            Catch ex As sqlclient.sqlexception
                vScript = "alert('Error occurred while trying to connect to SQL Server. Error is: " & _
                    ex.Message.Replace(vbCrLf, "\n") & "');"
                c.Dispose()
                cm.Dispose()
                Exit Sub
            End Try

            Try
                cm.ExecuteNonQuery()
                vScript = "alert('Your selected row has been activated.  It will now be included in the Deduction Schedule.');"
                c.Close()
                cm.Dispose()
                c.Dispose()
                DataRefresh(txtSearch.Text)
                getDetail()
            Catch ex As sqlclient.sqlexception
                vScript = "alert('Error occurred while updating Loan Ledger. Error is: " & ex.Message.Replace(vbCrLf, "\n") & "');"
                c.Close()
                cm.Dispose()
                c.Dispose()
            End Try
        Else
            vScript = "alert('You must first select a record to active.');"
        End If
    End Sub

    Protected Sub tblEmp_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tblEmp.SelectedIndexChanged
        getDetail()
        cmdPrint.Enabled = True
    End Sub
    Private Sub getDetail()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim vStr As String = "SELECT Emp_Cd,Tran_Date," & _
            " CASE WHEN Paid=1 THEN 'Paid' ELSE 'Unpaid' END AS Paid,round(Amt_Paid,2) AS Amt_Paid," & _
            "Date_Paid,CASE WHEN Active=1 THEN 'Active' ELSE 'Hold' END AS Active " & _
            ",round(Amt_Cost,2) AS Amt_Cost FROM py_loan_dtl WHERE Emp_Cd is null"

        If tblEmp.SelectedIndex >= 0 And tblEmp.SelectedIndex <= tblEmp.Rows.Count Then
            vStr = "SELECT Emp_Cd,Tran_Date," & _
                " CASE WHEN Paid=1 THEN 'Paid' ELSE 'Unpaid' END AS Paid,round(Amt_Paid,2) AS Amt_Paid," & _
                "Date_Paid,CASE WHEN Active=1 THEN 'Active' ELSE 'Hold' END AS Active " & _
                ",round(Amt_Cost,2) AS Amt_Cost FROM py_loan_dtl WHERE Emp_Cd='" & _
                tblEmp.SelectedRow.Cells(1).Text & "' and Loan_Cd='" & _
                cmbLoan.SelectedValue & "' and Loan_Date='" & _
                Format(CDate(tblEmp.SelectedRow.Cells(4).Text), "yyyy/MM/dd") & "' ORDER BY Tran_Date ASC"

        End If

        Dim da As New sqlclient.sqldataadapter(vStr, c)
        Dim ds As New DataSet

        Try
            da.Fill(ds, "Detail")
            tblDetail.DataSource = ds.Tables("Detail")
            tblDetail.DataBind()
            tblDetail.SelectedIndex = -1
        Catch ex As sqlclient.sqlexception
            vScript = "alert('Error occurred while binding the Loan Amortization Schedule to the grid. Error is: " & _
                ex.Message.Replace(vbCrLf, "\n").Replace("'", "") & "');"
        Finally
            ds.Dispose()
            da.Dispose()
            c.Dispose()
            cmdModifyLoan.Enabled = False
        End Try
    End Sub

    Protected Sub tblDetail_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles tblDetail.PageIndexChanging
        tblDetail.PageIndex = e.NewPageIndex
        tblDetail.SelectedIndex = -1
        getDetail()
    End Sub

    Protected Sub cmdModifyLoan_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdModifyLoan.Click
        If tblDetail.SelectedIndex >= 0 And tblDetail.SelectedIndex <= tblDetail.Rows.Count Then
            Dim vCmd As String = ""
            Dim VEmp As String = tblEmp.SelectedRow.Cells(0).Text
            Dim vAmort As Decimal = Val(tblEmp.SelectedRow.Cells(10).Text)
            Dim vLoanDate As Date = CDate(tblEmp.SelectedRow.Cells(3).Text)
            Dim vTranDate As Date = CDate(tblDetail.SelectedRow.Cells(0).Text)
            Dim vAmt As Decimal = CDbl(tblDetail.SelectedRow.Cells(1).Text)

            If tblDetail.SelectedRow.Cells(5).Text = "Hold" Then
                vCmd = "Activate"
            Else
                vCmd = "Deactivate"
            End If
            vScript = "win=window.open('modifyloansked.aspx?Id=" & VEmp & "&LoanCd=" & cmbLoan.SelectedValue & _
                "&DueDate=" & vTranDate & "&amort=" & vAmort & "&DueAmt=" & vAmt & _
                "&LoanDate=" & vLoanDate & "&vCmd=" & vCmd & _
                "','ModifyLoanSchedule','toolbar=no,scrollbars=yes,top=200,left=200,width=300,height=200'); win.focus();"
        Else
            vScript = "alert('You must first select a loan schedule.');"
        End If
    End Sub

    Protected Sub lnkView_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles lnkView.Click
        Server.Transfer("loanmonitorbyemp.aspx")
    End Sub

    Protected Sub tblDetail_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tblDetail.SelectedIndexChanged
        If tblDetail.SelectedRow.Cells(5).Text = "Active" Then
            cmdModifyLoan.Text = "Suspend Loan Schedule"
        Else
            cmdModifyLoan.Text = "Reactivate Loan Schedule"
        End If
        cmdModifyLoan.Enabled = True
    End Sub

    Protected Sub cmdPrintAll_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdPrintAll.Click
        Session("vPSQL") = txtPSql.Text
        vScript = "dedwin=window.open('loanmonitorprint.aspx?m=byFilter" & _
            "','dedwin','location=no,toolber=no,width=1024,height=500,scrollbars=yes'); dedwin.focus();"
    End Sub
End Class
