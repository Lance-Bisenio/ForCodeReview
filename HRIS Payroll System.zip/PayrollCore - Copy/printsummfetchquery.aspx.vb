﻿Imports denaro
Partial Class printsummfetchquery
    Inherits System.Web.UI.Page
    Public vReturn As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN               ''
        '' DATE MODIFIED: 12/7/2012                   ''
        '' PURPOSE: TO CHECK THE MODE THROWN          ''
        ''''''''''''''''''''''''''''''''''''''''''''''''
        '''''''''' old code ''''''''''''''''''''''''''''
        'If Val(Request.Form("mode")) = 1 Then
        '''''''''' END OLD CODE ''''''''''''''''''''''''
        If Request.Item("r") = "Amount" Then
            '''''''''' END OF MODIFICATION '''''''''''''''''
            GenerateSummary(1)
        Else
            GenerateSummary()
        End If
    End Sub

    Private Sub GenerateSummary(Optional ByVal pMode As Integer = 0)
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cmRef As New SqlClient.SqlCommand
        Dim vSQL As String = ""

        Dim rs As SqlClient.SqlDataReader
        Dim rsRef As SqlClient.SqlDataReader

        Dim iCtr As Integer
        Dim vDutyMealsTotal As Decimal = 0
        Dim vCountAll As Decimal = 0
        Dim vDutyMeals As Decimal = 0
        Dim vCount As Decimal = 0
        Dim vRatePerHr As Decimal

        Dim vTimesched_Count As Decimal = 0
        Dim vTimeLog_Count As Decimal = 0
        Dim vMaxRows As Decimal = 0


        Dim vSub As String = Session("vSub")
        Dim vTmp As String = Session("vTmp")
        Dim vSubs() As String
        Dim vCol() As String
        Dim vCodeList As String = ""
        Dim vValue As Single = 0
        Dim vRemarks As String = ""
        Dim vHrsWork As Decimal = 0
        Dim vColSelected As String = ""

        Dim vStartDate As Date = Session("startdate")
        Dim vEndDate As Date = Session("enddate")
        Dim vFilter As String = Session("filter")
        Dim vReqHrsDay As Decimal

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vReturn = "error"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        cm.Connection = c
        cmRef.Connection = c

        If Request.Item("r") = "Amount" Then
            vColSelected = "AmtConv"
        Else
            vColSelected = "Hrs_Rendered"
        End If


        Try

            If vSub <> "" Then
                vSub = vSub.Substring(0, vSub.Length - 1)
                vSubs = vSub.Split("|")
            End If

            cm.CommandText = "select Emp_Cd, Emp_LName+', '+Emp_Fname as EmpName,Req_Hrs_Day,Rate_Day " & _
                "from py_emp_master where Emp_Cd='" & Request.Form("id") & "'"
            rs = cm.ExecuteReader
            vReturn = ""
            If rs.Read Then
                vCol = vTmp.Split("|")

                'get hours work
                cmRef.CommandText = "select count(distinct Date_Sched) from py_emp_time_sched where Emp_Cd='" & _
                    Request.Form("id") & "' and Date_Sched between '" & Format(vStartDate, "yyyy/MM/dd") & _
                    "' and '" & Format(vEndDate, "yyyy/MM/dd") & "' and Start_Time is not null"
                rsRef = cmRef.ExecuteReader
                vHrsWork = 0
                If rsRef.Read Then
                    If Not IsDBNull(rsRef(0)) Then

                        vHrsWork = rsRef(0) '* 8 'convert to hours
                    End If
                End If
                rsRef.Close()


                'get paid absences
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY:  VIC GATCHALIAN                        ''
                '' DATE MODIFIED: 12/7/2012                            ''
                '' PURPOSE: TO REMOVE THE MODE CHECKING SINCE IT'S     ''
                ''          USELESS.                                   ''
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '''''''''''''''' OLD CODE '''''''''''''''''''''''''''''''
                'If pMode = 0 Then
                '    cmRef.CommandText = "select distinct TranCd,sum(" & vColSelected & ") as TotalHrs from py_time_log_dtl where Emp_Cd='" & _
                '       Request.Form("id") & "' and TranCd in (select Leave_Cd from py_leave_ref) and TranDate between '" & _
                '       Format(vStartDate, "yyyy/MM/dd") & "' and '" & Format(vEndDate, "yyyy/MM/dd") & "' group by TranCd"
                'Else
                '    cmRef.CommandText = "select distinct TranCd,sum(" & vColSelected & ") as TotalHrs from py_emp_time_log where Emp_Cd='" & _
                '       Request.Form("id") & "' and TranCd in (select Leave_Cd from py_leave_ref) and TranDate between '" & _
                '       Format(vStartDate, "yyyy/MM/dd") & "' and '" & Format(vEndDate, "yyyy/MM/dd") & "' group by TranCd"
                'End If
                '''''''''''''''' END OLD CODE '''''''''''''''''''''''''''
                cmRef.CommandText = "select distinct TranCd,sum(Hrs_Rendered) as TotalHrs from py_time_log_dtl where Emp_Cd='" & _
                       Request.Form("id") & "' and TranCd in (select Leave_Cd from py_leave_ref) and TranDate between '" & _
                       Format(vStartDate, "yyyy/MM/dd") & "' and '" & Format(vEndDate, "yyyy/MM/dd") & "' group by TranCd"
                '''''''''''''''' END OF MODIFICATION ''''''''''''''''''''

                vValue = 0
                vRemarks = ""
                rsRef = cmRef.ExecuteReader
                Do While rsRef.Read
                    If Not IsDBNull(rsRef("TotalHrs")) Then
                        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                        '' MODIFIED BY:  VIC GATCHALIAN                              ''
                        '' DATE MODIFIED: 12/7/2012                                  ''
                        '' PURPOSE: TO CONVERT IT TO DAYS                            ''
                        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                        ''''''''''''''''''''' OLD CODE ''''''''''''''''''''''''''''''''
                        'vValue += rsRef("TotalHrs")
                        'vRemarks += rsRef("TranCd") & "=" & rsRef("TotalHrs") & " "
                        ''''''''''''''''''''' END OLD CODE ''''''''''''''''''''''''''''
                        vValue += Math.Round((rsRef("TotalHrs") / 8), 2)
                        vRemarks += rsRef("TranCd") & "=" & Math.Round((rsRef("TotalHrs") / 8), 2) & " "
                        '''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''
                    End If

                Loop
                rsRef.Close()

                'subtract paid absences from total hours work
                vHrsWork -= vValue

                vReturn += rs("EmpName") & "~" '& Session("vSub") & "~" & Session("vTmp") & "~"
                vReturn += "HoursPaid~"

                vReturn += IIf(vValue <> 0, Format(Math.Round(vValue, 2), "##,##0.00"), " ") & "~"

                vReqHrsDay = 8

                If Not IsDBNull(rs("Req_Hrs_Day")) Then
                    vReqHrsDay = rs("Req_Hrs_Day")
                End If
                vRatePerHr = 0
                If Not IsDBNull(rs("Rate_Day")) Then
                    vRatePerHr = rs("Rate_Day") / vReqHrsDay   'hourly rate
                End If

                For iCtr = 1 To UBound(vCol)
                    vSubs = vCol(iCtr).Split("^")

                    cmRef.CommandText = "select OtCd from py_ot_ref where SubTitle='" & vSubs(0) & _
                        "' and GroupName='" & vSubs(1) & "'"
                    rsRef = cmRef.ExecuteReader
                    vCodeList = ""
                    Do While rsRef.Read
                        vCodeList += rsRef("OtCd") & ","
                    Loop
                    rsRef.Close()
                    If vCodeList <> "" Then
                        vCodeList = Mid(vCodeList, 1, Len(vCodeList) - 1)
                    End If
                    

                    If pMode = 1 And vCodeList.Contains("ABSENT") Then
                        cmRef.CommandText = "select sum(hrs_rendered) as TotalHrs from py_emp_time_log where Emp_Cd='" & _
                            Request.Form("id") & "' and TranCd in ('" & vCodeList.Replace(",", "','") & "') and TranDate between '" & _
                            Format(vStartDate, "yyyy/MM/dd") & "' and '" & Format(vEndDate, "yyyy/MM/dd") & "'"
                    Else
                        cmRef.CommandText = "select sum(" & vColSelected & ") as TotalHrs from py_time_log_dtl where Emp_Cd='" & _
                            Request.Form("id") & "' and TranCd in ('" & vCodeList.Replace(",", "','") & "') and TranDate between '" & _
                            Format(vStartDate, "yyyy/MM/dd") & "' and '" & Format(vEndDate, "yyyy/MM/dd") & "'"
                    End If

                    rsRef = cmRef.ExecuteReader
                    vValue = 0
                    If rsRef.Read Then
                        If Not IsDBNull(rsRef("TotalHrs")) Then
                            
                            vValue = rsRef("TotalHrs")
                            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                            '' MODIFIED BY: VIC GATCHALIAN                          ''
                            '' DATE MODIFIED: 2/19/2013                             ''
                            '' PURPOSE: TO CONVERT THE TARDINESS AND UNDERTIME      ''
                            ''          FROM HOURS TO MINUTES.                      ''
                            '' EXCEPTIONS: FOR FASTRAK USE.                         ''
                            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                            'If vCodeList.ToLower.Contains("tard") Or vCodeList.ToLower.Contains("ut") Then
                            '    vValue = Math.Round(vValue * 60, 0)
                            'End If
                            '''''''''''''''' END OF MODIFICATION '''''''''''''''''''''

                            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                            '' MODIFIED BY:  VIC GATCHALIAN                         ''
                            '' DATE MODIFIED: 12/7/2012                             ''
                            '' PURPOSE: TO CONVERT IT TO DAYS WHEN CODELIST IS      ''
                            ''          ABSENT                                      ''
                            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                            ''''''''''''''''' OLD CODE '''''''''''''''''''''''''''''''
                            'vValue = rsRef("TotalHrs")
                            ''''''''''''''''' END OLD CODE '''''''''''''''''''''''''''
                            If vCodeList.Contains("ABSENT") Then
                                vValue = vValue / 8
                            End If
                            ''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''
                        End If
                    End If
                    rsRef.Close()
                    If iCtr = 1 Then    'column is unpaid absences, subtract any value from hours work
                        vHrsWork -= vValue
                        If pMode = 1 Then   'convert it back to amount
                            cmRef.CommandText = "select sum(" & vColSelected & ") as TotalHrs from py_time_log_dtl where Emp_Cd='" & _
                                Request.Form("id") & "' and TranCd in ('" & vCodeList.Replace(",", "','") & "') and TranDate between '" & _
                                Format(vStartDate, "yyyy/MM/dd") & "' and '" & Format(vEndDate, "yyyy/MM/dd") & "'"
                            rsRef = cmRef.ExecuteReader
                            If rsRef.Read Then
                                If Not IsDBNull(rsRef("TotalHrs")) Then vValue = rsRef("TotalHrs")
                            End If
                            rsRef.Close()
                        End If
                    End If
                    vReturn += IIf(vValue <> 0, Format(Math.Round(vValue, 2), "##,##0.00"), " ") & "~"
                Next
                vReturn += vRemarks
            End If
            rs.Close()
            If vReturn <> "" Then
                If vHrsWork < 0 Then vHrsWork = 0
                vReturn = vReturn.Replace("HoursPaid", Format(vHrsWork, "##0.00"))
            End If

        Catch ex As SqlClient.SqlException
            vReturn = "error"
        Finally
            c.Close()
            c.Dispose()
            cm.Dispose()
            cmRef.Dispose()
        End Try
    End Sub
End Class
