Imports denaro
Partial Class apprequirement
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Dim c As New sqlclient.sqlconnection
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If

        If Not IsPostBack Then
            If Not CanRun(Session("caption"), Request.Item("id")) Then
                Session("denied") = "1"
                Server.Transfer("main.aspx")
                Exit Sub
            End If
            lblcaption.text = "Applicant's Document Requirements"
            Dim cm As New sqlclient.sqlcommand
            Dim dr As sqlclient.sqldatareader

            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c
            cm.CommandText = "select * from hr_checklist order by Descr"
            dr = cm.ExecuteReader
            Do While dr.Read
                lstCheckList.Items.Add(dr("CheckListCd") & "=>" & dr("Descr"))
            Loop
            dr.Close()
            cm.Dispose()
            c.Close()
            DataRefresh()
        End If
    End Sub
    Private Sub DataRefresh()
        Dim da As sqlclient.sqldataadapter
        Dim ds As New DataSet
        Dim vSQL As String = "select Request_No,Date_Requested as " & _
            "DateRequested,Date_Required as DateRequired,Number_Needed," & _
            "Position_Cd+'=>'+Position as Pos," & _
            "Rate,Frozen,Requested_By,Void from hr_hiring_request,py_position_ref where  " & _
            "Position_Cd=Pos_Cd  order by Date_Requested desc"
        c.ConnectionString = connStr
        da = New sqlclient.sqldataadapter(vSQL, c)
        da.Fill(ds, "request")
        tblRequest.DataSource = ds.Tables("request")
        tblRequest.DataBind()
        da.Dispose()
        ds.Dispose()
    End Sub

    Protected Sub tblRequest_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles tblRequest.PageIndexChanging
        tblRequest.PageIndex = e.NewPageIndex
        DataRefresh()
    End Sub
    Private Sub RefreshApplicant()
        Dim da As sqlclient.sqldataadapter
        Dim ds As New DataSet
        Dim vReqNo As String = tblRequest.SelectedRow.Cells(0).Text

        c.ConnectionString = connStr
        da = New sqlclient.sqldataadapter("select DateFiled as Date_Filed," & _
            "hr_applicant_master.ApplicantNo,Lname,Fname,Mname,Pos_Cd as Position,Tel,Email," & _
            "DesiredSalaryFrom,DesiredSalaryTo from hr_applicant_master,hr_shortlist where " & _
            "hr_applicant_master.ApplicantNo=" & _
            "hr_shortlist.ApplicantNo and hr_shortlist.RequestNo=" & vReqNo & " order by Lname,Fname", c)
        da.Fill(ds, "applicant")
        tblApplicant.DataSource = ds.Tables("applicant")
        tblApplicant.DataBind()
        ds.Dispose()
        da.Dispose()
    End Sub
    Private Sub RefreshChecklist()
        Dim da As sqlclient.sqlDataAdapter
        Dim ds As New DataSet
        Dim vApplicantNo As String = tblApplicant.SelectedRow.Cells(1).Text

        c.ConnectionString = connStr
        da = New sqlclient.sqlDataAdapter("select CheckListCd,DateFiled as Date_Filed," & _
            "DateSubmitted as Date_Submitted,UpdatedBy,Remarks from " & _
            "hr_applicant_checklist where ApplicantNo=" & vApplicantNo, c)
        da.Fill(ds, "checklist")
        tblChkList.DataSource = ds.Tables("checklist")
        tblChkList.DataBind()
        ds.Dispose()
        da.Dispose()
    End Sub
    Protected Sub tblRequest_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tblRequest.SelectedIndexChanged
        RefreshApplicant()
    End Sub

    Protected Sub tblApplicant_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles tblApplicant.PageIndexChanging
        tblApplicant.PageIndex = e.NewPageIndex
        RefreshApplicant()
    End Sub

    Protected Sub cmdViewReq_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdViewReq.Click
        If tblRequest.SelectedIndex <> -1 And tblRequest.SelectedIndex <= tblRequest.Rows.Count Then
            Session("mode") = "v"
            Session("reqno") = tblRequest.SelectedRow.Cells(0).Text
            vScript = "logwin=window.open('modifypr.aspx','logwin','location=no,toolber=no,width=600,height=468,top=100,left=100');"
        Else
            vScript = "alert('You must first select a Request #.');"
        End If
    End Sub

    Protected Sub cmdGenInfo_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdGenInfo.Click, _
        cmdGenInfo2.Click, cmdEducation.Click, cmdFamily.Click, cmdIdent.Click, cmdRef.Click, cmdSkills.Click, _
        cmdWork.Click

        Dim vASPX As String = ""
        Dim vScale As String = ""
        If tblApplicant.SelectedIndex <> -1 And tblApplicant.SelectedIndex <= tblApplicant.Rows.Count And _
            tblApplicant.Rows.Count > 0 Then
            Session("applicantno") = tblApplicant.SelectedRow.Cells(1).Text
            Select Case CType(sender, System.Web.UI.WebControls.Button).ID.ToLower
                Case "cmdgeninfo"
                    vASPX = "applicantgeninfo.aspx"
                    vScale = "width=700,height=450,top=100,left=100"
                Case "cmdgeninfo2"
                    vASPX = "applicantgeninfo2.aspx"
                    vScale = "width=650,height=280,top=100,left=100"
                Case "cmdeducation"
                    vASPX = "applicanteducation.aspx"

                Case "cmdfamily"
                    vASPX = "applicantfamily.aspx"
                    vScale = "width=700,height=450,top=100,left=100"
                Case "cmdident"
                    vASPX = "applicantident.aspx"
                    vScale = "width=550,height=180,top=200,left=200"
                Case "cmdref"
                    vASPX = "applicantref.aspx"
                    vScale = "width=830,height=270,top=100,left=100"
                Case "cmdskills"
                    vASPX = "applicantskills.aspx"
                    vScale = "width=650,height=450,top=100,left=100"
                Case "cmdwork"
                    vASPX = "applicantwork.aspx"
                    vScale = "width=800,height=450,top=100,left=100"
            End Select
            vScript = "logwin=window.open('" & vASPX & "','logwin','location=no,toolber=no," & _
                vScale & "');"
        Else
            vScript = "alert('You must first select an applicant record to view its information.');"
        End If
    End Sub

    Protected Sub cmdReturn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.Click
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub tblApplicant_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tblApplicant.SelectedIndexChanged
        RefreshChecklist()
    End Sub

    Protected Sub tblChkList_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles tblChkList.PageIndexChanging
        tblChkList.PageIndex = e.NewPageIndex
        RefreshChecklist()
    End Sub

    Protected Sub cmdAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdAdd.Click
        If tblApplicant.SelectedIndex <> -1 And tblApplicant.SelectedIndex <= tblApplicant.Rows.Count And _
            lstCheckList.SelectedIndex <> -1 And tblApplicant.Rows.Count > 0 Then
            Session("doctype") = ExtractData(lstCheckList.SelectedValue)
            Session("applicantno") = tblApplicant.SelectedRow.Cells(1).Text
            Session("mode") = "a"
            vScript = "logwin=window.open('modifychecklist.aspx','logwin','location=no,toolber=no,width=400,height=268,top=100,left=100');"
        Else
            vScript = "alert('You must first select an applicant # and a document type');"
        End If
    End Sub

    Protected Sub cmdEdit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdEdit.Click
        If tblApplicant.SelectedIndex <> -1 And tblApplicant.SelectedIndex <= tblApplicant.Rows.Count And _
            tblApplicant.Rows.Count > 0 And tblChkList.SelectedIndex <> -1 And _
            tblChkList.SelectedIndex <= tblChkList.Rows.Count And tblChkList.Rows.Count > 0 Then
            Session("doctype") = tblChkList.SelectedRow.Cells(0).Text
            Session("applicantno") = tblApplicant.SelectedRow.Cells(1).Text
            Session("mode") = "e"
            vScript = "logwin=window.open('modifychecklist.aspx','logwin','location=no,toolber=no,width=400,height=268,top=100,left=100');"
        Else
            vScript = "alert('You must first select an applicant # and a document type');"
        End If
    End Sub

    Protected Sub cmdDel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDel.Click
        If tblApplicant.SelectedIndex <> -1 And tblApplicant.SelectedIndex <= tblApplicant.Rows.Count And _
                    tblApplicant.Rows.Count > 0 And tblChkList.SelectedIndex <> -1 And _
                    tblChkList.SelectedIndex <= tblChkList.Rows.Count And tblChkList.Rows.Count > 0 Then
            Dim cm As New sqlclient.sqlcommand
            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c
            cm.CommandText = "delete from hr_applicant_checklist where ApplicantNo=" & _
                tblApplicant.SelectedRow.Cells(1).Text & " and CheckListCd='" & _
                tblChkList.SelectedRow.Cells(0).Text & "'"
            cm.ExecuteNonQuery()
            cm.Dispose()
            c.Close()
            RefreshChecklist()
            vScript = "alert('Document was successfully deleted.');"
        Else
            vScript = "alert('You must first select an applicant # and a document type');"
        End If
    End Sub
End Class
