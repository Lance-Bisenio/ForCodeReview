﻿Imports denaro.fis
Partial Class meal
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Public vData As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If

        If Not CanRun(Session("caption"), Request.Item("id")) Then
            Session("denied") = "1"
            Server.Transfer("main.aspx")
            Exit Sub
        End If

        If Not IsPostBack Then
            cmbYearFrom.Items.Clear()
            cmbYearTo.Items.Clear()
            For ictr As Integer = Now.Year To Now.Year - 3 Step -1
                cmbYearFrom.Items.Add(ictr)
                cmbYearTo.Items.Add(ictr)
            Next
            cmbMonthFrom.SelectedValue = Now.Month
            cmbYearFrom.SelectedValue = Now.Year
            cmbMonthTo.SelectedValue = Now.Month
            cmbYearTo.SelectedValue = Now.Year
            cmbMonthFrom_SelectedIndexChanged(sender, e)
            cmbMonthTo_SelectedIndexChanged(sender, e)
            cmbHrTo.SelectedValue = 23
            cmbMinTo.SelectedValue = 59
        End If
    End Sub

    Protected Sub cmbMonthFrom_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbMonthFrom.SelectedIndexChanged, _
        cmbYearFrom.SelectedIndexChanged

        cmbDayFrom.Items.Clear()

        For ictr As Integer = 1 To MonthEND(CDate(cmbMonthFrom.SelectedValue & "/1/" & cmbYearFrom.SelectedValue)).Day
            cmbDayFrom.Items.Add(ictr)
        Next
        cmbDayFrom.SelectedValue = 1
    End Sub

    Protected Sub cmbMonthTo_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbMonthTo.SelectedIndexChanged, _
        cmbYearTo.SelectedIndexChanged

        cmbDayTo.Items.Clear()

        For ictr As Integer = 1 To MonthEND(CDate(cmbMonthTo.SelectedValue & "/1/" & cmbYearTo.SelectedValue)).Day
            cmbDayTo.Items.Add(ictr)
        Next
        cmbDayTo.SelectedValue = Now.Day
    End Sub

    Protected Sub cmdClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdClose.Click
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub cmdGenerate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdGenerate.Click
        If txtIdList.Text.Trim = "" Then
            vScript = "alert('You must enter the Terminal ID to extract.');"
            Exit Sub
        End If

        Dim c As New SqlClient.SqlConnection(System.Configuration.ConfigurationManager.AppSettings.Get("NACconnstr"))
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim vClass As String = "odd"
        Dim iCount As Integer = 0
        Dim vLastEmp As String = ""

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        cm.Connection = c
        cm.CommandText = "select TransactionTime,TerminalId,UserId,(select Name from ngac_userinfo where Id=UserId) as Name " & _
            "from ngac_authlog where AuthResult=0 and TransactionTime between '" & _
            cmbYearFrom.SelectedValue & "/" & cmbMonthFrom.SelectedValue & "/" & cmbDayFrom.SelectedValue & " 00:00:00' and '" & _
            cmbYearTo.SelectedValue & "/" & cmbMonthTo.SelectedValue & "/" & cmbDayTo.SelectedValue & " 23:59:59' " & _
            "order by " & rdoSort.SelectedValue

        Try
            If rdoSort.SelectedIndex = 0 Then
                vData = "<table style='width:100%;' class='mainGridView'>" & _
                    "<tr class='titleBar'>" & _
                    "<th>Employee Id</th>" & _
                    "<th>Employee Name</th>" & _
                    "<th>Transaction Date</th>" & _
                    "<th>Transaction Time</th>" & _
                    "</tr>"
            Else
                vData = "<table style='width:100%;' class='mainGridView'>" & _
                    "<tr class='titleBar'>" & _
                    "<th>Transaction Date</th>" & _
                    "<th>Transaction Time</th>" & _
                    "<th>Employee Id</th>" & _
                    "<th>Employee Name</th>" & _
                    "</tr>"
            End If

            rs = cm.ExecuteReader
            iCount = 0
            Do While rs.Read
                If vLastEmp = "" Then vLastEmp = rs("UserId")
                iCount += 1
                If CDate(rs("TransactionTime")) >= CDate(Format(rs("TransactionTime"), "yyyy/MM/dd") & " " & cmbHrFrom.SelectedValue & ":" & cmbMinFrom.SelectedValue & ":00") And _
                   CDate(rs("TransactionTime")) <= CDate(Format(rs("TransactionTime"), "yyyy/MM/dd") & " " & cmbHrTo.SelectedValue & ":" & cmbMinTo.SelectedValue & ":00") Then
                    If rdoSort.SelectedIndex = 0 Then   'by employee, by date
                        vData &= "<tr class='" & vClass & "'>" & _
                            "<td class='labelC'>" & rs("UserId") & "</td>" & _
                            "<td class='labelL'>" & rs("Name") & "</td>" & _
                            "<td class='labelR'>" & Format(CDate(rs("TransactionTime")), "MM/dd/yyyy") & "</td>" & _
                            "<td class='labelR'>" & Format(CDate(rs("TransactionTime")), "HH:mm:ss") & "</td>" & _
                            "</tr>"
                    Else                                'by date, by employee
                        vData &= "<tr class='" & vClass & "'>" & _
                            "<td class='labelR'>" & Format(CDate(rs("TransactionTime")), "MM/dd/yyyy") & "</td>" & _
                            "<td class='labelR'>" & Format(CDate(rs("TransactionTime")), "HH:mm:ss") & "</td>" & _
                            "<td class='labelC'>" & rs("UserId") & "</td>" & _
                            "<td class='labelL'>" & rs("Name") & "</td>" & _
                            "</tr>"
                    End If
                    If vLastEmp <> rs("UserId") Then    'dump count
                        vData &= "<tr class='activeBar'>" & _
                            "<td class='labelR'>Total Count of " & rs("UserId") & "</td>" & _
                            "<td class='labelL'>" & Format(iCount, "#,##0") & "</td>" & _
                            "<td>&nbsp;</td>" & _
                            "<td>&nbsp;</td>" & _
                            "</tr>"
                        iCount = 0
                        vLastEmp = rs("UserId")
                    End If
                    vClass = IIf(vClass = "odd", "even", "odd")
                End If
            Loop
            rs.Close()
            vData += "</table>"
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to retrieve records. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            c.Dispose()
            cm.Dispose()
        End Try
    End Sub
End Class
