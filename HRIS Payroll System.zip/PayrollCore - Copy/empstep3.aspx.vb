Namespace denaro

Partial Class empstep3
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub


    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

        Public vScript As String = ""
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load, Me.Load
            If Session("uid") = "" Then
                vScript = "alert('Your login session has expired. Please login again.'); window.close();"
                Exit Sub
            End If

            If Not IsPostBack Then
                cmdPrev.Enabled = CanRun(Session("caption"), "41.2") Or CanRun(Session("caption"), "41.1")
                If Not CanRun(Session("caption"), "41.3") Then
                    Server.Transfer("empstep4.aspx")
                    Exit Sub
                End If
                Session.Remove("oldval")
                Session.Remove("newval")

                Dim c As New SqlClient.SqlConnection(connStr)
                Dim cm As New SqlClient.SqlCommand
                Dim rs As SqlClient.SqlDataReader

                Try
                    c.Open()
                Catch ex As SqlClient.SqlException
                    vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                        ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                    c.Dispose()
                    cm.Dispose()
                    Exit Sub
                End Try

                lblCaption.Text = "Employee Master Information (4 of 6)"
                'build combo references
                BuildCombo("select Tax_Cd,Descr from py_tax_ref", cmbTax, c)
                BuildCombo("select Pay_Cd,Payment from py_pay_mode", cmbPayMode, c)
                BuildCombo("select Status_Code,Descr from py_employee_stat", cmbStatus, c)
                BuildCombo("select Grade_Cd,Descr from py_grade", cmbGrade, c)

                'cmbTax.Items.Add("99=>Unknown")
                'cmbPayMode.Items.Add("99=>Unknown")
                'cmbStatus.Items.Add("99=>Unknown")
                'cmbGrade.Items.Add("99=>Unknown")

                cm.Connection = c
                cm.CommandText = "select Dates_To_Month from py_syscntrl"
                Try
                    rs = cm.ExecuteReader
                    If rs.Read Then
                        days.Value = IIf(IsDBNull(rs("Dates_To_Month")), 1, rs("Dates_To_Month"))
                    End If
                    rs.Close()
                Catch ex As sqlclient.sqlexception
                    vScript = "alert('Error occurred while trying to retrieve System Control. Error is: " & _
                        ex.Message.Replace(vbCrLf, "").Replace("'", "") & "'); window.close();"
                    c.Close()
                    cm.Dispose()
                    c.Dispose()
                    Exit Sub
                End Try

                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY:  VIC GATCHALIAN                                                 ''
                '' DATE MODIFIED: 2/5/2013                                                      ''
                '' PURPOSE: TO ADD THE FIXEDTAX2BASICONLY FIELD                                 ''
                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '''''''''''''''''''''' OLD CODE ''''''''''''''''''''''''''''''''''''''''''''''''''
                'cm.CommandText = "select Rate_Year,Rate_Month,Rate_Day,Req_Hrs_Day,Aca,Rata,Pera,MealAllow," & _
                '    "Tax_Cd,Pay_Cd,Emp_Status,Grade_Cd,FixedSss_Emp,FixedSss_Emr,FixedTax,IsNetAmt," & _
                '    "FixedPagibig_Emp,FixedPagibig_Emr,FixedHealth_Emp,FixedHealth_Emr, EmploymentType," & _
                '    "Emp_Lname,Emp_Fname,Emp_Mname,GracePeriod,Confidential, " & _
                '    "SalarySrcCurrCd, SalaryTargetCurrCd, AcaSrcCurrCd, AcaTargetCurrCd, RataSrcCurrCd,RataTargetCurrCd, PeraSrcCurrCd, " & _
                '    "PeraTargetCurrCd, MealSrcCurrCd, MealTargetCurrCd,SeniorAllowSrcCurrCd, SeniorAllowTargetCurrCd, TaxCurrCd, SssCurrCd, " & _
                '    "PagIbigCurrCd, PHICCurrCd, UnionDuesCurrCd,NotationalTax,FringeBenifitTax " & _
                '    "from py_emp_master where emp_cd='" & _
                '    Session("empid") & "'"
                '''''''''''''''''''''' END OLD CODE ''''''''''''''''''''''''''''''''''''''''''''''
                cm.CommandText = "select Rate_Year,Rate_Month,Rate_Day,Req_Hrs_Day,Aca,Rata,Pera,MealAllow," & _
                    "Tax_Cd,Pay_Cd,Emp_Status,Grade_Cd,FixedSss_Emp,FixedSss_Emr,FixedTax,IsNetAmt," & _
                    "FixedPagibig_Emp,FixedPagibig_Emr,FixedHealth_Emp,FixedHealth_Emr, EmploymentType," & _
                    "Emp_Lname,Emp_Fname,Emp_Mname,GracePeriod,Confidential,CumulativeGrace, " & _
                    "SalarySrcCurrCd, SalaryTargetCurrCd, AcaSrcCurrCd, AcaTargetCurrCd, RataSrcCurrCd,RataTargetCurrCd, PeraSrcCurrCd, " & _
                    "PeraTargetCurrCd, MealSrcCurrCd, MealTargetCurrCd,SeniorAllowSrcCurrCd, SeniorAllowTargetCurrCd, TaxCurrCd, SssCurrCd, " & _
                    "PagIbigCurrCd, PHICCurrCd, UnionDuesCurrCd,NotationalTax,FringeBenifitTax,FixedTax2BasicOnly,DailyPaid " & _
                    "from py_emp_master where emp_cd='" & _
                    Session("empid") & "'"
                '''''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''''''''''''''

                Try
                    rs = cm.ExecuteReader
                    If rs.Read Then
                        lblName.Text = rs("Emp_Lname") & ", " & rs("Emp_Fname") & " " & rs("Emp_Mname")
                        If Session("userlevel") = "1" Or _
                           (Session("userlevel") <> "1" And rs("Confidential") = 0) Then
                            txtRateYr.Text = IIf(IsDBNull(rs("Rate_Year")), 0, rs("Rate_Year"))
                            txtRateMo.Text = IIf(IsDBNull(rs("Rate_Month")), 0, rs("Rate_Month"))
                            txtRateDay.Text = IIf(IsDBNull(rs("Rate_Day")), 0, rs("Rate_Day"))
                            txtACA.Text = IIf(IsDBNull(rs("Aca")), 0, rs("Aca"))
                            txtRATA.Text = IIf(IsDBNull(rs("Rata")), 0, rs("Rata"))
                            txtPERA.Text = IIf(IsDBNull(rs("Pera")), 0, rs("Pera"))
                            txtMeal.Text = IIf(IsDBNull(rs("MealAllow")), 0, rs("MealAllow"))
                        Else
                            txtRateYr.Text = "RESTRICTED"
                            txtRateMo.Text = "RESTRICTED"
                            txtRateDay.Text = "RESTRICTED"
                            txtACA.Text = "RESTRICTED"
                            txtRATA.Text = "RESTRICTED"
                            txtPERA.Text = "RESTRICTED"
                            txtMeal.Text = "RESTRICTED"
                            txtRateYr.Enabled = False
                            txtRateMo.Enabled = False
                            txtRateDay.Enabled = False
                            txtACA.Enabled = False
                            txtRATA.Enabled = False
                            txtPERA.Enabled = False
                            txtMeal.Enabled = False
                        End If
                        chkDailyPaid.Checked = IIf(rs("DailyPaid") = 0, False, True)
                        txtGracePd.Text = IIf(IsDBNull(rs("GracePeriod")), 0, rs("GracePeriod"))
                        txtReqHrs.Text = IIf(IsDBNull(rs("Req_Hrs_Day")), 0, rs("Req_Hrs_Day"))
                        chkCumulative.Checked = rs("CumulativeGrace") = 1
                        txtEmpSSS.Text = IIf(IsDBNull(rs("FixedSss_Emp")), 0, rs("FixedSss_Emp"))
                        txtEmrSSS.Text = IIf(IsDBNull(rs("FixedSss_Emr")), 0, rs("FixedSss_Emr"))
                        txtEmpPagibig.Text = IIf(IsDBNull(rs("FixedPagibig_Emp")), 0, rs("FixedPagibig_Emp"))
                        txtEmrPagibig.Text = IIf(IsDBNull(rs("FixedPagibig_Emr")), 0, rs("FixedPagibig_Emr"))
                        txtEmpPhic.Text = IIf(IsDBNull(rs("FixedHealth_Emp")), 0, rs("FixedHealth_Emp"))
                        txtEmrPhic.Text = IIf(IsDBNull(rs("FixedHealth_Emr")), 0, rs("FixedHealth_Emr"))
                        txtTax.Text = IIf(IsDBNull(rs("FixedTax")), 0, rs("FixedTax"))
                        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                        '' MODIFIED BY: VIC GATCHALIAN                                                  ''
                        '' DATE MODIFID: 2/5/2013                                                       ''
                        '' PURPOSE: TO RETRIEVE THE FIXEDTAX2BASICONLY FIELD AND DISPLAY IT.            ''
                        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                        chkFix2Basic.Checked = rs("FixedTax2BasicOnly") = 1
                        ''''''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''''''''''''''

                        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                        '''''  Added By :   Rudner D. Diaz, Jr.                                       ''''
                        '''''  Date     :   July 7, 2012                                              ''''
                        '''''  Reason   :   To support the Gross up type of employee                  ''''
                        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                        txtNotionTax.Text = IIf(IsDBNull(rs("NotationalTax")), 0, rs("NotationalTax"))
                        txtFringeTax.Text = IIf(IsDBNull(rs("FringeBenifitTax")), 0, rs("FringeBenifitTax"))
                        ''''''''''''''''END of Addition'''''''''''''''''''''''''''''''''''''''''''''''''''


                        chkIsNet.Checked = rs("IsNetAmt") = 1
                        cmbTax.SelectedValue = IIf(IsDBNull(rs("Tax_Cd")), "", rs("Tax_Cd"))    'PointData("Select Tax_Cd,Descr from py_tax_ref where Tax_Cd='" & _
                        'IIf(IsDBNull(rs("Tax_Cd")), "", rs("Tax_Cd")) & "'")
                        cmbPayMode.SelectedValue = IIf(IsDBNull(rs("Pay_Cd")), "", rs("Pay_Cd"))    'PointData("Select Pay_Cd,Payment from py_pay_mode where pay_Cd='" & _
                        'IIf(IsDBNull(rs("Pay_Cd")), "", rs("Pay_Cd")) & "'")
                        cmbStatus.SelectedValue = IIf(IsDBNull(rs("Emp_Status")), "", rs("Emp_Status")) 'PointData("Select Status_Code,Descr from py_employee_stat where Status_Code='" & _
                        'IIf(IsDBNull(rs("Emp_Status")), "", rs("Emp_Status")) & "'")
                        cmbGrade.SelectedValue = IIf(IsDBNull(rs("Grade_Cd")), "", rs("Grade_Cd"))  'PointData("Select Grade_Cd,Descr from py_grade where Grade_Cd='" & _
                        'IIf(IsDBNull(rs("Grade_Cd")), "", rs("Grade_Cd")) & "'")

                        '"SalarySrcCurrCd, SalaryTargetCurrCd, AcaSrcCurrCd, AcaTargetCurrCd, RataSrcCurrCd,RataTargetCurrCd, PeraSrcCurrCd, " & _
                        '"PeraTargetCurrCd, MealSrcCurrCd, MealTargetCurrCd,SeniorAllowSrcCurrCd, SeniorAllowTargetCurrCd, TaxCurrCd, SssCurrCd, " & _
                        '"PagIbigCurrCd, PHICCurrCd, UnionDuesCurrCd " & _

                        

                        BuildCombo(" select CurrCd, CurrName from currency_ref", cmbSrcBasic, c)
                        BuildCombo(" select CurrCd, CurrName from currency_ref", cmbTargetBasic, c)
                        BuildCombo(" select CurrCd, CurrName from currency_ref", cmbSrcCOLA, c)
                        BuildCombo(" select CurrCd, CurrName from currency_ref", cmbTargetCOLA, c)
                        BuildCombo(" select CurrCd, CurrName from currency_ref", cmbSrcBTA, c)
                        BuildCombo(" select CurrCd, CurrName from currency_ref", cmbTargetBTA, c)
                        BuildCombo(" select CurrCd, CurrName from currency_ref", cmbSrcRATA, c)
                        BuildCombo(" select CurrCd, CurrName from currency_ref", cmbTargetRATA, c)
                        BuildCombo(" select CurrCd, CurrName from currency_ref", cmbSrcMeal, c)
                        BuildCombo(" select CurrCd, CurrName from currency_ref", cmbTargetMeal, c)
                        BuildCombo(" select CurrCd, CurrName from currency_ref", cmbSrcSenior, c)
                        BuildCombo(" select CurrCd, CurrName from currency_ref", cmbTargetSenior, c)
                        BuildCombo(" select CurrCd, CurrName from currency_ref", cmbTargetTax, c)
                        BuildCombo(" select CurrCd, CurrName from currency_ref", cmbTargetSSS, c)
                        BuildCombo(" select CurrCd, CurrName from currency_ref", cmbTargetPagIBIG, c)
                        BuildCombo(" select CurrCd, CurrName from currency_ref", cmbTargetPHIC, c)
                        BuildCombo(" select CurrCd, CurrName from currency_ref", cmbTargetUnion, c)

                        cmbSrcBasic.SelectedValue = rs("SalarySrcCurrCd")
                        cmbTargetBasic.SelectedValue = rs("SalaryTargetCurrCd")
                        cmbSrcCOLA.SelectedValue = rs("AcaSrcCurrCd")
                        cmbTargetCOLA.SelectedValue = rs("AcaTargetCurrCd")
                        cmbSrcBTA.SelectedValue = rs("PeraSrcCurrCd")
                        cmbTargetBTA.SelectedValue = rs("PeraTargetCurrCd")
                        cmbSrcRATA.SelectedValue = rs("RataSrcCurrCd")
                        cmbTargetRATA.SelectedValue = rs("RataTargetCurrCd")
                        cmbSrcMeal.SelectedValue = rs("MealSrcCurrCd")
                        cmbTargetMeal.SelectedValue = rs("MealTargetCurrCd")
                        cmbSrcSenior.SelectedValue = rs("SeniorAllowSrcCurrCd")
                        cmbTargetSenior.SelectedValue = rs("SeniorAllowTargetCurrCd")
                        cmbTargetTax.SelectedValue = rs("TaxCurrCd")
                        cmbTargetSSS.SelectedValue = rs("SssCurrCd")
                        cmbTargetPagIBIG.SelectedValue = rs("PagIbigCurrCd")
                        cmbTargetPHIC.SelectedValue = rs("PHICCurrCd")
                        cmbTargetUnion.SelectedValue = rs("UnionDuesCurrCd")

                    End If
                    Session("oldval") = "Rate/Year=" & IIf(IsDBNull(rs("Rate_Year")), 0, rs("Rate_Year")) & _
                        "|Rate/Month=" & IIf(IsDBNull(rs("Rate_Month")), 0, rs("Rate_Month")) & _
                        "|Rate/Day=" & IIf(IsDBNull(rs("Rate_Day")), 0, rs("Rate_Day")) & _
                        "|ACA=" & IIf(IsDBNull(rs("Aca")), 0, rs("Aca")) & _
                        "|RATA=" & IIf(IsDBNull(rs("Rata")), 0, rs("Rata")) & _
                        "|PERA=" & IIf(IsDBNull(rs("Pera")), 0, rs("Pera")) & _
                        "|Meal Allowance=" & IIf(IsDBNull(rs("MealAllow")), 0, rs("MealAllow")) & _
                        "|Grace Period=" & txtGracePd.Text & _
                        "|Cumulative Grace Period=" & If(chkCumulative.Checked, "yes", "no") & _
                        "|Is Net Amt=" & IIf(chkIsNet.Checked, "Yes", "No") & _
                        "|Required Hrs/Day=" & txtReqHrs.Text & _
                        "|Fixed SSS Emp Share=" & txtEmpSSS.Text & _
                        "|Fixed SSS Emr Share=" & txtEmrSSS.Text & _
                        "|Fixed PAGIBIG Emp Share=" & txtEmpPagibig.Text & _
                        "|Fixed PAGIBIG Emr Share=" & txtEmrPagibig.Text & _
                        "|Fixed PHIC Emp Share=" & txtEmpPhic.Text & _
                        "|Fixed PHIC Emr Share=" & txtEmrPhic.Text & _
                        "|Fixed Emp. Tax=" & txtTax.Text & _
                        "|Tax Cd=" & cmbTax.SelectedValue & _
                        "|Pay Cd=" & cmbPayMode.SelectedValue & _
                        "|Employment Status=" & cmbStatus.SelectedValue & _
                        "|Salary Grade=" & cmbGrade.SelectedValue & _
                        "|SalarySrcCurrCd=" & cmbSrcBasic.SelectedValue & _
                        "|SalaryTargetCurrCd=" & cmbTargetBasic.SelectedValue & _
                        "|AcaSrcCurrCd=" & cmbSrcCOLA.SelectedValue & _
                        "|AcaTargetCurrCd=" & cmbTargetCOLA.SelectedValue & _
                        "|PeraSrcCurrCd=" & cmbSrcBTA.SelectedValue & _
                        "|PeraTargetCurrCd=" & cmbTargetBTA.SelectedValue & _
                        "|RataSrcCurrCd=" & cmbSrcRATA.SelectedValue & _
                        "|RataTargetCurrCd=" & cmbTargetRATA.SelectedValue & _
                        "|MealSrcCurrCd=" & cmbSrcMeal.SelectedValue & _
                        "|MealTargetCurrCd=" & cmbTargetMeal.SelectedValue & _
                        "|SeniorAllowSrcCurrCd=" & cmbSrcSenior.SelectedValue & _
                        "|SeniorAllowTargetCurrCd=" & cmbTargetSenior.SelectedValue & _
                        "|TaxCurrCd=" & cmbTargetTax.SelectedValue & _
                        "|SssCurrCd=" & cmbTargetSSS.SelectedValue & _
                        "|PagIbigCurrCd=" & cmbTargetPagIBIG.SelectedValue & _
                        "|PHICCurrCd=" & cmbTargetPHIC.SelectedValue & _
                        "|UnionDuesCurrCd=" & cmbTargetUnion.SelectedValue & _
                        "|NotationalTax=" & IIf(IsDBNull(rs("NotationalTax")), 0, rs("NotationalTax")) & _
                        "|FringeBenifitTax=" & IIf(IsDBNull(rs("FringeBenifitTax")), 0, rs("FringeBenifitTax")) & _
                        "|Fixed Tax 2 Basic Pay Only=" & chkFix2Basic.Checked & _
                        "|Daily Paid=" & chkDailyPaid.Checked

                    rs.Close()
                Catch ex As SqlClient.SqlException
                    vScript = "alert('Error occurred while trying to retrieve data. Error is: " & _
                        ex.Message.Replace(vbCrLf, "").Replace("'", "") & "'); window.close();"
                Finally
                    c.Close()
                    cm.Dispose()
                    c.Dispose()
                End Try
            End If
        End Sub

        Private Sub cmdPrev_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdPrev.Click
            Session.Remove("oldval")
            Session.Remove("newval")

            If CanRun(Session("caption"), "41.2") Then
                Server.Transfer("empstep2_1.aspx")
            Else
                Server.Transfer("empstep2.aspx")
            End If
        End Sub

        Private Sub cmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
            Session.Remove("oldval")
            Session.Remove("newval")
            Session.Remove("empid")
            vScript = "window.close();"
        End Sub

        Private Sub cmdSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSave.Click
            If Page.IsValid Then
                Dim c As New SqlClient.SqlConnection(connStr)
                Dim cm As New SqlClient.SqlCommand

                Dim vInclStr = ""
                If txtRateYr.Enabled Then
                    vInclStr = ",Rate_Year=" & Val(txtRateYr.Text) & _
                        ",Rate_Month=" & Val(txtRateMo.Text) & _
                        ",Rate_Day=" & Val(txtRateDay.Text) & _
                        ",Aca=" & Val(txtACA.Text) & _
                        ",Rata=" & Val(txtRATA.Text) & _
                        ",Pera=" & Val(txtPERA.Text) & _
                        ",MealAllow=" & Val(txtMeal.Text)
                    Session("newval") = "Rate/Year=" & txtRateYr.Text & _
                        "|Rate/Month=" & txtRateMo.Text & _
                        "|Rate/Day=" & txtRateDay.Text & _
                        "|ACA=" & txtACA.Text & _
                        "|RATA=" & txtRATA.Text & _
                        "|PERA=" & txtPERA.Text & _
                        "|Meal Allowance=" & txtMeal.Text
                End If
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY:  VIC GATCHALIAN                                  ''
                '' DATE MODIFIED: 2/5/2013                                       ''
                '' PURPOSE: TO ADD THE FixedTax2BasicOnly FIELD DURING SAVING.   ''
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                ''''''''''''''''' OLD CODE ''''''''''''''''''''''''''''''''''''''''
                'Dim vSQL As String = "update py_emp_master set " & _
                '    "Req_Hrs_Day=" & Val(txtReqHrs.Text) & _
                '    ",IsNetAmt=" & IIf(chkIsNet.Checked, 1, 0) & _
                '    ",FixedSss_Emp=" & Val(txtEmpSSS.Text) & _
                '    ",FixedSss_Emr=" & Val(txtEmrSSS.Text) & _
                '    ",FixedPagibig_Emp=" & Val(txtEmpPagibig.Text) & _
                '    ",FixedPagibig_Emr=" & Val(txtEmrPagibig.Text) & _
                '    ",FixedHealth_Emp=" & Val(txtEmpPhic.Text) & _
                '    ",FixedHealth_Emr=" & Val(txtEmrPhic.Text) & _
                '    ",FixedTax=" & Val(txtTax.Text) & _
                '    ",Tax_Cd='" & cmbTax.SelectedValue & _
                '    "',Pay_Cd='" & cmbPayMode.SelectedValue & _
                '    "',Emp_Status='" & cmbStatus.SelectedValue & _
                '    "',Grade_Cd='" & cmbGrade.SelectedValue & _
                '    "',SalarySrcCurrCd='" & cmbSrcBasic.SelectedValue & _
                '    "',SalaryTargetCurrCd='" & cmbTargetBasic.SelectedValue & _
                '    "',AcaSrcCurrCd='" & cmbSrcCOLA.SelectedValue & _
                '    "',AcaTargetCurrCd='" & cmbTargetCOLA.SelectedValue & _
                '    "',PeraSrcCurrCd='" & cmbSrcBTA.SelectedValue & _
                '    "',PeraTargetCurrCd='" & cmbTargetBTA.SelectedValue & _
                '    "',RataSrcCurrCd='" & cmbSrcRATA.SelectedValue & _
                '    "',RataTargetCurrCd='" & cmbTargetRATA.SelectedValue & _
                '    "',MealSrcCurrCd='" & cmbSrcMeal.SelectedValue & _
                '    "',MealTargetCurrCd='" & cmbTargetMeal.SelectedValue & _
                '    "',SeniorAllowSrcCurrCd='" & cmbSrcSenior.SelectedValue & _
                '    "',SeniorAllowTargetCurrCd='" & cmbTargetSenior.SelectedValue & _
                '    "',TaxCurrCd='" & cmbTargetTax.SelectedValue & _
                '    "',SssCurrCd='" & cmbTargetSSS.SelectedValue & _
                '    "',PagIbigCurrCd='" & cmbTargetPagIBIG.SelectedValue & _
                '    "',PHICCurrCd='" & cmbTargetPHIC.SelectedValue & _
                '    "',UnionDuesCurrCd='" & cmbTargetUnion.SelectedValue & _
                '    "',Modified_Date='" & Format(Now, "yyyy/MM/dd HH:mm:ss") & _
                '    "',Modified_By='" & Session("uid") & _
                '    "',NotationalTax=" & Val(txtNotionTax.Text) & _
                '    ",FringeBenifitTax=" & Val(txtFringeTax.Text) & _
                '    " " & vInclStr & " where emp_cd='" & Session("empid") & "'"
                ''''''''''''''''' END OLD CODE ''''''''''''''''''''''''''''''''''''
                Dim vSQL As String = "update py_emp_master set " & _
                    "Req_Hrs_Day=" & Val(txtReqHrs.Text) & _
                    ",IsNetAmt=" & IIf(chkIsNet.Checked, 1, 0) & _
                    ",FixedSss_Emp=" & Val(txtEmpSSS.Text) & _
                    ",FixedSss_Emr=" & Val(txtEmrSSS.Text) & _
                    ",FixedPagibig_Emp=" & Val(txtEmpPagibig.Text) & _
                    ",FixedPagibig_Emr=" & Val(txtEmrPagibig.Text) & _
                    ",FixedHealth_Emp=" & Val(txtEmpPhic.Text) & _
                    ",FixedHealth_Emr=" & Val(txtEmrPhic.Text) & _
                    ",FixedTax=" & Val(txtTax.Text) & _
                    ",Tax_Cd='" & cmbTax.SelectedValue & _
                    "',Pay_Cd='" & cmbPayMode.SelectedValue & _
                    "',Emp_Status='" & cmbStatus.SelectedValue & _
                    "',Grade_Cd='" & cmbGrade.SelectedValue & _
                    "',GracePeriod=" & txtGracePd.Text & _
                    ",CumulativeGrace=" & IIf(chkCumulative.Checked, 1, 0) & _
                    ",SalarySrcCurrCd='" & cmbSrcBasic.SelectedValue & _
                    "',SalaryTargetCurrCd='" & cmbTargetBasic.SelectedValue & _
                    "',AcaSrcCurrCd='" & cmbSrcCOLA.SelectedValue & _
                    "',AcaTargetCurrCd='" & cmbTargetCOLA.SelectedValue & _
                    "',PeraSrcCurrCd='" & cmbSrcBTA.SelectedValue & _
                    "',PeraTargetCurrCd='" & cmbTargetBTA.SelectedValue & _
                    "',RataSrcCurrCd='" & cmbSrcRATA.SelectedValue & _
                    "',RataTargetCurrCd='" & cmbTargetRATA.SelectedValue & _
                    "',MealSrcCurrCd='" & cmbSrcMeal.SelectedValue & _
                    "',MealTargetCurrCd='" & cmbTargetMeal.SelectedValue & _
                    "',SeniorAllowSrcCurrCd='" & cmbSrcSenior.SelectedValue & _
                    "',SeniorAllowTargetCurrCd='" & cmbTargetSenior.SelectedValue & _
                    "',TaxCurrCd='" & cmbTargetTax.SelectedValue & _
                    "',SssCurrCd='" & cmbTargetSSS.SelectedValue & _
                    "',PagIbigCurrCd='" & cmbTargetPagIBIG.SelectedValue & _
                    "',PHICCurrCd='" & cmbTargetPHIC.SelectedValue & _
                    "',UnionDuesCurrCd='" & cmbTargetUnion.SelectedValue & _
                    "',Modified_Date='" & Format(Now, "yyyy/MM/dd HH:mm:ss") & _
                    "',Modified_By='" & Session("uid") & _
                    "',NotationalTax=" & Val(txtNotionTax.Text) & _
                    ",FringeBenifitTax=" & Val(txtFringeTax.Text) & _
                    ",FixedTax2BasicOnly=" & IIf(chkFix2Basic.Checked, 1, 0) & _
                    ",DailyPaid=" & IIf(chkDailyPaid.Checked, 1, 0) & _
                    " " & vInclStr & " where emp_cd='" & Session("empid") & "'"
                ''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''''

                
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                ''''''Added By  :   Rudner D. Diaz, Jr.                                                                 '''
                ''''''Date      :   July 7, 2012                                                                        '''
                ''''''Reason    :   To support the Gross up employee(Notational Tax and Fringe Benifit tax)             '''                                                    '''
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

                Try
                    c.Open()
                Catch ex As SqlClient.SqlException
                    vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                        ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                    c.Dispose()
                    cm.Dispose()
                    Exit Sub
                End Try

                cm.Connection = c
                cm.CommandText = vSQL
                Try
                    cm.ExecuteNonQuery()
                    Session("newval") += "|Grace Period=" & txtGracePd.Text & _
                        "|Cumulative Grace Period=" & IIf(chkCumulative.Checked, "yes", "no") & _
                        "|Is Net Amt=" & IIf(chkIsNet.Checked, "Yes", "No") & _
                        "|Required Hrs/Day=" & txtReqHrs.Text & _
                        "|Fixed SSS Emp Share=" & txtEmpSSS.Text & _
                        "|Fixed SSS Emr Share=" & txtEmrSSS.Text & _
                        "|Fixed PAGIBIG Emp Share=" & txtEmpPagibig.Text & _
                        "|Fixed PAGIBIG Emr Share=" & txtEmrPagibig.Text & _
                        "|Fixed PHIC Emp Share=" & txtEmpPhic.Text & _
                        "|Fixed PHIC Emr Share=" & txtEmrPhic.Text & _
                        "|Fixed Emp. Tax=" & txtTax.Text & _
                        "|Tax Cd=" & cmbTax.SelectedValue & _
                        "|Pay Cd=" & cmbPayMode.SelectedValue & _
                        "|Employment Status=" & cmbStatus.SelectedValue & _
                        "|Salary Grade=" & cmbGrade.SelectedValue & _
                        "|SalarySrcCurrCd=" & cmbSrcBasic.SelectedValue & _
                        "|SalaryTargetCurrCd=" & cmbTargetBasic.SelectedValue & _
                        "|AcaSrcCurrCd=" & cmbSrcCOLA.SelectedValue & _
                        "|AcaTargetCurrCd=" & cmbTargetCOLA.SelectedValue & _
                        "|PeraSrcCurrCd=" & cmbSrcBTA.SelectedValue & _
                        "|PeraTargetCurrCd=" & cmbTargetBTA.SelectedValue & _
                        "|RataSrcCurrCd=" & cmbSrcRATA.SelectedValue & _
                        "|RataTargetCurrCd=" & cmbTargetRATA.SelectedValue & _
                        "|MealSrcCurrCd=" & cmbSrcMeal.SelectedValue & _
                        "|MealTargetCurrCd=" & cmbTargetMeal.SelectedValue & _
                        "|SeniorAllowSrcCurrCd=" & cmbSrcSenior.SelectedValue & _
                        "|SeniorAllowTargetCurrCd=" & cmbTargetSenior.SelectedValue & _
                        "|TaxCurrCd=" & cmbTargetTax.SelectedValue & _
                        "|SssCurrCd=" & cmbTargetSSS.SelectedValue & _
                        "|PagIbigCurrCd=" & cmbTargetPagIBIG.SelectedValue & _
                        "|PHICCurrCd=" & cmbTargetPHIC.SelectedValue & _
                        "|UnionDuesCurrCd=" & cmbTargetUnion.SelectedValue & _
                        "|NotationalTax=" & txtNotionTax.Text & _
                        "|FringeBenifitTax=" & txtFringeTax.Text & _
                        "|Fixed Tax 2 Basic Pay Only=" & chkFix2Basic.Checked & _
                        "|Daily Paid=" & chkDailyPaid.Checked


                    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                    ''''''Added By  :   Rudner D. Diaz, Jr.                                                                 '''
                    ''''''Date      :   July 7, 2012                                                                        '''
                    ''''''Reason    :   To support the Gross up employee(Notational Tax and Fringe Benifit tax)             '''                                                    '''
                    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

                    EventLog(Session("uid"), Request.ServerVariables("REMOTE_ADDR"), "EDIT", Session("oldval"), Session("newval"), _
                        "Employee ID: " & Session("empid") & " was added/edited", "201 Profile", c)
                    Session.Remove("oldval")
                    Session.Remove("newval")
                    Server.Transfer("empstep4.aspx")
                Catch ex As SqlClient.SqlException
                    vScript = "alert('Error occurred while trying to save changes. Error is: " & _
                        ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                Finally
                    c.Close()
                    cm.Dispose()
                    c.Dispose()
                End Try
            End If
        End Sub

        Private Sub vldNumber_ServerValidate(ByVal source As System.Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles vldNumber.ServerValidate
            args.IsValid = False
            If txtRateYr.Enabled Then
                If Not IsNumeric(txtRateYr.Text) Then
                    vldNumber.ErrorMessage = "Invalid numeric format in Rate/Yr field. Please enter a valid number."
                    Exit Sub
                End If
                If Not IsNumeric(txtRateMo.Text) Then
                    vldNumber.ErrorMessage = "Invalid numeric format in Rate/Mo field. Please enter a valid number."
                    Exit Sub
                End If
                If Not IsNumeric(txtRateDay.Text) Then
                    vldNumber.ErrorMessage = "Invalid numeric format in Rate/Day field. Please enter a valid number."
                    Exit Sub
                End If
                If Not IsNumeric(txtACA.Text) Then
                    vldNumber.ErrorMessage = "Invalid numeric format in ACA field. Please enter a valid number."
                    Exit Sub
                End If
                If Not IsNumeric(txtRATA.Text) Then
                    vldNumber.ErrorMessage = "Invalid numeric format in RATA field. Plesae enter a valid number."
                    Exit Sub
                End If
                If Not IsNumeric(txtPERA.Text) Then
                    vldNumber.ErrorMessage = "Invalid numeric format in PERA field. Please enter a valid number."
                    Exit Sub
                End If
                If Not IsNumeric(txtMeal.Text) Then
                    vldNumber.ErrorMessage = "Invalid numeric format in Meal Allowance field. Please enter a valid number."
                    Exit Sub
                End If
            End If

            If Not IsNumeric(txtReqHrs.Text) Then
                vldNumber.ErrorMessage = "Invalid numeric format in # of Req. Hrs field. Please enter a valid number."
                Exit Sub
            End If
            
            If Not IsNumeric(txtEmpSSS.Text) Then
                vldNumber.ErrorMessage = "Invalid numeric format in SSS Employee field. Plesae enter a valid number."
                Exit Sub
            End If
            If Not IsNumeric(txtEmrSSS.Text) Then
                vldNumber.ErrorMessage = "Invalid numeric format in SSS Employer field. Plesae enter a valid number."
                Exit Sub
            End If
            If Not IsNumeric(txtEmpPagibig.Text) Then
                vldNumber.ErrorMessage = "Invalid numeric format in Pagibig Employee field. Please enter a valid number."
                Exit Sub
            End If
            If Not IsNumeric(txtEmrPagibig.Text) Then
                vldNumber.ErrorMessage = "Invalid numeric format in Pagibig Employer field. Please enter a valid number."
                Exit Sub
            End If
            If Not IsNumeric(txtEmpPhic.Text) Then
                vldNumber.ErrorMessage = "Invalid numeric format in Philhealth Employee field. Please enter a valid number."
                Exit Sub
            End If
            If Not IsNumeric(txtEmrPhic.Text) Then
                vldNumber.ErrorMessage = "Invalid numeric format in Philhealth Employer field. Please enter a valid number."
                Exit Sub
            End If
            If Not IsNumeric(txtTax.Text) Then
                vldNumber.ErrorMessage = "Invalid numeric format in Tax field. Please enter a valid number."
                Exit Sub
            End If
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            ''''''Added By  :   Rudner D. Diaz, Jr.                                                                 '''
            ''''''Date      :   July 7, 2012                                                                        '''
            ''''''Reason    :   To support the Gross up employee                                                    '''
            If Not IsNumeric(txtNotionTax.Text) Then
                vldNumber.ErrorMessage = "Invalid numeric format in Notational Tax field. Please enter a valid number."
                Exit Sub
            End If
            If Not IsNumeric(txtNotionTax.Text) Then
                vldNumber.ErrorMessage = "Invalid numeric format in Notational Tax field. Please enter a valid number."
                Exit Sub
            End If
            ''''''''''''''END of ADDITION''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            'make sure that no comma is included
            txtRateYr.Text.Replace(",", "")
            txtRateMo.Text.Replace(",", "")
            txtRateDay.Text.Replace(",", "")
            txtReqHrs.Text.Replace(",", "")
            txtACA.Text.Replace(",", "")
            txtRATA.Text.Replace(",", "")
            txtPERA.Text.Replace(",", "")
            txtMeal.Text.Replace(",", "")
            txtEmpSSS.Text.Replace(",", "")
            txtEmrSSS.Text.Replace(",", "")
            txtEmpPagibig.Text.Replace(",", "")
            txtEmrPagibig.Text.Replace(",", "")
            txtEmpPhic.Text.Replace(",", "")
            txtEmrPhic.Text.Replace(",", "")
            txtTax.Text.Replace(",", "")
            args.IsValid = True
        End Sub

   
    Private Sub txtRateYr_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtRateYr.Init
        Dim txt As Web.UI.WebControls.TextBox
        txt = CType(sender, Web.UI.WebControls.TextBox)
        txt.Attributes.Add("onblur", "computeyr();")
    End Sub

    Private Sub txtRateMo_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtRateMo.Init
        Dim txt As Web.UI.WebControls.TextBox
        txt = CType(sender, Web.UI.WebControls.TextBox)
        txt.Attributes.Add("onblur", "computemo();")
    End Sub

    Private Sub txtRateDay_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtRateDay.Init
        Dim txt As Web.UI.WebControls.TextBox
        txt = CType(sender, Web.UI.WebControls.TextBox)
        txt.Attributes.Add("onblur", "computeday();")
    End Sub

        Protected Sub cmbQuickNavi_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbQuickNavi.SelectedIndexChanged
            Session.Remove("oldval")
            Session.Remove("newval")
            Server.Transfer(cmbQuickNavi.SelectedValue)
        End Sub
    End Class

End Namespace
