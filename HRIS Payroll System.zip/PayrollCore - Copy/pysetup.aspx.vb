Imports denaro
Partial Class pysetup
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If

        If Not IsPostBack Then
            lblCaption.Text = "Profile Maintenance"
            BuildCombo("select distinct CaptionName,CaptionName from post_info", cmbProfile)
            
            DataRefresh()
        End If
    End Sub
    Private Sub DataRefresh()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim da As SqlClient.SqlDataAdapter
        Dim ds As New DataSet

        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                                          ''
        '' DATE MODIFIED: 5/1/2013                                               ''
        '' PURPOSE: TO EXPOSE THE "CONDITION" FIELD IN THE GRID.                 ''
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        ''''''''''''''''''''''''' OLD CODE ''''''''''''''''''''''''''''''''''''''''
        'da = New SqlClient.SqlDataAdapter("select post_info.SeqId,post_info.AcctCd," & _
        '    "(select AcctName from coa where coa.AcctCd=post_info.AcctCd) as AcctName," & _
        '    "CASE WHEN DrCr=0 THEN 'Debit' ELSE 'Credit' END as DebitCredit,FieldName,GroupBy,GroupByDump,ByEmployee from post_info where " & _
        '    "CaptionName='" & cmbProfile.SelectedValue & "' order by SeqId asc", c)
        ''''''''''''''''''''''''' END OLD CODE ''''''''''''''''''''''''''''''''''''
        da = New SqlClient.SqlDataAdapter("select post_info.SeqId,post_info.AcctCd,Condition," & _
            "(select AcctName from coa where coa.AcctCd=post_info.AcctCd) as AcctName," & _
            "CASE WHEN DrCr=0 THEN 'Debit' ELSE 'Credit' END as DebitCredit,FieldName,GroupBy," & _
            "GroupByDump,ByEmployee from post_info where " & _
            "CaptionName='" & cmbProfile.SelectedValue & "' order by SeqId asc", c)
        ''''''''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''''

        
        da.Fill(ds, "post")
        tblprofile.DataSource = ds.Tables("post")
        tblprofile.DataBind()
        da.Dispose()
        ds.Dispose()
        c.Dispose()
        Session("currprofile") = cmbProfile.SelectedValue
    End Sub

    Protected Sub cmdRefresh_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdRefresh.Click
        DataRefresh()
    End Sub

    Protected Sub cmdDel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDel.Click
        If tblprofile.SelectedIndex <> -1 And tblprofile.SelectedIndex <= tblprofile.Rows.Count Then
            Dim c As New SqlClient.SqlConnection(connStr)
            Dim cm As New SqlClient.SqlCommand

            Try
                c.Open()
            Catch ex As SqlClient.SqlException
                vScript = "alert('An error occurred while trying to connect to database. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                c.Dispose()
                cm.Dispose()
                Exit Sub
            End Try

            cm.Connection = c
            cm.CommandText = "delete from post_info where CaptionName='" & cmbProfile.SelectedValue & _
                "' and SeqId=" & tblprofile.SelectedRow.Cells(0).Text
            Try
                cm.ExecuteNonQuery()
                DataRefresh()
            Catch ex As SqlClient.SqlException
                vScript = "alert('An error occurred while trying to delete the record. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            Finally
                c.Close()
                c.Dispose()
                cm.Dispose()
            End Try
        Else
            vScript = "alert('You must first select a record to delete.');"
        End If
    End Sub

    Protected Sub cmdEdit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdEdit.Click
        If tblprofile.SelectedIndex <> -1 And tblprofile.SelectedIndex <= tblprofile.Rows.Count Then
            vScript = "win=window.open('modifyprofile.aspx?m=e&p=" & cmbProfile.SelectedValue & _
                "&id=" & tblprofile.SelectedRow.Cells(0).Text & _
                "','win','toolbar=no,top=10,left=100,width=900,height=500,resizable=yes');"
        Else
            vScript = "alert('You must first select a record to edit.');"
        End If

    End Sub

    Protected Sub cmdDelProfile_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDelProfile.Click
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('An error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            Exit Sub
        End Try

        cm.Connection = c
        cm.CommandText = "delete from post_info where CaptionName='" & cmbProfile.SelectedValue & "'"
        Try
            cm.ExecuteNonQuery()
            BuildCombo("select distinct CaptionName as Code,CaptionName from post_info", cmbProfile, c)
        Catch ex As SqlClient.SqlException
            vScript = "alert('An error occurred while trying to delete the profile. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            c.Dispose()
            cm.Dispose()
            DataRefresh()
        End Try
    End Sub

    Protected Sub cmdAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdAdd.Click
        If cmbProfile.SelectedIndex <> -1 Then
            vScript = "win=window.open('modifyprofile.aspx?m=a&p=" & cmbProfile.SelectedValue & _
                "','win','toolbar=no,top=10,left=100,width=900,height=500,resizable=yes');"
        Else
            vScript = "win=window.open('modifyprofile.aspx?m=a&p=" & Request.Form("txtnewname") & _
                "','win','toolbar=no,top=10,left=100,width=900,height=500,resizable=yes');"
        End If
    End Sub

    Protected Sub cmdCopy_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCopy.Click
        Dim vNewName As String = Request.Form("txtnewname")

        If vNewName <> "" Then
            Dim c As New SqlClient.SqlConnection(connStr)
            Dim cm As New SqlClient.SqlCommand

            Try
                c.Open()
            Catch ex As SqlClient.SqlException
                vScript = "alert('An error occurred while trying to connect to database. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                c.Dispose()
                Exit Sub
            End Try

            cm.Connection = c

            cm.CommandText = "insert into post_info (SeqId,CaptionName,AcctCd,DrCr,TableName,FieldName,GroupBy,Condition) " & _
                "select SeqId,'" & vNewName & "',AcctCd,DrCr,TableName,FieldName,GroupBy,Condition from post_info where CaptionName='" & _
                cmbProfile.SelectedValue & "'"
            Try
                cm.ExecuteNonQuery()

                vScript = "alert('The profile " & cmbProfile.SelectedValue & _
                    " has been successfully copied to new profile " & vNewName & "');"
                BuildCombo("select distinct CaptionName as Code,CaptionName from post_info", cmbProfile, c)
            Catch ex As SqlClient.SqlException
                vScript = "alert('An error occurred while trying to copy the profile. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            Finally
                c.Close()
                c.Dispose()
                cm.Dispose()
                DataRefresh()
            End Try
        End If
    End Sub

    Protected Sub tblprofile_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles tblprofile.PageIndexChanging
        tblprofile.PageIndex = e.NewPageIndex
        DataRefresh()
    End Sub
End Class
