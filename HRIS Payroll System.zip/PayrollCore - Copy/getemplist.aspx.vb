Imports denaro.fis
Partial Class getemplist
    Inherits System.Web.UI.Page
    Public vReturn As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            vReturn = "expired"
            Exit Sub
        End If

        Dim c As New sqlclient.sqlconnection(connStr)
        Dim cm As New sqlclient.sqlcommand
        Dim rs As sqlclient.sqldatareader
        Dim vFilter As String = ""

        cm.Connection = c

        'set filters 
        If Request.Form("rc") <> "All" Then
            vFilter += " and Rc_Cd='" & Request.Form("rc") & "' "
        Else
            vFilter += " and Rc_Cd in ('" & Session("rclist").ToString.Replace(",", "','") & "') "
        End If

        If Request.Form("ofc") <> "All" Then
            vFilter += " and Agency_Cd='" & Request.Form("ofc") & "' "
        Else
            vFilter += " and Agency_Cd in ('" & Session("agencylist").ToString.Replace(",", "','") & "') "
        End If

        If Request.Form("div") <> "All" Then
            vFilter += " and DivCd='" + Request.Form("div") & "' "
        Else
            vFilter += " and DivCd in ('" & Session("divlist").ToString.Replace(",", "','") & "') "
        End If

        If Request.Form("dept") <> "All" Then
            vFilter += " and DeptCd='" & Request.Form("dept") & "' "
        Else
            vFilter += " and DeptCd in ('" & Session("deptlist").ToString.Replace(",", "','") & "') "
        End If

        If Request.Form("section") <> "All" Then
            vFilter += " and SectionCd='" & Request.Form("section") & "' "
        Else
            vFilter += " and SectionCd in ('" & Session("sectionlist").ToString.Replace(",", "','") & "') "
        End If

        If Request.Form("unit") <> "All" Then
            vFilter += " and UnitCd='" & Request.Form("unit") & "' "
        Else
            vFilter += " and UnitCd in ('" & Session("unitlist").ToString.Replace(",", "','") & "') "
        End If

        If Request.Form("rank") <> "All" And Request.Form("rank") <> "" Then
            vFilter += " and EmploymentType='" & Request.Form("rank") & "' "
        Else
            vFilter += " and EmploymentType in ('" & Session("typelist").ToString.Replace(",", "','") & "') "
        End If

        If Request.Form("status") <> "All" Then
            vFilter += " and Emp_Status='" & Request.Form("status") & "' "
        End If

        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:     Rudner D. Diaz, Jr.                                        ''
        '' DATE:            4/4/2013                                                   ''
        '' PURPOSE:         To include the paymode in searching the employee           ''
        '' Exception:       Cygnus                                                     ''
        '' ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        If Request.Form("paymode") <> "All" Then
            vFilter += " and Pay_Cd='" & Request.Form("paymode") & "' "
        End If
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        'Select Case Request.Form("status")
        '    Case "1"    'active
        '        vFilter += " and Date_Resign is null and DateHold is null and DateSuspended is null " & _
        '            "and Date_Retired is null and DateDismissed is null "
        '    Case "0"    'inactive
        '        vFilter += " and (Date_Resign is not null or DateHold is not null or DateSuspended is not null " & _
        '            "or Date_Retired is not null or DateDismissed is not null) "
        'End Select

        If Request.Form("search") <> "" Then
            vFilter += " and " & Request.Form("field") & " like '" & Request.Form("search") & "%' "
        End If

        If Request.Form("ofilter") <> "" Then
            vFilter += Request.Form("ofilter")
        End If

        Try
            c.Open()
            Try
                cm.CommandText = "select * from py_emp_master where Date_Resign is null " & _
                    vFilter & " order by Emp_Lname,Emp_Fname"

                rs = cm.ExecuteReader
                vReturn = ""
                Do While rs.Read
                    vReturn += rs("Emp_Cd") & "~" & rs("Emp_Lname") & ", " & rs("Emp_Fname")
                    If Request.Form("ofield") <> "" Then
                        vReturn += "~" & rs(Request.Form("ofield"))
                    End If
                    vReturn += "|"
                Loop
                rs.Close()
            Catch ex As system.exception
                vReturn = ex.Message.Replace(vbCrLf, "").Replace("'", "")
            Finally
                c.Close()
                c.Dispose()
                cm.Dispose()
            End Try
        Catch ex As system.exception
            vReturn = ""
        End Try
        If vReturn <> "" Then vReturn = vReturn.Substring(0, vReturn.Length - 1)
    End Sub
End Class
