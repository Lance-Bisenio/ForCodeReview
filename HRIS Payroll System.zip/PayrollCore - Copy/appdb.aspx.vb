Imports denaro
Partial Class appdb
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Dim c As New SqlClient.SqlConnection
    Dim vSQL As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If

        If Not IsPostBack Then
            If Not CanRun(Session("caption"), Request.Item("id")) Then
                Session("denied") = "1"
                Server.Transfer("main.aspx")
                Exit Sub
            End If
            lblcaption.text = "Application Masterfile"
            BuildCombo("select Group_Cd,Descr from hr_group_ref order by Descr", cmbPos)
            cmbPos.Items.Add("All")
            cmbPos.SelectedValue = "All"
            txtFrom.Text = "1/1/" & Year(Now)
            txtTo.Text = Format(Now, "MM/dd/yyyy")
        End If
    End Sub

    Protected Sub cmdReturn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.Click
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub cmdRefresh_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdRefresh.Click
        DataRefresh()
    End Sub
    Private Sub DataRefresh()
        Dim da As sqlclient.sqlDataAdapter
        Dim ds As New DataSet
        Dim vCond As String = ""

        vCond = " where DateFiled between '" & Format(CDate(txtFrom.Text), "yyyy/MM/dd") & _
            "' and '" & Format(CDate(txtTo.Text), "yyyy/MM/dd") & "' "

        If cmbPos.SelectedValue <> "All" Then
            'vCond += " and instr(Pos_cd,'" & cmbPos.SelectedValue & "') > 0"
            vCond += " and Pos_cd='" & cmbPos.SelectedValue & "' "
        End If

        If txtSearch.Text.Trim <> "" Then
            vCond += " and " & cmbType.SelectedValue & " like '" & txtSearch.Text & "%'"
        End If
        c.ConnectionString = connStr

        vSQL = "select DateFiled as Date_Filed," & _
            "ApplicantNo,Lname,Fname,Mname,Pos_cd as Position,Tel,Email," & _
            "DesiredSalaryFrom,DesiredSalaryTo from hr_applicant_master " & _
            vCond & " order by Lname,Fname"


        da = New SqlClient.SqlDataAdapter(vSQL, c)

        da.Fill(ds, "applicant")
        tblApplicant.DataSource = ds.Tables("applicant")
        tblApplicant.DataBind()
        ds.Dispose()
        da.Dispose()
    End Sub

    Protected Sub tblApplicant_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles tblApplicant.PageIndexChanging
        tblApplicant.PageIndex = e.NewPageIndex
        DataRefresh()
    End Sub

    Protected Sub cmdGenInfo_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdGenInfo.Click, _
        cmdGenInfo2.Click, cmdEducation.Click, cmdFamily.Click, cmdIdent.Click, cmdRef.Click, cmdSkills.Click, _
        cmdWork.Click

        Dim vASPX As String = ""
        Dim vScale As String = ""
        If tblApplicant.SelectedIndex <> -1 And tblApplicant.SelectedIndex <= tblApplicant.Rows.Count Then
            Session("applicantno") = tblApplicant.SelectedRow.Cells(1).Text
            Select Case CType(sender, System.Web.UI.WebControls.Button).ID.ToLower
                Case "cmdgeninfo"
                    vASPX = "applicantgeninfo.aspx"
                    vScale = "width=700,height=450,top=100,left=100"
                Case "cmdgeninfo2"
                    vASPX = "applicantgeninfo2.aspx"
                    vScale = "width=650,height=280,top=100,left=100"
                Case "cmdeducation"
                    vASPX = "applicanteducation.aspx"

                Case "cmdfamily"
                    vASPX = "applicantfamily.aspx"
                    vScale = "width=700,height=450,top=100,left=100"
                Case "cmdident"
                    vASPX = "applicantident.aspx"
                    vScale = "width=550,height=180,top=200,left=200"
                Case "cmdref"
                    vASPX = "applicantref.aspx"
                    vScale = "width=830,height=270,top=100,left=100"
                Case "cmdskills"
                    vASPX = "applicantskills.aspx"
                    vScale = "width=650,height=450,top=100,left=100"
                Case "cmdwork"
                    vASPX = "applicantwork.aspx"
                    vScale = "width=800,height=450,top=100,left=100"
            End Select
            vScript = "logwin=window.open('" & vASPX & "','logwin','location=no,toolber=no," & _
                vScale & "');"
        Else
            vScript = "alert('You must first select an applicant record to view its information.');"
        End If
    End Sub

    Protected Sub cmdDel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDel.Click
        If tblApplicant.SelectedIndex <> -1 And tblApplicant.SelectedIndex <= tblApplicant.Rows.Count Then
            c.ConnectionString = connStr
            c.Open()
            Dim vId As String = tblApplicant.SelectedRow.Cells(1).Text
            Dim cm As New sqlclient.sqlcommand("delete from hr_applicant_employment_hist where Emp_Id='" & _
                vId & "'", c)
            cm.ExecuteNonQuery()
            cm.CommandText = "delete from hr_applicant_reference where Emp_Cd='" & vId & "'"
            cm.ExecuteNonQuery()
            cm.CommandText = "delete from hr_applicant_scholastic where Emp_Cd='" & vId & "'"
            cm.ExecuteNonQuery()
            cm.CommandText = "delete from hr_applicant_master where ApplicantNo=" & vId
            cm.ExecuteNonQuery()
            DataRefresh()
            vScript = "alert('Records were successfully deleted for Applicant No.: " & vId & "');"
        End If
    End Sub

    Protected Sub cmdPrint_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdPrint.Click
        If tblApplicant.SelectedIndex <> -1 And tblApplicant.SelectedIndex <= tblApplicant.Rows.Count And _
            tblApplicant.Rows.Count > 0 Then
            Server.Transfer("printresume.aspx?appid=" & tblApplicant.SelectedRow.Cells(1).Text)
        Else
            vScript = "alert('You must first select an applicant.');"
        End If
    End Sub

    Protected Sub cmdSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSearch.Click
        DataRefresh()
    End Sub
End Class
