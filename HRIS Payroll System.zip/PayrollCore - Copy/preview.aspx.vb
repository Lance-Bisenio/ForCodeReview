Imports denaro
Partial Class preview
    Inherits System.Web.UI.Page
    Public vListen As String = ""
    Public vDate As Date = Now
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        With Me
            .lblHeader.Text = Session("vHeader")
            .lblPeriod.Text = Session("vPeriod")
            .lblFilter.Text = Session("vFilter")
        End With

        vListen = Session("vList")
    End Sub
End Class