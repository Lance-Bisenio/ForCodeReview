﻿Imports denaro.fis
Partial Class importexception
    Inherits System.Web.UI.Page
    Public vDetail As String = ""
    Public vScript As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            vScript = "alert('Your login session has expired. Please re-login again.'); window.close();"
            Exit Sub
        End If
        If Not IsPostBack Then
            Dim c As New SqlClient.SqlConnection(connStr)
            Dim cm As New SqlClient.SqlCommand
            Dim cmRef As New SqlClient.SqlCommand
            Dim rs As SqlClient.SqlDataReader
            Dim rsRef As SqlClient.SqlDataReader
            Dim vClass As String = "odd"
            Dim vRemarks As String = ""
            Dim vDump As String = "Emp Id,Employee Name,Remarks" & vbNewLine

            Try
                c.Open()
            Catch ex As SqlClient.SqlException
                vScript = "alert('An error occurred while trying to connect to database. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                c.Dispose()
                cm.Dispose()
                cmRef.Dispose()
                Exit Sub
            End Try
            cm.Connection = c
            cmRef.Connection = c
            Try
                cm.CommandText = "select * from import_emp_master order by Emp_Lname,Emp_Fname"
                rs = cm.ExecuteReader
                Do While rs.Read
                    vRemarks = ""
                    If IsDBNull(rs("Sss_No")) Then
                        vRemarks = "No SSS Number"
                    Else
                        If rs("Sss_No").ToString.Trim = "" Then
                            vRemarks = "No SSS Number"
                        Else
                            If rs("Sss_No").ToString.Replace("-", "").Trim.Length <> 10 Then
                                vRemarks = "Invalid length on SSS Number"
                            Else
                                cmRef.CommandText = "select Emp_Cd,Emp_Lname,Emp_Fname from py_emp_master where Sss_No='" & _
                                    rs("Sss_No") & "' and Emp_Cd<>'" & rs("Emp_Cd") & "'"
                                rsRef = cmRef.ExecuteReader
                                If rsRef.Read Then
                                    vRemarks = "SSS # already in use by " & rsRef("Emp_Cd") & "=>" & _
                                        rsRef("Emp_Lname") & ", " & rsRef("Emp_Fname")
                                End If
                                rsRef.Close()
                            End If
                        End If
                    End If

                    If vRemarks <> "" Then vRemarks += "<br/>"

                    If IsDBNull(rs("Tin")) Then
                        vRemarks += "No TIN"
                    Else
                        If rs("Tin").ToString.Trim = "" Then
                            vRemarks = "No TIN"
                        Else
                            If rs("Tin").ToString.Replace("-", "").Trim.Length <> 9 Then
                                vRemarks = "Invalid length on TIN"
                            Else
                                cmRef.CommandText = "select Emp_Cd,Emp_Lname,Emp_Fname from py_emp_master where Tin='" & _
                                    rs("Tin") & "' and Emp_Cd<>'" & rs("Emp_Cd") & "'"
                                rsRef = cmRef.ExecuteReader
                                If rsRef.Read Then
                                    vRemarks = "TIN already in use by " & rsRef("Emp_Cd") & "=>" & _
                                        rsRef("Emp_Lname") & ", " & rsRef("Emp_Fname")
                                End If
                                rsRef.Close()
                            End If
                        End If
                    End If

                    If vRemarks <> "" Then vRemarks += "<br/>"

                    If IsDBNull(rs("Tax_Cd")) Then
                        vRemarks += "No Tax Exemption Code"
                    Else
                        If rs("Tax_Cd").ToString.Trim = "" Then
                            vRemarks = "No Tax Exemption Code"
                        End If
                    End If

                    If vRemarks <> "" Then vRemarks += "<br/>"

                    If IsDBNull(rs("Acct_No")) Then
                        vRemarks += "No Bank Account #"
                    Else
                        If rs("Acct_No").ToString.Trim = "" Then
                            vRemarks = "No Bank Account #"
                        Else
                            cmRef.CommandText = "select Emp_Cd,Emp_Lname,Emp_Fname from py_emp_master where Acct_No='" & _
                                rs("Acct_No") & "' and Emp_Cd<>'" & rs("Emp_Cd") & "'"
                            rsRef = cmRef.ExecuteReader
                            If rsRef.Read Then
                                vRemarks = "Bank Account # already in use by " & rsRef("Emp_Cd") & "=>" & _
                                    rsRef("Emp_Lname") & ", " & rsRef("Emp_Fname")
                            End If
                            rsRef.Close()
                        End If
                    End If

                    If vRemarks <> "" Then vRemarks += "<br/>"

                    If IsDBNull(rs("Rate_Month")) Then
                        vRemarks += "No Monthly Salary Rate"
                    Else
                        If rs("Rate_Month") = 0 Then
                            vRemarks = "No Monthly Salary Rate"
                        End If
                    End If

                    If vRemarks <> "" Then
                        vDetail += "<tr class='" & vClass & "'>" & _
                            "<td class='labelL'>" & rs("Emp_Cd") & "</td>" & _
                            "<td class='labelL'>" & rs("Emp_Lname") & ", " & rs("Emp_Fname") & "</td>" & _
                            "<td class='labelL'>" & vRemarks & "</td>" & _
                            "</tr>"
                        vDump += rs("Emp_Cd") & "," & rs("Emp_Lname") & ", " & rs("Emp_Fname") & "," & _
                            vRemarks & vbNewLine
                        vClass = IIf(vClass = "odd", "even", "odd")
                    End If

                Loop
                rs.Close()

                IO.File.WriteAllText(Server.MapPath(".") & "\downloads\" & Session.SessionID & "-import_exception.csv", vDump)
                lnkDownload.NavigateUrl = "downloads/" & Session.SessionID & "-import_exception.csv"

            Catch ex As SqlClient.SqlException
                vScript = "alert('An error occurred while trying to retrieve temporary table. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            Finally
                c.Close()
                cm.Dispose()
                cmRef.Dispose()
                c.Dispose()
            End Try
        End If
    End Sub
End Class
