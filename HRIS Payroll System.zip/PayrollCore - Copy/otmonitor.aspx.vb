Imports denaro
Partial Class otmonitor
    Inherits System.Web.UI.Page
    Public vScript As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Session("returnaddr") = "otmonitor.aspx"
            Server.Transfer("index.aspx")
        End If
        If Not IsPostBack Then
            If Not CanRun(Session("caption"), Request.Item("id")) Then
                Session("denied") = "1"
                Server.Transfer("main.aspx")
                Exit Sub
            End If
            Dim c As New SqlClient.SqlConnection(connStr)

            lblcaption.text = "Employee Overtime Monitoring"
            txtFrom.Text = Format(DateAdd(DateInterval.Day, -15, Now), "MM/dd/yyyy")
            txtTo.Text = Format(Now, "MM/dd/yyyy")
            Try
                c.Open()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                c.Dispose()
                Exit Sub
            End Try

            BuildCombo("select Rc_Cd, Descr from rc where Rc_Cd in ('" & _
                   Session("rclist").ToString.Replace(",", "','") & "') order by Descr ", cmbRC, c)
            BuildCombo("select AgencyCd,AgencyName from agency where Agencycd in ('" & _
                Session("agencylist").ToString.Replace(",", "','") & "') order by AgencyName", cmbOfc, c)
            BuildCombo("select Div_Cd,Descr from hr_div_ref where Div_Cd in ('" & _
                Session("divlist").ToString.Replace(",", "','") & "') order by Descr", cmbDiv, c)
            BuildCombo("select Dept_Cd,Descr from hr_dept_ref where Dept_Cd in ('" & _
                Session("deptlist").ToString.Replace(",", "','") & "') order by Descr", cmbDept, c)
            BuildCombo("select Section_Cd,Descr from hr_section_ref where Section_Cd in ('" & _
                Session("sectionlist").ToString.Replace(",", "','") & "') order by Descr", cmbSection, c)
            BuildCombo("select Unit_Cd,Descr from hr_unit_ref where Unit_Cd in ('" & _
                Session("unitlist").ToString.Replace(",", "','") & "') order by Descr", cmbUnit, c)
            BuildCombo("select EmploymentType,Descr from hr_employment_type where EmploymentType in ('" & _
                Session("typelist").ToString.Replace(",", "','") & "') order by Descr", cmbEmpType, c)
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:     Rudner Diaz                                                            ''
            '' DATE:            4/5/2013                                                               ''
            '' PURPOSE:         To include the Payment mode in the query                               ''
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            BuildCombo("select Pay_Cd,Payment from py_pay_mode order by Payment", cmbPaymode, c)
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''


            c.Close()
            c.Dispose()
            cmbRC.Items.Add("All")
            cmbRC.SelectedValue = "All"
            cmbOfc.Items.Add("All")
            cmbOfc.SelectedValue = "All"
            cmbDiv.Items.Add("All")
            cmbDiv.SelectedValue = "All"
            cmbDept.Items.Add("All")
            cmbDept.SelectedValue = "All"
            cmbSection.Items.Add("All")
            cmbSection.SelectedValue = "All"
            cmbUnit.Items.Add("All")
            cmbUnit.SelectedValue = "All"
            cmbEmpType.Items.Add("All")
            cmbEmpType.SelectedValue = "All"

            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:     Rudner Diaz                                                            ''
            '' DATE:            4/5/2013                                                               ''
            '' PURPOSE:         To include the Payment mode in the query                               ''
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            cmbPaymode.Items.Add("All")
            cmbPaymode.SelectedValue = "All"
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            Session("letter") = "A"
            DataRefresh(Session("letter"))
        Else
            If txtStatus.Value = "1" Then       'cancel confirmed
                Dim vVoid As Boolean
                Dim vHours As Decimal = 0
                Dim vCreditTo As String = "OT"
                Dim c As New SqlClient.SqlConnection(connStr)
                Dim cm As New sqlclient.sqlcommand
                Dim dr As sqlclient.sqldatareader

                Try
                    c.Open()
                Catch ex As SqlClient.SqlException
                    vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                        ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                    c.Dispose()
                    Exit Sub
                End Try

                cm.Connection = c
                cm.CommandText = "select Void,DaysLeave,CreditTo from hr_leave_application where Emp_Cd='" & _
                    Session("empid") & "' and TranDate='" & Format(CDate(Session("tdate")), "yyyy/MM/dd HH:mm:ss") & "'"
                Try
                    dr = cm.ExecuteReader
                    If dr.Read Then
                        vVoid = dr("Void")
                        vHours = Math.Round(dr("DaysLeave") / 2, 2)
                        vCreditTo = dr("CreditTo")
                    End If
                    dr.Close()

                    cm.CommandText = "update hr_leave_application set Void=" & IIf(vVoid, 0, 1) & _
                        " where Emp_Cd='" & Session("empid") & "' and TranDate='" & _
                        Format(CDate(Session("tdate")), "yyyy/MM/dd HH:mm:ss") & "'"
                    cm.ExecuteNonQuery()


                    'now adjust the creditto accordingly if creditto value is not "OT"
                    If vCreditTo <> "OT" Then
                        If vVoid Then   're-activated
                            cm.CommandText = "update py_emp_leave set Credit=Credit + " & vHours & _
                                ",Balance=Balance + " & vHours & " where Emp_Cd='" & Session("empid") & _
                                "' and Leave_Cd='" & vCreditTo & "'"
                        Else            'deactivated
                            cm.CommandText = "update py_emp_leave set Credit=Credit - " & vHours & _
                                ",Balance=Balance - " & vHours & " where Emp_Cd='" & Session("empid") & _
                                "' and Leave_Cd='" & vCreditTo & "'"
                        End If
                        cm.ExecuteNonQuery()
                    End If

                    EventLog(Session("uid"), Request.ServerVariables("REMOTE_ADDR"), "VOID/UNVOID", _
                        "Credit To=" & vCreditTo & "|Void=" & IIf(vVoid, "Void", "Active"), _
                        "Credit To=" & vCreditTo & "|Void=" & IIf(vVoid, "Active", "Void"), _
                        "Employee ID: " & Session("empid") & _
                        " OT application was modified", "Overtime Monitoring", c)
                Catch ex As SqlClient.SqlException
                    vScript = "alert('Error occurred while trying to update record. Error is: " & _
                        ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                Finally
                    cm.Dispose()
                    c.Close()
                    c.Dispose()
                End Try
                txtStatus.Value = ""
                RefreshLeave(Session("empid"))
            End If
        End If
    End Sub
    Private Sub DataRefresh(ByVal pLetter As String)
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim da As SqlClient.SqlDataAdapter
        Dim ds As New DataSet
        Dim vFilter As String = " and " & cmbType.SelectedValue & " like '" & pLetter & "%' "

        Select Case Val(cmbStatus.SelectedValue)
            Case 1  'active employees only
                vFilter += " and Date_Resign is null "
            Case 0  'inactive employees only
                vFilter += " and Date_Resign is not null "
        End Select

        If cmbRC.SelectedValue <> "All" Then   'filter by cost center
            vFilter += " and Rc_Cd='" & cmbRC.SelectedValue & "' "
        Else
            vFilter += " and Rc_Cd in ('" & Session("rclist").ToString.Replace(",", "','") & "') "
        End If
        If cmbOfc.SelectedValue <> "All" Then        'filter by office/agency
            vFilter += " and Agency_Cd='" & cmbOfc.SelectedValue & "' "
        Else
            vFilter += " and Agency_Cd in ('" & Session("agencylist").ToString.Replace(",", "','") & "') "
        End If
        If cmbDiv.SelectedValue <> "All" Then      'filter by division
            vFilter += " and Divcd='" & cmbDiv.SelectedValue & "' "
        Else
            vFilter += " and DivCd in ('" & Session("divlist").ToString.Replace(",", "','") & "') "
        End If
        If cmbDept.SelectedValue <> "All" Then  'filter by departments
            vFilter += " and DeptCd='" & cmbDept.SelectedValue & "' "
        Else
            vFilter += " and DeptCd in ('" & Session("deptlist").ToString.Replace(",", "','") & "') "
        End If
        If cmbSection.SelectedValue <> "All" Then 'filter by section
            vFilter += " and SectionCd='" & cmbSection.SelectedValue & "' "
        Else
            vFilter += " and SectionCd in ('" & Session("sectionlist").ToString.Replace(",", "','") & "') "
        End If
        If cmbUnit.SelectedValue <> "All" Then  'filter by units
            vFilter += " and UnitCd='" & cmbUnit.SelectedValue & "' "
        Else
            vFilter += " and UnitCd in ('" & Session("unitlist").ToString.Replace(",", "','") & "') "
        End If
        If cmbEmpType.SelectedValue <> "All" Then 'filter by employment types
            vFilter += " and EmploymentType='" & cmbEmpType.SelectedValue & "' "
        Else
            vFilter += " and EmploymentType in ('" & Session("typelist").ToString.Replace(",", "','") & "') "
        End If
        If cmbPaymode.SelectedValue <> "All" Then 'filter by Payment mode
            vFilter += " and Pay_Cd='" & cmbPaymode.SelectedValue & "' "
        End If


        Try
            da = New SqlClient.SqlDataAdapter("select Emp_Cd,Emp_Lname,Emp_Fname,Emp_Mname from py_emp_master " & _
                "where Date_Resign is null and DateHold is null and DateSuspended is null and Date_Retired is null " & _
                vFilter & " order by Emp_Lname,Emp_Fname,Emp_Mname", c)
            da.Fill(ds, "EmpMaster")
            tblEmp.DataSource = ds.Tables("EmpMaster")
            tblEmp.DataBind()
            da.Dispose()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to Retrieve records. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Dispose()
            ds.Dispose()
        End Try
    End Sub

    Protected Sub cmdA_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdA.Click, _
        cmdB.Click, cmdC.Click, cmdD.Click, cmdE.Click, cmdF.Click, cmdG.Click, cmdH.Click, cmdI.Click, _
        cmdJ.Click, cmdK.Click, cmdL.Click, cmdM.Click, cmdN.Click, cmdO.Click, cmdP.Click, cmdQ.Click, _
        cmdR.Click, cmdS.Click, cmdT.Click, cmdU.Click, cmdV.Click, cmdW.Click, cmdX.Click, cmdY.Click, cmdZ.Click
        EnableAll()
        Session("letter") = CType(sender, LinkButton).Text
        txtSearch.Text = CType(sender, LinkButton).Text
        tblEmp.SelectedIndex = -1
        DataRefresh(Session("letter"))
        CType(sender, LinkButton).Enabled = False
    End Sub
    Private Sub EnableAll()
        cmdA.Enabled = True : cmdB.Enabled = True : cmdC.Enabled = True : cmdD.Enabled = True
        cmdE.Enabled = True : cmdF.Enabled = True : cmdG.Enabled = True : cmdH.Enabled = True
        cmdI.Enabled = True : cmdJ.Enabled = True : cmdK.Enabled = True : cmdL.Enabled = True
        cmdM.Enabled = True : cmdN.Enabled = True : cmdO.Enabled = True : cmdP.Enabled = True
        cmdQ.Enabled = True : cmdR.Enabled = True : cmdS.Enabled = True : cmdT.Enabled = True
        cmdU.Enabled = True : cmdV.Enabled = True : cmdW.Enabled = True : cmdX.Enabled = True
        cmdY.Enabled = True : cmdZ.Enabled = True
    End Sub

    Protected Sub tblEmp_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles tblEmp.PageIndexChanging
        tblEmp.PageIndex = e.NewPageIndex
        DataRefresh(txtSearch.Text)
    End Sub

    Protected Sub tblEmp_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tblEmp.SelectedIndexChanged
        Page.Validate()
        If Page.IsValid Then
            Dim vEmpId As String = tblEmp.SelectedRow.Cells(0).Text
            Session("empid") = vEmpId
            RefreshLeave(vEmpId)
        End If
    End Sub
    Private Sub RefreshLeave(ByVal pEmpId As String)
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim da As SqlClient.SqlDataAdapter
        Dim ds As New DataSet
        Dim vQry As String = ""

        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                                        ''
        '' DATE MODIFIED: 5/29/2013                                            ''
        '' PURPOSE: TO EXPOSE ADDITIONAL FILTERS                               ''
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        If cmbPayMethod.SelectedIndex <> 2 Then
            vQry = cmbPayMethod.SelectedValue
        End If
        Select Case rdoDocStatus.SelectedValue
            Case "1"    'approved applications
                vQry += " and Void=0 and ((DateApproved is not null and RecommendedBy is null and NotedBy is null) or " & _
                    "(DateApproved is not null and RecommendedBy is not null and DateRecommended is not null and NotedBy is null) or " & _
                    "(DateApproved is not null and RecommendedBy is not null and DateRecommended is not null and NotedBy is not null and DateNoted is not null)) "
            Case "2"    'disapproved/cancelled applications
                vQry += " and Void=1 "
            Case "3"    'pending applications
                vQry += " and Void=0 and " & _
                    "((DateApproved is null and RecommendedBy is null and NotedBy is null) or " & _
                    "(DateApproved is not null and RecommendedBy is not null and DateRecommended is null and NotedBy is null) or " & _
                    "(DateApproved is not null and RecommendedBy is not null and DateRecommended is not null and NotedBy is not null and NotedBy is null)) "
        End Select

        Dim vSQL As String = "select TranDate as Tran_Date,LeaveCd,DaysLeave," & _
            "StartDate as DateStart,CreditTo," & _
            "EndDate as DateEnd,Void,Paid,DateApproved as Date_Approved " & _
            ",Posted from hr_leave_application where Emp_Cd='" & pEmpId & "' and StartDate >= '" & _
            Format(CDate(txtFrom.Text), "yyyy/MM/dd") & " 00:00:00' and StartDate <= '" & _
            Format(CDate(txtTo.Text), "yyyy/MM/dd") & " 23:59:59' and LeaveCd='OT' " & vQry & _
            " order by StartDate"
        Session("sql") = "select * from hr_leave_application where Emp_Cd='" & pEmpId & "' and StartDate >= '" & _
            Format(CDate(txtFrom.Text), "yyyy/MM/dd") & " 00:00:00' and StartDate <= '" & _
            Format(CDate(txtTo.Text), "yyyy/MM/dd") & " 23:59:59' and LeaveCd='OT' " & vQry & _
            " order by StartDate"
        Session("sqlByFilter") = "select *,(select Emp_Lname+', '+Emp_Fname from py_emp_master " & _
            "where py_emp_master.Emp_Cd=hr_leave_application.Emp_Cd) as EmpName " & _
            "from hr_leave_application where StartDate >= '" & _
            Format(CDate(txtFrom.Text), "yyyy/MM/dd") & " 00:00:00' and StartDate <= '" & _
            Format(CDate(txtTo.Text), "yyyy/MM/dd") & " 23:59:59' and LeaveCd='OT' " & vQry & _
            " order by EmpName, StartDate"
        '''''''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''''

        Try
            da = New SqlClient.SqlDataAdapter(vSQL, c)

            da.Fill(ds, "Applications")
            tblApplication.DataSource = ds.Tables("Applications")
            tblApplication.DataBind()
            da.Dispose()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to Refresh. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            ds.Dispose()
            c.Dispose()
        End Try
    End Sub

    Protected Sub cmdReturn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.Click
        Session.Remove("letter")
        Session.Remove("empid")
        Session.Remove("tdate")
        Session.Remove("mode")
        Session.Remove("sql")
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub tblApplication_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles tblApplication.PageIndexChanging
        tblApplication.PageIndex = e.NewPageIndex
        RefreshLeave(Session("empid"))
    End Sub

    Protected Sub tblApplication_RowDeleting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewDeleteEventArgs) Handles tblApplication.RowDeleting
        Session("tdate") = tblApplication.Rows(e.RowIndex).Cells(0).Text
        Session("empid") = tblEmp.SelectedRow.Cells(0).Text

        Dim vLabel As Label = tblApplication.Rows(e.RowIndex).FindControl("Label1")


        'If tblApplication.Rows(e.RowIndex).Cells(6).Text = "False" Then
        If vlabel.Text = "Active" Then
            vScript = "ConfirmDelete('Void');"
        Else
            vScript = "ConfirmDelete('Unvoid');"
        End If
    End Sub

    Protected Sub cmdAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdAdd.Click
        If tblEmp.SelectedIndex <> -1 Then    'a selection was made
            Session("empid") = tblEmp.SelectedRow.Cells(0).Text & "=>" & _
                tblEmp.SelectedRow.Cells(1).Text & ", " & _
                tblEmp.SelectedRow.Cells(2).Text
            Session.Remove("tdate")
            Session.Remove("mode")
            vScript = "otwin=window.open('modifyot.aspx','otwin','location=no,toolber=no,width=550,height=450,top=100,left=100');"
        Else
            vScript = "alert('Please select an employee first before adding an application.');"
        End If
    End Sub

    Protected Sub tblApplication_RowEditing(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewEditEventArgs) Handles tblApplication.RowEditing
        Session("empid") = tblEmp.SelectedRow.Cells(0).Text & "=>" & _
                tblEmp.SelectedRow.Cells(1).Text & ", " & _
                tblEmp.SelectedRow.Cells(2).Text
        Session("tdate") = tblApplication.Rows(e.NewEditIndex).Cells(0).Text
        Session.Remove("mode")
        vScript = "otwin=window.open('modifyot.aspx','otwin','location=no,toolber=no,width=550,height=400,top=100,left=100');"
    End Sub

    Protected Sub tblApplication_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tblApplication.SelectedIndexChanged
        Session("empid") = tblEmp.SelectedRow.Cells(0).Text & "=>" & _
                        tblEmp.SelectedRow.Cells(1).Text & ", " & _
                        tblEmp.SelectedRow.Cells(2).Text
        Session("tdate") = tblApplication.SelectedRow.Cells(0).Text
        Session("mode") = "v"
        vScript = "otwin=window.open('modifyot.aspx','otwin','location=no,toolber=no,width=550,height=450,top=100,left=100');"
    End Sub
    Protected Sub cmdSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSearch.Click
        DataRefresh(txtSearch.Text)
    End Sub

   
    Protected Sub CustomValidator1_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles CustomValidator1.ServerValidate
        args.IsValid = IsDate(txtFrom.Text) And IsDate(txtTo.Text)
        If Not args.IsValid Then
            vScript = "alert('Invalid date format in either Start Date or End Date field. Please correct the error and try again.');"
        End If
    End Sub

    Protected Sub txtFrom_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtFrom.Init
        txtFrom.Attributes.Add("onfocus", "showCalendarControl(this);")
    End Sub

    Protected Sub txtTo_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtTo.Init
        txtTo.Attributes.Add("onfocus", "showCalendarControl(this);")
    End Sub

    Protected Sub cmdPrint_Click(sender As Object, e As EventArgs) Handles cmdPrint.Click
        If txtPrintMode.Value = "0" Then
            If tblEmp.SelectedIndex = -1 Then
                vScript = "alert('Please select an employee first.');"
                Exit Sub
            End If
        End If

        Dim vData As String = ""
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cmRef As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim rsRef As SqlClient.SqlDataReader
        Dim vClass As String = "odd"
        Dim iCtr As Integer = 0
        Dim vStatus As String = ""
        Dim vApprovedBy As String = ""
        Dim vRecommendedBy As String = ""
        Dim vNotedBy As String = ""
        Dim vLastEmp As String = ""

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            cmRef.Dispose()
            Exit Sub
        End Try
        cm.Connection = c
        cmRef.Connection = c

        If txtPrintMode.Value = "0" Then
            cm.CommandText = Session("sql")
        Else
            cm.CommandText = Session("sqlByFilter")
        End If

        vData = "<html>" & _
            "<head><title>Overtime Application Prooflist Report</title>" & _
            "<link href='../redtheme/red.css' rel='stylesheet' type='text/css' /></head><body>" & _
            "<div style='text-align:center;'>" & _
            "<h1>Overtime Application prooflist</h1>"
        If txtPrintMode.Value = "0" Then
            vData += "<h2>of " & tblEmp.SelectedRow.Cells(1).Text & ", " & tblEmp.SelectedRow.Cells(2).Text & "</h2>"
        End If

        vData += "<h3>from " & txtFrom.Text & " to " & txtTo.Text & "</h3><hr/>" & _
            "<table border='1' style='width:100%;border-collapse:collapse;' class='label'>" & _
            "<tr class='titleBar'>"
        If txtPrintMode.Value = "1" Then
            vData += "<th>Emp Id</th><th>Employee Name</th>"
        End If
        vData += "<th>Start Date</th>" & _
            "<th>End Date</th>" & _
            "<th>Hrs Approved</th>" & _
            "<th>Credit To</th>" & _
            "<th>Date Applied</th>" & _
            "<th>Status</th>" & _
            "<th>Reason</th>" & _
            "<th>Remarks</th>" & _
            "<th>Approved By</th>" & _
            "<th>Date Approved</th>" & _
            "<th>Recommended By</th>" & _
            "<th>Date Recommended</th>" & _
            "<th>Noted By</th>" & _
            "<th>Date Noted</th></tr>"
        Try
            rs = cm.ExecuteReader
            Do While rs.Read
                If rs("Void") = 1 Then
                    vStatus = "Disapproved/Cancelled"
                Else
                    If (Not IsDBNull(rs("DateApproved")) And IsDBNull(rs("RecommendedBy")) And IsDBNull(rs("NotedBy"))) Or _
                        (Not IsDBNull(rs("DateApproved")) And Not IsDBNull(rs("RecommendedBy")) And Not IsDBNull(rs("DateRecommended")) And IsDBNull(rs("NotedBy"))) Or _
                        (Not IsDBNull(rs("DateApproved")) And Not IsDBNull(rs("RecommendedBy")) And Not IsDBNull(rs("DateRecommended")) And Not IsDBNull(rs("NotedBy")) And Not IsDBNull(rs("DateNoted"))) Then
                        vStatus = "Approved"
                    Else
                        vStatus = "Pending"
                    End If
                End If

                'get approver name
                vApprovedBy = ""
                cmRef.CommandText = "select Emp_Lname,Emp_Fname from py_emp_master where Emp_Cd='" & _
                    rs("ApprovedBy") & "'"
                rsRef = cmRef.ExecuteReader
                If rsRef.Read Then
                    vApprovedBy = rsRef("Emp_Lname") & ", " & rsRef("Emp_Fname")
                End If
                rsRef.Close()

                'get recommending officer name
                vRecommendedBy = ""
                If Not IsDBNull(rs("RecommendedBy")) Then
                    cmRef.CommandText = "select Emp_Lname,Emp_Fname from py_emp_master where Emp_Cd='" & _
                        rs("RecommendedBy") & "'"
                    rsRef = cmRef.ExecuteReader
                    If rsRef.Read Then
                        vRecommendedBy = rsRef("Emp_Lname") & ", " & rsRef("Emp_Fname")
                    End If
                    rsRef.Close()
                End If

                'get noting officer name 
                vNotedBy = ""
                If Not IsDBNull(rs("NotedBy")) Then
                    cmRef.CommandText = "select Emp_Lname,Emp_Fname from py_emp_master where Emp_Cd='" & _
                        rs("NotedBy") & "'"
                    rsRef = cmRef.ExecuteReader
                    If rsRef.Read Then
                        vNotedBy = rsRef("Emp_Lname") & ", " & rsRef("Emp_Fname")
                    End If
                    rsRef.Close()
                End If

                vData += "<tr class='" & vClass & "'>"
                If txtPrintMode.Value = "1" Then
                    If vLastEmp <> rs("Emp_Cd") Then
                        vData += "<td class='labelL'>" & rs("Emp_Cd") & "</td>" & _
                            "<td class='labelL'>" & rs("EmpName") & "</td>"
                        vLastEmp = rs("Emp_Cd")
                    Else
                        vData += "<td class='labelL'>&nbsp;</td><td class='labelL'>&nbsp;</td>"
                    End If
                End If

                vData += "<td class='labelR'>" & Format(CDate(rs("StartDate")), "MM/dd/yyyy HH:mm:ss") & "</td>" & _
                    "<td class='labelR'>" & Format(CDate(rs("EndDate")), "MM/dd/yyyy HH:mm:ss") & "</td>" & _
                    "<td class='labelR'>" & rs("DaysLeave") & "</td>" & _
                    "<td class='labelL'>" & rs("CreditTo") & "</td>" & _
                    "<td class='labelR'>" & Format(CDate(rs("TranDate")), "MM/dd/yyyy HH:mm:ss") & "</td>" & _
                    "<td class='labelL'>" & vStatus & "</td>" & _
                    "<td class='labelL'>" & rs("Reason") & "</td>" & _
                    "<td class='labelL'>" & rs("Remarks") & "</td>" & _
                    "<td class='labelL'>" & vApprovedBy & "</td>" & _
                    "<td class='labelR'>" & IIf(IsDBNull(rs("DateApproved")), "&nbsp;", rs("DateApproved")) & "</td>" & _
                    "<td class='labelL'>" & vRecommendedBy & "</td>" & _
                    "<td class='labelR'>" & IIf(IsDBNull(rs("DateRecommended")), "&nbsp;", rs("DateRecommended")) & "</td>" & _
                    "<td class='labelL'>" & vNotedBy & "</td>" & _
                    "<td class='labelR'>" & IIf(IsDBNull(rs("DateNoted")), "&nbsp;", rs("DateNoted")) & "</td></tr>"

                vClass = IIf(vClass = "odd", "even", "odd")
            Loop
            rs.Close()
            vData += "</table></div></body></html>"
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to retrieve documents. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            c.Dispose()
            cm.Dispose()
            cmRef.Dispose()
        End Try

        Dim vFile As String = Server.MapPath(".") & "\downloads\" & Session.SessionID & iCtr & ".html"
retry:
        If System.IO.File.Exists(vFile) Then
            Try
                System.IO.File.Delete(vFile)
            Catch ex As System.IO.IOException
                iCtr += 1
                vFile = Server.MapPath(".") & "\downloads\" & Session.SessionID & iCtr & ".html"
                GoTo retry
            End Try
        End If

        System.IO.File.WriteAllText(vFile, vData)
        vScript = "alert('Report rendering complete. Click Ok button to preview the report.');" & _
            "winrpt=window.open('downloads/" & Session.SessionID & iCtr & _
            ".html','winrpt','top=0,left=10,width=1024,height=640,resizable=yes,scrollbars=yes');"
    End Sub
End Class
