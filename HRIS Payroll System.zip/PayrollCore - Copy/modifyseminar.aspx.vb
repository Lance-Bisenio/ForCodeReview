Imports denaro
Partial Class modifyseminar
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Dim c As New sqlclient.sqlconnection
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If
        If Not IsPostBack Then
            Dim cm As New sqlclient.sqlcommand
            Dim dr As sqlclient.sqldatareader
            txtSemNo.Text = Session("empid")
            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c
            lblcaption.text = "Add/Modify Seminar"
            If Session("mode") = "e" Or Session("mode") = "v" Then
                cm.CommandText = "select * from hr_seminar_ref where Seminar_No=" & Session("semno")
                dr = cm.ExecuteReader
                If dr.Read Then
                    txtSemNo.Text = dr("Seminar_No")
                    txtSeminarName.Text = IIf(IsDBNull(dr("Sem_Title")), "", dr("Sem_Title"))
                    txtPlace.Text = IIf(IsDBNull(dr("Location")), "", dr("Location"))
                    txtFrom.Text = IIf(IsDBNull(dr("From_Date")), "", Format(dr("From_Date"), "MM/dd/yyyy"))
                    txtTo.Text = IIf(IsDBNull(dr("To_Date")), "", Format(dr("To_Date"), "MM/dd/yyyy"))
                    txtCost.Text = IIf(IsDBNull(dr("Expenses")), 0, dr("Expenses"))
                    txtSpeaker.Text = IIf(IsDBNull(dr("Trainor_Name")), "", dr("Trainor_Name"))
                    txtContact.Text = IIf(IsDBNull(dr("Trainor_Tel")), 0, dr("Trainor_Tel"))
                    txtAddr.Text = IIf(IsDBNull(dr("Address")), "", dr("Address"))
                    txtOtherInfo.Text = IIf(IsDBNull(dr("Trainor_Other")), "", dr("Trainor_Other"))
                    txtRemarks.Text = IIf(IsDBNull(dr("Other_Info")), "", dr("Other_Info"))
                    txtMaterials.Text = IIf(IsDBNull(dr("Materials_Used")), "", dr("Materials_Used"))
                    txtHrs.Text = IIf(IsDBNull(dr("ManHours")), 0, dr("ManHours"))
                    rdoType.SelectedIndex = IIf(IsDBNull(dr("Internal")), 0, dr("Internal"))
                End If
                dr.Close()
                If Session("mode") = "v" Then 'freeze fields
                    txtSemNo.ReadOnly = True
                    txtSeminarName.ReadOnly = True
                    txtPlace.ReadOnly = True
                    txtFrom.ReadOnly = True
                    txtTo.ReadOnly = True
                    txtCost.ReadOnly = True
                    txtSpeaker.ReadOnly = True
                    txtContact.ReadOnly = True
                    txtAddr.ReadOnly = True
                    txtOtherInfo.ReadOnly = True
                    txtRemarks.ReadOnly = True
                    txtMaterials.ReadOnly = True
                    txtHrs.ReadOnly = True
                    rdoType.Enabled = False
                End If
            End If
            cm.Dispose()
            c.Close()
        End If
    End Sub

    Protected Sub cmdCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        Session.Remove("semno")
        Session.Remove("mode")
        vScript = "window.close();"
    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        If Page.IsValid Then
            Dim cm As New sqlclient.sqlcommand
            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c
            If Session("mode") = "e" Then 'edit mode
                cm.CommandText = "update hr_seminar_ref set From_Date='" & _
                    Format(CDate(txtFrom.Text), "yyyy/MM/dd") & _
                    "',To_Date='" & Format(CDate(txtTo.Text), "yyyy/MM/dd") & _
                    "',Expenses=" & txtCost.Text & _
                    ",Trainor_Name='" & txtSpeaker.Text & _
                    "',Address='" & txtAddr.Text & _
                    "',Trainor_Tel='" & txtContact.Text & _
                    "',Trainor_Other='" & txtOtherInfo.Text & _
                    "',Materials_Used='" & txtMaterials.Text & _
                    "',Sem_Title='" & txtSeminarName.Text & _
                    "',Location='" & txtPlace.Text & _
                    "',Other_Info='" & txtRemarks.Text & _
                    "',ManHours=" & txtHrs.Text & _
                    " where Seminar_No=" & txtSemNo.Text
            Else                          'add mode
                cm.CommandText = "insert into hr_seminar_ref (Seminar_No,From_Date,To_Date,Expenses," & _
                    "Trainor_Name,Address,Trainor_Tel,Trainor_Other,Materials_Used,Sem_Title," & _
                    "Location,Other_Info,ManHours) values (" & txtSemNo.Text & ",'" & _
                    Format(CDate(txtFrom.Text), "yyyy/MM/dd") & "','" & _
                    Format(CDate(txtTo.Text), "yyyy/MM/dd") & "'," & txtCost.Text & ",'" & _
                    txtSpeaker.Text & "','" & txtAddr.Text & "','" & txtContact.Text & "','" & _
                    txtOtherInfo.Text & "','" & txtMaterials.Text & "','" & txtSeminarName.Text & _
                    "','" & txtPlace.Text & "','" & txtRemarks.Text & "'," & txtHrs.Text & ")"
            End If
            cm.ExecuteNonQuery()
            Session.Remove("mode")
            Session.Remove("semno")
            vScript = "alert('Changes where successfully saved.'); window.close();"
        End If
    End Sub

    Protected Sub vldDate_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles vldDate.ServerValidate
        vldDate.ErrorMessage = "Invalid date format."
        If txtFrom.Text = "" Then
            vScript = "alert('From date field should not be empty.');"
            args.IsValid = False
            Exit Sub
        End If
        If txtTo.Text = "" Then
            vScript = "alert('To date field should not be empty.');"
            args.IsValid = False
            Exit Sub
        End If
        If Not IsDate(txtFrom.Text) Then
            vScript = "alert('The From date field has an invalid date format.');"
            args.IsValid = False
            Exit Sub
        End If
        If Not IsDate(txtTo.Text) Then
            vScript = "alert('The To date field has an invalid date format.');"
            args.IsValid = False
            Exit Sub
        End If
        If txtSeminarName.Text = "" Then
            vScript = "alert('Training name field should not be empty.');"
            vldDate.ErrorMessage = "Training name field should not be empty."
            args.IsValid = False
            Exit Sub
        End If
        If Not IsNumeric(txtCost.Text) Then
            vScript = "alert('Fee field has an invalid numeric format.');"
            vldDate.ErrorMessage = "Fee field has an invalid numeric format."
            args.IsValid = False
            Exit Sub
        End If
        If txtSemNo.Text = "" Then
            vScript = "alert('Seminar # field should not be empty.');"
            vldDate.ErrorMessage = "Seminar # field should be empty."
            args.IsValid = False
            Exit Sub
        End If
        args.IsValid = True
    End Sub
End Class
