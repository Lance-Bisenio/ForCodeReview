Imports denaro
Partial Class applicantgeninfo2
    Inherits System.Web.UI.Page
    Dim c As New sqlclient.sqlconnection
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If

        If Not IsPostBack Then
            Dim cRef As New sqlclient.sqlconnection(connStr)
            Dim cm As New sqlclient.sqlcommand
            Dim cmRef As New sqlclient.sqlcommand
            Dim dr As sqlclient.sqldatareader
            Dim drRef As sqlclient.sqldatareader

            lblCaption.Text = "Applicant's General Information (2 of 2)"
            c.ConnectionString = connStr
            cRef.Open()
            c.Open()
            cm.Connection = c
            cmRef.Connection = cRef
            cm.CommandText = "select * from hr_applicant_master where ApplicantNo=" & _
                Session("applicantno")
            dr = cm.ExecuteReader
            If dr.Read Then
                cmRef.CommandText = "select Descr from hr_citizenship_ref where Citizen_Cd='" & _
                    dr("CitizenCd") & "'"
                drRef = cmRef.ExecuteReader
                txtCitizenship.Text = ""
                If drRef.Read Then
                    txtCitizenship.Text = drRef("Descr")
                End If
                drRef.Close()
                cmRef.CommandText = "select Descr from py_civil_ref where Civil_Cd='" & _
                    dr("Civil_Cd") & "'"
                drRef = cmRef.ExecuteReader
                txtCivil.Text = ""
                If drRef.Read Then
                    txtCivil.Text = drRef("Descr")
                End If
                drRef.Close()
                cmRef.CommandText = "select Descr from hr_religion_ref where ReligionCd='" & _
                    dr("ReligionCd") & "'"
                drRef = cmRef.ExecuteReader
                txtReligion.Text = ""
                If drRef.Read Then
                    txtReligion.Text = drRef("Descr")
                End If
                drRef.Close()
                cmRef.CommandText = "select Descr from hr_bloodtype_ref where BloodType='" & _
                    dr("BloodType") & "'"
                drRef = cmRef.ExecuteReader
                txtType.Text = ""
                If drRef.Read Then
                    txtType.Text = drRef("Descr")
                End If
                drRef.Close()
                txtBDate.Text = ""
                If IsDBNull(dr("Bday")) Then
                    txtBDate.Text = ""
                Else
                    txtBDate.Text = Format(dr("Bday"), "MM/dd/yyyy")
                End If
                txtId.Text = dr("ApplicantNo")
                txtName.Text = dr("Lname") & ", " & dr("Fname") & " " & dr("Mname")
                txtSex.Text = IIf(dr("Male"), "Male", "Female")
                txtBPlace.Text = IIf(IsDBNull(dr("BirthPlace")), "", dr("BirthPlace"))
                txtChildren.Text = IIf(IsDBNull(dr("ChildrenNo")), "", dr("ChildrenNo"))
                txtHeight.Text = IIf(IsDBNull(dr("Height")), "", dr("Height"))
                txtWeight.Text = IIf(IsDBNull(dr("Weight")), "", dr("Weight"))
            End If
            dr.Close()
            cm.Dispose()
            cmRef.Dispose()
            cRef.Close()
            cRef.Dispose()
            c.Close()
        End If
    End Sub
End Class
