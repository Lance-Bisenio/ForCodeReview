Imports denaro
Partial Class coinfo
    Inherits System.Web.UI.Page
    Public vScript As String = ""
   
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Session("returnaddr") = "coinfo.aspx"
            Server.Transfer("index.aspx")
        End If
        If Not CanRun(Session("caption"), Request.Item("id")) Then
            Session("denied") = "1"
            Server.Transfer("main.aspx")
            Exit Sub
        End If

        If Not IsPostBack Then
            lblCaption.Text = "Company Information"
            BuildCombo("select AgencyCd,AgencyName from agency order by AgencyName", cmbAgency)
            BuildCombo("select Bank_Code,Bank_Name from bank_codes order by Bank_Name", cmbBank)
            DataRefresh()
        End If
    End Sub
    Private Sub DataRefresh()
        If cmbAgency.Items.Count > 0 Then
            Dim c As New SqlClient.SqlConnection
            Dim dr As SqlClient.SqlDataReader
            Dim cm As New SqlClient.SqlCommand

            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c
            cm.CommandText = "select * from glsyscntrl where AgencyCd='" & _
                cmbAgency.SelectedValue & "'"
            dr = cm.ExecuteReader
            txtCompCd.Text = ""
            txtCompName.Text = ""
            txtContactPerson.Text = ""
            txtContactPosition.Text = ""
            txtAddress.Text = ""
            txtCity.Text = ""
            txtCountry.Text = ""
            txtZIP.Text = ""
            txtTel.Text = ""
            txtFax.Text = ""
            txtSSS.Text = ""
            txtPagibig.Text = ""
            txtPhilhealth.Text = ""
            txtTIN.Text = ""
            txtBankAcct.Text = ""
            If dr.Read Then
                txtCompCd.Text = IIf(IsDBNull(dr("CompanyCd")), "", dr("CompanyCd"))
                txtCompName.Text = IIf(IsDBNull(dr("Company_Name")), "", dr("Company_Name"))
                txtContactPerson.Text = IIf(IsDBNull(dr("Attention")), "", dr("Attention"))
                txtContactPosition.Text = IIf(IsDBNull(dr("AttentionPos")), "", dr("AttentionPos"))
                txtAddress.Text = IIf(IsDBNull(dr("Address")), "", dr("Address"))
                txtCity.Text = IIf(IsDBNull(dr("City")), "", dr("City"))
                txtCountry.Text = IIf(IsDBNull(dr("Country")), "", dr("Country"))
                txtZIP.Text = IIf(IsDBNull(dr("Zip")), "", dr("Zip"))
                txtTel.Text = IIf(IsDBNull(dr("Phone")), "", dr("Phone"))
                txtFax.Text = IIf(IsDBNull(dr("Fax")), "", dr("Fax"))
                txtSSS.Text = IIf(IsDBNull(dr("Employer_SssNo")), "", dr("Employer_SssNo"))
                txtPagibig.Text = IIf(IsDBNull(dr("PagIbigNo")), "", dr("PagIbigNo"))
                txtPhilhealth.Text = IIf(IsDBNull(dr("PhicNo")), "", dr("PhicNo"))
                txtTIN.Text = IIf(IsDBNull(dr("Tin")), "", dr("Tin"))
                txtBankAcct.Text = IIf(IsDBNull(dr("BankAcctNo")), "", dr("BankAcctNo"))
                cmbBank.SelectedValue = IIf(IsDBNull(dr("BankCd")), "", dr("BankCd"))
                If Not IsDBNull(dr("CompLogoPath")) Then
                    imgLogo.ImageUrl = dr("CompLogoPath")
                Else
                    imgLogo.ImageUrl = ""
                End If
            End If
            dr.Close()
            c.Close()
            c.Dispose()
            cm.Dispose()
        Else
            vScript = "alert('No Office defined! Please create an office first.');"
        End If
    End Sub
    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        Dim c As New SqlClient.SqlConnection
        Dim cm As New SqlClient.SqlCommand
        Dim dr As SqlClient.SqlDataReader
        Dim iCtr As Integer = 0

        c.ConnectionString = connStr
        Try
            c.Open()
            cm.Connection = c
            cm.CommandText = "select count(*) from glsyscntrl where AgencyCd='" & _
                cmbAgency.selectedvalue & "'"
            dr = cm.ExecuteReader
            If dr.Read Then
                iCtr = IIf(IsDBNull(dr(0)), 0, dr(0))
            End If
            dr.Close()
            If iCtr = 0 Then
                cm.CommandText = "insert glsyscntrl (AgencyCd,CompanyCd) values ('" & _
                    cmbAgency.selectedvalue & "','" & txtCompCd.Text & "')"
                cm.ExecuteNonQuery()
            End If
            cm.CommandText = "update glsyscntrl set CompanyCd='" & txtCompCd.Text & _
                "',Company_Name='" & txtCompName.Text & _
                "',Attention='" & txtContactPerson.Text & _
                "',AttentionPos='" & txtContactPosition.Text & _
                "',Address='" & txtAddress.Text & _
                "',City='" & txtCity.Text & _
                "',Country='" & txtCountry.Text & _
                "',Zip='" & txtZIP.Text & _
                "',Phone='" & txtTel.Text & _
                "',Fax='" & txtFax.Text & _
                "',Employer_SssNo='" & txtSSS.Text & _
                "',PagIbigNo='" & txtPagibig.Text & _
                "',PhicNo='" & txtPhilhealth.Text & _
                "',Tin='" & txtTIN.Text & _
                "',BankAcctNo='" & txtBankAcct.Text & _
                "',BankCd='" & cmbBank.SelectedValue & _
                "',CompLogoPath='" & imgLogo.ImageUrl & "' where AgencyCd='" & cmbAgency.SelectedValue & "'"

            cm.ExecuteNonQuery()
            cm.Dispose()
            c.Close()
            vScript = "alert('Changes were successfull saved!');"
        Catch ex As sqlclient.sqlException
            vScript = "alert('An error occurred while trying to save the changes. ');"
            '    ex.Message.Replace("'", "") & "');"
        End Try
    End Sub

    Protected Sub cmdGet_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdGet.Click
        DataRefresh()
    End Sub

    Protected Sub cmdClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdClose.Click
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub cmdUpload_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdUpload.Click
        If cmdBrowse.FileName = "" Then
            vScript = "alert('You must first select an image file to upload.');"
            Exit Sub
        End If

        Dim vType As String = cmdBrowse.FileName.Substring(cmdBrowse.FileName.LastIndexOf("."))
        Dim vFilename As String = cmbAgency.SelectedValue & vType
        cmdBrowse.SaveAs(Server.MapPath(".") & "\uploaded\" & vFilename)
        imgLogo.ImageUrl = "uploaded/" & vFilename
    End Sub
End Class
