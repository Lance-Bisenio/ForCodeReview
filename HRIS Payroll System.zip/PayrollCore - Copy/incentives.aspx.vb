Imports denaro
Partial Class leavemonitor
    Inherits System.Web.UI.Page
    Public vScript As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If
        If Not IsPostBack Then 'now build the reference code
            If Not CanRun(Session("caption"), Request.Item("id")) Then
                Session("denied") = "1"
                Server.Transfer("main.aspx")
                Exit Sub
            End If

            cmbYearFr.Items.Clear()
            cmbYearTo.Items.Clear()
            For i As Integer = Now.Year - 2 To Now.Year + 1
                cmbYearFr.Items.Add(i)
                cmbYearTo.Items.Add(i)
            Next
            cmbMonthFr.SelectedValue = Now.Month
            cmbMonthTo.SelectedValue = Now.Month
            cmbYearFr.SelectedValue = Now.Year
            cmbYearTo.SelectedValue = Now.Year
            BuildDays()

            lblcaption.text = "Incentives and Other Income Monitoring"
            BuildCombo("select Incentive_Cd,Descr from py_other_incentvs order by Descr", cmbIncent)
            BuildCombo("select Rc_Cd,Descr from rc where exists (select User_Id from rights_list where User_Id='" & _
                  Session("uid") & "' and property='rc' and Property_Value=Rc_Cd) order by Descr", cmbRC)
            BuildCombo("select AgencyCd,AgencyName from agency where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='agency' and Property_Value=AgencyCd) order by AgencyName", cmbOfc)
            BuildCombo("select Div_Cd,Descr from hr_div_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='division' and Property_Value=Div_Cd) order by Descr", cmbDiv)
            BuildCombo("select Dept_Cd,Descr from hr_dept_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='department' and Property_Value=Dept_Cd) order by Descr", cmbDept)
            BuildCombo("select Section_Cd,Descr from hr_section_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='section' and Property_Value=Section_Cd) order by Descr", cmbSection)
            BuildCombo("select Unit_Cd,Descr from hr_unit_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='unit' and Property_Value=Unit_Cd) order by Descr", cmbUnit)
            BuildCombo("select EmploymentType,Descr from hr_employment_type where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='employmenttype' and Property_Value=EmploymentType) order by Descr", cmbSecurity)

            cmbRC.Items.Add("All")
            cmbRC.SelectedValue = "All"
            cmbOfc.Items.Add("All")
            cmbOfc.SelectedValue = "All"
            cmbDiv.Items.Add("All")
            cmbDiv.SelectedValue = "All"
            cmbDept.Items.Add("All")
            cmbDept.SelectedValue = "All"
            cmbSection.Items.Add("All")
            cmbSection.SelectedValue = "All"
            cmbUnit.Items.Add("All")
            cmbUnit.SelectedValue = "All"
            cmbSecurity.Items.Add("All")
            cmbSecurity.SelectedValue = "All"
            Session("letter") = ""
            'DataRefresh(txtSearch.Text)
        End If
    End Sub
    Private Sub BuildDays()
        Dim i As Integer

        cmbDayFr.Items.Clear()
        cmbDayTo.Items.Clear()
        For i = 1 To MonthEND(CDate(cmbMonthFr.SelectedValue & "/1/" & cmbYearFr.SelectedValue)).Day
            cmbDayFr.Items.Add(i)
        Next
        For i = 1 To MonthEND(CDate(cmbMonthTo.SelectedValue & "/1/" & cmbYearTo.SelectedValue)).Day
            cmbDayTo.Items.Add(i)
        Next
        cmbDayFr.SelectedValue = 1
        cmbDayTo.SelectedValue = 1
    End Sub
    Protected Sub DataRefresh(ByVal pLetter As String)
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        '        Dim dr As sqlclient.sqlDataReader
        Dim da As SqlClient.SqlDataAdapter
        Dim ds As New DataSet
        Dim vFrom As Date = CDate(cmbMonthFr.SelectedValue & "/" & cmbDayFr.SelectedValue & "/" & cmbYearFr.SelectedValue)
        Dim vTo As Date = CDate(cmbMonthTo.SelectedValue & "/" & cmbDayTo.SelectedValue & "/" & cmbYearTo.SelectedValue)
        Dim vQryIncent As String = " and Incentive_Cd='" & cmbIncent.SelectedValue & "' "
        Dim vFilter As String = " where " & cmbType.SelectedValue & " like '" & pLetter & "%' "
        Dim vQuery As String = ""
        Dim vSql As String = ""
        Dim vSql_Print As String = ""

        Select Case rdoStatus.SelectedValue
            Case 1  'active
                vFilter += " and Date_Resign is null and Date_Retired is null and DateHold is Null and DateDismissed is null "
                vQuery = " where Date_Resign is null and Date_Retired is null and DateHold is Null and DateDismissed is null "
            Case 0  'inactive
                vFilter += " and (Date_Resign is not null or Date_Retired is not null or DateHold is not Null or DateDismissed is not null) "
                vQuery = " where (Date_Resign is not null or Date_Retired is not null or DateHold is not Null or DateDismissed is not null) "
            Case Else   'both
                vQuery = " where (Date_Resign is not null or Date_Resign is null) "
        End Select

        If cmbRC.SelectedValue <> "All" Then   'filter by cost center
            vFilter += " and Rc_Cd='" & cmbRC.SelectedValue & "' "
            vQuery += " and Rc_Cd='" & cmbRC.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                 "' and Property='rc' and Property_Value=Rc_Cd) "
            vQuery += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='rc' and Property_Value=Rc_Cd) "
        End If
        If cmbOfc.SelectedValue <> "All" Then        'filter by office/agency
            vFilter += " and Agency_Cd='" & cmbOfc.SelectedValue & "' "
            vQuery += " and Agency_Cd='" & cmbOfc.SelectedValue & "' "
        Else
            vFilter += "  and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                   "' and Property='agency' and Property_Value=Agency_Cd) "
            vQuery += "  and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                   "' and Property='agency' and Property_Value=Agency_Cd) "
        End If
        If cmbDiv.SelectedValue <> "All" Then      'filter by division
            vFilter += " and Divcd='" & cmbDiv.SelectedValue & "' "
            vQuery += " and Divcd='" & cmbDiv.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='division' and Property_Value=DivCd) "
            vQuery += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='division' and Property_Value=DivCd) "
        End If
        If cmbDept.SelectedValue <> "All" Then  'filter by departments
            vFilter += " and DeptCd='" & cmbDept.SelectedValue & "' "
            vQuery += " and DeptCd='" & cmbDept.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='department' and Property_Value=DeptCd) "
            vQuery += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='department' and Property_Value=DeptCd) "
        End If
        If cmbSection.SelectedValue <> "All" Then 'filter by section
            vFilter += " and SectionCd='" & cmbSection.SelectedValue & "' "
            vQuery += " and SectionCd='" & cmbSection.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='section' and Property_Value=SectionCd) "
            vQuery += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='section' and Property_Value=SectionCd) "
        End If
        If cmbUnit.SelectedValue <> "All" Then  'filter by units
            vFilter += " and UnitCd='" & cmbUnit.SelectedValue & "' "
            vQuery += " and UnitCd='" & cmbUnit.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='unit' and Property_Value=UnitCd) "
            vQuery += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='unit' and Property_Value=UnitCd) "
        End If
        If cmbSecurity.SelectedValue <> "All" Then      'filter by security
            vFilter += " and EmploymentType='" & cmbSecurity.SelectedValue & "' "
            vQuery += " and EmploymentType='" & cmbSecurity.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='employmenttype' and Property_Value=EmploymentType) "
            vQuery += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='employmenttype' and Property_Value=EmploymentType) "
        End If

        vSql = "select Id,py_incentives_dtl.Emp_Cd,(select (Emp_Lname+', '+Emp_Fname) as Name from py_emp_master where " & _
            "py_emp_master.Emp_Cd=py_incentives_dtl.Emp_Cd) as EmpName,Incentive_Amt as IncentiveAmt," & _
            "FromDate as From_Date,SrcCurrCd,TargetCurrCd," & _
            "ToDate as To_Date," & _
            "Recurring,FreqCd from py_incentives_dtl where exists (select py_emp_master.Emp_Cd from py_emp_master " & vFilter & _
            " and py_emp_master.Emp_Cd=py_incentives_dtl.Emp_Cd) and ((FromDate >='" & Format(vFrom, "yyyy/MM/dd 00:00:00") & _
            "' and ToDate <='" & Format(vTo, "yyyy/MM/dd 23:59:59") & "') or FromDate is null) " & vQryIncent
        Session("sql") = vSql
        'For Printing
        vSql_Print = "select Incentive_Cd,py_emp_master.Emp_Cd,(Emp_Lname+', '+Emp_Fname) as EmpName,Incentive_Amt as IncentiveAmt," & _
           "FromDate as From_Date,ToDate as To_Date,SrcCurrCd,TargetCurrCd," & _
           "Recurring,FreqCd from py_incentives_dtl,py_emp_master where py_incentives_dtl.Emp_Cd=py_emp_master.Emp_Cd " & _
           vQryIncent & " and exists (select py_emp_master.Emp_Cd from py_emp_master " & vQuery & _
           " and py_emp_master.Emp_Cd=py_incentives_dtl.Emp_Cd)  and " & _
           "((FromDate >='" & Format(vFrom, "yyyy/MM/dd 00:00:00") & _
           "' and ToDate <='" & Format(vTo, "yyyy/MM/dd 23:59:59") & _
           "') or FromDate is null) order by Emp_Lname,Emp_Fname,Emp_Mname"

        Session("sql_print") = vSql_Print
        Session("selectedrc") = cmbRC.SelectedValue
        Session("selectedagency") = cmbOfc.SelectedValue
        Session("selecteddiv") = cmbDiv.SelectedValue
        Session("selecteddept") = cmbDept.SelectedValue
        Session("selectedsection") = cmbSection.SelectedValue
        Session("selectedunit") = cmbUnit.SelectedValue
        Session("selectedrank") = cmbSecurity.SelectedValue
        Try
            da = New sqlclient.sqlDataAdapter(vSql, c)
            da.Fill(ds, "Incentives")
            tblEmp.DataSource = ds.Tables("Incentives")
            tblEmp.DataBind()
            tblEmp.SelectedIndex = -1
            ds.Dispose()
            da.Dispose()
        Catch ex As sqlclient.sqlException
            vScript = "alert('Error occurred while trying to retrieve Incentives Ledger. Error is: " & _
                ex.Message.Replace(vbCrLf, "\n").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            ds.Dispose()
            Exit Sub
        End Try

        'Try
        '    c.Open()
        'Catch ex As sqlclient.sqlexception
        '    vScript = "alert('Error occurred while trying to connect to SQL Server. Error is: " & _
        '        ex.Message.Replace(vbCrLf, "\n") & "');"
        '    cm.Dispose()
        '    Exit Sub
        'End Try

        'cm.Connection = c
        'cm.CommandText = "select distinct substring(Emp_Lname,1,1) as Letters from py_emp_master A where " & _
        '    "Emp_Cd in (select Emp_Cd from py_incentives_dtl where Emp_Cd in (select py_emp_master.Emp_Cd " & _
        '    "from py_emp_master " & vQuery & ") " & vQryIncent & ")"
        'Try
        '    dr = cm.ExecuteReader
        '    EnableAll(False)
        '    Do While dr.Read
        '        SetLetters(dr("Letters"))
        '    Loop
        '    dr.Close()
        'Catch ex As sqlclient.sqlexception
        '    vScript = "alert('Error occurred in Line 160: " & ex.Message.Replace(vbCrLf, "\n") & "');"
        '    c.Close()
        '    cm.Dispose()
        '    c.Dispose()
        '    Exit Sub
        'End Try

        'cm.CommandText = "select * from py_other_incentvs where Incentive_Cd= '" & cmbIncent.SelectedValue & "'"
        'Try
        '    dr = cm.ExecuteReader
        '    If dr.Read Then
        '        Session("inc_name") = dr("Descr")
        '    End If
        '    dr.Close()
        'Catch ex As sqlclient.sqlexception
        '    vScript = "alert('Error occurred while retrieving Incentives Reference. Error is: " & ex.Message.Replace(vbCrLf, "\n") & "');"
        'Finally
        cm.Dispose()
        c.Close()
        c.Dispose()
        'End Try

    End Sub
    Private Sub SetLetters(ByVal pLetter As String)
        Select Case LCase(pLetter)
            Case "a"
                cmdA.Visible = True
            Case "b"
                cmdB.Visible = True
            Case "c"
                cmdC.Visible = True
            Case "d"
                cmdD.Visible = True
            Case "e"
                cmdE.Visible = True
            Case "f"
                cmdF.Visible = True
            Case "g"
                cmdG.Visible = True
            Case "h"
                cmdH.Visible = True
            Case "i"
                cmdI.Visible = True
            Case "j"
                cmdJ.Visible = True
            Case "k"
                cmdK.Visible = True
            Case "l"
                cmdL.Visible = True
            Case "m"
                cmdM.VISIBLE = True
            Case "n"
                cmdN.Visible = True
            Case "o"
                cmdO.Visible = True
            Case "p"
                cmdP.Visible = True
            Case "q"
                cmdQ.Visible = True
            Case "r"
                cmdR.Visible = True
            Case "s"
                cmdS.Visible = True
            Case "t"
                cmdT.Visible = True
            Case "u"
                cmdU.Visible = True
            Case "v"
                cmdV.Visible = True
            Case "w"
                cmdW.Visible = True
            Case "x"
                cmdX.Visible = True
            Case "y"
                cmdY.Visible = True
            Case "z"
                cmdZ.Visible = True
        End Select
    End Sub
    Protected Sub cmdReturn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.Click
        Session.Remove("incentcd")
        Session.Remove("empname")
        Session.Remove("tdate")
        Session.Remove("mode")
        Session.Remove("selectedrc")
        Session.Remove("selectedagency")
        Session.Remove("selecteddiv")
        Session.Remove("selecteddept")
        Session.Remove("selectedsection")
        Session.Remove("selectedunit")
        Session.Remove("selectedrank")
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub tblEmp_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles tblEmp.PageIndexChanging
        tblEmp.PageIndex = e.NewPageIndex
        DataRefresh(txtSearch.Text)
    End Sub

    Protected Sub cmdA_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdA.Click, _
       cmdB.Click, cmdC.Click, cmdD.Click, cmdE.Click, cmdF.Click, cmdG.Click, cmdH.Click, cmdI.Click, _
       cmdJ.Click, cmdK.Click, cmdL.Click, cmdM.Click, cmdN.Click, cmdO.Click, cmdP.Click, cmdQ.Click, _
       cmdR.Click, cmdS.Click, cmdT.Click, cmdU.Click, cmdV.Click, cmdW.Click, cmdX.Click, cmdY.Click, cmdZ.Click
        Session("letter") = CType(sender, LinkButton).Text
        txtSearch.Text = CType(sender, LinkButton).Text
        DataRefresh(txtSearch.Text)
    End Sub
    Private Sub EnableAll(Optional ByVal pState As Boolean = False)
        cmdA.Visible = pState : cmdB.Visible = pState : cmdC.Visible = pState : cmdD.Visible = pState
        cmdE.Visible = pState : cmdF.Visible = pState : cmdG.Visible = pState : cmdH.Visible = pState
        cmdI.Visible = pState : cmdJ.Visible = pState : cmdK.Visible = pState : cmdL.Visible = pState
        cmdM.Visible = pState : cmdN.Visible = pState : cmdO.Visible = pState : cmdP.Visible = pState
        cmdQ.Visible = pState : cmdR.Visible = pState : cmdS.Visible = pState : cmdT.Visible = pState
        cmdU.Visible = pState : cmdV.Visible = pState : cmdW.Visible = pState : cmdX.Visible = pState
        cmdY.Visible = pState : cmdZ.Visible = pState
    End Sub


    Protected Sub cmdAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdAdd.Click
        Session("tid") = ""
        Session("mode") = "a"
        Session("incentcd") = cmbIncent.SelectedValue
        vScript = "incentwin=window.open('modifyincent.aspx','incentwin','location=no,toolbar=no,width=492,height=300,top=100,left=100');"
    End Sub

    Protected Sub cmdSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSearch.Click
        DataRefresh(txtSearch.Text)
    End Sub

    Protected Sub cmdEdit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdEdit.Click
        If tblEmp.SelectedIndex >= 0 Then
            Session("incentcd") = cmbIncent.SelectedValue
            Session("tid") = tblEmp.SelectedRow.Cells(0).Text
            'Session("empname") = tblEmp.SelectedRow.Cells(0).Text
            'Session("selrc") = cmbRC.SelectedValue
            'Session("selofc") = cmbOfc.SelectedValue
            'Session("seldiv") = cmbDiv.SelectedValue
            'Session("seldept") = cmbDept.SelectedValue
            'Session("selsection") = cmbSection.SelectedValue
            'Session("selunit") = cmbUnit.SelectedValue
            'Session("seltype") = cmbSecurity.SelectedValue

            'If IsDate(tblEmp.SelectedRow.Cells(3).Text) Then
            '    Session("tdate") = Format(CDate(tblEmp.SelectedRow.Cells(3).Text), "yyyy/MM/dd")
            'Else
            '    Session("tdate") = ""
            'End If

            'Session("amount") = Val(CType(tblEmp.SelectedRow.FindControl("lblAmount"), Label).Text.Replace(",", ""))

            Session("mode") = "e"
            vScript = "incentwin=window.open('modifyincent.aspx','incentwin','location=no,toolber=no,width=492,height=300,top=100,left=100');"
        Else
            vScript = "alert('Please select employee first.');"
        End If
    End Sub

    Protected Sub cmdDelete_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDelete.Click
        Dim cm As New sqlclient.sqlcommand
        Dim c As New sqlclient.sqlconnection(connStr)
        Dim vSQL_Del As String = ""
        Dim vDate As Date = Nothing

        Try
            c.Open()
        Catch ex As sqlclient.sqlexception
            vScript = "alert('Error occurred while trying to connect to SQL Server. Error is: " & _
                ex.Message.Replace(vbCrLf, "\n").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        cm.Connection = c

        If tblEmp.SelectedIndex >= 0 Then

            cm.CommandText = "delete from py_incentives_dtl where Id=" & _
                tblEmp.SelectedRow.Cells(0).Text & " and Incentive_Cd='" & cmbIncent.SelectedValue & "'"
            Try
                cm.ExecuteNonQuery()
            Catch ex As sqlclient.sqlException
                vScript = "alert('Error while trying to delete the record. Error is: " & _
                    ex.Message.Replace(vbCrLf, "\n").Replace("'", "") & "');"
            Finally
                cm.Dispose()
                c.Close()
                c.Dispose()
                DataRefresh(txtSearch.Text)
            End Try
        Else
            vScript = "alert('Please select employee first.');"
        End If
    End Sub

    Protected Sub cmbMonthFr_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles _
        cmbMonthFr.SelectedIndexChanged, cmbYearFr.SelectedIndexChanged, _
        cmbMonthTo.SelectedIndexChanged, cmbYearTo.SelectedIndexChanged
        BuildDays()
    End Sub
End Class
