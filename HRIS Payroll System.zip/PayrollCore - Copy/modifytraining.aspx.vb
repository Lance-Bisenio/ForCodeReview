Imports denaro
Partial Class modifytraining
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Dim c As New sqlclient.sqlconnection
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If
        If Not IsPostBack Then
            Dim cm As New sqlclient.sqlcommand
            Dim dr As sqlclient.sqldatareader
            txtEmpCd.Text = Session("empid")
            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c
            cm.CommandText = "select Emp_Lname,Emp_Fname from py_emp_master where Emp_Cd='" & txtEmpCd.Text & "'"
            dr = cm.ExecuteReader
            lblcaption.text = "Add/Modify Self-Training for "
            If dr.Read Then
                lblcaption.Text += dr("Emp_Lname") & ", " & dr("Emp_Fname")
            End If
            dr.Close()

            If Session("mode") = "e" Or Session("mode") = "v" Then
                cm.CommandText = "select * from hr_emp_training where Seqid='" & Session("seqid") & "'"
                dr = cm.ExecuteReader
                If dr.Read Then
                    txtFrom.Text = IIf(IsDBNull(dr("From_Date")), "", dr("From_Date"))
                    txtTo.Text = IIf(IsDBNull(dr("To_Date")), "", dr("To_Date"))
                    txtTrainingName.Text = IIf(IsDBNull(dr("Training_Name")), "", dr("Training_Name"))
                    txtSpeaker.Text = IIf(IsDBNull(dr("Speaker")), "", dr("Speaker"))
                    txtPlace.Text = IIf(IsDBNull(dr("Held")), "", dr("Held"))
                    txtHours.Text = IIf(IsDBNull(dr("No_Of_Hours")), 0, dr("No_Of_Hours"))
                    txtFee.Text = IIf(IsDBNull(dr("Fee")), 0, dr("Fee"))
                    txtRemarks.Text = IIf(IsDBNull(dr("Remarks")), "", dr("Remarks"))
                End If
                dr.Close()
                If Session("mode") = "v" Then 'freeze fields
                    txtFrom.ReadOnly = True
                    txtTo.ReadOnly = True
                    txtTrainingName.ReadOnly = True
                    txtSpeaker.ReadOnly = True
                    txtPlace.ReadOnly = True
                    txtHours.ReadOnly = True
                    txtFee.ReadOnly = True
                    txtRemarks.ReadOnly = True
                End If
            End If
            cm.Dispose()
            c.Close()
        End If
    End Sub

    Protected Sub cmdCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        Session.Remove("empid")
        Session.Remove("seqid")
        'If Session("mode") = "v" Then
        Session.Remove("mode")
        vScript = "window.close();"
        'Else
        'Session.Remove("mode")
        'Server.Transfer("emp.aspx")
        'End If
    End Sub
    Private Function CleanVar(ByVal pStr As String) As String
        Return pStr.Replace("'", "''")
    End Function
    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        If Page.IsValid Then
            Dim cm As New sqlclient.sqlcommand
            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c
            If Session("mode") = "e" Then 'edit mode
                cm.CommandText = "update hr_emp_training set From_Date='" & _
                    Format(CDate(txtFrom.Text), "yyyy/MM/dd") & _
                    "',To_Date='" & Format(CDate(txtTo.Text), "yyyy/MM/dd") & _
                    "',Training_Name='" & CleanVar(txtTrainingName.Text) & _
                    "',Fee=" & CleanVar(txtFee.Text) & _
                    ",Held='" & CleanVar(txtPlace.Text) & _
                    "',Remarks='" & CleanVar(txtRemarks.Text) & _
                    "',Speaker='" & CleanVar(txtSpeaker.Text) & _
                    "',No_Of_Hours=" & CleanVar(txtHours.Text) & _
                    " where seqid='" & Session("seqid") & "'"
            Else                          'add mode
                cm.CommandText = "insert into hr_emp_training (Emp_Id,From_Date,To_Date," & _
                    "Training_Name,Fee,Held,Remarks,Speaker,No_Of_Hours) values ('" & _
                    Session("empid") & "','" & Format(CDate(txtFrom.Text), "yyyy/MM/dd") & _
                    "','" & Format(CDate(txtTo.Text), "yyyy/MM/dd") & "','" & _
                    CleanVar(txtTrainingName.Text) & "'," & CleanVar(txtFee.Text) & ",'" & CleanVar(txtPlace.Text) & _
                    "','" & CleanVar(txtRemarks.Text) & "','" & CleanVar(txtSpeaker.Text) & "'," & _
                    txtHours.Text & ")"
            End If
            cm.ExecuteNonQuery()
            vScript = "alert('Changes where successfully saved.');self.close();"
        End If
    End Sub

    Protected Sub vldDate_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles vldDate.ServerValidate
        vldDate.ErrorMessage = "Invalid date format."
        If txtFrom.Text = "" Then
            vScript = "alert('From date field should not be empty.');"
            args.IsValid = False
            Exit Sub
        End If
        If txtTo.Text = "" Then
            vScript = "alert('To date field should not be empty.');"
            args.IsValid = False
            Exit Sub
        End If
        If Not IsDate(txtFrom.Text) Then
            vScript = "alert('The From date field has an invalid date format.');"
            args.IsValid = False
            Exit Sub
        End If
        If Not IsDate(txtTo.Text) Then
            vScript = "alert('The To date field has an invalid date format.');"
            args.IsValid = False
            Exit Sub
        End If
        If txtTrainingName.Text = "" Then
            vScript = "alert('Training name field should not be empty.');"
            vldDate.ErrorMessage = "Training name field should not be empty."
            args.IsValid = False
            Exit Sub
        End If
        If Not IsNumeric(txtFee.Text) Then
            vScript = "alert('Fee field has an invalid numeric format.');"
            vldDate.ErrorMessage = "Fee field has an invalid numeric format."
            args.IsValid = False
            Exit Sub
        End If
        args.IsValid = True
    End Sub
End Class
