﻿Imports denaro
Partial Class addleaveref
    Inherits System.Web.UI.Page
    
    Public vscript As String = ""
    Dim vValue As String = ""
    Dim vMode As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim vranks As String = ""
        Dim vstatus As String = ""

        vValue = Request.Item("value")
        vMode = Request.Item("mode")

        If Not IsPostBack Then
            c.Open()
            cm.Connection = c

            'Response.Write(Request.Item("mode") & " " & Request.Item("value"))
            If Request.Item("mode") = "e" Then
                cm.CommandText = "select * from py_leave_ref where Leave_Cd='" & Request.Item("value") & "'"
                rs = cm.ExecuteReader
                If rs.Read Then
                    txtLeaveCode.Enabled = False
                    txtLeaveCode.Text = rs("Leave_Cd")
                    txtLeaveDescr.Text = rs("Descr")
                    txtMaxCredit.Text = rs("MaxCredit")
                    txtEffectivity.Text = rs("EffectivityMonths")
                    txtCashLeaveCredit.Text = rs("CashLeaveCredit")
                    txtLeaveMultiple.Text = rs("FilingMultipleMins")
                    rdoAlwaysPaid.SelectedValue = rs("AlwaysPaid")
                    rdoConversionBasis.SelectedValue = IIf(IsDBNull(rs("ConversionBasis")), 1, rs("ConversionBasis"))
                    rdoNeedsRequest.SelectedValue = IIf(IsDBNull(rs("NeedsRequest")), 0, rs("NeedsRequest"))
                    rdoCreditFreq.SelectedValue = IIf(IsDBNull(rs("CreditFreq")), 12, rs("CreditFreq"))
                    rdoResetBasis.SelectedValue = IIf(IsDBNull(rs("ResetBasis")), 1, rs("ResetBasis"))
                    rdoAvailmentType.SelectedValue = IIf(IsDBNull(rs("Availtype")), 1, rs("Availtype"))
                    rdoEarnedType.SelectedValue = IIf(IsDBNull(rs("EarnedType")), 0, rs("EarnedType"))
                    vranks = IIf(IsDBNull(rs("Rank")), "", rs("Rank"))
                    vstatus = IIf(IsDBNull(rs("Status")), "", rs("Status"))
                End If
                rs.Close()
            End If
            cm.CommandText = "select * from hr_employment_type"
            rs = cm.ExecuteReader
            Dim vEmploymentType() As String
            Dim iLoop As Integer = 0
            Dim iCtr As Integer = 0

            vEmploymentType = vranks.Split(",")
            iCtr = 0
            chkEmpRanks.Items.Clear()
            Do While rs.Read
                chkEmpRanks.Items.Add(rs("EmploymentType") & "=>" & rs("Descr"))
                If vranks <> "" Then
                    For iLoop = 0 To UBound(vEmploymentType)
                        If vEmploymentType(iLoop) = rs("EmploymentType") Then
                            chkEmpRanks.Items(iCtr).Selected = True
                            Exit For
                        End If
                    Next
                    iCtr += 1
                End If
            Loop
            rs.Close()

            cm.CommandText = "select * from py_employee_stat"
            rs = cm.ExecuteReader
            Dim vEmpStatus() As String

            vEmpStatus = vstatus.Split(",")
            iCtr = 0
            chkEmpStatus.Items.Clear()
            Do While rs.Read
                chkEmpStatus.Items.Add(rs("Status_Code") & "=>" & rs("Descr"))
                If vstatus <> "" Then
                    For iLoop = 0 To UBound(vEmpStatus)
                        If vEmpStatus(iLoop) = rs("Status_Code") Then
                            chkEmpStatus.Items(iCtr).Selected = True
                        End If
                    Next
                    iCtr += 1
                End If
            Loop
            rs.Close()
            cm.Dispose()
            c.Close()
            c.Dispose()
        End If
    End Sub

    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand


        Dim vranks As String = ""
        Dim vstatus As String = ""
        Dim iCtr As Integer = 0


        If txtLeaveCode.Text = "" Then
            vscript = "alert('Please enter a leave code.');"
            Exit Sub
        End If

        If txtLeaveDescr.Text = "" Then
            vscript = "alert('Please enter a leave description.');"
            Exit Sub
        End If

        If txtMaxCredit.Text <> "" Then
            If Not IsNumeric(txtMaxCredit.Text) Then
                vscript = "alert('Please enter a maximum credit in a number format');"
                Exit Sub
            End If
        End If

        If txtCashLeaveCredit.Text <> "" Then
            If Not IsNumeric(txtCashLeaveCredit.Text) Then
                vscript = "alert('Please enter a cash leave credit in a number format');"
                Exit Sub
            End If
        End If

        If txtEffectivity.Text <> "" Then
            If Not IsNumeric(txtEffectivity.Text) Then
                vscript = "alert('Please enter a effectivity in a number format');"
                Exit Sub
            End If
        End If

        If txtExpDate.Text <> "" Then
            If Not IsDate(txtExpDate.Text) Then
                vscript = "alert('Please enter in a Expiry date format.');"
                Exit Sub
            End If
        End If

        If Not IsNumeric(txtLeaveMultiple.Text) Then
            vscript = "alert('Please enter a valid numeric value in Multiples of Leave Filing field.');"
            Exit Sub
        End If

        txtLeaveMultiple.Text = txtLeaveMultiple.Text.Replace(",", "")

        For iCtr = 0 To chkEmpRanks.Items.Count - 1
            If chkEmpRanks.Items(iCtr).Selected Then
                vranks += ExtractData(chkEmpRanks.Items(iCtr).Text) & ","
            End If
        Next
        If vranks <> "" Then
            vranks = vranks.Substring(0, vranks.Length - 1)
        End If

        For iCtr = 0 To chkEmpStatus.Items.Count - 1
            If chkEmpStatus.Items(iCtr).Selected Then
                vstatus += ExtractData(chkEmpStatus.Items(iCtr).Text) & ","
            End If
        Next
        If vstatus <> "" Then
            vstatus = vstatus.Substring(0, vstatus.Length - 1)
        End If

        Dim vExpdate As String = ""

        If txtExpDate.Text = "" Then
            vExpdate = "NULL"
        Else
            vExpdate = "'" & Format(CDate(txtExpDate.Text), "yyyy/MM/dd") & "'"
        End If

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vscript = "alert('Error occurred while trying to open the database.');"
        
        End Try

        Try
            cm.Connection = c
            If vmode = "a" Then
                cm.CommandText = "insert into py_leave_ref(Leave_Cd, Descr, MaxCredit, " & _
                    "EffectivityMonths,CashLeaveCredit,AlwaysPaid," & _
                    "ConversionBasis,NeedsRequest,CreditFreq,ResetBasis,Availtype," & _
                    "EarnedType,RANK,Status,ExpiryDate,FilingMultipleMins)values('" & _
                    txtLeaveCode.Text & "','" & txtLeaveDescr.Text & "'," & _
                    txtMaxCredit.Text & "," & _
                    txtEffectivity.Text & "," & txtCashLeaveCredit.Text & "," & _
                    rdoAlwaysPaid.SelectedValue & "," & rdoConversionBasis.SelectedValue & "," & _
                    rdoNeedsRequest.SelectedValue & "," & rdoCreditFreq.SelectedValue & "," & _
                    rdoResetBasis.SelectedValue & "," & rdoAvailmentType.SelectedValue & "," & _
                    rdoEarnedType.SelectedValue & ",'" & vranks & "','" & vstatus & "'," & _
                    vExpdate & "," & Val(txtLeaveMultiple.Text) & ")"
            Else
                cm.CommandText = "update py_leave_ref set Descr='" & txtLeaveDescr.Text & _
                    "',MaxCredit=" & txtMaxCredit.Text & ",EffectivityMonths=" & txtEffectivity.Text & _
                    ",CashLeaveCredit=" & txtCashLeaveCredit.Text & ",AlwaysPaid=" & rdoAlwaysPaid.SelectedValue & _
                    ",ConversionBasis=" & rdoConversionBasis.SelectedValue & _
                    ",NeedsRequest=" & rdoNeedsRequest.SelectedValue & ",CreditFreq=" & rdoCreditFreq.SelectedValue & _
                    ",ResetBasis=" & rdoResetBasis.SelectedValue & ",Availtype=" & rdoAvailmentType.SelectedValue & _
                    ",EarnedType=" & rdoEarnedType.SelectedValue & ",Rank='" & vranks & _
                    "',Status='" & vstatus & "',ExpiryDate=" & vExpdate & _
                    ",FilingMultipleMins=" & Val(txtLeaveMultiple.Text) & _
                    " where Leave_Cd='" & vValue & "'"
            End If

            cm.ExecuteNonQuery()
            vscript = "alert('Record saved.');window.opener.document.form1.submit();"
        Catch ex As SqlClient.SqlException
            'Response.Write(cm.CommandText)
            vscript = "alert('Error occurred while trying to retrieve record. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            cm.Dispose()
            c.Dispose()
        End Try

    End Sub

    Protected Sub txtExpDate_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtExpDate.Init
        txtExpDate.Attributes.Add("onfocus", "showCalendarControl(this)")
    End Sub
End Class
