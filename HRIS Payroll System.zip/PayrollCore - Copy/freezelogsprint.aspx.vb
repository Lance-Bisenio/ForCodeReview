﻿Imports denaro.fis
Partial Class freezelogsprint
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Public vList As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        GetDisApprovedApplication()
    End Sub

    Private Sub GetDisApprovedApplication()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim vStatus As String = ""
        Dim pFrom As Date = CDate(Request.Item("pFrom"))
        Dim pTo As Date = CDate(Request.Item("pTo"))
        Dim vCtr As Integer = 1

        Dim vMOList As String = ""
        Dim vSMList As String = ""
        Dim vMOTimelogList As String = ""
        Dim vSMTimelogList As String = ""
        Dim vMOCShiftList As String = ""
        Dim vSMCShiftList As String = ""

        c.Open()
        cm.Connection = c

        'GET ALL PENDING APPLICATION IN hr_leave_application*
        cm.CommandText = "select *, " & _
            "(select Emp_Lname+', '+Emp_Fname  from py_emp_master where py_emp_master.Emp_Cd=hr_leave_application.Emp_Cd) as FullName," & _
            "(select Emp_Lname+', '+Emp_Fname  from py_emp_master where py_emp_master.Emp_Cd=hr_leave_application.ApprovedBy) as vApprovedBy, " & _
            "(select Emp_Lname+', '+Emp_Fname  from py_emp_master where py_emp_master.Emp_Cd=hr_leave_application.RecommendedBy) as vRecommendedBy, " & _
            "(select Emp_Lname+', '+Emp_Fname  from py_emp_master where py_emp_master.Emp_Cd=hr_leave_application.NotedBy) as vNotedBy, " & _
            "(select Pay_Cd from py_emp_master where py_emp_master.Emp_Cd=hr_leave_application.Emp_Cd ) as vPaycode " & _
            "from hr_leave_application where void= 0 and " & _
            "StartDate Between '" & Format(pFrom, "yyyy/MM/dd") & "' and '" & Format(pTo, "yyyy/MM/dd") & "' and EffectivityDate is null and " & _
            "((ApprovedBy is Not null and DateApproved is null) or " & _
            "(ApprovedBy is Not null and DateApproved is not null and RecommendedBy is Not null and DateRecommended is null) or " & _
            "(ApprovedBy is Not null and DateApproved is not null and RecommendedBy is Not null and DateRecommended is not null and NotedBy is not null and DateNoted is null)) " & _
            "order by LeaveCd"

        rs = cm.ExecuteReader
        Do While rs.Read

            vList += "<tr class='linkstyle-row' ><td class='labelBC'>" & vCtr & "</td>" & _
                "<td class='labelBC' style='padding:5px; color: #000000;'>" & rs("TranDate") & "</td>" & _
                "<td class='labelBC' style='padding:5px; color: #000000;'>" & rs("Emp_Cd") & "</td>" & _
                "<td class='labelBL' style='padding:5px; color: #000000;'>" & rs("FullName") & "</td>" & _
                "<td class='labelBC' style='padding:5px; color: #000000;'>" & rs("LeaveCd") & "</td>" & _
                "<td class='labelBC' style='padding:5px; color: #000000;'>" & rs("DaysLeave") & "</td>" & _
                "<td class='labelBC' style='padding:5px; color: #000000;'>" & rs("StartDate") & "</td>" & _
                "<td class='labelBC' style='padding:5px; color: #000000;'>" & rs("EndDate") & "</td>" & _
                "<td class='labelBL' style='padding:5px; color: #000000;'>" & rs("vApprovedBy") & ""

            If Not IsDBNull(rs("DateApproved")) Then
                vList += "<br>" & Format(rs("DateApproved"), "MM/dd/yyyy")
            End If

            vList += "</td>" & _
                "<td class='labelBL' style='padding:5px; color: #000000;'>" & rs("vRecommendedBy") & ""

            If Not IsDBNull(rs("DateRecommended")) Then
                vList += "<br>" & Format(rs("DateRecommended"), "MM/dd/yyyy")
            End If


            vList += "</td>" & _
                "<td class='labelBL' style='padding:5px; color: #000000;'>" & rs("vNotedBy") & ""
            If Not IsDBNull(rs("DateNoted")) Then
                vList += "<br>" & Format(rs("DateNoted"), "MM/dd/yyyy")
            End If

            vList += "</td></tr>"

            vCtr += 1
        Loop

        rs.Close()

        'GET ALL PENDING APPLICATION IN py_time_log*
        cm.CommandText = "SELECT Emp_Cd,Tran_Date,Emp_Name,Id,Reason,CorrectionTimeIn,CorrectionTimeOutDate,EffectivityDate, " & _
            "CorrectionTimeOut, ApprovedBy, Date_Approved, Remarks, DateFiled, " & _
            "(select Emp_Lname+', '+Emp_Fname from py_emp_master where py_emp_master.Emp_Cd=py_time_log.Emp_Cd) as FullName, " & _
            "(select Emp_Lname+', '+Emp_Fname from py_emp_master where py_emp_master.Emp_Cd=py_time_log.ApprovedBy) as vApprovedBy, " & _
            "(select Pay_Cd from py_emp_master where py_emp_master.Emp_Cd=py_time_log.Emp_Cd ) as vPaycode " & _
            "FROM py_time_log WHERE CorrectionTimeIn IS NOT NULL AND Tran_Date Between '" & _
            Format(pFrom, "yyyy/MM/dd") & "' and '" & Format(pTo, "yyyy/MM/dd") & "' AND  " & _
            " ApprovedBy IS NOT null and EffectivityDate is null and  ((Date_Approved IS NOT NULL AND DateDisapproved IS NULL)  " & _
            "OR (Date_Approved IS NULL AND DateDisapproved IS NOT NULL)) ORDER BY Tran_Date desc"

        rs = cm.ExecuteReader

        Do While rs.Read
            
            vList += "<tr class='linkstyle-row' ><td class='labelBC'>" & vCtr & "</td>" & _
                "<td class='labelBC' style='padding:5px; color: #000000;'>" & rs("Tran_Date") & "</td>" & _
                "<td class='labelBC' style='padding:5px; color: #000000;'>" & rs("Emp_Cd") & "</td>" & _
                "<td class='labelBL' style='padding:5px; color: #000000;'>" & rs("FullName") & "</td>" & _
                "<td class='labelBC' style='padding:5px; color: #000000;'>DTR Correction</td>" & _
                "<td class='labelBC' style='padding:5px; color: #000000;'>0</td>" & _
                "<td class='labelBC' style='padding:5px; color: #000000;'>...</td>" & _
                "<td class='labelBC' style='padding:5px; color: #000000;'>...</td>" & _
                "<td class='labelBL' style='padding:5px; color: #000000;'>" & rs("vApprovedBy") & ""

            If Not IsDBNull(rs("Date_Approved")) Then
                vList += "<br>" & Format(rs("Date_Approved"), "MM/dd/yyyy")
            End If

            vList += "</td>" & _
                "<td class='labelBL' style='padding:5px; color: #000000;'></td>" & _
                "<td class='labelBL' style='padding:5px; color: #000000;'></td>" & _
                "</tr>"

            vCtr += 1
        Loop
        rs.Close()

        cm.CommandText = "select *, (select Emp_Lname+', '+Emp_Fname from py_emp_master where py_emp_master.Emp_Cd=py_emp_time_sched.Emp_Cd) as FullName, " & _
            "(select Emp_Lname+', '+Emp_Fname from py_emp_master where py_emp_master.Emp_Cd=py_emp_time_sched.ApprovedBy) as vApprovedBy, " & _
            "(select Emp_Lname+', '+Emp_Fname from py_emp_master where py_emp_master.Emp_Cd=py_emp_time_sched.RecommendedBy) as vRecommendedBy, " & _
            "(select Emp_Lname+', '+Emp_Fname from py_emp_master where py_emp_master.Emp_Cd=py_emp_time_sched.NotedBy) as vNotedBy, " & _
            "(select Pay_Cd from py_emp_master where py_emp_master.Emp_Cd=py_emp_time_sched.Emp_Cd ) as vPaycode " & _
            "from py_emp_time_sched where void= 0 and Date_Sched Between '" & _
            Format(pFrom, "yyyy/MM/dd") & "' and '" & Format(pTo, "yyyy/MM/dd") & "' and " & _
            "Transdate is not null and EffectivityDate is null and  " & _
            "((ApprovedBy is Not null and DateApproved is null) or " & _
            "(ApprovedBy is Not null and DateApproved is not null and RecommendedBy is Not null and DateRecommended is null) or " & _
            "(ApprovedBy is Not null and DateApproved is not null and RecommendedBy is Not null and DateRecommended is not null and NotedBy is not null and DateNoted is null)) "


        rs = cm.ExecuteReader
        Do While rs.Read

            vList += "<tr class='linkstyle-row' ><td class='labelBC'>" & vCtr & "</td>" & _
                "<td class='labelBC' style='padding:5px; color: #000000;'>" & rs("TransDate") & "</td>" & _
                "<td class='labelBC' style='padding:5px; color: #000000;'>" & rs("Emp_Cd") & "</td>" & _
                "<td class='labelBL' style='padding:5px; color: #000000;'>" & rs("FullName") & "</td>" & _
                "<td class='labelBC' style='padding:5px; color: #000000;'>Change Shift</td>" & _
                "<td class='labelBC' style='padding:5px; color: #000000;'>0</td>" & _
                "<td class='labelBC' style='padding:5px; color: #000000;'>...</td>" & _
                "<td class='labelBC' style='padding:5px; color: #000000;'>...</td>" & _
                "<td class='labelBL' style='padding:5px; color: #000000;'>" & rs("vApprovedBy") & ""

            If Not IsDBNull(rs("DateApproved")) Then
                vList += "<br>" & Format(rs("DateApproved"), "MM/dd/yyyy")
            End If

            vList += "</td>" & _
                "<td class='labelBL' style='padding:5px; color: #000000;'>" & rs("vRecommendedBy") & ""

            If Not IsDBNull(rs("DateRecommended")) Then
                vList += "<br>" & Format(rs("DateRecommended"), "MM/dd/yyyy") & ""
            End If

            vList += "</td>" & _
                "<td class='labelBL' style='padding:5px; color: #000000;'>" & rs("NotedBy") & ""

            If Not IsDBNull(rs("DateNoted")) Then
                vList += "<br>" & Format(rs("DateNoted"), "MM/dd/yyyy")
            End If

            vList += "</td></tr>"

            vCtr += 1
        Loop
        rs.Close()

        c.Close()
        c.Dispose()
        cm.Dispose()
    End Sub
End Class
