Imports denaro
Imports System.Data.SqlClient
Partial Class index2_exec
    Inherits System.Web.UI.Page
    Public msg As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Request.HttpMethod = "POST" Then
            Check4Updates()
            If Request.Form("usrname") <> "" Or Request.Form("passwd") <> "" Then
                Dim usrname As String = System.Security.SecurityElement.Escape(Request.Form("usrname").ToString.Trim)
                Dim passwd As String = System.Security.SecurityElement.Escape(Request.Form("passwd").ToString.Trim)

                Dim cn As New SqlClient.SqlConnection
                Dim cm As New SqlClient.SqlCommand
                Dim cmRef As New SqlClient.SqlCommand
                Dim rsRef As SqlClient.SqlDataReader
                Dim rs As SqlClient.SqlDataReader

                'default to not licensed
                Dim vLicensed As Boolean = False
                Dim vExpiryDate As Date = "2023-01-01"
                Dim vCtr As Integer = 99
                Dim vMaxCount As Integer = 0
                Dim vBLTag As Integer = 0
                Dim vBLCredit As Integer = 0
                cn.ConnectionString = connStr
                cn.Open()
                cm.Connection = cn
                cmRef.Connection = cn

                passwd = getEncryptedCode256(passwd)

                cm.CommandText = "select * from user_list where User_Id='" & usrname & "' and UserPassword='" & passwd & "'"
                rs = cm.ExecuteReader

                Try
                    If rs.Read Then

                        'check if licensed or not
                        '-----------------------------------------------------------------------------
                        cmRef.CommandText = "select Licensed,Actr,ExpiryDate,MaxCount from glsyscntrl"
                        rsRef = cmRef.ExecuteReader

                        If rsRef.Read Then
                            vLicensed = IIf(IsDBNull(rsRef("Licensed")), False, Math.Abs(Val(rsRef("Licensed"))) = 1 Or rsRef("Licensed"))
                            vCtr = IIf(IsDBNull(rsRef("Actr")), 99, rsRef("Actr"))
                            vExpiryDate = "2023-01-01" 'IIf(IsDBNull(rsRef("ExpiryDate")), Now, rsRef("ExpiryDate"))
                            vMaxCount = IIf(IsDBNull(rsRef("MaxCount")), 0, rsRef("MaxCount"))

                        End If
                        rsRef.Close()

                        If Now > CDate(vExpiryDate) Then
                            msg = "Trial version has elapsed. Please contact your system administrator to enable this application."
                            Exit Sub
                        End If


                        'If Not vLicensed Then   'check other parameter limits
                        '    If Now > vExpiryDate Then
                        '        msg = "Trial version had elapsed. Please purchase a licensed version from Evolve Integrated Software Solutions at www.evolvesoftwaresolutions.com"
                        '        Exit Sub
                        '    End If
                        '    If vCtr > vMaxCount Then
                        '        'GoTo expired
                        '    Else
                        '        cmRef.CommandText = "update glsyscntrl set Actr=Actr + 1"
                        '        cmRef.ExecuteNonQuery()
                        '    End If
                        'End If

                        msg = ""
                        UpdateSalaryHist(cn)

                        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                        If vBLTag = 1 Then
                            Check4BdayLeaveCrediting(cn, vBLCredit)
                        End If
                        ''''''''''END OF INCLUSION''''''''''''''''''''''''''''''''''''

                        Session("caption") = IIf(IsDBNull(rs("Caption")), "", rs("Caption"))
                        Session("userlevel") = IIf(IsDBNull(rs("UserLevel")), 0, rs("UserLevel"))
                        Session("agencylist") = IIf(IsDBNull(rs("AgencyCd")), "", rs("AgencyCd"))
                        Session("rclist") = IIf(IsDBNull(rs("Rc_Cd")), "", rs("Rc_Cd"))
                        Session("deptlist") = IIf(IsDBNull(rs("DeptCd")), "", rs("DeptCd"))
                        Session("sectionlist") = IIf(IsDBNull(rs("SectionCd")), "", rs("SectionCd"))
                        Session("divlist") = IIf(IsDBNull(rs("DivCd")), "", rs("DivCd"))
                        Session("unitlist") = IIf(IsDBNull(rs("UnitCd")), "", rs("UnitCd"))
                        Session("typelist") = IIf(IsDBNull(rs("EmploymentType")), "", rs("EmploymentType"))
                        Session("uid") = usrname
                        Session("sessionid") = Session.SessionID

                        'Session("sessionid") = Session("sessionid").ToString.Substring(Session("sessionid").ToString.IndexOf("=") + 1)

                        EventLog(Session("uid"), Request.ServerVariables("REMOTE_ADDR"), "LOGIN", "", "", "Successful LogIn on " _
                                     & Format(Now, "yyyy/MM/dd HH:mm:ss"), "LOGIN")

                        If msg = "" Then
                            msg = "ok"
                        End If

                    Else
                        EventLog(usrname, Request.ServerVariables("REMOTE_ADDR"), "LOGIN", "", "", "Invalid LogIn Userid Attempt on " _
                                 & Format(Now, "yyyy/MM/dd HH:mm:ss"), "LOGIN")
                        msg = "nok"
                    End If
                    rs.Close()
                Catch ex As SqlClient.SqlException
                    msg = ex.Message.ToString
                End Try
                cmRef.Dispose()
                cm.Dispose()

                cn.Close()
                cn.Dispose()
            End If
        Else
            Session.RemoveAll()
            Server.Transfer("index2.aspx")
        End If
    End Sub


    Private Sub UpdateSalaryHist(ByRef c As SqlClient.SqlConnection)
        Dim cm As New SqlClient.SqlCommand

        cm.Connection = c

        'clean up salary hist
        cm.CommandText = "delete from py_emp_salary_hist where YearCd=" & Now.Year & _
            " and [Month]=" & Now.Month
        cm.ExecuteNonQuery()

        'now insert updated salary for the month
        cm.CommandText = "insert into py_emp_salary_hist " & _
            "select Emp_Cd,employmenttype," & Now.Year & "," & Now.Month & _
            ",rate_year,rate_month,rate_day,rate_day/8 from py_emp_master"
        cm.ExecuteNonQuery()
        cm.Dispose()
    End Sub
    Private Sub Check4Updates()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim a As IO.FileInfo
        Dim sr As IO.StreamReader
        Dim vFilename As String = Server.MapPath(".") & "\updates.dat"

        Try
            cm.Connection = c
            c.Open()
            If IO.File.Exists(vFilename) Then
                a = New IO.FileInfo(vFilename)
                sr = IO.File.OpenText(vFilename)
                Do While Not sr.EndOfStream
                    cm.CommandText = sr.ReadLine
                    cm.ExecuteNonQuery()
                Loop
                sr.Close()
                sr.Dispose()
                a.Delete()
            End If
            c.Close()
            c.Dispose()
            cm.Dispose()
            a = Nothing
        Catch ex As SqlClient.SqlException
            'Exit Sub
        End Try
    End Sub
    Private Sub Check4LeaveCredits(ByRef c As SqlClient.SqlConnection)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader

        Dim query As New SqlClient.SqlCommand
        Dim result As SqlClient.SqlDataReader

        Dim cmRef As New SqlClient.SqlCommand

        Dim strsql As New SqlClient.SqlCommand
        Dim res As SqlClient.SqlDataReader

        Dim LeaveCode As String = ""
        Dim Interval As Integer = 0
        Dim CreditLeaves As Double = 0
        Dim vLastUpdate As Date
        Dim EmpMonth As Integer = 0
        Dim vBasis As String = ""
        Dim vFrequency As String = ""
        Dim MaxCredit As Decimal = 0

        strsql.Connection = c
        cm.Connection = c
        query.Connection = c
        cmRef.Connection = c

        cm.CommandText = "select Leave_LastUpdated from py_syscntrl"
        rs = cm.ExecuteReader

        If rs.Read Then
            vLastUpdate = CDate(IIf(IsDBNull(rs("Leave_LastUpdated")), "1/1/" & Year(Now), _
                rs("Leave_LastUpdated")))
        End If
        rs.Close()

        If Math.Abs(DateDiff(DateInterval.Month, vLastUpdate, Now)) > 0 Then    'time to increment the leaves
            'cm.CommandText = "SELECT * FROM py_leave_ref WHERE MonthlyCredit > 0"
            cm.CommandText = "SELECT * FROM py_leave_ref "
            rs = cm.ExecuteReader

            Do While rs.Read
                LeaveCode = rs("Leave_Cd")
                MaxCredit = IIf(IsDBNull(rs("MaxCredit")), 0, rs("MaxCredit"))

                'get the monthly difference of a leave

                query.CommandText = "SELECT Emp_Cd,Start_Date, " & _
                    "(select EffectivityMonths from py_emp_leave where py_emp_leave.Emp_Cd=py_emp_master.Emp_Cd and Leave_Cd='" & _
                    LeaveCode & "') as EffectivityMonths FROM py_emp_master WHERE Date_Resign is null AND Start_Date is not null"
                result = query.ExecuteReader

                Do While result.Read

                    Dim vSQL As String = ""
                    Dim UpdateLeaveLast As String = ""
                    Dim CreditNow As Decimal = 0
                    Dim vEffectivity As Decimal = 0
                    CreditLeaves = 0

                    If Not IsDBNull(rs("EffectivityMonths")) Then
                        vEffectivity = rs("EffectivityMonths")
                    End If
                    EmpMonth = DateDiff(DateInterval.Month, result("Start_Date"), Now.Date)

                    If EmpMonth >= vEffectivity Then
                        strsql.CommandText = "SELECT Credit,Basis,Frequency,CreditableDays,LastUpdate FROM py_emp_leave WHERE Emp_Cd='" & _
                                  result("Emp_Cd") & "' AND Leave_Cd='" & LeaveCode & "' "

                        res = strsql.ExecuteReader

                        If res.Read Then  'UPDATE THE ENTRY
                            vBasis = IIf(IsDBNull(res("Basis")), "", res("Basis"))
                            CreditLeaves = IIf(IsDBNull(res("CreditableDays")), 0, res("CreditableDays"))
                            vFrequency = IIf(IsDBNull(res("Frequency")), "", res("Frequency"))
                            UpdateLeaveLast = IIf(IsDBNull(res("LastUpdate")), "", res("LastUpdate"))

                            If vFrequency <> "" Then
                                CreditNow = IIf(IsDBNull(res("Credit")), "", res("Credit"))

                                If CreditNow + CreditLeaves > MaxCredit Then 'Limit the credits
                                    CreditLeaves = MaxCredit - CreditNow
                                End If

                                If Math.Abs(DateDiff(DateInterval.Month, CDate(UpdateLeaveLast), Now)) >= vFrequency Then
                                    cmRef.CommandText = "UPDATE py_emp_leave SET Credit=Credit + " & _
                                       CreditLeaves & ", Balance=(Credit + " & _
                                       CreditLeaves & ") - Used,LastUpdate='" & _
                                       Format(Now, "yyyy/MM/dd") & "' WHERE Emp_Cd='" & _
                                       result("Emp_Cd") & "' AND Leave_Cd='" & LeaveCode & "'"
                                    cmRef.ExecuteNonQuery()
                                End If
                            End If
                        End If
                        res.Close()
                    End If
                Loop    'next employee
                result.Close()
            Loop    'next leave reference
            rs.Close()

            cm.CommandText = "update py_syscntrl set Leave_LastUpdated='" & Format(Now, "yyyy/MM/dd") & " 00:00:00'"
            cm.ExecuteNonQuery()
            msg = "Leave Credit were successfully incremented. Click the Login button again to access the main menu..."
        End If

        cm.Dispose()
        query.Dispose()
        strsql.Dispose()
        cmRef.Dispose()
    End Sub
    Private Sub Check4LeaveCredits_bak(ByRef c As SqlClient.SqlConnection)
        Dim vLastUpdate As Date
        Dim vVacation As Boolean = False
        Dim vSick As Boolean = False
        Dim cn As New SqlClient.SqlConnection
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader

        cn.ConnectionString = connStr
        cn.Open()
        cm.Connection = cn
        cm.CommandText = "select Leave_LastUpdated from py_syscntrl"
        rs = cm.ExecuteReader

        If rs.Read Then
            vLastUpdate = CDate(IIf(IsDBNull(rs("Leave_LastUpdated")), "1/1/" & Year(Now), _
                rs("Leave_LastUpdated")))
        End If
        rs.Close()


        If Math.Abs(DateDiff(DateInterval.Month, vLastUpdate, Now)) > 0 Then    'time to increment the leaves
            Dim vDiff As Integer
            Dim vYears As Single = 0
            Dim vCredit As Single = 0
            Dim vMaxCredit As Single = 0
            Dim vStr As String
            Dim cnRef As New SqlClient.SqlConnection
            Dim cnLeave As New SqlClient.SqlConnection
            Dim cmRef As New SqlClient.SqlCommand
            Dim cmLeave As New SqlClient.SqlCommand
            Dim rsRef As SqlClient.SqlDataReader
            Dim rsleave As SqlClient.SqlDataReader
            cnRef.ConnectionString = connStr
            cnLeave.ConnectionString = connStr
            cnRef.Open()
            cnLeave.Open()

            cmRef.Connection = cnRef
            cmLeave.Connection = cnLeave
            vDiff = Math.Abs(DateDiff(DateInterval.Month, vLastUpdate, Now))
            vDiff = IIf(vDiff > 12, 12, vDiff)

            'get all leaves that supports monthly crediting where monthlycredit should be true
            'otherwise, leaves are credited on a yearly basis
            cmRef.CommandText = "select Leave_Cd, MonthlyCredit from py_leave_ref " & _
                "where MonthlyCredit <> 0 and MonthlyCredit is not null"

            rsRef = cmRef.ExecuteReader
            Do While rsRef.Read

                cm.CommandText = "select Emp_Cd,Start_Date from py_emp_master where Date_Resign is null and Start_Date is not null"
                rs = cm.ExecuteReader

                Do While rs.Read
                    vYears = Math.Abs(DateDiff(DateInterval.Year, rs("Start_Date"), Now))
                    vStr = ""

                    'get monthly credit based on years of service
                    cmLeave.CommandText = "select MonthlyCredit,CreditsEarned from py_leave_table where " & _
                        vYears & " between YearFrom and YearTo and Leave_Cd='" & rsRef("Leave_Cd") & "'"
                    rsleave = cmLeave.ExecuteReader
                    vCredit = 0
                    vMaxCredit = 0
                    If rsleave.Read Then
                        vCredit = IIf(IsDBNull(rsleave("MonthlyCredit")), 0, rsleave("MonthlyCredit"))
                        vMaxCredit = IIf(IsDBNull(rsleave("CreditsEarned")), 0, rsleave("CreditsEarned"))
                    End If
                    rsleave.Close()


                    vCredit = Math.Round(vMaxCredit / 12 * vDiff, 2) 'set at monthly credit multiplied by the # of months delayed/

                    'increment employee leave
                    cmLeave.CommandText = "select Credit from py_emp_leave where Emp_Cd='" & _
                       rs("Emp_Cd") & "' and Leave_Cd='" & rsRef("Leave_Cd") & "'"
                    rsleave = cmLeave.ExecuteReader

                    If rsleave.Read Then  'UPDATE
                        'If rsleave("Credit") + (vCredit * vDiff) < vMaxCredit Then
                        '    vCredit = 0
                        'Else 
                        'End If
                        vStr = "update py_emp_leave set Credit=Credit + " & _
                           vCredit & ", Balance=(Credit + " & _
                           vCredit & ") - Used,LastUpdate='" & _
                           Format(Now, "yyyy/MM/dd") & "' where Emp_Cd='" & _
                           rs("Emp_Cd") & "' and Leave_Cd='" & rsRef("Leave_Cd") & "'"
                    Else  'CREATE ENTRY
                        vStr = "insert into py_emp_leave (Emp_Cd,Leave_Cd,Credit,Balance," & _
                           "Used,LastUpdate) values ('" & rs("Emp_Cd") & "','" & rsRef("Leave_Cd") & _
                           "'," & vCredit & "," & vCredit & _
                           ",0,'" & Format(Now, "yyyy/MM/dd") & "')"
                    End If
                    rsleave.Close()

                    If vStr <> "" Then
                        cmLeave.CommandText = vStr
                        cmLeave.ExecuteNonQuery()
                    End If
                Loop
                rs.Close()
            Loop
            rsRef.Close()
            cmRef.Dispose()
            cmLeave.Dispose()
            cnLeave.Close()
            cnRef.Close()

            cm.Connection = cn
            cm.CommandText = "update py_syscntrl set Leave_LastUpdated='" & _
                Format(Now, "yyyy/MM/dd") & " 00:00:00'"

            cm.ExecuteNonQuery()

            msg = "Leave Credit were successfully incremented. Click the Login button again to access the main menu..."
            'Response.Write("<script type='text/javascript' language='javascript'>alert('Update of monthly credit leaves complete!'); </script>")
        End If
        cm.Dispose()
        cn.Close()
    End Sub
    Private Sub Check4BdayLeaveCrediting(ByRef c As SqlClient.SqlConnection, ByRef vBLCheckdays As Integer)
        'Dim vLastUpdate As Date
        Dim cm As New SqlClient.SqlCommand
        Dim rs1 As SqlClient.SqlDataReader
        Dim i As Integer = 0
        Dim vok As Boolean = False
        Dim vRank() As String
        Dim vStatus() As String
        Dim cmref As New SqlClient.SqlCommand
        Dim rsref As SqlClient.SqlDataReader
        Dim vHasrows As Boolean = False
        'Dim vBlCredit As Integer = 0

        cm.Connection = c
        cmref.Connection = c


        cm.CommandText = "select Rank,Status from py_leave_ref where Leave_Cd='BL'"
        rs1 = cm.ExecuteReader
        If rs1.Read Then
            vStatus = rs1("Status").ToString.Split(",")
            vRank = rs1("Rank").ToString.Split(",")
        End If
        rs1.Close()
        
        cm.CommandText = "select Emp_Status,EmploymentType,Emp_Cd,Emp_Lname, Emp_Fname, Emp_Mname, MONTH(Bday) as bMonth, DAY(Bday) as bDay from py_emp_master " & _
            "where Date_Resign is null and CONVERT(DATETIME,CONVERT(VARCHAR,MONTH(Bday))+'/'+CONVERT(VARCHAR,DAY(Bday))+'/" & _
            Now.Year & "') between '" & Format(Now.AddDays(vBLCheckdays - 7), "yyyy/MM/dd") & "' and '" & _
            Format(Now.AddDays(vBLCheckdays), "yyyy/MM/dd") & "'"

        rs1 = cm.ExecuteReader
        Do While rs1.Read
            For i = 0 To UBound(vStatus)
                If vStatus(i) = "*" Then
                    vok = True
                    Exit For
                End If
                If rs1("Emp_Status") = vStatus(i) Then
                    vok = True
                    Exit For
                End If
            Next

            If vok Then
                For i = 0 To UBound(vRank)
                    If vRank(i) = "*" Then
                        vok = True
                        Exit For
                    End If
                    If rs1("EmploymentType") = vRank(i) Then
                        vok = True
                        Exit For
                    End If
                Next
            End If

            If vok Then
                cmref.CommandText = "select Credit from py_emp_leave where Leave_Cd='BL' and Emp_Cd='" & rs1("Emp_Cd") & "'"
                rsref = cmref.ExecuteReader
                vHasrows = rsref.HasRows
                rsref.Close()

                If vHasrows Then
                    cmref.CommandText = "update py_emp_leave set Credit=1 where Leave_Cd='BL' and Emp_Cd='" & rs1("Emp_Cd") & "'"
                Else
                    cmref.CommandText = "insert into py_emp_leave(Emp_Cd,Leave_Cd,Credit,Used,Balance,LastUpdate)values('" & _
                                        rs1("Emp_Cd") & "','BL',1,0,0,'" & Format(Now, "yyyy/MM/dd HH:mm:ss") & "')"
                End If
                cmref.ExecuteNonQuery()
            End If
            vHasrows = False
            vok = False
        Loop
        rs1.Close()
        
        cm.Dispose()

    End Sub
End Class
