Imports denaro
Partial Class philhealth_er2_printt
    Inherits System.Web.UI.Page
    Public vData As String = ""
    Public vScript As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Session("returnaddr") = "philhealth_er2.aspx"
            Server.Transfer("index.aspx")
        End If
        If Not IsPostBack Then
            Dim c As New sqlclient.sqlconnection(connStr)
            Dim cm As New sqlclient.sqlcommand
            Dim dr As sqlclient.sqldatareader

            c.Open()
            cm.Connection = c
            cm.CommandText = "select * from glsyscntrl where AgencyCd='" & Session("ofc") & "'"
            dr = cm.ExecuteReader
            If dr.Read Then
                lblEmployer.Text = dr("Company_Name")
                lblAddr.Text = dr("Address") & "<br />" & dr("City") & " " & dr("Country") & " " & dr("Zip")
                lblPHIC.Text = IIf(IsDBNull(dr("PhicNo")), "Unknown", dr("PhicNo"))
                lblEmail.Text = IIf(IsDBNull(dr("Email")), "N/A", dr("Email"))

                GetEmployee()
                vScript = "alert('Request complete. To print the document, just click the File->Print menu on your browser');"
            Else
                vScript = "alert('Nothing to print.');"
            End If
            dr.Close()
            cm.Dispose()
            c.Close()
            c.Dispose()
        End If
    End Sub
    Private Sub GetEmployee()
        Dim c As New sqlclient.sqlconnection(connStr)
        c.Open()
        Dim cm As New sqlclient.sqlcommand(Session("sql"), c)
        Dim dr As sqlclient.sqldatareader
        Dim vId As String = ""
        Dim iCtr As Integer = 0

        vData = ""
        dr = cm.ExecuteReader
        Do While dr.Read
            iCtr += 1
            If Not IsDBNull(dr("PhicNo")) Then
                vId = dr("PhicNo")
            ElseIf Not IsDBNull(dr("Sss_No")) Then
                vId = dr("Sss_No")
            ElseIf Not IsDBNull(dr("Gsis_No")) Then
                vId = dr("Gsis_No")
            Else
                vId = "&nbsp;"
            End If
            vData += "<tr>" & _
                "<td style='width: 113px; height: 19px'><strong><span style='font-size: 8pt; font-family: Arial'>" & _
                vId & "</span></strong></td>" & _
                "<td style='width: 237px; height: 19px'><strong><span style='font-size: 8pt; font-family: Arial'>" & _
                dr("Emp_Lname") & ", " & dr("Emp_Fname") & " " & dr("Emp_Mname") & "</span></strong></td>" & _
                "<td style='width: 136px; height: 19px'><strong><span style='font-size: 8pt; font-family: Arial'>" & _
                dr("Position") & "</span></strong></td>" & _
                "<td style='width: 77px; height: 19px' align='right'><strong><span style='font-size: 8pt; font-family: Arial'>" & _
                Format(dr("Rate_Month"), "###,##0.00") & "</span></strong></td>" & _
                "<td style='width: 81px; height: 19px'><strong><span style='font-size: 8pt; font-family: Arial'>" & _
                Format(dr("Start_Date"), "MM/dd/yyyy") & "</span></strong></td>" & _
                "<td style='width: 81px; height: 19px'>&nbsp;</td>" & _
                "<td style='width: 12px; height: 19px'>&nbsp;</td>" & _
                "</tr>"
        Loop
        dr.Close()
        cm.Dispose()
        c.Close()
        c.Dispose()
        lblCount.Text = Format(iCtr, "#,##0")
    End Sub
End Class
