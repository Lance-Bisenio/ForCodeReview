﻿Imports denaro.fis
Partial Class modifysc
    Inherits System.Web.UI.Page

    Public vScript As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            vScript = "alert('Your login session has expired. Please login again.'); window.close();"
            Exit Sub
        End If

        If Not IsPostBack Then
            Dim vMode As String = Request.Item("m")
            If vMode <> "" Then 'edit mode
                Dim c As New SqlClient.SqlConnection(connStr)
                Dim cm As New SqlClient.SqlCommand("select * from scledger where TranDate='" & _
                    Format(CDate(vMode), "yyyy/MM/dd") & "'", c)
                Dim rs As SqlClient.SqlDataReader

                Try
                    c.Open()
                Catch ex As SqlClient.SqlException
                    vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                        ex.Message.Replace(vbCrLf, "").Replace("'", "") & "'); window.close();"
                    c.Dispose()
                    cm.Dispose()
                    Exit Sub
                End Try

                Try
                    rs = cm.ExecuteReader
                    If rs.Read Then
                        txtTranDate.Text = Format(rs("TranDate"), "MM/dd/yyyy")
                        txtFrom.Text = Format(rs("FromDate"), "MM/dd/yyyy")
                        txtTo.Text = Format(rs("ToDate"), "MM/dd/yyyy")
                        txtAmount.Text = rs("Amount")
                        txtBalance.Text = rs("Balance")
                        chkFrozen.Checked = rs("Frozen") = 1
                    End If
                    rs.Close()
                Catch ex As SqlClient.SqlException
                    vScript = "alert('Error occurred while trying to retrieve record. Error is: " & _
                        ex.Message.Replace(vbCrLf, "").Replace("'", "") & "'); window.close();"
                    c.Close()
                Finally
                    c.Dispose()
                    cm.Dispose()
                End Try
            End If
        End If
    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        If Page.IsValid Then
            If txtTranDate.Text.Trim = "" Then
                vScript = "alert('You must enter a valid date in Transaction date field. Please try again.');"
                Exit Sub
            End If
            If txtFrom.Text.Trim = "" Then
                vScript = "alert('You must enter a valid date in Starting cut off field.  Please try again.');"
                Exit Sub
            End If
            If txtTo.Text.Trim = "" Then
                vScript = "alert('You must enter a valid date in Ending cut off field.  Please try again.');"
                Exit Sub
            End If

            Dim vMode As String = Request.Item("m")
            Dim c As New SqlClient.SqlConnection(connStr)
            Dim cm As New SqlClient.SqlCommand("", c)

            Try
                c.Open()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                c.Dispose()
                cm.Dispose()
                Exit Sub
            End Try
            Try
                If vMode <> "" Then   'edit mode
                    cm.CommandText = "update scledger set FromDate='" & Format(CDate(txtFrom.Text), "yyyy/MM/dd") & _
                        "',ToDate='" & Format(CDate(txtTo.Text), "yyyy/MM/dd") & _
                        "',Amount=" & Val(txtAmount.Text) & _
                        ",Balance=" & Val(txtBalance.Text) & _
                        ",Frozen=" & IIf(chkFrozen.Checked, 1, 0) & _
                        " where TranDate='" & Format(CDate(vMode), "yyyy/MM/dd") & "'"
                Else                  'add mode
                    cm.CommandText = "insert into scledger (TranDate,FromDate,ToDate,Amount,Balance,Frozen) values ('" & _
                        Format(CDate(txtTranDate.Text), "yyyy/MM/dd") & "','" & _
                        Format(CDate(txtFrom.Text), "yyyy/MM/dd") & "','" & _
                        Format(CDate(txtTo.Text), "yyyy/MM/dd") & "'," & _
                        Val(txtAmount.Text) & "," & _
                        Val(txtBalance.Text) & "," & _
                        IIf(chkFrozen.Checked, 1, 0) & ")"
                End If
                cm.ExecuteNonQuery()

                vScript = "alert('Changes were successfully saved.'); window.opener.document.form1.submit(); window.close();"

            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to save your changes. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            Finally
                c.Close()
                c.Dispose()
                cm.Dispose()
            End Try

        End If
    End Sub

    Protected Sub vldTranDate_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) _
        Handles vldTranDate.ServerValidate

        If Not IsDate(txtTranDate.Text) Then
            vScript = "alert('Invalid date format in Transaction date field. Please try again.');"
            args.IsValid = False
        Else
            args.IsValid = True
        End If
    End Sub

    Protected Sub vldFrom_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles vldFrom.ServerValidate
        If Not IsDate(txtFrom.Text) Then
            vScript = "alert('Invalid date format in Starting cut off field. Please try again.');"
            args.IsValid = False
        Else
            args.IsValid = True
        End If
    End Sub

    Protected Sub vldTo_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles vldTo.ServerValidate
        If Not IsDate(txtTo.Text) Then
            vScript = "alert('Invalid date format in Ending cut off field.  Please try again.');"
            args.IsValid = False
        Else
            args.IsValid = True
        End If
    End Sub

    Protected Sub vldAmount_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles vldAmount.ServerValidate
        If Val(txtAmount.Text) = 0 Then
            vScript = "alert('You must enter a non-zero amount and a valid numeric date in Last Balance field.  Please try again');"
            args.IsValid = False
        Else
            args.IsValid = True
        End If
    End Sub

    Protected Sub vldBalance_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles vldBalance.ServerValidate
        If Val(txtBalance.Text) = 0 Then
            vScript = "alert('You must enter a non-zero amount and a valid numeric date in Last Balance field.  Please try again');"
            args.IsValid = False
        Else
            args.IsValid = True
        End If
    End Sub
End Class
