Imports denaro
Partial Class latefiled
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Public vData As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Session("returnaddr") = "philhealth_er2.aspx"
            Server.Transfer("index.aspx")
        End If
        If Not IsPostBack Then
            Session.Remove("vHeader")
            Session.Remove("vPeriod")
            Session.Remove("vFilter")
            Session.Remove("vList")

            lblCaption.Text = "Late Filed Query Report"

            If Not CanRun(Session("caption"), Request.Item("id")) Then
                Session("denied") = "1"
                Server.Transfer("main.aspx")
                Exit Sub
            End If

            BuildCombo("select Rc_Cd, Descr from rc where Rc_Cd in ('" & _
                Session("rclist").ToString.Replace(",", "','") & "') order by Descr ", cmbRC)
            BuildCombo("select AgencyCd,AgencyName from agency where Agencycd in ('" & _
                Session("agencylist").ToString.Replace(",", "','") & "') order by AgencyName", cmbOfc)
            BuildCombo("select Div_Cd,Descr from hr_div_ref where Div_Cd in ('" & _
                Session("divlist").ToString.Replace(",", "','") & "') order by Descr", cmbDiv)
            BuildCombo("select Dept_Cd,Descr from hr_dept_ref where Dept_Cd in ('" & _
                Session("deptlist").ToString.Replace(",", "','") & "') order by Descr", cmbDept)
            BuildCombo("select Section_Cd,Descr from hr_section_ref where Section_Cd in ('" & _
                Session("sectionlist").ToString.Replace(",", "','") & "') order by Descr", cmbSection)
            BuildCombo("select Unit_Cd,Descr from hr_unit_ref where Unit_Cd in ('" & _
                Session("unitlist").ToString.Replace(",", "','") & "') order by Descr", cmbUnit)
            cmbRC.Items.Add("All")
            cmbRC.SelectedValue = "All"
            cmbOfc.Items.Add("All")
            cmbOfc.SelectedValue = "All"
            cmbDiv.Items.Add("All")
            cmbDiv.SelectedValue = "All"
            cmbDept.Items.Add("All")
            cmbDept.SelectedValue = "All"
            cmbSection.Items.Add("All")
            cmbSection.SelectedValue = "All"
            cmbUnit.Items.Add("All")
            cmbUnit.SelectedValue = "All"
            BuildCombo("select Pay_Cd,Payment from py_pay_mode order by Payment", cmbPayMode)
            cmbMonth.SelectedValue = Now.Month
            SetStartCutOff()
        End If
    End Sub

    Protected Sub cmdReturn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.Click
        Server.Transfer("main.aspx")
        Session.Remove("vHeader")
        Session.Remove("vPeriod")
        Session.Remove("vFilter")
        Session.Remove("vList")
    End Sub

    Protected Sub cmbPayMode_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbPayMode.SelectedIndexChanged, _
        cmbMonth.SelectedIndexChanged
        SetStartCutOff()
    End Sub
    Private Sub SetStartCutOff()
        Dim c As New sqlclient.sqlconnection(connStr)
        Dim cm As New sqlclient.sqlcommand
        Dim dr As sqlclient.sqldatareader
        Dim vCutOff As String = ""
        Dim vDays() As String
        Dim iCtr As Integer

        c.Open()
        cm.Connection = c
        cm.CommandText = "select * from py_pay_mode where Pay_Cd='" & cmbPayMode.SelectedValue & "'"
        dr = cm.ExecuteReader
        If dr.Read Then
            Session("divisor") = IIf(IsDBNull(dr("Divisor")), 1, dr("Divisor"))
            Session("index") = "1"
            vCutOff = IIf(IsDBNull(dr("Days")), "", dr("Days"))
            cmbFrom.Items.Clear()
            txtTo.Text = ""
            vDays = vCutOff.Split(",")
            For iCtr = 0 To vDays.Length - 1
                cmbFrom.Items.Add(cmbMonth.SelectedValue & "/" & vDays(iCtr) & "/" & Now.Year)
                cmbFrom.Items.Add(cmbMonth.SelectedValue & "/" & vDays(iCtr) & "/" & Now.Year - 1)
            Next iCtr
        End If
        dr.Close()
        cm.Dispose()
        c.Close()
        c.Dispose()
        SetEndCutOff()
    End Sub

    Protected Sub cmbFrom_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbFrom.SelectedIndexChanged
        Select Case cmbFrom.SelectedIndex + 1
            Case 1, 3
                Session("index") = 1
            Case Else
                Session("index") = 2
        End Select
        SetEndCutOff()
    End Sub
    Private Sub SetEndCutOff()
        Dim vDate As Date
        Dim vTo As Date
        Dim c As New sqlclient.sqlconnection(connStr)
        Dim cm As New sqlclient.sqlcommand
        Dim dr As sqlclient.sqldatareader
        Dim vWorkingDays As Boolean = True
        Dim iDate As Date
        Dim iWeekEnds As Integer = 0

        txtTo.Text = ""

        If (cmbFrom.SelectedIndex = 1 And cmbFrom.Items.Count = 2) Or _
           (cmbFrom.SelectedIndex > 1 And cmbFrom.Items.Count > 2) Then
            Select Case cmbFrom.SelectedIndex
                Case 1, 2
                    vDate = CDate(cmbFrom.Items(0).Text)   'get first index value
                Case 3
                    vDate = CDate(cmbFrom.Items(1).Text)
            End Select
            If vDate.Month = 12 Then
                vTo = CDate("1/" & vDate.Day & "/" & vDate.Year + 1)
            Else
                vTo = CDate(vDate.Month + 1 & "/" & vDate.Day & "/" & vDate.Year)
            End If
        Else
            If cmbFrom.Items.Count = 2 Then
                vTo = CDate(cmbFrom.Items(cmbFrom.SelectedIndex + 1).Text)
            Else
                vTo = CDate(cmbFrom.Items(cmbFrom.SelectedIndex + 2).Text)
            End If
        End If
        txtTo.Text = DateAdd(DateInterval.Day, -1, vTo)

        c.Open()
        cm.Connection = c
        cm.CommandText = "select WorkingDays_Only from glsyscntrl"
        dr = cm.ExecuteReader
        If dr.Read Then
            vWorkingDays = IIf(IsDBNull(dr("WorkingDays_Only")), True, dr("WorkingDays_Only"))
        End If
        dr.Close()
        cm.CommandText = "select Days,CreditDay from py_pay_mode"
        dr = cm.ExecuteReader
        If dr.Read() Then
            Dim vCutOff() As String = dr("Days").ToString.Split(",")
            Dim vCredit() As String = dr("CreditDay").ToString.Split(",")
            Dim vDay As Integer = CDate(cmbFrom.SelectedValue).Day
            Dim iCtr As Integer
            Dim vMonth As Integer = 0
            Dim vYear As Integer = 0

            For iCtr = 0 To UBound(vCutOff)
                If vCutOff(iCtr) = vDay Then
                    If CDate(txtTo.Text).Month = 12 And CDate(txtTo.Text).Day >= 30 Then
                        vMonth = 0
                        vYear = CDate(txtTo.Text).Year + 1
                    Else
                        vMonth = CDate(txtTo.Text).Month
                        vYear = CDate(txtTo.Text).Year
                    End If
                    txtPayDate.Text = Format(vMonth + _
                        IIf(CDate(txtTo.Text).Day < vCredit(iCtr), 0, 1), "00") & "/" & Format(Val(vCredit(iCtr)), "00") & "/" & _
                        Format(vYear, "0000")
                    If vCredit(iCtr) = 30 Then
                        txtPayDate.Text = MonthEND(CDate(Mid(txtPayDate.Text, 1, 2) & "/1/" & Mid(txtPayDate.Text, 7)))
                    End If
                    Exit For
                End If
            Next iCtr
        End If

        cm.Dispose()
        c.Close()
        c.Dispose()
        iDate = CDate(cmbFrom.SelectedValue)
        Do While iDate <= CDate(txtTo.Text)
            If iDate.DayOfWeek = DayOfWeek.Sunday Or (iDate.DayOfWeek = DayOfWeek.Saturday And Not vWorkingDays) Then
                iWeekEnds += 1
            End If
            iDate = DateAdd(DateInterval.Day, 1, iDate)
        Loop
        Session("ActualDays") = Math.Abs(DateDiff(DateInterval.Day, CDate(cmbFrom.SelectedValue), CDate(txtTo.Text)) + 1 - iWeekEnds)
        Session("WeekEnds") = iWeekEnds
    End Sub

    Protected Sub cmdGenerate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdGenerate.Click
        DataRefresh(txtSearch.Text)
    End Sub
    Private Sub DataRefresh(ByVal pLetter As String)
        Dim vFilter As String = ""
        Dim vLtrFilter As String = ""
        Dim vOrder As String = ""
        Dim vFrom As String = Me.cmbFrom.SelectedValue
        Dim vTo As String = Me.txtTo.Text

        Session.Remove("vHeader")
        Session.Remove("vPeriod")
        Session.Remove("vFilter")
        Session.Remove("vList")

        If Not IsDate(vFrom) Or Not IsDate(vTo) Then
            Exit Sub
        Else
            vFrom = CDate(vFrom)
            vTo = CDate(vTo)
        End If

        If Me.cmbTxnType.SelectedIndex = 0 Then
            vOrder = " order by Emp_Lname,Emp_Fname,TranDate desc"
        ElseIf Me.cmbTxnType.SelectedIndex = 1 Then
            vOrder = " order by Emp_Lname,Emp_Fname,Tran_Date desc"
        End If

        vFilter = " And " & cmbType.SelectedValue & " like '" & pLetter & "%' "
        vLtrFilter = vFilter

        If cmbRC.SelectedValue <> "All" Then   'filter by cost center
            vFilter += " and py_emp_master.Rc_Cd='" & cmbRC.SelectedValue & "' "
            vLtrFilter += " and py_emp_master.Rc_Cd='" & cmbRC.SelectedValue & "' "
            Session("vFilter") += GetRef("SELECT Descr FROM rc WHERE Rc_Cd = '" & cmbRC.SelectedValue & "'", cmbRC.SelectedValue) & ", "
        Else
            vFilter += " and py_emp_master.Rc_Cd in ('" & Session("rclist").ToString.Replace(",", "','") & "') "
            vLtrFilter += " and py_emp_master.Rc_Cd in ('" & Session("rclist").ToString.Replace(",", "','") & "') "
        End If

        If cmbOfc.SelectedValue <> "All" Then        'filter by office/agency
            vFilter += " and py_emp_master.Agency_Cd='" & cmbOfc.SelectedValue & "' "
            vLtrFilter += " and py_emp_master.Agency_Cd='" & cmbOfc.SelectedValue & "' "
            Session("vFilter") += GetRef("SELECT AgencyName FROM agency WHERE AgencyCd = '" & cmbOfc.SelectedValue & "'", cmbOfc.SelectedValue) & ", "
        Else
            vFilter += " and py_emp_master.Agency_Cd in ('" & Session("agencylist").ToString.Replace(",", "','") & "') "
            vLtrFilter += " and py_emp_master.Agency_Cd in ('" & Session("agencylist").ToString.Replace(",", "','") & "') "
        End If
        If cmbDiv.SelectedValue <> "All" Then      'filter by division
            vFilter += " and py_emp_master.Divcd='" & cmbDiv.SelectedValue & "' "
            vLtrFilter += " and py_emp_master.Divcd='" & cmbDiv.SelectedValue & "' "
            Session("vFilter") += GetRef("SELECT Descr FROM hr_div_ref WHERE Div_Cd = '" & cmbDiv.SelectedValue & "'", cmbDiv.SelectedValue) & ", "
        Else
            vFilter += " and py_emp_master.DivCd in ('" & Session("divlist").ToString.Replace(",", "','") & "') "
            vLtrFilter += " and py_emp_master.DivCd in ('" & Session("divlist").ToString.Replace(",", "','") & "') "
        End If
        If cmbDept.SelectedValue <> "All" Then  'filter by departments
            vFilter += " and py_emp_master.DeptCd='" & cmbDept.SelectedValue & "' "
            vLtrFilter += " and py_emp_master.DeptCd='" & cmbDept.SelectedValue & "' "
            Session("vFilter") += GetRef("SELECT Descr FROM hr_dept_ref WHERE Dept_Cd = '" & cmbDept.SelectedValue & "'", cmbDept.SelectedValue) & ", "
        Else
            vFilter += " and py_emp_master.DeptCd in ('" & Session("deptlist").ToString.Replace(",", "','") & "') "
            vLtrFilter += " and py_emp_master.DeptCd in ('" & Session("deptlist").ToString.Replace(",", "','") & "') "
        End If
        If cmbSection.SelectedValue <> "All" Then 'filter by section
            vFilter += " and py_emp_master.SectionCd='" & cmbSection.SelectedValue & "' "
            vLtrFilter += " and py_emp_master.SectionCd='" & cmbSection.SelectedValue & "' "
            Session("vFilter") += GetRef("SELECT Descr FROM hr_section_ref WHERE Section_Cd = '" & cmbSection.SelectedValue & "'", cmbSection.SelectedValue) & ", "
        Else
            vFilter += " and py_emp_master.SectionCd in ('" & Session("sectionlist").ToString.Replace(",", "','") & "') "
            vLtrFilter += " and py_emp_master.SectionCd in ('" & Session("sectionlist").ToString.Replace(",", "','") & "') "
        End If
        If cmbUnit.SelectedValue <> "All" Then  'filter by units
            vFilter += " and py_emp_master.UnitCd='" & cmbUnit.SelectedValue & "' "
            vLtrFilter += " and py_emp_master.UnitCd='" & cmbUnit.SelectedValue & "' "
            Session("vFilter") += GetRef("SELECT Descr FROM hr_unit_ref WHERE Unit_Cd = '" & cmbUnit.SelectedValue & "'", cmbUnit.SelectedValue) & ", "
        Else
            vFilter += " and py_emp_master.UnitCd in ('" & Session("unitlist").ToString.Replace(",", "','") & "') "
            vLtrFilter += " and py_emp_master.UnitCd in ('" & Session("unitlist").ToString.Replace(",", "','") & "') "
        End If

        vFilter += " and EmploymentType in ('" & Session("typelist").ToString.Replace(",", "','") & "') "
        If Session("vFilter") <> "" Then
            Session("vFilter") = Session("vFilter").ToString.Substring(0, Session("vFilter").ToString.Length - 2)
        End If
        Session("vPeriod") = Format(CDate(vFrom), "MM/dd/yyyy") & " - " & Format(CDate(vTo), "MM/dd/yyyy")
        Session("vHeader") = cmbTxnType.SelectedItem.ToString



        Dim c As New sqlclient.sqlconnection(connStr)
        Dim cm As New sqlclient.sqlcommand
        Dim rs As sqlclient.sqldatareader
        Dim cRef As New sqlclient.sqlconnection(connStr)
        Dim cmRef As New sqlclient.sqlcommand
        Dim rsRef As sqlclient.sqldatareader
        Dim vEmpCd As String = ""
        Dim vSql As String = ""
        Dim vClass As String = "odd"

        c.Open()
        cm.Connection = c

        cRef.Open()
        cmRef.Connection = cRef

        cm.CommandText = "SELECT Emp_Cd FROM py_emp_master WHERE Date_Resign is null " & vFilter
        rs = cm.ExecuteReader
        Do While rs.Read
            vEmpCd += rs("Emp_Cd") & "','"
        Loop
        If rs.HasRows Then
            vEmpCd = vEmpCd.Substring(0, vEmpCd.Length.ToString - 3)
        End If
        rs.Close()

        Select Case cmbTxnType.SelectedValue
            Case "0" 'Late Leave
                vData = "<table border='1' cellspacing='0' style='border-collapse:collapse; width:95%'>"
                vData += "<tr class='even'><th style='width:100px'>Emp ID</th><th style='width:250px'>Emp Name</th><th  style='width:100px'>Hrs/Days</th><th style='width:100px'>Type</th><th>Start Date</th><th>End Date</th></tr>"
                cm.CommandText = "SELECT LeaveCd,Emp_Cd,DaysLeave,StartDate,EndDate FROM hr_leave_application WHERE Emp_Cd IN ('" & vEmpCd & "') " & _
                                 "AND EffectivityDate IS NOT NULL AND LeaveCd IN (SELECT Leave_Cd FROM py_leave_ref " & _
                                 "WHERE Leave_Cd NOT IN ('SUSP','UT')) AND Void=0 AND Paid=1 AND DateApproved IS NOT NULL " & _
                                 "AND EffectivityDate BETWEEN '" & cmbFrom.SelectedValue & "' AND '" & txtTo.Text & "'"
                rs = cm.ExecuteReader
                Do While rs.Read
                    If rs("DaysLeave") > 1 Then
                        cmRef.CommandText = "SELECT Emp_Cd,TranCd,(Hrs_Rendered / 8) AS Hrs_Rendered,TranDate FROM py_time_log_dtl WHERE Emp_Cd='" & _
                                            rs("Emp_Cd") & "' AND TranDate BETWEEN '" & rs("StartDate") & "' AND '" & rs("EndDate") & "'"
                        rsRef = cmRef.ExecuteReader
                        Do While rsRef.Read
                            vData += "<tr class='" & vClass & "'><td>" & rsRef("Emp_Cd") & "</td><td>" & GetName(rsRef("Emp_Cd")) & _
                                     "</td><td style='text-align:right'>" & Math.Round(rsRef("Hrs_Rendered"), 2) & " day(s)</td><td>" & _
                                     rs("LeaveCd") & "</td><td style='text-align:right'>" & Format(rsRef("TranDate"), "yyyy/MM/dd") & _
                                     "</td><td style='text-align:right'>" & Format(rsRef("TranDate"), "yyyy/MM/dd") & "</td></tr>"
                        Loop
                        rsRef.Close()
                    Else
                        vData += "<tr class='" & vClass & "'><td>" & rs("Emp_Cd") & "</td><td>" & GetName(rs("Emp_Cd")) & _
                                 "</td><td style='text-align:right'>" & rs("DaysLeave") & " day(s)</td><td>" & _
                                 rs("LeaveCd") & "</td><td style='text-align:right'>" & Format(rs("StartDate"), "yyyy/MM/dd") & _
                                 "</td><td style='text-align:right'>" & Format(rs("EndDate"), "yyyy/MM/dd") & "</td></tr>"
                    End If
                    If vClass = "odd" Then
                        vClass = "even"
                    Else
                        vClass = "odd"
                    End If
                Loop
                rs.Close()
                vData += "</table>"
            Case "1" 'Late Overtime
                vData = "<table border='1' cellspacing='0' style='border-collapse:collapse; width:95%'>"
                vData += "<tr class='even'><th style='width:100px'>Emp ID</th><th style='width:250px'>Emp Name</th><th  style='width:100px'>Hrs/Days</th><th style='width:100px'>Type</th><th>Start Date</th><th>End Date</th></tr>"
                cm.CommandText = "SELECT LeaveCd,Emp_Cd,DaysLeave,StartDate,EndDate FROM hr_leave_application WHERE Emp_Cd IN ('" & vEmpCd & "') " & _
                                 "AND EffectivityDate IS NOT NULL AND LeaveCd='OT' AND Void=0 AND Paid=1 AND DateApproved IS NOT NULL " & _
                                 "AND CAST(EffectivityDate AS DATE) BETWEEN '" & Format(CDate(cmbFrom.SelectedValue), "yyyy/MM/dd") & _
                                 "' AND '" & Format(CDate(txtTo.Text), "yyyy/MM/dd") & "'"
                rs = cm.ExecuteReader

                Do While rs.Read
                    cmRef.CommandText = "SELECT Emp_Cd,TranCd,Hrs_Rendered,TranDate FROM py_time_log_dtl WHERE Emp_Cd='" & _
                                        rs("Emp_Cd") & "' AND TranDate BETWEEN '" & Format(rs("StartDate"), "yyyy/MM/dd") & "' AND '" & Format(rs("EndDate"), "yyyy/MM/dd") & _
                                        "' AND TranCd in ('A1','B1','B3','C1','C3','D1','D3','E1','E3','F1','F3')"

                    rsRef = cmRef.ExecuteReader
                    Do While rsRef.Read
                        vData += "<tr class='" & vClass & "'><td>" & rsRef("Emp_Cd") & "</td><td>" & GetName(rsRef("Emp_Cd")) & _
                                 "</td><td style='text-align:right'>" & Math.Round(rsRef("Hrs_Rendered"), 2) & " hrs</td><td>" & _
                                 rs("LeaveCd") & "</td><td style='text-align:right'>" & Format(rsRef("TranDate"), "yyyy/MM/dd") & _
                                 "</td><td style='text-align:right'>" & Format(rsRef("TranDate"), "yyyy/MM/dd") & "</td></tr>"
                    Loop
                    rsRef.Close()
                    If vClass = "odd" Then
                        vClass = "even"
                    Else
                        vClass = "odd"
                    End If
                Loop
                rs.Close()
                vData += "</table>"
            Case "2" 'Late DTR Correction
                vData = "<table border='1' cellspacing='0' style='border-collapse:collapse; width:95%'>"
                vData += "<tr class='even'><th>Date</th><th style='width:100px'>Emp ID</th><th style='width:250px'>Emp Name</th>" & _
                         "<th>Time In</th><th>Time Out</th><th>Time Out Date</th><th>Reason</th><th>Hrs Worked</th></tr>"
                cm.CommandText = "SELECT Tran_Date,Emp_Cd,Emp_Name,Time_In,Time_Out,Time_OutDate,Hrs_Worked,Reason FROM py_time_log WHERE Emp_Cd IN ('" & vEmpCd & "') " & _
                                 "AND EffectivityDate IS NOT NULL AND Date_Approved IS NOT NULL " & _
                                 "AND CAST(EffectivityDate AS DATE) BETWEEN '" & Format(CDate(cmbFrom.SelectedValue), "yyyy/MM/dd") & _
                                 "' AND '" & Format(CDate(txtTo.Text), "yyyy/MM/dd") & "'"
                rs = cm.ExecuteReader

                Do While rs.Read

                    vData += "<tr class='" & vClass & "'><td style='text-align:right'>" & rs("Tran_Date") & "</td><td>" & rs("Emp_Cd") & "</td><td>" & GetName(rs("Emp_Cd")) & _
                             "<td style='text-align:right'>" & rs("Time_In") & "</td><td style='text-align:right'>" & rs("Time_Out") & "</td><td style='text-align:right'>" & rs("Time_OutDate") & "</td>" & _
                             "<td>" & rs("Reason") & "</td><td style='text-align:right'>" & rs("Hrs_Worked") & "</td></tr>"
                    If vClass = "odd" Then
                        vClass = "even"
                    Else
                        vClass = "odd"
                    End If
                Loop
                rs.Close()
                vData += "</table>"
        End Select

        Session("vList") = vData
        cmRef.Dispose()
        cRef.Close()
        cRef.Dispose()

        cm.Dispose()
        c.Close()
        c.Dispose()

    End Sub
End Class
