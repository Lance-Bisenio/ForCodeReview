Imports denaro
Partial Class modifydep
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Dim c As New sqlclient.sqlconnection
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim addtype As String = ""
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If
        If Not IsPostBack Then
            Dim cm As New sqlclient.sqlcommand
            Dim dr As sqlclient.sqldatareader
            txtEmpCd.Text = Session("empid")

            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c
            cm.CommandText = "select Emp_Lname,Emp_Fname from py_emp_master where Emp_Cd='" & txtEmpCd.Text & "'"
            dr = cm.ExecuteReader
            lblDependents.Text = "Add/Modify " & Session("addtype") & " for "
            If dr.Read Then
                lblDependents.Text += dr("Emp_Lname") & ", " & dr("Emp_Fname")
            End If
            dr.Close()
            If Session("addtype") = "dependents" Then
                compschool.Visible = False
                position.Visible = False
                tel.Visible = False
                position.Visible = False
                department.Visible = False
            ElseIf Session("addtype") = "sibling" Then
                bplace.Visible = False
                department.Visible = False
            Else
                ''adding relatives
                bday.Visible = False
                bplace.Visible = False
                compschool.Visible = False
            End If

            If Session("mode") = "e" Then
                cm.CommandText = "Select * from hr_dependents where SeqId='" & Session("seqid") & "'"
                'If Session("addtype") = "dependents" Then
                'ElseIf Session("addtype") = "sibling" Then

                'Else
                'End If
                dr = cm.ExecuteReader
                If dr.Read Then

                    If Not IsDBNull(dr("DependentName")) Then txtDependentName.Text = dr("DependentName")
                    If Not IsDBNull(dr("Sex")) Then
                        cmbGender.SelectedValue = dr("Sex")
                    Else
                        cmbGender.SelectedValue = "Male"
                    End If
                    If Not IsDBNull(dr("Relationship")) Then txtRelationship.Text = dr("Relationship")
                    If Not IsDBNull(dr("Bday")) Then txtbday.Text = Format(CDate(dr("Bday")), "yyyy/MM/dd")
                    If Not IsDBNull(dr("BPlace")) Then txtBPlace.Text = dr("BPlace")
                    If Not IsDBNull(dr("Tel")) Then txtTel.Text = dr("Tel")
                    If Not IsDBNull(dr("School")) Then txtSchoolComp.Text = dr("School")
                    If Not IsDBNull(dr("Position")) Then txtPos.Text = dr("Position")
                    If Not IsDBNull(dr("BPlace")) Then txtDepartment.Text = dr("BPlace")
                    If Not IsDBNull(dr("HMO_Age")) Then txtAge.Text = dr("HMO_Age")

                    If Not IsDBNull(dr("HMO_Mem")) Then
                        If dr("HMO_Mem") = 1 Then
                            chkHMOmem.Checked = True
                        End If
                    End If
                End If
                dr.Close()
                'Else   'Adding new records either dependents,sibling,relative
            End If
            cm.Dispose()
            c.Close()
        End If
    End Sub

    Protected Sub cmdCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        Session.Remove("empid")
        Session.Remove("mode")
        Session.Remove("seqid")
        'Server.Transfer("emp.aspx")
        vScript = "window.close();"
    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        Dim vPlace As String = ""
        Dim vHMOmem As Integer = 0

        If chkHMOmem.Checked = True Then
            vHMOmem = 1

            If txtAge.Text.Trim <> "" Then
                If Not IsNumeric(txtAge.Text.Trim) Then
                    vScript = "alert('Invalid Age value.');"
                    Exit Sub
                End If
            End If
        End If

        If Page.IsValid Then
            Dim cm As New SqlClient.SqlCommand
            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c
            If txtbday.Text = "" Then
                txtbday.Text = "NULL"
            Else
                txtbday.Text = "'" & Format(CDate(txtbday.Text), "yyyy/MM/dd") & "'"
            End If

            If Session("addtype") = "dependents" Then
                vPlace = IIf(txtBPlace.Text = "", "NULL", "'" & CleanVar(txtBPlace.Text) & "'")
            ElseIf Session("addtype") = "sibling" Then
                vPlace = IIf(txtBPlace.Text = "", "NULL", "'" & CleanVar(txtBPlace.Text) & "'")
            Else
                vPlace = IIf(txtDepartment.Text = "", "NULL", "'" & CleanVar(txtDepartment.Text) & "'")
            End If

            If Session("mode") = "e" Then 'edit mode
                cm.CommandText = "update hr_dependents set Emp_Cd=" & IIf(txtEmpCd.Text = "", "NULL", "'" & CleanVar(txtEmpCd.Text) & "'") & "," & _
                                 "DependentName=" & IIf(txtDependentName.Text = "", "NULL", "'" & CleanVar(txtDependentName.Text) & "'") & "," & _
                                 "Sex='" & cmbGender.SelectedValue & "'," & _
                                 "Relationship=" & IIf(txtRelationship.Text = "", "NULL", "'" & CleanVar(txtRelationship.Text) & "'") & "," & _
                                 "Bday=" & txtbday.Text & "," & _
                                 "BPlace=" & vPlace & "," & _
                                 "Tel=" & IIf(txtTel.Text = "", "NULL", "'" & CleanVar(txtTel.Text) & "'") & "," & _
                                 "School=" & IIf(txtSchoolComp.Text = "", "NULL", "'" & CleanVar(txtSchoolComp.Text) & "'") & "," & _
                                 "HMO_Mem=" & vHMOmem & "," & _
                                 "HMO_Age=" & IIf(txtAge.Text.Trim = "", 0, txtAge.Text.Trim) & "," & _
                                 "Position=" & IIf(txtPos.Text = "", "NULL", "'" & CleanVar(txtPos.Text) & "'") & _
                                 " where SeqId='" & Session("seqid") & "'"
            Else  'adding
                cm.CommandText = "insert into hr_dependents(Emp_Cd,DependentName,Sex,Relationship,Bday," & _
                                 "BPlace,Tel,School,Position,rel_type, HMO_Mem, HMO_Age)values('" & CleanVar(txtEmpCd.Text) & "'," & _
                                 IIf(txtDependentName.Text = "", "NULL", "'" & CleanVar(txtDependentName.Text) & "'") & ",'" & _
                                 cmbGender.SelectedValue & "'," & _
                                 IIf(txtRelationship.Text = "", "NULL", "'" & CleanVar(txtRelationship.Text) & "'") & "," & _
                                 txtbday.Text & "," & vPlace & "," & _
                                 IIf(txtTel.Text = "", "NULL", "'" & CleanVar(txtTel.Text) & "'") & "," & _
                                 IIf(txtSchoolComp.Text = "", "NULL", "'" & CleanVar(txtSchoolComp.Text) & "'") & "," & _
                                 IIf(txtPos.Text = "", "NULL", "'" & CleanVar(txtPos.Text) & "'") & ",'" & Session("addtype") & _
                                 "', " & vHMOmem & ", " & IIf(txtAge.Text.Trim = "", 0, txtAge.Text.Trim) & ")"
            End If
            'Response.Write(cm.CommandText)
            cm.ExecuteNonQuery()
            vScript = "alert('Changes were successfully saved.');self.close();"
        End If
    End Sub

    Protected Sub CustomValidator1_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles CustomValidator1.ServerValidate
        args.IsValid = IsDate(txtbday.Text)
        If Not args.IsValid Then
            vScript = "alert('Invalid date format.');"
        End If
    End Sub
    Private Function CleanVar(ByVal pStr As String) As String
        Return pStr.Replace("'", "''")
    End Function
End Class
