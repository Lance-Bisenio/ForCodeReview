Imports denaro.fis
Partial Class profile
    Inherits System.Web.UI.Page
    Public msg As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            msg = "alert('Your session has expired!'); window.close();"
            Exit Sub
        End If
        If Not IsPostBack Then
            Dim vShifts(7) As String
            Dim iCtr As Integer
            Dim cn As New SqlClient.SqlConnection(connStr)
            Dim cm As New SqlClient.SqlCommand
            Dim rs As SqlClient.SqlDataReader

            cn.Open()
            cm.Connection = cn
            vShifts(0) = Request.Item("sun")
            vShifts(1) = Request.Item("mon")
            vShifts(2) = Request.Item("tue")
            vShifts(3) = Request.Item("wed")
            vShifts(4) = Request.Item("thu")
            vShifts(5) = Request.Item("fri")
            vShifts(6) = Request.Item("sat")
            'check if this pattern already exist in the profile
            cm.CommandText = "select * from py_shift_profile where SunShiftCd='" & vShifts(0) & _
                 "' and MonShiftCd='" & vShifts(1) & "' and TueShiftCd='" & vShifts(2) & _
                 "' and WedShiftCd='" & vShifts(3) & "' and ThuShiftCd='" & vShifts(4) & _
                 "' and FriShiftCd='" & vShifts(5) & "' and SatShiftCd='" & vShifts(6) & "'"
            rs = cm.ExecuteReader
            If rs.Read Then
                txtId.Text = rs("ProfileCd")
                txtName.Text = rs("Descr")
                txtId.ReadOnly = True
                txtName.ReadOnly = True
                msg = "alert('This pattern has a profile already defined.');"
            End If
            rs.Close()

            For iCtr = 0 To UBound(vShifts)
                cm.CommandText = "select * from py_shift where ShiftCd='" & _
                    vShifts(iCtr) & "'"
                rs = cm.ExecuteReader
                If rs.Read Then
                    Dim vDescr As String = rs("Descr")
                    Dim vStart As String = IIf(IsDBNull(rs("Start_Time")), "", rs("Start_Time"))
                    Dim vEnd As String = IIf(IsDBNull(rs("End_Time")), "", rs("End_Time"))

                    Select Case iCtr
                        Case 0  'sun
                            txtShiftSun.Text = vShifts(0)
                            txtSunDescr.Text = vDescr
                            txtSunStart.Text = vStart
                            txtSunEnd.Text = vEnd
                        Case 1  'mon
                            txtShiftMon.Text = vShifts(1)
                            txtMonDescr.Text = vDescr
                            txtMonStart.Text = vStart
                            txtMonEnd.Text = vEnd
                        Case 2  'tue
                            txtShiftTue.Text = vShifts(2)
                            txtTueDescr.Text = vDescr
                            txtTueStart.Text = vStart
                            txtTueEnd.Text = vEnd
                        Case 3  'wed
                            txtShiftWed.Text = vShifts(3)
                            txtWedDescr.Text = vDescr
                            txtWedStart.Text = vStart
                            txtWedEnd.Text = vEnd
                        Case 4  'thu
                            txtShiftThu.Text = vShifts(4)
                            txtThuDescr.Text = vDescr
                            txtThuStart.Text = vStart
                            txtThuEnd.Text = vEnd
                        Case 5  'fri
                            txtShiftFri.Text = vShifts(5)
                            txtFriDescr.Text = vDescr
                            txtFriStart.Text = vStart
                            txtFriEnd.Text = vEnd
                        Case 6  'sat
                            txtShiftSat.Text = vShifts(6)
                            txtSatDescr.Text = vDescr
                            txtSatStart.Text = vStart
                            txtSatEnd.Text = vEnd
                    End Select
                End If
                rs.Close()
            Next iCtr
            cn.Close()
            cm.Dispose()
            cn.Dispose()
        End If
    End Sub

    Protected Sub cmdDel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDel.Click
        Dim cn As New sqlclient.sqlconnection(connStr)
        Dim cm As New sqlclient.sqlcommand("delete from py_shift_profile where ProfileCd='" & _
            txtId.Text & "'", cn)
        cn.Open()
        cm.ExecuteNonQuery()
        cn.Close()
        cn.Dispose()
        cm.Dispose()
        msg = "alert('Profile was successfully deleted.'); opener.refresh; window.close();"
    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        Dim cn As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand

        Try
            cn.Open()
        Catch ex As SqlClient.SqlException
            msg = "alert('Error occurred while trying to connect to the database server. Error is: " & _
                ex.Message.Replace("'", "").Replace(vbCrLf, "") & "');"
            cn.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        cm.Connection = cn
        cm.CommandText = "insert into py_shift_profile (Descr,SunShiftCd,MonShiftCd,TueShiftCd," & _
            "WedShiftCd,ThuShiftCd,FriShiftCd,SatShiftCd) values ('" & txtName.Text & "','" & _
            txtShiftSun.Text & "','" & txtShiftMon.Text & "','" & _
            txtShiftTue.Text & "','" & txtShiftWed.Text & "','" & txtShiftThu.Text & "','" & _
            txtShiftFri.Text & "','" & txtShiftSat.Text & "')"
        Try
            cm.ExecuteNonQuery()
            msg = "alert('Profile was successfully saved.'); opener.refresh(); window.close();"
        Catch ex As SqlClient.SqlException
            msg = "alert('Error occurred while tyring to save the record. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") * "');"
        Finally
            cn.Close()
            cn.Dispose()
            cm.Dispose()
        End Try
    End Sub
End Class
