Imports denaro
Partial Class phicsetup
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Dim c As New sqlclient.sqlconnection
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If
        If Not IsPostBack Then
            Dim cm As New sqlclient.sqlcommand
            Dim dr As sqlclient.sqldatareader
            lblcaption.text = "Philhealth Setup Parameters"
            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c
            cm.CommandText = "select PhicNo,Company_Name,Address,Attention,AttentionPos " & _
                "from glsyscntrl where AgencyCd='" & Session("office") & "'"
            dr = cm.ExecuteReader
            If dr.Read Then
                txtCompanyName.Text = IIf(IsDBNull(dr("Company_Name")), "", dr("Company_Name"))
                txtAddress.Text = IIf(IsDBNull(dr("Address")), "", dr("Address"))
                txtPhicNo.Text = IIf(IsDBNull(dr("PhicNo")), "", dr("PhicNo"))
                txtAttention.Text = IIf(IsDBNull(dr("Attention")), "", dr("Attention"))
                txtPosition.Text = IIf(IsDBNull(dr("AttentionPos")), "", dr("AttentionPos"))
            Else
                vScript = "alert('Record not found!');"
            End If
            dr.Close()
            cm.Dispose()
            c.Close()
        End If
    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        Dim cm As New sqlclient.sqlcommand

        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c
        cm.CommandText = "update glsyscntrl set Company_Name='" & txtCompanyName.Text & _
            "',Address='" & txtAddress.Text & _
            "',PhicNo='" & txtPhicNo.Text & _
            "',Attention='" & txtAttention.Text & _
            "',AttentionPos='" & txtPosition.Text & "' where AgencyCd='" & Session("office") & "'"
        cm.ExecuteNonQuery()
        cm.Dispose()
        c.Close()
        vScript = "alert('Changes have been saved successfully!'); window.close();"
    End Sub
End Class
