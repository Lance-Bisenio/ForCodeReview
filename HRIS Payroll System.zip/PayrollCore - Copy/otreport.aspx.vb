Imports denaro.fis
Partial Class otreport
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Public vDisplayData As String = ""
    Public vData As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If

        txtRank.Text = Request.Form("txtRank")
        If Not IsPostBack Then
            If Not CanRun(Session("caption"), Request.Item("id")) Then
                Session("denied") = "1"
                Server.Transfer("main.aspx")
                Exit Sub
            End If
            'lblcaption.text = "View/Print Payroll Register"
            Dim vItem As New ListItem
            '            Dim i As Integer
            BuildCombo("select Rc_Cd,Descr from rc where exists (select User_Id from rights_list where User_Id='" & _
                   Session("uid") & "' and property='rc' and Property_Value=Rc_Cd) order by Descr", cmbRC)
            BuildCombo("select AgencyCd,AgencyName from agency where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='agency' and Property_Value=AgencyCd) order by AgencyName", cmbOffice)
            BuildCombo("select Div_Cd,Descr from hr_div_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='division' and Property_Value=Div_Cd) order by Descr", cmbDiv)
            BuildCombo("select Dept_Cd,Descr from hr_dept_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='department' and Property_Value=Dept_Cd) order by Descr", cmbDept)
            BuildCombo("select Section_Cd,Descr from hr_section_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='section' and Property_Value=Section_Cd) order by Descr", cmbSection)
            BuildCombo("select Unit_Cd,Descr from hr_unit_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='unit' and Property_Value=Unit_Cd) order by Descr", cmbUnit)
            'BuildCombo("select EmploymentType,Descr from hr_employment_type where exists (select User_Id from rights_list where User_Id='" & _
            'Session("uid") & "' and property='employmenttype' and Property_Value=EmploymentType) order by Descr", cmbSecurity)

            BuildCombo("select Status_Code,Descr from py_employee_stat order by Descr", cmbStatus)

            cmbRC.Items.Add("All")
            cmbDiv.Items.Add("All")
            cmbDept.Items.Add("All")
            cmbSection.Items.Add("All")
            cmbUnit.Items.Add("All")
            'cmbSecurity.Items.Add("All")
            cmbStatus.Items.Add("All Status")

            cmbRC.SelectedValue = "All"
            cmbDiv.SelectedValue = "All"
            cmbDept.SelectedValue = "All"
            cmbSection.SelectedValue = "All"
            cmbUnit.SelectedValue = "All"
            'cmbSecurity.SelectedValue = "All"
            cmbStatus.SelectedValue = "All Status"
            cmbMonthFrom.SelectedValue = Now.Month
            cmbMonthTo.SelectedValue = Now.Month

            Dim c As New SqlClient.SqlConnection(connStr)
            Dim cm As New SqlClient.SqlCommand
            Dim rs As SqlClient.SqlDataReader
            Try
                c.Open()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                c.Dispose()
                cm.Dispose()
                Exit Sub
            End Try

            cm.Connection = c
            cm.CommandText = "select distinct year(paydate) from py_report order by year(paydate) desc "
            Try
                rs = cm.ExecuteReader
                cmbYearTo.Items.Clear()
                cmbYearFrom.Items.Clear()
                Do While rs.Read
                    cmbYearFrom.Items.Add(rs(0))
                Loop
                rs.Close()
                If cmbYearFrom.Items.Count > 0 Then
                    cmbYearFrom.SelectedIndex = 0
                    cmbMonthFrom_SelectedIndexChanged(sender, e)
                    cmbMonthTo_SelectedIndexChanged(sender, e)
                Else
                    vScript = "alert('No records yet in the payroll register. There should be at " & _
                        "least one payroll register transaction in order for this report to run.');"
                End If
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to read Payroll register. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            Finally
                c.Close()
                cm.Dispose()
                c.Dispose()
            End Try
        End If
    End Sub

    Protected Sub cmdReturn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.Click
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub cmdRefresh_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdRefresh.Click
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cmSection As New SqlClient.SqlCommand
        Dim cmEmp As New SqlClient.SqlCommand
        Dim cmRef As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim rsSection As SqlClient.SqlDataReader
        Dim rsRef As SqlClient.SqlDataReader
        Dim rsEmp As SqlClient.SqlDataReader

        Dim vStartDate As Date
        Dim vEndDate As Date
        Dim vClass As String = "odd"
        Dim vFilter As String = ""
        Dim vDeptFilter As String = ""
        Dim vDump As New StringBuilder
        Dim vSectionDescr As String = ""
        Dim vSubHeader As String = ""
        Dim vDeptGrp As String = ""
        Dim vOnce As Boolean = True

        Dim vHeadCount As Decimal = 0
        Dim vRegOT() As Decimal = {0, 0}
        Dim vND() As Decimal = {0, 0}
        Dim vNDReg() As Decimal = {0, 0}
        Dim vRestDay() As Decimal = {0, 0}
        Dim vHoliday() As Decimal = {0, 0}
        Dim vHolidayRest() As Decimal = {0, 0}
        Dim vCrossTotal() As Decimal = {0, 0}

        Dim vDeptHeadCount As Decimal = 0
        Dim vDeptRegOt() As Decimal = {0, 0}
        Dim vDeptND() As Decimal = {0, 0}
        Dim vDeptNDReg() As Decimal = {0, 0}
        Dim vDeptRestDay() As Decimal = {0, 0}
        Dim vDeptHoliday() As Decimal = {0, 0}
        Dim vDeptHolidayRest() As Decimal = {0, 0}
        Dim vDeptCrossTotal() As Decimal = {0, 0}

        Dim vTotHeadCount As Decimal = 0
        Dim vTotRegOT() As Decimal = {0, 0}
        Dim vTotND() As Decimal = {0, 0}
        Dim vTotNDReg() As Decimal = {0, 0}
        Dim vTotRest() As Decimal = {0, 0}
        Dim vTotHoliday() As Decimal = {0, 0}
        Dim vTotHolidayRest() As Decimal = {0, 0}
        Dim vTotCrossTotal() As Decimal = {0, 0}

        Dim vEmpRegOt As Decimal = 0
        Dim vEmpND As Decimal = 0
        Dim vEmpNDReg As Decimal = 0
        Dim vEmpRest As Decimal = 0
        Dim vEmpHoliday As Decimal = 0
        Dim vEmpHolidayRest As Decimal = 0
        Dim vEmpTotHours As Decimal = 0
        Dim vDummy As Decimal = 0

        'define filters first
        If cmbRC.SelectedValue <> "All" Then   'filter by cost center
            vFilter += " and Rc_Cd='" & cmbRC.SelectedValue & "' "
            vSubHeader += "Cost Center: " & cmbRC.SelectedItem.Text & "<br/>"
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='rc' and Property_Value=Rc_Cd) "
        End If
        If cmbOffice.SelectedValue <> "All" Then        'filter by office/agency
            vFilter += " and Agency_Cd='" & cmbOffice.SelectedValue & "' "
            vSubHeader += "Company: " & cmbOffice.SelectedItem.Text & "<br/>"
        Else
            vFilter += "  and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='agency' and Property_Value=Agency_Cd) "
        End If
        If cmbDiv.SelectedValue <> "All" Then      'filter by division
            vFilter += " and Divcd='" & cmbDiv.SelectedValue & "' "
            vSubHeader += "Division: " & cmbDiv.SelectedItem.Text & "<br/>"
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='division' and Property_Value=DivCd) "
        End If
        If cmbDept.SelectedValue <> "All" Then  'filter by departments
            vFilter += " and DeptCd='" & cmbDept.SelectedValue & "' "
            vDeptFilter = " where Dept_Cd='" & cmbDept.SelectedValue & "' "
            vSubHeader += "Department: " & cmbDept.SelectedItem.Text & "<br/>"
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='department' and Property_Value=DeptCd) "
            vDeptFilter = " where exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='department' and Property_Value=Dept_Cd) "
        End If
        If cmbSection.SelectedValue <> "All" Then 'filter by section
            vFilter += " and SectionCd='" & cmbSection.SelectedValue & "' "
            vSubHeader += "Section: " & cmbSection.SelectedItem.Text & "<br/>"
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='section' and Property_Value=SectionCd) "
        End If
        If cmbUnit.SelectedValue <> "All" Then  'filter by units
            vFilter += " and UnitCd='" & cmbUnit.SelectedValue & "' "
            vSubHeader += "Unit: " & cmbUnit.SelectedItem.Text & "<br/>"
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='unit' and Property_Value=UnitCd) "
        End If

        vFilter += " and EmploymentType in ('" & txtRank.Text.Replace(",", "','") & "')"
        vSubHeader += "Rank: " & txtRank.Text & "<br/>"
        'If cmbSecurity.SelectedValue <> "All" Then 'filter by employment types
        '    vFilter += " and EmploymentType='" & cmbSecurity.SelectedValue & "' "
        '    vSubHeader += "Rank: " & cmbSecurity.SelectedItem.Text & "<br/>"
        'Else
        '    vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
        '        "' and Property='employmenttype' and Property_Value=EmploymentType) "
        'End If
        'EMPLOYEE STATUS
        If cmbStatus.SelectedValue <> "All Status" Then     'use specif employment status
            vFilter += " and Emp_Status='" & cmbStatus.SelectedValue & "' "
            vSubHeader += "Emp. Status: " & cmbStatus.SelectedItem.Text & "<br/>"
        End If

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "\n").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            cmSection.Dispose()
            cmRef.Dispose()
            cmEmp.Dispose()
            Exit Sub
        End Try

        cm.Connection = c
        cmSection.Connection = c
        cmRef.Connection = c
        cmEmp.Connection = c

        'get cut off dates based on paydates
        vStartDate = CDate(cmbMonthFrom.SelectedValue & "/" & cmbDayFrom.SelectedValue & "/" & cmbYearFrom.SelectedValue)
        vEndDate = CDate(cmbMonthTo.SelectedValue & "/" & cmbDayTo.SelectedValue & "/" & cmbYearTo.SelectedValue)
        
        vDump.AppendLine("<p align='center' style='font-size:10pt;font-family:Arial;'><b>")
        vDump.AppendLine("Overtime Summary Report<br />" & _
               "From " & Format(vStartDate, "MM/dd/yyyy") & _
               " To " & Format(vEndDate, "MM/dd/yyyy"))
        vDump.AppendLine("<br />" & vSubHeader)
        vDump.AppendLine("</b></p>")
        vDisplayData = vDump.ToString

        vDump.Remove(0, vDump.Length)

        cm.CommandText = "select Dept_Cd,Descr from hr_dept_ref " & vDeptFilter & " order by Descr"
        rs = cm.ExecuteReader

        Do While rs.Read
            cmSection.CommandText = "select distinct SectionCd,sum(BasicRate) as BasicRate " & _
                "from py_report where DeptCd='" & rs("Dept_Cd") & "' and PayDate between '" & _
                Format(vStartDate, "yyyy/MM/dd") & "' and '" & Format(vEndDate, "yyyy/MM/dd") & _
                "' " & vFilter & " group by sectioncd"
            rsSection = cmSection.ExecuteReader
            With vDump
                .AppendLine("<tr class='activeBar'>")
                .AppendLine("<td class='labelL'>" & rs("Descr") & "</td>")
                .AppendLine("<td class='labelR'>%headcount%</td>")
                .AppendLine("<td class='labelR'>%deptothrs%</td>")
                .AppendLine("<td class='labelR'>%deptotamt%</td>")
                .AppendLine("<td class='labelR'>%deptndhrs%</td>")
                .AppendLine("<td class='labelR'>%deptndamt%</td>")
                .AppendLine("<td class='labelR'>%deptrestdayhrs%</td>")
                .AppendLine("<td class='labelR'>%deptrestdayamt%</td>")
                .AppendLine("<td class='labelR'>%deptholidayhrs%</td>")
                .AppendLine("<td class='labelR'>%deptholidayamt%</td>")
                .AppendLine("<td class='labelR'>%deptholidayresthrs%</td>")
                .AppendLine("<td class='labelR'>%deptholidayrestamt%</td>")
                .AppendLine("<td class='labelR'>%deptndreghrs%</td>")
                .AppendLine("<td class='labelR'>%deptndregamt%</td>")
                .AppendLine("<td class='labelR'>%crosstotalhrs%</td>")
                .AppendLine("<td class='labelR'>%crosstotalamt%</td>")
                .AppendLine("</tr>")
            End With
            vDeptRegOt(0) = 0 : vDeptRegOt(1) = 0
            vDeptND(0) = 0 : vDeptND(1) = 0
            vDeptNDReg(0) = 0 : vDeptNDReg(1) = 0
            vDeptRestDay(0) = 0 : vDeptRestDay(1) = 0
            vDeptHoliday(0) = 0 : vDeptHoliday(1) = 0
            vDeptHolidayRest(0) = 0 : vDeptHolidayRest(1) = 0
            vDeptCrossTotal(0) = 0 : vDeptCrossTotal(1) = 0
            vDeptHeadCount = 0
            Do While rsSection.Read
                'get head count
                vHeadCount = 0
                HeadCount(c, vHeadCount, rs("Dept_Cd"), rsSection("SectionCd"), vStartDate, vEndDate, vFilter)
                'get regular overtime
                GetOT("'A1'", vStartDate, vEndDate, rs("Dept_Cd"), rsSection("SectionCd"), c, _
                    vRegOT(0), vRegOT(1), vFilter)
                'get night diff
                GetOT("'A2','A3','B2','B4','C2','C4','D2','D4','E2','E4','F2','F4'", vStartDate, vEndDate, _
                    rs("Dept_Cd"), rsSection("SectionCd"), c, vND(0), vND(1), vFilter)
                'get night diff regular
                GetOT("'A4','NDREG'", vStartDate, vEndDate, rs("Dept_Cd"), rsSection("SectionCd"), c, vNDReg(0), vNDReg(1), vFilter)
                'get restday
                GetOT("'E1','E3'", vStartDate, vEndDate, rs("Dept_Cd"), rsSection("SectionCd"), c, _
                    vRestDay(0), vRestDay(1), vFilter)
                'get holiday
                GetOT("'C1','C3','F1','F3'", vStartDate, vEndDate, rs("Dept_Cd"), rsSection("SectionCd"), c, _
                    vHoliday(0), vHoliday(1), vFilter)
                'get holiday on restday
                GetOT("'B1','B3','D1','D3'", vStartDate, vEndDate, rs("Dept_Cd"), rsSection("SectionCd"), _
                    c, vHolidayRest(0), vHolidayRest(1), vFilter)

                vTotHeadCount += vHeadCount
                vTotRegOT(0) += vRegOT(0)
                vTotRegOT(1) += vRegOT(1)
                vTotND(0) += vND(0)
                vTotND(1) += vND(1)
                vTotNDReg(0) += vNDReg(0)
                vTotNDReg(1) += vNDReg(1)
                vTotRest(0) += vRestDay(0)
                vTotRest(1) += vRestDay(1)
                vTotHoliday(0) += vHoliday(0)
                vTotHoliday(1) += vHoliday(1)
                vTotHolidayRest(0) += vHolidayRest(0)
                vTotHolidayRest(1) += vHolidayRest(1)

                vCrossTotal(0) = vRegOT(0) + vND(0) + vNDReg(0) + vRestDay(0) + vHoliday(0) + vHolidayRest(0)
                vCrossTotal(1) = vRegOT(1) + vND(1) + vNDReg(1) + vRestDay(1) + vHoliday(1) + vHolidayRest(1)
                vTotCrossTotal(0) += vRegOT(0) + vND(0) + vNDReg(0) + vRestDay(0) + vHoliday(0) + vHolidayRest(0)
                vTotCrossTotal(1) += vRegOT(1) + vND(1) + vNDReg(1) + vRestDay(1) + vHoliday(1) + vHolidayRest(1)

                vDeptHeadCount += vHeadCount
                vDeptRegOt(0) += vRegOT(0)
                vDeptRegOt(1) += vRegOT(1)
                vDeptND(0) += vND(0)
                vDeptND(1) += vND(1)
                vDeptNDReg(0) += vNDReg(0)
                vDeptNDReg(1) += vNDReg(1)
                vDeptRestDay(0) += vRestDay(0)
                vDeptRestDay(1) += vRestDay(1)
                vDeptHoliday(0) += vHoliday(0)
                vDeptHoliday(1) += vHoliday(1)
                vDeptHolidayRest(0) += vHolidayRest(0)
                vDeptHolidayRest(1) += vHolidayRest(1)

                vDeptCrossTotal(0) += vRegOT(0) + vND(0) + vNDReg(0) + vRestDay(0) + vHoliday(0) + vHolidayRest(0)
                vDeptCrossTotal(1) += vRegOT(1) + vND(1) + vNDReg(1) + vRestDay(1) + vHoliday(1) + vHolidayRest(1)


                cmRef.CommandText = "select Descr from hr_section_ref where Section_Cd='" & rsSection("SectionCd") & "'"
                rsRef = cmRef.ExecuteReader
                vSectionDescr = rsSection("SectionCd") & "=>Unknown"
                If rsRef.Read Then
                    vSectionDescr = IIf(IsDBNull(rsRef("Descr")), rsSection("SectionCd") & "=>Unknown", rsRef("Descr"))
                End If
                rsRef.Close()

                With vDump
                    .AppendLine("<tr class='even'>")
                    .AppendLine("<td class='labelL'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" & vSectionDescr & "</td>")
                    .AppendLine("<td class='labelR'>" & IIf(vHeadCount = 0, "-", Format(vHeadCount, "##,##0")) & "</td>")
                    .AppendLine("<td class='labelR'>" & IIf(vRegOT(0) = 0, "-", Format(vRegOT(0), "###,##0.00")) & "</td>")
                    .AppendLine("<td class='labelR'>" & IIf(vRegOT(1) = 0, "-", Format(vRegOT(1), "##,###,##0.00")) & "</td>")
                    .AppendLine("<td class='labelR'>" & IIf(vND(0) = 0, "-", Format(vND(0), "###,##0.00")) & "</td>")
                    .AppendLine("<td class='labelR'>" & IIf(vND(1) = 0, "-", Format(vND(1), "##,###,##0.00")) & "</td>")
                    .AppendLine("<td class='labelR'>" & IIf(vRestDay(0) = 0, "-", Format(vRestDay(0), "###,##0.00")) & "</td>")
                    .AppendLine("<td class='labelR'>" & IIf(vRestDay(1) = 0, "-", Format(vRestDay(1), "##,###,##0.00")) & "</td>")
                    .AppendLine("<td class='labelR'>" & IIf(vHoliday(0) = 0, "-", Format(vHoliday(0), "###,##0.00")) & "</td>")
                    .AppendLine("<td class='labelR'>" & IIf(vHoliday(1) = 0, "-", Format(vHoliday(1), "##,###,##0.00")) & "</td>")
                    .AppendLine("<td class='labelR'>" & IIf(vHolidayRest(0) = 0, "-", Format(vHolidayRest(0), "###,##0.00")) & "</td>")
                    .AppendLine("<td class='labelR'>" & IIf(vHolidayRest(1) = 0, "-", Format(vHolidayRest(1), "##,###,##0.00")) & "</td>")
                    .AppendLine("<td class='labelR'>" & IIf(vNDReg(0) = 0, "-", Format(vNDReg(0), "##,###,##0.00")) & "</td>")
                    .AppendLine("<td class='labelR'>" & IIf(vNDReg(1) = 0, "-", Format(vNDReg(1), "##,###,##0.00")) & "</td>")
                    .AppendLine("<td class='labelR'>" & IIf(vCrossTotal(0) = 0, "-", Format(vCrossTotal(0), "##,###,##0.00")) & "</td>")
                    .AppendLine("<td class='labelR'>" & IIf(vCrossTotal(1) = 0, "-", Format(vCrossTotal(1), "##,###,##0.00")) & "</td>")
                    .AppendLine("</tr>")
                End With
                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY:  VIC GATCHALIAN                                                           ''
                '' DATE MODIFIED: 6/4/2012                                                                ''
                '' PURPOSE: TO ADD SPECIFIC EMPLOYEES LIST                                                ''
                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                If chkDetailed.Checked Then
                    cmEmp.CommandText = "select * from py_report where PayDate between '" & _
                        Format(vStartDate, "yyyy/MM/dd") & "' and '" & Format(vEndDate, "yyyy/MM/dd") & _
                        "' and SectionCd='" & rsSection("SectionCd") & "' and DeptCd='" & rs("Dept_Cd") & "' and Ot<>0 " & _
                        vFilter & " order by Name"
                    rsEmp = cmEmp.ExecuteReader
                    Do While rsEmp.Read
                        'get regular overtime
                        GetOT("'A1'", vStartDate, vEndDate, rs("Dept_Cd"), rsSection("SectionCd"), c, _
                            vEmpRegOt, vDummy, vFilter, rsEmp("Emp_Cd"))
                        'get night diff
                        GetOT("'A2','A3','B2','B4','C2','C4','D2','D4','E2','E4','F2','F4'", vStartDate, vEndDate, _
                            rs("Dept_Cd"), rsSection("SectionCd"), c, vEmpND, vDummy, vFilter, rsEmp("Emp_Cd"))
                        'get night diff regular
                        GetOT("'A4','NDREG'", vStartDate, vEndDate, rs("Dept_Cd"), rsSection("SectionCd"), c, _
                            vEmpNDReg, vDummy, vFilter, rsEmp("Emp_Cd"))
                        'get restday
                        GetOT("'E1','E3'", vStartDate, vEndDate, rs("Dept_Cd"), rsSection("SectionCd"), c, _
                            vEmpRest, vDummy, vFilter, rsEmp("Emp_Cd"))
                        'get holiday
                        GetOT("'C1','C3','F1','F3'", vStartDate, vEndDate, rs("Dept_Cd"), rsSection("SectionCd"), c, _
                            vEmpHoliday, vDummy, vFilter, rsEmp("Emp_Cd"))
                        'get holiday on restday
                        GetOT("'B1','B3','D1','D3'", vStartDate, vEndDate, rs("Dept_Cd"), rsSection("SectionCd"), _
                            c, vEmpHolidayRest, vDummy, vFilter, rsEmp("Emp_Cd"))

                        vEmpTotHours = vEmpRegOt + vEmpND + vEmpNDReg + vEmpRest + vEmpHoliday + vEmpHolidayRest
                        With vDump
                            .AppendLine("<tr class='odd'>")
                            .AppendLine("<td class='labelL'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" & rsEmp("Name") & "</td>")
                            .AppendLine("<td class='labelR'>1</td>")
                            .AppendLine("<td class='labelR'>" & IIf(vEmpRegOt = 0, "-", Format(vEmpRegOt, "###,##0.00")) & "</td>")
                            .AppendLine("<td class='labelR'>" & IIf(vEmpRegOt = 0, "-", Format(rsEmp("A1"), "##,###,##0.00")) & "</td>")
                            .AppendLine("<td class='labelR'>" & IIf(vEmpND = 0, "-", Format(vEmpND, "###,##0.00")) & "</td>")
                            .AppendLine("<td class='labelR'>" & IIf(vEmpND = 0, "-", Format(rsEmp("A2") + rsEmp("A3") + rsEmp("B2") + rsEmp("B4") + rsEmp("C2") + rsEmp("C4") + _
                                rsEmp("D2") + rsEmp("D4") + rsEmp("E2") + rsEmp("E4") + rsEmp("F2") + rsEmp("F4"), "##,###,##0.00")) & "</td>")
                            .AppendLine("<td class='labelR'>" & IIf(vEmpRest = 0, "-", Format(vEmpRest, "###,##0.00")) & "</td>")
                            .AppendLine("<td class='labelR'>" & IIf(vEmpRest = 0, "-", Format(rsEmp("E1") + rsEmp("E3"), "##,###,##0.00")) & "</td>")
                            .AppendLine("<td class='labelR'>" & IIf(vEmpHoliday = 0, "-", Format(vEmpHoliday, "###,##0.00")) & "</td>")
                            .AppendLine("<td class='labelR'>" & IIf(vEmpHoliday = 0, "-", Format(rsEmp("C1") + rsEmp("C3") + rsEmp("F1") + rsEmp("F3"), "##,###,##0.00")) & "</td>")
                            .AppendLine("<td class='labelR'>" & IIf(vEmpHolidayRest = 0, "-", Format(vEmpHolidayRest, "###,##0.00")) & "</td>")
                            .AppendLine("<td class='labelR'>" & IIf(vEmpHolidayRest = 0, "-", Format(rsEmp("B1") + rsEmp("B3") + rsEmp("D1") + rsEmp("D3"), "##,###,##0.00")) & "</td>")
                            .AppendLine("<td class='labelR'>" & IIf(vEmpNDReg = 0, "-", Format(vEmpNDReg, "##,###,##0.00")) & "</td>")
                            .AppendLine("<td class='labelR'>" & IIf(vEmpNDReg = 0, "-", Format(rsEmp("A4") + rsEmp("NDREG"), "##,###,##0.00")) & "</td>")
                            .AppendLine("<td class='labelR'>" & IIf(vEmpTotHours = 0, "-", Format(vEmpTotHours, "##,###,##0.00")) & "</td>")
                            .AppendLine("<td class='labelR'>" & IIf(vEmpTotHours = 0, "-", Format(rsEmp("Ot"), "##,###,##0.00")) & "</td>")
                            .AppendLine("</tr>")
                        End With
                    Loop
                    rsEmp.Close()
                End If
                ''''''''''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''''''''''''''''''''
            Loop
            rsSection.Close()
            vDump.Replace("%headcount%", IIf(vDeptHeadCount = 0, "-", Format(vDeptHeadCount, "##,##0")))
            vDump.Replace("%deptothrs%", IIf(vDeptRegOt(0) = 0, "-", Format(vDeptRegOt(0), "###,##0.00")))
            vDump.Replace("%deptotamt%", IIf(vDeptRegOt(1) = 0, "-", Format(vDeptRegOt(1), "##,###,##0.00")))
            vDump.Replace("%deptndhrs%", IIf(vDeptND(0) = 0, "-", Format(vDeptND(0), "###,##0.00")))
            vDump.Replace("%deptndamt%", IIf(vDeptND(1) = 0, "-", Format(vDeptND(1), "##,###,##0.00")))
            vDump.Replace("%deptrestdayhrs%", IIf(vDeptRestDay(0) = 0, "-", Format(vDeptRestDay(0), "###,##0.00")))
            vDump.Replace("%deptrestdayamt%", IIf(vDeptRestDay(1) = 0, "-", Format(vDeptRestDay(1), "##,###,##0.00")))
            vDump.Replace("%deptholidayhrs%", IIf(vDeptHoliday(0) = 0, "-", Format(vDeptHoliday(0), "###,##0.00")))
            vDump.Replace("%deptholidayamt%", IIf(vDeptHoliday(1) = 0, "-", Format(vDeptHoliday(1), "##,###,##0.00")))
            vDump.Replace("%deptholidayresthrs%", IIf(vDeptHolidayRest(0) = 0, "-", Format(vDeptHolidayRest(0), "###,##0.00")))
            vDump.Replace("%deptholidayrestamt%", IIf(vDeptHolidayRest(1) = 0, "-", Format(vDeptHolidayRest(1), "##,###,##0.00")))
            vDump.Replace("%deptndreghrs%", IIf(vDeptNDReg(0) = 0, "-", Format(vDeptNDReg(0), "###,##0.00")))
            vDump.Replace("%deptndregamt%", IIf(vDeptNDReg(1) = 0, "-", Format(vDeptNDReg(1), "###,##0.00")))
            vDump.Replace("%crosstotalhrs%", IIf(vDeptCrossTotal(0) = 0, "-", Format(vDeptCrossTotal(0), "###,##0.00")))
            vDump.Replace("%crosstotalamt%", IIf(vDeptCrossTotal(1) = 0, "-", Format(vDeptCrossTotal(1), "###,##0.00")))
        Loop
        rs.Close()

        With vDump
            .AppendLine("<tr class='activeBar'>")
            .AppendLine("<td class='labelC'><span style='font-weight:bold;'>Grand Total:</span></td>")
            .AppendLine("<td class='labelR'><span style='font-weight:bold;'>" & IIf(vTotHeadCount = 0, "-", Format(vTotHeadCount, "###,##0")) & "</span></td>")
            .AppendLine("<td class='labelR'><span style='font-weight:bold;'>" & IIf(vTotRegOT(0) = 0, "-", Format(vTotRegOT(0), "###,##0.00")) & "</span></td>")
            .AppendLine("<td class='labelR'><span style='font-weight:bold;'>" & IIf(vTotRegOT(1) = 0, "-", Format(vTotRegOT(1), "##,###,##0.00")) & "</span></td>")
            .AppendLine("<td class='labelR'><span style='font-weight:bold;'>" & IIf(vTotND(0) = 0, "-", Format(vTotND(0), "###,##0.00")) & "</span></td>")
            .AppendLine("<td class='labelR'><span style='font-weight:bold;'>" & IIf(vTotND(1) = 0, "-", Format(vTotND(1), "##,###,##0.00")) & "</span></td>")
            .AppendLine("<td class='labelR'><span style='font-weight:bold;'>" & IIf(vTotRest(0) = 0, "-", Format(vTotRest(0), "###,##0.00")) & "</span></td>")
            .AppendLine("<td class='labelR'><span style='font-weight:bold;'>" & IIf(vTotRest(1) = 0, "-", Format(vTotRest(1), "##,###,##0.00")) & "</span></td>")
            .AppendLine("<td class='labelR'><span style='font-weight:bold;'>" & IIf(vTotHoliday(0) = 0, "-", Format(vTotHoliday(0), "###,##0.00")) & "</span></td>")
            .AppendLine("<td class='labelR'><span style='font-weight:bold;'>" & IIf(vTotHoliday(1) = 0, "-", Format(vTotHoliday(1), "##,###,##0.00")) & "</span></td>")
            .AppendLine("<td class='labelR'><span style='font-weight:bold;'>" & IIf(vTotHolidayRest(0) = 0, "-", Format(vTotHolidayRest(0), "###,##0.00")) & "</span></td>")
            .AppendLine("<td class='labelR'><span style='font-weight:bold;'>" & IIf(vTotHolidayRest(1) = 0, "-", Format(vTotHolidayRest(1), "##,###,##0.00")) & "</span></td>")
            .AppendLine("<td class='labelR'><span style='font-weight:bold;'>" & IIf(vTotNDReg(0) = 0, "-", Format(vTotNDReg(0), "##,###,##0.00")) & "</span></td>")
            .AppendLine("<td class='labelR'><span style='font-weight:bold;'>" & IIf(vTotNDReg(1) = 0, "-", Format(vTotNDReg(1), "##,###,##0.00")) & "</span></td>")
            .AppendLine("<td class='labelR'><span style='font-weight:bold;'>" & IIf(vTotCrossTotal(0) = 0, "-", Format(vTotCrossTotal(0), "##,###,##0.00")) & "</span></td>")
            .AppendLine("<td class='labelR'><span style='font-weight:bold;'>" & IIf(vTotCrossTotal(1) = 0, "-", Format(vTotCrossTotal(1), "##,###,##0.00")) & "</span></td>")
            .AppendLine("</tr>")
        End With

        vData = vDump.ToString
        c.Close()
        cm.Dispose()
        cmRef.Dispose()
        cmSection.Dispose()
        cmEmp.Dispose()
        c.Dispose()
        vScript = "document.getElementById('divWait').style.visibility='hidden'"
    End Sub

    Private Sub GetOT(ByVal pCode As String, ByVal vStartDate As Date, ByVal vEndDate As Date, ByVal vDeptCd As String, _
        ByVal vSectionCd As String, ByRef c As SqlClient.SqlConnection, ByRef pHrs As Decimal, ByRef pAmt As Decimal, _
        ByVal pFilter As String, Optional ByVal pEmpCd As String = "")

        Dim cmRef As New SqlClient.SqlCommand
        Dim rsRef As SqlClient.SqlDataReader

        cmRef.Connection = c

        If pEmpCd = "" Then
            cmRef.CommandText = "select sum(Hrs_Rendered) as TotalHrs, sum(AmtConv) as TotalAmt " & _
                " from py_emp_time_log where TranDate between '" & _
                Format(vStartDate, "yyyy/MM/dd") & _
                "' and '" & Format(vEndDate, "yyyy/MM/dd") & "' and TranCd in (" & pCode & ") and exists (" & _
                "select py_report.Emp_Cd from py_report where py_report.Emp_Cd=py_emp_time_log.Emp_Cd and " & _
                "DeptCd='" & vDeptCd & "' and SectionCd='" & vSectionCd & "' and Agency_Cd='" & cmbOffice.SelectedValue & _
                "') and exists (select Emp_Cd from py_emp_master where py_emp_master.Emp_Cd=py_emp_time_log.Emp_Cd " & pFilter & ")"
        Else
            cmRef.CommandText = "select sum(Hrs_Rendered) as TotalHrs, sum(AmtConv) as TotalAmt " & _
                " from py_emp_time_log where Emp_Cd='" & pEmpCd & "' and TranDate between '" & _
                Format(vStartDate, "yyyy/MM/dd") & _
                "' and '" & Format(vEndDate, "yyyy/MM/dd") & "' and TranCd in (" & pCode & ") and exists " & _
                "(select Emp_Cd from py_emp_master where py_emp_master.Emp_Cd=py_emp_time_log.Emp_Cd " & _
                pFilter & ")"
        End If


        rsRef = cmRef.ExecuteReader
        rsRef.Read()

        pHrs = 0 : pAmt = 0
        If Not IsDBNull(rsRef("TotalHrs")) Then
            pHrs = Math.Round(rsRef("TotalHrs"), 2)
            'pAmt = Math.Round(rsRef("TotalAmt"), 2)
        End If
        rsRef.Close()

        If pEmpCd = "" Then
            'get amount from py_report
            Dim vCodes = pCode.Replace("','", "+")
            vCodes = vCodes.ToString.Replace("'", "")

            cmRef.CommandText = "select sum(" & vCodes & ") as TotalAmt from py_report where PayDate between '" & _
                Format(vStartDate, "yyyy/MM/dd") & "' and '" & Format(vEndDate, "yyyy/MM/dd") & "' and DeptCd='" & vDeptCd & _
                "' and SectionCd='" & vSectionCd & "' and Agency_Cd='" & cmbOffice.SelectedValue & "' " & pFilter

            rsRef = cmRef.ExecuteReader
            rsRef.Read()
            If Not IsDBNull(rsRef("TotalAmt")) Then
                pAmt = Math.Round(rsRef("TotalAmt"), 2)
            End If
            rsRef.Close()
        End If

        cmRef.Dispose()
    End Sub
    Private Sub HeadCount(ByRef c As SqlClient.SqlConnection, ByRef pHeadCount As Decimal, ByVal pDeptCd As String, _
        ByVal pSectionCd As String, ByVal pStartDate As Date, ByVal pEndDate As Date, ByVal pFilter As String)

        Dim cmRef As New SqlClient.SqlCommand
        Dim rsRef As SqlClient.SqlDataReader
        cmRef.Connection = c

        cmRef.CommandText = "select count( distinct Emp_Cd) as HeadCount from py_emp_time_log where TranDate between '" & _
            Format(pStartDate, "yyyy/MM/dd") & _
            "' and '" & Format(pEndDate, "yyyy/MM/dd") & "' and " & _
            "TranCd in ('A1','A2','A3','A4','B1','B2','B3','B4','C1','C2','C3','C4','D1','D2','D3','D4'," & _
            "'E1','E2','E3','E4','F1','F2','F3','F4') and AmtConv <> 0 and " & _
            "(EffectivityDate=TranDate or EffectivityDate is null) and  exists (" & _
            "select py_emp_master.Emp_Cd from py_emp_master where py_emp_master.Emp_Cd=py_emp_time_log.Emp_Cd and " & _
            "DeptCd='" & pDeptCd & "' and SectionCd='" & pSectionCd & "') and exists " & _
            "(select Emp_Cd from py_emp_master where py_emp_master.Emp_Cd=py_emp_time_log.Emp_Cd " & pFilter & ")"

        rsRef = cmRef.ExecuteReader
        If rsRef.Read Then
            pHeadCount = 0
            If Not IsDBNull(rsRef("HeadCount")) Then
                pHeadCount = rsRef("HeadCount")
            End If
        End If
        rsRef.Close()
        cmRef.Dispose()
    End Sub

    Protected Sub cmbMonthFrom_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbMonthFrom.SelectedIndexChanged, _
        cmbYearFrom.SelectedIndexChanged

        cmbDayFrom.Items.Clear()
        cmbYearTo.Items.Clear()
        For ictr As Integer = 1 To MonthEND(cmbMonthFrom.SelectedValue & "/1/" & cmbYearFrom.SelectedValue).Day
            cmbDayFrom.Items.Add(ictr)
        Next

        cmbDayFrom.SelectedValue = 1
        cmbYearTo.Items.Add(cmbYearFrom.SelectedValue)
        cmbYearTo.SelectedIndex = 0
    End Sub

    Protected Sub cmbMonthTo_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbMonthTo.SelectedIndexChanged
        cmbDayTo.Items.Clear()

        For ictr As Integer = 1 To MonthEND(cmbMonthTo.SelectedValue & "/1/" & cmbYearTo.SelectedValue).Day
            cmbDayTo.Items.Add(ictr)
        Next
        cmbDayTo.SelectedIndex = cmbDayTo.Items.Count - 1
    End Sub
End Class
