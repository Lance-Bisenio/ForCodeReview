Imports denaro
Partial Class remitdepartment
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Dim c As New sqlclient.sqlconnection
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If

        If Not IsPostBack Then
            If Not CanRun(Session("caption"), Request.Item("id")) Then
                Session("denied") = "1"
                Server.Transfer("main.aspx")
                Exit Sub
            End If

            BuildCombo("select Rc_Cd, Descr from rc where Rc_Cd in ('" & _
                    Session("rclist").ToString.Replace(",", "','") & "') order by Descr ", cmbRC)
            BuildCombo("select AgencyCd,AgencyName from agency where Agencycd in ('" & _
                Session("agencylist").ToString.Replace(",", "','") & "') order by AgencyName", cmbOfc)

            cmbRC.Items.Add("All")
            cmbRC.SelectedValue = "All"
            BuildCombo("select Loan_Cd,Loan_Name from py_loan_ref order by Loan_Name", cmbReport)
            cmbReport.Items.Add(New ListItem("SSS=>SSS Remittance", "SSS"))
            cmbReport.Items.Add(New ListItem("PAGIBIG=>PagIbig Remittance", "PAGIBIG"))
            cmbReport.Items.Add(New ListItem("PHILHEALTH=>Philhealth Remittance", "PHILHEALTH"))
            cmbReport.Items.Add(New ListItem("TAX=>Tax Remittance", "TAX"))
            cmbReport.Items.Add(New ListItem("Employer's Contribution", "EMPLOYER"))
            cmbPayDate.SelectedValue = Now.Month
        End If
    End Sub
    Protected Sub cmdReturn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.Click
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub cmdRefresh_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdRefresh.Click
        DataRefresh()
    End Sub
    Private Sub DataRefresh()
        Dim vFilter As String = ""
        Dim vRptName As String = ""
        Dim vCond As String = ""

        If cmbRC.SelectedValue <> "All" Then   'filter by cost center
            vCond = " and Rc_Cd='" & cmbRC.SelectedValue & "' "
        Else
            vCond = " and Rc_Cd in ('" & Session("rclist").ToString.Replace(",", "','") & "') "
        End If
        If cmbOfc.SelectedValue <> "All" Then        'filter by office/agency
            vCond += " and Agency_Cd='" & cmbOfc.SelectedValue & "' "
        Else
            vCond += " and Agency_Cd in ('" & Session("agencylist").ToString.Replace(",", "','") & "') "
        End If

        Select Case cmbReport.SelectedValue.ToLower
            Case "sss"
                SSS_REMIT_MONTHLY(vCond)
                Exit Select
            Case "philhealth"
                PHILHEALTH_REMITTANCE(vCond)
                Exit Select
            Case "pagibig"
                PAGIBIG_REMITTANCE(vCond)
                Exit Select
            Case "tax"
                TAX_REMITTANCE(vCond)
                Exit Select
            Case "employer"
                EMPLOYER_REPORT(vCond)
                Exit Select
            Case Else
                LOAN_REMITTANCE(cmbReport.SelectedValue.ToLower, vCond)
                Exit Sub
        End Select
    End Sub
    Private Sub EMPLOYER_REPORT(ByVal pCond As String)
        Dim cRef As New sqlclient.sqlconnection(connStr)
        Dim cm As New sqlclient.sqlcommand
        Dim cmRef As New sqlclient.sqlcommand
        Dim dr As sqlclient.sqldatareader
        Dim drRef As sqlclient.sqldatareader
        Dim vCompanyName As String = "Unknown"
        Dim vDescr As String = ""
        Dim iCtr As Integer = 0
        Dim vNo As Integer = 0
        Dim vGov As Integer = 0
        Dim vPer As Integer = 0
        Dim vTot(5) As Decimal
        Dim vOut As String = "<html><body><div align='center'>"

        cRef.Open()
        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c
        cmRef.Connection = cRef
        cm.CommandText = "select AgencyName from agency where AgencyCd='" & cmbOfc.SelectedValue & "'"
        dr = cm.ExecuteReader
        If dr.Read Then
            vCompanyName = IIf(IsDBNull(dr("AgencyName")), Space(60), dr("AgencyName"))
        End If
        dr.Close()

        cm.CommandText = "select Rc_Cd,Agency_Cd,DeptCd,SectionCd, sum(Pagibig_Gov) as PagibigEmr,sum(Sss_Gov) as SssEmr, " & _
            "sum(Medicare_Gov) as PhicEmr, sum(Ec) as E_c from py_report where " & _
            "year(PayDate)=" & Now.Year & " and month(PayDate)=" & cmbPayDate.SelectedValue & pCond & _
            " group by Rc_Cd,Agency_Cd,DeptCd,SectionCd"

        dr = cm.ExecuteReader
        vOut += "<p style='font-size:12pt; font-family:Verdana;'>" & vCompanyName & "<br/>" & _
                "DEPARTMENTALIZED EMPLOYER'S CONTRIBUTION REPORT<br/>" & _
                "for the period " & cmbPayDate.SelectedItem.Text & ", " & Now.Year & "</p>"
        vOut += "<table border='1' cellpadding='0' cellspacing='0' style='border-collapse:collapse; font-size=10pt; font-family:Helvetica;'>" & _
            "<tr><th>Cost Center</th><th>Dept Code</th><th>Description</th><th>Section</th><th>SSS</th><th>EC</th><th>PHIC</th><th>PagIbig</th><th>Total</th></tr>"
        vTot(0) = 0 : vTot(1) = 0 : vTot(2) = 0 : vTot(3) = 0 : vTot(4) = 0
        Do While dr.Read
            cmRef.CommandText = "select Descr from hr_dept_ref where Dept_Cd='" & _
                dr("DeptCd") & "'"
            drRef = cmRef.ExecuteReader
            vDescr = "Not in Reference!"
            If drRef.Read Then
                vDescr = drRef("Descr")
            End If
            drRef.Close()
            vOut += "<tr><td>" & dr("DeptCd") & "</td><td>" & dr("DeptCd") & "</td><td>" & vDescr & "</td><td>" & dr("SectionCd") & "</td><td align='right'>" & _
                Format(dr("SssEmr"), "##,##0.00") & "</td><td align='right'>" & Format(dr("E_c"), "##,##0.00") & _
                "</td><td align='right'>" & Format(dr("PhicEmr"), "##,##0.00") & _
                "<td align='right'>" & Format(dr("PagibigEmr"), "##,##0.00") & _
                "</td><td align='right'>" & Format(dr("PhicEmr") + dr("PagibigEmr") + dr("SssEmr") + dr("E_c"), "##,##0.00") & "</td></tr>"
            vTot(0) += dr("SssEmr")
            vTot(1) += dr("E_c")
            vTot(2) += dr("PhicEmr")
            vTot(3) += dr("PagibigEmr")
            vTot(4) += dr("SssEmr") + dr("PagibigEmr") + dr("PhicEmr") + dr("E_c")
        Loop
        dr.Close()
        cm.Dispose()
        cmRef.Dispose()
        c.Close()
        vOut += "<tr style='font-weight:bold;'><td>&nbsp;</td><td align='right'>Grand Total==></td><td>&nbsp;</td><td align='right'>" & _
            Format(vTot(0), "#,###,##0.00") & "</td><td align='right'>" & _
            Format(vTot(1), "#,###,##0.00") & "</td><td align='right'>" & _
            Format(vTot(2), "#,###,##0.00") & "</td><td align='right'>" & _
            Format(vTot(3), "#,###,##0.00") & "</td><td align='right'>" & _
            Format(vTot(4), "#,###,##0.00") & "</td></tr>" & _
            "</table></div></body></html>"
        If Dir(Server.MapPath(".") & "\downloads\" & Session("sessionid") & "-sharedept.html") <> "" Then
            Kill(Server.MapPath(".") & "\downloads\" & Session("sessionid") & "-sharedept.html")
        End If
        IO.File.WriteAllText(Server.MapPath(".") & "\downloads\" & Session("sessionid") & "-sharedept.html", vOut)
        vScript = "document.getElementById('iframe').src = 'downloads/" & Session("sessionid") & "-sharedept.html';"
        cRef.Close()
        cRef.Dispose()
    End Sub

    Private Sub SSS_REMIT_MONTHLY(ByVal pCond As String)
        Dim cRef As New sqlclient.sqlconnection(connStr)
        Dim cm As New sqlclient.sqlcommand
        Dim cmRef As New sqlclient.sqlcommand
        Dim dr As sqlclient.sqldatareader
        Dim drRef As sqlclient.sqldatareader
        Dim vCompanyName As String = "Unknown"
        Dim vDescr As String = ""
        Dim iCtr As Integer = 0
        Dim vNo As Integer = 0
        Dim vGov As Integer = 0
        Dim vPer As Integer = 0
        Dim vTot(4) As Decimal
        Dim vOut As String = "<html><body><div align='center'>"

        cRef.Open()
        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c
        cmRef.Connection = cRef
        cm.CommandText = "select AgencyName from agency where AgencyCd='" & cmbOfc.SelectedValue & "'"
        dr = cm.ExecuteReader
        If dr.Read Then
            vCompanyName = IIf(IsDBNull(dr("AgencyName")), Space(60), dr("AgencyName"))
        End If
        dr.Close()

        cm.CommandText = "select Rc_Cd,Agency_Cd,DeptCd, sum(Sss_Per) as SssEmp,sum(Sss_Gov) as SssEmr, sum(Ec) as E_c from py_report where " & _
            "year(PayDate)=" & Now.Year & " and month(PayDate)=" & cmbPayDate.SelectedValue & pCond & " group by Rc_Cd,Agency_Cd,DeptCd"

        dr = cm.ExecuteReader
        vOut += "<p style='font-size:12pt; font-family:Verdana;'>" & vCompanyName & "<br/>" & _
                "DEPARTMENTALIZED SSS REMITTANCE REPORT<br/>" & _
                "for the period " & cmbPayDate.SelectedItem.Text & ", " & Now.Year & "</p>"
        vOut += "<table border='1' cellpadding='0' cellspacing='0' style='border-collapse:collapse; font-size=10pt; font-family:Helvetica;'>" & _
            "<tr><th>Cost Center</th><th>Dept Code</th><th>Description</th><th>SSS Emp</th><th>SSS Emr</th><th>EC</th><th>Total</th></tr>"
        vTot(0) = 0 : vTot(1) = 0 : vTot(2) = 0
        Do While dr.Read
            cmRef.CommandText = "select Descr from hr_dept_ref where Dept_Cd='" & _
                dr("DeptCd") & "'"
            drRef = cmRef.ExecuteReader
            vDescr = "Not in Reference!"
            If drRef.Read Then
                vDescr = drRef("Descr")
            End If
            drRef.Close()
            vOut += "<tr><td>" & dr("Rc_Cd") & "</td><td>" & dr("DeptCd") & "</td><td>" & vDescr & "</td><td align='right'>" & _
                Format(dr("SssEmp"), "##,##0.00") & "</td><td align='right'>" & Format(dr("SssEmr"), "##,##0.00") & _
                "</td><td align='right'>" & Format(dr("E_c"), "##,##0.00") & _
                "</td><td align='right'>" & Format(dr("SssEmp") + dr("SssEmr") + dr("E_c"), "##,##0.00") & "</td></tr>"
            vTot(0) += dr("SssEmp")
            vTot(1) += dr("SssEmr")
            vTot(2) += dr("E_c")
            vTot(3) += dr("SssEmp") + dr("SssEmr") + dr("E_c")
        Loop
        dr.Close()
        cm.Dispose()
        cmRef.Dispose()
        c.Close()
        vOut += "<tr style='font-weight:bold;'><td>&nbsp;</td><td align='right'>Grand Total==></td><td align='right'>" & _
            Format(vTot(0), "#,###,##0.00") & "</td><td align='right'>" & _
            Format(vTot(1), "#,###,##0.00") & "</td><td align='right'>" & _
            Format(vTot(2), "#,###,##0.00") & "</td><td align='right'>" & _
            Format(vTot(3), "#,###,##0.00") & "</td></tr>" & _
            "</table></div></body></html>"
        If Dir(Server.MapPath(".") & "\downloads\" & Session("sessionid") & "-sssdept.html") <> "" Then
            Kill(Server.MapPath(".") & "\downloads\" & Session("sessionid") & "-sssdept.html")
        End If
        IO.File.WriteAllText(Server.MapPath(".") & "\downloads\" & Session("sessionid") & "-sssdept.html", vOut)
        vScript = "document.getElementById('iframe').src = 'downloads/" & Session("sessionid") & "-sssdept.html';"
        cRef.Close()
        cRef.Dispose()
    End Sub

    Private Sub LOAN_REMITTANCE(ByVal p_loancd As String, ByVal pCond As String)
        Dim cRef As New sqlclient.sqlconnection(connStr)
        Dim cm As New sqlclient.sqlcommand
        Dim cmRef As New sqlclient.sqlcommand
        Dim dr As sqlclient.sqldatareader
        Dim drRef As sqlclient.sqldatareader
        Dim vCompanyName As String = "Unknown"
        Dim vDescr As String = ""
        Dim iCtr As Integer = 0
        Dim vNo As Integer = 0
        Dim vGov As Integer = 0
        Dim vPer As Integer = 0
        Dim vTot As Decimal = 0
        Dim vIndex As Integer = 0
        Dim vOut As String = "<html><body><div align='center'>"

        cRef.Open()
        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c
        cmRef.Connection = cRef
        cm.CommandText = "select * from py_syscntrl"
        dr = cm.ExecuteReader
        dr.Read()
        vIndex = 0
        For iCtr = 1 To 30
            If Not IsDBNull(dr("OthDed" & iCtr & "Cd")) Then
                If LCase(dr("OthDed" & iCtr & "Cd")) = p_loancd Then
                    vIndex = iCtr
                    Exit For
                End If
            End If
        Next iCtr
        dr.Close()
        cm.CommandText = "select AgencyName from agency where AgencyCd='" & cmbOfc.SelectedValue & "'"
        dr = cm.ExecuteReader
        If dr.Read Then
            vCompanyName = IIf(IsDBNull(dr("AgencyName")), Space(60), dr("AgencyName"))
        End If
        dr.Close()

        cm.CommandText = "select Rc_Cd,Agency_Cd,DeptCd, sum(Other_Deduct" & vIndex & ") as LoanAmt from py_report where " & _
            "year(PayDate)=" & Now.Year & " and month(PayDate)=" & cmbPayDate.SelectedValue & pCond & " group by Rc_Cd,Agency_Cd,DeptCd"

        dr = cm.ExecuteReader
        vOut += "<p style='font-size:12pt; font-family:Verdana;'>" & vCompanyName & "<br/>" & _
                "DEPARTMENTALIZED " & cmbReport.SelectedItem.Text & " REMITTANCE REPORT<br/>" & _
                "for the period of " & cmbPayDate.SelectedItem.Text & ", " & Now.Year & "</p>"
        vOut += "<table border='1' cellpadding='0' cellspacing='0' style='border-collapse:collapse; font-size=10pt; font-family:Helvetica;'>" & _
            "<tr><th>Cost Center</th><th>Dept Code</th><th>Description</th><th>Amount</th></tr>"
        vTot = 0
        Do While dr.Read
            cmRef.CommandText = "select Descr from hr_dept_ref where Dept_Cd='" & _
                dr("DeptCd") & "'"
            drRef = cmRef.ExecuteReader
            vDescr = "Not in Reference!"
            If drRef.Read Then
                vDescr = drRef("Descr")
            End If
            drRef.Close()
            vOut += "<tr><td>" & dr("Rc_Cd") & "</td><td>" & dr("DeptCd") & "</td><td>" & vDescr & "</td><td align='right'>" & _
                Format(dr("LoanAmt"), "##,###,##0.00") & "</td></tr>"
            vTot += dr("LoanAmt")
        Loop
        dr.Close()
        cm.Dispose()
        cmRef.Dispose()
        c.Close()
        vOut += "<tr style='font-weight:bold;'><td>&nbsp;</td><td align='right'>Grand Total==></td><td align='right'>" & _
            Format(vTot, "#,###,##0.00") & "</td></tr>" & _
            "</table></div></body></html>"
        If Dir(Server.MapPath(".") & "\downloads\" & Session("sessionid") & "-" & p_loancd & "dept.html") <> "" Then
            Kill(Server.MapPath(".") & "\downloads\" & Session("sessionid") & "-" & p_loancd & "dept.html")
        End If
        IO.File.WriteAllText(Server.MapPath(".") & "\downloads\" & Session("sessionid") & "-" & p_loancd & "dept.html", vOut)
        vScript = "document.getElementById('iframe').src = 'downloads/" & Session("sessionid") & "-" & p_loancd & "dept.html';"
        cRef.Close()
        cRef.Dispose()
    End Sub

    Private Sub TAX_REMITTANCE(ByVal pCond As String)
        Dim cRef As New sqlclient.sqlconnection(connStr)
        Dim cm As New sqlclient.sqlcommand
        Dim cmRef As New sqlclient.sqlcommand
        Dim dr As sqlclient.sqldatareader
        Dim drRef As sqlclient.sqldatareader
        Dim vCompanyName As String = "Unknown"
        Dim vDescr As String = ""
        Dim iCtr As Integer = 0
        Dim vNo As Integer = 0
        Dim vGov As Integer = 0
        Dim vPer As Integer = 0
        Dim vTot As Decimal = 0
        Dim vOut As String = "<html><body><div align='center'>"

        cRef.Open()
        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c
        cmRef.Connection = cRef
        cm.CommandText = "select AgencyName from agency where AgencyCd='" & cmbOfc.SelectedValue & "'"
        dr = cm.ExecuteReader
        If dr.Read Then
            vCompanyName = IIf(IsDBNull(dr("AgencyName")), Space(60), dr("AgencyName"))
        End If
        dr.Close()

        cm.CommandText = "select Rc_Cd,Agency_Cd,DeptCd, sum(With_Tax) as WTax from py_report where " & _
            "year(PayDate)=" & Now.Year & " and month(PayDate)=" & cmbPayDate.SelectedValue & pCond & " group by Rc_Cd,Agency_Cd,DeptCd"

        dr = cm.ExecuteReader
        vOut += "<p style='font-size:12pt; font-family:Verdana;'>" & vCompanyName & "<br/>" & _
                "DEPARTMENTALIZED WITHHOLDING TAX REMITTANCE REPORT<br/>" & _
                "for the period " & cmbPayDate.SelectedItem.Text & ", " & Now.Year & "</p>"
        vOut += "<table border='1' cellpadding='0' cellspacing='0' style='border-collapse:collapse; font-size=10pt; font-family:Helvetica;'>" & _
            "<tr><th>Cost Center</th><th>Dept Code</th><th>Description</th><th>Withholding Tax</th></tr>"
        vTot = 0
        Do While dr.Read
            cmRef.CommandText = "select Descr from hr_dept_ref where Dept_Cd='" & _
                dr("DeptCd") & "'"
            drRef = cmRef.ExecuteReader
            vDescr = "Not in Reference!"
            If drRef.Read Then
                vDescr = drRef("Descr")
            End If
            drRef.Close()
            vOut += "<tr><td>" & dr("Rc_Cd") & "</td><td>" & dr("DeptCd") & "</td><td>" & vDescr & "</td><td align='right'>" & _
                Format(dr("WTax"), "##,###,##0.00") & "</td></tr>"
            vTot += dr("WTax")
        Loop
        dr.Close()
        cm.Dispose()
        cmRef.Dispose()
        c.Close()
        vOut += "<tr style='font-weight:bold;'><td>&nbsp;</td><td align='right'>Grand Total==></td><td align='right'>" & _
            Format(vTot, "#,###,##0.00") & "</td></tr>" & _
            "</table></div></body></html>"
        If Dir(Server.MapPath(".") & "\downloads\" & Session("sessionid") & "-taxdept.html") <> "" Then
            Kill(Server.MapPath(".") & "\downloads\" & Session("sessionid") & "-taxdept.html")
        End If
        IO.File.WriteAllText(Server.MapPath(".") & "\downloads\" & Session("sessionid") & "-taxdept.html", vOut)
        vScript = "document.getElementById('iframe').src = 'downloads/" & Session("sessionid") & "-taxdept.html';"
        cRef.Close()
        cRef.Dispose()
    End Sub

    Private Sub PHILHEALTH_REMITTANCE(ByVal pCond As String)
        Dim cRef As New sqlclient.sqlconnection(connStr)
        Dim cm As New sqlclient.sqlcommand
        Dim cmRef As New sqlclient.sqlcommand
        Dim dr As sqlclient.sqldatareader
        Dim drRef As sqlclient.sqldatareader
        Dim vCompanyName As String = "Unknown"
        Dim vDescr As String = ""
        Dim iCtr As Integer = 0
        Dim vNo As Integer = 0
        Dim vGov As Integer = 0
        Dim vPer As Integer = 0
        Dim vTot(3) As Decimal
        Dim vOut As String = "<html><body><div align='center'>"

        cRef.Open()
        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c
        cmRef.Connection = cRef
        cm.CommandText = "select AgencyName from agency where AgencyCd='" & cmbOfc.SelectedValue & "'"
        dr = cm.ExecuteReader
        If dr.Read Then
            vCompanyName = IIf(IsDBNull(dr("AgencyName")), Space(60), dr("AgencyName"))
        End If
        dr.Close()

        cm.CommandText = "select Rc_Cd,Agency_Cd,DeptCd, sum(Medicare_Per) as McrEmp,sum(Medicare_Gov) as McrEmr from py_report where " & _
            "year(PayDate)=" & Now.Year & " and month(PayDate)=" & cmbPayDate.SelectedValue & pCond & " group by Rc_Cd,Agency_Cd,DeptCd"

        dr = cm.ExecuteReader
        vOut += "<p style='font-size:12pt; font-family:Verdana;'>" & vCompanyName & "<br/>" & _
                "DEPARTMENTALIZED PHIC REMITTANCE REPORT (BY COST CENTER)<br/>" & _
                "for the period " & cmbPayDate.SelectedItem.Text & ", " & Now.Year & "</p>"
        vOut += "<table border='1' cellpadding='0' cellspacing='0' style='border-collapse:collapse; font-size=10pt; font-family:Helvetica;'>" & _
            "<tr><th>Cost Center</th><th>Dept Code</th><th>Description</th><th>PHIC Emp</th><th>PHIC Emr</th><th>Total</th></tr>"
        vTot(0) = 0 : vTot(1) = 0 : vTot(2) = 0
        Do While dr.Read
            cmRef.CommandText = "select Descr from hr_dept_ref where Dept_Cd='" & _
                dr("DeptCd") & "'"
            drRef = cmRef.ExecuteReader
            vDescr = "Not in Reference!"
            If drRef.Read Then
                vDescr = drRef("Descr")
            End If
            drRef.Close()
            vOut += "<tr><td>" & dr("Rc_Cd") & "</td><td>" & dr("DeptCd") & "</td><td>" & vDescr & "</td><td align='right'>" & _
                Format(dr("McrEmp"), "##,##0.00") & "</td><td align='right'>" & Format(dr("McrEmr"), "##,##0.00") & _
                "</td><td align='right'>" & Format(dr("McrEmp") + dr("McrEmr"), "##,##0.00") & "</td></tr>"
            vTot(0) += dr("McrEmp")
            vTot(1) += dr("McrEmr")
            vTot(2) += dr("McrEmp") + dr("McrEmr")
        Loop
        dr.Close()
        cm.Dispose()
        cmRef.Dispose()
        c.Close()
        vOut += "<tr style='font-weight:bold;'><td>&nbsp;</td><td align='right'>Grand Total==></td><td align='right'>" & _
            Format(vTot(0), "#,###,##0.00") & "</td><td align='right'>" & _
            Format(vTot(1), "#,###,##0.00") & "</td><td align='right'>" & _
            Format(vTot(2), "#,###,##0.00") & "</td></tr>" & _
            "</table></div></body></html>"
        If Dir(Server.MapPath(".") & "\downloads\" & Session("sessionid") & "-phicdept.html") <> "" Then
            Kill(Server.MapPath(".") & "\downloads\" & Session("sessionid") & "-phicdept.html")
        End If
        IO.File.WriteAllText(Server.MapPath(".") & "\downloads\" & Session("sessionid") & "-phicdept.html", vOut)
        vScript = "document.getElementById('iframe').src = 'downloads/" & Session("sessionid") & "-phicdept.html';"
        cRef.Close()
        cRef.Dispose()
    End Sub

    Private Sub PAGIBIG_REMITTANCE(ByVal pCond As String)
        Dim cRef As New sqlclient.sqlconnection(connStr)
        Dim cm As New sqlclient.sqlcommand
        Dim cmRef As New sqlclient.sqlcommand
        Dim dr As sqlclient.sqldatareader
        Dim drRef As sqlclient.sqldatareader
        Dim vCompanyName As String = "Unknown"
        Dim vDescr As String = ""
        Dim iCtr As Integer = 0
        Dim vNo As Integer = 0
        Dim vGov As Integer = 0
        Dim vPer As Integer = 0
        Dim vTot(3) As Decimal
        Dim vOut As String = "<html><body><div align='center'>"

        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c
        cmRef.Connection = c
        cm.CommandText = "select AgencyName from agency where AgencyCd='" & cmbOfc.SelectedValue & "'"
        dr = cm.ExecuteReader
        If dr.Read Then
            vCompanyName = IIf(IsDBNull(dr("AgencyName")), Space(60), dr("AgencyName"))
        End If
        dr.Close()

        cm.CommandText = "select Rc_Cd,Agency_Cd,DeptCd, sum(Pagibig_Per) as PagibigEmp,sum(Pagibig_Gov) as PagibigEmr from py_report where " & _
            "year(PayDate)=" & Now.Year & " and month(PayDate)=" & cmbPayDate.SelectedValue & pCond & " group by Rc_Cd,Agency_Cd,DeptCd"

        dr = cm.ExecuteReader
        vOut += "<p style='font-size:12pt; font-family:Verdana;'>" & vCompanyName & "<br/>" & _
                "DEPARTMENTALIZED PAGIBIG REMITTANCE REPORT<br/>" & _
                "for the period " & cmbPayDate.SelectedItem.Text & ", " & Now.Year & "</p>"
        vOut += "<table border='1' cellpadding='0' cellspacing='0' style='border-collapse:collapse; font-size=10pt; font-family:Helvetica;'>" & _
            "<tr><th>Cost Center</th><th>Dept Code</th><th>Description</th><th>PAGIBIG Emp</th><th>PAGIBIG Emr</th><th>Total</th></tr>"
        vTot(0) = 0 : vTot(1) = 0 : vTot(2) = 0
        Do While dr.Read
            cmRef.CommandText = "select Descr from hr_dept_ref where Dept_Cd='" & _
                dr("DeptCd") & "'"
            drRef = cmRef.ExecuteReader
            vDescr = "Not in Reference!"
            If drRef.Read Then
                vDescr = drRef("Descr")
            End If
            drRef.Close()
            vOut += "<tr><td>" & dr("Rc_Cd") & "</td><td>" & dr("DeptCd") & "</td><td>" & vDescr & "</td><td align='right'>" & _
                Format(dr("PagibigEmp"), "##,##0.00") & "</td><td align='right'>" & Format(dr("PagibigEmr"), "##,##0.00") & _
                "</td><td align='right'>" & Format(dr("PagibigEmp") + dr("PagibigEmr"), "##,##0.00") & "</td></tr>"
            vTot(0) += dr("PagibigEmp")
            vTot(1) += dr("PagibigEmr")
            vTot(2) += dr("PagibigEmp") + dr("PagibigEmr")
        Loop
        dr.Close()
        cm.Dispose()
        cmRef.Dispose()
        c.Close()
        vOut += "<tr style='font-weight:bold;'><td>&nbsp;</td><td align='right'>Grand Total==></td><td align='right'>" & _
            Format(vTot(0), "#,###,##0.00") & "</td><td align='right'>" & _
            Format(vTot(1), "#,###,##0.00") & "</td><td align='right'>" & _
            Format(vTot(2), "#,###,##0.00") & "</td></tr>" & _
            "</table></div></body></html>"
        If Dir(Server.MapPath(".") & "\downloads\" & Session("sessionid") & "-pagibigdept.html") <> "" Then
            Kill(Server.MapPath(".") & "\downloads\" & Session("sessionid") & "-pagibigdept.html")
        End If
        IO.File.WriteAllText(Server.MapPath(".") & "\downloads\" & Session("sessionid") & "-pagibigdept.html", vOut)
        vScript = "document.getElementById('iframe').src = 'downloads/" & Session("sessionid") & "-pagibigdept.html';"
        cRef.Close()
        cRef.Dispose()
    End Sub
End Class
