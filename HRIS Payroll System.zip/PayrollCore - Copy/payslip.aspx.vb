Imports denaro
Partial Class payslip
    Inherits System.Web.UI.Page
    Dim vOTHrs As Single = 0
    Public vSrc As String = ""
    Public vScript As String = ""
    Protected Sub cmdRefresh_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdRefresh.Click
        Select Case rdoPayslipMode.SelectedValue
            Case "payslip"  'vertical payslp (3 payslips in a page)
                GeneratePayslipVer()
            Case "payslip_horizontal"
                GeneratePayslipHorz()
            Case "payslip_multi"
                GeneratePayslipMultiCol()
            Case "payslip_acknowledgement"
                GeneratePayslipAcknowledge()
        End Select
    End Sub
    Private Sub GeneratePayslipAcknowledge()
        Dim c As New SqlClient.SqlConnection(connStr)

        Dim cmRef As New SqlClient.SqlCommand
        Dim cmEmp As New SqlClient.SqlCommand
        Dim cmReport As New SqlClient.SqlCommand
        Dim rsRef As SqlClient.SqlDataReader
        Dim rsEmp As SqlClient.SqlDataReader
        Dim rsReport As SqlClient.SqlDataReader

        Dim vPrn As New VSPrinter8Lib.VSPrinter
        Dim vPDF As New VSPDF8Lib.VSPDF8

        Dim vPageCtr As Integer = 0
        Dim i_loop As Integer
        Dim v_data As String
        Dim v_format As String
        Dim vGross As Decimal
        Dim vOT As Decimal
        Dim vTaxCd As String
        Dim vVL As Single
        Dim vSL As Single
        Dim vEO As Single
        Dim vYTDSal As Decimal
        Dim vYTDTax As Decimal
        Dim vBankCd As String
        Dim vAcctNo As String
        Dim vTotDed As Decimal
        Dim vTotInc As Decimal
        Dim vCompanyName As String = "Unknown"
        Dim vCode As String = ""
        Dim vDaysPerMonth As Decimal = 0
        Dim vIncentName As String = ""
        Dim vRateDay As Decimal = 0
        Dim vPayCd As String = ""
        Dim v_data1 As String = ""
        Dim vCurrentX As Decimal = 0
        Dim vCurrentY As Decimal = 0
        Dim vTmpCurrX As Decimal = 0
        Dim vTmpCurrY As Decimal = 0
        Dim vDummyAmt As Decimal = 0

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cmRef.Dispose()
            cmEmp.Dispose()
            cmReport.Dispose()
            Exit Sub
        End Try

        cmReport.Connection = c
        cmRef.Connection = c
        cmEmp.Connection = c

        cmReport.CommandText = "select Dates_to_Month from py_syscntrl"
        Try
            rsRef = cmReport.ExecuteReader
            If rsRef.Read Then
                vDaysPerMonth = IIf(IsDBNull(rsRef("Dates_to_Month")), 0, rsRef("Dates_to_Month"))
            End If
            rsRef.Close()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to retrieve System Parameter. Error is: " & ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Close()
            c.Dispose()
            cmReport.Dispose()
            cmRef.Dispose()
            cmEmp.Dispose()
            Exit Sub
        End Try

        Dim vFilterEmpCd As String = ""
        If Request.Item("id") <> "" Then
            vFilterEmpCd = " and Emp_Cd= '" & Request.Item("id") & "'"
        End If

        cmReport.CommandText = "select * from py_report " & Session("limit") & " " & vFilterEmpCd & " order by Name"
        rsReport = cmReport.ExecuteReader

        vPrn.Zoom = 75
        vPrn.PaperSize = VSPrinter8Lib.PaperSizeSettings.pprLegal
        vPrn.Footer = "Powered by Evolve Integrated Software Solutions"
        vPrn.Columns = 1
        vPrn.HdrFontSize = 8
        vPrn.HdrFontName = "Arial"
        vPrn.Orientation = VSPrinter8Lib.OrientationSettings.orPortrait

        vPrn.FontSize = 7
        vPrn.MarginTop = OneInch / 8
        vPrn.MarginBottom = OneInch / 8
        vPrn.MarginLeft = OneInch / 8
        vPrn.MarginRight = OneInch / 8
        vPrn.Action = VSPrinter8Lib.ActionSettings.paStartDoc
        Do While rsReport.Read
            vPageCtr += 1
            cmEmp.CommandText = "select Emp_Cd, Tax_Cd,Rate_Month,Rate_Day,Pay_Cd,Rc_Cd,Bank_Code,Acct_No from py_emp_master " & _
                "where Emp_Cd='" & rsReport("Emp_Cd") & "'"
            rsEmp = cmEmp.ExecuteReader
            vTaxCd = "Unknown"
            vBankCd = "Unknown"
            vAcctNo = "Unknown"
            If rsEmp.Read Then
                vTaxCd = IIf(IsDBNull(rsEmp("Tax_Cd")), "Unknown", rsEmp("Tax_Cd"))
                vBankCd = IIf(IsDBNull(rsEmp("Bank_Code")), "Unknown", rsEmp("Bank_Code"))
                vAcctNo = IIf(IsDBNull(rsEmp("Acct_No")), "Unknown", rsEmp("Acct_No"))
                vRateDay = IIf(IsDBNull(rsEmp("Rate_Day")), 0, rsEmp("Rate_Day"))
                vPayCd = IIf(IsDBNull(rsEmp("Pay_Cd")), "SM", rsEmp("Pay_Cd"))
            End If
            rsEmp.Close()

            cmRef.CommandText = "select sum(Month_Rate+Absent+Tardiness+Ot+Rata+Aca+Pera+MealAllow+Other_Incent1+" & _
               "Other_Incent2+Other_Incent3+Other_Incent4+Other_Incent5+Other_Incent6+Other_Incent7+" & _
               "Other_Incent8+Other_Incent9+Other_Incent10+Other_Incent11+Other_Incent12+Other_Incent13+" & _
               "Other_Incent14+Other_Incent15+Other_Incent16+Other_Incent17+Other_Incent18+" & _
               "Other_Incent19+Other_Incent20+Other_Incent21+Other_Incent22+Other_Incent23+" & _
               "Other_Incent24+Other_Incent25+Other_Incent26+Other_Incent27+Other_Incent28+" & _
               "Other_Incent29+Other_Incent30+Other_Incent31+Other_Incent32+Other_Incent33+" & _
               "Other_Incent34+Other_Incent35+Other_Incent36+Other_Incent37+Other_Incent38+" & _
               "Other_Incent39+Other_Incent40+Other_Incent41+Other_Incent42+Other_Incent43+" & _
               "Other_Incent44+Other_Incent45+Other_Incent46+Other_Incent47+Other_Incent48+" & _
               "Other_Incent49+Other_Incent50+Other_Incent51+Other_Incent52+Other_Incent53+" & _
               "Other_Incent54+Other_Incent55+Other_Incent56+Other_Incent57+Other_Incent58+" & _
               "Other_Incent59+Other_Incent60) as YtdSal,sum(With_Tax) AS YtdTax from py_report " & _
               "where Emp_Cd='" & rsReport("Emp_Cd") & _
               "' and year(PayDate)=" & Year(rsReport("PayDate")) & _
               " and PayDate <='" & Format(CDate(rsReport("PayDate")), "yyyy/MM/dd") & "'"

            rsRef = cmRef.ExecuteReader
            vYTDSal = 0
            vYTDTax = 0
            If rsRef.Read Then
                vYTDSal = IIf(IsDBNull(rsRef("YtdSal")), 0, rsRef("YtdSal"))
                vYTDTax = IIf(IsDBNull(rsRef("YtdTax")), 0, rsRef("YtdTax"))
            End If
            rsRef.Close()
            vVL = 0
            vSL = 0
            vEO = 0

            v_format = ""
            cmRef.CommandText = "select Leave_Cd,Balance from py_emp_leave where Emp_Cd='" & rsReport("Emp_Cd") & _
               "' and LEave_Cd in ('VL','SL','EO') order by Leave_Cd"
            rsRef = cmRef.ExecuteReader
            Do While rsRef.Read
                Select Case rsRef("Leave_Cd")
                    Case "VL"
                        vVL = rsRef("Balance")
                    Case "SL"
                        vSL = rsRef("Balance")
                    Case "EO"
                        vEO = rsRef("Balance")
                End Select
            Loop
            rsRef.Close()
            cmRef.CommandText = "select AgencyName from agency where AgencyCd='" & _
                rsReport("Agency_Cd") & "'"
            rsRef = cmRef.ExecuteReader
            vCompanyName = "Unknown -" & rsReport("Agency_Cd")
            If rsRef.Read Then
                vCompanyName = rsReport("Agency_Cd") & "-" & rsRef("AgencyName")
            End If
            rsRef.Close()
            vPrn.FontName = "Arial"
            vPrn.FontSize = 7
            vPrn.FontBold = True
            vPrn.TableBorder = 0
            vPrn.FontUnderline = True
            vPrn.TextAlign = VSPrinter8Lib.TextAlignSettings.taJustMiddle
            v_format = "^6000|^6000;"
            v_data = vCompanyName & "|" & vCompanyName
            vPrn.Table = v_format & v_data
            'vPrn.Paragraph = vCompanyName & vbCrLf
            vPrn.FontUnderline = False
            vPrn.FontBold = False
            vPrn.TextAlign = VSPrinter8Lib.TextAlignSettings.taJustMiddle
            v_format = ">1300|<2000|>1500|<1200|>1300|<2000|>1500|<1200;"
            v_data = "Employee No.:|" & IIf(IsDBNull(rsReport("Emp_Cd")), "", rsReport("Emp_Cd")) & "|||" & _
                     "Employee No.:|" & IIf(IsDBNull(rsReport("Emp_Cd")), "", rsReport("Emp_Cd")) & "||;" & _
              "Employee Name:|" & IIf(IsDBNull(rsReport("Name")), "", rsReport("Name")) & "|Tax Cd:|" & _
               vTaxCd & "|" & _
               "Employee Name:|" & IIf(IsDBNull(rsReport("Name")), "", rsReport("Name")) & "|Tax Cd:|" & _
               vTaxCd & ";"
            If chkLeaveBal.Checked Then   'PRINT LEAVE BALANCES
                v_data1 = "VL Bal:|" & vVL & "|SL Bal:|" & vSL & ";"
                v_data = v_data & "VL Bal:|" & vVL & "|SL Bal:|" & vSL & "|" & v_data1

            End If

            v_data = v_data & "Payroll Period:|" & Format(rsReport("FromDate"), "MM/dd/yyyy") & "-" & _
               Format(rsReport("ToDate"), "MM/dd/yyyy") & "|Pay Date:|" & _
               Format(rsReport("PayDate"), "MM/dd/yyyy") & "|" & _
            "Payroll Period:|" & Format(rsReport("FromDate"), "MM/dd/yyyy") & "-" & _
            Format(rsReport("ToDate"), "MM/dd/yyyy") & "|Pay Date:|" & _
            Format(rsReport("PayDate"), "MM/dd/yyyy") & ";"

            If chkYTDGross.Checked Then
                v_data = v_data & "YTD Gross:|" & Format(vYTDSal, "#,###,##0.00") & _
                   IIf(Not chkYTDTax.Checked, "|||", "|" & "YTD Tax:|" & Format(vYTDTax, "#,###,##0.00")) & _
                "|YTD Gross:|" & Format(vYTDSal, "#,###,##0.00") & _
                   IIf(Not chkYTDTax.Checked, "|||;", "|")
            End If
            If chkYTDTax.Checked Then
                v_data += "YTD Tax:|" & Format(vYTDTax, "#,###,##0.00") & ";;"
            End If
            vPrn.TableBorder = VSPrinter8Lib.TableBorderSettings.tbNone
            vPrn.Table = v_format & v_data

            If chkAnnot.Checked Then    'PRINT ANNOTATIONS
                vPrn.Paragraph = "A deposit in the amount stated below was made to your " & _
                   vBankCd & " Account No. " & vAcctNo & " on " & Format(rsReport("PayDate"), "MM/dd/yyyy") & _
                   " and was properly acknowledged by the bank.  The details of this deposit are as " & _
                   "follows:"
            End If
            'print headers
            v_format = "^6000;"
            v_data = "EARNINGS;"
            vPrn.FontBold = True
            vPrn.TableBorder = VSPrinter8Lib.TableBorderSettings.tbBox
            vPrn.Table = v_format & v_data
            vPrn.FontBold = False

            'get total income
            vTotInc = 0
            For i_loop = 1 To 30
                vTotInc = vTotInc + rsReport("Other_Incent" & i_loop)
            Next i_loop
            vGross = rsReport("Month_Rate") + rsReport("Ot") + rsReport("Absent") + _
               rsReport("Tardiness") + rsReport("Aca") + rsReport("Rata") + rsReport("Pera") + _
               rsReport("MealAllow") + vTotInc

            v_format = "<3750|>1000|>1250;"
            v_data = ""
            'If rsReport("Month_Rate") <> 0 Then
            vDummyAmt = GetOT("'BASIC'", rsReport("FromDate"), rsReport("ToDate"), rsReport("Emp_Cd"), c)
            v_data = v_data & "Basic Pay|" & Format(vOTHrs, "#0.00") & "|" & Format(rsReport("Month_Rate"), "###,##0.00") & ";"
            'End If
            If rsReport("Rata") <> 0 Then
                v_data = v_data & "Transpo Allow||" & Format(rsReport("Rata"), "###,##0.00") & ";"
            End If
            'If rsReport("Aca") <> 0 Then
            vDummyAmt = GetOT("'COLA'", rsReport("FromDate"), rsReport("ToDate"), rsReport("Emp_Cd"), c)
            v_data = v_data & "COLA|" & Format(vOTHrs, "#0.00") & "|" & Format(rsReport("Aca"), "###,##0.00") & ";"
            'End If
            If rsReport("Pera") <> 0 Then
                v_data = v_data & "Temporary/OT Allowance||" & Format(rsReport("Pera"), "###,##0.00") & ";"
            End If
            If rsReport("MealAllow") <> 0 Then
                v_data = v_data & "Meal/Rice Allow||" & Format(rsReport("MealAllow"), "###,##0.00") & ";"
            End If
            'If rsReport("Tardiness") <> 0 Then
            vDummyAmt = GetOT("'TARD','UT'", rsReport("FromDate"), rsReport("ToDate"), rsReport("Emp_Cd"), c)
            vOTHrs = vOTHrs / 8 'convert to days
            v_data = v_data & "Tardy/UT|" & Format(vOTHrs, "#0.00") & "|" & Format(rsReport("Tardiness"), "###,##0.00") & ";"
            'End If
            'If rsReport("Absent") <> 0 Then
            vDummyAmt = GetOT("'ABSENT'", rsReport("FromDate"), rsReport("ToDate"), rsReport("Emp_Cd"), c)
            vOTHrs = vOTHrs / 8 'convert to days
            v_data = v_data & "Absences|" & Format(vOTHrs, "#0.00") & "|" & Format(rsReport("Absent"), "###,##0.00") & ";"
            'End If
            vPrn.Table = v_format & v_data


            'OVERTIME DETAILS
            v_data = "OT TYPE|HRS.|AMOUNT;"
            vPrn.FontBold = True
            vPrn.Table = v_format & v_data
            vPrn.TableBorder = VSPrinter8Lib.TableBorderSettings.tbBoxColumns
            vPrn.FontBold = False
            v_data = ""

            'regular ot
            vOT = GetOT("'A1'", rsReport("FromDate"), rsReport("ToDate"), rsReport("Emp_Cd"), c)
            v_data = v_data & "Reg. OT|" & Format(vOTHrs, "##0.00") & "|" & _
               Format(vOT, "##,##0.00") & ";"

            'regular night differential
            vOT = GetOT("'NDREG','A2','A3','A4','B2','B4','C2','C4','D2','D4','E2','E4','F2','F4'", _
                    rsReport("FromDate"), rsReport("ToDate"), rsReport("Emp_Cd"), c)
            v_data = v_data & "Night Diff.|" & Format(vOTHrs, "##0.00") & "|" & _
                   Format(vOT, "##,##0.00") & ";"

            'rest day
            vOT = GetOT("'E1','E3'", rsReport("FromDate"), rsReport("ToDate"), rsReport("Emp_Cd"), c)
            v_data = v_data & "Restday|" & Format(vOTHrs, "##0.00") & "|" & _
                   Format(vOT, "##,##0.00") & ";"

            'legal Holiday
            vOT = GetOT("'C1','C3','D1','D3'", rsReport("FromDate"), rsReport("ToDate"), rsReport("Emp_Cd"), c)
            v_data = v_data & "Legal|" & Format(vOTHrs, "##0.00") & "|" & _
                   Format(vOT, "##,##0.00") & ";"

            'Special Holiday
            vOT = GetOT("'F1','F3','B1','B3'", rsReport("FromDate"), rsReport("ToDate"), rsReport("Emp_Cd"), c)
            v_data = v_data & "Special|" & Format(vOTHrs, "##0.00") & "|" & _
                   Format(vOT, "##,##0.00") & ";"

            vPrn.Table = v_format & v_data
            'OTHER INCENTIVES

            v_data = "OTH. INCOME||AMOUNT;"
            vPrn.FontBold = True
            vPrn.TableBorder = VSPrinter8Lib.TableBorderSettings.tbBox
            vPrn.Table = v_format & v_data

            vCurrentX = vPrn.CurrentX + 6500
            vCurrentY = vPrn.CurrentY

            vPrn.TableBorder = VSPrinter8Lib.TableBorderSettings.tbBoxColumns
            vPrn.FontBold = False
            v_data = ""

            For i_loop = 1 To 60
                If rsReport("Other_Incent" & i_loop) <> 0 Then
                    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                    '' MODIFIED BY:  VIC GATCHALIAN                               ''
                    '' DATE MODIFIED: 3/7/2012                                    ''
                    '' PURPOSE: TO GET THE NAME AND PUT IT IN VARIABLE AND CHECK  ''
                    ''          WHETHER THE NAME IS CODE 'SL' FOR SICK LEAVE      ''
                    ''          CONVERSION. IF CODE IS 'SL', SYSTEM WILL DISPLAY  ''
                    ''          THE CORRESPONDING NUMBER OF DAYS CONVERTED.       ''
                    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                    '''''''''''''''''''''''''' OLD CODE ''''''''''''''''''''''''''''
                    'v_data = v_data & GetIncentDeductName("OthIncent" & i_loop & "Cd", c) & _
                    '   "||" & Format(rsReport("Other_Incent" & i_loop), "##,##0.00") & ";"
                    ''''''''''''''''''' END OLD CODE '''''''''''''''''''''''''''''''
                    vIncentName = GetIncentDeductName("OthIncent" & i_loop & "Cd", vCode, c)
                    vIncentName = vIncentName.Trim
                    v_data = v_data & vIncentName & "|"
                    If vIncentName = "SL" Then  'show the number of days converted
                        If rsReport("Pay_Cd") = "SM" Then     'employee is semi-monthly, multiply the basicrate by two
                            v_data = v_data & Format(rsReport("Other_Incent" & i_loop) / vRateDay, "##0.00")
                        Else                                  'employee is monthly
                            v_data = v_data & Format(rsReport("Other_Incent" & i_loop) / vRateDay, "##0.00")
                        End If
                    End If
                    v_data = v_data & "|" & Format(rsReport("Other_Incent" & i_loop), "##,##0.00") & ";"
                    ''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''
                End If
            Next i_loop
            vPrn.FontBold = False
            vPrn.TableBorder = VSPrinter8Lib.TableBorderSettings.tbBoxColumns
            vPrn.Table = v_format & v_data

            v_data = "|Gross Pay:|" & Format(vGross, "#,###,##0.00") & ";"
            vPrn.TableBorder = VSPrinter8Lib.TableBorderSettings.tbBox
            vPrn.FontBold = True
            vPrn.Table = v_format & v_data


            vPrn.Table = "^6000;DEDUCTIONS;"
            vPrn.FontBold = False
            vPrn.TableBorder = VSPrinter8Lib.TableBorderSettings.tbBoxColumns

            'DEDUCTIONS
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:  VIC GATCHALIAN                            ''
            '' DATE MODIFIED: 3/2/2012                                 ''
            '' PURPOSE: TO DISPLAY THE DEDUCTED UNION DUES             ''
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            ''''''''''''''''' OLD CODE ''''''''''''''''''''''''''''''''''
            'vTotDed = rsReport("With_Tax") + rsReport("Sss_Per") + _
            '   rsReport("Medicare_Per") + rsReport("PagIbig_Per") + rsReport("Gsis_Per")
            '''''''''''''' END OLD CODE        ''''''''''''''''''''''''''
            vTotDed = rsReport("With_Tax") + rsReport("Sss_Per") + _
               rsReport("Medicare_Per") + rsReport("PagIbig_Per") + _
               rsReport("Gsis_Per") + rsReport("UnionDues")
            '''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''

            For i_loop = 1 To 60
                vTotDed = vTotDed + rsReport("Other_Deduct" & i_loop)
            Next i_loop
            v_data = ""
            'If rsReport("With_Tax") <> 0 Then
            v_data = v_data & "Withholding Tax||" & Format(rsReport("With_Tax"), "##,##0.00") & ";"
            'End If
            'If rsReport("Sss_Per") <> 0 Then
            v_data = v_data & "SSS Cont.||" & Format(rsReport("Sss_Per"), "#,##0.00") & ";"
            'End If
            'If rsReport("Medicare_Per") <> 0 Then
            v_data = v_data & "PhilHealth Cont.||" & Format(rsReport("Medicare_Per"), "#,##0.00") & ";"
            'End If
            'If rsReport("PagIbig_Per") <> 0 Then
            v_data = v_data & "HDMF Cont.||" & Format(rsReport("PagIbig_Per"), "#,##0.00") & ";"
            'End If
            If rsReport("Gsis_Per") <> 0 Then
                v_data = v_data & "GSIS||" & Format(rsReport("Gsis_Per"), "#,##0.00") & ";"
            End If
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:  VIC GATCHALIAN                            ''
            '' DATE MODIFIED: 3/2/2012                                 ''
            '' PURPOSE: TO DISPLAY THE DEDUCTED UNION DUES             ''
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            If rsReport("UnionDues") <> 0 Then
                v_data = v_data & "Union Dues||" & Format(rsReport("UnionDues"), "#,##0.00") & ";"
            End If
            '''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''

            vPrn.Table = v_format & v_data

            'OTHER DEDUCTION DETAILS
            v_data = "LOAN TYPE|BEG. BAL.|AMOUNT;"
            vPrn.FontBold = True
            vPrn.TableBorder = VSPrinter8Lib.TableBorderSettings.tbBox
            vPrn.Table = v_format & v_data
            vPrn.TableBorder = VSPrinter8Lib.TableBorderSettings.tbBoxColumns
            vPrn.FontBold = False
            v_data = ""
            cmRef.CommandText = "select * from py_syscntrl"
            rsRef = cmRef.ExecuteReader
            rsRef.Read()
            For i_loop = 1 To 60
                If rsReport("Other_Deduct" & i_loop) <> 0 Then
                    v_data = v_data & GetIncentDeductName("OthDed" & i_loop & "Cd", vCode, c) & _
                       "|" & IIf(chkLoanBal.Checked, _
                       Format(GetBalance(rsRef("OthDed" & i_loop & "Cd"), rsReport("Emp_Cd"), c), "###,##0.00"), "") & _
                       "|" & Format(rsReport("Other_Deduct" & i_loop), "##,##0.00") & ";"
                End If
            Next i_loop
            rsRef.Close()
            vPrn.Table = v_format & v_data

            vPrn.FontBold = True
            vPrn.TableBorder = VSPrinter8Lib.TableBorderSettings.tbBox
            vPrn.Table = ">4625|>1375;Total Deductions:|" & Format(vTotDed, "#,###,##0.00") & ";"
            vPrn.Table = ">4625|>1375;NET PAY:|" & Format(rsReport("Amount_Per"), "#,###,##0.00") & ";"
            vPrn.FontBold = False

            vTmpCurrX = vPrn.CurrentX
            vTmpCurrY = vPrn.CurrentY

            vPrn.CurrentX = vCurrentX
            vPrn.CurrentY = vCurrentY
            v_format = "<6500|<5500;"
            v_data = "|Received the Amount in Pesos " & Num2Words(rsReport("Amount_Per")) & _
                " (Php " & Format(rsReport("Amount_Per"), "###,##0.00") & ");;;;;" & _
                "|__________________________;|Signature of Employee;"

            vPrn.TableBorder = VSPrinter8Lib.TableBorderSettings.tbNone
            vPrn.Table = v_format & v_data

            vPrn.CurrentX = vTmpCurrX
            vPrn.CurrentY = vTmpCurrY
            vPrn.Paragraph = vbNewLine & StrDup(150, "=") & vbNewLine

            If vPageCtr = 3 Then
                vPrn.CurrentColumn = 1
                vPrn.NewPage()
                vPageCtr = 0
            End If
        Loop
        rsReport.Close()
        cmReport.Dispose()
        cmEmp.Dispose()
        cmRef.Dispose()
        c.Close()
        'cReport.Close()
        'cEmp.Close()
        c.Dispose()
        'cReport.Dispose()
        'cEmp.Dispose()
        vPrn.Action = VSPrinter8Lib.ActionSettings.paEndDoc
        Try
            Kill(Server.MapPath("") & "\downloads\" & Session.SessionID & "-payslip.pdf")
        Catch ex As IO.IOException
        End Try
        vPDF.ConvertDocument(vPrn, Server.MapPath("") & "\downloads\" & Session.SessionID & "-payslip.pdf")
        vSrc = "downloads/" & Session.SessionID & "-payslip.pdf"
        vPrn = Nothing
        vPDF = Nothing
    End Sub
    Private Sub GeneratePayslipMultiCol()
        Dim c As New SqlClient.SqlConnection(connStr)

        Dim cmRef As New SqlClient.SqlCommand
        Dim cmEmp As New SqlClient.SqlCommand
        Dim cmReport As New SqlClient.SqlCommand
        Dim rsRef As SqlClient.SqlDataReader
        Dim rsEmp As SqlClient.SqlDataReader
        Dim rsReport As SqlClient.SqlDataReader

        Dim vPrn As New VSPrinter8Lib.VSPrinter
        Dim vPDF As New VSPDF8Lib.VSPDF8

        Dim vPageCtr As Integer = 0
        Dim i_loop As Integer
        Dim v_data As String
        Dim v_format As String
        Dim vGross As Decimal
        Dim vOT As Decimal
        Dim vTaxCd As String
        Dim vVL As Single
        Dim vSL As Single
        Dim vYTDSal As Decimal
        Dim vYTDTax As Decimal
        Dim vBankCd As String
        Dim vAcctNo As String
        Dim vTotDed As Decimal
        Dim vTotInc As Decimal
        Dim vCompanyName As String = "Unknown"

        c.Open()

        cmReport.Connection = c
        cmRef.Connection = c
        cmEmp.Connection = c
        cmReport.CommandText = "select * from py_report " & Session("limit") & " order by Name"
        rsReport = cmReport.ExecuteReader

        vPrn.Zoom = 75
        vPrn.PaperSize = VSPrinter8Lib.PaperSizeSettings.pprLegal
        vPrn.Footer = "Powered by Evolve Integrated Software Solutions"
        vPrn.Columns = 2
        vPrn.ColumnSpacing = OneInch / 4
        vPrn.PageBorder = VSPrinter8Lib.PageBorderSettings.pbAll
        vPrn.HdrFontSize = 8
        vPrn.HdrFontName = "Arial"
        vPrn.Orientation = VSPrinter8Lib.OrientationSettings.orPortrait

        vPrn.FontSize = 7
        vPrn.MarginTop = OneInch / 8
        vPrn.MarginBottom = OneInch / 8
        vPrn.MarginLeft = OneInch / 8
        vPrn.MarginRight = OneInch / 8
        vPrn.Action = VSPrinter8Lib.ActionSettings.paStartDoc


        Do While rsReport.Read
            vPageCtr += 1
            cmEmp.CommandText = "select Emp_Cd, Tax_Cd,Rate_Month,Pay_Cd,Rc_Cd,Bank_Code,Acct_No from py_emp_master " & _
                "where Emp_Cd='" & rsReport("Emp_Cd") & "'"
            rsEmp = cmEmp.ExecuteReader
            vTaxCd = "Unknown"
            vBankCd = "Unknown"
            vAcctNo = "Unknown"
            If rsEmp.Read Then
                vTaxCd = IIf(IsDBNull(rsEmp("Tax_Cd")), "Unknown", rsEmp("Tax_Cd"))
                vBankCd = IIf(IsDBNull(rsEmp("Bank_Code")), "Unknown", rsEmp("Bank_Code"))
                vAcctNo = IIf(IsDBNull(rsEmp("Acct_No")), "Unknown", rsEmp("Acct_No"))
            End If
            rsEmp.Close()

            cmRef.CommandText = "select sum(Month_Rate+Absent+Tardiness+Ot+Rata+Aca+Pera+MealAllow+Other_Incent1+" & _
               "Other_Incent2+Other_Incent3+Other_Incent4+Other_Incent5+Other_Incent6+Other_Incent7+" & _
               "Other_Incent8+Other_Incent9+Other_Incent10+Other_Incent11+Other_Incent12+Other_Incent13+" & _
               "Other_Incent14+Other_Incent15+Other_Incent16+Other_Incent17+Other_Incent18+" & _
               "Other_Incent19+Other_Incent20+Other_Incent21+Other_Incent22+Other_Incent23+" & _
               "Other_Incent24+Other_Incent25+Other_Incent26+Other_Incent27+Other_Incent28+" & _
               "Other_Incent29+Other_Incent30+Other_Incent31+Other_Incent32+Other_Incent33+" & _
               "Other_Incent34+Other_Incent35+Other_Incent36+Other_Incent37+Other_Incent38+" & _
               "Other_Incent39+Other_Incent40+Other_Incent41+Other_Incent42+Other_Incent43+" & _
               "Other_Incent44+Other_Incent45+Other_Incent46+Other_Incent47+Other_Incent48+" & _
               "Other_Incent49+Other_Incent50+Other_Incent51+Other_Incent52+Other_Incent53+" & _
               "Other_Incent54+Other_Incent55+Other_Incent56+Other_Incent57+Other_Incent58+" & _
               "Other_Incent59+Other_Incent60) as YtdSal,sum(With_Tax) AS YtdTax from py_report " & _
               "where Emp_Cd='" & rsReport("Emp_Cd") & _
               "' and year(PayDate)=" & Year(rsReport("PayDate")) & _
               " and PayDate <='" & Format(CDate(rsReport("PayDate")), "yyyy/MM/dd") & "'"

            rsRef = cmRef.ExecuteReader
            vYTDSal = 0
            vYTDTax = 0
            If rsRef.Read Then
                vYTDSal = IIf(IsDBNull(rsRef("YtdSal")), 0, rsRef("YtdSal"))
                vYTDTax = IIf(IsDBNull(rsRef("YtdTax")), 0, rsRef("YtdTax"))
            End If
            rsRef.Close()
            vVL = 0
            vSL = 0
            v_format = ""
            cmRef.CommandText = "select Leave_Cd,Balance from py_emp_leave where Emp_Cd='" & rsReport("Emp_Cd") & _
               "' and LEave_Cd in ('VL','SL') order by Leave_Cd"
            rsRef = cmRef.ExecuteReader
            Do While rsRef.Read
                Select Case rsRef("Leave_Cd")
                    Case "VL"
                        vVL = rsRef("Balance")
                    Case "SL"
                        vSL = rsRef("Balance")
                End Select
            Loop
            rsRef.Close()
            cmRef.CommandText = "select AgencyName from agency where AgencyCd='" & _
                rsReport("Agency_Cd") & "'"
            rsRef = cmRef.ExecuteReader
            vCompanyName = "Unknown -" & rsReport("Agency_Cd")
            If rsRef.Read Then
                vCompanyName = rsReport("Agency_Cd") & "-" & rsRef("AgencyName")
            End If
            rsRef.Close()
            vPrn.FontName = "Arial"
            vPrn.FontSize = 7
            vPrn.FontBold = True
            vPrn.TableBorder = 0
            vPrn.FontUnderline = True
            vPrn.TextAlign = VSPrinter8Lib.TextAlignSettings.taCenterMiddle
            vPrn.Paragraph = vCompanyName & vbCrLf
            vPrn.FontUnderline = False
            vPrn.FontBold = False
            vPrn.TextAlign = VSPrinter8Lib.TextAlignSettings.taJustMiddle
            v_format = ">1000|<2000|>1000|<1250;"
            v_data = "Employee No.:|" & IIf(IsDBNull(rsReport("Emp_Cd")), "", rsReport("Emp_Cd")) & "||;" & _
               "Employee Name:|" & IIf(IsDBNull(rsReport("Name")), "", rsReport("Name")) & "|Tax Cd:|" & _
               vTaxCd & ";"
            If chkLeaveBal.Checked Then   'PRINT LEAVE BALANCES
                v_data = v_data & "VL Bal:|" & vVL & "|SL Bal:|" & vSL & ";"
            End If
            v_data = v_data & "Payroll Period:|" & Format(rsReport("FromDate"), "MM/dd/yyyy") & "-" & _
               Format(rsReport("ToDate"), "MM/dd/yyyy") & "|Pay Date:|" & _
               Format(rsReport("PayDate"), "MM/dd/yyyy") & ";"

            If chkYTDGross.Checked Then
                v_data = v_data & "YTD Gross:|" & Format(vYTDSal, "#,###,##0.00") & _
                   IIf(Not chkYTDTax.Checked, "||;;", "")
            End If
            If chkYTDTax.Checked Then
                v_data = v_data & IIf(chkYTDGross.Checked, "|", "||") & _
                   "YTD Tax:|" & Format(vYTDTax, "#,###,##0.00") & ";;"
            End If
            vPrn.TableBorder = VSPrinter8Lib.TableBorderSettings.tbNone
            vPrn.Table = v_format & v_data

            If chkAnnot.Checked Then    'PRINT ANNOTATIONS
                vPrn.Paragraph = "A deposit in the amount stated below was made to your " & _
                   vBankCd & " Account No. " & vAcctNo & " on " & Format(rsReport("PayDate"), "MM/dd/yyyy") & _
                   " and was properly acknowledged by the bank.  The details of this deposit are as " & _
                   "follows:"
            End If
            'print headers

            v_format = "^5250;"
            v_data = "EARNINGS;"
            vPrn.FontBold = True
            vPrn.TableBorder = VSPrinter8Lib.TableBorderSettings.tbBox
            vPrn.Table = v_format & v_data
            vPrn.FontBold = False

            'get total income
            vTotInc = 0
            For i_loop = 1 To 30
                vTotInc = vTotInc + rsReport("Other_Incent" & i_loop)
            Next i_loop
            vGross = rsReport("Month_Rate") + rsReport("Ot") + rsReport("Absent") + _
               rsReport("Tardiness") + rsReport("Aca") + rsReport("Rata") + rsReport("Pera") + _
               rsReport("MealAllow") + vTotInc
            v_format = "<3500|>750|>1000;"
            v_data = ""
            If rsReport("Month_Rate") <> 0 Then
                v_data = v_data & "Basic Pay||" & Format(rsReport("Month_Rate"), "###,##0.00") & ";"
            End If
            If rsReport("Rata") <> 0 Then
                v_data = v_data & "Transpo Allow||" & Format(rsReport("Rata"), "###,##0.00") & ";"
            End If
            If rsReport("Aca") <> 0 Then
                v_data = v_data & "ACA||" & Format(rsReport("Aca"), "###,##0.00") & ";"
            End If
            If rsReport("Pera") <> 0 Then
                v_data = v_data & "Temporary/OT Allowance||" & Format(rsReport("Pera"), "###,##0.00") & ";"
            End If
            If rsReport("MealAllow") <> 0 Then
                v_data = v_data & "Meal/Rice Allow||" & Format(rsReport("MealAllow"), "###,##0.00") & ";"
            End If
            If rsReport("Tardiness") <> 0 Then
                v_data = v_data & "Tardiness||" & Format(rsReport("Tardiness"), "###,##0.00") & ";"
            End If
            If rsReport("Absent") <> 0 Then
                v_data = v_data & "Absences||" & Format(rsReport("Absent"), "###,##0.00") & ";"
            End If
            vPrn.Table = v_format & v_data

            'OVERTIME DETAILS
            v_data = "OT TYPE|HRS.|AMOUNT;"
            vPrn.FontBold = True
            vPrn.TableBorder = VSPrinter8Lib.TableBorderSettings.tbBox
            vPrn.Table = v_format & v_data
            vPrn.TableBorder = VSPrinter8Lib.TableBorderSettings.tbBoxColumns
            v_data = ""

            For i_loop = 1 To 2  'get ot regular
                vOT = GetOT("'A" & i_loop & "'", rsReport("FromDate"), rsReport("ToDate"), rsReport("Emp_Cd"), c)
                If vOT <> 0 Then
                    v_data = v_data & GetOTName("A" & i_loop, c) & "|" & _
                       Format(vOTHrs, "##0.00") & "|" & _
                       Format(vOT, "##,##0.00") & ";"
                End If
            Next i_loop
            'regular night differential
            vOT = GetOT("'A4'", rsReport("FromDate"), rsReport("ToDate"), rsReport("Emp_Cd"), c)
            If vOT <> 0 Then
                v_data = v_data & GetOTName("A4", c) & "|" & _
                       Format(vOTHrs, "##0.00") & "|" & _
                       Format(vOT, "##,##0.00") & ";"
            End If

            For i_loop = 1 To 4  'SPECIAL HOLIDAY REST DAY
                vOT = GetOT("'B" & i_loop & "'", rsReport("FromDate"), rsReport("ToDate"), rsReport("Emp_Cd"), c)
                If vOT <> 0 Then
                    v_data = v_data & GetOTName("B" & i_loop, c) & "|" & Format(vOTHrs, "##0.00") & "|" & _
                       Format(vOT, "##,##0.00") & ";"
                End If
            Next i_loop

            For i_loop = 1 To 4  'LEGAL HOLIDAY
                vOT = GetOT("'C" & i_loop & "','G" & i_loop & "'", rsReport("FromDate"), rsReport("ToDate"), rsReport("Emp_Cd"), c)
                If vOT <> 0 Then
                    v_data = v_data & GetOTName("C" & i_loop, c) & "|" & Format(vOTHrs, "##0.00") & "|" & _
                       Format(vOT, "##,##0.00") & ";"
                End If
            Next i_loop

            For i_loop = 1 To 4  'LEGAL HOLIDAY REST DAY
                vOT = GetOT("'D" & i_loop & "'", rsReport("FromDate"), rsReport("ToDate"), rsReport("Emp_Cd"), c)
                If vOT <> 0 Then
                    v_data = v_data & GetOTName("D" & i_loop, c) & "|" & Format(vOTHrs, "##0.00") & "|" & _
                       Format(vOT, "##,##0.00") & ";"
                End If
            Next i_loop

            For i_loop = 1 To 4  'OT REST DAY
                vOT = GetOT("'E" & i_loop & "'", rsReport("FromDate"), rsReport("ToDate"), rsReport("Emp_Cd"), c)
                If vOT <> 0 Then
                    v_data = v_data & GetOTName("E" & i_loop, c) & "|" & Format(vOTHrs, "##0.00") & "|" & _
                       Format(vOT, "##,##0.00") & ";"
                End If
            Next i_loop

            For i_loop = 1 To 4  'SPECIAL HOLIDAY
                vOT = GetOT("'F" & i_loop & "'", rsReport("FromDate"), rsReport("ToDate"), rsReport("Emp_Cd"), c)
                If vOT <> 0 Then
                    v_data = v_data & GetOTName("F" & i_loop, c) & "|" & Format(vOTHrs, "##0.00") & "|" & _
                       Format(vOT, "##,##0.00") & ";"
                End If
            Next i_loop

            'For i_loop = 1 To 4  'OTHERS
            '    vOT = GetOT("'G" & i_loop & "'", rsReport("FromDate"), rsReport("ToDate"), rsReport("Emp_Cd"), c)
            '    If vOT <> 0 Then
            '        v_data = v_data & GetOTName("G" & i_loop, c) & "|" & Format(vOTHrs, "##0.00") & "|" & _
            '           Format(vOT, "##,##0.00") & ";"
            '    End If
            'Next i_loop

            'OTHER INCENTIVES
            For i_loop = 1 To 60
                If rsReport("Other_Incent" & i_loop) <> 0 Then
                    v_data = v_data & GetIncentDeductName("OthIncent" & i_loop & "Cd", rsReport("Other_Incent" & i_loop), c) & _
                       "||" & Format(rsReport("Other_Incent" & i_loop), "##,##0.00") & ";"
                End If
            Next i_loop
            vPrn.FontBold = False
            vPrn.TableBorder = VSPrinter8Lib.TableBorderSettings.tbBoxColumns
            vPrn.Table = v_format & v_data

            v_data = "|Gross Pay:|" & Format(vGross, "#,###,##0.00") & ";"
            vPrn.TableBorder = VSPrinter8Lib.TableBorderSettings.tbBox
            vPrn.FontBold = True
            vPrn.Table = v_format & v_data


            vPrn.Table = "^5250;DEDUCTIONS;"
            vPrn.FontBold = False
            vPrn.TableBorder = VSPrinter8Lib.TableBorderSettings.tbBoxColumns

            'DEDUCTIONS
            vTotDed = rsReport("With_Tax") + rsReport("Sss_Per") + _
               rsReport("Medicare_Per") + rsReport("PagIbig_Per") + rsReport("Gsis_Per")
            For i_loop = 1 To 60
                vTotDed = vTotDed + rsReport("Other_Deduct" & i_loop)
            Next i_loop
            v_data = ""
            If rsReport("With_Tax") <> 0 Then
                v_data = v_data & "Withholding Tax||" & Format(rsReport("With_Tax"), "##,##0.00") & ";"
            End If
            If rsReport("Sss_Per") <> 0 Then
                v_data = v_data & "SSS Cont.||" & Format(rsReport("Sss_Per"), "#,##0.00") & ";"
            End If
            If rsReport("Medicare_Per") <> 0 Then
                v_data = v_data & "PhilHealth Cont.||" & Format(rsReport("Medicare_Per"), "#,##0.00") & ";"
            End If
            If rsReport("PagIbig_Per") <> 0 Then
                v_data = v_data & "HDMF Cont.||" & Format(rsReport("PagIbig_Per"), "#,##0.00") & ";"
            End If
            If rsReport("Gsis_Per") <> 0 Then
                v_data = v_data & "GSIS||" & Format(rsReport("Gsis_Per"), "#,##0.00") & ";"
            End If
            vPrn.Table = v_format & v_data

            'OTHER DEDUCTION DETAILS
            v_data = "LOAN TYPE|BEG. BAL.|AMOUNT;"
            vPrn.FontBold = True
            vPrn.TableBorder = VSPrinter8Lib.TableBorderSettings.tbBox
            vPrn.Table = v_format & v_data
            vPrn.TableBorder = VSPrinter8Lib.TableBorderSettings.tbBoxColumns
            vPrn.FontBold = False
            v_data = ""
            cmRef.CommandText = "select * from py_syscntrl"
            rsRef = cmRef.ExecuteReader
            rsRef.Read()
            For i_loop = 1 To 60
                If rsReport("Other_Deduct" & i_loop) <> 0 Then
                    v_data = v_data & GetIncentDeductName("OthDed" & i_loop & "Cd", rsReport("Other_Deduct" & i_loop), c) & _
                       "|" & IIf(chkLoanBal.Checked, _
                       Format(GetBalance(rsRef("OthDed" & i_loop & "Cd"), rsReport("Emp_Cd"), c), "###,##0.00"), "") & _
                       "|" & Format(rsReport("Other_Deduct" & i_loop), "##,##0.00") & ";"
                End If
            Next i_loop
            rsRef.Close()
            vPrn.Table = v_format & v_data

            vPrn.FontBold = True
            vPrn.TableBorder = VSPrinter8Lib.TableBorderSettings.tbBox
            vPrn.Table = ">4250|>1000;Total Deductions:|" & Format(vTotDed, "#,###,##0.00") & ";"
            vPrn.Table = ">4250|>1000;NET PAY:|" & Format(rsReport("Amount_Per"), "#,###,##0.00") & ";"

            vPrn.FontBold = False
            vPrn.Paragraph = vbCrLf & vbCrLf & "Received By: _________________________" & vbCrLf & vbCrLf & vbCrLf
            If vPageCtr = 3 Then
                vPrn.CurrentColumn = 2
            End If
            If vPageCtr = 6 Then
                vPrn.NewPage()
                vPageCtr = 0
            End If
        Loop
        rsReport.Close()
        cmReport.Dispose()
        cmEmp.Dispose()
        cmRef.Dispose()
        c.Close()
        c.Dispose()
        vPrn.Action = VSPrinter8Lib.ActionSettings.paEndDoc
        Try
            Kill(Server.MapPath("") & "\downloads\" & Session.SessionID & "-payslip.pdf")
        Catch ex As System.Exception
        End Try
        vPDF.ConvertDocument(vPrn, Server.MapPath("") & "\downloads\" & Session.SessionID & "-payslip.pdf")
        vSrc = "downloads/" & Session.SessionID & "-payslip.pdf"
        vPrn = Nothing
        vPDF = Nothing
    End Sub
    Private Sub GeneratePayslipHorz()
        Dim c As New SqlClient.SqlConnection(connStr)

        Dim cmRef As New SqlClient.SqlCommand
        Dim cmEmp As New SqlClient.SqlCommand
        Dim cmReport As New SqlClient.SqlCommand
        Dim rsRef As SqlClient.SqlDataReader
        Dim rsEmp As SqlClient.SqlDataReader
        Dim rsReport As SqlClient.SqlDataReader

        Dim vPrn As New VSPrinter8Lib.VSPrinter
        Dim vPDF As New VSPDF8Lib.VSPDF8
        Dim vWithDetails As String = ""
        Dim vDetails() As String
        Dim vIncentDtl As New Collection
        Dim vIncomeList As New Collection
        Dim vDeductList As New Collection
        Dim vIncentNameList As New Collection
        Dim vDeductNameList As New Collection

        Dim vData() As String

        Dim vMaxCtr As Integer

        Dim vPageCtr As Integer = 0
        Dim i_loop As Integer
        Dim v_data As String
        Dim v_format As String
        Dim vGross As Decimal
        Dim vOT As Decimal
        Dim vTaxCd As String
        Dim vVL As Single
        Dim vSL As Single
        Dim vEO As Single
        Dim vYTDSal As Decimal
        Dim vYTDTax As Decimal
        Dim vBankCd As String
        Dim vAcctNo As String
        Dim vTotDed As Decimal
        Dim vTotInc As Decimal
        Dim vCompanyName As String = "Unknown"
        Dim vUnionFactor As Decimal = 0
        Dim vDaysPerMonth As Decimal = 0
        Dim vIncentName As String = ""
        Dim vRateDay As Decimal = 0
        Dim vMonthRate As Decimal = 0
        Dim vRateMonthly As Decimal = 0
        Dim vPayCd As String = ""
        Dim vSection As String = ""
        Dim vCode As String = ""
     
        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cmRef.Dispose()
            cmEmp.Dispose()
            cmReport.Dispose()
            Exit Sub
        End Try

        cmReport.Connection = c
        cmRef.Connection = c
        cmEmp.Connection = c

        cmReport.CommandText = "select Dates_to_Month from py_syscntrl"
        Try
            rsRef = cmReport.ExecuteReader
            If rsRef.Read Then
                vDaysPerMonth = IIf(IsDBNull(rsRef("Dates_to_Month")), 0, rsRef("Dates_to_Month"))
            End If
            rsRef.Close()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to retrieve System Parameter. Error is: " & ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Close()
            c.Dispose()
            cmReport.Dispose()
            cmRef.Dispose()
            cmEmp.Dispose()
            Exit Sub
        End Try

        Dim vFilterEmpCd As String = ""
        If Request.Item("id") <> "" Then
            vFilterEmpCd = " and Emp_Cd= '" & Request.Item("id") & "'"
        End If

        cmReport.CommandText = "select * from py_report " & Session("limit") & " " & vFilterEmpCd & " order by Name"
        rsReport = cmReport.ExecuteReader

        vPrn.Zoom = 75

        vPrn.PaperSize = VSPrinter8Lib.PaperSizeSettings.pprA4
        vPrn.Footer = "Powered by Evolve Integrated Software Solutions"
        vPrn.Columns = 1
        vPrn.HdrFontSize = 8
        vPrn.HdrFontName = "Arial"
        vPrn.Orientation = VSPrinter8Lib.OrientationSettings.orPortrait

        vPrn.FontSize = 7
        vPrn.MarginTop = OneInch / 8
        vPrn.MarginBottom = OneInch / 8
        vPrn.MarginLeft = OneInch / 8
        vPrn.MarginRight = OneInch / 8
        vPrn.Action = VSPrinter8Lib.ActionSettings.paStartDoc

        Do While rsReport.Read

            vPageCtr += 1

            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY: VIC GATCHALIAN                        ''
            '' DATE MODIFIED: 5/22/2012                           ''
            '' PURPOSE: TO GET THE LAST MONTHLY RATE FOR          ''
            ''          USE IN SPECIAL PAYROLL                    ''
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            cmRef.CommandText = "select TOP 1 Month_Rate,Pay_Cd from py_report where Emp_Cd='" & rsReport("Emp_Cd") & _
                "' and month(PayDate)<=" & CDate(rsReport("PayDate")).Month & _
                " and year(PayDate)=" & CDate(rsReport("PayDate")).Year & _
                " and Month_Rate <> 0 ORDER BY PayDate Desc"
            rsRef = cmRef.ExecuteReader
            If rsRef.Read Then
                If rsRef("Pay_Cd") = "SM" Then
                    vMonthRate = rsRef("Month_Rate") * 2
                Else
                    vMonthRate = rsRef("Month_Rate")
                End If
            End If
            rsRef.Close()
            ''''''''''''' END OF MODIFICATION ''''''''''''''''''''''

            cmEmp.CommandText = "select Emp_Cd, Tax_Cd,Rate_Month,Rate_Day,Pay_Cd,Rc_Cd,Bank_Code,Acct_No from py_emp_master " & _
                "where Emp_Cd='" & rsReport("Emp_Cd") & "'"
            rsEmp = cmEmp.ExecuteReader
            vTaxCd = "Unknown"
            vBankCd = "Unknown"
            vAcctNo = "Unknown"
            If rsEmp.Read Then
                vTaxCd = IIf(IsDBNull(rsEmp("Tax_Cd")), "Unknown", rsEmp("Tax_Cd"))
                vBankCd = IIf(IsDBNull(rsEmp("Bank_Code")), "Unknown", rsEmp("Bank_Code"))
                vAcctNo = IIf(IsDBNull(rsEmp("Acct_No")), "Unknown", rsEmp("Acct_No"))
                vRateDay = IIf(IsDBNull(rsEmp("Rate_Day")), 0, rsEmp("Rate_Day"))
                vPayCd = IIf(IsDBNull(rsEmp("Pay_Cd")), "SM", rsEmp("Pay_Cd"))
            End If
            rsEmp.Close()

            ''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:  VIC GATCHALIAN                     ''
            '' DATE MODIFIED: 3/2/2012                          ''
            '' PURPOSE: TO EXTEND THE SUMMATION OF OTHER        ''
            ''          INCENTIVES FROM 30 TO 60 INDECES.       ''
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''
            ''''''''''''' OLD CODE '''''''''''''''''''''''''''''''
            'cmRef.CommandText = "select sum(Month_Rate+Absent+Tardiness+Ot+Rata+Aca+Pera+MealAllow+Other_Incent1+" & _
            '   "Other_Incent2+Other_Incent3+Other_Incent4+Other_Incent5+Other_Incent6+Other_Incent7+" & _
            '   "Other_Incent8+Other_Incent9+Other_Incent10+Other_Incent11+Other_Incent12+Other_Incent13+" & _
            '   "Other_Incent14+Other_Incent15+Other_Incent16+Other_Incent17+Other_Incent18+" & _
            '   "Other_Incent19+Other_Incent20+Other_Incent21+Other_Incent22+Other_Incent23+" & _
            '   "Other_Incent24+Other_Incent25+Other_Incent26+Other_Incent27+Other_Incent28+" & _
            '   "Other_Incent29+Other_Incent30) as YtdSal,sum(With_Tax) AS YtdTax from py_report " & _
            '   "where Emp_Cd='" & rsReport("Emp_Cd") & _
            '   "' and year(PayDate)=" & Year(rsReport("PayDate")) & _
            '   " and PayDate <='" & Format(CDate(rsReport("PayDate")), "yyyy/MM/dd") & "'"
            ''''''''''''' END OLD CODE '''''''''''''''''''''''''''
            cmRef.CommandText = "select " & _
                "(select Descr from hr_section_ref where hr_section_ref.Section_Cd=py_report.SectionCd) as Section from py_report " & _
               "where Emp_Cd='" & rsReport("Emp_Cd") & "' and year(PayDate)=" & Year(rsReport("PayDate")) & _
               " and PayDate <='" & Format(CDate(rsReport("PayDate")), "yyyy/MM/dd") & "'"
            rsRef = cmRef.ExecuteReader
            If rsRef.Read Then
                vSection = IIf(IsDBNull(rsRef("Section")), "", rsRef("Section"))
            End If
            rsRef.Close()

            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:  VIC GATCHALIAN                                    ''
            '' DATE MODIFIED: 10/5/2012                                        ''
            '' PURPOSE: TO DETERMINE TAXABLE INCOME ONLY AS PART OF THE        ''
            ''          YTDINCOME                                              ''
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            Dim vTaxableInc As New Collection
            Dim vQuery As String = ""

            cmRef.CommandText = "select Incentive_Cd from py_other_incentvs where Taxable=1"
            rsRef = cmRef.ExecuteReader
            Do While rsRef.Read
                vTaxableInc.Add(rsRef("Incentive_Cd"))
            Loop
            rsRef.Close()

            cmRef.CommandText = "select * from py_syscntrl"
            rsRef = cmRef.ExecuteReader
            If rsRef.Read Then
                For iLoop As Integer = 1 To 60
                    For ictr As Integer = 0 To vTaxableInc.Count

                    Next
                Next
            End If
            rsRef.Close()
            ''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''''''

            cmRef.CommandText = "select sum(Month_Rate+Absent+Tardiness+Ot+Rata+Aca+Pera+MealAllow+Other_Incent1+" & _
               "Other_Incent2+Other_Incent3+Other_Incent4+Other_Incent5+Other_Incent6+Other_Incent7+" & _
               "Other_Incent8+Other_Incent9+Other_Incent10+Other_Incent11+Other_Incent12+Other_Incent13+" & _
               "Other_Incent14+Other_Incent15+Other_Incent16+Other_Incent17+Other_Incent18+" & _
               "Other_Incent19+Other_Incent20+Other_Incent21+Other_Incent22+Other_Incent23+" & _
               "Other_Incent24+Other_Incent25+Other_Incent26+Other_Incent27+Other_Incent28+" & _
               "Other_Incent29+Other_Incent30+Other_Incent31+Other_Incent32+Other_Incent33+" & _
               "Other_Incent34+Other_Incent35+Other_Incent36+Other_Incent37+Other_Incent38+" & _
               "Other_Incent39+Other_Incent40+Other_Incent41+Other_Incent42+Other_Incent43+" & _
               "Other_Incent44+Other_Incent45+Other_Incent46+Other_Incent47+Other_Incent48+" & _
               "Other_Incent49+Other_Incent50+Other_Incent51+Other_Incent52+Other_Incent53+" & _
               "Other_Incent54+Other_Incent55+Other_Incent56+Other_Incent57+Other_Incent58+" & _
               "Other_Incent59+Other_Incent60) as YtdSal,sum(With_Tax) AS YtdTax from py_report " & _
               "where Emp_Cd='" & rsReport("Emp_Cd") & _
               "' and year(PayDate)=" & Year(rsReport("PayDate")) & _
               " and PayDate <='" & Format(CDate(rsReport("PayDate")), "yyyy/MM/dd") & "'"
            ''''''''''''' END OF MODIFICATION ''''''''''''''''''''

            rsRef = cmRef.ExecuteReader
            vYTDSal = 0
            vYTDTax = 0
            If rsRef.Read Then
                vYTDSal = IIf(IsDBNull(rsRef("YtdSal")), 0, rsRef("YtdSal"))
                vYTDTax = IIf(IsDBNull(rsRef("YtdTax")), 0, rsRef("YtdTax"))
            End If
            rsRef.Close()
            vVL = 0
            vSL = 0
            vEO = 0
            v_format = ""
            cmRef.CommandText = "select Leave_Cd,Balance from py_emp_leave where Emp_Cd='" & rsReport("Emp_Cd") & _
               "' and LEave_Cd in ('VL','SL','EO') order by Leave_Cd"
            rsRef = cmRef.ExecuteReader
            Do While rsRef.Read
                Select Case rsRef("Leave_Cd")
                    Case "VL"
                        vVL = rsRef("Balance")
                    Case "SL"
                        vSL = rsRef("Balance")
                    Case "EO"
                        vEO = rsRef("Balance")
                End Select
            Loop
            rsRef.Close()
            cmRef.CommandText = "select AgencyName from agency where AgencyCd='" & _
                rsReport("Agency_Cd") & "'"
            rsRef = cmRef.ExecuteReader
            vCompanyName = "Unknown -" & rsReport("Agency_Cd")
            If rsRef.Read Then
                vCompanyName = rsReport("Agency_Cd") & "-" & rsRef("AgencyName")
            End If
            rsRef.Close()
            vPrn.FontName = "Arial"
            vPrn.FontSize = 7
            vPrn.FontBold = True
            vPrn.TableBorder = 0
            vPrn.FontUnderline = True
            vPrn.TextAlign = VSPrinter8Lib.TextAlignSettings.taCenterMiddle
            vPrn.Paragraph = vCompanyName & vbCrLf
            vPrn.FontUnderline = False
            vPrn.FontBold = False
            vPrn.TextAlign = VSPrinter8Lib.TextAlignSettings.taJustMiddle
            v_format = ">1300|<2000|>1500|<2000|>1500|<2700;"
            'v_format = ">1000|<2000|>1000|<1250;"

            If rsReport("Pay_Cd") = "SM" Then
                vRateMonthly = rsReport("BasicRate") * 2
            Else
                vRateMonthly = rsReport("BasicRate")
            End If

            v_data = "Employee No.:|" & IIf(IsDBNull(rsReport("Emp_Cd")), "", rsReport("Emp_Cd")) & _
                "|Monthly Rate:|" & Format(IIf(vRateMonthly = 0, vMonthRate, vRateMonthly), "###,##0.00") & "|"

            If chkLeaveBal.Checked Then   'PRINT V LEAVE BALANCES
                v_data = v_data & "VL Bal:|" & vVL
            End If
            v_data = v_data & ";"

            v_data = v_data & "Employee Name:|" & IIf(IsDBNull(rsReport("Name")), "", rsReport("Name")) & _
                "|Tax Cd:|" & vTaxCd & "|"
            If chkLeaveBal.Checked Then   'PRINT S LEAVE BALANCES
                v_data = v_data & "SL Bal:|" & vSL
            End If
            v_data = v_data & ";"

            v_data = v_data & "Section:|" & vSection & "|"
            If chkYTDGross.Checked Then
                v_data = v_data & "YTD Gross:|" & Format(vYTDSal, "#,###,##0.00") & _
                   IIf(Not chkYTDTax.Checked, "|", "|")
            End If
            v_data = v_data & "Extra off:| " & vEO & ";"

            v_data = v_data & "Payroll Period:|" & Format(rsReport("FromDate"), "MM/dd/yyyy") & "-" & _
               Format(rsReport("ToDate"), "MM/dd/yyyy") & ""
            If chkYTDTax.Checked Then
                v_data = v_data & IIf(chkYTDGross.Checked, "|", "|") & _
                   "YTD Tax:|" & Format(vYTDTax, "#,###,##0.00") & ""
            End If
            v_data = v_data & ";"


            v_data = v_data & "Pay Date:|" & _
               Format(rsReport("PayDate"), "MM/dd/yyyy") & ";;"

            vPrn.TableBorder = VSPrinter8Lib.TableBorderSettings.tbNone
            vPrn.Table = v_format & v_data

            If chkAnnot.Checked Then    'PRINT ANNOTATIONS
                vPrn.Paragraph = "A deposit in the amount stated below was made to your " & _
                   vBankCd & " Account No. " & vAcctNo & " on " & Format(rsReport("PayDate"), "MM/dd/yyyy") & _
                   " and was properly acknowledged by the bank.  The details of this deposit are as " & _
                   "follows:"
            End If
            'print headers
            v_format = "^5500|^5800;"
            'v_format = "^5250;"
            v_data = "EARNINGS|DEDUCTIONS;"
            vPrn.FontBold = True
            vPrn.TableBorder = VSPrinter8Lib.TableBorderSettings.tbAll
            vPrn.Table = v_format & v_data
            vPrn.FontBold = False

            'get total income
            vTotInc = 0
            For i_loop = 1 To 60
                vTotInc = vTotInc + rsReport("Other_Incent" & i_loop)
            Next i_loop
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:  VIC GATCHALIAN                              ''
            '' DATE MODIFIED: 5/21/2012                                  ''
            '' PURPOSE: TO ADD THE SENIORITY ALLOWANCE                   ''
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            ''''''''''''''''''' OLD CODE ''''''''''''''''''''''''''''''''''
            'vGross = rsReport("Month_Rate") + rsReport("Ot") + rsReport("Absent") + _
            '   rsReport("Tardiness") + rsReport("Aca") + rsReport("Rata") + rsReport("Pera") + _
            '   rsReport("MealAllow") + vTotInc
            ''''''''''''''''''' END OLD CODE ''''''''''''''''''''''''''''''
            vGross = rsReport("Month_Rate") + rsReport("Ot") + rsReport("Absent") + _
               rsReport("Tardiness") + rsReport("Aca") + rsReport("Rata") + rsReport("Pera") + _
               rsReport("MealAllow") + rsReport("SeniorAllowance") + vTotInc
            ''''''''''''''''''' END OF MODIFICATION  ''''''''''''''''''''''
            v_format = "<3500|>1000|>1000|<3500|>1300|>1000;"

            vDeductList.Clear()
            vIncomeList.Clear()
            vIncentNameList.Clear()
            vDeductNameList.Clear()

            If rsReport("Month_Rate") <> 0 Then
                vIncomeList.Add(rsReport("Month_Rate"), "Basic Pay")
                vIncentNameList.Add("Basic Pay")
            End If
            If rsReport("Rata") <> 0 Then
                vIncomeList.Add(rsReport("Rata"), "Transpo Allow")
                vIncentNameList.Add("Transpo Allow")
            End If
            If rsReport("Aca") <> 0 Then
                vIncomeList.Add(rsReport("Aca"), "E-COLA")
                vIncentNameList.Add("E-COLA")
            End If
            If rsReport("Pera") <> 0 Then
                vIncomeList.Add(rsReport("Pera"), "Temporary/OT Allowance")
                vIncentNameList.Add("Temporary/OT Allowance")
            End If
            If rsReport("MealAllow") <> 0 Then
                vIncomeList.Add(rsReport("MealAllow"), "Meal/Rice Allow")
                vIncentNameList.Add("Meal/Rice Allow")
            End If
            If rsReport("SeniorAllowance") <> 0 Then
                vIncomeList.Add(rsReport("SeniorAllowance"), "Seniority Allowance")
                vIncentNameList.Add("Seniority Allowance")
            End If
            If rsReport("Tardiness") <> 0 Then
                vOT = GetOT("'TARD','UT'", rsReport("FromDate"), rsReport("ToDate"), rsReport("Emp_Cd"), c)
                vIncomeList.Add(vOTHrs & "~" & rsReport("Tardiness"), "Tardiness/UT")
                vIncentNameList.Add("Tardiness/UT")
            End If
            If rsReport("Absent") <> 0 Then
                vOT = GetOT("'ABSENT'", rsReport("FromDate"), rsReport("ToDate"), rsReport("Emp_Cd"), c)
                'v_data = v_data & "Absences||" & Format(rsReport("Absent"), "###,##0.00") & ";"
                vIncomeList.Add(vOTHrs & "~" & rsReport("Absent"), "Absences")
                vIncentNameList.Add("Absences")
            End If

            'vPrn.Table = v_format & v_data

            'OVERTIME DETAILS
            'v_data = "OT TYPE|HRS.|AMOUNT;"
            vIncomeList.Add("OT TYPE|HRS.|AMOUNT", "OT TYPE|HRS.|AMOUNT")
            vIncentNameList.Add("OT TYPE|HRS.|AMOUNT")
            'vPrn.FontBold = True
            'vPrn.Table = v_format & v_data
            'vPrn.TableBorder = VSPrinter8Lib.TableBorderSettings.tbBoxColumns
            'vPrn.FontBold = False
            'v_data = ""

            'get ot regular
            If rsReport("A1") <> 0 Then
                vOT = GetOT("'A1'", rsReport("FromDate"), rsReport("ToDate"), rsReport("Emp_Cd"), c)
                If vOT <> 0 Then
                    'v_data = v_data & GetOTName("A" & i_loop, c) & "|" & _
                    '   Format(vOTHrs, "##0.00") & "|" & _
                    '   Format(vOT, "##,##0.00") & ";"
                    v_data = GetOTName("A1", c)
                    vIncomeList.Add(vOTHrs & "~" & vOT, v_data)
                    vIncentNameList.Add(v_data)
                End If
            End If

            'regular night differential
            If rsReport("NDReg") <> 0 Then
                vOT = GetOT("'A2','A3','A4'", rsReport("FromDate"), rsReport("ToDate"), rsReport("Emp_Cd"), c)
                If vOT <> 0 Then
                    'v_data = v_data & GetOTName("NDREG", c) & "|" & _
                    '       Format(vOTHrs, "##0.00") & "|" & _
                    '       Format(vOT, "##,##0.00") & ";"
                    v_data = GetOTName("A4", c)
                    vIncomeList.Add(vOTHrs & "~" & vOT, v_data)
                    vIncentNameList.Add(v_data)
                End If
            End If

            For i_loop = 1 To 4  'SPECIAL HOLIDAY REST DAY
                If rsReport("B" & i_loop) Then
                    vOT = GetOT("'B" & i_loop & "'", rsReport("FromDate"), rsReport("ToDate"), rsReport("Emp_Cd"), c)
                    If vOT <> 0 Then
                        'v_data = v_data & GetOTName("B" & i_loop, c) & "|" & Format(vOTHrs, "##0.00") & "|" & _
                        '   Format(vOT, "##,##0.00") & ";"
                        v_data = GetOTName("B" & i_loop, c)
                        vIncomeList.Add(vOTHrs & "~" & vOT, v_data)
                        vIncentNameList.Add(v_data)
                    End If
                End If
            Next i_loop

            For i_loop = 1 To 4  'LEGAL HOLIDAY
                If rsReport("C" & i_loop) <> 0 Then
                    vOT = GetOT("'C" & i_loop & "','G" & i_loop & "'", rsReport("FromDate"), rsReport("ToDate"), rsReport("Emp_Cd"), c)
                    If vOT <> 0 Then
                        'v_data = v_data & GetOTName("C" & i_loop, c) & "|" & Format(vOTHrs, "##0.00") & "|" & _
                        '   Format(vOT, "##,##0.00") & ";"
                        v_data = GetOTName("C" & i_loop, c)
                        vIncomeList.Add(vOTHrs & "~" & vOT, v_data)
                        vIncentNameList.Add(v_data)
                    End If
                End If
            Next i_loop

            For i_loop = 1 To 4  'LEGAL HOLIDAY REST DAY
                If rsReport("D" & i_loop) <> 0 Then
                    vOT = GetOT("'D" & i_loop & "'", rsReport("FromDate"), rsReport("ToDate"), rsReport("Emp_Cd"), c)
                    If vOT <> 0 Then
                        'v_data = v_data & GetOTName("D" & i_loop, c) & "|" & Format(vOTHrs, "##0.00") & "|" & _
                        '   Format(vOT, "##,##0.00") & ";"
                        v_data = GetOTName("D" & i_loop, c)
                        vIncomeList.Add(vOTHrs & "~" & vOT, v_data)
                        vIncentNameList.Add(v_data)
                    End If
                End If
            Next i_loop

            For i_loop = 1 To 4  'OT REST DAY
                If rsReport("E" & i_loop) <> 0 Then
                    vOT = GetOT("'E" & i_loop & "'", rsReport("FromDate"), rsReport("ToDate"), rsReport("Emp_Cd"), c)
                    If vOT <> 0 Then
                        'v_data = v_data & GetOTName("E" & i_loop, c) & "|" & Format(vOTHrs, "##0.00") & "|" & _
                        '   Format(vOT, "##,##0.00") & ";"
                        v_data = GetOTName("E" & i_loop, c)
                        vIncomeList.Add(vOTHrs & "~" & vOT, v_data)
                        vIncentNameList.Add(v_data)
                    End If
                End If
            Next i_loop

            For i_loop = 1 To 4  'SPECIAL HOLIDAY
                If rsReport("F" & i_loop) Then
                    vOT = GetOT("'F" & i_loop & "'", rsReport("FromDate"), rsReport("ToDate"), rsReport("Emp_Cd"), c)
                    If vOT <> 0 Then
                        'v_data = v_data & GetOTName("F" & i_loop, c) & "|" & Format(vOTHrs, "##0.00") & "|" & _
                        '   Format(vOT, "##,##0.00") & ";"
                        v_data = GetOTName("F" & i_loop, c)
                        vIncomeList.Add(vOTHrs & "~" & vOT, v_data)
                        vIncentNameList.Add(v_data)
                    End If
                End If
            Next i_loop

            For i_loop = 1 To 4  'OTHERS
                If rsReport("G" & i_loop) Then
                    vOT = GetOT("'G" & i_loop & "'", rsReport("FromDate"), rsReport("ToDate"), rsReport("Emp_Cd"), c)
                    If vOT <> 0 Then
                        'v_data = v_data & GetOTName("G" & i_loop, c) & "|" & Format(vOTHrs, "##0.00") & "|" & _
                        '   Format(vOT, "##,##0.00") & ";"
                        v_data = GetOTName("G" & i_loop, c)
                        vIncomeList.Add(vOTHrs & "~" & vOT, v_data)
                        vIncentNameList.Add(v_data)
                    End If
                End If
            Next i_loop

            'vPrn.Table = v_format & v_data
            'OTHER INCENTIVES

            'v_data = "OTH. INCOME|DAYS|AMOUNT;"
            vIncomeList.Add("OTH. INCOME||AMOUNT", "OTH. INCOME||AMOUNT")
            vIncentNameList.Add("OTH. INCOME||AMOUNT")
            'vPrn.FontBold = True
            'vPrn.TableBorder = VSPrinter8Lib.TableBorderSettings.tbBox
            'vPrn.Table = v_format & v_data
            'vPrn.TableBorder = VSPrinter8Lib.TableBorderSettings.tbBoxColumns
            'vPrn.FontBold = False
            'v_data = ""
            vWithDetails = ""

            For i_loop = 1 To 60
                If rsReport("Other_Incent" & i_loop) <> 0 Then
                    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                    '' MODIFIED BY:  VIC GATCHALIAN                               ''
                    '' DATE MODIFIED: 3/7/2012                                    ''
                    '' PURPOSE: TO GET THE NAME AND PUT IT IN VARIABLE AND CHECK  ''
                    ''          WHETHER THE NAME IS CODE 'SL' FOR SICK LEAVE      ''
                    ''          CONVERSION. IF CODE IS 'SL', SYSTEM WILL DISPLAY  ''
                    ''          THE CORRESPONDING NUMBER OF DAYS CONVERTED.       ''
                    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                    '''''''''''''''''''''''''' OLD CODE ''''''''''''''''''''''''''''
                    'v_data = v_data & GetIncentDeductName("OthIncent" & i_loop & "Cd", c) & _
                    '   "||" & Format(rsReport("Other_Incent" & i_loop), "##,##0.00") & ";"
                    ''''''''''''''''''' END OLD CODE '''''''''''''''''''''''''''''''
                    vIncentName = GetIncentDeductName("OthIncent" & i_loop & "Cd", vCode, c).Trim

                    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                    '' MODIFIED BY:  VIC GATCHALIAN                               ''
                    '' DATE MODIFIED: 4/15/2012                                   ''
                    '' PURPOSE: TO DISPLAY THE NUMBER OF HOURS WORKED/CREDITED    ''
                    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

                    'cmRef.CommandText = "select HrsWorked,UnitAmt from py_incentives_dtl where " & _
                    '            "Incentive_Cd='" & vCode & "' and Emp_Cd='" & rsReport("Emp_Cd") & "' and ToDate='" & _
                    '            Format(CDate(rsReport("ToDate")), "yyyy/MM/dd") & "'"
                    cmRef.CommandText = "select * from py_incentives_dtl where " & _
                        "Incentive_Cd='" & vCode & "' and Emp_Cd='" & rsReport("Emp_Cd") & "' and FromDate between '" & _
                        Format(CDate(rsReport("FromDate")), "yyyy/MM/dd") & "' and '" & _
                        Format(CDate(rsReport("ToDate")), "yyyy/MM/dd") & "'"
                    rsRef = cmRef.ExecuteReader
                    Dim vHrsRendered As Decimal = 0
                    Dim vUnitAmt As Decimal = 0
                    Dim vAbsentHr As Decimal = 0
                    Dim vAbsentAmt As Decimal = 0
                    Dim vTardyHr As Decimal = 0
                    Dim vTardyAmt As Decimal = 0
                    Dim vUTHr As Decimal = 0
                    Dim vUTAmt As Decimal = 0
                    Dim vString As String = ""


                    Do While rsRef.Read
                        vHrsRendered += rsRef("HrsWorked")
                        vUnitAmt = rsRef("UnitAmt")
                        vAbsentHr = rsRef("AbsentHr")
                        vAbsentAmt = rsRef("AbsentAmt")
                        vTardyHr = rsRef("TardyHr")
                        vTardyAmt = rsRef("TardyAmt")
                        vUTAmt = rsRef("UTAmt")
                        vUTHr = rsRef("UTHr")
                        If vAbsentHr <> 0 Or vTardyHr <> 0 Or vUTHr <> 0 Then
                            If Not IsDBNull(rsRef("EndDate")) Then
                                vString = Format(rsRef("EndDate"), "MM/dd/yyyy")
                            Else
                                vString = Format(rsRef("FromDate"), "MM/dd/yyyy")
                            End If
                            vString = vString & "=" & _
                                vHrsRendered + vAbsentHr + vTardyHr + vUTHr & " * " & vUnitAmt / 8 & "=" & _
                                Format((vHrsRendered + vAbsentHr + vTardyHr + vUTHr) * (vUnitAmt / 8), "##,##0.00") & vbNewLine & _
                                "Less: Absences (" & vUnitAmt / 8 & " * " & vAbsentHr & ")=" & vAbsentAmt & vbNewLine & _
                                "      Tardiness: (" & vUnitAmt / 8 & " * " & vTardyHr & ")=" & vTardyAmt & vbNewLine & _
                                "      Undertime: (" & vUnitAmt / 8 & " * " & vUTHr & ")=" & vUTAmt & vbNewLine
                            vIncentDtl.Add(vString, vIncentName)
                            vWithDetails += vIncentName & ","
                        End If
                    Loop
                    rsRef.Close()
                    If vWithDetails <> "" Then
                        vWithDetails = Mid(vWithDetails, 1, Len(vWithDetails) - 1)
                    End If

                    '''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''

                    'v_data = v_data & vIncentName & "|"
                    'If vIncentName = "SL" Then  'show the number of days converted
                    '    If rsReport("Pay_Cd") = "SM" Then     'employee is semi-monthly, multiply the basicrate by two
                    '        v_data = v_data & Format(rsReport("Other_Incent" & i_loop) / vRateDay, "##0.00")
                    '    Else                                  'employee is monthly
                    '        v_data = v_data & Format(rsReport("Other_Incent" & i_loop) / vRateDay, "##0.00")
                    '    End If
                    'End If
                    'v_data = v_data & "|" & Format(rsReport("Other_Incent" & i_loop), "##,##0.00") & ";"
                    ''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''
                    If vHrsRendered <> 0 Then
                        vIncomeList.Add(vHrsRendered & "~" & rsReport("Other_Incent" & i_loop), vIncentName)
                    Else
                        vIncomeList.Add(rsReport("Other_Incent" & i_loop), vIncentName)
                    End If

                    vIncentNameList.Add(vIncentName)
                End If
            Next i_loop
            'vPrn.FontBold = False
            'vPrn.TableBorder = VSPrinter8Lib.TableBorderSettings.tbBoxColumns
            'vPrn.Table = v_format & v_data

            'v_data = "|Gross Pay:|" & Format(vGross, "#,###,##0.00") & ";"
            vIncomeList.Add(vGross, "Gross Pay")
            vIncentNameList.Add("Gross Pay")
            'vPrn.TableBorder = VSPrinter8Lib.TableBorderSettings.tbBox
            'vPrn.FontBold = True
            'vPrn.Table = v_format & v_data


            'vPrn.Table = "^6000;DEDUCTIONS;"
            'vPrn.FontBold = False
            'vPrn.TableBorder = VSPrinter8Lib.TableBorderSettings.tbBoxColumns

            'DEDUCTIONS
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:  VIC GATCHALIAN                            ''
            '' DATE MODIFIED: 3/2/2012                                 ''
            '' PURPOSE: TO DISPLAY THE DEDUCTED UNION DUES             ''
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            ''''''''''''''''' OLD CODE ''''''''''''''''''''''''''''''''''
            'vTotDed = rsReport("With_Tax") + rsReport("Sss_Per") + _
            '   rsReport("Medicare_Per") + rsReport("PagIbig_Per") + rsReport("Gsis_Per")
            '''''''''''''' END OLD CODE        ''''''''''''''''''''''''''
            vTotDed = rsReport("With_Tax") + rsReport("Sss_Per") + _
               rsReport("Medicare_Per") + rsReport("PagIbig_Per") + _
               rsReport("Gsis_Per") + rsReport("UnionDues")
            '''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''

            For i_loop = 1 To 60
                vTotDed = vTotDed + rsReport("Other_Deduct" & i_loop)
            Next i_loop
            v_data = ""
            If rsReport("With_Tax") <> 0 Then
                'v_data = v_data & "Withholding Tax||" & Format(rsReport("With_Tax"), "##,##0.00") & ";"
                vDeductList.Add(rsReport("With_Tax"), "Withholding Tax")
                vDeductNameList.Add("Withholding Tax")
            End If
            If rsReport("Sss_Per") <> 0 Then
                'v_data = v_data & "SSS Cont.||" & Format(rsReport("Sss_Per"), "#,##0.00") & ";"
                vDeductList.Add(rsReport("Sss_Per"), "SSS Cont.")
                vDeductNameList.Add("SSS Cont.")
            End If
            If rsReport("Medicare_Per") <> 0 Then
                'v_data = v_data & "PhilHealth Cont.||" & Format(rsReport("Medicare_Per"), "#,##0.00") & ";"
                vDeductList.Add(rsReport("Medicare_Per"), "PhilHealth Cont.")
                vDeductNameList.Add("PhilHealth Cont.")
            End If
            If rsReport("PagIbig_Per") <> 0 Then
                'v_data = v_data & "HDMF Cont.||" & Format(rsReport("PagIbig_Per"), "#,##0.00") & ";"
                vDeductList.Add(rsReport("PagIbig_Per"), "HDMF Cont.")
                vDeductNameList.Add("HDMF Cont.")
            End If
            If rsReport("Gsis_Per") <> 0 Then
                'v_data = v_data & "GSIS||" & Format(rsReport("Gsis_Per"), "#,##0.00") & ";"
                vDeductList.Add(rsReport("Gsis_Per"), "GSIS")
                vDeductNameList.Add("GSIS")
            End If
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:  VIC GATCHALIAN                            ''
            '' DATE MODIFIED: 3/2/2012                                 ''
            '' PURPOSE: TO DISPLAY THE DEDUCTED UNION DUES             ''
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            If rsReport("UnionDues") <> 0 Then

                'v_data = v_data & "Union Dues||" & Format(rsReport("UnionDues"), "#,##0.00") & ";"
                vDeductList.Add(rsReport("UnionDues"), "Union Dues")
                vDeductNameList.Add("Union Dues")
            End If
            '''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''

            'vPrn.Table = v_format & v_data

            'OTHER DEDUCTION DETAILS
            'v_data = "LOAN TYPE|BEG. BAL.|AMOUNT;"
            vDeductList.Add("LOAN TYPE|BEG. BAL|AMOUNT", "LOAN TYPE|BEG. BAL|AMOUNT")
            vDeductNameList.Add("LOAN TYPE|BEG. BAL|AMOUNT")

            'vPrn.FontBold = True
            'vPrn.TableBorder = VSPrinter8Lib.TableBorderSettings.tbBox
            'vPrn.Table = v_format & v_data
            'vPrn.TableBorder = VSPrinter8Lib.TableBorderSettings.tbBoxColumns
            'vPrn.FontBold = False
            'v_data = ""
            cmRef.CommandText = "select * from py_syscntrl"
            rsRef = cmRef.ExecuteReader
            rsRef.Read()
            For i_loop = 1 To 60
                If rsReport("Other_Deduct" & i_loop) <> 0 Then
                    'v_data = v_data & GetIncentDeductName("OthDed" & i_loop & "Cd", c) & _
                    '   "|" & IIf(chkLoanBal.Checked, _
                    '   Format(GetBalance(rsRef("OthDed" & i_loop & "Cd"), rsReport("Emp_Cd"), c), "###,##0.00"), "") & _
                    '   "|" & Format(rsReport("Other_Deduct" & i_loop), "##,##0.00") & ";"
                    v_data = GetIncentDeductName("OthDed" & i_loop & "Cd", vCode, c)
                    vDeductList.Add(GetBalance(rsRef("OthDed" & i_loop & "Cd"), rsReport("Emp_Cd"), c) & "~" & _
                        rsReport("Other_Deduct" & i_loop), v_data)
                    vDeductNameList.Add(v_data)
                End If
            Next i_loop
            rsRef.Close()
            'vPrn.Table = v_format & v_data

            'vPrn.FontBold = True
            'vPrn.TableBorder = VSPrinter8Lib.TableBorderSettings.tbBox
            'vPrn.Table = ">4625|>1375;Total Deductions:|" & Format(vTotDed, "#,###,##0.00") & ";"
            vDeductList.Add(vTotDed, "Total Deductions")
            vDeductNameList.Add("Total Deductions")

            vDeductList.Add(rsReport("Amount_Per"), "NET PAY")
            vDeductNameList.Add("NET PAY")
            'vPrn.Table = ">4625|>1375;NET PAY:|" & Format(rsReport("Amount_Per"), "#,###,##0.00") & ";"

            'vPrn.Table = ">4250|>1000;Total Deductions:|" & Format(vTotDed, "#,###,##0.00") & ";"
            'vPrn.Table = ">4250|>1000;NET PAY:|" & Format(rsReport("Amount_Per"), "#,###,##0.00") & ";"

            'vPrn.FontBold = False
            'vPrn.Paragraph = vbCrLf & vbCrLf & "Received By: ________________________" & vbCrLf & vbCrLf & vbCrLf
            'If vPageCtr = 3 Then
            'vPrn.CurrentColumn = 1
            'End If
            'If vPageCtr = 3 Then
            '    vPrn.NewPage()
            '    vPageCtr = 0
            'End If
            vMaxCtr = Math.Max(vIncomeList.Count, vDeductList.Count)

            vDetails = vWithDetails.Split(",")

            For i_loop = 1 To vMaxCtr
                v_data = ""
                If i_loop <= vIncomeList.Count Then
                    If vIncomeList(i_loop).ToString.Contains("~") Then
                        vData = vIncomeList(i_loop).ToString.Split("~")
                        v_data = vIncentNameList(i_loop)
                        For ictr As Integer = 0 To UBound(vDetails)
                            If vDetails(ictr) = vIncentNameList(i_loop) Then
                                v_data += vbCrLf & vIncentDtl(vIncentNameList(i_loop))
                            End If
                        Next

                        v_data += "|" & Format(Val(vData(0)), "##,##0.00") & " |" & Format(Val(vData(1)), "###,##0.00")
                    Else
                        If Not IsNumeric(vIncomeList(i_loop)) Then
                            v_data += vIncomeList(i_loop)
                        Else
                            v_data = vIncentNameList(i_loop) & "||" & Format(Val(vIncomeList(i_loop)), "###,##0.00")
                        End If
                    End If
                Else
                    v_data = "||"
                End If
                If i_loop <= vDeductList.Count Then

                    If vDeductList(i_loop).ToString.Contains("~") Then
                        vData = vDeductList(i_loop).ToString.Split("~")
                        v_data += "|" & vDeductNameList(i_loop) & "|" & _
                            IIf(chkLoanBal.Checked, Format(Val(vData(0)), "#,###,##0.00"), "") & _
                            "|" & Format(Val(vData(1)), "###,##0.00") & ";"
                    Else
                        If Not IsNumeric(vDeductList(i_loop)) Then
                            v_data += "|" & vDeductNameList(i_loop) & ";"
                        Else
                            v_data += "|" & vDeductNameList(i_loop) & "||" & Format(Val(vDeductList(i_loop)), "###,##0.00") & ";"
                        End If

                    End If
                Else
                    v_data += "||;"
                End If
                vPrn.Table = v_format & v_data
            Next
            vPrn.Paragraph = vbCrLf & StrDup(253, "-") & vbCrLf & vbCrLf
            If vPageCtr = 3 Then
                vPrn.NewPage()
                vPageCtr = 0
            End If
        Loop
        rsReport.Close()
        cmReport.Dispose()
        cmEmp.Dispose()
        cmRef.Dispose()
        c.Close()
        c.Dispose()


        vPrn.Action = VSPrinter8Lib.ActionSettings.paEndDoc
        Try
            Kill(Server.MapPath("") & "\downloads\" & Session.SessionID & "-payslip.pdf")
        Catch ex As IO.IOException
        End Try
        vPDF.ConvertDocument(vPrn, Server.MapPath("") & "\downloads\" & Session.SessionID & "-payslip.pdf")
        vSrc = "downloads/" & Session.SessionID & "-payslip.pdf"
        vPrn = Nothing
        vPDF = Nothing
    End Sub

    Private Sub GeneratePayslipVer()
        Dim c As New SqlClient.SqlConnection(connStr)
        'Dim cEmp As New SqlClient.SqlConnection(connStr)
        'Dim cReport As New SqlClient.SqlConnection(connStr)

        Dim cmRef As New SqlClient.SqlCommand
        Dim cmEmp As New SqlClient.SqlCommand
        Dim cmReport As New SqlClient.SqlCommand
        Dim rsRef As SqlClient.SqlDataReader
        Dim rsEmp As SqlClient.SqlDataReader
        Dim rsReport As SqlClient.SqlDataReader

        Dim vPrn As New VSPrinter8Lib.VSPrinter
        Dim vPDF As New VSPDF8Lib.VSPDF8

        Dim vPageCtr As Integer = 0
        Dim i_loop As Integer
        Dim v_data As String
        Dim v_format As String
        Dim vGross As Decimal
        Dim vOT As Decimal
        Dim vTaxCd As String
        Dim vVL As Single
        Dim vSL As Single
        Dim vEO As Single
        Dim vYTDSal As Decimal
        Dim vYTDTax As Decimal
        Dim vBankCd As String
        Dim vAcctNo As String
        Dim vTotDed As Decimal
        Dim vTotInc As Decimal
        Dim vCompanyName As String = "Unknown"
        Dim vCode As String = ""
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                          ''
        '' DATE MODIFIED: 3/7/2012                               ''
        '' PURPOSE: TO GET THE NUMBER OF DAYS IN A MONTH SO THAT ''
        ''          YOU CAN DERIVE THE DAILY RATE CALCULATED ON  ''
        ''          THE SPECIFIED PAYROLL PERIOD.                ''
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        Dim vDaysPerMonth As Decimal = 0
        Dim vIncentName As String = ""
        Dim vRateDay As Decimal = 0
        Dim vPayCd As String = ""
        '''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cmRef.Dispose()
            cmEmp.Dispose()
            cmReport.Dispose()
            Exit Sub
        End Try

        cmReport.Connection = c
        cmRef.Connection = c
        cmEmp.Connection = c

        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' DATE MODIFIED: 3/7/2012                               ''
        '' PURPOSE: TO RETRIEVE THE NUMBER OF DAYS IN A MONTH    ''
        ''          AND STORE IT IN THE VARIABLE DECLARED ABOVE. ''
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        cmReport.CommandText = "select Dates_to_Month from py_syscntrl"
        Try
            rsRef = cmReport.ExecuteReader
            If rsRef.Read Then
                vDaysPerMonth = IIf(IsDBNull(rsRef("Dates_to_Month")), 0, rsRef("Dates_to_Month"))
            End If
            rsRef.Close()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to retrieve System Parameter. Error is: " & ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Close()
            c.Dispose()
            cmReport.Dispose()
            cmRef.Dispose()
            cmEmp.Dispose()
            Exit Sub
        End Try
        '''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''

        Dim vFilterEmpCd As String = ""
        If Request.Item("id") <> "" Then
            vFilterEmpCd = " and Emp_Cd= '" & Request.Item("id") & "'"
        End If

        cmReport.CommandText = "select * from py_report " & Session("limit") & " " & vFilterEmpCd & " order by Name"
        'Response.Write(cmReport.CommandText)
        rsReport = cmReport.ExecuteReader

        vPrn.Zoom = 75
        'vPrn.PaperSize = VSPrinter8Lib.PaperSizeSettings.pprB4
        vPrn.PaperSize = VSPrinter8Lib.PaperSizeSettings.pprLegal
        vPrn.Footer = "Powered by Evolve Integrated Software Solutions"
        vPrn.Columns = 1
        vPrn.HdrFontSize = 8
        vPrn.HdrFontName = "Arial"
        vPrn.Orientation = VSPrinter8Lib.OrientationSettings.orPortrait

        vPrn.FontSize = 7
        vPrn.MarginTop = OneInch / 8
        vPrn.MarginBottom = OneInch / 8
        vPrn.MarginLeft = OneInch / 8
        vPrn.MarginRight = OneInch / 8
        vPrn.Action = VSPrinter8Lib.ActionSettings.paStartDoc
        Do While rsReport.Read
            vPageCtr += 1
            cmEmp.CommandText = "select Emp_Cd, Tax_Cd,Rate_Month,Rate_Day,Pay_Cd,Rc_Cd,Bank_Code,Acct_No from py_emp_master " & _
                "where Emp_Cd='" & rsReport("Emp_Cd") & "'"
            rsEmp = cmEmp.ExecuteReader
            vTaxCd = "Unknown"
            vBankCd = "Unknown"
            vAcctNo = "Unknown"
            If rsEmp.Read Then
                vTaxCd = IIf(IsDBNull(rsEmp("Tax_Cd")), "Unknown", rsEmp("Tax_Cd"))
                vBankCd = IIf(IsDBNull(rsEmp("Bank_Code")), "Unknown", rsEmp("Bank_Code"))
                vAcctNo = IIf(IsDBNull(rsEmp("Acct_No")), "Unknown", rsEmp("Acct_No"))
                vRateDay = IIf(IsDBNull(rsEmp("Rate_Day")), 0, rsEmp("Rate_Day"))
                vPayCd = IIf(IsDBNull(rsEmp("Pay_Cd")), "SM", rsEmp("Pay_Cd"))
            End If
            rsEmp.Close()

            ''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:  VIC GATCHALIAN                     ''
            '' DATE MODIFIED: 3/2/2012                          ''
            '' PURPOSE: TO EXTEND THE SUMMATION OF OTHER        ''
            ''          INCENTIVES FROM 30 TO 60 INDECES.       ''
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''
            ''''''''''''' OLD CODE '''''''''''''''''''''''''''''''
            'cmRef.CommandText = "select sum(Month_Rate+Absent+Tardiness+Ot+Rata+Aca+Pera+MealAllow+Other_Incent1+" & _
            '   "Other_Incent2+Other_Incent3+Other_Incent4+Other_Incent5+Other_Incent6+Other_Incent7+" & _
            '   "Other_Incent8+Other_Incent9+Other_Incent10+Other_Incent11+Other_Incent12+Other_Incent13+" & _
            '   "Other_Incent14+Other_Incent15+Other_Incent16+Other_Incent17+Other_Incent18+" & _
            '   "Other_Incent19+Other_Incent20+Other_Incent21+Other_Incent22+Other_Incent23+" & _
            '   "Other_Incent24+Other_Incent25+Other_Incent26+Other_Incent27+Other_Incent28+" & _
            '   "Other_Incent29+Other_Incent30) as YtdSal,sum(With_Tax) AS YtdTax from py_report " & _
            '   "where Emp_Cd='" & rsReport("Emp_Cd") & _
            '   "' and year(PayDate)=" & Year(rsReport("PayDate")) & _
            '   " and PayDate <='" & Format(CDate(rsReport("PayDate")), "yyyy/MM/dd") & "'"
            ''''''''''''' END OLD CODE '''''''''''''''''''''''''''
            cmRef.CommandText = "select sum(Month_Rate+Absent+Tardiness+Ot+Rata+Aca+Pera+MealAllow+Other_Incent1+" & _
               "Other_Incent2+Other_Incent3+Other_Incent4+Other_Incent5+Other_Incent6+Other_Incent7+" & _
               "Other_Incent8+Other_Incent9+Other_Incent10+Other_Incent11+Other_Incent12+Other_Incent13+" & _
               "Other_Incent14+Other_Incent15+Other_Incent16+Other_Incent17+Other_Incent18+" & _
               "Other_Incent19+Other_Incent20+Other_Incent21+Other_Incent22+Other_Incent23+" & _
               "Other_Incent24+Other_Incent25+Other_Incent26+Other_Incent27+Other_Incent28+" & _
               "Other_Incent29+Other_Incent30+Other_Incent31+Other_Incent32+Other_Incent33+" & _
               "Other_Incent34+Other_Incent35+Other_Incent36+Other_Incent37+Other_Incent38+" & _
               "Other_Incent39+Other_Incent40+Other_Incent41+Other_Incent42+Other_Incent43+" & _
               "Other_Incent44+Other_Incent45+Other_Incent46+Other_Incent47+Other_Incent48+" & _
               "Other_Incent49+Other_Incent50+Other_Incent51+Other_Incent52+Other_Incent53+" & _
               "Other_Incent54+Other_Incent55+Other_Incent56+Other_Incent57+Other_Incent58+" & _
               "Other_Incent59+Other_Incent60) as YtdSal,sum(With_Tax) AS YtdTax from py_report " & _
               "where Emp_Cd='" & rsReport("Emp_Cd") & _
               "' and year(PayDate)=" & Year(rsReport("PayDate")) & _
               " and PayDate <='" & Format(CDate(rsReport("PayDate")), "yyyy/MM/dd") & "'"
            ''''''''''''' END OF MODIFICATION ''''''''''''''''''''

            rsRef = cmRef.ExecuteReader
            vYTDSal = 0
            vYTDTax = 0
            If rsRef.Read Then
                vYTDSal = IIf(IsDBNull(rsRef("YtdSal")), 0, rsRef("YtdSal"))
                vYTDTax = IIf(IsDBNull(rsRef("YtdTax")), 0, rsRef("YtdTax"))
            End If
            rsRef.Close()
            vVL = 0
            vSL = 0
            vEO = 0

            v_format = ""
            cmRef.CommandText = "select Leave_Cd,Balance from py_emp_leave where Emp_Cd='" & rsReport("Emp_Cd") & _
               "' and LEave_Cd in ('VL','SL','EO') order by Leave_Cd"
            rsRef = cmRef.ExecuteReader
            Do While rsRef.Read
                Select Case rsRef("Leave_Cd")
                    Case "VL"
                        vVL = rsRef("Balance")
                    Case "SL"
                        vSL = rsRef("Balance")
                    Case "EO"
                        vEO = rsRef("Balance")
                End Select
            Loop
            rsRef.Close()
            cmRef.CommandText = "select AgencyName from agency where AgencyCd='" & _
                rsReport("Agency_Cd") & "'"
            rsRef = cmRef.ExecuteReader
            vCompanyName = "Unknown -" & rsReport("Agency_Cd")
            If rsRef.Read Then
                vCompanyName = rsReport("Agency_Cd") & "-" & rsRef("AgencyName")
            End If
            rsRef.Close()
            vPrn.FontName = "Arial"
            vPrn.FontSize = 7
            vPrn.FontBold = True
            vPrn.TableBorder = 0
            vPrn.FontUnderline = True
            vPrn.TextAlign = VSPrinter8Lib.TextAlignSettings.taCenterMiddle
            vPrn.Paragraph = vCompanyName & vbCrLf
            vPrn.FontUnderline = False
            vPrn.FontBold = False
            vPrn.TextAlign = VSPrinter8Lib.TextAlignSettings.taJustMiddle
            v_format = ">1300|<2000|>1500|<15000;"
            'v_format = ">1000|<2000|>1000|<1250;"
            v_data = "Employee No.:|" & IIf(IsDBNull(rsReport("Emp_Cd")), "", rsReport("Emp_Cd")) & "||;" & _
               "Employee Name:|" & IIf(IsDBNull(rsReport("Name")), "", rsReport("Name")) & "|Tax Cd:|" & _
               vTaxCd & ";"
            If chkLeaveBal.Checked Then   'PRINT LEAVE BALANCES
                v_data = v_data & "VL Bal:|" & vVL & "|SL Bal:|" & vSL & ";"
            End If
            v_data = v_data & "Payroll Period:|" & Format(rsReport("FromDate"), "MM/dd/yyyy") & "-" & _
               Format(rsReport("ToDate"), "MM/dd/yyyy") & "|Pay Date:|" & _
               Format(rsReport("PayDate"), "MM/dd/yyyy") & ";"

            If chkYTDGross.Checked Then
                v_data = v_data & "YTD Gross:|" & Format(vYTDSal, "#,###,##0.00") & _
                   IIf(Not chkYTDTax.Checked, "||;;", "")
            End If
            If chkYTDTax.Checked Then
                v_data = v_data & IIf(chkYTDGross.Checked, "|", "||") & _
                   "YTD Tax:|" & Format(vYTDTax, "#,###,##0.00") & ";;"
            End If
            vPrn.TableBorder = VSPrinter8Lib.TableBorderSettings.tbNone
            vPrn.Table = v_format & v_data

            If chkAnnot.Checked Then    'PRINT ANNOTATIONS
                vPrn.Paragraph = "A deposit in the amount stated below was made to your " & _
                   vBankCd & " Account No. " & vAcctNo & " on " & Format(rsReport("PayDate"), "MM/dd/yyyy") & _
                   " and was properly acknowledged by the bank.  The details of this deposit are as " & _
                   "follows:"
            End If
            'print headers
            v_format = "^6000;"
            'v_format = "^5250;"
            v_data = "EARNINGS;"
            vPrn.FontBold = True
            vPrn.TableBorder = VSPrinter8Lib.TableBorderSettings.tbBox
            vPrn.Table = v_format & v_data
            vPrn.FontBold = False

            'get total income
            vTotInc = 0
            For i_loop = 1 To 30
                vTotInc = vTotInc + rsReport("Other_Incent" & i_loop)
            Next i_loop
            vGross = rsReport("Month_Rate") + rsReport("Ot") + rsReport("Absent") + _
               rsReport("Tardiness") + rsReport("Aca") + rsReport("Rata") + rsReport("Pera") + _
               rsReport("MealAllow") + vTotInc

            v_format = "<3750|>1000|>1250;"
            v_data = ""
            If rsReport("Month_Rate") <> 0 Then
                v_data = v_data & "Basic Pay||" & Format(rsReport("Month_Rate"), "###,##0.00") & ";"
            End If
            If rsReport("Rata") <> 0 Then
                v_data = v_data & "Transpo Allow||" & Format(rsReport("Rata"), "###,##0.00") & ";"
            End If
            If rsReport("Aca") <> 0 Then
                v_data = v_data & "ACA||" & Format(rsReport("Aca"), "###,##0.00") & ";"
            End If
            If rsReport("Pera") <> 0 Then
                v_data = v_data & "Temporary/OT Allowance||" & Format(rsReport("Pera"), "###,##0.00") & ";"
            End If
            If rsReport("MealAllow") <> 0 Then
                v_data = v_data & "Meal/Rice Allow||" & Format(rsReport("MealAllow"), "###,##0.00") & ";"
            End If
            If rsReport("Tardiness") <> 0 Then
                v_data = v_data & "Tardiness||" & Format(rsReport("Tardiness"), "###,##0.00") & ";"
            End If
            If rsReport("Absent") <> 0 Then
                v_data = v_data & "Absences||" & Format(rsReport("Absent"), "###,##0.00") & ";"
            End If
            vPrn.Table = v_format & v_data


            'OVERTIME DETAILS
            v_data = "OT TYPE|HRS.|AMOUNT;"
            vPrn.FontBold = True
            vPrn.Table = v_format & v_data
            vPrn.TableBorder = VSPrinter8Lib.TableBorderSettings.tbBoxColumns
            vPrn.FontBold = False
            v_data = ""

            For i_loop = 1 To 4  'get ot regular
                vOT = GetOT("'A" & i_loop & "'", rsReport("FromDate"), rsReport("ToDate"), rsReport("Emp_Cd"), c)
                If vOT <> 0 Then
                    v_data = v_data & GetOTName("A" & i_loop, c) & "|" & _
                       Format(vOTHrs, "##0.00") & "|" & _
                       Format(vOT, "##,##0.00") & ";"
                End If
            Next i_loop
            'regular night differential
            vOT = GetOT("'NDREG'", rsReport("FromDate"), rsReport("ToDate"), rsReport("Emp_Cd"), c)
            If vOT <> 0 Then
                v_data = v_data & GetOTName("NDREG", c) & "|" & _
                       Format(vOTHrs, "##0.00") & "|" & _
                       Format(vOT, "##,##0.00") & ";"
            End If

            For i_loop = 1 To 4  'SPECIAL HOLIDAY REST DAY
                vOT = GetOT("'B" & i_loop & "'", rsReport("FromDate"), rsReport("ToDate"), rsReport("Emp_Cd"), c)
                If vOT <> 0 Then
                    v_data = v_data & GetOTName("B" & i_loop, c) & "|" & Format(vOTHrs, "##0.00") & "|" & _
                       Format(vOT, "##,##0.00") & ";"
                End If
            Next i_loop

            For i_loop = 1 To 4  'LEGAL HOLIDAY
                vOT = GetOT("'C" & i_loop & "','G" & i_loop & "'", rsReport("FromDate"), rsReport("ToDate"), rsReport("Emp_Cd"), c)
                If vOT <> 0 Then
                    v_data = v_data & GetOTName("C" & i_loop, c) & "|" & Format(vOTHrs, "##0.00") & "|" & _
                       Format(vOT, "##,##0.00") & ";"
                End If
            Next i_loop

            For i_loop = 1 To 4  'LEGAL HOLIDAY REST DAY
                vOT = GetOT("'D" & i_loop & "'", rsReport("FromDate"), rsReport("ToDate"), rsReport("Emp_Cd"), c)
                If vOT <> 0 Then
                    v_data = v_data & GetOTName("D" & i_loop, c) & "|" & Format(vOTHrs, "##0.00") & "|" & _
                       Format(vOT, "##,##0.00") & ";"
                End If
            Next i_loop

            For i_loop = 1 To 4  'OT REST DAY
                vOT = GetOT("'E" & i_loop & "'", rsReport("FromDate"), rsReport("ToDate"), rsReport("Emp_Cd"), c)
                If vOT <> 0 Then
                    v_data = v_data & GetOTName("E" & i_loop, c) & "|" & Format(vOTHrs, "##0.00") & "|" & _
                       Format(vOT, "##,##0.00") & ";"
                End If
            Next i_loop

            For i_loop = 1 To 4  'SPECIAL HOLIDAY
                vOT = GetOT("'F" & i_loop & "'", rsReport("FromDate"), rsReport("ToDate"), rsReport("Emp_Cd"), c)
                If vOT <> 0 Then
                    v_data = v_data & GetOTName("F" & i_loop, c) & "|" & Format(vOTHrs, "##0.00") & "|" & _
                       Format(vOT, "##,##0.00") & ";"
                End If
            Next i_loop

            For i_loop = 1 To 4  'OTHERS
                vOT = GetOT("'G" & i_loop & "'", rsReport("FromDate"), rsReport("ToDate"), rsReport("Emp_Cd"), c)
                If vOT <> 0 Then
                    v_data = v_data & GetOTName("G" & i_loop, c) & "|" & Format(vOTHrs, "##0.00") & "|" & _
                       Format(vOT, "##,##0.00") & ";"
                End If
            Next i_loop

            vPrn.Table = v_format & v_data
            'OTHER INCENTIVES

            v_data = "OTH. INCOME||AMOUNT;"
            vPrn.FontBold = True
            vPrn.TableBorder = VSPrinter8Lib.TableBorderSettings.tbBox
            vPrn.Table = v_format & v_data
            vPrn.TableBorder = VSPrinter8Lib.TableBorderSettings.tbBoxColumns
            vPrn.FontBold = False
            v_data = ""

            For i_loop = 1 To 60
                If rsReport("Other_Incent" & i_loop) <> 0 Then
                    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                    '' MODIFIED BY:  VIC GATCHALIAN                               ''
                    '' DATE MODIFIED: 3/7/2012                                    ''
                    '' PURPOSE: TO GET THE NAME AND PUT IT IN VARIABLE AND CHECK  ''
                    ''          WHETHER THE NAME IS CODE 'SL' FOR SICK LEAVE      ''
                    ''          CONVERSION. IF CODE IS 'SL', SYSTEM WILL DISPLAY  ''
                    ''          THE CORRESPONDING NUMBER OF DAYS CONVERTED.       ''
                    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                    '''''''''''''''''''''''''' OLD CODE ''''''''''''''''''''''''''''
                    'v_data = v_data & GetIncentDeductName("OthIncent" & i_loop & "Cd", c) & _
                    '   "||" & Format(rsReport("Other_Incent" & i_loop), "##,##0.00") & ";"
                    ''''''''''''''''''' END OLD CODE '''''''''''''''''''''''''''''''
                    vIncentName = GetIncentDeductName("OthIncent" & i_loop & "Cd", vCode, c)
                    vIncentName = vIncentName.Trim
                    v_data = v_data & vIncentName & "|"
                    If vIncentName = "SL" Then  'show the number of days converted
                        If rsReport("Pay_Cd") = "SM" Then     'employee is semi-monthly, multiply the basicrate by two
                            v_data = v_data & Format(rsReport("Other_Incent" & i_loop) / vRateDay, "##0.00")
                        Else                                  'employee is monthly
                            v_data = v_data & Format(rsReport("Other_Incent" & i_loop) / vRateDay, "##0.00")
                        End If
                    End If
                    v_data = v_data & "|" & Format(rsReport("Other_Incent" & i_loop), "##,##0.00") & ";"
                    ''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''
                End If
            Next i_loop
            vPrn.FontBold = False
            vPrn.TableBorder = VSPrinter8Lib.TableBorderSettings.tbBoxColumns
            vPrn.Table = v_format & v_data

            v_data = "|Gross Pay:|" & Format(vGross, "#,###,##0.00") & ";"
            vPrn.TableBorder = VSPrinter8Lib.TableBorderSettings.tbBox
            vPrn.FontBold = True
            vPrn.Table = v_format & v_data


            vPrn.Table = "^6000;DEDUCTIONS;"
            vPrn.FontBold = False
            vPrn.TableBorder = VSPrinter8Lib.TableBorderSettings.tbBoxColumns

            'DEDUCTIONS
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:  VIC GATCHALIAN                            ''
            '' DATE MODIFIED: 3/2/2012                                 ''
            '' PURPOSE: TO DISPLAY THE DEDUCTED UNION DUES             ''
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            ''''''''''''''''' OLD CODE ''''''''''''''''''''''''''''''''''
            'vTotDed = rsReport("With_Tax") + rsReport("Sss_Per") + _
            '   rsReport("Medicare_Per") + rsReport("PagIbig_Per") + rsReport("Gsis_Per")
            '''''''''''''' END OLD CODE        ''''''''''''''''''''''''''
            vTotDed = rsReport("With_Tax") + rsReport("Sss_Per") + _
               rsReport("Medicare_Per") + rsReport("PagIbig_Per") + _
               rsReport("Gsis_Per") + rsReport("UnionDues")
            '''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''

            For i_loop = 1 To 60
                vTotDed = vTotDed + rsReport("Other_Deduct" & i_loop)
            Next i_loop
            v_data = ""
            If rsReport("With_Tax") <> 0 Then
                v_data = v_data & "Withholding Tax||" & Format(rsReport("With_Tax"), "##,##0.00") & ";"
            End If
            If rsReport("Sss_Per") <> 0 Then
                v_data = v_data & "SSS Cont.||" & Format(rsReport("Sss_Per"), "#,##0.00") & ";"
            End If
            If rsReport("Medicare_Per") <> 0 Then
                v_data = v_data & "PhilHealth Cont.||" & Format(rsReport("Medicare_Per"), "#,##0.00") & ";"
            End If
            If rsReport("PagIbig_Per") <> 0 Then
                v_data = v_data & "HDMF Cont.||" & Format(rsReport("PagIbig_Per"), "#,##0.00") & ";"
            End If
            If rsReport("Gsis_Per") <> 0 Then
                v_data = v_data & "GSIS||" & Format(rsReport("Gsis_Per"), "#,##0.00") & ";"
            End If
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:  VIC GATCHALIAN                            ''
            '' DATE MODIFIED: 3/2/2012                                 ''
            '' PURPOSE: TO DISPLAY THE DEDUCTED UNION DUES             ''
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            If rsReport("UnionDues") <> 0 Then
                v_data = v_data & "Union Dues||" & Format(rsReport("UnionDues"), "#,##0.00") & ";"
            End If
            '''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''

            vPrn.Table = v_format & v_data

            'OTHER DEDUCTION DETAILS
            v_data = "LOAN TYPE|BEG. BAL.|AMOUNT;"
            vPrn.FontBold = True
            vPrn.TableBorder = VSPrinter8Lib.TableBorderSettings.tbBox
            vPrn.Table = v_format & v_data
            vPrn.TableBorder = VSPrinter8Lib.TableBorderSettings.tbBoxColumns
            vPrn.FontBold = False
            v_data = ""
            cmRef.CommandText = "select * from py_syscntrl"
            rsRef = cmRef.ExecuteReader
            rsRef.Read()
            For i_loop = 1 To 60
                If rsReport("Other_Deduct" & i_loop) <> 0 Then
                    v_data = v_data & GetIncentDeductName("OthDed" & i_loop & "Cd", vCode, c) & _
                       "|" & IIf(chkLoanBal.Checked, _
                       Format(GetBalance(rsRef("OthDed" & i_loop & "Cd"), rsReport("Emp_Cd"), c), "###,##0.00"), "") & _
                       "|" & Format(rsReport("Other_Deduct" & i_loop), "##,##0.00") & ";"
                End If
            Next i_loop
            rsRef.Close()
            vPrn.Table = v_format & v_data

            vPrn.FontBold = True
            vPrn.TableBorder = VSPrinter8Lib.TableBorderSettings.tbBox
            vPrn.Table = ">4625|>1375;Total Deductions:|" & Format(vTotDed, "#,###,##0.00") & ";"
            vPrn.Table = ">4625|>1375;NET PAY:|" & Format(rsReport("Amount_Per"), "#,###,##0.00") & ";"

            'vPrn.Table = ">4250|>1000;Total Deductions:|" & Format(vTotDed, "#,###,##0.00") & ";"
            'vPrn.Table = ">4250|>1000;NET PAY:|" & Format(rsReport("Amount_Per"), "#,###,##0.00") & ";"

            vPrn.FontBold = False
            vPrn.Paragraph = vbCrLf & vbCrLf & "Received By: _________________________" & vbCrLf & vbCrLf & vbCrLf
            If vPageCtr = 3 Then
                vPrn.CurrentColumn = 1
            End If
            If vPageCtr = 3 Then
                vPrn.NewPage()
                vPageCtr = 0
            End If
        Loop
        rsReport.Close()
        cmReport.Dispose()
        cmEmp.Dispose()
        cmRef.Dispose()
        c.Close()
        'cReport.Close()
        'cEmp.Close()
        c.Dispose()
        'cReport.Dispose()
        'cEmp.Dispose()
        vPrn.Action = VSPrinter8Lib.ActionSettings.paEndDoc
        Try
            Kill(Server.MapPath("") & "\downloads\" & Session.SessionID & "-payslip.pdf")
        Catch ex As IO.IOException
        End Try
        vPDF.ConvertDocument(vPrn, Server.MapPath("") & "\downloads\" & Session.SessionID & "-payslip.pdf")
        vSrc = "downloads/" & Session.SessionID & "-payslip.pdf"
        vPrn = Nothing
        vPDF = Nothing
    End Sub
    Private Function GetBalance(ByVal pLoanCd As String, ByVal pEmpCd As String, ByRef c As SqlClient.SqlConnection) As Decimal
        'Dim c As New sqlclient.sqlconnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader

        'c.Open()
        cm.Connection = c
        cm.CommandText = "select sum(Amt_Bal) from py_loan_hdr where Active<>0 and Emp_Cd='" & pEmpCd & _
           "' and Loan_Cd='" & pLoanCd & "' and Amt_Bal > 0"
        rs = cm.ExecuteReader
        GetBalance = 0
        If rs.Read Then
            If Not IsDBNull(rs(0)) Then
                GetBalance = rs(0)
            Else
                GetBalance = 0
            End If
        End If
        rs.Close()
        cm.Dispose()
        'c.Close()
        'c.Dispose()
    End Function

    Private Function GetIncentDeductName(ByVal pDeductionCd As String, ByRef pCode As String, ByRef c As SqlClient.SqlConnection) As String
        'Dim c As New sqlclient.sqlconnection(connStr)
        Dim cmPYSysCntrl As New SqlClient.SqlCommand
        Dim rsPYSysCntrl As SqlClient.SqlDataReader

        'c.Open()
        cmPYSysCntrl.Connection = c
        cmPYSysCntrl.CommandText = "select * from py_syscntrl"
        rsPYSysCntrl = cmPYSysCntrl.ExecuteReader

        rsPYSysCntrl.Read()
        If Not IsDBNull(rsPYSysCntrl(pDeductionCd)) Then
            pCode = rsPYSysCntrl(pDeductionCd)
            If InStr(1, pDeductionCd, "Ded") > 0 Then
                GetIncentDeductName = GetLoanName(rsPYSysCntrl(pDeductionCd), c)
            Else
                '''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY: VIC GATCHALIAN                   ''
                '' DATE MODIFIED: 3/9/2012                       ''
                '' PURPOSE: TO CONVERT THE DISPLAY OF INCENTIVE  ''
                ''          FROM CODE TO DESCRIPTION.            ''
                '''''''''''''''''''''''''''''''''''''''''''''''''''
                ''''''''''' OLD CODE ''''''''''''''''''''''''''''''
                'GetIncentDeductName = rsPYSysCntrl(pDeductionCd)
                ''''''''''''' END OF OLD CODE '''''''''''''''''''''
                GetIncentDeductName = GetIncentName(rsPYSysCntrl(pDeductionCd), c)
                ''''''''''''' END OF MODIFICATION '''''''''''''''''
            End If
        Else
            GetIncentDeductName = ""
            pCode = ""
        End If
        rsPYSysCntrl.Close()
        cmPYSysCntrl.Dispose()
        'c.Close()
        'c.Dispose()
    End Function
    Private Function GetIncentName(ByVal pIncentCd As String, ByRef c As SqlClient.SqlConnection) As String
        If Trim(pIncentCd <> "") Then
            'Dim c As New sqlclient.sqlconnection(connStr)
            Dim cmRef As New SqlClient.SqlCommand
            Dim rsRef As SqlClient.SqlDataReader

            'c.Open()
            cmRef.Connection = c
            cmRef.CommandText = "select Descr from py_other_incentvs where Incentive_Cd='" & pIncentCd & "'"
            rsRef = cmRef.ExecuteReader
            GetIncentName = ""
            If rsRef.Read Then
                GetIncentName = rsRef("Descr")
            End If
            rsRef.Close()
            cmRef.Dispose()
            'c.Close()
            'c.Dispose()
        Else
            GetIncentName = ""
        End If
    End Function
    Private Function GetLoanName(ByVal LoanCd As String, ByRef c As SqlClient.SqlConnection) As String
        If Trim(LoanCd <> "") Then
            'Dim c As New sqlclient.sqlconnection(connStr)
            Dim cmRef As New SqlClient.SqlCommand
            Dim rsRef As SqlClient.SqlDataReader

            'c.Open()
            cmRef.Connection = c
            cmRef.CommandText = "select Loan_Name from py_loan_ref where Loan_Cd='" & LoanCd & "'"
            rsRef = cmRef.ExecuteReader
            GetLoanName = ""
            If rsRef.Read Then
                GetLoanName = rsRef("Loan_Name")
            End If
            rsRef.Close()
            cmRef.Dispose()
            'c.Close()
            'c.Dispose()
        Else
            GetLoanName = ""
        End If
    End Function

    Private Function GetOT(ByVal pOTCd As String, ByVal pFromDate As Date, ByVal pDate As Date, ByVal pEmpCd As String, ByRef c As SqlClient.SqlConnection) As Decimal
        'Dim c As New sqlclient.sqlconnection(connStr)
        Dim cmTimeLog As New SqlClient.SqlCommand
        Dim rsTimeLog As SqlClient.SqlDataReader

        'c.Open()
        cmTimeLog.Connection = c
        cmTimeLog.CommandText = "select sum(AmtConv),sum(Hrs_Rendered) from py_emp_time_log where Emp_Cd='" & _
           pEmpCd & "' and TranDate between '" & Format(pFromDate, "yyyy/MM/dd") & "' and '" & _
           Format(pDate, "yyyy/MM/dd") & "' and TranCd in (" & _
           pOTCd & ")"
        rsTimeLog = cmTimeLog.ExecuteReader
        If rsTimeLog.Read Then
            GetOT = IIf(IsDBNull(rsTimeLog(0)), 0, rsTimeLog(0))
            vOTHrs = IIf(IsDBNull(rsTimeLog(1)), 0, rsTimeLog(1))
        Else
            GetOT = 0
        End If
        rsTimeLog.Close()
        cmTimeLog.Dispose()
        'c.Close()
        'c.Dispose()
    End Function
    Private Function GetOTName(ByVal pOTCd As String, ByRef c As SqlClient.SqlConnection) As String
        'Dim c As New sqlclient.sqlconnection(connStr)
        Dim cmRef As New SqlClient.SqlCommand
        Dim rsRef As SqlClient.SqlDataReader

        'c.Open()
        cmRef.Connection = c
        cmRef.CommandText = "select Descr from py_ot_ref where OtCd='" & pOTCd & "'"
        rsRef = cmRef.ExecuteReader
        If rsRef.Read Then
            GetOTName = rsRef("Descr")
        Else
            GetOTName = ""
        End If
        rsRef.Close()
        cmRef.Dispose()
        'c.Close()
        'c.Dispose()
    End Function

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'If Session("uid") = "" Then
        '    Server.Transfer("index.aspx")
        'End If
        lblCaption.Text = "View/Print Payslip"
    End Sub
End Class
