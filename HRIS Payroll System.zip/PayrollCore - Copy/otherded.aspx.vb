Imports denaro
Partial Class otherded
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Dim i As Integer
    Dim vDedList(60) As String
    Protected Sub cmdCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Session("returnaddr") = "otherded.aspx"
            Server.Transfer("index.aspx")
        End If
        If Not CanRun(Session("caption"), Request.Item("id")) Then
            Session("denied") = "1"
            Server.Transfer("main.aspx")
            Exit Sub
        End If

        If Not IsPostBack Then
            lblCaption.Text = "Loans and Other Deductions Settings"
            Dim c As New SqlClient.SqlConnection
            Dim cm As New SqlClient.SqlCommand
            Dim dr As SqlClient.SqlDataReader

            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c
            cm.CommandText = "select OthDed1Cd,OthDed2Cd,OthDed3Cd,OthDed4Cd,OthDed5Cd," & _
                "OthDed6Cd,OthDed7Cd,OthDed8Cd,OthDed9Cd,OthDed10Cd," & _
                "OthDed11Cd,OthDed12Cd,OthDed13Cd,OthDed14Cd,OthDed15Cd," & _
                "OthDed16Cd,OthDed17Cd,OthDed18Cd,OthDed19Cd,OthDed20Cd," & _
                "OthDed21Cd,OthDed22Cd,OthDed23Cd,OthDed24Cd,OthDed25Cd," & _
                "OthDed26Cd,OthDed27Cd,OthDed28Cd,OthDed29Cd,OthDed30Cd," & _
                "OthDed31Cd,OthDed32Cd,OthDed33Cd,OthDed34Cd,OthDed35Cd," & _
                "OthDed36Cd,OthDed37Cd,OthDed38Cd,OthDed39Cd,OthDed40Cd," & _
                "OthDed41Cd,OthDed42Cd,OthDed43Cd,OthDed44Cd,OthDed45Cd," & _
                "OthDed46Cd,OthDed47Cd,OthDed48Cd,OthDed49Cd,OthDed50Cd," & _
                "OthDed51Cd,OthDed52Cd,OthDed53Cd,OthDed54Cd,OthDed55Cd," & _
                "OthDed56Cd,OthDed57Cd,OthDed58Cd,OthDed59Cd,OthDed60Cd " & _
                "from py_syscntrl"
            dr = cm.ExecuteReader

            If dr.Read Then
                For i As Integer = 1 To 60
                    vDedList(i - 1) = IIf(IsDBNull(dr("OthDed" & i & "Cd")), "", dr("OthDed" & i & "Cd"))
                Next
            End If
            dr.Close()
            cm.Dispose()
            c.Close()
            c.Dispose()
        End If
    End Sub

    Private Sub ClearList()
        cmbInc1.SelectedValue = "" : cmbInc2.SelectedValue = "" : cmbInc3.SelectedValue = ""
        cmbInc4.SelectedValue = "" : cmbInc5.SelectedValue = "" : cmbInc6.SelectedValue = ""
        cmbInc7.SelectedValue = "" : cmbInc8.SelectedValue = "" : cmbInc9.SelectedValue = ""
        cmbInc10.SelectedValue = "" : cmbInc11.SelectedValue = "" : cmbInc12.SelectedValue = ""
        cmbInc13.SelectedValue = "" : cmbInc14.SelectedValue = "" : cmbInc15.SelectedValue = ""
        cmbInc16.SelectedValue = "" : cmbInc17.SelectedValue = "" : cmbInc18.SelectedValue = ""
        cmbInc19.SelectedValue = "" : cmbInc20.SelectedValue = "" : cmbInc21.SelectedValue = ""
        cmbInc22.SelectedValue = "" : cmbInc23.SelectedValue = "" : cmbInc24.SelectedValue = ""
        cmbInc25.SelectedValue = "" : cmbInc26.SelectedValue = "" : cmbInc27.SelectedValue = ""
        cmbInc28.SelectedValue = "" : cmbInc29.SelectedValue = "" : cmbInc30.SelectedValue = ""
        cmbInc31.SelectedValue = "" : cmbInc32.SelectedValue = "" : cmbInc33.SelectedValue = ""
        cmbInc34.SelectedValue = "" : cmbInc35.SelectedValue = "" : cmbInc36.SelectedValue = ""
        cmbInc37.SelectedValue = "" : cmbInc38.SelectedValue = "" : cmbInc39.SelectedValue = ""
        cmbInc40.SelectedValue = "" : cmbInc41.SelectedValue = "" : cmbInc42.SelectedValue = ""
        cmbInc43.SelectedValue = "" : cmbInc44.SelectedValue = "" : cmbInc45.SelectedValue = ""
        cmbInc46.SelectedValue = "" : cmbInc47.SelectedValue = "" : cmbInc48.SelectedValue = ""
        cmbInc49.SelectedValue = "" : cmbInc50.SelectedValue = "" : cmbInc51.SelectedValue = ""
        cmbInc52.SelectedValue = "" : cmbInc53.SelectedValue = "" : cmbInc54.SelectedValue = ""
        cmbInc55.SelectedValue = "" : cmbInc56.SelectedValue = "" : cmbInc57.SelectedValue = ""
        cmbInc58.SelectedValue = "" : cmbInc59.SelectedValue = "" : cmbInc60.SelectedValue = ""
    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click

        Try
            Dim c As New SqlClient.SqlConnection
            Dim cm As New SqlClient.SqlCommand
            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c

            cm.CommandText = "update py_syscntrl set OthDed1Cd='" & cmbInc1.SelectedValue & _
                "',OthDed2Cd='" & cmbInc2.SelectedValue & _
                "',OthDed3Cd='" & cmbInc3.SelectedValue & _
                "',OthDed4Cd='" & cmbInc4.SelectedValue & _
                "',OthDed5Cd='" & cmbInc5.SelectedValue & _
                "',OthDed6Cd='" & cmbInc6.SelectedValue & _
                "',OthDed7Cd='" & cmbInc7.SelectedValue & _
                "',OthDed8Cd='" & cmbInc8.SelectedValue & _
                "',OthDed9Cd='" & cmbInc9.SelectedValue & _
                "',OthDed10Cd='" & cmbInc10.SelectedValue & _
                "',OthDed11Cd='" & cmbInc11.SelectedValue & _
                "',OthDed12Cd='" & cmbInc12.SelectedValue & _
                "',OthDed13Cd='" & cmbInc13.SelectedValue & _
                "',OthDed14Cd='" & cmbInc14.SelectedValue & _
                "',OthDed15Cd='" & cmbInc15.SelectedValue & _
                "',OthDed16Cd='" & cmbInc16.SelectedValue & _
                "',OthDed17Cd='" & cmbInc17.SelectedValue & _
                "',OthDed18Cd='" & cmbInc18.SelectedValue & _
                "',OthDed19Cd='" & cmbInc19.SelectedValue & _
                "',OthDed20Cd='" & cmbInc20.SelectedValue & _
                "',OthDed21Cd='" & cmbInc21.SelectedValue & _
                "',OthDed22Cd='" & cmbInc22.SelectedValue & _
                "',OthDed23Cd='" & cmbInc23.SelectedValue & _
                "',OthDed24Cd='" & cmbInc24.SelectedValue & _
                "',OthDed25Cd='" & cmbInc25.SelectedValue & _
                "',OthDed26Cd='" & cmbInc26.SelectedValue & _
                "',OthDed27Cd='" & cmbInc27.SelectedValue & _
                "',OthDed28Cd='" & cmbInc28.SelectedValue & _
                "',OthDed29Cd='" & cmbInc29.SelectedValue & _
                "',OthDed30Cd='" & cmbInc30.SelectedValue & _
                "',OthDed31Cd='" & cmbInc31.SelectedValue & _
                "',OthDed32Cd='" & cmbInc32.SelectedValue & _
                "',OthDed33Cd='" & cmbInc33.SelectedValue & _
                "',OthDed34Cd='" & cmbInc34.SelectedValue & _
                "',OthDed35Cd='" & cmbInc35.SelectedValue & _
                "',OthDed36Cd='" & cmbInc36.SelectedValue & _
                "',OthDed37Cd='" & cmbInc37.SelectedValue & _
                "',OthDed38Cd='" & cmbInc38.SelectedValue & _
                "',OthDed39Cd='" & cmbInc39.SelectedValue & _
                "',OthDed40Cd='" & cmbInc40.SelectedValue & _
                "',OthDed41Cd='" & cmbInc41.SelectedValue & _
                "',OthDed42Cd='" & cmbInc42.SelectedValue & _
                "',OthDed43Cd='" & cmbInc43.SelectedValue & _
                "',OthDed44Cd='" & cmbInc44.SelectedValue & _
                "',OthDed45Cd='" & cmbInc45.SelectedValue & _
                "',OthDed46Cd='" & cmbInc46.SelectedValue & _
                "',OthDed47Cd='" & cmbInc47.SelectedValue & _
                "',OthDed48Cd='" & cmbInc48.SelectedValue & _
                "',OthDed49Cd='" & cmbInc49.SelectedValue & _
                "',OthDed50Cd='" & cmbInc50.SelectedValue & _
                "',OthDed51Cd='" & cmbInc51.SelectedValue & _
                "',OthDed52Cd='" & cmbInc52.SelectedValue & _
                "',OthDed53Cd='" & cmbInc53.SelectedValue & _
                "',OthDed54Cd='" & cmbInc54.SelectedValue & _
                "',OthDed55Cd='" & cmbInc55.SelectedValue & _
                "',OthDed56Cd='" & cmbInc56.SelectedValue & _
                "',OthDed57Cd='" & cmbInc57.SelectedValue & _
                "',OthDed58Cd='" & cmbInc58.SelectedValue & _
                "',OthDed59Cd='" & cmbInc59.SelectedValue & _
                "',OthDed60Cd='" & cmbInc60.SelectedValue & "'"
            cm.ExecuteNonQuery()
            cm.Dispose()
            c.Close()
            c.Dispose()
            vScript = "alert('Changes have been saved successfully.');"
        Catch ex As system.exception
            vScript = "alert('Error occurred while trying to save the changes. Error is: " & _
                ex.Message.Replace("'", "").Replace(vbCrLf, "") & "');"
        End Try
    End Sub


    Protected Sub cmdReset_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReset.Click
        ClearList()
    End Sub

    Protected Sub cmbInc1_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles _
        cmbInc1.PreRender, cmbInc2.PreRender, cmbInc3.PreRender, cmbInc4.PreRender, cmbInc5.PreRender, _
        cmbInc6.PreRender, cmbInc7.PreRender, cmbInc8.PreRender, cmbInc9.PreRender, cmbInc10.PreRender, _
        cmbInc11.PreRender, cmbInc12.PreRender, cmbInc13.PreRender, cmbInc14.PreRender, cmbInc15.PreRender, _
        cmbInc16.PreRender, cmbInc17.PreRender, cmbInc18.PreRender, cmbInc19.PreRender, cmbInc20.PreRender, _
        cmbInc21.PreRender, cmbInc22.PreRender, cmbInc23.PreRender, cmbInc24.PreRender, cmbInc25.PreRender, _
        cmbInc26.PreRender, cmbInc27.PreRender, cmbInc28.PreRender, cmbInc29.PreRender, cmbInc30.PreRender, _
        cmbInc31.PreRender, cmbInc32.PreRender, cmbInc33.PreRender, cmbInc34.PreRender, cmbInc35.PreRender, _
        cmbInc36.PreRender, cmbInc37.PreRender, cmbInc38.PreRender, cmbInc39.PreRender, cmbInc40.PreRender, _
        cmbInc41.PreRender, cmbInc42.PreRender, cmbInc43.PreRender, cmbInc44.PreRender, cmbInc45.PreRender, _
        cmbInc46.PreRender, cmbInc47.PreRender, cmbInc48.PreRender, cmbInc49.PreRender, cmbInc50.PreRender, _
        cmbInc51.PreRender, cmbInc52.PreRender, cmbInc53.PreRender, cmbInc54.PreRender, cmbInc55.PreRender, _
        cmbInc56.PreRender, cmbInc57.PreRender, cmbInc58.PreRender, cmbInc59.PreRender, cmbInc60.PreRender

        If txtState.Value = "" Then
            Dim vIdx As String

            BuildCombo("select Loan_Cd,Loan_Name from py_loan_ref order by Loan_Name", CType(sender, DropDownList))

            CType(sender, DropDownList).Items.Add("")
            vIdx = CType(sender, DropDownList).ID.Substring(6)
            CType(sender, DropDownList).SelectedValue = vDedList(vIdx - 1)
            If vIdx = 60 Then txtState.Value = "1"
        End If
    End Sub

End Class
