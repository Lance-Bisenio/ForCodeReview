Imports denaro
Imports System.IO
Imports System.Drawing
Partial Class generate_id
    Inherits System.Web.UI.Page
    Public vData As String = ""
    Public vMsg As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Session.RemoveAll()
            Server.Transfer("index.aspx")
        End If

        If Not CanRun(Session("caption"), Request.Item("id")) Then
            Session("denied") = "1"
            Server.Transfer("main.aspx")
            Exit Sub
        End If

        If Not IsPostBack Then
            BuildCombo("select Rc_Cd, Descr from rc where Rc_Cd in ('" & _
                                Session("rclist").ToString.Replace(",", "','") & "') order by Descr ", cmbRC)
            BuildCombo("select AgencyCd,AgencyName from agency where Agencycd in ('" & _
                Session("agencylist").ToString.Replace(",", "','") & "') order by AgencyName", cmbOfc)
            BuildCombo("select Div_Cd,Descr from hr_div_ref where Div_Cd in ('" & _
                Session("divlist").ToString.Replace(",", "','") & "') order by Descr", cmbDiv)
            BuildCombo("select Dept_Cd,Descr from hr_dept_ref where Dept_Cd in ('" & _
                Session("deptlist").ToString.Replace(",", "','") & "') order by Descr", cmbDept)
            BuildCombo("select Section_Cd,Descr from hr_section_ref where Section_Cd in ('" & _
                Session("sectionlist").ToString.Replace(",", "','") & "') order by Descr", cmbSection)
            BuildCombo("select Unit_Cd,Descr from hr_unit_ref where Unit_Cd in ('" & _
                Session("unitlist").ToString.Replace(",", "','") & "') order by Descr", cmbUnit)
            BuildCombo("select EmploymentType,Descr from hr_employment_type where EmploymentType in ('" & _
                Session("typelist").ToString.Replace(",", "','") & "') order by Descr", cmbEmpType)
            cmbRC.Items.Add("All")
            cmbRC.SelectedValue = "All"
            cmbOfc.Items.Add("All")
            cmbOfc.SelectedValue = "All"
            cmbDiv.Items.Add("All")
            cmbDiv.SelectedValue = "All"
            cmbDept.Items.Add("All")
            cmbDept.SelectedValue = "All"
            cmbSection.Items.Add("All")
            cmbSection.SelectedValue = "All"
            cmbUnit.Items.Add("All")
            cmbUnit.SelectedValue = "All"
            cmbEmpType.Items.Add("All Types")
            cmbEmpType.SelectedValue = "All Types"
            cmdPrint.Enabled = False
            'DataRefresh(txtSearch.Text)
        End If
    End Sub
    Private Sub DataRefresh(ByVal vLetter As String)
        Dim c As New sqlclient.sqlconnection
        Dim cm As New sqlclient.sqlcommand
        Dim dr As sqlclient.sqldatareader
        Dim vSQL As String = ""
        Dim vFilter As String = ""
        Dim vEmpData As String = ""
        vMsg = ""
        vData = ""
        c.ConnectionString = connStr
        vFilter = " where " & cmbType.SelectedValue & " like '" & vLetter & "%' "
        Select Case Val(cmbStatus.SelectedValue)
            Case 1  'active employees only
                vFilter += " and Date_Resign is null "
            Case 0  'inactive employees only
                vFilter += " and Date_Resign is not null "
        End Select

        If cmbRC.SelectedValue <> "All" Then   'filter by cost center
            vFilter += " and Rc_Cd='" & cmbRC.SelectedValue & "' "
        Else
            vFilter += " and Rc_Cd in ('" & Session("rclist").ToString.Replace(",", "','") & "') "
        End If
        If cmbOfc.SelectedValue <> "All" Then        'filter by office/agency
            vFilter += " and Agency_Cd='" & cmbOfc.SelectedValue & "' "
        Else
            vFilter += " and Agency_Cd in ('" & Session("agencylist").ToString.Replace(",", "','") & "') "
        End If
        If cmbDiv.SelectedValue <> "All" Then      'filter by division
            vFilter += " and Divcd='" & cmbDiv.SelectedValue & "' "
        Else
            vFilter += " and DivCd in ('" & Session("divlist").ToString.Replace(",", "','") & "') "
        End If
        If cmbDept.SelectedValue <> "All" Then  'filter by departments
            vFilter += " and DeptCd='" & cmbDept.SelectedValue & "' "
        Else
            vFilter += " and DeptCd in ('" & Session("deptlist").ToString.Replace(",", "','") & "') "
        End If
        If cmbSection.SelectedValue <> "All" Then 'filter by section
            vFilter += " and SectionCd='" & cmbSection.SelectedValue & "' "
        Else
            vFilter += " and SectionCd in ('" & Session("sectionlist").ToString.Replace(",", "','") & "') "
        End If
        If cmbUnit.SelectedValue <> "All" Then  'filter by units
            vFilter += " and UnitCd='" & cmbUnit.SelectedValue & "' "
        Else
            vFilter += " and UnitCd in ('" & Session("unitlist").ToString.Replace(",", "','") & "') "
        End If
        If cmbEmpType.SelectedValue <> "All Types" Then 'filter by employment types
            vFilter += " and EmploymentType='" & cmbEmpType.SelectedValue & "' "
        Else
            vFilter += " and EmploymentType in ('" & Session("typelist").ToString.Replace(",", "','") & "') "
        End If
        vSQL = "select Emp_Cd, Emp_Lname, Emp_Fname, Emp_Mname from py_emp_master " & vFilter & _
            " order by Emp_Lname,Emp_Fname,Emp_Mname"
        c.Open()
        cm.Connection = c
        cm.CommandText = vSQL
        dr = cm.ExecuteReader
        chklist.Items.Clear()
        If dr.HasRows Then
            Do While dr.Read
                chklist.Items.Add(dr("Emp_Cd") & " : " & dr("Emp_Lname") & ", " & dr("Emp_Fname") & " " & dr("Emp_Mname").ToString.Substring(0, 1) & ".")
            Loop
            cmdPrint.Enabled = True
        Else
            vMsg = "<span style='color:blue;font-size:1.1em;font-weight:bold;'>No records to display...</span>"
            cmdPrint.Enabled = Not True
        End If
        cm.Dispose()
        dr.Close()
        c.Close()
    End Sub
    'Private Sub PrintReview()
    '    Dim vPDF As New VSPDF8Lib.VSPDF8
    '    Dim vPrinter As New VSPrinter8Lib.VSPrinter
    '    Dim c As New sqlclient.sqlconnection
    '    Dim cm As New sqlclient.sqlcommand
    '    Dim rs As sqlclient.sqldatareader
    '    Dim vEmpId As String = ""
    '    Dim twips As Integer = 1440
    '    Dim vFormat As String = ""
    '    Dim x As Integer = 0
    '    Dim y As Integer = 0
    '    Dim sel As Integer = 0
    '    For x = 0 To chklist.Items.Count - 1
    '        If chklist.Items(x).Selected Then
    '            sel += 1
    '            y = chklist.Items(x).Value.IndexOf(":")
    '            vEmpId += "'" & chklist.Items(x).Value.Substring(0, y) & "',"
    '        End If
    '    Next
    '    If sel = 0 Then
    '        vData = "alert('Select Employee(s) you wish to print.');"
    '        Exit Sub
    '    End If
    '    If vEmpId.Length > 2 Then
    '        vEmpId = vEmpId.Substring(0, vEmpId.Length - 1)
    '    End If
    '    c.ConnectionString = connStr
    '    c.Open()
    '    cm.Connection = c
    '    cm.CommandText = "SELECT COUNT(*) FROM py_emp_master WHERE Emp_Cd IN(" & vEmpId & ")"
    '    rs = cm.ExecuteReader
    '    Dim total As Long = 0
    '    If rs.HasRows Then
    '        rs.Read()
    '        If Not rs(0) = total Then
    '            total = rs(0)
    '        End If
    '    End If
    '    rs.Close()
    '    With vPrinter
    '        .Orientation = VSPrinter8Lib.OrientationSettings.orPortrait
    '        .PaperSize = VSPrinter8Lib.PaperSizeSettings.pprLetter
    '        .Columns = 2
    '        .StartDoc()
    '        Dim ctr As Integer = 0
    '        Dim ipagectr As Integer = 1
    '        cm.CommandText = "SELECT Emp_Cd,Emp_Lname, Emp_Fname, Emp_Mname,Emp_Address, Emp_Tel, NickName, AgencyName FROM py_emp_master, Agency WHERE Emp_Cd IN(" & vEmpId & ") AND Agency.AgencyCd=py_emp_master.Agency_Cd"
    '        rs = cm.ExecuteReader
    '        If rs.HasRows Then
    '            Do While rs.Read
    '                .DrawRectangle(100, 100, 500, 500)
    '                .TableBorder = VSPrinter8Lib.TableBorderSettings.tbBox
    '                .TextAlign = VSPrinter8Lib.TextAlignSettings.taCenterMiddle
    '                vFormat = "<1440;"
    '                vData = " ; ; ; ; ;"
    '                .Table = vFormat & vData
    '                .Paragraph = ""
    '                .FontSize = 12
    '                .Paragraph = rs("AgencyName")
    '                .FontSize = 10
    '                .Paragraph = rs("Emp_Address")
    '                .Paragraph = rs("Emp_Tel")
    '                .Paragraph = ""
    '                .FontSize = 14
    '                .FontBold = True
    '                .Paragraph = rs("NickName").ToString.ToUpper
    '                .FontSize = 10
    '                .Paragraph = rs("Emp_Cd")
    '                .Paragraph = ""
    '                .Paragraph = ""
    '                .Paragraph = ""
    '                ipagectr += 1
    '                If ipagectr = 5 Then
    '                    ipagectr = 1
    '                    .NewPage()
    '                End If
    '            Loop
    '        End If
    '        rs.Close()
    '        .EndDoc()
    '    End With
    '    vPDF.ConvertDocument(vPrinter, Server.MapPath("") & "\id.pdf")
    '    rs.Close()
    '    cm.Dispose()
    '    c.Close()
    '    vData = "viewwin=window.open('id.pdf','viewwin','toolbar=no,location=no,width=800,height=600,top=50,left=100,scrollbars=yes');"
    'End Sub

    Private Sub PrintID()
        Dim vEmpId As String = ""
        Dim x As Integer = 0
        Dim y As Integer = 0
        Dim sel As Integer = 0
        For x = 0 To chklist.Items.Count - 1
            If chklist.Items(x).Selected Then
                sel += 1
                y = chklist.Items(x).Value.IndexOf(":")
                vEmpId += "'" & chklist.Items(x).Value.Substring(0, y) & "',"
            End If
        Next
        If sel = 0 Then
            vData = "alert('Select Employee(s) you wish to print.');"
            Exit Sub
        End If
        If vEmpId.Length > 2 Then
            vEmpId = vEmpId.Substring(0, vEmpId.Length - 1)
        End If
        Session("vEmpId") = vEmpId
        vData = "javascript:win=window.open('printer_id.aspx'); win.focus();"
    End Sub
    Protected Sub cmdSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSearch.Click
        DataRefresh(txtSearch.Text)
    End Sub

    Protected Sub cmdPrint_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdPrint.Click
        PrintID()
    End Sub

    Protected Sub cmdreturn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdreturn.Click
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub cmddeselect_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmddeselect.Click
        For Each list As ListItem In chklist.Items
            list.Selected = False
        Next
    End Sub

    Protected Sub cmdselect_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdselect.Click
        For Each list As ListItem In chklist.Items
            list.Selected = True
        Next
    End Sub
End Class
