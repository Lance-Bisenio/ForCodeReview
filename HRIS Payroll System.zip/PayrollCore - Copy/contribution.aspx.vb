﻿Imports denaro.fis
Partial Class contribution
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If
        If Not IsPostBack Then
            If Not CanRun(Session("caption"), Request.Item("id")) Then
                Session("denied") = "1"
                Server.Transfer("main.aspx")
                Exit Sub
            End If

            BuildCombo("select Rc_Cd,Descr from rc where exists (select User_Id from rights_list where User_Id='" & _
                    Session("uid") & "' and property='rc' and Property_Value=Rc_Cd) order by Descr", cmbRC)
            BuildCombo("select AgencyCd,AgencyName from agency where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='agency' and Property_Value=AgencyCd) order by AgencyName", cmbOfc)
            BuildCombo("select Div_Cd,Descr from hr_div_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='division' and Property_Value=Div_Cd) order by Descr", cmbDiv)
            BuildCombo("select Dept_Cd,Descr from hr_dept_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='department' and Property_Value=Dept_Cd) order by Descr", cmbDept)
            BuildCombo("select Section_Cd,Descr from hr_section_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='section' and Property_Value=Section_Cd) order by Descr", cmbSection)
            BuildCombo("select Unit_Cd,Descr from hr_unit_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='unit' and Property_Value=Unit_Cd) order by Descr", cmbUnit)
            BuildCombo("select EmploymentType,Descr from hr_employment_type where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='employmenttype' and Property_Value=EmploymentType) order by Descr", cmbEmpType)

            cmbRC.Items.Add("All")
            cmbRC.SelectedValue = "All"
            cmbOfc.Items.Add("All")
            cmbOfc.SelectedValue = "All"
            cmbDiv.Items.Add("All")
            cmbDiv.SelectedValue = "All"
            cmbDept.Items.Add("All")
            cmbDept.SelectedValue = "All"
            cmbSection.Items.Add("All")
            cmbSection.SelectedValue = "All"
            cmbUnit.Items.Add("All")
            cmbUnit.SelectedValue = "All"
            cmbEmpType.Items.Add("All")
            cmbEmpType.SelectedValue = "All"

            Dim i As Integer
            cmbYrFr.Items.Clear()
            For i = Now.Year - 10 To Now.Year
                cmbYrFr.Items.Add(i)
                cmbYrTo.Items.Add(i)
            Next
            cmbYrFr.SelectedValue = Now.Year - 2
            cmbYrTo.SelectedValue = Now.Year
            cmbStartMonthFr.SelectedValue = 1
            cmbStartMonthTo.SelectedValue = 12
            cmbEndMonthFr.SelectedValue = 1
            cmbEndMonthTo.SelectedValue = Now.Month

            DataRefresh(txtSearch.Text)
        End If
    End Sub
    Private Sub DataRefresh(Optional ByVal pSearch As String = "")
        Dim c As New sqlclient.sqlConnection(connStr)
        Dim da As sqlclient.sqlDataAdapter
        Dim ds As New DataSet
        Dim vFilter_ref As String = ""
        Dim vLtrFilter As String = ""
        Dim vFilter As String = ""

        '''''''''''''''''''''''''''''''''


        vFilter += iif(vFilter <> "", " and ", " where ")
        If cmbRC.SelectedValue <> "All" Then   'filter by cost center
            vFilter += " Rc_Cd='" & cmbRC.SelectedValue & "' "
        Else
            vFilter += " exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
            "' and Property='rc' and Property_Value=Rc_Cd) "
        End If

        vFilter += iif(vFilter <> "", " and ", " where ")
        If cmbOfc.SelectedValue <> "All" Then        'filter by office/agency
            If vFilter <> "" Then
                vFilter += " Agency_Cd='" & cmbOfc.SelectedValue & "' "
            Else
                vFilter += " Agency_Cd='" & cmbOfc.SelectedValue & "' "
            End If
        Else
            vFilter += " exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='agency' and Property_Value=Agency_Cd) "
        End If

        vFilter += iif(vFilter <> "", " and ", " where ")
        If cmbDiv.SelectedValue <> "All" Then      'filter by division
            vFilter += " Divcd='" & cmbDiv.SelectedValue & "' "
        Else
            vFilter += " exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='division' and Property_Value=DivCd) "
        End If

        vFilter += iif(vFilter <> "", " and ", " where ")
        If cmbDept.SelectedValue <> "All" Then  'filter by departments
            vFilter += " DeptCd='" & cmbDept.SelectedValue & "' "
        Else
            vFilter += " exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='department' and Property_Value=DeptCd) "
        End If

        vFilter += iif(vFilter <> "", " and ", " where ")
        If cmbSection.SelectedValue <> "All" Then 'filter by section
            vFilter += " SectionCd='" & cmbSection.SelectedValue & "' "
        Else
            vFilter += " exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='section' and Property_Value=SectionCd) "
        End If

        vFilter += iif(vFilter <> "", " and ", " where ")
        If cmbUnit.SelectedValue <> "All" Then  'filter by units
            vFilter += " UnitCd='" & cmbUnit.SelectedValue & "' "
        Else
            vFilter += " exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='unit' and Property_Value=UnitCd) "
        End If

        vFilter += iif(vFilter <> "", " and ", " where ")
        If cmbemptype.SelectedValue <> "All" Then 'filter by employment types
            vFilter += " EmploymentType='" & cmbemptype.SelectedValue & "' "
        Else
            vFilter += " exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='employmenttype' and Property_Value=EmploymentType) "
        End If

        Select Case Val(cmbStatus.SelectedValue)

            Case 1  'active employees only
                vFilter += iif(vFilter <> "", " and ", " where ")
                vFilter += " Date_Resign is null AND Date_Retired IS NULL AND DateHold IS NULL AND DateDismissed IS NULL"
            Case 0  'inactive employees only
                vFilter += iif(vFilter <> "", " and ", " where ")
                vFilter += " (Date_Resign is not null OR Date_Retired IS NOT NULL OR DateHold IS NOT NULL Or DateDismissed IS NOT NULL)"
        End Select
        '''''''''''''''''''''''''''''''''

        If pSearch <> "" Then
            vFilter += iif(vFilter <> "", " and ", " where ")
            vFilter += cmbType.SelectedValue & " like '" & txtSearch.Text & "%' "
        End If

        da = New SqlClient.SqlDataAdapter("select Emp_Cd,(Emp_Lname+', '+Emp_Fname) as Name, " & _
            "Start_Date,Date_Resign,DateHold from py_emp_master " & _
            vFilter & " order by Emp_Lname,Emp_Fname", c)
        da.Fill(ds, "Employee")
        tblEmp.DataSource = ds.Tables("Employee")
        tblEmp.DataBind()
        c.Dispose()
        da.Dispose()
        ds.Dispose()
        tblEmp.SelectedIndex = -1

    End Sub
    
    Protected Sub cmdClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdClose.Click
        Session.Remove("empcd")
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub tblEmp_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles tblEmp.PageIndexChanging
        tblEmp.PageIndex = e.NewPageIndex
        DataRefresh(txtSearch.Text)
    End Sub

 
    Protected Sub cmdSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSearch.Click
        DataRefresh(txtSearch.Text)
    End Sub

    Private Sub cmdA_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdA.Click, _
            cmdB.Click, cmdC.Click, cmdD.Click, cmdE.Click, cmdF.Click, cmdG.Click, cmdH.Click, cmdI.Click, _
            cmdJ.Click, cmdK.Click, cmdL.Click, cmdM.Click, cmdN.Click, cmdO.Click, cmdP.Click, cmdQ.Click, _
            cmdR.Click, cmdS.Click, cmdT.Click, cmdU.Click, cmdV.Click, cmdW.Click, cmdX.Click, cmdY.Click, cmdZ.Click
        txtSearch.Text = CType(sender, LinkButton).Text
        tblEmp.SelectedIndex = -1
        tblEmp.PageIndex = 0
        DataRefresh(txtSearch.Text)
    End Sub

    Protected Sub cmdSearch0_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSearch0.Click
        If tblEmp.SelectedIndex <> -1 Then
            Session("empcd") = tblEmp.SelectedRow.Cells(0).Text
            vScript = "winletter = window.open('gencontr.aspx?r=" & cmbReport.SelectedValue & _
                "&y1=" & cmbYrFr.SelectedValue & "&y2=" & cmbYrTo.SelectedValue & "&m1=" & cmbStartMonthFr.SelectedValue & _
                "&m2=" & cmbStartMonthTo.SelectedValue & "&m3=" & cmbEndMonthFr.SelectedValue & _
                "&m4=" & cmbEndMonthTo.SelectedValue & _
                "','letter','top=5,left=100,width=800,height=600,toolbar=no,scrollbars=yes,resizable=yes');" & _
                "winletter.focus();"
        Else
            vScript = "alert('Please select an employee first.');"
        End If
    End Sub

   
End Class
