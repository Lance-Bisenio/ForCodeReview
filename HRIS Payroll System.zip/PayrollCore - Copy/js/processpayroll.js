﻿vEmpList="";
var vStart = new Date();
var vEnd   = new Date();
var vPayDate = new Date();
var d = null;
var i = 0;      //loop counter
var vTotalList = 0; //upper bound of list of employees
var vList = ""; //holds the list of employees
var vRow = 0;
var vDistMode = 0; //holds the distribution method

function GetXmlHttpObject() {
    var xmlHttp=null;
    try
      {
      // Firefox, Opera 8.0+, Safari
      xmlHttp=new XMLHttpRequest();
      }
    catch (e)
      {
      // Internet Explorer
      try
        {
        xmlHttp=new ActiveXObject("Msxml2.XMLHTTP");
        }
      catch (e)
        {
        xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
        }
      }
    return xmlHttp;
}




function process(vDist) {
    if(document.getElementById("txtEmplist").value=="") {
        alert("You must click first the Refresh button before starting the process.");
        return;
    }
    var vId = document.getElementById("txtEmplist").value;
    var vMode = document.getElementById("txtMode").value;
    
    if(vMode=="reg") {
        vStart =  new Date(document.getElementById("cmbFrom").value); 
        vEnd = new Date(document.getElementById("cmbTo").value);
    } else {
        vStart = new Date(document.getElementById("txtStartDate").value);
        vEnd = new Date(document.getElementById("txtEndDate").value);
    }
    
    vDistMode = vDist;
    vPayDate = new Date(document.getElementById("txtPayDate").value);
    
    document.getElementById("divWait").style.visibility = "visible";

    //validate xml object
    d = GetXmlHttpObject();
    if(d==null){ 
        alert("Your browser does not support XML object"); 
        return; 
    }

    vList = vId.split(",");
    i=0;
    vTotalList = vList.length - 1;
    processEmp(vDist);
}

function processEmp(vDist) {
    if(i>vTotalList) { 
        document.getElementById("divWait").style.visibility ="hidden";
        if(vTotalList>0) {
            alert("Processing of payroll completed.");
            showMTP();
        }
        return;
    }
    
    document.getElementById("txtId").innerHTML = vList[i];
    document.getElementById("txtCtr").innerHTML = "(" + i + " of " + vTotalList + ")";
    //recalculate
    var url = "processpayroll.aspx";
    var vMode = document.getElementById("txtMode").value;
    /*var vUnion = document.getElementById("chkUnion").checked;

    if (vUnion) {
        vUnion = "1";
    } else {
        vUnion = "0";
    }
      */
        
    if(vMode=="reg") {
        vMode="1";
     } else {
        vMode="0";
     }
     
    d = GetXmlHttpObject();
    d.onreadystatechange=doneProcess;
    d.open("POST",url);
    d.setRequestHeader("Content-Type","application/x-www-form-urlencoded;charset = UTF-8");
    //id = employee id to process
    //s = start cut off date
    //e = end cut off date
    //p = payout date
    //m = payroll mode (1 for regular, 0 for special)
    //a = 1=annualized; 0 = periodical
    //vDist = distribution mode; 0=no distribution;1=equal distribution;2=proportional distribution
    //u = 1=allow union dues deduction; 0 = skip union dues deduction
    
    if(document.getElementById("chkAnnualize").checked) {
        a = 1;
    } else {
        a = 0;
    }
    if(document.getElementById("chkMeal").checked) {
        vMeal=1;
    } else {
        vMeal=0;
    }
    
    /////////////////////////////////////////////////////////////////////
    // MODIFIED BY:  VIC GATCHALIAN                                    //
    // DATE MODIFIED: 3/7/2012                                         //
    // PURPOSE: TO SUPPORT SELECTIVE SPECIAL INCENTIVES LIST           //
    /////////////////////////////////////////////////////////////////////
    ///////////////////////// OLD CODE //////////////////////////////////
    //    param = "id=" + vList[i] + "&s=" + (vStart.getMonth() + 1) + "/" + vStart.getDate() + "/" + vStart.getFullYear() + 
    //        "&e=" + (vEnd.getMonth() + 1) + "/" + vEnd.getDate() + "/" + vEnd.getFullYear() +
    //        "&p=" + (vPayDate.getMonth() + 1) + "/" + vPayDate.getDate() + "/" + vPayDate.getFullYear() +
    //        "&m=" + vMode + "&a=" + a + "&d=" + vDist + "&meal=" + vMeal;
    //////////////////// END OLD CODE ///////////////////////////////////
    
    var vIncentList = document.getElementById("txtIncentList").value;
    param = "id=" + vList[i] + "&s=" + (vStart.getMonth() + 1) + "/" + vStart.getDate() + "/" + vStart.getFullYear() + 
        "&e=" + (vEnd.getMonth() + 1) + "/" + vEnd.getDate() + "/" + vEnd.getFullYear() +
        "&p=" + (vPayDate.getMonth() + 1) + "/" + vPayDate.getDate() + "/" + vPayDate.getFullYear() +
        "&m=" + vMode + "&a=" + a + "&d=" + vDist + "&meal=" + vMeal + "&incent=" + vIncentList +
        "&u=0";
    ///////////// END OF MODIFICATION ////////////////////////////////////
    
    d.send(param);
}

function doneProcess() {
    if(d.readyState=="complete" || d.readyState==4){
        var vReturn = d.responseText;
        if(vReturn=="expired") {
            alert("Your login session has expired. Please re-login to continue...");
            window.location="index.aspx";
            return true;
        }
        if(vReturn!="ok") {
            alert(vReturn);
            return true;
        }
        if(i<=vTotalList) {
            i++;
            processEmp(vDistMode);
        } 
    }
}