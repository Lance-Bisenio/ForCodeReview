    var vStart = new Date();
    var vEnd   = new Date();
    var d = null;
    var c = null;   //cell
    var r = null;   //row
    var i = 0;      //loop counter
    var vTotalList = 0; //upper bound of list of employees
    var vList = ""; //holds the list of employees
    var n = "";
    var sw = 0;
    var row = 0;
    var rperpg = 15;    //# of rows per page
    var tpages = 0;     //total number of pages
    var pgStart = 0;    //start index of the page
    var pgEnd = 0;      //end index of the page
    var pgCurr = 1;     //current page #
    
	

	
	function show(pEmp,pDate,pLinkId,pShift,pTime) {
		win=window.open("showshift.aspx?id=" + pEmp + "&date=" + pDate + "&linkid="+pLinkId+"&shift=" + pShift + "&stime=" + pTime,"win",
			"top=150,left=200,width=400,height=280,scrollbar=no,toolbar=no");
		win.focus();
	}
	
	function showemps(pShift,pDate) {
		win=window.open("showmancount.aspx?shiftcd=" + pShift + "&date=" + pDate,"win","toolbar=no,width=400,height=400,left=100,top=100");
		win.focus();
	}
	function checkprofile() {
		val = document.getElementById("cmbProfile").value;
		if(val=="All") {
			alert("You must select a specific profile first.");
			return false;
		} else  {
			return true;
		}
	}
	
	function validateshift() {
		vSun = document.getElementById("cmbShiftSun").value;
		vMon = document.getElementById("cmbShiftMon").value;
		vTue = document.getElementById("cmbShiftTue").value;
		vWed = document.getElementById("cmbShiftWed").value;
		vThu = document.getElementById("cmbShiftThu").value;
		vFri = document.getElementById("cmbShiftFri").value;
		vSat = document.getElementById("cmbShiftSat").value;
		
		if(vSun=="All" || vMon=="All" || vTue=="All" || vWed=="All" || vThu=="All" || vFri=="All" || vSat=="All" || vSun=="All") {
			alert("Cannot apply the profile right now because you must select a specific schedule for each day.");
			return false;
		} else {
			win=window.open("profile.aspx?sun=" +  vSun + "&mon=" + vMon + "&tue=" + vTue + "&wed=" + vWed +
				"&thu=" + vThu + "&fri=" + vFri + "&sat=" + vSat,
				"win","toolbar=no,scrollbar=no,top=200,left=200,width=650,height=400");
		}
	}
	
	function validate() {
		vSun = document.getElementById("cmbShiftSun").value;
		vMon = document.getElementById("cmbShiftMon").value;
		vTue = document.getElementById("cmbShiftTue").value;
		vWed = document.getElementById("cmbShiftWed").value;
		vThu = document.getElementById("cmbShiftThu").value;
		vFri = document.getElementById("cmbShiftFri").value;
		vSat = document.getElementById("cmbShiftSat").value;
		if(vSun=="All" || vMon=="All" || vTue=="All" || vWed=="All" || vThu=="All" || vFri=="All" || vSun=="All") {
			alert("Cannot apply the profile right now because you must select a specific schedule for each day.");
			return false;
		} else {
			rowcount = document.getElementById("txtRows").value;
			sw=0;
			for(iCtr=1;iCtr<=row;iCtr++) {
				rowval=document.getElementById("r" + iCtr).value;
				if(rowval=="on") {
					sw=1;
					break;
				}
			}
			if(sw==1) {
				return confirm("Are you sure you want to apply the profile to the selected employee(s)?");
			} else {
				alert("You must select at least one employee.");
				return false;
			}
		}
	}
	
	function getstat(d) {
		document.getElementById("txtDate").value =  d;
		refresh();
	}
	
	function across(id) {
	    c = id.substring(1);
		rowval = document.getElementById(id).checked;
		colcount = document.getElementById("txtCols").value;
		rowcount = document.getElementById("txtRows").value;
		document.getElementById("txtEmp").value = "";
		
		for(r=1;r<=row;r++) {
			rowv=document.getElementById("r" + r).checked;
			if(rowv) {
				document.getElementById("txtEmp").value += document.getElementById("r" + r).value + ",";
			} // if
		} // for
		
		if(rowval) {
			for(iCtr=1;iCtr<=colcount;iCtr++) {
			    if(document.getElementById("c"+iCtr)!=null) {
			        colval=document.getElementById("c" + iCtr).checked;
				    if(colval) {
					    document.getElementById("r" + c + "c" + iCtr+"chk").checked = "checked";
				    }  else {
					    document.getElementById("r" + c + "c" + iCtr+"chk").checked = "";
				    }  //if
				}
			} // for
		} else {
			for(iCtr=1;iCtr<=colcount;iCtr++) {
				document.getElementById("r" + c + "c" + iCtr+"chk").checked = "";
			}
		}	// if
	}
	
	function down(c) {
		colval = document.getElementById("c" + c).checked;
		rowcount = document.getElementById("txtRows").value;
		
		if(colval) {
			for(r=1;r<=row;r++) {
				rowval=document.getElementById("r" + r).checked;
				if(rowval) {
				    if(document.getElementById("r" + r + "c" + c + "chk")!=null) {
					    document.getElementById("r" + r + "c" + c +"chk").checked = "checked";
					}
				} // if
			} // for
		} else {
			for(r=1;r<=row;r++) {
			    if(document.getElementById("r" + r + "c" + c + "chk")!=null) {
				    document.getElementById("r" + r + "c" + c+"chk").checked="";
				}
			}
		}//if
	}
	function selectallcol() {
		c = document.getElementById("c_all").checked;
		rowcount = document.getElementById("txtRows").value;
		colcount = document.getElementById("txtCols").value;
		if(c) {
			for(iCtr=1;iCtr<=colcount;iCtr++) {
			    if(document.getElementById("c" + iCtr)!=null) {
				    document.getElementById("c" + iCtr).checked = "checked";
				}
			} // for
		} else {
			for(iCtr=1;iCtr<=colcount;iCtr++) {
			    if(document.getElementById("c" + iCtr)!=null) {
				    document.getElementById("c" + iCtr).checked = "";
				}
			}
		}
		for(r=1;r<=row;r++) {
			across("r"+r);
		}
	}
	function selectallrow() {
		r = document.getElementById("r_all").checked;
		rowcount = document.getElementById("txtRows").value;
		colcount = document.getElementById("txtCols").value;
		document.getElementById("txtEmp").value = "";
		if(r) {
			for(iCtr=1;iCtr<=row;iCtr++) {
			    if(document.getElementById("r" + iCtr)!=null) {
				    document.getElementById("r" + iCtr).checked = "checked";
				    document.getElementById("txtEmp").value += document.getElementById("r" + iCtr).value + ",";
				}
			} // for
		} else {
			for(iCtr=1;iCtr<=row;iCtr++) {
			    if(document.getElementById("r" + iCtr)!=null) {
				    document.getElementById("r" + iCtr).checked = "";
				}
			}
		}
		for(c=1;c<=colcount;c++) {
			down(c);
		}
	}

	function setsked() {
		sw=0;
		rowcount = document.getElementById("txtRows").value;
		colcount = document.getElementById("txtCols").value;
		for(r=1;r<=row;r++) {
			for(c=1;c<=colcount;c++) {
			    if(document.getElementById("r" + r + "c" + c + "chk")!=null) {
				    cellval=document.getElementById("r" + r + "c" + c + "chk").checked;
				    if(cellval==true) {
					    sw=1;
					    break;
				    }
				}
			} // for c
			if(sw==1) { break; }
		} // r
		
		if(sw==1)
		{
		    vEmp = "";
		    vEmpNdDate = "";
		    vDate = "";
		    
			document.getElementById("txtShift").value = "";
			document.getElementById("txtEmpCd").value = "";
		    
		    // get EmpCd and Date
		    for(r=1;r<=row;r++) {
		        vEmp = document.getElementById("r" + r).value;
			    for(c=1;c<=colcount;c++) {
			        if(document.getElementById("r" + r + "c" + c + "chk")!=null) {
				        cellval=document.getElementById("r" + r + "c" + c + "chk").checked;
				        if(cellval==true) {
				            vDate=document.getElementById("r" + r + "c" + c + "chk").name;
                            vEmpNdDate += vEmp+"="+vDate+",";
				        }
				    }
			    } // for c
			} // for r
		    
			document.getElementById("txtEmpCd").value = vEmpNdDate;
			win=window.open("batchshift.aspx","win","top=200,left=300,scrollbar=no,toolbar=no,width=400,height=200");
		} else {
			alert("You must select at least one cell.");
			return false;
		}
	}
	 
	 function GetXmlHttpObject() {
        var xmlHttp=null;
        try
          {
          // Firefox, Opera 8.0+, Safari
          xmlHttp=new XMLHttpRequest();
          }
        catch (e)
          {
          // Internet Explorer
          try
            {
            xmlHttp=new ActiveXObject("Msxml2.XMLHTTP");
            }
          catch (e)
            {
            xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
            }
          }
        return xmlHttp;
    }
        
    
    function changepage(np) {
        pgCurr = np;
        pgStart = (pgCurr - 1) * rperpg;
        pgEnd = ((pgCurr - 1) * rperpg) + (rperpg - 1);
        refresh();
    }
    
	function refresh() {
	    document.getElementById("divWait").style.visibility = "visible";
	    //validate xml object
	    d = GetXmlHttpObject();
	    if(d==null){ 
            alert("Your browser does not support XML object"); 
            return; 
        }
	    
	    //dump headers
	    vDOW = new Array();
	    vDOW[0] = "Su";
	    vDOW[1] = "Mo";
	    vDOW[2] = "Tu";
	    vDOW[3] = "We";
	    vDOW[4] = "Th";
	    vDOW[5] = "Fr";
	    vDOW[6] = "Sa";
        //vStart = new Date(document.getElementById("cmbPeriod").value + "/" + document.getElementById("cmbYear").value);
	    vStart = new Date(document.getElementById("txtFromPeriod").value);
	    
        //if(vStart.getDate() > 15)
        //{
            //vEnd = new Date(vStart.getFullYear(), vStart.getMonth(), document.getElementById("txtMonthEnd").value);
        //}else{
	    //vEnd = new Date(vStart.getFullYear(), vStart.getMonth(), vStart.getDate() + 14);
	    vEnd = new Date(document.getElementById("txtEndPeriod").value);
        //}
	    colVal = Math.abs(parseInt((vEnd.getDate() - vStart.getDate())) + 1);
	    
        document.getElementById("txtCols").value = colVal;
        
	    c = document.getElementById("data");
        vDump = "<table id='tblContent' border='1' cellpadding='0' cellspacing='0' style='border-collapse:collapse; width: 99%;'>" +
            "<tr class='odd' title='Click the day to view the shift man count for the selected day...' >" +
            "<th valign='top' style='width:40px' class='labelL'><input type='checkbox' id='c_all' style='width:15px;'" +
            "onclick='selectallcol();' /><br/>Id<br/><input type='checkbox' id='r_all' style='width:15px;'" +
            "onclick='selectallrow();' /></th><th style='width:88px' class='labelL'>Name</th>";
        vTmp = vStart;
        //for(i=1;i<=colVal;i++) {
        while (vTmp <= vEnd) {
            vDump += "<th style='width:10px' class='labelL'><input type='checkbox' id='c" + i + "' name='chk" + i +
                "' style='width:15px;' onclick='down(&quot;" + i + "&quot;);' /><br/>" +
                vDOW[vTmp.getDay()] + "<br/><a href='javascript:getstat(&quot;" + vTmp.getFullYear() + "/" + (vTmp.getMonth() + 1) +
                "/" + vTmp.getDate() + "&quot;)'>" + vTmp.getDate() + "</a></th>";
            vTmp = new Date(vTmp.getFullYear(),vTmp.getMonth(),vTmp.getDate() + 1);
        }
        vDump += "</tr></table>";
        c.innerHTML = vDump;
	    //get list of employees
	    fetchEmp();
	}
	
	function fetchEmp() {
        var url = "getemplist.aspx";
        vRc = document.getElementById("cmbRC").value;
        vOfc = document.getElementById("cmbOfc").value;
        vDiv = document.getElementById("cmbDiv").value;
        vDept = document.getElementById("cmbDept").value;
        vSection = document.getElementById("cmbSection").value;
        vUnit = document.getElementById("cmbUnit").value;
        vRank = document.getElementById("cmbEmpType").value;
        vStatus = document.getElementById("cmbEmpStatus").value;
        vSearchLike = document.getElementById("txtQuickSearch").value;
        vSearchBy = document.getElementById("cmbSearchBy").value;
        vPayMode = document.getElementById("cmbPayMode").value;
        
        d = GetXmlHttpObject();
        d.onreadystatechange=getEmpList;
        d.open("POST",url);
        d.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset = UTF-8");
        d.send("rc=" + vRc + "&ofc=" + vOfc + "&div=" + vDiv + "&dept=" + vDept + "&section=" + vSection + "&unit=" + vUnit + 
            "&rank=" + vRank + "&field=" + vSearchBy + "&search=" + vSearchLike + "&status=" + vStatus + "&paymode=" + vPayMode);
	}
	
	function getEmpList() {
	    if(d.readyState=="complete" || d.readyState==4){
           var vReturn = d.responseText;
           if(vReturn=="expired") {
                alert("Your login session has expired. You must re-login again.");
                window.location = "index.aspx";
                return;
           }
           vList = vReturn.split("|");
           //i=0;
           
           vTotalList = vList.length - 1;       //total arraylist
           tpages = Math.ceil(vTotalList / rperpg);        // total number of pages
           var iPages=1;
           var vPageDump = "";
           var vColor = "blue";
           for (iPages = 1; iPages <= tpages; iPages++) {
               vColor = "blue";
               if (iPages == pgCurr) {
                   vColor = "red";
               }
                vPageDump+="<a href='javascript:changepage(" + iPages + ")' style='color:" + vColor + ";' >" + iPages + "</a> ";
           }
           document.getElementById("pages").innerHTML = vPageDump;
           pgStart = (pgCurr - 1) * rperpg;
           pgEnd =  ((pgCurr - 1) * rperpg) + (rperpg - 1);
           document.getElementById("txtRows").value = vTotalList+1;
           i = pgStart;   
          
           row=0;
           dump();
        }
	}
	
	function dump() {
	    if(i>vTotalList) { 
            document.getElementById("divWait").style.visibility ="hidden";
            alert("Processing complete.");
            sw = 0;
            return;
        }
        
        
        n = vList[i].split("~");
        t = document.getElementById("tblContent");
        r = t.insertRow(-1);
        if(sw==0) {
            //r.setAttribute("style","background-color:#DDDDDD");
            r.style.backgroundColor = "#EEEEEE";
            sw=1;
        } else {
            //r.setAttribute("style","background-color:#AAAAAA");
            r.style.backgroundColor = "#FFFFFF";
            sw=0;
        }

        //emp id
        c = r.insertCell(-1);
        c.setAttribute("class", "labelL");
        e = document.createElement("input");
        
        e.type = "checkbox";
        e.id = "r" + parseInt(row + 1);
        e.name = "chk" + n[0];
        e.value = n[0];
        e.onclick = function () { across(this.id); }
        //e.onclick = "across('" + parseInt(row+1) + "')";
        c.appendChild(e);
        
        t = document.createTextNode(n[0]);
        c.appendChild(t);
        
        //emp name
        c = r.insertCell(-1);
        //c.align="left";
        c.setAttribute("class", "labelL");
        c.style.width="150px";
        c.verticalAlign="bottom";
        t = document.createTextNode(n[1]);
        c.appendChild(t);
        
        //get shifts
        var url = "getshifts.aspx";
        d = GetXmlHttpObject();
        d.onreadystatechange=parseShift;
        d.open("POST",url);
        d.setRequestHeader("Content-Type","application/x-www-form-urlencoded;charset = UTF-8");
        param = "id=" + n[0] + "&s=" + (vStart.getMonth() + 1) + "/" + vStart.getDate() + "/" + vStart.getFullYear() + 
            "&e=" + (vEnd.getMonth() + 1) + "/" + vEnd.getDate() + "/" + vEnd.getFullYear();
        row++;
        d.send(param);
	}
	
	function parseShift() {
	    if (d.readyState == "complete" || d.readyState == 4) {
	        var vReturn = d.responseText;
	        var vDays = vReturn.split("~");

	        //vStartDay = vStart.getDate();
	        vStartDay = vStart.getDate() - 1;
	        //if(vStartDay==16) {
	        //   vStartDay = 15;
	        //} else {
	        //   vStartDay = 0;
	        //}

	        for (ctr = 0; ctr < vDays.length; ctr++) {
	            vData = vDays[ctr].split("-");

	            //create checkbox
	            e = document.createElement("input");
	            e.id = "r" + row + "c" + parseInt(ctr + 1) + "chk";
	            vTmp = new Date(vStart.getFullYear(), vStart.getMonth(), (ctr + 1 + vStartDay));

	            //e.name = vStart.getFullYear() + "/" + (vStart.getMonth() + 1) + "/" + (ctr + 1 + vStartDay)
	            e.name = vTmp.getFullYear() + "/" + (vTmp.getMonth() + 1) + "/" + vTmp.getDate();

	            e.type = "checkbox";

	            c = r.insertCell(-1);
	            c.setAttribute("class", "labelC");
	            c.style.align = "center";
	            c.verticalAlign = "top";
	            c.style.width = "20px";

	            c.appendChild(e);

	            vShiftList = vData[0].split(",");
	            for (iCtr = 0; iCtr <= vShiftList.length - 1; iCtr++) {
	                t = document.createTextNode(vShiftList[iCtr] + (iCtr == vShiftList.length - 1 ? "" : ","));
	                a = document.createElement("a");
	                a.id = "r" + row + "c" + parseInt(ctr + 1);
	                a.appendChild(t);
	                vTmp = new Date(vStart.getFullYear(), vStart.getMonth(), (ctr + 1 + vStartDay));

	                if (vData[0] == "__") {    //empty shift
	                    //a.href = 'javascript:show("' + n[0] + '","' + vStart.getFullYear() + "/" + (vStart.getMonth() + 1) + "/" + (ctr + 1 + vStartDay) +
	                    //'","' + a.id + '","","");';
	                    a.href = 'javascript:show("' + n[0] + '","' + vTmp.getFullYear() + "/" + (vTmp.getMonth() + 1) + "/" + vTmp.getDate() +
                         '","' + a.id + '","","");';
	                } else {
	                    //a.href = 'javascript:show("' + n[0] + '","' + vStart.getFullYear() + "/" + (vStart.getMonth() + 1) + "/" + (ctr + 1 + vStartDay) +
	                    // '","' + a.id + '","' + vShiftList[iCtr] + '","");';
	                    a.href = 'javascript:show("' + n[0] + '","' + vTmp.getFullYear() + "/" + (vTmp.getMonth() + 1) + "/" + vTmp.getDate() +
                         '","' + a.id + '","' + vShiftList[iCtr] + '","");';
	                }
	                c.appendChild(a);
	            }

	            if (vData[1] != 0) {
	                t = document.createTextNode("-" + vData[1]);
	                s = document.createElement("span");
	                s.appendChild(t);
	                s.style.color = "red";
	                c.appendChild(s);
	            }
	        }
	        if (i == pgEnd) {
	            document.getElementById("divWait").style.visibility = "hidden";
	            return;
	        }
	        if (i <= vTotalList) {
	            i++;
	            dump();
	        }
	    }
	}
	