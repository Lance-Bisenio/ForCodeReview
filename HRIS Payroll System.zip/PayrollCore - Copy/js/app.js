﻿/*
**
**Application Javascript File
**
*/
function initveilimg(emp_code,emp_name)
{
    //div box for image upload for Watson Wyatt by JMM - ICBSI
    /*create the transparent veil to disable user to interact with the underlying page temporarily 
    and make the upload box modal*/
    /*var transp_veil = document.createElement("div");
    transp_veil.setAttribute("id","transp_veil");
    $("body").append(transp_veil); //append to manipulate the DOM element using jquery
    $("#transp_veil").css( //manipulate the CSS properties
        {
            position: "absolute",
            top: "0",
            left: "0",
            width: '100%',
            height: '100%',
            'background-color': 'black',
            'z-order': '2'
        }
    ).hide(); */
    
    //create the upload box
    var upload_box = document.createElement("div");
	
	//set the upload box properties
    $(upload_box).attr(
        {
            id: 'upload_box',
            align: 'center'
        }
    ).hide();
	
	//append the upload box to body
    $("body").append(upload_box);
	
	//set the upload box's CSS
    $("#upload_box").css(
        {
            position: "absolute",
            top: "5px",
            left: "5px",
            width: "400px",
            height: "110px",
            'background-color': "white",
            'border': "solid 1px gray",
            'z-order': '3'
        }
    );
    
    var titlebox = document.createElement("h3");
    $(titlebox).attr('id','titlebox');
    $(titlebox).css("margin","0px");
    $(titlebox).html("Choose Image to Upload for : " + emp_code + "<br /><b style='color:blue;'>" + emp_name + "</b>");
    $(titlebox).addClass("titlepanel");
    
    var frm_upload = document.createElement("form");
    $(frm_upload).attr(
        {
            id: 'frm_upload',
            name: 'frm_upload',
            enctype: 'multipart/form-data',
            runat: 'server',
            action: 'upload_handler.aspx',
            target: 'temp_iframe',
            method: 'post'
        }
    );
    $("#frm_upload").css(
        {
            padding: '0px',
            margin: '0px'
        }
    );
    $("#upload_box").append(titlebox);
    $("#upload_box").append("<br />");
    $("#upload_box").append(frm_upload);
    
    //create the input box to hold the file upload string
    var filebox = document.createElement("input");
    //filebox.setAttribute("id","filebox");
    $(filebox).attr(
        {
            id: 'filebox',
            type: 'file',
            runat: 'server',
            name: 'filebox'
        }
    );
    $(filebox).css(
        {
            position: 'relative',
            padding: '2px',
            border: "solid 1px gray"
        }
    );
    $("#frm_upload").append(filebox);  
    
    //create the submit button
    var uploadbutton = document.createElement("input");
    //uploadbutton.setAttribute("id","uploadbutton");
    $(uploadbutton).attr(
        {
            id: "uploadbutton",
            type: "submit",
            value: "Upload",
            runat: "server",
            onclick: "showloading()"
        }
    ).addClass("linuxpanelbutton");
    $("#frm_upload").append("&nbsp;");
    $("#frm_upload").append(uploadbutton);
    //create the close button
    var closebutton = document.createElement("span");
    $(closebutton).attr(
        {
            id: "closetxt",
            name: "closetxt"
        }
    ).html("Close");
    $(closebutton).css(
        {
            cursor: "pointer",
            'text-decoration': "underline",
            'font-size': "1.2em",
            'font-weight': "bold"
        }
    );
    $(closebutton).click(
        function(){
            closewindows();
        }   
    );
    
	/*var temp_iframe = document.createElement("iframe");
    $(temp_iframe).attr(
        {
            id: "temp_iframe",
            name: "temp_iframe",
            src: "blank.html"
        }
    );
    $(temp_iframe).css(
        {
            height: "0px",
            border: "0px",
            width: "0px"
        }
    );*/
    
    var txtload = document.createElement("span");
    $(txtload).attr("id","txtload").html("Processing Image...Please wait...");
    $(txtload).css(
        {
            'font-size': '1.1em',
            'font-weight':'bold',
            'color': 'green'
        }
    ).hide();
    $("#frm_upload").append("<br />");
    $("#frm_upload").append("<br />");
    $("#frm_upload").append(closebutton);
    $("#frm_upload").append("<br />");
    $("#frm_upload").append(txtload);
    $("#frm_upload").append("<br />");
    $("#frm_upload").append("<input id='usrid' name='usrid' type='hidden' value='" + emp_code + "' />")
	//$("#upload_box").append(temp_iframe);
    $("#upload_box").append("<iframe name='temp_iframe' id='temp_iframe' style='border:0px;width:0px;height:0px' src='blank.html'></iframe>");
    /*if(window.frames["temp_iframe"].name!="temp_iframe"){
        window.frames["temp_iframe"].name="temp_iframe";
     }*/
    //$("#transp_veil").show().fadeTo(300,0.8);
    $("#page").hide();
    $("#upload_box").show().fadeTo(800,1);
    
}

function successupload(fname){
    //
    $("#txtload").html("Upload Success!");
    $(".imgdesign").attr("src","blank.gif");
    $(".imgdesign").attr("src","../kiosk/pics/"+fname);
}

function failupload(){
    //
    $("#txtload").html("Upload Failed!");
}

function closewindows(){
    $("#upload_box").fadeOut("slow", function(){$(this).remove();$("#page").show()});
    //$("#transp_veil").fadeOut("slow", function(){$(this).remove();});
    
}

function nofiletoupload(){
    $("#txtload").html("No File to Save!");
    alert("No File to Save!");
}

function invupload(){
    $("#txtload").html("Not a Valid Image File!");
}

function showloading(){
    
    $("#txtload").show();
}

//$(document).ready(
//    function(){
//        $("#msg").hide();
//        if($.browser.msie){
//            $("#msg").show();
//        }
//    }
//);