function GetXmlHttpObject() {
                var xmlHttp=null;
                try
                  {
                  // Firefox, Opera 8.0+, Safari
                  xmlHttp=new XMLHttpRequest();
                  }
                catch (e)
                  {
                  // Internet Explorer
                  try
                    {
                    xmlHttp=new ActiveXObject("Msxml2.XMLHTTP");
                    }
                  catch (e)
                    {
                    xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
                    }
                  }
                return xmlHttp;
            }
            
            var vEmpList   = "";
            var d          = null;
            var i          = 0;      //loop counter
            var iCtr       = 0;   //loop counter
            var vTotalList = 0; //upper bound of list of employees
            var vList      = ""; //holds the list of employees
            var n          = "";
            var vDate      = new Date();
            var vbounds    = 0;  //holds the start and end day of the loop
            var sTotal     = 0;  //holds the sub-total of Hours
            var gTotal     = 0; //holds the grand-total of Hours
            var sTotalAmt  = 0; //holds the sub-total of amount
            var gTotalAmt  = 0; //holds the grand-total of amount
            var fracTrunc  = 0; //holds the value if fraction of an hour is truncated
            var r          = "";
            function recalculate() {
                document.getElementById("divWait").style.visibility = "visible";
                
                document.getElementById("content").innerHTML = "<table border='1' width='95%' cellspacing='0' id='dump'>" + 
                        "<tr class='titleBar'><th align='center'>Emp. Id</th>" +
                        "<th align='center'>Employee Name</th>" +
                        "<th align='center'>Trans. Date</th>" + 
                        "<th align='center'>Sched. Out</th>" +
                        "<th align='center'>Actual Out</th>" +
                        "<th align='center'>Excess Hrs.</th>" +
                        "<th align='center'>Approved Hrs.</th>" +
                        "<th align='center'>Hrs. Credited</th>" +
                        "<th align='center'>Amt. Credited</th></tr></table>";
                
                //validate xml object
	            d = GetXmlHttpObject();
	            if(d==null){ 
                    alert("Your browser does not support XML object"); 
                    return; 
                }
	            d.onreadystatechange=Emplist;
	            d.open("POST","getemplist.aspx");
	            d.setRequestHeader("Content-Type","application/x-www-form-urlencoded;charset = UTF-8");
	            param = "rc=" + document.getElementById("cmbRC").value +
	                "&ofc=" + document.getElementById("cmbOfc").value +
	                "&div=" + document.getElementById("cmbDiv").value +
	                "&dept=" + document.getElementById("cmbDept").value + 
	                "&section=" + document.getElementById("cmbSection").value +
	                "&unit=" + document.getElementById("cmbUnit").value +
	                "&search=" + document.getElementById("txtSearch").value +
	                "&field=" + document.getElementById("cmbType").value +
	                "&ofilter=and RegOt > 0" +
	                "&ofield=FractionTruncated";
                d.send(param);
            }
            
            function Emplist() {
                if(d.readyState=="complete" || d.readyState==4){
                    var vReturn = d.responseText;
                    
                    if(vReturn=="expired") {
                        alert("Your login session has expired. Please re-login to continue...");
                        window.location="index.aspx";
                        return;
                    }
                    if(vReturn=="") {
                        document.getElementById("divWait").style.visibility ="hidden";
                        alert("No employee list retrieved.");
                        return;
                    }
                    vList = vReturn.split("|");
                    i=0;
	                vTotalList = vList.length - 1;
	                //process dates
                    vPeriod = document.getElementById("cmbPeriod").value.split("/");
                    vbounds = vPeriod[1].split("-");
                    gTotal=0;
                    gTotalAmt=0;
	                processEmp();   
                }
            }
            
            function processEmp() {
                if(i>vTotalList) {
                    t = document.getElementById("dump");
                    r = t.insertRow(-1);
                    c = r.insertCell(-1);
                    c.colSpan="7";
                    c.align="right";
                    txt = document.createTextNode("GRAND TOTAL==>");
                    c.appendChild(txt);
                    c = r.insertCell(-1);
                    c.align="right";
                    txt = document.createTextNode(gTotal + " hr(s)");
                    c.appendChild(txt);
                    c = r.insertCell(-1);
                    c.align="right";
                    txt = document.createTextNode("Php " + gTotalAmt);
                    c.appendChild(txt);
                    
                    document.getElementById("divWait").style.visibility ="hidden";
                    alert("Processing complete.");
                    return;
                }
                n = vList[i].split("~");
                document.getElementById("txtId").innerHTML = n[0];
                
                sTotal=0;
                sTotalAmt=0;
                ictr=vbounds[0];
                //process OT Allowance
                processOT();
            }
            
            function processOT() {
                if(ictr > vbounds[1]) {
                    //dump sub-total
                    if((document.getElementById("chkZero").checked && sTotal > 0) || !document.getElementById("chkZero").checked) {      //dump only if total is not zero
                        if(n[2]=="1") { //truncate fraction of an hour
                            sTotal = Math.floor(sTotal);
                        }
                        t = document.getElementById("dump");
                        r = t.insertRow(-1);
                        c = r.insertCell(-1);
                        c.colSpan="7";
                        c.align="right";
                        txt = document.createTextNode("Total Overtime Allowance of " + n[1] + "==>");
                        c.appendChild(txt);
                        
                        txt = document.createTextNode(sTotal + " hr(s)");
                        c = r.insertCell(-1);
                        c.align="right";
                        c.appendChild(txt);
                        
                        //calculate ot allowance amount
                        var url = "getotamount.aspx";
                        d = GetXmlHttpObject();
                        d.onreadystatechange=dumpOTAmt;
                        d.open("POST",url);
                        d.setRequestHeader("Content-Type","application/x-www-form-urlencoded;charset = UTF-8");
                        param = "id=" + n[0] + "&h=" + sTotal;
                        d.send(param);
                    } else {
                        gTotal+=sTotal;
                        gTotalAmt+=sTotalAmt;
                        sTotal=0;
                        sTotalAmt=0;
                        if(i<=vTotalList) {
                            i++;
                            processEmp();
                        }   
                    }
                    return;
                }
                var url = "getotallowance.aspx";
                d = GetXmlHttpObject();
                d.onreadystatechange=doneOT;
                d.open("POST",url);
                d.setRequestHeader("Content-Type","application/x-www-form-urlencoded;charset = UTF-8");
                param = "id=" + n[0] + "&p=" + document.getElementById("cmbPeriod").value + "&d=" + ictr;
                d.send(param);
            }
            
            function dumpOTAmt() {
                if(d.readyState=="complete" || d.readyState==4){
                    var vReturn = d.responseText;
                    if(vReturn=="expired") {
                        alert("Your login session has expired. Please re-login to continue...");
                        window.location="index.aspx";
                        return;
                    }
                    sTotalAmt += parseFloat(vReturn);
                    txt = document.createTextNode("Php " + sTotalAmt);
                    c = r.insertCell(-1);
                    c.align="right";
                    c.appendChild(txt);
                    
                    gTotal+=sTotal;
                    gTotalAmt+=sTotalAmt;
                    sTotal=0;
                    sTotalAmt=0;
                    if(i<=vTotalList) {
                        i++;
                        processEmp();
                    }   
                }
            }
            
            
            function doneOT() {
                if(d.readyState=="complete" || d.readyState==4){
                    var vReturn = d.responseText;
                    if(vReturn=="expired") {
                        alert("Your login session has expired. Please re-login to continue...");
                        window.location="index.aspx";
                        return;
                    }
                    
                    if(ictr <= vbounds[1]) {
                        vData = vReturn.split("|");
                        if((parseFloat(vData[4]) > 0 && document.getElementById("chkZero").checked) || !document.getElementById("chkZero").checked) {      //dump only if date has hrs credit value
                            sTotal+=parseFloat(vData[4]);
                            sTotalAmt+=parseFloat(vData[5]);
                            //insert the cell
                            t = document.getElementById("dump");
                            
                            r = t.insertRow(-1);
                            c = r.insertCell(-1);
                            txt = document.createTextNode(n[0]);
                            c.appendChild(txt);
                            txt = document.createTextNode(n[1]);
                            c = r.insertCell(-1);
                            c.appendChild(txt);
                            c.align="left";    
                            txt = document.createTextNode(document.getElementById("cmbMonth").value + "/" + ictr + "/" + vDate.getFullYear());
                            c = r.insertCell(-1);
                            c.appendChild(txt);
                            c.align="right";
                            
                            
                            for(iLoop=0;iLoop<=vData.length - 1;iLoop++) {
                                c = r.insertCell(-1);
                                c.align="right";
                                txt = document.createTextNode(vData[iLoop]);
                                c.appendChild(txt);
                            }
                        }
                        ictr++;
                        processOT();
                    }
                }
            }