﻿obj = null;
var accttype = "";
function GetXmlHttpObject() {
    var xmlHttp=null;
    try
      {
      // Firefox, Opera 8.0+, Safari
      xmlHttp=new XMLHttpRequest();
      }
    catch (e)
      {
      // Internet Explorer
      try
        {
        xmlHttp=new ActiveXObject("Msxml2.XMLHTTP");
        }
      catch (e)
        {
        xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
        }
      }
    return xmlHttp;
}   //end xmlhttpobject

function generate() {
    bank = document.getElementById("cmbBank").value;
    url = bank + ".aspx";
    url = url.toLowerCase();

    //cutoff = new Date(document.getElementById("cmbCutOff").value);
    cutoff = new Date(document.getElementById("txtFrom").value);
    cutoffE = new Date(document.getElementById("txtTo").value);
    
    paydate = new Date(document.getElementById("txtPayDate").value);
    creditdate = new Date(document.getElementById("txtCreditDate").value);
    rc = document.getElementById("cmbRC").value;
    agency = document.getElementById("cmbOffice").value;
    div = document.getElementById("cmbDiv").value;
    rank = document.getElementById("txtRank").value;
    stat = document.getElementById("cmbStatus").value;
    
    if(document.getElementById("rdoType_0").checked) {
        accttype = "SA";
    } else if(document.getElementById("rdoType_1").checked) {
        accttype = "CA";
    } else if(document.getElementById("rdoType_3").checked) {
        accttype = "BOTH";
    } else {
        accttype = "NA";
        url = "noacct.aspx";
    }
    
    testdate = /\b\d{1,2}[\/-]\d{1,2}[\/-]\d{4}\b/;
    if(!testdate.test(document.getElementById("txtCreditDate").value)) {
        alert("Credit date field should have this format: mm/dd/yyyy");
        return false;
    }

    //validate xml object
    obj = GetXmlHttpObject();
    if(obj==null){ 
        alert("Your browser does not support XML object"); 
        return; 
    }
    
    document.getElementById("divWait").style.visibility = "visible";
    document.getElementById("frmBank").src = "";
    obj.onreadystatechange=doneProcess;
    obj.open("POST",url);
    obj.setRequestHeader("Content-Type","application/x-www-form-urlencoded;charset = UTF-8");

    param = "cutoff=" + (cutoff.getMonth() + 1) + "/" + cutoff.getDate() + "/" + cutoff.getFullYear() +
        "&cutoffE=" + (cutoffE.getMonth() + 1) + "/" + cutoffE.getDate() + "/" + cutoffE.getFullYear() + 
        "&payout=" + (paydate.getMonth() + 1) + "/" + paydate.getDate() + "/" + paydate.getFullYear() +
        "&credit=" + (creditdate.getMonth() + 1) + "/" + creditdate.getDate() + "/" + creditdate.getFullYear() +
        "&rc=" + rc + 
        "&agency=" + agency +
        "&div=" + div +
        "&rank=" + rank + 
        "&acct=" + accttype +
        "&bank=" + bank +
        "&stat=" + stat;
   
    obj.send(param);
}

function doneProcess() {
    if(obj.readyState=="complete" || obj.readyState==4){
        var vReturn = obj.responseText;
        if(vReturn=="expired") {
            alert("Your login session has expired. Please re-login to continue...");
            window.location="index.aspx";
            return;
        }
        if(vReturn=="error") {
            alert("An error occurred while trying to generate the advise. Please see your administrator");
            return;
        }
        
        bank = document.getElementById("cmbBank").value;
        vfiles = vReturn.split("~");
        document.getElementById("frmBank").src = vfiles[0];
        document.getElementById("divWait").style.visibility = "hidden";
        //document.getElementById("lnkDownload").href = vfiles[1];
        if (accttype != "NA") {
            winbank = window.open(vfiles[1], "bankwin", "top=100,left=100,width=800,height=600,resizable=yes,scrollbars=yes");
            if (bank == "MBTC" || bank=="RCBC" || bank=="BDO") {
                wintop = window.open(vfiles[2], "topwin", "top=100,left=400,width=800,height=600,resizable=yes,scrollbars=yes");
            }
            winbank.focus();
        }
    }
}