﻿// JScript File


function compute() {
    document.getElementById("txtBal").value = (parseFloat(document.getElementById("txtLoanAmt").value) +
        parseFloat(document.getElementById("txtInterest").value)) -
        parseFloat(document.getElementById("txtAmtPaid").value);
}

function computeamtpaid() {
    document.getElementById("txtAmtPaid").value = (parseFloat(document.getElementById("txtLoanAmt").value) +
        parseFloat(document.getElementById("txtInterest").value)) - 
        parseFloat(document.getElementById("txtBal").value);
}

function computeamort() {
    document.getElementById("txtMonthly").value = parseFloat(document.getElementById("txtBal").value) /
        parseFloat(document.getElementById("txtNoOfPayments").value);
}

function computefreq() {
    document.getElementById("txtNoOfPayments").value = ceil(parseFloat(document.getElementById("txtBal").value) / 
        parseFloat(document.getElementById("txtMonthly").value));
}
function ceil(number){    
    if(parseInt(number) < parseFloat(number)){
        return parseInt(number) + 1;
    }else{
        return parseInt(number);
    }
}

var vEmpList="";
var d = null;   //XML Handler
var i = 0;      //loop counter
var vTotalList = 0; //upper bound of list of employees
var vList = ""; //holds the list of employees
var vRow = 0;
var vLoanCd = "";   //holds the selected Loan
var vLoanDate = ""; //holds the entered Loan Date

function GetXmlHttpObject() {
    var xmlHttp=null;
    try
      {
      // Firefox, Opera 8.0+, Safari
      xmlHttp=new XMLHttpRequest();
      }
    catch (e)
      {
      // Internet Explorer
      try
        {
        xmlHttp=new ActiveXObject("Msxml2.XMLHTTP");
        }
      catch (e)
        {
        xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
        }
      }
    return xmlHttp;
}

function  computeLedger() {
    document.getElementById("divWait").style.visibility = "visible";
    var vId = document.getElementById("txtEmpList").value;
    vLoanCd = document.getElementById("cmbLoan").value;
    vLoanDate = document.getElementById("txtLoanDate").value;
    
    //validate xml object
    d = GetXmlHttpObject();
    if(d==null){ 
        alert("Your browser does not support XML object"); 
        return; 
    }

    vList = vId.split(",");
    i=0;
    vTotalList = vList.length - 1;
    processEmp();
}

function processEmp() {
    if(i>vTotalList) { 
        document.getElementById("divWait").style.visibility ="hidden";
        alert("Processing complete.");
        return;
    }
    
    
    document.getElementById("txtId").innerHTML = vList[i];
    //recalculate
    var url = "syncamortization.aspx";
    d = GetXmlHttpObject();
    d.onreadystatechange=doneSync;
    d.open("POST",url);
    d.setRequestHeader("Content-Type","application/x-www-form-urlencoded;charset = UTF-8");
    param = "id=" + vList[i] + "&l=" + vLoanCd + "&d=" + vLoanDate;
    d.send(param);
}

function doneSync() {
    if(d.readyState=="complete" || d.readyState==4){
        var vReturn = d.responseText;
        if(vReturn=="expired") {
            alert("Your login session has expired. Please re-login to continue...");
            window.location="index.aspx";
            return true;
        }
        if(vReturn!="ok") {
            alert(vReturn);
            return true;
        }
        if(i<=vTotalList) {
            i++;
            processEmp();
        } 
    }
}


