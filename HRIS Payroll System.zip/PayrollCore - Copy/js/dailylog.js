vEmpList="";
var vStart = new Date();
var vEnd   = new Date();
var d = null;
var i = 0;      //loop counter
var vTotalList = 0; //upper bound of list of employees
var vList = ""; //holds the list of employees
var vRow = 0;

function view(id,t) {
    document.getElementById("txtEmpCd").value = id;
    document.getElementById("txtLate").value = "";
    l = t.replace("cmdView","lblRow");
    vRow = document.getElementById(l).value;
    compute();
    return false;
}

function hide() {
    document.getElementById("divmsgbox").style.visibility = "hidden";
    document.getElementById("divBlur").style.visibility = "hidden";
}

function hiderecalc() {
    document.getElementById("divRecalc").style.visibility = "hidden";
    document.getElementById("divBlur").style.visibility = "hidden";
}

function GetXmlHttpObject() {
    var xmlHttp=null;
    try
      {
      // Firefox, Opera 8.0+, Safari
      xmlHttp=new XMLHttpRequest();
      }
    catch (e)
      {
      // Internet Explorer
      try
        {
        xmlHttp=new ActiveXObject("Msxml2.XMLHTTP");
        }
      catch (e)
        {
        xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
        }
      }
    return xmlHttp;
}


function compute() {
    var vId = document.getElementById("txtEmpCd").value;
    //vStart =  new Date(document.getElementById("cmbYrFr").value + "/" + document.getElementById("cmbMonthFr").value + '/' + document.getElementById("cmbDayFr").value);
    //vEnd = new Date(document.getElementById("cmbYrTo").value + "/" + document.getElementById("cmbMonthTo").value + '/' + document.getElementById("cmbDayTo").value);
    
    
    vStart = new Date(document.getElementById("txtFrom").value);
    vEnd   = new Date(document.getElementById("txtTo").value);
    
    document.getElementById("divWait").style.visibility = "visible";

    //validate xml object
    d = GetXmlHttpObject();
    if(d==null){ 
        alert("Your browser does not support XML object"); 
        return; 
    }

    vList = vId.split(",");
    i=0;
    vTotalList = vList.length - 1;
    processEmp();
}

function recalculate() {
    v = document.getElementById("divBlur");
    v.style.visibility = "visible";
    v.style.left=0;
    v.style.top=0;
    if(navigator.appName == "Microsoft Internet Explorer")
    {
        v.style.width=screen.width;
        v.style.height=screen.height;
    }else{
        v.style.width='100%';
        v.style.height='100%';
    }
    document.getElementById("divRecalc").style.visibility = "visible";
}

function currall() {
    var vId = document.getElementById("txtvId").value;
    document.getElementById("txtLate").value = "0";
    //vStart =  new Date(document.getElementById("cmbYrFr").value + "/" + document.getElementById("cmbMonthFr").value + '/' + document.getElementById("cmbDayFr").value);
    //vEnd = new Date(document.getElementById("cmbYrTo").value + "/" + document.getElementById("cmbMonthTo").value + '/' + document.getElementById("cmbDayTo").value);
    
    vStart = new Date(document.getElementById("txtFrom").value);
    vEnd   = new Date(document.getElementById("txtTo").value);
    
    hiderecalc();
    document.getElementById("divWait").style.visibility = "visible";

    //validate xml object
    d = GetXmlHttpObject();
    if(d==null){ 
        alert("Your browser does not support XML object"); 
        return; 
    }

    vList = vId.split(",");
    i=0;
    vTotalList = vList.length - 1;
    processEmp();
}

function curremp() {
    var vEmpCd = document.getElementById("txtEmpCd").value;
    var vId = vEmpCd;
    document.getElementById("txtLate").value = "0";
    //vStart =  new Date(document.getElementById("cmbYrFr").value + "/" + document.getElementById("cmbMonthFr").value + '/' + document.getElementById("cmbDayFr").value);
    //vEnd = new Date(document.getElementById("cmbYrTo").value + "/" + document.getElementById("cmbMonthTo").value + '/' + document.getElementById("cmbDayTo").value);
    
    vStart = new Date(document.getElementById("txtFrom").value);
    vEnd   = new Date(document.getElementById("txtTo").value);

    hiderecalc();
    document.getElementById("divWait").style.visibility = "visible";

    //validate xml object
    d = GetXmlHttpObject();
    if(d==null){ 
        alert("Your browser does not support XML object"); 
        return; 
    }

    vList = vId.split(",");
    i=0;
    vTotalList = vList.length - 1;
    processEmp();
}

function lateall() {
    var vId = document.getElementById("txtvId").value;
    document.getElementById("txtLate").value = "1";
    //vStart =  new Date(document.getElementById("cmbYrFr").value + "/" + document.getElementById("cmbMonthFr").value + '/' + document.getElementById("cmbDayFr").value);
    //vEnd = new Date(document.getElementById("cmbYrTo").value + "/" + document.getElementById("cmbMonthTo").value + '/' + document.getElementById("cmbDayTo").value);
    vStart = new Date(document.getElementById("txtFrom").value);
    vEnd   = new Date(document.getElementById("txtTo").value);
    
    
    hiderecalc();
    document.getElementById("divWait").style.visibility = "visible";

    //validate xml object
    d = GetXmlHttpObject();
    if(d==null){ 
        alert("Your browser does not support XML object"); 
        return; 
    }

    vList = vId.split(",");
    i=0;
    vTotalList = vList.length - 1;
    processEmp();
}

function lateemp() {
    var vEmpCd = document.getElementById("txtEmpCd").value;
    var vId = vEmpCd;
    document.getElementById("txtLate").value = "1";
    //vStart =  new Date(document.getElementById("cmbYrFr").value + "/" + document.getElementById("cmbMonthFr").value + '/' + document.getElementById("cmbDayFr").value);
    //vEnd = new Date(document.getElementById("cmbYrTo").value + "/" + document.getElementById("cmbMonthTo").value + '/' + document.getElementById("cmbDayTo").value);
    vStart = new Date(document.getElementById("txtFrom").value);
    vEnd   = new Date(document.getElementById("txtTo").value);
    
    hiderecalc();
    document.getElementById("divWait").style.visibility = "visible";

    //validate xml object
    d = GetXmlHttpObject();
    if(d==null){ 
        alert("Your browser does not support XML object"); 
        return; 
    }

    vList = vId.split(",");
    i=0;
    vTotalList = vList.length - 1;
    processEmp();
}

function processEmp() {
    if(i>vTotalList) { 
        document.getElementById("divWait").style.visibility ="hidden";
        if(vTotalList>1) {
            alert("Processing complete.");
        }
        if(document.getElementById("txtLate").value=="") {
            vEvent = "Select$" + vRow;
            __doPostBack('tblEmp',vEvent);
        }
        return;
    }
    
    
    document.getElementById("txtId").innerHTML = vList[i];
    //recalculate
    var url = "recalc.aspx";
    d = GetXmlHttpObject();
    d.onreadystatechange=doneRecalc;
    d.open("POST",url);
    d.setRequestHeader("Content-Type","application/x-www-form-urlencoded;charset = UTF-8");
    param = "id=" + vList[i] + "&s=" + (vStart.getMonth() + 1) + "/" + vStart.getDate() + "/" + vStart.getFullYear() + 
        "&e=" + (vEnd.getMonth() + 1) + "/" + vEnd.getDate() + "/" + vEnd.getFullYear() +
        "&m=1";
    if(document.getElementById("txtLate").value=="1") {
        param = param + "&ldtr=1&lot=1";
    }
    d.send(param);
}

function doneRecalc() {
    if(d.readyState=="complete" || d.readyState==4){
        var vReturn = d.responseText;
        if(vReturn=="expired") {
            alert("Your login session has expired. Please re-login to continue...");
            window.location="index.aspx";
            return true;
        }
        if(vReturn!="ok") {
            alert(vReturn);
            return true;
        }
        if(i<=vTotalList) {
            i++;
            processEmp();
        } 
    }
}


function getDTR(pMode) {
    if(pMode==1) {
        vStr = "Click OK to print the current selected employee.\nOtherwise, it will print all employee's DTR.";
    } else {
        vStr = "Click OK to download the current selected employee.\nOtherwise, it will download all employee's DTR.";
    }
    if(confirm(vStr)) {
        document.getElementById("txtStatus").value = "0"; //specific
    } else {
        document.getElementById("txtStatus").value = "1"; //all
        vStr = "Do you want to group the Employee's DTR by Department?";
        if (confirm(vStr)) {
            document.getElementById("txtByDept").value = "1";
        } else {
            document.getElementById("txtByDept").value = "0";
        }
    }
    document.getElementById("divWait1").style.visibility = "visible";
    return true;
}

function ask()
{
    //var fromCut = document.getElementById("cmbMonthFr").value + '/' + document.getElementById("cmbDayFr").value + '/' + document.getElementById("cmbYrFr").value;
    //var toCut = document.getElementById("cmbMonthTo").value + '/' + document.getElementById("cmbDayTo").value + '/' + document.getElementById("cmbYrTo").value;
    
    var fromCut = new Date(document.getElementById("txtFrom").value);
    var toCut   = new Date(document.getElementById("txtTo").value);
    
    var freeze = confirm("Are you sure you want to freeze this selected cut off?\n\n\t" + fromCut + ' to ' + toCut);
    
    if (freeze == false)
    {
        return false;
    }
} 
       
function cmdPrintSumm2_onclick() {
    v = document.getElementById("divBlur");
    v.style.visibility = "visible";
    v.style.left=0;
    v.style.top=0;
    if(navigator.appName == "Microsoft Internet Explorer")
    {
        v.style.width=screen.width;
        v.style.height=screen.height;
    }else{
        v.style.width='100%';
        v.style.height='100%';
    }
    document.getElementById("divMsgBox").style.visibility = "visible";
}
