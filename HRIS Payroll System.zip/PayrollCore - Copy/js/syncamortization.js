﻿// JScript File
function compute() {
            vOrgPaidAmt = parseFloat(document.getElementById("txtDetailAmtPaid").value);
            vPaidAmt = parseFloat(document.getElementById("txtAmtPaid").value);
            if(vPaidAmt < vOrgPaidAmt) {
                alert("Your amount paid field should not be less than the paid amount of " + vOrgPaidAmt + " computed by the system.");
                return;
            }
            document.getElementById("txtBal").value = (parseFloat(document.getElementById("txtLoanAmt").value) +
                parseFloat(document.getElementById("txtInterest").value)) -
                parseFloat(document.getElementById("txtAmtPaid").value);
        }

        function computeamtpaid() {
            document.getElementById("txtAmtPaid").value = (parseFloat(document.getElementById("txtLoanAmt").value) +
                parseFloat(document.getElementById("txtInterest").value)) - 
                parseFloat(document.getElementById("txtBal").value);
        }

        function computeamort() {
            var vLoan = parseFloat(document.getElementById("txtLoanAmt").value);
            var vInterest = parseFloat(document.getElementById("txtInterest").value);
            var vPay  = parseFloat(document.getElementById("txtNoOfPayments").value);
            document.getElementById('txtMonthly').value = ((vLoan + vInterest)/ vPay);
            document.getElementById("txtNoOfPayments").value = ceil(document.getElementById("txtNoOfPayments").value);
        }

        function computefreq() {
            document.getElementById("txtNoOfPayments").value = ceil(parseFloat(document.getElementById("txtBal").value) / 
                parseFloat(document.getElementById("txtMonthly").value));
        }
        function ceil(number){
            if(parseInt(number) < parseFloat(number)){
                return parseInt(number) + 1;
            }else{
                return parseInt(number);
            }
        }
        function computenopayment() {
            var a = parseFloat(document.getElementById("txtLoanAmt").value);
            var b = parseFloat(document.getElementById("txtMonthly").value);
            var c = a / b;
            document.getElementById("txtNoOfPayments").value = ceil(c);
            
        }
        function cmdClose_onclick() {
            window.close();
        }

        var d;
        function GetXmlHttpObject() {
            var xmlHttp=null;
            try
              {
              // Firefox, Opera 8.0+, Safari
              xmlHttp=new XMLHttpRequest();
              }
            catch (e)
              {
              // Internet Explorer
              try
                {
                xmlHttp=new ActiveXObject("Msxml2.XMLHTTP");
                }
              catch (e)
                {
                xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
                }
              }
            return xmlHttp;
        }

        function syncAmort(pId,pLoanCd,pLoanDate) {
            //validate xml object
            d = GetXmlHttpObject();
            if(d==null){ 
                alert("Your browser does not support XML object"); 
                return; 
            }
            
            var url = "syncamortization.aspx";
            d = GetXmlHttpObject();
            d.onreadystatechange=doneSync;
            d.open("POST",url);
            d.setRequestHeader("Content-Type","application/x-www-form-urlencoded;charset = UTF-8");
            param = "id=" + pId + "&l=" + pLoanCd + "&d=" + pLoanDate;
            d.send(param);
            
        }
        
        function doneSync() {
            if(d.readyState=="complete" || d.readyState==4){
                var vReturn = d.responseText;
                if(vReturn=="expired") {
                    alert("Your login session has expired. Please re-login to continue...");
                    window.close();
                    return;
                }
                if(vReturn!="ok") {
                    alert(vReturn);
                    return;
                }
                alert("Changes were successfuly saved.");
                window.close();    
            }
        }