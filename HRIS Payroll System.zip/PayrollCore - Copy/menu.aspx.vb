Imports System.Data
Imports denaro.fis
Partial Class menu
    Inherits System.Web.UI.Page
    Dim c As New sqlclient.sqlconnection(connStr)
    Public vPage As String = "main.aspx"
    Public vTodolist As String = "todolist.aspx"


    Public vParentMenu As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        vParentMenu = ""

        'If Not IsPostBack Then
        Dim cm As New sqlclient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim t As TreeNode

        cm.Connection = c
        cm.CommandText = "select * from menu where SystemName='CAERUS' and ParentId is null order by Menu_Caption"
        c.Open()
        rs = cm.ExecuteReader
        'triMenu.Nodes.Clear()

        vParentMenu = ""

        Do While rs.Read
            t = New TreeNode
            t.Value = rs("Menu_Caption")
            t.Text = rs("Label_Caption")


            'triMenu.Nodes.Add(t)

            vParentMenu += "<li class='nav-item dropdown'>" _
                & "<a class='nav-link dropdown-toggle' href='#' id='" & rs("Menu_Caption") & "' data-toggle='dropdown'>" & rs("Label_Caption") & "</a>"
            vParentMenu += "<div class='dropdown-menu'>"


            If rs("Label_Caption") = "System" Then
                vParentMenu += "<div class='row panel-menu'>"
            Else
                vParentMenu += "<div class='row panel-menu2'>"
            End If

            GetChild(t)
            GetSubParentMenu(rs("Menu_Caption"))

            vParentMenu += "</div></div></li>"
        Loop

        rs.Close()
        cm.Dispose()
        c.Close()

        getuser()

        'End If
    End Sub
    Private Sub GetChild(ByRef t As TreeNode)
        Dim cm As New sqlclient.sqlcommand
        Dim rs As sqlclient.sqldatareader
        Dim tChild As TreeNode

        cm.Connection = c
        cm.CommandText = "Select * from menu where SystemName='CAERUS' and ParentId='" & t.Value & "' order by Label_Caption"
        rs = cm.ExecuteReader
        Do While rs.Read
            tChild = New TreeNode
            tChild.Text = rs("Label_Caption")
            tChild.Value = rs("Menu_Caption")
            GetChild(tChild)
            t.ChildNodes.Add(tChild)
        Loop
        rs.Close()
        cm.Dispose()
    End Sub
    Private Sub GetSubParentMenu(ByRef pMenuId As String)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim vSubmenu As Integer = 0

        cm.Connection = c

        cm.CommandText = "Select * from menu where SystemName='CAERUS' and ParentId='" & pMenuId & "' and MenuType='Level2' order by SeqId"
        rs = cm.ExecuteReader
        Do While rs.Read
            vParentMenu += "<div class='col-sm-3'><b>" & rs("Label_Caption") & "</b>"

            GetChildMenu(rs("Menu_Caption"), "")

            vParentMenu += "</div>"

            vSubmenu += 1
        Loop
        rs.Close()

        If vSubmenu = 0 Then
            cm.CommandText = "Select * from menu where SystemName='CAERUS' and ParentId='" & pMenuId & "' order by SeqId"
            rs = cm.ExecuteReader
            Do While rs.Read

                If Not IsDBNull(rs("Dependencies")) Then
                    vParentMenu += "<div class='col-sm-12 icon-menu2 btn btn-link' onclick='openNav(""" & rs("Dependencies") & """)' >" & rs("Label_Caption") & ""
                Else
                    vParentMenu += "<div class='col-sm-12 icon-menu2 btn' >" & rs("Label_Caption") & ""
                End If

                GetChildMenu(rs("Menu_Caption"), "YES")

                vParentMenu += "</div>"

                vSubmenu += 1
            Loop
            rs.Close()

        End If


        rs.Close()
        cm.Dispose()
    End Sub

    Private Sub GetChildMenu(ByRef pMenuId As String, ByRef pIsSubItem As String)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader

        cm.Connection = c
        cm.CommandText = "Select * from menu where SystemName='CAERUS' and ParentId='" & pMenuId & "' order by Label_Caption"
        rs = cm.ExecuteReader
        Do While rs.Read

            If Not IsDBNull(rs("MenuType")) Then
                If rs("MenuType") = "Level3" Then
                    vParentMenu += "<div class='col-sm-12 icon-menu btn btn-link'>1<b>" & rs("Label_Caption") & "</b></div>"
                End If
            Else
                If pIsSubItem = "YES" Then
                    vParentMenu += "<div class='col-sm-12 icon-menu btn btn-link' style='padding-left: 10px;' onclick='openNav(""" & rs("Dependencies") & """)'>" & rs("Label_Caption") & "</div>"
                Else
                    vParentMenu += "<div class='col-sm-12 icon-menu btn btn-link' onclick='openNav(""" & rs("Dependencies") & """)' >" & rs("Label_Caption") & "</div>"
                End If

            End If

            GetChildMenu(rs("Menu_Caption"), "")
        Loop
        rs.Close()
        cm.Dispose()
    End Sub

    Private Sub getuser()
        Dim cm As New sqlclient.sqlcommand
        Dim rs As sqlclient.sqldatareader

        cm.Connection = c
        cm.CommandText = "select Male,Civil_Cd,NickName,Emp_Fname,EmploymentType,Bday," & _
                   "ImgPath,PinExpiry from py_emp_master where Emp_Cd='" & Session("uid") & "'"
        c.Open()
        rs = cm.ExecuteReader

        If rs.Read Then
            'lblWelcome.Text = "Welcome " & IIf(IsDBNull(rs("NickName")), rs("Emp_Fname"), _
            '           rs("NickName")) & "&nbsp;!"
        End If
        rs.Close()
        cm.Dispose()
    End Sub

    'Protected Sub triMenu_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles triMenu.Init
    '    triMenu.Attributes.Add("onclick", "turnon();")
    'End Sub

    'Protected Sub triMenu_SelectedNodeChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles triMenu.SelectedNodeChanged
    '    Dim cm As New sqlclient.sqlCommand("select Dependencies from evolvemenus where SystemName='CAERUS' " & _
    '        " and Menu_Caption='" & triMenu.SelectedValue & "'", c)
    '    Dim rs As sqlclient.sqldatareader

    '    c.Open()
    '    rs = cm.ExecuteReader
    '    If rs.Read Then
    '        If Not IsDBNull(rs("Dependencies")) Then
    '            vPage = rs("Dependencies")
    '        Else
    '            vPage = "main.aspx"
    '        End If
    '    End If
    '    rs.Close()
    '    cm.Dispose()
    '    c.Close()
    'End Sub

    'Protected Sub cmdSignOut_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSignOut.Click
    '    Session.RemoveAll()
    '    Server.Transfer("index.aspx")
    'End Sub

    Protected Sub cmdSignOut_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSignOut.Click
        Session.RemoveAll()
        Server.Transfer("index.aspx")
    End Sub

    'Protected Sub triMenu_TreeNodeExpanded(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.TreeNodeEventArgs) Handles triMenu.TreeNodeExpanded

    'End Sub
End Class
