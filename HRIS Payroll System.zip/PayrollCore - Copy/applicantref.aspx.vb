Imports denaro
Partial Class applicantref
    Inherits System.Web.UI.Page
    Dim c As New sqlclient.sqlconnection
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If

        If Not IsPostBack Then
            Dim cm As New sqlclient.sqlcommand
            Dim dr As sqlclient.sqldatareader
            lblCaption.Text = "Applicant's Character Reference"
            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c
            cm.CommandText = "select * from hr_applicant_reference where Emp_Cd='" & _
                Session("applicantno") & "'"
            dr = cm.ExecuteReader
            If dr.Read Then
                txtFullName1.Text = IIf(IsDBNull(dr("FullName")), "", dr("FullName"))
                txtPosition1.Text = IIf(IsDBNull(dr("Position")), "", dr("Position"))
                txtContact1.Text = IIf(IsDBNull(dr("Contact_No")), "", dr("Contact_No"))
                txtAddr1.Text = IIf(IsDBNull(dr("Address")), "", dr("Address"))
            End If
            If dr.Read Then
                txtFullName2.Text = IIf(IsDBNull(dr("FullName")), "", dr("FullName"))
                txtPosition2.Text = IIf(IsDBNull(dr("Position")), "", dr("Position"))
                txtContact2.Text = IIf(IsDBNull(dr("Contact_No")), "", dr("Contact_No"))
                txtAddr2.Text = IIf(IsDBNull(dr("Address")), "", dr("Address"))
            End If
            If dr.Read Then
                txtFullName3.Text = IIf(IsDBNull(dr("FullName")), "", dr("FullName"))
                txtPosition3.Text = IIf(IsDBNull(dr("Position")), "", dr("Position"))
                txtContact3.Text = IIf(IsDBNull(dr("Contact_No")), "", dr("Contact_No"))
                txtAddr3.Text = IIf(IsDBNull(dr("Address")), "", dr("Address"))
            End If
            dr.Close()
            cm.Dispose()
            c.Close()
        End If
    End Sub
End Class
