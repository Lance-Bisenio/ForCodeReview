Imports denaro
Partial Class post2jv
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Public vBuild As String = ""
    Public vFilename As String = ""


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Or Session("uid") = Nothing Then
            Session("returnaddr") = "emp.aspx"
            Server.Transfer("index.aspx")
        End If
        If Not CanRun(Session("caption"), Request.Item("id")) Then
            Session("denied") = "1"
            Server.Transfer("main.aspx")
            Exit Sub
        End If

        If Not IsPostBack Then

            lblCaption.Text = "Post payroll to Journal entries"

            cmbYear.Items.Clear()
            For i As Integer = Now.Year To Now.Year - 5 Step -1
                cmbYear.Items.Add(i)
            Next
            cmbYear.SelectedValue = Now.Year

            Dim c As New SqlClient.SqlConnection(connStr)

            Try
                c.Open()
            Catch ex As SqlClient.SqlException
                vScript = "alert('An error has occurred while trying to connect to database: Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                c.Dispose()
                Exit Sub
            End Try

            BuildCombo("select distinct CaptionName as Code,CaptionName from post_info order by CaptionName", cmbProfile, c)
            BuildCombo("select Rc_Cd,Descr from rc where exists (select User_Id from rights_list where User_Id='" & _
               Session("uid") & "' and property='rc' and Property_Value=Rc_Cd) order by Descr", cmbRC, c)
            BuildCombo("select AgencyCd,AgencyName from agency where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='agency' and Property_Value=AgencyCd) order by AgencyName", cmbOfc, c)
            BuildCombo("select Div_Cd,Descr from hr_div_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='division' and Property_Value=Div_Cd) order by Descr", cmbDiv, c)
            BuildCombo("select Dept_Cd,Descr from hr_dept_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='department' and Property_Value=Dept_Cd) order by Descr", cmbDept, c)
            BuildCombo("select Section_Cd,Descr from hr_section_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='section' and Property_Value=Section_Cd) order by Descr", cmbSection, c)
            BuildCombo("select Unit_Cd,Descr from hr_unit_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='unit' and Property_Value=Unit_Cd) order by Descr", cmbUnit, c)
            'BuildCombo("select distinct GroupName,GroupName as Descr from hr_employment_type where exists (select User_Id from rights_list where User_Id='" & _
            '    Session("uid") & "' and property='employmenttype' and Property_Value=EmploymentType) order by Descr", cmbEmpType, c)

            'BuildCombo("select EmploymentType,Descr from hr_employment_type where exists (select User_Id from rights_list where User_Id='" & _
            '                Session("uid") & "' and property='employmenttype' and Property_Value=EmploymentType) order by Descr", cmbEmpType, c)

            'BuildCombo("select Status_Code,Descr from py_employee_stat order by Descr", cmbStatus, c)
            'BuildCombo("select distinct CaptionName,CaptionName from post_info", cmbProfile)

            BuildCombo("select distinct PayDate as DatePay,PayDate from py_report where year(PayDate)=" & _
                cmbYear.SelectedValue & " group by PayDate order by DatePay desc", cmbPeriod, c)

            c.Close()
            c.Dispose()

            cmbRC.Items.Add("All")
            cmbRC.SelectedValue = "All"
            cmbOfc.Items.Add("All")
            cmbOfc.SelectedValue = "All"
            cmbDiv.Items.Add("All")
            cmbDiv.SelectedValue = "All"
            cmbDept.Items.Add("All")
            cmbDept.SelectedValue = "All"
            cmbSection.Items.Add("All")
            cmbSection.SelectedValue = "All"
            cmbUnit.Items.Add("All")
            cmbUnit.SelectedValue = "All"
            'cmbEmpType.Items.Add("All")
            'cmbEmpType.SelectedValue = "All"
            'cmbStatus.Items.Add("All")
            'cmbStatus.SelectedValue = "All"
        End If
    End Sub

    Protected Sub cmdReturn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.Click
        Server.Transfer("main.aspx")
    End Sub

    Private Sub GenerateEntry()
        Dim c As New SqlClient.SqlConnection
        Dim cm As New SqlClient.SqlCommand
        Dim cmRef As New SqlClient.SqlCommand
        Dim cmRC As New SqlClient.SqlCommand
        Dim rsRef As SqlClient.SqlDataReader
        Dim rsRC As SqlClient.SqlDataReader
        Dim rs As SqlClient.SqlDataReader
        Dim vFilter As String = ""
        Dim vDrTotal As Decimal = 0
        Dim vCrTotal As Decimal = 0
        Dim vAmount As Decimal = 0
        Dim vTitle As String = ""
        'Dim vClass As String = "odd"
        Dim vCond As String = ""
        Dim vGroup As String = ""
        Dim vField As String = ""
        Dim vCompanyName As String = ""
        Dim vRows As Boolean = False
        Dim vRC As String = "All"
        Dim vFormat As String = ""
        Dim vData As String = ""
        Dim vPrn As New VSPrinter8Lib.VSPrinter
        Dim vPDF As New VSPDF8Lib.VSPDF8

        txtStatus.Text = Request.Form("txtStatus")
        txtRank.Text = Request.Form("txtRank")
        If txtRank.Text.Trim = "" Then
            vScript = "alert('You must first select the Rank.');"
            Exit Sub
        End If
        If txtStatus.Text.Trim = "" Then
            vScript = "alert('You must first select the Employment Status.');"
            Exit Sub
        End If

        Try
            'cmRC.CommandText = "select Rc_Cd,Descr from rc order by Descr"
            'rsRC = cmRC.ExecuteReader

            'Do While rsRC.Read
            vFilter = ""
            If cmbRC.SelectedValue <> "All" Then   'filter by cost center
                vFilter += " and Rc_Cd='" & cmbRC.SelectedValue & "' "
            Else
                'If rdoReportType.SelectedValue = 0 Then  'consolidated
                vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='rc' and Property_Value=Rc_Cd) "
                '    Else
                '    vFilter += " and Rc_Cd='" & rsRC("Rc_Cd") & "' "
                'End If
            End If

            If cmbOfc.SelectedValue <> "All" Then        'filter by office/agency
                vFilter += " and Agency_Cd='" & cmbOfc.SelectedValue & "' "
            Else
                vFilter += "  and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='agency' and Property_Value=Agency_Cd) "
            End If
            If cmbDiv.SelectedValue <> "All" Then      'filter by division
                vFilter += " and Divcd='" & cmbDiv.SelectedValue & "' "
            Else
                vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='division' and Property_Value=DivCd) "
            End If
            If cmbDept.SelectedValue <> "All" Then  'filter by departments
                vFilter += " and DeptCd='" & cmbDept.SelectedValue & "' "
            Else
                vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='department' and Property_Value=DeptCd) "
            End If
            If cmbSection.SelectedValue <> "All" Then 'filter by section
                vFilter += " and SectionCd='" & cmbSection.SelectedValue & "' "
            Else
                vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='section' and Property_Value=SectionCd) "
            End If
            If cmbUnit.SelectedValue <> "All" Then  'filter by units
                vFilter += " and UnitCd='" & cmbUnit.SelectedValue & "' "
            Else
                vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='unit' and Property_Value=UnitCd) "
            End If
            vFilter += " and EmploymentType in ('" & txtRank.Text.Replace(",", "','") & "') "

           
            vFilter += " and Emp_Status in ('" & txtStatus.Text.Replace(",", "','") & "') "

            c.ConnectionString = connStr
            c.Open()

            cm.Connection = c
            cmRef.Connection = c
            cmRC.Connection = c

            vCompanyName = cmbOfc.SelectedItem.Text
            cm.CommandText = "select Company_Name from glsyscntrl where AgencyCd='" & cmbOfc.SelectedValue & "'"
            rs = cm.ExecuteReader
            If rs.Read Then
                If Not IsDBNull(rs("Company_Name")) Then
                    'lblCompany.Text = rs("Company_Name")
                    vCompanyName = rs("Company_Name")
                End If
            End If
            rs.Close()

            vPrn.MarginTop = OneInch
            vPrn.MarginBottom = OneInch
            vPrn.MarginLeft = OneInch
            vPrn.MarginRight = OneInch
            vPrn.StartDoc()
            vPrn.HdrFontSize = 6
            vPrn.Footer = "Powered by Evolve Integrated Software Solutions||%p"

            vData = ""
            vDrTotal = 0
            vCrTotal = 0

            cm.CommandText = "select * from post_info where CaptionName='" & cmbProfile.SelectedValue & "'"
            rs = cm.ExecuteReader

            Do While rs.Read
                vTitle = "Unknown Account"
                cmRef.CommandText = "select AcctName from coa where AcctCd='" & rs("AcctCd") & "'"
                rsRef = cmRef.ExecuteReader
                If rsRef.Read Then
                    vTitle = rsRef("AcctName")
                End If
                rsRef.Close()

                vCond = ""
                If Not IsDBNull(rs("Condition")) Then
                    If rs("Condition").ToString.Trim <> "" Then
                        vCond = " and " & rs("Condition")
                    End If
                End If
                vGroup = IIf(IsDBNull(rs("GroupBy")), "", rs("GroupBy"))
                vField = rs("FieldName")
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY:  VIC GATCHALIAN                                  ''
                '' DATE MODIFIED: 3/19/2013                                      ''
                '' PURPOSE: TO CHECK IF THE FIELD IS MANCOUNT OR NOT SO THAT     ''
                ''          PROPER SYNTAX IS EXECUTED.                           ''
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '''''''''''''''''''''' OLD CODE '''''''''''''''''''''''''''''''''''
                'vField = "sum(" & vField.Replace(",", "+") & ") as Total"
                '''''''''''''''''''''' END OLD CODE '''''''''''''''''''''''''''''''
                If rs("FieldName") = "mancount" Then
                    vField = "count(Emp_Cd) as Total"
                Else
                    vField = "sum(" & vField.Replace(",", "+") & ") as Total"
                End If
                '''''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''


                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY:  VIC GATCHALIAN                                    ''
                '' DATE MODIFIED: 5/1/2013                                         ''
                '' PURPOSE: TO ADD THE CONDITIONAL VARIABLE AS PART OF THE FILTER  ''
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '''''''''''''''''''''''' OLD CODE '''''''''''''''''''''''''''''''''''
                'cmRef.CommandText = "select GrossUp, " & vField & IIf(vGroup = "", "", "," & vGroup) & _
                '    " from py_report where PayDate='" & Format(CDate(cmbPeriod.SelectedValue), "yyyy/MM/dd") & _
                '    "' " & vFilter & " group by GrossUp" & IIf(vGroup = "", "", "," & vGroup)
                '''''''''''''''''''''''' END OLD CODE '''''''''''''''''''''''''''''''
                cmRef.CommandText = "select GrossUp, " & vField & IIf(vGroup = "", "", "," & vGroup) & _
                    " from py_report where PayDate='" & Format(CDate(cmbPeriod.SelectedValue), "yyyy/MM/dd") & _
                    "' " & vFilter & vCond & " group by GrossUp" & IIf(vGroup = "", "", "," & vGroup)
                '''''''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''
                rsRef = cmRef.ExecuteReader
               
                vRows = rsRef.HasRows
                Do While rsRef.Read
                    vAmount = IIf(IsDBNull(rsRef("Total")), 0, rsRef("Total"))
                    If vAmount <> 0 Then
                        If rs("DrCr") = 0 Then      'debit
                            vDrTotal += vAmount
                        Else                        'credit
                            vCrTotal += vAmount
                        End If
                        'vDump += "<tr class='" & vClass & "'><td class='labelL'>" & rs("AcctCd") & "</td>" & "<td class='labelL'>" & vTitle
                        vData += rs("AcctCd") & "|" & vTitle
                        If vGroup <> "" Then
                            'vDump += " - " & rsRef(vGroup)
                            vData += " - " & GetRef("select Descr from Rc where Rc_Cd='" & rsRef(vGroup) & "'", rsRef(vGroup), c)
                        End If

                        'vDump += "</td>" & "<td class='labelR'>" & IIf(rs("DrCr") = 0, Format(vAmount, "##,###,##0.00"), "&nbsp;") & "</td>" & _
                        '    "<td class='labelR'>" & IIf(rs("DrCr") = 0, "&nbsp;", Format(vAmount, "##,###,##0.00")) & "</td>"
                        vData += "|" & IIf(rs("DrCr") = 0, Format(vAmount, "##,###,##0.00"), "") & "|" & _
                            IIf(rs("DrCr") = 0, "", Format(vAmount, "##,###,##0.00")) & ";"
                        'vData.AppendLine(rs("AcctCd") & "," & vTitle & "," & _
                        '    IIf(rs("DrCr") = 0, """" & Format(vAmount, "##,###,##0.00") & """", ",") & _
                        '    IIf(rs("DrCr") = 0, ",", """" & Format(vAmount, "##,###,##0.00") & """"))
                    End If

                    'vClass = IIf(vClass = "odd", "even", "odd")
                Loop
                rsRef.Close()
            Loop
            rs.Close()
            'vDump += "<tr class='activeBar'><td>&nbsp;</td><td align='right'><strong>Total==></strong></td><td align='right'><strong>" & _
            '    Format(vDrTotal, "###,###,##0.00") & "</strong></td><td align='right'><strong>" & _
            '    Format(vCrTotal, "###,###,##0.00") & "</strong></td></tr>"
            'vData.AppendLine(",Total=>,""" & Format(vDrTotal, "###,###,##0.00") & """,""" & Format(vCrTotal, "##,###,##0.00") & """")

            If vDrTotal <> 0 Then
                vPrn.FontSize = 14
                vPrn.FontName = "Arial"
                vPrn.TextAlign = VSPrinter8Lib.TextAlignSettings.taCenterBottom
                vPrn.FontBold = True
                vPrn.Paragraph = vCompanyName
                vPrn.FontBold = False
                vPrn.FontSize = 12
                vPrn.Paragraph = "PAYROLL ACCOUNTING ENTRIES -- " & txtRank.Text
                vPrn.Paragraph = "Pay Period: " & cmbPeriod.SelectedValue
                'vPrn.Paragraph = "Cost Center: " & IIf(rdoReportType.SelectedValue = 0 Or cmbRC.SelectedValue <> "All", _
                '    cmbRC.SelectedItem.Text, rsRC("Descr")) & vbNewLine
                vPrn.Paragraph = "Cost Center: " & cmbRC.SelectedItem.Text & vbNewLine
                vPrn.FontSize = 10
                vPrn.FontBold = True
                vFormat = "^2000|^5000|^1500|^1500;"
                vPrn.TableBorder = VSPrinter8Lib.TableBorderSettings.tbAll
                vPrn.Table = vFormat & "Account Code|Account Title|Debit|Credit;"
                vPrn.FontBold = False
                vFormat = "^2000|<5000|>1500|>1500;"
                vPrn.Table = vFormat & vData
                vPrn.FontBold = True
                vData = "|Total=>|" & Format(vDrTotal, "###,###,##0.00") & "|" & Format(vCrTotal, "###,###,##0.00") & ";"
                vPrn.Table = vFormat & vData
            End If
            'Loop
            'rsRC.Close()
            vPrn.EndDoc()

            'Dim vFilename As String = Server.MapPath(".") & "\downloads\" & Session.SessionID & "-glentry.csv"
            'If IO.File.Exists(vFilename) Then
            '    Try
            '        IO.File.Delete(vFilename)
            '    Catch ex As IO.IOException
            '    End Try
            'End If
            'IO.File.WriteAllText(vFilename, vData.ToString)
            'lnkDownload.NavigateUrl = "downloads/" & Session.SessionID & "-glentry.csv"
            Dim vName As String = Server.MapPath(".") & "\downloads\" & Session.SessionID & "-glentry.pdf"
            If IO.File.Exists(vName) Then
                IO.File.Delete(vName)
            End If
            vPDF.ConvertDocument(vPrn, vName)
            vFilename = "downloads/" & Session.SessionID & "-glentry.pdf"
        Catch ex As SqlClient.SqlException
            Response.Write(ex.Message & " on line #: " & rs("SeqId"))
            vScript = "alert('Error occurred. Error is: " & _
                ex.Message.Replace(vbCrLf, "\n").Replace("'", "\'") & " on line #: " & rs("SeqId") & "');"
        Finally
            c.Close()
            cm.Dispose()
            cmRef.Dispose()
            cmRC.Dispose()
            c.Dispose()
        End Try
    End Sub

    Protected Sub cmdRefresh_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdRefresh.Click
        GenerateEntry()
    End Sub

    Protected Sub cmbYear_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbYear.SelectedIndexChanged
        BuildCombo("select distinct PayDate as DatePay,PayDate from py_report where year(PayDate)=" & _
                cmbYear.SelectedValue & " group by PayDate order by DatePay desc", cmbPeriod)
    End Sub

    Protected Sub cmdDump_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDump.Click
        DumpEntryGenerated()
    End Sub

    Private Sub DumpEntryGenerated()
        Dim c As New SqlClient.SqlConnection

        Dim cm As New SqlClient.SqlCommand
        Dim cmRef As New SqlClient.SqlCommand
        Dim cmRefSub As New SqlClient.SqlCommand
        Dim cmRC As New SqlClient.SqlCommand

        Dim rsRef As SqlClient.SqlDataReader
        Dim rsRefSub As SqlClient.SqlDataReader
        Dim rsRC As SqlClient.SqlDataReader
        Dim rs As SqlClient.SqlDataReader

        Dim vFilter As String = ""
        Dim vDrTotal As Decimal = 0
        Dim vCrTotal As Decimal = 0

        Dim vAmount As Decimal = 0
        Dim vTitle As String = ""
        Dim vCond As String = ""
        Dim vGroup As String = ""
        Dim vDivAltCode As String = ""
        Dim vSecAltCode As String = ""
        Dim vRankCode() As String
        Dim vCnt As Integer = 0
        Dim vDescription As String = ""

        Dim vField As String = ""
        Dim vCompanyName As String = ""
        Dim vAltUid As String = ""

        Dim vRows As Boolean = False
        Dim vRC As String = "All"

        Dim vFormat As String = ""
        Dim vData As String = ""
        
        Dim vFilename = Server.MapPath(".") & "/downloads/" & Session.SessionID & "-POST_to_JV.txt"
        Dim vDumpData As New StringBuilder

        c.ConnectionString = connStr
        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to the database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Close()
            cm.Dispose()
            c.Dispose()
            Exit Sub
        End Try

        cm.Connection = c
        cmRef.Connection = c
        cmRefSub.Connection = c
        cmRC.Connection = c

        If IO.File.Exists(vFilename) Then
            Try
                IO.File.Delete(vFilename)
            Catch ex As IO.IOException
                vScript = "alert('Error deleting dump file. Error is: " & ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                Exit Sub
            End Try
        End If
        vBuild = "VERSION"
        vBuild += Space(25)
        vBuild += "42601"

        vDumpData.AppendLine(vBuild)
        IO.File.WriteAllText(vFilename, vDumpData.ToString)
        

        txtStatus.Text = Request.Form("txtStatus")
        txtRank.Text = Request.Form("txtRank")
        If txtStatus.Text = "" Then
            vScript = "alert('You must first select the Employment Status.');"
            Exit Sub
        End If

        vCompanyName = cmbOfc.SelectedItem.Text
        cm.CommandText = "select Company_Name from glsyscntrl where AgencyCd='" & cmbOfc.SelectedValue & "'"
        rs = cm.ExecuteReader
        If rs.Read Then
            If Not IsDBNull(rs("Company_Name")) Then
                vCompanyName = rs("Company_Name")
            End If
        End If
        rs.Close()

        cm.CommandText = "select Alt_Userid from user_list where User_Id='" & Session("uid") & "'"
        rs = cm.ExecuteReader
        If rs.Read Then
            If Not IsDBNull(rs("Alt_Userid")) Then
                vAltUid = rs("Alt_Userid")
            End If
        End If
        rs.Close()

        Try
            'cmRC.CommandText = "select Rc_Cd,Descr from rc order by Descr"
            'rsRC = cmRC.ExecuteReader

            'Do While rsRC.Read
            vFilter = ""

            If cmbRC.SelectedValue <> "All" Then   'filter by cost center
                vFilter += " and Rc_Cd='" & cmbRC.SelectedValue & "' "
            Else
                'If rdoReportType.SelectedValue = 0 Then  'consolidated
                vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='rc' and Property_Value=Rc_Cd) "
                '    Else
                '    vFilter += " and Rc_Cd='" & rsRC("Rc_Cd") & "' "
                'End If
            End If

            If cmbOfc.SelectedValue <> "All" Then        'filter by office/agency
                vFilter += " and Agency_Cd='" & cmbOfc.SelectedValue & "' "
            Else
                vFilter += "  and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='agency' and Property_Value=Agency_Cd) "
            End If
            If cmbDiv.SelectedValue <> "All" Then      'filter by division
                vFilter += " and Divcd='" & cmbDiv.SelectedValue & "' "
            Else
                vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='division' and Property_Value=DivCd) "
            End If
            If cmbDept.SelectedValue <> "All" Then  'filter by departments
                vFilter += " and DeptCd='" & cmbDept.SelectedValue & "' "
            Else
                vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='department' and Property_Value=DeptCd) "
            End If
            If cmbSection.SelectedValue <> "All" Then 'filter by section
                vFilter += " and SectionCd='" & cmbSection.SelectedValue & "' "
            Else
                vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='section' and Property_Value=SectionCd) "
            End If
            If cmbUnit.SelectedValue <> "All" Then  'filter by units
                vFilter += " and UnitCd='" & cmbUnit.SelectedValue & "' "
            Else
                vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='unit' and Property_Value=UnitCd) "
            End If

            'If cmbEmpType.SelectedValue <> "All" Then 'filter by employment types
            '    vFilter += " and exists (select EmploymentType from hr_employment_type where hr_employment_type.EmploymentType=" & _
            '        "py_report.EmploymentType and EmploymentType='" & cmbEmpType.SelectedValue & "') "
            'Else
            '    vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
            '        "' and Property='employmenttype' and Property_Value=EmploymentType) "
            'End If

            vFilter += " and EmploymentType in ('" & txtRank.Text.Replace(",", "','") & "') "
            vFilter += " and Emp_Status in ('" & txtStatus.Text.Replace(",", "','") & "') "

            vData = ""
            vBuild = ""
            vDrTotal = 0
            vCrTotal = 0

            cm.CommandText = "select * from post_info where CaptionName='" & cmbProfile.SelectedValue & "'"

            rs = cm.ExecuteReader
            Do While rs.Read

                vTitle = "Unknown Account"
                cmRef.CommandText = "select ShortName from coa where AcctCd='" & rs("AcctCd") & "'"
                rsRef = cmRef.ExecuteReader
                If rsRef.Read Then
                    vTitle = rsRef("ShortName")
                End If
                rsRef.Close()

                vCond = IIf(IsDBNull(rs("Condition")), "", rs("Condition"))
                vGroup = IIf(IsDBNull(rs("GroupByDump")), "", rs("GroupByDump"))
                vField = rs("FieldName")

                'If cmbRC.SelectedValue <> "All" Then   'filter by cost center
                '    vFilter += " and Rc_Cd='" & cmbRC.SelectedValue & "' "
                'Else
                '    If rdoReportType.SelectedValue = 0 Then  'consolidated
                '        vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                '            "' and Property='rc' and Property_Value=Rc_Cd) "
                '    Else
                '        vFilter += " and Rc_Cd='" & rsRC("Rc_Cd") & "' "
                '    End If
                'End If

                If rs("ByEmployee") = 1 Then
                    vField = " " & vField.Replace(",", "+") & " as Total, Emp_Cd"
                    cmRef.CommandText = "select " & vField & IIf(vGroup = "", "", "," & vGroup) & _
                        " from py_report where PayDate='" & Format(CDate(cmbPeriod.SelectedValue), "yyyy/MM/dd") & _
                        "' " & vFilter
                Else
                    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                    '' MODIFIED BY:  VIC GATCHALIAN                                             ''
                    '' DATE MODIFIED: 3/19/2013                                                 ''
                    '' PURPOSE: TO DETERMINE IF THE FIELD IS MANCOUNT OR OTHERWISE AND SET THE  ''
                    ''          PROPER SYNTAX TO EXECUTE.                                       ''
                    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                    '''''''''''''''''''''' OLD CODE ''''''''''''''''''''''''''''''''''''''''''''''
                    'vField = "sum(" & vField.Replace(",", "+") & ") as Total"
                    '''''''''''''''''''''' END OLD CODE ''''''''''''''''''''''''''''''''''''''''''
                    If vField = "mancount" Then
                        vField = "count(Emp_Cd) as Total"
                    Else
                        vField = "sum(" & vField.Replace(",", "+") & ") as Total"
                    End If

                    '''''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''''''''''


                    cmRef.CommandText = "select " & vField & IIf(vGroup = "", "", "," & vGroup) & _
                        " from py_report where PayDate='" & Format(CDate(cmbPeriod.SelectedValue), "yyyy/MM/dd") & _
                        "' " & vFilter & IIf(vGroup = "", "", " group by " & vGroup & " order by " & vGroup)
                End If

                rsRef = cmRef.ExecuteReader

                vRows = rsRef.HasRows

                Do While rsRef.Read
                    vBuild = ""

                    vAmount = IIf(IsDBNull(rsRef("Total")), 0, rsRef("Total"))
                    If vAmount <> 0 Then

                        If rs("AcctCd").ToString.Contains("-") Then
                            vRankCode = rs("AcctCd").split("-")
                            vCnt = 14 - vRankCode(0).Length
                            vBuild += vRankCode(0)
                        Else
                            vCnt = 14 - rs("AcctCd").Length
                            vBuild += rs("AcctCd")
                        End If
                        vBuild += Space(vCnt)

                        vBuild += Space(1)
                        vBuild += cmbYear.SelectedValue & "0" & Format(CDate(cmbPeriod.SelectedValue), "MM") & _
                                        Format(CDate(cmbPeriod.SelectedValue), "yyyMMdd")
                        vBuild += Space(2)

                        vBuild += "M"
                        vBuild += Space(14)

                        If rs("DrCr") = 0 Then      'debit
                            vDrTotal += vAmount
                            vBuild += Format(vDrTotal * 1000, "000000000000000000") & "D"
                        Else                        'credit
                            vCrTotal += vAmount
                            vBuild += Format(vCrTotal * 1000, "000000000000000000") & "C"
                        End If
                        vAmount = 0
                        vDrTotal = 0
                        vCrTotal = 0

                        vBuild += Space(1)

                        vBuild += "PAYR"
                        vBuild += Space(1)

                        'vBuild += "GJ"
                        'vBuild += Space(3)

                        vBuild += vAltUid
                        vBuild += Space(2)

                        vBuild += "JV32"
                        vBuild += Space(11)

                        vCnt = 0
                        If Mid(txtRank.Text, 1, 3).Length < 3 Then
                            vDescription = txtRank.Text & " " & Mid(vTitle, 1, 5) & _
                            "-" & Format(CDate(cmbPeriod.SelectedValue), "MM/dd/yyyy")
                            vCnt = 24 - vDescription.Length
                        Else
                            vDescription = Mid(txtRank.Text, 1, 3) & " " & Mid(vTitle, 1, 4) & _
                            "-" & Format(CDate(cmbPeriod.SelectedValue), "MM/dd/yyyy")
                            vCnt = 24 - vDescription.Length
                        End If

                        vBuild += vDescription
                        If vCnt > 0 Then
                            vBuild += Space(vCnt)
                        End If

                        vBuild += Space(1)
                        vBuild += "00000000000000000000000"
                        vBuild += Space(51)
                        vBuild += "0000000000000000000000000000000000002"
                        vBuild += Space(13)

                        vDivAltCode = ""
                        vSecAltCode = ""
                        If (vGroup <> "") Then
                            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                            '' MODIFIED BY:  VIC GATCHALIAN                                          ''
                            '' DATE MODIFIED: 7/5/2012                                               ''
                            '' PURPOSE: TO CHECK FIRST THE GROUP CONTENTS BEFORE GETTING THE TABLE   ''
                            ''          INFOMRATION.                                                 ''
                            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                            If vGroup.ToLower.Contains("rc_cd") Then
                                cmRefSub.CommandText = "select Alt_Code from rc where Rc_Cd='" & rsRef("Rc_Cd") & "'"
                                rsRefSub = cmRefSub.ExecuteReader
                                If rsRefSub.Read Then
                                    If Not IsDBNull(rsRefSub("Alt_Code")) Then
                                        Dim vAltCode() As String
                                        Dim vSeparator As String = ""
                                        If rsRefSub("Alt_Code").ToString.Contains("-") Then
                                            vSeparator = "-"
                                        ElseIf rsRefSub("Alt_Code").ToString.Contains(".") Then
                                            vSeparator = "."
                                        ElseIf rsRefSub("Alt_Code").ToString.Contains("~") Then
                                            vSeparator = "~"
                                        End If
                                        vAltCode = rsRefSub("Alt_Code").ToString.Split(vSeparator)
                                        If UBound(vAltCode) > 0 Then
                                            vDivAltCode = vAltCode(0)
                                            vSecAltCode = vAltCode(1)
                                        Else
                                            vDivAltCode = rsRefSub("Alt_Code")
                                        End If
                                    End If
                                End If
                                rsRefSub.Close()
                            Else
                                If vGroup.ToLower.Contains("divcd") Then
                                    'GET DIV ALT CODE IN (hr_div_ref)
                                    Try
                                        cmRefSub.CommandText = "select Alt_Codes from hr_div_ref where Div_Cd='" & rsRef("DivCd") & "'"
                                        rsRefSub = cmRefSub.ExecuteReader
                                        If rsRefSub.Read Then
                                            If Not IsDBNull(rsRefSub("Alt_Codes")) Then
                                                vDivAltCode = rsRefSub("Alt_Codes")
                                            End If
                                        End If
                                        rsRefSub.Close()
                                    Catch ex As system.exception

                                    End Try
                                End If

                                If vGroup.ToLower.Contains("sectioncd") Then
                                    'GET SECTION ALT CODE IN (hr_section_ref)
                                    Try
                                        cmRefSub.CommandText = "select Alt_Codes from hr_section_ref where Section_Cd='" & rsRef("SectionCd") & "'"
                                        rsRefSub = cmRefSub.ExecuteReader
                                        If rsRefSub.Read Then
                                            If Not IsDBNull(rsRefSub("Alt_Codes")) Then
                                                vSecAltCode = rsRefSub("Alt_Codes")
                                            End If
                                        End If
                                        rsRefSub.Close()
                                    Catch ex As system.exception

                                    End Try
                                End If
                            End If
                            '''''''''''''''''''''''''' END OF MODIFICATION  '''''''''''''''''''''''''''''
                        End If

                        vCnt = 14 - vDivAltCode.Length
                        vBuild += vDivAltCode
                        vBuild += Space(vCnt)
                        vBuild += Space(1)

                        vCnt = 14 - vSecAltCode.Length
                        vBuild += vSecAltCode
                        vBuild += Space(vCnt)
                        vBuild += Space(1)

                        If rs("AcctCd").ToString.Contains("-") Then
                            vRankCode = rs("AcctCd").split("-")
                            vCnt = 29 - vRankCode(1).Length
                            vBuild += vRankCode(1)
                            vBuild += Space(vCnt)
                        Else
                            cmRefSub.CommandText = "select TOP 1 Alt_Codes from hr_employment_type  where EmploymentType in ('" & _
                                txtRank.Text.Replace(",", "','") & "')"
                            rsRefSub = cmRefSub.ExecuteReader
                            If rsRefSub.Read Then
                                If Not IsDBNull(rsRefSub("Alt_Codes")) Then
                                    vCnt = 29 - rsRefSub("Alt_Codes").Length
                                    vBuild += rsRefSub("Alt_Codes")
                                End If
                            Else
                                vCnt = 29 - txtRank.Text.Length
                                vBuild += txtRank.Text
                            End If
                            rsRefSub.Close()

                            vBuild += Space(vCnt)
                        End If
                        vBuild += Space(1)

                        If rs("ByEmployee") = 1 Then
                            vCnt = 91 - rsRef("Emp_Cd").Length
                            vBuild += rsRef("Emp_Cd")
                            vBuild += Space(vCnt)
                        Else
                            vBuild += Space(91)
                        End If

                        vCnt = 0
                    End If

                    If vBuild <> "" Then
                        vDumpData.AppendLine(vBuild)
                        vBuild = ""
                    End If
                Loop
                rsRef.Close()
            Loop
            rs.Close()

            IO.File.WriteAllText(vFilename, vDumpData.ToString)
            vScript = "window.open('downloads/" & Session.SessionID & "-POST_to_JV.txt','winjv','top=1,left=1,scrollbars=yes');"
        Catch ex As SqlClient.SqlException
            Response.Write(ex.Message)
        Finally
            c.Close()
            cm.Dispose()
            cmRef.Dispose()
            cmRC.Dispose()
            c.Dispose()
        End Try
    End Sub
End Class

