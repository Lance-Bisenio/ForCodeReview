Imports denaro
Partial Class applicanteducation
    Inherits System.Web.UI.Page
    Dim c As New sqlclient.sqlconnection
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If

        If Not IsPostBack Then
            Dim cm As New sqlclient.sqlcommand
            Dim dr As sqlclient.sqldatareader
            lblcaption.text = "Applicant's Educational Background"
            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c
            cm.CommandText = "select * from hr_applicant_scholastic where Emp_Cd='" & _
                Session("applicantno") & "' order by SeqId"
            dr = cm.ExecuteReader
            If dr.Read Then     'primary school
                txtCourse1.Text = IIf(IsDBNull(dr("Course")), "", dr("Course"))
                txtFrom1.Text = IIf(IsDBNull(dr("From_Date")), "", Format(dr("From_Date"), "MM/dd/yyyy"))
                txtTo1.Text = IIf(IsDBNull(dr("To_Date")), "", Format(dr("To_Date"), "MM/dd/yyyy"))
                txtSchool1.Text = IIf(IsDBNull(dr("School")), "", dr("School"))
                txtAddr1.Text = IIf(IsDBNull(dr("School_Address")), "", dr("School_Address"))
                txtAccomplish1.Text = IIf(IsDBNull(dr("Accomplishments")), "", dr("Accomplishments"))
                txtGrade1.Text = IIf(IsDBNull(dr("Final_Grade")), "", dr("Final_Grade"))
            End If
            If dr.Read Then     'secondary school
                txtCourse2.Text = IIf(IsDBNull(dr("Course")), "", dr("Course"))
                txtFrom2.Text = IIf(IsDBNull(dr("From_Date")), "", Format(dr("From_Date"), "MM/dd/yyyy"))
                txtTo2.Text = IIf(IsDBNull(dr("To_Date")), "", Format(dr("To_Date"), "MM/dd/yyyy"))
                txtSchool2.Text = IIf(IsDBNull(dr("School")), "", dr("School"))
                txtAddr2.Text = IIf(IsDBNull(dr("School_Address")), "", dr("School_Address"))
                txtAccomplish2.Text = IIf(IsDBNull(dr("Accomplishments")), "", dr("Accomplishments"))
                txtGrade2.Text = IIf(IsDBNull(dr("Final_Grade")), "", dr("Final_Grade"))
            End If
            If dr.Read Then     'tertiary school
                txtCourse3.Text = IIf(IsDBNull(dr("Course")), "", dr("Course"))
                txtFrom3.Text = IIf(IsDBNull(dr("From_Date")), "", Format(dr("From_Date"), "MM/dd/yyyy"))
                txtTo3.Text = IIf(IsDBNull(dr("To_Date")), "", Format(dr("To_Date"), "MM/dd/yyyy"))
                txtSchool3.Text = IIf(IsDBNull(dr("School")), "", dr("School"))
                txtAddr3.Text = IIf(IsDBNull(dr("School_Address")), "", dr("School_Address"))
                txtAccomplish3.Text = IIf(IsDBNull(dr("Accomplishments")), "", dr("Accomplishments"))
                txtGrade3.Text = IIf(IsDBNull(dr("Final_Grade")), "", dr("Final_Grade"))
            End If
            If dr.Read Then     'masterial school
                txtCourse4.Text = IIf(IsDBNull(dr("Course")), "", dr("Course"))
                txtFrom4.Text = IIf(IsDBNull(dr("From_Date")), "", Format(dr("From_Date"), "MM/dd/yyyy"))
                txtTo4.Text = IIf(IsDBNull(dr("To_Date")), "", Format(dr("To_Date"), "MM/dd/yyyy"))
                txtSchool4.Text = IIf(IsDBNull(dr("School")), "", dr("School"))
                txtAddr4.Text = IIf(IsDBNull(dr("School_Address")), "", dr("School_Address"))
                txtAccomplish4.Text = IIf(IsDBNull(dr("Accomplishments")), "", dr("Accomplishments"))
                txtGrade4.Text = IIf(IsDBNull(dr("Final_Grade")), "", dr("Final_Grade"))
            End If
            If dr.Read Then     'doctorate school
                txtCourse5.Text = IIf(IsDBNull(dr("Course")), "", dr("Course"))
                txtFrom5.Text = IIf(IsDBNull(dr("From_Date")), "", Format(dr("From_Date"), "MM/dd/yyyy"))
                txtTo5.Text = IIf(IsDBNull(dr("To_Date")), "", Format(dr("To_Date"), "MM/dd/yyyy"))
                txtSchool5.Text = IIf(IsDBNull(dr("School")), "", dr("School"))
                txtAddr5.Text = IIf(IsDBNull(dr("School_Address")), "", dr("School_Address"))
                txtAccomplish5.Text = IIf(IsDBNull(dr("Accomplishments")), "", dr("Accomplishments"))
                txtGrade5.Text = IIf(IsDBNull(dr("Final_Grade")), "", dr("Final_Grade"))
            End If
            If dr.Read Then     'vocational school
                txtCourse6.Text = IIf(IsDBNull(dr("Course")), "", dr("Course"))
                txtFrom6.Text = IIf(IsDBNull(dr("From_Date")), "", Format(dr("From_Date"), "MM/dd/yyyy"))
                txtTo6.Text = IIf(IsDBNull(dr("To_Date")), "", Format(dr("To_Date"), "MM/dd/yyyy"))
                txtSchool6.Text = IIf(IsDBNull(dr("School")), "", dr("School"))
                txtAddr6.Text = IIf(IsDBNull(dr("School_Address")), "", dr("School_Address"))
                txtAccomplish6.Text = IIf(IsDBNull(dr("Accomplishments")), "", dr("Accomplishments"))
                txtGrade6.Text = IIf(IsDBNull(dr("Final_Grade")), "", dr("Final_Grade"))
            End If
            dr.Close()
            cm.Dispose()
            c.Close()
        End If
    End Sub
End Class
