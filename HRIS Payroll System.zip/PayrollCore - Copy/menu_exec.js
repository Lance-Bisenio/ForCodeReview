﻿// JScript File
var ajaxmenu;
var ajaxview;
function buildmenu(menuid){
    ajaxmenu = GetXmlHttpObject();
    if(ajaxmenu==null){ajaxerr();return;}
    var url = "navi.aspx";
    var id = menuid;
    var htmlelem = document.getElementById("contentvar");
    htmlelem.innerHTML = "";
    ajaxmenu.onreadystatechange=checkmenu;
	ajaxmenu.open("POST",url);
	ajaxmenu.setRequestHeader("Content-Type","application/x-www-form-urlencoded;charset = UTF-8");//send a POST header
	ajaxmenu.send("menuid="+id);
}

function checkmenu(){
    if(ajaxmenu.readyState==4 || ajaxmenu.readyState=="complete"){
        var htmlelem = document.getElementById("sidebarcontent");
        htmlelem.innerHTML = ajaxmenu.responseText;
    }
}

function buildview(viewid){
    ajaxview = GetXmlHttpObject();
    if(ajaxview==null){ajaxerr();return;}
    var url = "winview.aspx";
    var id = viewid;
    ajaxview.onreadystatechange=checkview;
	ajaxview.open("POST",url);
	ajaxview.setRequestHeader("Content-Type","application/x-www-form-urlencoded;charset = UTF-8");//send a POST header
	ajaxview.send("viewid="+id);
}

function checkview(){
    if(ajaxview.readyState==4 || ajaxview.readyState=="complete"){
        var htmlelem = document.getElementById("contentvar");
        htmlelem.innerHTML = ajaxview.responseText;
    }
}

function confirmexit(){
    if(confirm("Are you sure you want to logout?")){
        servtransfer("logoff.aspx");
    }
}