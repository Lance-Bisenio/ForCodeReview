Imports denaro.fis
Partial Class getshifts
    Inherits System.Web.UI.Page
    Public vReturn As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim c As New sqlclient.sqlconnection(connStr)
        Dim cmRef As New sqlclient.sqlcommand
        Dim rsRef As sqlclient.sqldatareader
        Dim vId As String = Request.Form("id")
        Dim vStart As Date = CDate(Request.Form("s"))
        Dim vEnd As Date = CDate(Request.Form("e"))
        Dim vStartDay As Date = vStart
        Dim vApprovedOT As Decimal = 0
        Dim vShifts As String = ""

        c.Open()
        cmRef.Connection = c

        vReturn = ""
        Do While vStartDay <= vEnd
            'check for any approved OT
            'cmRef.CommandText = "select sum(DaysLeave) as DaysLeave from hr_leave_application where Emp_Cd='" & vId & _
            '    "' and month(StartDate)=" & vStartDay.Month & " and day(StartDate)=" & vStartDay.Day & _
            '    " and year(StartDate)=" & vStartDay.Year & " and LeaveCd='OT' and Void=0 and DateApproved is not null"
            'rsRef = cmRef.ExecuteReader
            'vApprovedOT = 0
            'If rsRef.Read Then
            '    If Not IsDBNull(rsRef("DaysLeave")) Then
            '        vApprovedOT = rsRef("DaysLeave")
            '    End If
            'End If
            'rsRef.Close()

            'get schedule
            cmRef.CommandText = "select ShiftCd,Date_Sched,Start_Time from py_emp_time_sched where Date_Sched='" & _
                Format(vStartDay, "yyyy/MM/dd") & "' and Emp_Cd='" & vId & "'"

            rsRef = cmRef.ExecuteReader
            If rsRef.HasRows Then
                vShifts = ""
                Do While rsRef.Read
                    vShifts += rsRef("ShiftCd") & ","
                Loop
                vShifts = vShifts.Substring(0, vShifts.Length - 1)
                vReturn += vShifts & "-" & vApprovedOT & "~"
            Else       'empty schedule
                vReturn += "__-" & vApprovedOT & "~"
            End If
            rsRef.Close()
            vStartDay = DateAdd(DateInterval.Day, 1, vStartDay)
        Loop    'days
        c.Close()
        cmRef.Dispose()
        c.Dispose()
        If vReturn <> "" Then
            vReturn = vReturn.Substring(0, vReturn.Length - 1)
        End If
    End Sub
End Class
