<?php
	function fnAnalyze( $pEmp_Cd,$psdate ){  //function Analyze-Start
		global $vStart_Night;   //Start of Night Differential
		global $vEnd_Night;     //End of Night Differential
		global $vHalf_day;      //if No out and there is an In this variable is used a time out
		global $ReqHrs;         //Required Hour for the employee to render
		global $vHoly;          //1 if it will fall on holida 0 if regular day
		global $vLegal;         //1 if the holiday fall on legal holiday
		global $vEmpStat;       // Employee status of the employee
		global $vCasualCd;      // Code of the employee either casual, probationary or regular
		global $vFlexi;         // if the employee is entitled in flexi time
		global $vBreak;         // Break Hourse
		global $vGrade;          //
		global $vRateHr;        // Rate per hour of the employee
		global $vGrace;         //allowed Grace period by the company
		global $vOtAfter;       // A time used to check if the overhouse is entitle for Overtime
		global $vRegIn;
		global $vRegOut;
		global $vUsedSked;
		$vRest=false; //set to false 	
		$LogList = array();	//this is a multi-dimensional array with the following secondary elements for each record:
								//     [0] = Schedule Time In
								//     [1] = Schedule Time Out
								//     [2] = Schedule Hours
								//     [3] = Actual Time In
								//	   [4] = Actual Time Out
								//	   [5] = Actual Hours Worked
								//	   [6] = Shift Code
	
		//get number of records in shift schedule....
		$vsql = "select * from py_emp_time_sched where Date_Sched='" .
			date("Y/m/d",$psdate) . "' and Emp_Cd='" . $pEmp_Cd . "'";
		$cm = mysql_query($vsql);
		$skedCtr = mysql_num_rows($cm);
		$i=0;
		while($r = mysql_fetch_array($cm)) {
			$TmpIn = explode(" ",$r["Start_Time"]);
			$TmpOut = explode(" ",$r["End_Time"]);
			if(strtotime($TmpOut[1]) < strtotime($TmpIn[1])) {	//out is next day
				$LogList[$i][1] = date("Y/m/d",mktime(0,0,0,date("m",$psdate),date("d",$psdate) + 1,date("Y",$psdate))) . 
					" " . $TmpOut[1];
			} else {
				$LogList[$i][1] = date("Y/m/d",$psdate) . " " . $TmpOut[1];
			}
			$LogList[$i][0] = date("Y/m/d",$psdate) . " " . $TmpIn[1];
			$LogList[$i][2] = fnDateDiff("hour",$LogList[$i][0],$LogList[$i][1]);
			$LogList[$i][6] = (is_null($r["ShiftCd"])?"99":$r["ShiftCd"]);
			$i++;
		}
		
		//Get actual timein and time out of employee
		$vsql="select Type,Time_In,Time_Out,Time_OutDate,Etp from py_time_log where Tran_Date='" .
				 date("Y/m/d",$psdate) ."' and Emp_Cd='" . $pEmp_Cd . "'";	 
		$cm=mysql_query($vsql);
		$vIn = ""; $vOut = ""; $vOutD = ""; $vETP = 0; $vType = "99";
		$logCtr = mysql_num_rows($cm);
		
		if($logCtr==0 and $skedCtr==0){  //Current date is either absent or rest day 
			if ($vEmpStat != $vCasualCd and $vHoly){
				return; 
			}	
		} else {
			$vIn=$vOutD=$vOut="";
			switch($logCtr) {
				case 0:	//no logs, do nothing
					break;
				case 1:	//single log
					$r = mysql_fetch_array($cm);
					if( !is_null($r["Time_In"]) or trim($r["Time_In"])!=""){
						$vIn= date("Y/m/d",$psdate). " " . $r["Time_In"];
					}
					$vOutD = "";
					if( !is_null( $r["Time_OutDate"] ) or trim($r["Time_OutDate"]) != "") {	
						$vOutD = strtotime($r["Time_OutDate"]);	
						$vOut=date("Y/m/d",$vOutD) . " " . $r["Time_Out"];
					}else{
						$vOut = date("Y/m/d",$psdate) ." ". $vHalf_day;
					}
					switch($skedCtr){
						case 0:	//no schedule
							$LogList[0][0]="";	//sked in
							$LogList[0][1]="";	//sked out
							$LogList[0][2]=0;	//sked hrs rendered
							$LogList[0][3]=$vIn;	//actual log in
							$LogList[0][4]=$vOut;	//actual log out
							$LogList[0][5]=fnDateDiff("hour",$vIn,$vOut);
							$LogList[0][6]="";
							break;
						case 1: //single schedule
							$LogList[0][3]=$vIn;
							$LogList[0][4]=$vOut;
							$LogList[0][5]=fnDateDiff("hour",$vIn,$vOut);
							break;
						default: //multiple schedules found
							$vDiff = 99; //initialize to maximum level
							$idx = -1;
							$i=0;
							foreach($LogList as $In) {
								if(strtotime($In[0]) > strtotime($vIn)) {
									$variance =fnDateDiff("hour",$vIn,$In[0]);
								} else {
									$variance = fnDateDiff("hour",$In[0],$vIn);
								}
								if($variance < $vDiff) {	//computed variance is less than the previous variance, get the index.
									$idx = $i;
									$vDiff = $variance;		//set the new lowest variance
								}
								$i++;
							} 
							$LogList[$idx][3] = $vIn;
							$LogList[$idx][4] = $vOut;
							$LogList[$idx][5] = fnDateDiff("hour",$vIn,$vOut);
							break;
					}	//case 
					break;
				default:	//multiple log
					$iLoop=0;
					$tmplist=array();
					while($r=mysql_fetch_array($cm)) {
						if(!is_null($r["Time_In"]) or trim($r["Time_In"])!="") {
							$vIn = date("Y/m/d",$psdate) . " " . $r["Time_In"];
						}
						$vOutD="";
						if(!is_null($r["Time_OutDate"]) or trim($r["Time_OutDate"])!="") {
							$vOutD=strtotime($r["Time_OutDate"]);
							$vOut = date("Y/m/d",$vOutD) . " " .$r["Time_Out"];
						} else {
							$vOut = date("Y/m/d",$psdate) . " " .$vHalf_day;
						}
						$tmplist[$iLoop][0] = $vIn;		//actual in
						$tmplist[$iLoop][1] = $vOut;	//actual out
						$tmplist[$iLoop][2] = fnDateDiff("hour",$vIn,$vOut);	//hours worked
						$tmplist[$iLoop][3] = "";		//sched in
						$tmplist[$iLoop][4] = "";		//sched out
						$tmplist[$iLoop][5] = 0;		//sched hours
						$tmplist[$iLoop][6] = "";		//shift code
						$iLoop++;
					}	// while
					$iLoop=0;
					$vDiff=99;
					$idx = -1;
					foreach($tmplist as $tmp) {
						switch($skedCtr) {
							case 0:		//no schedule
								$LogList[$iLoop][0] = "";
								$LogList[$iLoop][1] = "";
								$LogList[$iLoop][2] = 0;
								$LogList[$iLoop][3] = $tmp[0];
								$LogList[$iLoop][4] = $tmp[1];
								$LogList[$iloop][5] = $tmp[2];
								$LogList[$iLoop][6] = "";
								break;
							case 1:			//single schedule
								if(strtotime($LogList[0][0]) > strtotime($tmp[0])) {
									$variance =fnDateDiff("hour",$tmp[0],$LogList[0][0]);
								} else {
									$variance = fnDateDiff("hour",$LogList[0][0],$tmp[0]);
								}
								
								if($variance < $vDiff){ //computed variance is less than the previous variance, get the index.
									$idx = $iLoop;
									$vDiff = $variance;		//set the new lowest variance
								}
								break;
							default: 		//multiple schedule, 1:1 assignment
								$LogList[$iLoop][3] = $tmp[0];
								$LogList[$iLoop][4] = $tmp[1];
								$LogList[$iLoop][5] = $tmp[2];
								break;
						}	//case
						$iLoop++;
					}	//for
					if($skedCtr==1) {	// for single schedules only
						$tmplist[$idx][3] = $LogList[0][0];
						$tmplist[$idx][4] = $LogList[0][1];
						$tmplist[$idx][5] = fnDateDiff("hour",$LogList[0][0],$LogList[1][1]);
						//assign back to loglist variable
						for($i=0;$i<count($tmplist);$i++) {
							$LogList[$i][0] = $tmplist[$i][3];
							$LogList[$i][1] = $tmplist[$i][4];
							$LogList[$i][2] = $tmplist[$i][5];
							$LogList[$i][3] = $tmplist[$i][0];
							$LogList[$i][4] = $tmplist[$i][1];
							$LogList[$i][5] = $tmplist[$i][2];
						}
					}

					break;
			}	//case
			
			foreach($LogList as $log) {
				//////////////// delete afterwards /////////////////
				print("Sked In: " . $log[0] . " Out: " . $log[1] . " Hrs: " . $log[2] . "<br/>" .
					  "Act  In: " . $log[3] . " Out: " . $log[4] . " Hrs: " . $log[5] . "<br/>");
				////////////////////////// END OF DELETE /////////////////////
				
				$vOtHrs = fnGetHrsAllowed($pEmp_Cd,$psdate,$log[6]); 
				$vRegIn = $log[0]; $vRegOut = $log[1];
				$vIn    = $log[3]; $vOut    = $log[4];
				fnDigestTime($psdate,$pEmp_Cd,$vETP,$vRegIn,$vIn,$vHoly,$vEmpStat,$vRateHr,$vGrace,
					$vRegOut,$vOut,$vLegal,$vGrade,$vOtHrs,$vOtAfter,$vStart_Night,$vEnd_Night,
					$vHalf_day,$vCasualCd,$log[5],$log[2]); 
			} 
		}	//end if
		
	} //function Analyze-End
	
	function fnGetHrsAllowed($pEmp_Cd,$psdate,$pShift) {
		$sql = "select * from hr_leave_application where LeaveCd='OT' and Emp_Cd='" . $pEmp_Cd .
			"' and year(StartDate)=" . date("Y",$psdate) .
			" and month(StartDate)=" . date("m",$psdate) . " and day(StartDate)=" . date("d",$psdate) .
			" and void=0 and DateApproved is not null and ShiftCd='" . $pShift . "'";
			
		$rs=mysql_query($sql);
		$vOtHrs=0;
		if(mysql_num_rows($rs) > 0 ) {
			$row=mysql_fetch_array($rs);
			//First Level of Checking
			if(!is_null($row["ApprovedBy"]) and !is_null($row["DateApproved"]) and is_null($row["RecommendedBy"]) ){
				$vOtHrs = (is_null($row["DaysLeave"])? 0: $row["DaysLeave"]);
			}else{
				if( !is_null($row["RecommendedBy"]) and !is_null($row["DateRecommended"]) and is_null($row["NotedBy"]) ){
					$vOtHrs = (is_null($row["DaysLeave"])? 0: $row["DaysLeave"]);
				}else{
					if( !is_null($row["NotedBy"]) and !is_null($row["DateNoted"]) ){
						$vOtHrs = (is_null($row["DaysLeave"])? 0: $row["DaysLeave"]);
					}
				}
			}
		}
		return $vOtHrs;
	}
	
	function fnDigestTime($psdate,$pEmp_Cd,$vETP,$vRegIn,$vIn,$vHoly,$vEmpStat,$vRateHr,
		$vGrace,$vRegOut,$vOut,$vLegal,$vGrade,$vOtHrs,$vOtAfter,$vStart_Night,$vEnd_Night,
		$vHalf_day,$vCasualCd,$pActualHrs,$pSkedHrs) { 		
		
		global $ReqHrs;
		$vsql = "delete from py_time_log_dtl where Reason='Auto-generated'" .
				" and Emp_Cd='" . $pEmp_Cd . "' and TranDate='" . date("Y/m/d",$psdate) . "'";
		mysql_query($vsql);
				
		//Check for Rest Day
		if ( $vRegIn == "" and $vIn == ""){ 
			return;
		}
		
		if($vIn == "" and $vRegIn != "") {	
			if($vHoly and $vEmpStat != $vCasualCd ) { //employee is a regular employee
				return;
			}
			
			if(($vHoly and !$vLegal) or !$vHoly) { 
				$vsql = "select * from py_time_log where Emp_Cd='" . 
					$pEmp_Cd . "' and Tran_Date='" . date("Y/m/d",$psdate) . 
					"' and Time_In='" . date("H:i:s",strtotime($vIn)) . "'";
					
				$rs=mysql_query($vsql);
				if( mysql_num_rows($rs) <= 0 ) {	//record does not exist, write new log
					$vsql = "insert into py_time_log(Tran_Date,Emp_Cd,Emp_Name," .
					        "Time_In,Time_Out,Time_OutDate) values ('" .
							date("Y-m-d",$psdate) ."','" . $pEmp_Cd . "','" .
							$vName . "','" . date("H:i:s",strtotime($vIn)) . 
							"','" . date("H:i:s",strtotime($vOut)) . "','" .
							date("Y/m/d",strtotime($vOut)) . "')";
					mysql_query($vsql);
				}
				
				$vsql = "select * from py_time_log_dtl where Emp_Cd='" .
						 $pEmp_Cd . "' and TranDate='" . date("Y-m-d",$psdate) . "'";
				$rs=mysql_query($vsql);
				if( mysql_num_rows($rs) <= 0 ) {
					$vsql="insert into py_time_log_dtl(Emp_Cd,TranDate,TranCd,Reason,Hrs_Rendered,AmtConv,Time_In)" .
					      "values('" . $pEmp_Cd . "','" . date("Y/m/d",$psdate) . "','ABSENT','Auto-generated'," . 
						  $ReqHrs . "," . ($vRateHr * -1) . ",'" . date("H:i:s",strtotime($vIn)) . ")";
					mysql_query($vsql);
				} 
			}
			return;
		}
		
		//Check for Ovetime in restday
		if($vIn != "" and $vRegIn == "" ){
			if(!$vHoly) {   //Rest Day does not fall on a Holiday(Code is E1 to E4)
				fnExtractTime("E1","E2","E3","E4", $psdate,$pEmp_Cd,$vOut,$vIn,$vRegOut,$vOtHrs,$vOtAfter,$vGrade,
					$vRateHr,$vStart_Night,$vEnd_Night,$pActualHrs,$pSkedHrs,$vRegIn);
			}else{  //Rest Day Falls on a Holiday
				if( $vLegal ) {		//Holiday is a Legal Holiday
					fnExtractTime("D1","D2","D3","D4", $psdate, $pEmp_Cd,$vOut,$vIn,$vRegOut,$vOtHrs,$vOtAfter,$vGrade,
						$vRateHr,$vStart_Night,$vEnd_Night,$pActualHrs,$pSkedHrs,$vRegIn);
				}else{  //Holiday is a special (Code is B1 to B4)	
					fnExtractTime("B1","B2","B3","B4",$psdate,$pEmp_Cd,$vOut,$vIn,$vRegOut,$vOtHrs,$vOtAfter,$vGrade,
						$vRateHr,$vStart_Night,$vEnd_Night,$pActualHrs,$pSkedHrs,$vRegIn);
				}
			}
			return;
		}
		
		if($vIn != "" and $vRegIn != "") {
			if(!$vHoly) { //Regulard Day
				fnCheckRegular($psdate,$pEmp_Cd,$vIn,$vRegIn,$vGrace,$vRegOut,$vOut,$vRateHr,
					$vStart_Night,$vEnd_Night,$vOtAfter,$vOtHrs,$pActualHrs,$pSkedHrs,$vGrade);	
			}else{ //Check for Overtime in Holiday
				if($vLegal) {  //Holiday is a Legal Holiday				
					fnExtractTime("C1","C2","C3","C4",$psdate,$pEmp_Cd,$vOut,$vIn,$vRegOut,$vOtHrs,$vOtAfter,$vGrade,
						$vRateHr,$vStart_Night,$vEnd_Night,$pActualHrs,$pSkedHrs,$vRegIn);
				}else{	//Holiday is a Special Holiday
					fnExtractTime( "F1","F2","F3","F4",$psdate,$pEmp_Cd,$vOut,$vIn,$vRegOut,$vOtHrs,$vOtAfter,$vGrade,
						$vRateHr,$vStart_Night,$vEnd_Night,$pActualHrs,$pSkedHrs,$vRegIn);
				}
			}	
			return;
		}
	}	// Function Digest Time
	
	function fnExtractTime($p1,$p2,$p3,$p4,$psdate,$pEmp_Cd,$vOut,$vIn,$vRegOut,$vOtHrs,$vOtAfter,
		$vGrade,$vRateHr,$vStart_Night,$vEnd_Night,$pActualHrs,$pSkedHrs,$vRegIn) {
		$vHours=0;		//excess hours
		if($pActualHrs > $pSkedHrs) {
			$vHours = $pActualHrs - $pSkedHrs;
		}
		
		///////////////////////////////////////////////////////////////////////////////////////////////////////////
		//$vHours = (int) $vHours + fnRoundOff( ($vHours - (int) $vHours) ); -- this is only used if you want to //
		//																	 -- to round off the remainder into //
		//																     -- multiples of 15mins or .25 hours /
		//////////////////////////////////////////////////////////////////////////////////////////////////////////
		if(strtotime(date("H:i:s",strtotime($vRegIn))) >= strtotime(date("H:i:s",strtotime($vStart_Night)))) {
			//if regular shift falls on night differential,calculate the night diff regular
			$vHours = fnDateDiff( "hour", date("Y/m/d",$psdate) . " " . date("H:i:s",strtotime($vStart_Night)), $vOut );
			fnWriteLog("A4", $vHours,$pEmp_Cd, date("Y/m/d",strtotime($vIn)),
				$vHours, $vRateHr,date("H:i:s",strtotime($vIn)));
		}
		
		if( $vHours > $vOtAfter ) {  //should at least consumes the minimum # of hours to recognze the approved OT
			
			if( $vHours > $vOtHrs ) {		//if actual hours is greater than the approved hours,realign hours
				$vHours = $vOtHrs;
			}
			if(strtolower($vGrade)=="l-4a" or strtolower($vGrade)=="l-4b") {		//for VC use only
				$vRateHr = 1;
				$pCode = (strpos(strtolower($p1),"a") >=0?"G1":"G2");
				fnWriteLog($pCode, (int) ($vHours / 2) , $pEmp_Cd, date("Y/m/d",strtotime($vIn)),
						$vHours,$vRateHr,date("H:i:s",strtotime($vIn)));
			} elseif(strtotime($vGrade)=="l-5a" or strtotime($vGrade)=="l-5b") {							//for VC use only
				$vRateHr = 1;
				$pCode = (strpos(strtolower($p1),"a") >=0?"G3":"G4");
				fnWriteLog($pCode, (int) ($vHours / 2), $pEmp_Cd, date("Y/m/d",strtotime($vIn)),
					$vHours,$vRateHr,date("H:i:s",strtotime($vIn)));
			} else {
				fnWriteLog($p1, ($vHours > 8? 8: $vHours), $pEmp_Cd, date("Y/md/",strtotime($vIn)),
					($vHours > 8? 8: $vHours), $vRateHr,date("H:i:s",strtotime($vIn)));
				if ($vHours > 8) {		//Overtime is over 8 hours
					fnWriteLog($p3, ($vHours - 8), $pEmp_Cd, date("Y/m/d",strtotime($vIn)),
						($vHours - 8), $vRateHr,date("H:i:s",strtotime($vIn)));
				} 
			}	

			//Checking if it falls on Night Differential
			if($vRegIn=="" or strtotime(date("H:i:s",strtotime($vRegIn))) >= strtotime(date("H:i:s",strtotime($vStart_Night))))
			{
				//if there is overtime on restday, holiday or restday on a holiday or with schedule but less than 10pm//
				if(strtotime(date("H:i:s",strtotime($vOut))) > strtotime(date("H:i:s",strtotime($vStart_Night)))) {
					//out is After 10pm
					$vHours = fnDateDiff( "hour", date("Y/m/d",$psdate) . " " . date("H:i:s",strtotime($vStart_Night)), $vOut );	
					//get first 2 hours of night differential overtime
					fnWriteLog( $p2, ($vHours > 2? 2: $vHours),$pEmp_Cd, date("Y/m/d",strtotime($vIn)),
							($vHours > 2? 2: $vHours), $vRateHr,date("H:i:s",strtotime($vIn)));
					if( $vHours > 2 ) {
						//if hours is more than 2 hours, get the excess of 2 hours for night differential overtime in 
						//excess of 2 hours
						fnWriteLog($p4, $vHours - 2, $pEmp_Cd, date("Y/m/d",strtotime($vIn)),
							$vHours - 2,$vRateHr,date("H:i:s",strtotime($vIn)));
					}
				}	//out is after 10pm
			}
		}  //vhours > votafter
	}
	
	function fnRoundOff( $pRemainder ) {
		if ( $pRemainder > 0.75 ) {
			return 0.75;
		}
		if ( $pRemainder > 0.5 ) {
			return 0.5;
		}
		if ( $pRemainder > 0.25 ) {
			return 0.25;
		}
		
		return 0;

	}
	
	function fnWriteLog( $vtxtETP, $pHrs, $pEmp_Cd, $psdate, $pOrgHrs, $vRateHr, $pIn ){
		$vsql ="select OtPer from py_ot_ref where OtCd='" . $vtxtETP . "'";
		$rs=mysql_query($vsql);
		if( mysql_num_rows($rs) > 0 ) {
			$row=mysql_fetch_array($rs);
			$vFactor = (is_null($row["OtPer"]))? 0: $row["OtPer"];
		}
		
		//ADD NEW DATA
		$hrsrendered=($vtxtETP == "ETP")? 1: $pOrgHrs;
		
		$amtconv = ($vtxtETP == "ETP"? $pOrgHrs:round($vFactor*$pHrs*$vRateHr,2));
		$vStr = "insert into py_time_log_dtl(Emp_Cd,TranDate,TranCd,Hrs_Rendered,AmtConv,Reason,Time_In)" .
		        "values ('" . $pEmp_Cd . "','" . $psdate . "','" .
				 $vtxtETP . "'," . $hrsrendered . "," . $amtconv . ",'Auto-generated','" . $pIn . "')";
		mysql_query($vStr);
	}
	
	function fnCheckRegular( $psdate,$pEmp_Cd,$vIn,$vRegIn,$vGrace,$vRegOut,$vOut,$vRateHr,
							$vStart_Night,$vEnd_Night,$vOtAfter,$vOtHrs,$pActualHrs,$pSkedHrs,$vGrade){
		$vTardy=0;
		//Check for Tardiness
		
		if (strtotime($vIn) < strtotime($vRegIn)) {
			$vIn = $vRegIn;
		}else{
			$vOrgRegIn = $vRegIn;
			$vRegIn =    date("Y/m/d", strtotime($vRegIn)) . " " . fnAdjustGrace(strtotime($vRegIn), $vGrace);
				
			if(strtotime($vIn) > strtotime($vRegIn) ){	//still with tardiness even with grace period
				$vTardy = fnDateDiff("minute",$vRegIn,$vIn);
				$vsql = "select * from py_tardiness_table where " . $vTardy . " between FromMinutes and ToMinutes";
				$rs=mysql_query($vsql);
				
				$vFactor=1;  //Default to 100% 
				if( mysql_num_rows($rs) > 0 ){
					$row=mysql_fetch_array($rs);
					$vFactor = (is_null($row["Factor"])?1:$row["Factor"]);
					if($row["RoundTo"] != 0) {
						$vTardy = (is_null($row["RoundTo"])? 0 : $row["RoundTo"]);	
					}
				}
				$vTardy = ($vTardy * $vFactor) / 60;
			}
		}
		
		//Check for UnderTime
		if( strtotime($vOut) < strtotime($vRegOut)){ //UnderTime
			$vTardy += fnDateDiff("minute",$vOut,$vRegOut);
		}
		if ( $vTardy != 0 ){
			 fnWriteLog("TARD", $vTardy, $pEmp_Cd, date("Y/m/d",$vIn), $vTardy, $vRateHr,date("H:i:s",$vIn) );
		}
			
		if($pActualHrs > $pSkedHrs) {
			$vHours = $pActualHrs - $pSkedHrs;
		}
		
		///////////////////////////////////////////////////////////////////////////////////////////////////////////
		//$vHours = (int) $vHours + fnRoundOff( ($vHours - (int) $vHours) ); -- this is only used if you want to //
		//																	 -- to round off the remainder into //
		//																     -- multiples of 15mins or .25 hours /
		//////////////////////////////////////////////////////////////////////////////////////////////////////////
        if(strtotime($vRegOut) >= strtotime(date("Y/m/d",$psdate) . " " . $vStart_Night)) {
			//if regular shift falls on night differential,calculate the night diff regular
            
			$vHours = fnDateDiff( "hour", date("Y/m/d",$psdate) . " " . date("H:i:s",strtotime($vStart_Night)), $vOut );
			fnWriteLog("A4", $vHours,$pEmp_Cd, date("Y/m/d",strtotime($vIn)),
				$vHours, $vRateHr,date("H:i:s",strtotime($vIn)));
		}
		
		if( $vHours > $vOtAfter ) {  //should at least consumes the minimum # of hours to recognze the approved OT
			if( $vHours > $vOtHrs ) {		//if actual hours is greater than the approved hours,realign hours
				$vHours = $vOtHrs;
			}
			print ("Overtime Hours: " . $vHours);
			if(strtolower($vGrade)=="l-4a" or strtolower($vGrade)=="l-4b") {		//for VC use only
				$vRateHr = 1;
				$pCode = (strpos(strtolower($p1),"a") >=0?"G1":"G2");
				fnWriteLog($pCode, (int) ($vHours / 2) , $pEmp_Cd, date("Y/m/d",strtotime($vIn)),
						$vHours,$vRateHr,date("H:i:s",strtotime($vIn)));
			} elseif(strtotime($vGrade)=="l-5a" or strtotime($vGrade)=="l-5b") {							//for VC use only
				$vRateHr = 1;
				$pCode = (strpos(strtolower($p1),"a") >=0?"G3":"G4");
				fnWriteLog($pCode, (int) ($vHours / 2), $pEmp_Cd, date("Y/m/d",strtotime($vIn)),
					$vHours,$vRateHr,date("H:i:s",strtotime($vIn)));
			} else {
				fnWriteLog("A1", $vHours, $pEmp_Cd, date("Y/md/",strtotime($vIn)),
					$vHours, $vRateHr,date("H:i:s",strtotime($vIn)));
			}	

			//Checking if it falls on Night Differential
			if($vRegIn=="" or strtotime(date("H:i:s",strtotime($vRegIn))) >= strtotime(date("H:i:s",strtotime($vStart_Night))))
			{
				//if there is overtime on restday, holiday or restday on a holiday or with schedule but less than 10pm//
				if(strtotime(date("H:i:s",strtotime($vOut))) > strtotime(date("H:i:s",strtotime($vStart_Night)))) {
					//out is After 10pm
					$vHours = fnDateDiff( "hour", date("Y/m/d",$psdate) . " " . date("H:i:s",strtotime($vStart_Night)), $vOut );	
					//get first 2 hours of night differential overtime
					fnWriteLog( "A2", ($vHours > 2? 2: $vHours),$pEmp_Cd, date("Y/m/d",strtotime($vIn)),
							($vHours > 2? 2: $vHours), $vRateHr,date("H:i:s",strtotime($vIn)));
					if( $vHours > 2 ) {
						//if hours is more than 2 hours, get the excess of 2 hours for night differential overtime in 
						//excess of 2 hours
						fnWriteLog("A3", $vHours - 2, $pEmp_Cd, date("Y/m/d",strtotime($vIn)),
							$vHours - 2,$vRateHr,date("H:i:s",strtotime($vIn)));
					}
				}	//out is after 10pm
			}
		}  //vhours > votafter
	}
	
	function fnAdjustGrace($pdate, $pvGrace ){
		$vHr=0; $vMin=0;
		if ( $pvGrace > 59 ) {
			$vHr = (int) $pvGrace / 60;
			$vMin = $pvGrace - ($vHr * 60);		// $pvGrace Mod 60;
		} else {
			$vMin = $pvGrace;
		}
		
		$vHr +=  (int) date("H",$pdate);
		$vMin += (int) date("i",$pdate);
		$AdjustGrace = $vHr . ":" . $vMin . ":" . "00";
		return $AdjustGrace;
	}
	/////////////////////
?>