<?php
	require_once("inc/connect.php");
	require_once("inc/activate.php");
	require_once("inc/chkuid.php");
	require_once("inc/fn.php");
	parse_str($_SERVER['QUERY_STRING']);
	
	//echo $_SERVER['QUERY_STRING'].'<br>';
	
	$title = "Print/Download Bank Advise";
	$message="";
	$url="";
	$rpturl="";
	//$bank_account = $_POST["bank_account"];
	$banktype="All";
	$rc=fnBuildCombo("select Rc_Cd,Descr from rc where Rc_Cd in ('" .
		str_replace(",","','",$_SESSION["rclist"]) . "') order by Descr",fnGetVal("cmbRC"));
	$ofc=fnBuildCombo("select AgencyCd,AgencyName from agency where AgencyCd in ('" . 
		str_replace(",","','",$_SESSION["agencylist"]) . "') order by AgencyName",fnGetVal("cmbOffice"));
	$div=fnBuildCombo("select Div_Cd,Descr from hr_div_ref where Div_Cd in ('" . 
		str_replace(",","','",$_SESSION["divlist"]) . "') order by Descr",fnGetVal("cmbDiv"));
	$type=fnBuildCombo("select EmploymentType,Descr from hr_employment_type  where EmploymentType in ('" .
		str_replace(",","','",$_SESSION["typelist"]) . "') order by Descr",fnGetVal("cmbType"));
	$cutoff=fnBuildCombo("select distinct date_format(PayDate,'%Y/%c/%e') as Pay_Date,concat(date_format(FromDate,'%Y/%c/%d'),'-',date_format(ToDate,'%Y/%c/%d')) as CutOff from py_report where year(PayDate)=" . 
		date("Y") . " order by FromDate desc",fnGetVal("cmbCutOff"));
		
	////////// event handlers ///////////////
	if(isset($_POST["cmdReturn"])) {
		unset($_SESSION["filter"]);
		unset($_SESSION["format"]);
		unset($_SESSION["ofc"]);
		unset($_SESSION["creditdate"]);
		unset($_SESSION["type"]);
		header("Location: main.php");
	}
	if(isset($_POST["txtCreditDate"])) {
		$creditdate=$_POST["txtCreditDate"];
	}
	if(isset($_POST["cmbCutOff"])) {
		if($_POST["cmbCutOff"]=="All") {
			$message = "alert('Please select a specific cut off date first.');";
		} else {	//get paydate vlaue
			$paydate=$_POST["cmbCutOff"];
			$creditdate=$_POST["cmbCutOff"];
		}
	}
	
	if(isset($_POST["cmdRefresh"])) {
		foreach($_POST["rdoType"] as $banktype) {
			$_SESSION["bank_type"]=$banktype;
		}
		
		$filter=" where PayDate='" . $_POST["txtPayDate"] . "' ";
		if($_POST["cmbOffice"]=="All") 
		{
			$filter .=" and Agency_Cd in ('" . str_replace(",","','",$_SESSION["agencylist"]) . "') ";
		} else 
		{
			$filter .= " and Agency_Cd='" . $_POST["cmbOffice"] . "' ";
		}
		if($_POST["cmbRC"]=="All") {
			$filter .=" and Rc_Cd in ('" . str_replace(",","','",$_SESSION["rclist"]) . "')";
		} else {
			$filter .= " and Rc_Cd='" . $_POST["cmbRC"] . "' ";
		}
		if($_POST["cmbDiv"]="All") {
			$filter .= " and DivCd in ('" . str_replace(",","','",$_SESSION["divlist"]) . "') ";
		} else {
			$filter .= " and DivCd='" . $_POST["cmbDiv"] . "' ";
		}
		if($_POST["cmbType"]=="All") {
			$filter .= " and EmploymentType in ('" . str_replace(",","','",$_SESSION["typelist"]) . "') ";
		} else {
			$filter .= " and EmploymentType='" . $_POST["cmbType"] . "' ";
		}
		
		if($banktype!="All") 
		{
			if($banktype!="NA") 
			{
				$filter .= " and Report_No<>'' ";
			} 
				else 
			{
				$filter .= " and (Report_No='' or Report_No is null) ";
			}
		}
		$_SESSION["ofc"] = $_POST["cmbOffice"];
		$_SESSION["creditdate"] = $_POST["txtCreditDate"];
		$_SESSION["filter"]= $filter;
		$_SESSION["format"]=$_POST["cmbBank"];
		
		if($_POST["cmbBank"]=='MB')
		{
			$url="reports/rpt_bankadviseMB.php";
		}
		else
		{
			//$url="reports/rpt_bankadvise.php";
			//$rpturl="downloads/" . session_id() . "-bankadvise.txt";
		}
	}
	
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Print/Download Bank Adivse Page</title>
</head>
<script language="javascript" type="text/javascript">
	function validate() 
	{
		co=document.getElementById("cmbOffice").value;
		if(co=="All") {
			alert("You must first select an Office.");
			
		} else {
			link="setupadvise.php?co=" + co
			win=window.open(link,'win','top=100,left=100,height=250,width=400,scrollbar=no,toolbar=no');
		}
	}
	
	function chkfields() {
		if(document.getElementById("cmbOffice").value=="All" && document.getElementById("cmbRC").value != "HO") {
			alert("You must first select an Office.");
			return false;
			
		}
		if(document.getElementById("cmbCutOff").value=="All") {
			alert("You must first select a specific cut off period.");
			return false;
			
		}
		return true;
		
	}
</script>
<style type="text/css" media="all">
			@import url("s/base.css");
			@import url("wii_mac/wii_mac.css");
</style>

<body onload="invoke()">
<form id="form1" name="form1" method="post">

	<?php require_once("inc/header.inc"); ?>
	<?php require_once("inc/sidebartop.inc"); ?>
		<table border="0" width="100%">
			<tr style="height:30px;">
				<td width="40%" class="label">Select Cut - Off Period :</td>
				<td width="60%">
					<select id="cmbCutOff" name="cmbCutOff" class="inputbox" style="width:100%;" onchange="document.form1.submit();">
						<?php print($cutoff); ?>
                    </select>
				</td>
			</tr>
			
			<tr style="height:30px;">
				<td width="40%" valign="top" class="label">Pay - Date :</td>
				<td width="60%" valign="top">
					<input type="text" id="txtPayDate" name="txtPayDate" class="inputbox" style="width:100%;" readonly="readonly" value="<?php print($paydate); ?>" />
				</td>
			</tr>
			
			<tr style="height:30px;">
				<td width="40%" valign="top" class="label">Credit - Date :</td>
				<td width="60%" valign="top">
					<input type="text" id="txtCreditDate" name="txtCreditDate" class="inputbox" style="width:100%;" value="<?php print($creditdate); ?>" />
				</td>
			</tr>
			
			
			<tr style="height:30px;">
				<td width="40%" class="label" valign="top">Cost Center :</td>
				<td width="60%" valign="top">
					<select id="cmbRC" name="cmbRC" class="inputbox" style="width:100%;">
                    	<?php print($rc); ?>
                    </select>
				</td>
			</tr>
			
			<tr style="height:30px;">
				<td width="40%" class="label" valign="top">Office :</td>
				<td width="60%" valign="top">
					<select id="cmbOffice" name="cmbOffice" class="inputbox" style="width:100%;">
                    	<?php print($ofc); ?>
                    </select>
				</td>
			</tr>
			
			<tr style="height:30px;">
				<td width="40%" valign="top" class="label">Division :</td>
				<td width="60%" valign="top">
					<select id="cmbDiv" name="cmbDiv" class="inputbox" style="width:100%;">
                    	<?php print($div); ?>
                    </select>
				</td>
			</tr>
			
			<tr style="height:30px;">
				<td width="40%" valign="top" class="label">Employment Type :</td>
				<td width="60%" valign="top">
					<select id="cmbType" name="cmbType" class="inputbox" style="width:100%;">
                    	<?php print($type); ?>
                    </select>
				</td>
			</tr>
			
			<tr style="height:30px;">
				<td width="40%" valign="top" class="label">Bank Format :</td>
				<td width="60%" valign="top">
					<select id="cmbBank" name="cmbBank" class="inputbox" style="width:100%;">
						<option value="MB" <?php if($_POST["cmbBank"]=="MB") { print("selected='selected'"); } ?>>Metrobank Format</option>
						<option value="RCBC" <?php if($_POST["cmbBank"]=="RCBC") { print("selected='selected'"); } ?>>RCBC Format</option>
                        <option value="BDO" <?php if($_POST["cmbBank"]=="BDO") { print("selected='selected'"); } ?>>BDO Format</option>
                        <option value="BPI" <?php if($_POST["cmbBank"]=="BPI") { print("selected='selected'"); } ?>>BPI Format</option>
					</select>
				</td>
			</tr>
			
			<tr style="height:30px;">
				<td width="40%" valign="top" class="label">Bank Account Type :</td>
				<td width="60%" valign="top">
					<table border="1" width="100%">
						<tr>
							<td>
								<input type="radio" id="rdoType1" name="rdoType[]" class="inputbox" <?php if($banktype=="CA") { print("checked='checked'");}?> value="CA" style="width:10px;" />
							</td>
							<td>With Account</td>
						</tr>
						
						<tr>
							<td>
								<input type="radio" id="rdoType3" name="rdoType[]" class="inputbox" <?php if($banktype=="NA") { print("checked='checked'");}?> value="NA" style="width:10px;" />
							</td>
							<td>No Account</td>
						</tr>
					</table>
                   
				</td>
			</tr>
			
			
		</table><br>
	    <input type="submit" id="cmdRefresh" name="cmdRefresh" class="linkstyle" value="Generate" style="width:100%;" onclick="return chkfields();"/>
    	<input type="button" class="linkstyle" value="Setup" style="width:100%;" name="cmdsetup" onclick="validate();" /><br />
        <input type="button" class="linkstyle" value="Print Bank Advise" style="width:100%" onclick="javascript:frmdata.window.print();" />
     <?php require_once("inc/sidebarbottom.inc"); ?>
	<?php require_once("inc/topcontentborder.inc"); ?>
		 <iframe scrolling="auto" style="width:98%; height:420px;" id="frmdata" name="frmdata" src="<?php print($url) ?>" >
        </iframe>
  	<?php require_once("inc/bottomcontentborder.inc"); ?>
	

</form>
</body>
</html>
<script language="javascript" type="text/javascript">
	function invoke() {
		<?php print($message); ?>
	}
</script>

<?php
	require_once("inc/disconnect.php");
?>