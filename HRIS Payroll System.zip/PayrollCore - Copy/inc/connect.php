<?php
mysql_connect('localhost','root','');
mysql_select_db('accsys_victoria');
$sysname='ACCSYS';
$systemname='ONLINEPAYROLL';
?>