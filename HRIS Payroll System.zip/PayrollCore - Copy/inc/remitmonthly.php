<?php
	require_once("inc/connect.php");
	require_once("inc/activate.php");
	require_once("inc/chkuid.php");
	require_once("inc/fn.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>Generate Monthly Remittance Page</title> <style type="text/css" media="all">
			@import url("s/base.css");
			@import url("wii_mac/wii_mac.css");
	</style>
    
    <script language="javascript" type="text/javascript">
		
		
		function changecaption(c) 
		{
			document.getElementById("cmdSetup").style.visibility = "visible";
			document.getElementById("frame1").src="";
			switch(c.value) {
				case "SSS":
					document.getElementById("cmdSetup").value = "SSS Setup";
					break;
				case "PAGIBIG": 
					document.getElementById("cmdSetup").value = "PAGIBIG Setup";
					break;
				case "PHIL":
					document.getElementById("cmdSetup").value = "Philhealth Setup";
					break;
				case "TAX":
					document.getElementById("cmdSetup").value = "TAX Setup";
					break;
				default:
					document.getElementById("cmdSetup").value="";
					document.getElementById("cmdSetup").style.visibility = "hidden";
					break;
			}
		}
		
		function getwindow(c) {
			switch(c.value){
				
				case "SSS Setup":	
					sss=window.open('sssetup.php','sss','width=455,height=130,status=no,resizable=no,top=220,left=270,dependent=yes,alwaysRaised=yes,scrollbars=no');
					break;
				case "PAGIBIG Setup": 
					pag=window.open('pagibigsetup.php','pagibig','width=455,height=200,status=no,resizable=no,top=220,left=270,dependent=yes,alwaysRaised=yes,scrollbars=no');
					break;
				case "Philhealth Setup":
					ph=window.open('phicsetup.php','ph','width=455,height=200,status=no,resizable=no,top=220,left=270,dependent=yes,alwaysRaised=yes,scrollbars=no');	
					break;
				default:
					break;
			}
		}
		
		function ShowTextFile(txt_file)
		{
			var win = window.open('downloadText.php?txt_file='+txt_file, 'Text File', 'height=300,width=700,top=100,left=100,scrollbars=yes');
		}
		
    </script>
    
    
    <?php 
		
		// path for the created file... -jpb
		//print_r($_POST);
		$lstReport = $_POST['lstReport'];
		
		//echo $_SERVER['DOCUMENT_ROOT'];
		define('DOWNLOAD_PATH',  '/accsys/downloads');
		
		$title = "Generate Monthly Remittance Page";
		$year = $_POST['year'];
		
		//////// event handlers ///////////
		if(isset($_POST["cmdReturn"])) 
		{
			unset($_SESSION["ofc"]);
			unset($_SESSION["rc"]);
			unset($_SESSION["filter"]);
			unset($_SESSION["month"]);
			unset($_SESSION["rc"]);
		
			unset($_SESSION["div"]);
			unset($_SESSION["dept"]);
			unset($_SESSION["section"]);
			unset($_SESSION["unit"]);
			unset($_SESSION["type"]);
			unset($_SESSION["loan"]);
			unset($_SESSION["year"]);
			unset ($_SESSION["reportfil"]);
			header("Location: main.php");
		}
		
		
		$rc=fnBuildCombo("select Rc_Cd, Descr from rc where Rc_Cd in ('" .
                str_replace(",","','",$_SESSION["rclist"]) . "') order by Descr ", fnGetVal("cmbRC"));
		$ofc=fnBuildCombo("select AgencyCd, AgencyName from agency where Agencycd in ('" .
                str_replace(",","','",$_SESSION["agencylist"]) . "') order by AgencyName", fnGetVal("cmbOfc"));
		$div=fnBuildCombo("select Div_Cd,Descr from hr_div_ref where Div_Cd in ('" .
                str_replace(",","','",$_SESSION["divlist"]). "') order by Descr", fnGetVal("cmbDiv"));
		$dept=fnBuildCombo("select Dept_Cd,Descr from hr_dept_ref where Dept_Cd in ('" .
               str_replace(",","','",$_SESSION["deptlist"]) . "') order by Descr", fnGetVal("cmbDept"));
		$section=fnBuildCombo("select Section_Cd,Descr from hr_section_ref where Section_Cd in ('" .
                str_replace(",","','",$_SESSION["sectionlist"]) . "') order by Descr", fnGetVal("cmbSection"));
		$unit=fnBuildCombo("select Unit_Cd,Descr from hr_unit_ref where Unit_Cd in ('" .
               str_replace(",", "','",$_SESSION["unitlist"]) . "') order by Descr", fnGetVal("cmbUnit"));
		$type=fnBuildCombo("select EmploymentType,Descr from hr_employment_type where EmploymentType in ('" .
                str_replace(",", "','",$_SESSION["typelist"]) . "') order by Descr", fnGetVal("cmbType"));		
		$unit=fnBuildCombo("select Unit_Cd,Descr from hr_unit_ref where Unit_Cd in ('" .
               str_replace(",", "','",$_SESSION["unitlist"]) . "') order by Descr", fnGetVal("cmbUnit"));
		$status=fnBuildCombo("select Status_Code,Descr from py_employee_stat order by Descr", fnGetVal("cmbStatus"));
		
	
		if(isset($_POST["cmbMonth"]))
		{
			$month=$_POST["cmbMonth"];
		} 
		else 
		{
			$month=date("m");
		}
	$url="";
	
	//---------------------------------------------------------------------------------
	$report="SSS";
	if(isset($_POST["cmdRefresh"])) 
	{
		$_SESSION["Report"]=$_POST["lstReport"];
		$vFilter="";
		

		if($_POST["cmbOfc"] != "All") 
		{ //filter by office
			$vFilter .= " Agency_Cd='" . $_POST["cmbOfc"]. "' ";
			$reportfil .=" py_report.Agency_Cd='" . $_POST["cmbOfc"]. "' ";
		} 
		else 
		{
			$vFilter .= "  Agency_Cd in ('" . str_replace(",","','",$_SESSION["agencylist"]). "') ";
			$reportfil .= " py_report.Agency_Cd in ('" . str_replace(",","','",$_SESSION["agencylist"]). "') ";
		}
		
		if($_POST["cmbRC"] != "All") 
		{ //filter by cost center
			$vFilter .= " and Rc_Cd='" . $_POST["cmbRC"]. "' ";
		} 
		else 
		{
			$vFilter .= " and Rc_Cd in ('" . str_replace(",","','",$_SESSION["rclist"]). "') ";
		}
		
		if($_POST["cmbDiv"] != "All") 
		{ //filter by division
			$vFilter .= " and DivCd='" . $_POST["cmbDiv"]. "' ";
			$reportfil .= " and py_report.DivCd='" . $_POST["cmbDiv"]. "' ";
		} 
		else 
		{
			$vFilter .= " and DivCd in ('" . str_replace(",","','",$_SESSION["divlist"]). "') ";
			$reportfil .= " and py_report.DivCd in ('" . str_replace(",","','",$_SESSION["divlist"]). "') ";
		}
		
		if($_POST["cmbDept"] != "All") 
		{ //filter by Department
			$vFilter .= " and DeptCd='" . $_POST["cmbDept"]. "' ";
		} 
		else 
		{
			$vFilter .= " and DeptCd in ('" . str_replace(",","','",$_SESSION["deptlist"]). "') ";
		}
		
		if($_POST["cmbSection"] != "All") 
		{ //filter by Section
			$vFilter .= " and SectionCd='" . $_POST["cmbSection"]. "' ";
		} 
		else 
		{
			$vFilter .= " and SectionCd in ('" . str_replace(",","','",$_SESSION["sectionlist"]). "') ";
		}
		
		if($_POST["cmbUnit"] != "All") 
		{ //filter by Unit
			$vFilter .= " and UnitCd='" . $_POST["cmbUnit"]. "' ";
		} 
		else 
		{
			$vFilter .= " and UnitCd in ('" . str_replace(",","','",$_SESSION["unitlist"]). "') ";
		}
		if($_POST["cmbType"] != "All") 
		{ //filter by Employment type
			$vFilter .= " and EmploymentType='" . $_POST["cmbType"]. "' ";
		} 
		else 
		{
			$vFilter .= " and EmploymentType in ('" . str_replace(",","','",$_SESSION["typelist"]). "') ";
		}
		
			 
		$vFilter .= " and month(PayDate)=" . $_POST["cmbMonth"] ." and year(PayDate)=" . $year;
	
		$_SESSION["with_sss"] = $_POST["wsss"];
		$_SESSION["reportfil"] = $reportfil;
		$_SESSION["filter"] = $vFilter;
		$_SESSION["month"] = $_POST["cmbMonth"];
		$_SESSION["ofc"]=$_POST["cmbOfc"];
		$_SESSION["rc"]=$_POST["cmbRC"];
		$_SESSION["div"]=$_POST["cmbDiv"];
		$_SESSION["dept"]=$_POST["cmbDept"];
		$_SESSION["section"]=$_POST["cmbSection"];
		$_SESSION["unit"]=$_POST["cmbUnit"];
		$_SESSION["type"]=$_POST["cmbType"];
		$_SESSION["loan"] = $_POST["lstReport"];
		$_SESSION["year"] = $year;
		
		if(isset($_POST["lstReport"])) 
		{
			$report=$_POST["lstReport"];
			switch($_POST["lstReport"]) 
			{
				case "SSS" :
					$validation = validation_paydate(1);
					if($validation =="")
					{
						echo '<script language="javascript">alert("No Contribution/s on this month.");self.close();</script>';
					}
					else
					{
						$url="reports/remit_print.php";
						echo '<script type="text/javascript">ShowTextFile(\''.session_id().'-sss.txt'.'\');</script>';
						SSS_REMIT_MONTHLY($validation);
					}
					
					break; 
				case "PAGIBIG":
					$validation = validation_paydate(2);
					if($validation =="")
					{
						echo '<script language="javascript">alert("No Contribution/s on this month.");self.close();</script>';
					}
					else
					{
						$url="reports/remit_pagibig_print.php";
						echo '<script type="text/javascript">ShowTextFile(\''.session_id().'-PAGIBIGREMITTANCE.csv'.'\');</script>';
						pagibig_excel($validation);
					}
					
					break;
				case "PHIL":
					
					$validation = validation_paydate(3);
					if($validation =="")
					{
						echo '<script language="javascript">alert("No Contribution/s on this month.");self.close();</script>';
					}
					else
					{
						$url="reports/remit_philhealth_print.php";
						echo '<script type="text/javascript">ShowTextFile(\''.session_id().'-phic.txt'.'\');</script>';
						PHILHEALTH_REMITTANCE($validation);
					}
					break;
				
			}
		}
	}
	
	
?>
</head>
<body>
    <form id="form1" name="form1" method="post">
    <?php require_once("inc/header.inc"); ?>
    <?php require_once("inc/sidebartop.inc"); ?>
    
    <table  border="0" cellpadding="0" cellspacing="0" class="a" style="width: 100%;">
        <tr>
        	<td align="right" class="label" style="width: 45px;" >Cost-Center:</td>
        	<td align="left" style="width: 45px; height: 14px" valign="top">
        		<select id="cmbRC" class="inputbox" name="cmbRC" style="width: 146px">
        			<?php print($rc);?>
       		 	</select>
       	 	</td>
        </tr>
        
        <tr>
        	<td align="right" class="label">Office:</td>
        	<td>
        		<select id="cmbOfc" class="inputbox" name="cmbOfc" style="width: 145px">
        			<?php print($ofc); ?>
        		</select>
        	</td>
        </tr>
        
        <tr>
        	<td align="right" class="label">Division:</td>
        	<td>
        		<select id="cmbOfc" class="inputbox" name="cmbDiv" style="width: 145px">
        			<?php print($div); ?>
        		</select>
        	</td>
        </tr>
        
        <tr>
        	<td align="right" class="label">Dept.:</td>
        	<td>
        		<select id="cmbOfc" class="inputbox" name="cmbDept" style="width: 145px">
        			<?php print($dept); ?>
        		</select>
        	</td>
        </tr>
        
        <tr>
        	<td align="right" class="label">Section:</td>
        	<td>
        		<select id="cmbOfc" class="inputbox" name="cmbSection" style="width: 145px">
        			<?php print($section); ?>
        		</select>
        	</td>
        </tr>
        
        <tr>
        	<td align="right" class="label">Unit:</td>
        	<td>
        		<select id="cmbOfc" class="inputbox" name="cmbUnit" style="width: 145px">
        			<?php print($unit); ?>
        		</select>
        	</td>
        </tr>
        
        <tr>
        	<td align="right" class="label">Type:</td>
        	<td>
        		<select id="cmbOfc" class="inputbox" name="cmbType" style="width: 145px">
        			<?php print($type); ?>
        		</select>
        	</td>
        </tr>
        
        <tr>
        	<td align="right" class="label">Month:</td>
        	<td>
                <select id="cmbMonth" class="inputbox" name="cmbMonth" style="width: 145px">
                    <option value="1" <?php if($month==1) { print("selected='selected'"); } ?>>January</option>
                    <option value="2" <?php if($month==2) { print("selected='selected'"); } ?>>February</option>
                    <option value="3" <?php if($month==3) { print("selected='selected'"); } ?>>March</option>
                    <option value="4" <?php if($month==4) { print("selected='selected'"); } ?>>April</option>
                    <option value="5" <?php if($month==5) { print("selected='selected'"); } ?>>May</option>
                    <option value="6" <?php if($month==6) { print("selected='selected'"); } ?>>June</option>
                    <option value="7" <?php if($month==7) { print("selected='selected'"); } ?>>July</option>
                    <option value="8" <?php if($month==8) { print("selected='selected'"); } ?>>August</option>
                    <option value="9" <?php if($month==9) { print("selected='selected'"); } ?>>September</option>
                    <option value="10" <?php if($month==10) { print("selected='selected'"); } ?>>October</option>   
                    <option value="11" <?php if($month==11) { print("selected='selected'"); } ?>>November</option>
                    <option value="12" <?php if($month==12) { print("selected='selected'"); } ?>>December</option>   
                </select>
            </td>
        </tr>
        
        <tr>
            <td align="right" class="label">Year:</td>
            <td>
            <?php
				echo "<select name='year'  class='inputbox' style='width:145px'>";
					for($y=2007; $y<=date("Y"); $y++)
					{
						echo "<option value='$y'  ".($year==$y?'selected':'')." >$y</option>";
					}
				echo "</select>";
            ?>
            </td>
        </tr>
    </table>
    <br>
    
    <table border="1" width="80%">
        <tr>
            <td  width="15%"><input name="wsss" type="radio" value="0" style="width:10px;"  <?php echo $_POST["wsss"]==0?"checked":""; ?>>	</td>
            <td  width="855%">No SSS</td>
        </tr>
        
         <tr>
            <td width="15%"><input name="wsss" type="radio" value="1" style="width:10px;"  <?php echo $_POST["wsss"]==1?"checked":""; ?> /></td>
            <td  width="85%">With SSS No.</td>
       	</tr>
    </table>
    
    <br>
    <hr />
        <br />
            <input id="cmdRefresh" class="linkstyle" name="cmdRefresh" type="submit" value="Refresh" style="width:100%"  />
            <input id="cmdSetup" class="inputbox" name="cmdSetup" type="button" value="Set Up" style="width:100%" onclick="getwindow(this);" /> 
            <input type="button" class="linkstyle" value="Print this document" id='cmdprint' onclick="frame1.window.print();" style="width:100%" />
        <br />
    <hr />
    
    Select Report<br />     
    <select name="lstReport" size="10" id="lstReport" style="width:200px;" onchange="changecaption(this);">
        <option value="SSS" <?php if($report=="SSS") { print("selected='selected'"); } ?>>SSS Remittance</option>
        <option value="PAGIBIG" <?php if($report=="PAGIBIG") { print("selected='selected'"); } ?>>PagIbig Remittance</option>
        <option value="PHIL" <?php if($report=="PHIL") { print("selected='selected'"); } ?>>Philhealth Remittance</option>
        <!--
        <option value="TAX" <?php if($report=="TAX") { print("selected='selected'"); } ?>>Tax Remittance</option>
        <option value="EPF" <?php if($report=="EPF") { print("selected='selected'"); } ?>>Employee Pre-validation File</option>
        -->
        <?php reports($lstReport); ?>
    </select>
    
    <?php require_once("inc/sidebarbottom.inc"); ?>
    <?php require_once("inc/topcontentborder.inc"); ?>
    
    <div align="center">
    	<iframe id="frame1" name="frame1" style="width:99%; height:450px;" scrolling="yes" src="<?php print($url); ?>"></iframe>
    </div>
    
    <?php require_once("inc/bottomcontentborder.inc"); ?>
    </form>
    </body>
</html>
<?php
	function SSS_REMIT_MONTHLY($employees)
	{
		extract($GLOBALS);
		//echo $year."BEBE<br>";
			$vEC = 0;
			$vOut = "";
   			$vDate = "";
   			$vSSS  = "";
   			$vLName = "";
   			$vFName = "";
   			$vMName = "";
   		
   			$i_ctr = 1;
   			$v_tot[0] = $v_tot[1] = $v_tot[2] = $v_tot[3] = 0;
			
			
			$query = "select Company_Name,HeaderNo,TrailerNo,Employer_SssNo,StubNo from glsyscntrl";
			$result = mysql_query($query) or die(mysql_error());
			$row = mysql_fetch_array($result);
			
			$m = (int) $_POST['cmbMonth'];
			if(($m==1)||($m==4)||($m==7)||($m==10)||($m==2)||($m==5)||($m==8)||($m==11))
			{
				$vOut = "00";
			}
			else
			{
				$vOut = "000";
			}
			$company_nm = substr($row['Company_Name'], 0, 30);
			$vOut .= AlNumOnly($company_nm).Space(30-strlen($company_nm));
			//$emp_sss_no = substr($row['Employer_SssNo'], 0, 10).Space(70);
			$emp_sss_no = substr($row['Employer_SssNo'], 0, 10).Space(68);
			$vOut .= sprintf('%02d',$_POST['cmbMonth']).$year.$emp_sss_no.Space(10-strlen($emp_sss_no))."\r\n";
			
			$cmEmp = 	"Select Emp_Cd,Name, sum(Sss_Per) as Sss_Emp, sum(Sss_Gov) as Sss_Emr, Sum(Ec) as E_c
     					from py_report where Emp_Cd in ($employees) and month(PayDate)=".$_POST['cmbMonth']." 
						and year(PayDate)=".$year."  group by Emp_Cd order by Name";
			 
			$rs_Emp = 	mysql_query($cmEmp) or die(mysql_error());
			$iCtr = 0;
   
			while($row_Emp = mysql_fetch_array($rs_Emp))
			{
				$iCtr ++;
      			$cm = "select  Sss_No,Emp_Lname,Emp_Fname,Emp_Mname,Start_Date from py_emp_master 
					 where Emp_Cd='" .$row_Emp["Emp_Cd"] . "'";
         		$rs = mysql_query($cm) or die(mysql_error());
				$row = mysql_fetch_array($rs);
				if(mysql_num_rows($rs) > 0) 
				{
					$emp_lname = empty($row['Emp_Lname'])?"":trim(substr($row['Emp_Lname'], 0, 15));
					$emp_fname = empty($row['Emp_Fname'])?"":trim(substr($row['Emp_Fname'], 0, 15));
					$emp_mname = $row['Emp_Mname']=="."?" ":substr($row['Emp_Mname'], 0, 1);
					$emp_start_date = date('mdy', strtotime($row['Start_Date']));
					$emp_start_month=date('n', strtotime($row['Start_Date']));
					$emp_start_year=date('Y', strtotime($row['Start_Date']));
					
					if(!empty($row['Sss_No']))
						$vSSS = substr(str_replace('-', '', $row['Sss_No']), 0, 10);
					
					$vOut .= '20'.AlNumOnly($emp_lname).Space(15-strlen($emp_lname)).AlNumOnly($emp_fname).Space(15-strlen($emp_fname))
						. $emp_mname;
					$vOut .= $vSSS;
					
					$vPer = empty($row_Emp['Sss_Emp'])?0:$row_Emp['Sss_Emp'];
      				$vGov = empty($row_Emp["Sss_Emr"])?0:$row_Emp['Sss_Emr'];
      				$vEC =  $row_Emp["E_c"];
					
					$emp_contri = $vPer + $vGov;
					$emp_contri = sprintf('%.2f', $emp_contri);
					$emp_contri = sprintf('%4.2f', $emp_contri);
					$emp_contri	= sprintf('%7s',$emp_contri);
					
					$emr_contri = $vEC;
					$emr_contri = sprintf('%.2f', $emr_contri);
					$emr_contri = sprintf('%2.2f', $emr_contri);
					$emr_contri	= sprintf('%4s',$emr_contri);
		
					
					//PER MONTH
					//SIR VIC
							if($m==1 or $m==4 or $m==7 or $m==10) 
							{


									//Falls on Jan, Apr, Jul, or Oct
							/*	$vOut .=Space(1).$emp_contri.Space(4)."0.00".Space(4)."0.00".
										Space(2)."0.00".Space(2)."0.00".Space(2)."0.00".Space(1).
										$emr_contri.Space(2)."0.00".Space(2)."0.00".
										sprintf('%02d',$_POST['cmbMonth']).$year."N".$emp_start_date.Space(2)."\r\n"; 
								*/
								$vOut .=Space(1).$emp_contri.Space(4)."0.00".Space(4)."0.00".
										Space(2)."0.00".Space(2)."0.00".Space(2)."0.00".Space(1).
										$emr_contri.Space(2)."0.00".Space(2)."0.00".Space(6) . "N"; 
								/*print("Start Month:".$emp_start_month."Start Year:".$emp_start_year.
								     " Selected Month:".$_POST['cmbMonth']." Selected Year:".$year)."<br/>";		*/
								
								if( $emp_start_month==$_POST['cmbMonth'] and $emp_start_year==$year) {
									$vOut.=$emp_start_date."\r\n";	
								} else {
									$vOut.="0     \r\n";	
								}
									
								
//										sprintf('%02d',$_POST['cmbMonth']).$year."N".

							}
							elseif($m==2 or $m==5 or $m==8 or $m==11) 
							{	//falls on FEB, MAY, AUG, & NOV
								/*$vOut .=	Space(4)."0.00".Space(1).$emp_contri.Space(4)."0.00".Space(2)."0.00".Space(2)."0.00".
											Space(2)."0.00".Space(2)."0.00".Space(1).$emr_contri.Space(2)."0.00".
											sprintf('%02d',$_POST['cmbMonth']).$year."N".$emp_start_date.Space(2)."\r\n";*/
								
								$vOut .=	Space(4)."0.00".Space(1).$emp_contri.Space(4)."0.00".Space(2)."0.00".Space(2)."0.00".
											Space(2)."0.00".Space(2)."0.00".Space(1).$emr_contri.Space(2)."0.00".
											Space(6)."N";
											
								if($emp_start_month==$_POST['cmbMonth'] and $emp_start_year==$year) {
									$vOut.=$emp_start_date."\r\n";	
								} else {
									$vOut.="0     \r\n";	
								}			
											
							}
							else 
							{   // falls on MAR, JUN, SEP, & DEC
								/*$vOut .=Space(4)."0.00".Space(4)."0.00".Space(1).$emp_contri.Space(2)."0.00".Space(2)."0.00".
										Space(2)."0.00".Space(2)."0.00".Space(2)."0.00".Space(1).$emr_contri.
										sprintf('%02d',$_POST['cmbMonth']).$year."N".$emp_start_date.Space(2)."\r\n";*/
								
								$vOut .=Space(4)."0.00".Space(4)."0.00".Space(1).$emp_contri.Space(2)."0.00".Space(2)."0.00".
										Space(2)."0.00".Space(2)."0.00".Space(2)."0.00".Space(1).$emr_contri.Space(6)."N";
								
								if($emp_start_month==$_POST['cmbMonth'] and $emp_start_year==$year) {
									$vOut.=$emp_start_date."\r\n";	
								} else {
									$vOut.="0     \r\n";
								}		

							}
						
						$v_tot[0] += $vPer;
      					$v_tot[1] += $vGov;
      					$com_share +=$vEC;
      					$v_tot[3] += ($vPer + $vGov);
											
				}
					
			}
			
			$v_tot = $v_tot[0]+$v_tot[1];
			$v_tot = sprintf('%.2f', $v_tot);
			$v_tot = sprintf('%10.2f', $v_tot);
			$v_tot	= sprintf('%10s',$v_tot);
			
			$v_ec = sprintf('%.2f', $com_share);
			$v_ec = sprintf('%8.2f', $v_ec);
			$v_ec	= sprintf('%8s',$v_ec);
			
			if($m==1 or $m==4 or $m==7 or $m==10) 
			{		//Falls on Jan, Apr, Jul, or Oct
				/*$vOut .= "99".Space(1).$v_tot.Space(8)."0.00".Space(8)."0.00".Space(7)."0.00".Space(6)."0.00".
						  Space(6)."0.00".Space(2).$v_ec.Space(6)."0.00".Space(6)."0.00".Space(20); */
				$vOut .= "99".Space(2).$v_tot.Space(8)."0.00".Space(8)."0.00".Space(6)."0.00".Space(6)."0.00".
						  Space(6)."0.00".Space(2).$v_ec.Space(6)."0.00".Space(6)."0.00".Space(18);
			} 
			elseif($m==2 or $m==5 or $m==8 or $m==11) 
			{	//falls on FEB, MAY, AUG, & NOV
				/*$vOut .= "99".Space(7)."0.00".Space(2).$v_tot.Space(8)."0.00".Space(7)."0.00".Space(6)."0.00".Space(6)."0.00".
						  Space(6)."0.00".Space(2).$v_ec.Space(6)."0.00".Space(20); */
				$vOut .= "99".Space(8)."0.00".Space(2).$v_tot.Space(8)."0.00".Space(6)."0.00".Space(6)."0.00".Space(6)."0.00".
						  Space(6)."0.00".Space(2).$v_ec.Space(6)."0.00".Space(18);
			} 
			else 
			{	//	MAR, JUN, SEP, & DEC
				/*$vOut .= "99".Space(7)."0.00".Space(8)."0.00".Space(2).$v_tot.Space(7)."0.00".Space(6)."0.00".Space(6)."0.00".
						Space(6)."0.00".Space(6)."0.00".Space(2).$v_ec.Space(20); */
				$vOut .= "99".Space(8)."0.00".Space(8)."0.00".Space(2).$v_tot.Space(6)."0.00".Space(6)."0.00".Space(6)."0.00".
						Space(6)."0.00".Space(6)."0.00".Space(2).$v_ec.Space(18);
			}
			
		
		if(file_exists($_SERVER['DOCUMENT_ROOT']. DOWNLOAD_PATH . '/'.session_id().'-sss.txt'))
		{
			unlink($_SERVER['DOCUMENT_ROOT']. DOWNLOAD_PATH . '/'.session_id().'-sss.txt');
		}

		WriteFile(session_id().'-sss.txt', $_SERVER['DOCUMENT_ROOT']. DOWNLOAD_PATH . '', $vOut);
	
	}

	
	function pagibig_excel($employees)
	{
	extract($GLOBALS);
		//FOR PAG - IBIG
		
		$query_pagibig = "select Tin,Emp_Lname,Emp_Fname,Emp_Mname,py_report.Emp_Cd,sum(PagIbig_Per) as Pag_Emp, 
							sum(PagIbig_Gov) as Pag_Emr ,sum(Pagibig_Per+Pagibig_Gov)as Total,Paydate
							from py_report,py_emp_master  where py_report.Emp_Cd=py_emp_master.Emp_Cd and 
							month(PayDate)=" . $_SESSION["month"] . " and year(PayDate)=" . $year."
							and py_report.Emp_Cd in ($employees) group by Emp_Cd order by Name";
		//secho $query_pagibig ;
		$rs_pagibig = mysql_query($query_pagibig) or die(mysql_error());
		
		$vOut .= "EYERID,HDMFID,LNAME,FNAME,MID,PERCC,PFRNO,PFRDATE,EE,ER,PFRAMT,REM"."\r\n";
		while($row_pagibig = mysql_fetch_array($rs_pagibig))
		{
			$vOut .='229-344-619-000,'.$row_pagibig["Tin"].','.$row_pagibig["Emp_Lname"].','.$row_pagibig["Emp_Fname"].','.$row_pagibig["Emp_Mname"].','.date('Ym',strtotime($row_pagibig["Paydate"])).',,,'.number_format($row_pagibig["Pag_Emp"],2).','.number_format($row_pagibig["Pag_Emr"],2).','.number_format($row_pagibig["Total"],2).','."\r\n";
		}
		
			if(file_exists($_SERVER['DOCUMENT_ROOT']. DOWNLOAD_PATH . '/'.session_id().'-PAGIBIGREMITTANCE.csv'))
			{
				unlink($_SERVER['DOCUMENT_ROOT']. DOWNLOAD_PATH . '/'.session_id().'-PAGIBIGREMITTANCE.csv');
			}
	
			WriteFile(session_id().'-PAGIBIGREMITTANCE.csv', $_SERVER['DOCUMENT_ROOT']. DOWNLOAD_PATH . '', $vOut);
	}
	
	
	function PHILHEALTH_REMITTANCE()
	{
		extract($GLOBALS);
		
        $vTmp = ''; 
		$v_hdr = "REMITTANCE REPORT";
		$vOut = $v_hdr.space(137)."\r\n"; 
       
		$vCompanyName = Space(60); $vName = Space(40); $vPosition = Space(20);
        $vAddress = Space(100); $vPHICNo = sprintf("%012d", 0);
        $iCtr = 0; $vNo = 0; $vGov = 0; $vPer = 0; $vTot = 0.00;
		
        $query = "select Company_Name,Address,PhicNo,Attention,AttentionPos 
						from glsyscntrl where AgencyCd='" . $_POST['cmbOfc'] . "'";
		$result = mysql_query($query) or die(mysql_error().'->'.$query);
		$row = mysql_fetch_array($result);

		$vCompanyName = empty($row["Company_Name"])?'':$row["Company_Name"];
		$vCompanyName = trim(substr($vCompanyName, 0, 60));
		$vAddress = empty($row["Address"])?'':$row["Address"];
		$vAddress = trim(substr($vAddress, 0, 100));
		$vPHICNo = empty($row["PhicNo"])?0:$row["PhicNo"];
		$vPHICNo = trim(substr($vPHICNo, 0, 12));
		$vName = empty($row["Attention"])?'':$row["Attention"];
		$vPosition = empty($row["AttentionPos"])?'':$row["AttentionPos"];
		
		//header
		$vCompanyName = strtoupper($vCompanyName) . Space(165 - strlen($vCompanyName));
		$vAddress = strtoupper($vAddress) . Space(161 - strlen($vAddress));
		$vPHICNo .=  Space(12-strlen($vPHICNo));

        $vOut .= AlNumOnly($vCompanyName) . "\r\n" . AlNumOnly($vAddress) . "\r\n" . $vPHICNo;
		
		$month = (int) $_POST['cmbMonth'];
		
		switch(true)
		{
			case ($month < 4): //1, 2, 3 - first qusrter
				$vOut .= '1';
				break;
			case ($month < 7): // 4, 5, 6 - second quarter
				$vOut .= '2';
				break;
			case ($month < 10): // 7, 8, 9 - third quarter
				$vOut .= '3';
				break;
			default: // 10, 11, 12 - fourth quarter
				$vOut .= '4';
				break;
		}
		
		$vOut .= $year . 'R' . "\r\n";
		$vOut .= 'MEMBERS'."\r\n";
		mysql_free_result($result);
		$row = $query = NULL;
		
		
		$month = (int) $_POST['cmbMonth'];
	   
		switch($month)
		{
			case ($month < 4): //1, 2, 3 - first qusrter
				$month_inc = "'1','2','3'";
				$ictr_i = 1;
				$ictr_t = 3;
				break;
			case ($month < 7): // 4, 5, 6 - second quarter
				$month_inc = "'4','5','6'";
				$ictr_i = 4;
				$ictr_t = 6;
				break;
			case ($month < 10): // 7, 8, 9 - third quarter
				$month_inc = "'7','8','9'";
				$ictr_i = 7;
				$ictr_t = 9;
				break;
			default: // 10, 11, 12 - fourth quarter
				$month_inc = "'10','11','12'";
				$ictr_i = 10;
				$ictr_t = 12;
				break;
		}
	
		if($_POST['cmbOfc'] != 'All')
			$add .= " and Agency_Cd='".$_POST['cmbOfc']."' ";
		else
			$add .= " and Agency_Cd in ('".str_replace(',', "','", $_SESSION['agencylist'])."') ";
		
		if($_POST['cmbRC'] != 'All')
			$add .= " and Rc_Cd='".$_POST['cmbRC']."' ";
		else
			$add .= " and Rc_Cd in ('".str_replace(',', "','", $_SESSION['rclist'])."') ";
		
		if($_POST["cmbDiv"] != "All") 
			$add .= " and DivCd='" . $_POST["cmbDiv"]. "' ";
		else 
			$add .= " and DivCd in ('" . str_replace(",","','",$_SESSION["divlist"]). "') ";
		
		if($_POST["cmbDept"] != "All") 
			$add .= " and DeptCd='" . $_POST["cmbDept"]. "' ";
		else 
			$add .= " and DeptCd in ('" . str_replace(",","','",$_SESSION["deptlist"]). "') ";
		
		if($_POST["cmbSection"] != "All") 
			$add .= " and SectionCd='" . $_POST["cmbSection"]. "' ";
		else 
			$add .= " and SectionCd in ('" . str_replace(",","','",$_SESSION["sectionlist"]). "') ";
		
		if($_POST["cmbUnit"] != "All") 
			$add .= " and UnitCd='" . $_POST["cmbUnit"]. "' ";
		else 
			$add .= " and UnitCd in ('" . str_replace(",","','",$_SESSION["unitlist"]). "') ";
	
		if($_POST["cmbType"] != "All") 
			$add .= " and EmploymentType='" . $_POST["cmbType"]. "' ";
		else 
			$add .= " and EmploymentType in ('" . str_replace(",","','",$_SESSION["typelist"]). "') ";
			
		//GET EMPLOYEES
		$query_get_emp = "Select Emp_Cd from py_report
					where month(PayDate) in ($month_inc) 
					and year(PayDate)=".$year." $add
					group by Emp_Cd order by Name";
		
		$rs_get_emp = mysql_query($query_get_emp) or die(mysql_error());
		while($row_get_emp = mysql_fetch_array($rs_get_emp))
		{
			//GET INFO IN 201
			$query_201 = "Select * from py_emp_master where Emp_Cd='".$row_get_emp["Emp_Cd"]."'";
			$rs_201 = mysql_query($query_201) or die(mysql_error());
			$row_201=mysql_fetch_array($rs_201);
			
			if(!empty($row_201["Sss_No"]))
			{
				$vPHICNo = trim(substr(str_replace('-', '', $row_201["Sss_No"]), 0, 12));
				$vPHICNo .= Space(12 - strlen($vPHICNo));
			}
			else
			{
				$vPHICNo = "X";
				$vPHICNo .= Space(12 - strlen($vPHICNo));
			}
			
			//echo $row_201["Emp_Lname"].", ".$row_201["Emp_Fname"]."=".$vPHICNo."==".$row_201["Sss_No"]."<br>";
			
			
			$vOut.= $vPHICNo;
			$vTmp = strtoupper(trim(substr($row_201["Emp_Lname"], 0, 30)));
            $vTmp .= Space(30 - strlen($vTmp));
            $vOut .= AlNumOnly($vTmp);
            $vTmp = strtoupper(trim(substr($row_201["Emp_Fname"], 0, 30)));
            $vTmp .= Space(30 - strlen($vTmp));
			$emp_mname = $row_201["Emp_Mname"]=="."?" ":substr($row_201["Emp_Mname"], 0, 1);
					
            $vOut .= AlNumOnly($vTmp) . strtoupper($emp_mname)."0";
			$vOut .= zeroTrail($row_201["Rate_Month"],8);
			
			//GET CONTRIBUTIONS
			for($ictr=$ictr_i; $ictr<=$ictr_t; $ictr++)
			{
				$count_emp=1;
				$query_eeec = "select sum(Medicare_Per) as Med_Emp, sum(Medicare_Gov) as Med_Emr 
							from py_report where month(PayDate)=" . $ictr . " and 
							year(PayDate)=" . $year . " and Emp_Cd='" . $row_201["Emp_Cd"]. "'";
				$rs_eeec = mysql_query($query_eeec) or die(mysql_error());
				$row_eeec = mysql_fetch_array($rs_eeec);
				
				$vPer_ee[$ictr] =  empty($row_eeec["Med_Emp"])?0:$row_eeec["Med_Emp"];
				$vGov_ec[$ictr] =  empty($row_eeec["Med_Emr"])?0:$row_eeec["Med_Emr"];
				$Contr_EE[$ictr]+=$row_eeec["Med_Emp"];
				$Contr_EC[$ictr]+=$row_eeec["Med_Emr"];
				
				if(($row_eeec["Med_Emp"]!=0)||($row_eeec["Med_Emr"]!=0))
				{
					$total_emp[$ictr]+=$count_emp;
				}
				
				//EMPLOYED
				$query_employed = "Select * from py_emp_master where Emp_Cd='".$row_201["Emp_Cd"]."' and year(Start_Date)='".$year."'
							  and month(Start_Date)='".$ictr."'";
				$rs_employed = mysql_query($query_employed) or die(mysql_error());
				$row_employed = mysql_fetch_array($rs_employed);
				$date_employed = date('m', strtotime($row_employed["Start_Date"]));
				
				if(mysql_num_rows($rs_employed)>=1)
				{
					$stat_emp = "NH".date('Ymd', strtotime($row_employed["Start_Date"]));
				}
				
				//RESIGNED
				$query_resign = "Select * from py_emp_master where Emp_Cd='".$row_201["Emp_Cd"]."' and year(Date_Resign)='".$year."'
							  and month(Date_Resign)='".$ictr."'";
				$rs_resign = mysql_query($query_resign) or die(mysql_error());
				$row_resign = mysql_fetch_array($rs_resign);
				$date_resign = date('m', strtotime($row_resign["Date_Resign"]));
				
				if(mysql_num_rows($rs_resign)>=1)
				{
					$stat_emp = "SP".date('Ymd', strtotime($row_resign["Date_Resign"]));
				}
				$count_emp++;
			}
			
			
			for($out_ctr=$ictr_i; $out_ctr<=$ictr_t-1; $out_ctr++)
			{
				$emp_ee = $vPer_ee[$out_ctr];
				$emp_ec = $vGov_ec[$out_ctr];
				$com_ee_ec .=zeroTrail($emp_ee,6).zeroTrail($emp_ec,6);
			}
			
			if($stat_emp!="")
			{
				$stat_emp = $stat_emp;
			}
			else
			{
				$stat_emp = Space(10);
			}
			
			$vOut.=$com_ee_ec.zeroTrail($vPer_ee[$ictr_t],6).zeroTrail($vGov_ec[$ictr_t],5).$stat_emp;
			unset($com_ee_ec);
			unset($stat_emp);
			
			$vOut.="\r\n";
		}
		
		$vOut .= 'M5-SUMMARY' . "\r\n";
		$ctr_s = 1;
		for($out_ctr=$ictr_i; $out_ctr<=$ictr_t; $out_ctr++)
		{
			$subtotal_ec_ee = $Contr_EE[$out_ctr]+$Contr_EC[$out_ctr];
			$total_ec_ee+= $subtotal_ec_ee;
			$subtotal_ec_ee = zeroTrail($subtotal_ec_ee,8);
			
			
			$vOut.=$ctr_s.$subtotal_ec_ee.Space(25).$total_emp[$out_ctr]."\r\n";
			$ctr_s++;
		}
		$total_ec_ee = zeroTrail($total_ec_ee,10);
		$vOut .= 'GRAND TOTAL' .$total_ec_ee."\r\n";
		$vOut .= strtoupper(AlNumOnly($vName)).Space(40-strlen($vName)) . strtoupper($vPosition);
		if(file_exists($_SERVER['DOCUMENT_ROOT']. DOWNLOAD_PATH . '/'.session_id().'-phic.txt'))
		{
			unlink($_SERVER['DOCUMENT_ROOT']. DOWNLOAD_PATH . '/'.session_id().'-phic.txt');
		}

		WriteFile(session_id().'-phic.txt', $_SERVER['DOCUMENT_ROOT']. DOWNLOAD_PATH . '', $vOut);
	}
	
	function zeroTrail($amount, $zero_s)
	{
		/**
		 *	Author: MakubeX
		 *	Description: appends trailing zeroes for a given amount
		 */

		/**
		 *	Author: MakubeX
		 *	Description: appends trailing zeroes for a given amount
		 */
		$places=$zero_s;
		if(!is_numeric($places)) {
			return die('invalid value for the no. of trailing zeroes for function zeroTrail()');
		}
	
		if(strpos($amount, '.') or strpos($amount, ',')) {
			$rem_dot = str_replace('.', '', (float) $amount);
			$clean   = str_replace(',', '', $rem_dot);
		}
		else {
			$clean = (float) $amount;
		}

	
		if($places==0) {
			return $clean;
		}
		elseif($places>0) {
			$len = strlen($clean);
			if($len < $places) {
				$num_zero = $places - $len;
				return $clean.str_repeat('0', $num_zero);
			}
			else {
				return $clean;
			}
		}
		else {
			return die('invalid number of trailing zeroes for zeroTrail()');
		}
	}
	
	
	function GetContr($pEmpCd, &$pNo, &$pPer, &$pGov)
	{
		extract($GLOBALS);
        $vMonth = (int) $_POST['cmbMonth'];
		
		
			$query = "select sum(Medicare_Per) as Med_Emp, sum(Medicare_Gov) as Med_Emr 
					from py_report where month(PayDate)=" . $vMonth . " and 
						year(PayDate)=" . $year . " and Emp_Cd='" . $pEmpCd . "'";
			$result = mysql_query($query) or die(mysql_error().'-> '.$query);
			$row = mysql_fetch_array($result);
	
			$vPer = $vGov = 0;
		
			$vPer = $pPer = empty($row["Med_Emp"])?0:$row["Med_Emp"];
			$vGov = $pGov = empty($row["Med_Emr"])?0:$row["Med_Emr"];
			$vPer = $vPer*100;
			$vGov = $vGov*100;
					
			$get_contr = '000000000000000000000000000000000000';
			
			switch(true)
			{
				case ($vMonth==1 || $vMonth==4 || $vMonth==7 || $vMonth==10): // first months of each quarter
					$get_contr = sprintf("%06s", $vPer) . sprintf("%06s", $vGov) . '000000000000000000000000';
					$pNo = 1;
					break;
				case ($vMonth==2 || $vMonth==5 || $vMonth==8 || $vMonth==11): //second months of each quarter
					$get_contr = '000000000000' . sprintf("%06s", $vPer) . sprintf("%06s", $vGov) . '000000000000';
					$pNo = 2;
					break;
				case ($vMonth==3 || $vMonth==6 || $vMonth==9 || $vMonth==12): //third months of each quarter
					$get_contr = '000000000000000000000000' . sprintf("%06s", $vPer) . sprintf("%06d", $vGov);
					$pNo = 3;
					break;
			}
		
		return $get_contr;
	}
	
	
	function WriteFile($file_name, $str_path, $file_cont)
	{
		$fh = fopen($str_path.'/'.$file_name, 'w') or die('can not write file!');
		fwrite($fh, $file_cont);
		fclose($fh);
	}

	function Space($num)
	{
		$sp = '';
		
		for($i=0; $i<$num; $i++)
			$sp .= ' ';
	
		return $sp;
	}
	
	function MonthEND($mn)
	{
		$dt = date('Y').'-'.$mn.'-01';
		return date('t', strtotime($dt));
	}
	
	function nf($val)
	{
		$val = (float) $val;
		return "\$".number_format($val, 2, '.', ',');
	}
	
	function reports($report)
	{
		extract($GLOBALS);
		
		$query = "select Loan_Cd,Loan_Name from py_loan_ref order by Loan_Name";
		$rs=mysql_query($query);
		$other="";
	
		while($row=mysql_fetch_array($rs)) 
		{
			echo "<option value='$row[0]' ".($row[0]==$report?'selected':'')." >$row[1]</option>";
		}
		  
	}
	
	function AlNumOnly($val)
	{
		return ereg_replace("[^A-Za-z0-9]", " ", $val);
	}
	
	function validation_paydate($pass_variable)
	{
		extract($GLOBALS);
		global $emp_list;
		
		//SSS
		if($pass_variable=='1')
		{
			$field_name = " Emp_Cd,Name,sum(Sss_Per) as Sss_Emp,sum(Sss_Gov) as Sss_Emr, sum(Ec) as E_C";
			$row_array = "Sss_Emp";
		}
		elseif($pass_variable=='2')
		{
			$field_name = " Emp_Cd,Name,sum(PagIbig_Per) as Pag_Emp,sum(PagIbig_Gov) as Pag_Emr ,sum(Pagibig_Per+Pagibig_Gov)as Total";
			$row_array = "Pag_Emp";
		}
		elseif($pass_variable=='3')
		{
			$field_name = " Emp_Cd,Name,sum(Medicare_Per) as Med_Emp, sum(Medicare_Gov) as Med_Emr";
			$row_array = "Med_Emp";
		}
		
		
		//GET EMP WHOSE SSS_SHARE is not equal to 0
		$quert_get_emp_ws = "select $field_name from py_report
					where  ".$_SESSION["filter"]."
					group by Name,Emp_Cd";
		$rs_get_emp_ws = mysql_query($quert_get_emp_ws) or die(mysql_error);
		while($row_get_emp_ws = mysql_fetch_array($rs_get_emp_ws))
		{
			if($row_get_emp_ws[$row_array] != '0')
			{
				$query_get_sss = "Select * from py_emp_master where Emp_Cd='".$row_get_emp_ws["Emp_Cd"]."'";
				$rs_get_sss = mysql_query($query_get_sss) or die(mysql_error());
				$row_get_sss = mysql_fetch_array($rs_get_sss);
				
				if($pass_variable=='1')
				{
					if($_POST["wsss"] == '1')
					{
						if($row_get_sss["Sss_No"]!="")
						{
							$emp_list .="'".$row_get_emp_ws["Emp_Cd"]."',";
						}
					}
					else
					{
						if($row_get_sss["Sss_No"]=="")
						{
							$emp_list .="'".$row_get_emp_ws["Emp_Cd"]."',";
						}
					}
				}
				else
				{
					$emp_list .="'".$row_get_emp_ws["Emp_Cd"]."',";
					
				}
				
			}
			
		}
		$emp_list  = substr($emp_list,0,$emp_list.length - 1);
		return $emp_list;
		
	}
?>

<?php
	require_once("inc/disconnect.php");
?>