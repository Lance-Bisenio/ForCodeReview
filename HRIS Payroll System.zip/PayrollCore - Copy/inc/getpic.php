<?php
	// check existence of picture
	$pic="pics/" . $_SESSION["uid"] . ".jpg";
?>