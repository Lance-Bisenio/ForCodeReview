<?php
	require_once("../inc/connect.php");
	require_once("../inc/activate.php");
	require_once("../inc/chkuid.php");
	require_once("../inc/fn.php");
	parse_str($_SERVER['QUERY_STRING']);
	//echo $_SERVER['QUERY_STRING'].'GENARRA<br>';
	define('DOWNLOAD_PATH',  '/accsys/downloads');
	cominfo();
	other_details();
	
	if($_SESSION["bank_type"]=='CA')
	{
		$header_up = "Employees with Account Number";
	}
	else
	{
		$header_up = "Employees with no Account Number";
	}
	//echo $_SESSION["bank_type"].'GEN';
	echo '<script type="text/javascript">ShowTextFile(\''.session_id().'-BANKADVISE.DAT'.'\');</script>';
	metrobank();
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Print Bank Advise</title>
<link href="../../accsys/wii_mac/wii_mac.css" rel="stylesheet" type="text/css" />
<script language="javascript" type="text/javascript">
	function ShowTextFile(txt_file)
		{
			var win = window.open('../downloadText.php?txt_file='+txt_file, 'Text File', 'height=300,width=700,top=100,left=100,scrollbars=yes');
		}
		
    </script>
</head>
<body onload="invoke();">
<form id="form1" name="form1" method="get">
	<div align="center">
    	<table border="0" width="100%">
			<tr>
				<td align="center" class="txtcompany"><?php echo  $header_report; ?></td>
			</tr>
			<tr>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td align="center" class="txtheader"><?php //echo $header_up; ?></td>
			</tr>
			<tr>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td>
					<table border="0" width="100%">
						<tr>
							<td width="20%" class="txtNormal"><b>Payroll Credit Date :</b></td>
							<td width="80%" class="txtNormal"><?php echo date("m/d/Y",strtotime($_SESSION["creditdate"])); ?></td>
						</tr>
						<tr>
							<td width="20%" class="txtNormal"><b>Company Code :</b></td>
							<td width="80%" class="txtNormal"><?php echo $company_descr; ?></td>
						</tr>
						
					</table>
				</td>
			</tr>
			<tr>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td>
					<table border="1" width="100%" style=" border-collapse:collapse;">
						<tr>
							<td class="txtheader">Line No.</td>
							<td class="txtheader">Account Name</td>
							<td class="txtheader">Account Number</td>
							<td class="txtheader">Credited Amount</td>
						</tr>
							<?php details(); ?>
						<tr>
							<td class="txtheader" colspan="3">Hash Totals :</td>
							<td align="right" class="txtNormal"><?php echo number_format($total_amounts,2); ?></td>
						</tr>
					</table>
				</td>
			</tr>
			<tr>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td>
					<table width="100%">
						<tr>
							<td width="50%" class="txtheader">Prepared By :</td>
							<td width="50%" class="txtheader">Approved By :</td>
						</tr>
						<tr>
							<td width="50%" align="center" class="txtNormal" ><?php echo str_repeat('_', 30); ?></td>
							<td width="50%" align="center" class="txtNormal" ><?php echo str_repeat('_', 30); ?></td>
						</tr>
					</table>
				</td>
			</tr>
		</table>
        
    </div>
</form>
<?php

function cominfo()
{
	extract ($GLOBALS);
	global $comname,$add,$contact,$header_report;
	
	$query = "Select * from glsyscntrl";
	$rs = mysql_query($query);
	$row = mysql_fetch_array($rs);

	$comname 	= $row["Company_Name"];
	$add 		= $row["Address"];
	$contact 	= "Tel Num. ".$row["Phone"]." / Fax No. ".$row["Fax"];
	$header_report = $comname.'<br>'.$add.'<br>'.$contact;
}

function other_details()
{
	extract($GLOBALS);
	global $company_descr,$acct,$batch;
	$query_info = "select * from agency where AgencyCd='" .$_SESSION["ofc"] . "'";
	$rs_info = mysql_query($query_info) or die(mysql_error());
	$row_info = mysql_fetch_array($rs_info);
	$company_descr = $row_info["AgencyName"];
	
	$query_bank ="Select * from py_syscntrl";
	$rs_bank = mysql_query($query_bank) or die(mysql_error());
	$row_bank = mysql_fetch_array($rs_bank);
	$acct=$row_bank["BankAcctNo"];
	$batch=$row_bank["BatchNo"];
	
}

function details()
{
	extract($GLOBALS);
	global $total_amounts;
	
	$sql_info = "select Name,Report_No,Amount_Per,Emp_Cd from py_report " . $_SESSION["filter"] . " order by Name";
	//echo $sql_info;
	$rs_info = mysql_query($sql_info) or die(mysql_error());
	$line_no = 1;
	while($row_info = mysql_fetch_array($rs_info))
	{
		echo '<tr>';
		echo '<td  class="txtNormal">'.$line_no.'.</td>';
		echo '<td  class="txtNormal">'.$row_info["Name"].'</td>';
		$query_acct_emp = "Select * from py_emp_master where Emp_Cd='".$row_info["Emp_Cd"]."'";
		$rs_acct_emp = mysql_query($query_acct_emp) or die(mysql_error());
		$row_acct_emp = mysql_fetch_array($rs_acct_emp);
		$amount_per= $row_info["Amount_Per"]*100;
		echo '<td align="right"  class="txtNormal">'.$row_info["Report_No"].'</td>';
		echo '<td align="right"  class="txtNormal">'.number_format($row_info["Amount_Per"],2).'</td>';
		echo '</td>';
		
		$total_amounts += $row_info["Amount_Per"];
		
		$line_no++; 
	}
	$line_no - 1;
	//echo $hello.'<br>';
}

	function metrobank()
	{
	extract($GLOBALS);
		
		$vCompanyName = Space(40); 
		$query = "select Company_Name,CompanyCd,BranchCd,BankCd 
					from glsyscntrl where AgencyCd='" .$_SESSION["ofc"] . "'";
		$result = mysql_query($query) or die(mysql_error());
		$row = mysql_fetch_array($result);

		$vCompanyName = empty($row['Company_Name'])?'':trim(substr($row['Company_Name'], 0, 40));
        $vCompanyName = $vCompanyName . Space(40 - strlen($vCompanyName));
        
		$sql_bank_info = "select Emp_Cd,Name,Report_No,Amount_Per,PayDate from py_report " . $_SESSION["filter"] . " order by Name";
		$rs_bankinfo = mysql_query($sql_bank_info) or die(mysql_error());
		$num_row_bank = mysql_num_rows($rs_bankinfo);
		$ctr_iemp = 1;
		while($row_bankinfo = mysql_fetch_array($rs_bankinfo))
		{
			$fixed_val1 = "2"; 		//FIXED VALUE
			$com_dep 	=$row["CompanyCd"];		//COMPANY DEPOSITORY BRANCH CODE
			$bank_code ="26";		//BANKCODE
			$curen_fixed ="001";		//CURRENCY FIXED
			$pay_acct_code =$row["BranchCd"];		//PAYROLL ACCOUNT BRANCH CODE
			$fixedval ="0000000"; 	//FIXED VALUE
			$query_py_emp = "Select * from py_emp_master where Emp_Cd='".$row_bankinfo["Emp_Cd"]."'";
			$rs_py_emp = mysql_query($query_py_emp) or die(mysql_error());
			$row_py_emp = mysql_fetch_array($rs_py_emp);
			
			if($row_bankinfo["Report_No"]!="")
			{
				$account_num = substr(str_replace('-', '', $row_bankinfo["Report_No"]), 0, 10);  
			}
			else
			{
				$account_num = "0000000000";
			}
			//$amount_per= substr(sprintf('%015d', $row_bankinfo["Amount_Per"]), 0, 15);// SALARY
			$amount_per= $row_bankinfo["Amount_Per"]*100;
			//print("Name: " . $rs_py_emp["Emp_Lname"] . ", " . $rs_py_emp["Emp_Fname"] . "==Net before formatted: " . $amount_per .  "<br/>" );
			$amount_per = sprintf('%015s', $amount_per);
			$fixed_val2 ="9";		//FIXED VALUE
			$com_code =$row["BankCd"];		//COMPANY CODE
			$paydate =date('mdY',strtotime($row_bankinfo["PayDate"]));
			$vOut .=$fixed_val1.$com_dep.$bank_code.$curen_fixed.$pay_acct_code.$fixedval.$vCompanyName.$account_num.$amount_per.$fixed_val2.$com_code.$paydate;
			//$vOut .=$fixed_val1.$com_dep.$bank_code.$curen_fixed.$pay_acct_code.$fixedval.$vCompanyName.$account_num.$amount_per.$fixed_val2.$com_code.$paydate;
			
			if($ctr_iemp!=$num_row_bank)
			{
				$vOut .="\r\n";
			}
			//echo $row_bankinfo["Emp_Cd"]."=>".$row_bankinfo["Name"]."=>".$fixed_val1.$com_dep.$bank_code.$curen_fixed.$pay_acct_code.$fixedval.$vCompanyName.$account_num.$amount_per.$fixed_val2.$com_code.$paydate."<br>";
			$ctr_iemp++;
			//$row_bankinfo["Name"]."=>".$account_num."=>".$amount_per."=>".$fixed_val2."=>".$com_code."=>".$paydate."<br>";
		}
		//echo $num_row_bank.'GEN';
       
		
			if(file_exists($_SERVER['DOCUMENT_ROOT']. DOWNLOAD_PATH . '/'.session_id().'-BANKADVISE.DAT'))
			{
				unlink($_SERVER['DOCUMENT_ROOT']. DOWNLOAD_PATH . '/'.session_id().'-BANKADVISE.DAT');
			}
	
			WriteFile(session_id().'-BANKADVISE.DAT', $_SERVER['DOCUMENT_ROOT']. DOWNLOAD_PATH . '', $vOut);
	}

	function WriteFile($file_name, $str_path, $file_cont)
	{
		$fh = fopen($str_path.'/'.$file_name, 'w') or die('can not write file!');
		fwrite($fh, $file_cont);
		fclose($fh);
	}

	function Space($num)
	{
		$sp = '';
		
		for($i=0; $i<$num; $i++)
			$sp .= ' ';
	
		return $sp;
	}
	
	function MonthEND($mn)
	{
		$dt = date('Y').'-'.$mn.'-01';
		return date('t', strtotime($dt));
	}
	
	function nf($val)
	{
		$val = (float) $val;
		return "\$".number_format($val, 2, '.', ',');
	}
	
?>
</body>
</html>
<script language="javascript" type="text/javascript">
	function invoke() {
		<?php print($message); ?>
	}
</script>
<?php
	require_once("../inc/disconnect.php");
?>