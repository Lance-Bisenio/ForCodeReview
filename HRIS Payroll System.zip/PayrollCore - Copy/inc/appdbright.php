<?php
	if($_POST["txtPage"] != "") {
		$curr_page=$_POST["txtPage"];
	} else {
		$curr_page=1;
	}
	
	if(isset($_POST["cmdPage"])) {
		$offset=($_POST["txtPage"] - 1) * $num_pages;
		$_SESSION["offset"]=$offset;
	}
	
	if(isset($_POST["cmdFirst"])) {
		$offset=0;
		$_SESSION["offset"]=$offset;
		$curr_page=1;
	}
	if(isset($_POST["cmdPrev"])) {
		if($curr_page > 1) {
			$offset=($_POST["txtPage"] - 2) * $num_pages;
			$_SESSION["offset"]=$offset;
			$curr_page=$_POST["txtPage"] - 1;
		}
	}
	if(isset($_POST["cmdNext"])) {
		if($curr_page < $_SESSION["pages"]) {
			$offset=$_POST["txtPage"] * $num_pages;
			$_SESSION["offset"]=$offset;
			$curr_page=$_POST["txtPage"] + 1;
		}
	}
	if(isset($_POST["cmdLast"])) {
		$offset=($_SESSION["pages"] - 1) * $num_pages;
		$_SESSION["offset"]=$offset;
		$curr_page=$_SESSION["pages"];
	}
	
	if($_SESSION["offset"] != "") {
		$offset=$_SESSION["offset"];
	} else {
		$offset=0;
	}
	
	////// build combobox ////////////
	$filter=$_SESSION["filter"];
	if(isset($_POST["cmdSearch"])) 
		{
		$filter="";
		if($withDeptFilters != 0) 
		{	
			if($filter!="") { $prefix=" and "; } else { $prefix=" where "; }	
			if($_POST["cmbRc"]=="All") {
				$filter .= $prefix . " Rc_Cd in ('" . str_replace(",","','",$_SESSION["rclist"]) . "') ";
			} else {
				$filter .= $prefix . " Rc_Cd='" . $_POST["cmbRc"] . "' ";
			}
			
		if($_POST["txtSearch"] !="") {
			if($filter !="") {
				$filter .=" and $searchkey like '" . $_POST["txtSearch"] . "%'";
			} else {
				$filter .=" where $searchkey like '" . $_POST["txtSearch"] . "%'";
			}
		} 
		$_SESSION["filter"]=$filter;

	}
}
	///// build title/////////////
	if($withDeptFilters!=0) {
		$rc=fnBuildCombo("select Rc_Cd,Descr from rc order by Descr","cmbRc");
		$ofc=fnBuildCombo("select AgencyCd,AgencyName from agency order by AgencyName","cmbOfc");
		
	}
		
	$temp = explode("|",$coltitle);
	$header="<table border='1' style='width:100%'><tr class='titlebar'>";
	for($ictr=0;$ictr < sizeof($temp);$ictr++) {
		$header .= "<th>" . $temp[$ictr] . "</th>";
	}
	$header .="<th>Select</th></tr>";
	
	///////////// build sql statement //////////////
	$rs = mysql_query($sqlstmt . " " . $filter . $cond .  " " . $sortorder);
	$recs = mysql_num_rows($rs);
	$pages = ceil($recs / $num_pages);
	$_SESSION["pages"]=$pages;
	$rs = mysql_query($sqlstmt . " " . $filter . $cond . " " . $sortorder .
		" limit " . $offset . "," . $num_pages);

	$detail="";
	$sw=0;
	$irow=1;
	$curr_row=0;
	$temp=explode("|",$colfields);
	
	while($row=mysql_fetch_array($rs)) {
		if($sw==0) {
			$class="regular_color";
			$sw=1;
		} else {
			$class="alternate_color";
			$sw=0;
		}
	
		if(isset($_POST["cmd" . $row[$key]])) {
			$class="highlighted_color";
			$curr_row=$irow + (($curr_page - 1) * $num_pages);
			$_SESSION["return_val"]=$row[$key];
		}

		
		$detail .= "<tr class='" . $class . "'>";

		for($ictr=0;$ictr < sizeof($temp);$ictr++) {
			$detail .= "<td>" . $row[$temp[$ictr]] . "</td>";
		}	
		$detail .= "<td><input type='submit' name='cmd" . $row[$key] . "' value='Select' class='button' /></td></tr>";
		$irow += 1;
	}
	$footer="</table>";
	$status="<table border='0' cellspacing='0' cellpadding='0'><tr><td>Record: $curr_row of $recs |</td><td valign='bottom'> 
			<input type='text' id='txtPage' name='txtPage' class='label' value='$curr_page' 		
			style='width:20px;' /> of $pages Page(s)</td><td>
			<input type='submit' name='cmdPage' id='cmdPage' value='Go to Page' class='navbutton' />
			<input type='submit' name='cmdFirst' id='cmdFirst' value='First'  class='navbutton' />
			<input type='submit' name='cmdPrev' id='cmdPrev' value='Previous'  class='navbutton' />
			<input type='submit' name='cmdNext' id='cmdNext' value='Next'  class='navbutton' />
			<input type='submit' name='cmdLast' id='cmdLast' value='Last'  class='navbutton' /></td></tr></</table>";
?>