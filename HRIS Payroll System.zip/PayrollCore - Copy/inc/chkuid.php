<?php
	if($_SESSION["uid"]=="") {
		header("Location: index.php");
		ob_end_flush();
		exit;
	}
?>