<?php
	function fnDateDiff($format,$tIn,$tOut){
		///////////////////////////////////////////////////////////////////////////////
		////////// co-author: Rudner Diaz
		////////// Description: returns the date difference of two dates/time period specified by type of return /////////
		////////// Parameters:
		//////////      $format = specify whether what type of return value
		//////////      $tIn = specifies the start date/time value
		//////////      $tOut = sepcifies the end date/time value
		//////////////////////////////////////////////////////////////////////////////////

		$vIn=strtotime($tIn);
		$vOut=strtotime($tOut);
		$tmpDayOut = date("d",$vOut);
		if($tmpDayOut < date("d",$vIn)) {		//out date falls on the next month
			$tmpDayOut += date("d",$vIn);
		}
		$minWorked=(($tmpDayOut - date("d",$vIn)) * 1440  + ((date("H",$vOut) * 60) + date("i",$vOut)) - ((date("H",$vIn) * 60 ) + date("i",$vIn)));

		switch ($format) {
			case "hour":
				return number_format($minWorked / 60,2);
				break;
			case "minute":
			 	return number_format($minWorked,2);
				break;
			case "second":
				return number_format($minWorked * 60,2);
				break;
			case "day":
				return number_format($minWorked / 1440,2);	
				break;
		}	
	}
	
	function fnMonthEnd($pMonth,$pYear)  {
		/////////////////////////////////////////////////////////////////////////////////
		//////////  Author:  Vic Gatchalian
		//////////  Date Created:  Feb. 23, 2008
		//////////  Description: returns the last day of the given month and year 
		//////////  Parameters:  
		//////////        $pMonth = The Month you want to determine the last day
		//////////        $pYear  = The Year you want to determine the last of the the given month
		/////////////////////////////////////////////////////////////////////////////////
		$basedate=explode("/",date("m/d/Y",mktime(0,0,0,$pMonth,28 + 4,$pYear)));
		$baseday=$basedate[1];
		$end = date("d",mktime(0,0,0,$basedate[0],$basedate[1] - $baseday,$basedate[2]));
		return $end;
	}
	
	function fnGetVal($pCombo) {
		/////////////////////////////////////////////////////////////////////////////////
		//////////  Author:  Vic Gatchalian
		//////////  Date Created:  Feb. 2, 2008
		//////////  Description: Sets the default selected value of the combo box  
		//////////  Parameters:  
		//////////        $pCombo = The name of the combo box you want to check
		/////////////////////////////////////////////////////////////////////////////////
		if(isset($_POST[$pCombo])) {
			return $_POST[$pCombo];
		} else {
			return "";
		}
	}
	
	function GetRef($sql,$default,$field) {
		/////////////////////////////////////////////////////////////////////////////////
		//////////  Author:  Vic Gatchalian
		//////////  Date Created:  Feb. 2, 2008
		//////////  Description: returns the descriptive value of the given code base on sql statement sent
		//////////  Parameters:  
		//////////        $sql = The SQL statement from where to get the description of the code
		//////////               (e.g. select descr1 from table1 where code1='code')
		//////////               NOTE: You don't need to list all fields just the field to return
	 	//////////        $default = The default value the function would return if the field is null or 
		//////////                the sql return with no records
		//////////        $field = The field to return. This should be the same field in the SQL statement
		/////////////////////////////////////////////////////////////////////////////////
		$rsRef=mysql_query($sql);
		$r=mysql_fetch_array($rsRef);
		if(mysql_num_rows($rsRef) > 0) {
			if(is_null($r[$field])) {
				return $default;
			} else {
				return $r[$field];
			}
		} else {
			return $default;
		}
		mysql_free_result($rsRef);
	}
	
	function CheckNull($val) {
		/////////////////////////////////////////////////////////////////////////////////
		//////////  Author:  Vic Gatchalian
		//////////  Date Created:  Feb. 2, 2008
		//////////  Description: Checks if the value passed is null or not, if null, it returns the 'Unknown' string
		//////////  Parameters:  
		//////////        $val = The value to check if it is null in value or not
		/////////////////////////////////////////////////////////////////////////////////
		if(is_null($val)) {
			return "Unknown";
		} else {
			return $val;
		}
	}
	
	function fnBuildCombo($psql,$pcombo) {
		/////////////////////////////////////////////////////////////////////////////////
		//////////  Author:  Vic Gatchalian
		//////////  Date Created:  Feb. 2, 2008
		//////////  Description: Creates the contents of the Combobox passed
		//////////  Parameters:  
		//////////        $psql = The SQL statement from where to get the description and the code
		//////////               (e.g. select code1,descr1 from table1 where code1='code' ....)
		//////////               NOTE: You don't need to list all fields just the code and description field
	 	//////////        $pcombo = The current value of the combo box
		//////////  NOTES:  You can use this in conjunction with the fnGetVal function to
		//////////        properly stick the current selection of the combo
		/////////////////////////////////////////////////////////////////////////////////
		$rs=mysql_query($psql);
		$dump="<option selected='selected'>All</option>";
		$select = "";
		
		while($row=mysql_fetch_array($rs)) {
			if($row[0]==$pcombo) {
				$select="selected='selected'";
			} else {
				$select="";
			}
			
			$dump .= "<option value='" . $row[0] . "' " . $select . ">" . $row[1] . "</option>";
		}
		
		return $dump;
	}
?>