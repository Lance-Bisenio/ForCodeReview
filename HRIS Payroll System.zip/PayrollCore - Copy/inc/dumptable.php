<table style="width:inherit">
	<?php
		if($withDeptFilters!=0) {
			require_once("inc/filters.inc");
		}
		print($otherfilter); 
	?>
</table>
<table style="width:100%">
	<tr>
	  	<td>
			<table border="0" cellpadding="=0" cellspacing="0">
				<tr>
					<td align="right">Quick Search:</td>
					<td><input type="text" name="txtSearch" id="txtSearch"
	  					style="width:200px;" value="<?php print($_POST['txtSearch']); ?>" class="inputbox" /> 
	  	  				<input type="submit" name="cmdSearch" id="cmdSearch" value="Search" class="navbutton" />
					</td>
                    <td>
                    	<?php print($letters); ?>
                    </td>
				</tr>
		  	</table>
		</td>
	</tr>
	<tr>
		<td>
			<?php
				print($header);
				print($detail);
				print($footer);
			?>		
		</td>
	</tr>
	<tr class="footer">
		<td>
			<?php 
				print($status);
			?>
		</td>
	</tr>
</table>
