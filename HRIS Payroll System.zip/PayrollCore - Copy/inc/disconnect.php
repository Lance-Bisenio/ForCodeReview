<?php
	mysql_close();
	ob_end_flush();
?>