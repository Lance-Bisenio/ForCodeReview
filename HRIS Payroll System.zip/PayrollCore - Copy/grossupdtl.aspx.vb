﻿Imports denaro.fis
Partial Class grossupdtl
    Inherits System.Web.UI.Page
    Public vData As String = ""
    Public vScript As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            vScript = "alert('Your login session has expired. Please re-login again.'); window.close();"
            Exit Sub
        End If
        If Not IsPostBack Then
            Dim c As New SqlClient.SqlConnection(connStr)
            Dim cm As New SqlClient.SqlCommand
            Dim rs As SqlClient.SqlDataReader

            Dim vEmpCd As String = Request.Item("id")
            Dim vPayDate As Date = CDate(Request.Item("p"))
            Dim vFromDate As Date = Nothing
            Dim vToDate As Date = Nothing
            Dim vNormalPayroll As Boolean = Val(Request.Item("m")) = 1
            Dim vClass As String = "odd"

            Try
                c.Open()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                c.Dispose()
                cm.Dispose()
                Exit Sub
            End Try

            cm.Connection = c

            cm.CommandText = "select FromDate,ToDate from py_report where Emp_Cd='" & vEmpCd & _
                "' and PayDate='" & Format(vPayDate, "yyyy/MM/dd") & "' and NormalPayroll=" & IIf(vNormalPayroll, 1, 0)
            Try
                rs = cm.ExecuteReader
                If rs.Read Then
                    vFromDate = CDate(rs("FromDate"))
                    vToDate = CDate(rs("ToDate"))
                Else
                    vScript = "alert('Cannot determine payroll register.'); window.close();"
                End If
                rs.Close()

                cm.CommandText = "select * from py_report_dtl where Emp_Cd='" & vEmpCd & _
                    "' and FromDate='" & Format(vFromDate, "yyyy/MM/dd") & _
                    "' and ToDate='" & Format(vToDate, "yyyy/MM/dd") & _
                    "' and PayDate='" & Format(vPayDate, "yyyy/MM/dd") & _
                    "' and NormalPayroll=" & IIf(vNormalPayroll, 1, 0) & _
                    " order by LineNum"
                rs = cm.ExecuteReader
                If rs.HasRows Then
                    vData = ""
                    Do While rs.Read
                        vData += "<tr class='" & vClass & "'>" & _
                            "<td class='labelR'>" & Format(rs("FromDate"), "yyyy/MM/dd") & "</td>" & _
                            "<td class='labelR'>" & Format(rs("ToDate"), "yyyy/MM/dd") & "</td>" & _
                            "<td class='labelR'>" & Format(rs("PayDate"), "yyyy/MM/dd") & "</td>" & _
                            "<td class='labelC'>" & IIf(rs("TranType") = 1, "DED", "INC") & "</td>" & _
                            "<td class='labelL'>" & rs("TranGroup") & "</td>" & _
                            "<td class='labelL'>" & rs("TranCd") & "</td>" & _
                            "<td class='labelL'>" & rs("TranCurrCd") & "</td>" & _
                            "<td class='labelR'>" & Format(rs("TranAmount"), "###,##0.00") & "</td></tr>"
                        vClass = IIf(vClass = "odd", "even", "odd")
                    Loop
                Else
                    vScript = "alert('No detailed record is available'); window.close();"
                End If
                rs.Close()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to retrieve payroll register. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            Finally
                c.Close()
                c.Dispose()
                cm.Dispose()
            End Try
        End If
    End Sub
End Class
