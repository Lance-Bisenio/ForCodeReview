Imports denaro
Partial Class getdtr
    Inherits System.Web.UI.Page
    Public vResult As String = ""
    Dim c As New SqlClient.SqlConnection(connStr)
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim vPdfFile As String = ""
        Dim vStart As Date = Now
        Dim vPrn As New VSPrinter8Lib.VSPrinter
        Dim vPdf As New VSPDF8Lib.VSPDF8
        Dim vData As String
        Dim vFormat As String

        Dim cm As New SqlClient.SqlCommand
        Dim cmEmp As New SqlClient.SqlCommand
        Dim cmRef As New SqlClient.SqlCommand

        Dim rs As SqlClient.SqlDataReader
        Dim rsRef As SqlClient.SqlDataReader
        Dim rsEmp As SqlClient.SqlDataReader

        Dim vHrsAllowed As Decimal = 0
        Dim vFrom As Date = CDate(Session("from"))
        Dim vTo As Date = CDate(Session("to"))
        Dim iDate As Date = vFrom
        Dim vId As String = Session("id")
        Dim iPageCtr As Integer
        Dim vIn As DateTime
        Dim vOut As DateTime
        Dim vRegHrs As Decimal = 0
        Dim vND As Decimal = 0
        Dim vOT As Decimal = 0
        Dim vLeave As String = ""
        Dim vTLeave As String = ""
        Dim vRice As Integer = 0
        Dim vMeal1 As Integer = 0
        Dim vMeal2 As Integer = 0
        Dim vLBound As Decimal = 0
        Dim vUBound As Decimal = 0
        Dim iTardy As Single = 0
        Dim vUtime As Decimal = 0
        Dim iUtime As Decimal = 0
        Dim iRegHrs As Decimal = 0
        Dim vTimeSched As Decimal = 0
        Dim iND As Decimal = 0
        Dim iOT As Decimal = 0
        Dim iApprovedOT As Decimal = 0
        Dim vMealTag1 As Boolean = False
        Dim vMealTag2 As Boolean = False
        Dim vRegDay As Boolean = False
        Dim vCompanyName As String = "Unknown"
        Dim vGrace As Integer = 0
        Dim vMinOtHours As Integer = 0
        Dim vTotalTardy As Decimal = 0
        Dim vTemp As Decimal = 0
        Dim DaysLeave As String = ""
        Dim EndDate As Date
        Dim LeaveCd As String = ""
        Dim vHaveSched As Boolean = True
        Dim LeavesTable As New Hashtable
        Dim vDayType As String = ""
        Dim vAgencyCd As String = ""
        Dim vOfficial As Boolean = False
        Dim vOfficeCd As String = ""
        Dim vBranch As String = ""
        Dim vBranchCd As String = ""
        Dim vEffectivityDate As String = ""

        c.Open()
        cm.Connection = c
        cmEmp.Connection = c
        cmRef.Connection = c

        cmEmp.CommandText = "select Emp_Cd,Emp_Lname,Emp_Fname,Emp_Mname,UnitCd,GracePeriod,MinOtHours,Agency_Cd " & _
            "from py_emp_master where Emp_Cd in ('" & vId & "') order by Emp_Lname,Emp_Fname"

        rsEmp = cmEmp.ExecuteReader
        iPageCtr = 0

        vPrn.PaperSize = VSPrinter8Lib.PaperSizeSettings.pprA4
        vPrn.Orientation = VSPrinter8Lib.OrientationSettings.orPortrait
        vPrn.MarginTop = OneInch / 4
        vPrn.MarginBottom = OneInch / 4
        vPrn.MarginLeft = OneInch / 8
        vPrn.MarginRight = OneInch / 8

        vPrn.StartDoc()

        Do While rsEmp.Read
            LeavesTable.Clear()
            vAgencyCd = ""
            vTLeave = ""
            iUtime = 0
            vTotalTardy = 0
            'get name of company
            cm.CommandText = "select Company_Name from glsyscntrl where AgencyCd='" & _
                rsEmp("Agency_Cd") & "'"
            rs = cm.ExecuteReader
            If rs.Read Then
                If Not IsDBNull(rs("Company_Name")) Then
                    vCompanyName = rs("Company_Name")
                End If
            End If
            rs.Close()

            'get branch code and name
            cm.CommandText = "select Unit_Cd,Descr from hr_unit_ref where Unit_Cd='" & _
                rsEmp("UnitCd") & "'"
            rs = cm.ExecuteReader
            If rs.Read Then
                If Not IsDBNull(rs("Unit_Cd")) Then
                    vBranch = IIf(IsDBNull(rs("Descr")), "", rs("Descr"))
                    vBranchCd = IIf(IsDBNull(rs("Unit_Cd")), "", rs("Unit_Cd"))
                End If
            End If
            rs.Close()

            'get grace period, min. ot hours
            vGrace = 0
            vMinOtHours = 0
            vAgencyCd = ""
            If Not IsDBNull(rsEmp("GracePeriod")) Then
                vGrace = rsEmp("GracePeriod")
            End If
            If Not IsDBNull(rsEmp("MinOtHours")) Then
                vMinOtHours = rsEmp("MinOtHours")
            End If
            If Not IsDBNull(rsEmp("Agency_Cd")) Then
                vAgencyCd = rsEmp("Agency_Cd")
            End If

            vPrn.TextAlign = VSPrinter8Lib.TextAlignSettings.taCenterBottom
            vPrn.FontBold = True
            vPrn.FontName = "Arial"
            vPrn.FontSize = 10
            vPrn.Paragraph = vCompanyName
            vPrn.FontBold = False
            vPrn.FontSize = 9
            vPrn.Paragraph = "Daily Time Record"
            vPrn.Paragraph = "For the Period: " & Format(vFrom, "MM/dd/yyyy") & " to " & Format(vTo, "MM/dd/yyyy")
            vPrn.TextAlign = VSPrinter8Lib.TextAlignSettings.taJustTop
            vPrn.Paragraph = "Name of Employee: " & rsEmp("Emp_Lname") & ", " & _
                rsEmp("Emp_Fname") & " " & rsEmp("Emp_Mname")
            vPrn.Paragraph = "Employee ID: " & rsEmp("Emp_Cd")
            vPrn.Paragraph = "Branch/Branch Name : " & vBranchCd & "/" & vBranch
            vPrn.TableBorder = VSPrinter8Lib.TableBorderSettings.tbAll

            vPrn.FontBold = True
            vData = "Date|Shift Schedule|IN|OUT|IN|OUT|IN|OUT|Actual Hours Rendered|Absence|Overtime|UT/Tardy|Remarks;"
            vFormat = "^1100|^1500|^500|^500|^500|^500|^500|^500|^850|^850|^800|^800|^2500;"
            vPrn.Table = vFormat & vData
            vPrn.FontBold = False
            vFormat = ">1100|>1500|>500|>500|>500|>500|>500|>500|>850|>850|>800|>800|<2500;"
            vData = ""

            iDate = vFrom
            iPageCtr += 1
            iUtime = 0
            iRegHrs = 0
            iND = 0
            iOT = 0
            iApprovedOT = 0
            vMeal1 = 0
            vMeal2 = 0
            vRice = 0

            Do While iDate <= vTo
                vMealTag1 = False
                vMealTag2 = False
                vUtime = 0
                DaysLeave = ""
                vTimeSched = 0
                LeaveCd = ""
                vLeave = 0
                iTardy = 0
                vRegHrs = 0
                vHaveSched = True
                vHrsAllowed = 0
                vDayType = ""
                vOT = 0
                vEffectivityDate = ""
                Dim vReason As String = ""

                'get schedules
                cm.CommandText = "select Start_Time,End_Time,HrsAllowed from py_emp_time_sched" & _
                    " where Emp_Cd='" & rsEmp("Emp_Cd") & "' and Date_Sched='" & Format(iDate, "yyyy/MM/dd") & "'"
                rs = cm.ExecuteReader
                vHrsAllowed = 0
                vHaveSched = False
                vOut = Nothing
                vIn = Nothing
                If rs.Read Then  'not eof
                    If Not IsDBNull(rs("Start_Time")) And IsDate(rs("Start_Time")) Then
                        vIn = iDate & " " & Format(rs("Start_Time"), "HH:mm:00")
                    End If
                    If Not IsDBNull(rs("End_Time")) And IsDate(rs("End_Time")) And _
                       Not IsDBNull(rs("Start_Time")) And IsDate(rs("Start_Time")) Then
                        vOut = IIf(rs("End_Time") < rs("Start_Time"), iDate.AddDays(1), iDate) & _
                            " " & Format(rs("End_Time"), "HH:mm:00")
                        vTimeSched = Math.Round(Math.Abs(DateDiff(DateInterval.Minute, vIn, vOut)) / 60, 2)
                        vHaveSched = True
                    End If
                End If
                rs.Close()

                vLeave = 0
                If vHaveSched Then
                    '######Start Leave Query
                    cm.CommandText = "SELECT CASE WHEN EL=1 THEN 'EL' ELSE LeaveCd END AS LeaveCd,DaysLeave,EndDate,EffectivityDate FROM hr_leave_application WHERE '" & _
                        Format(iDate, "yyyy/MM/dd") & "' >= StartDate AND '" & Format(iDate, "yyyy/MM/dd") & _
                        "' <= EndDate AND Void=0 AND Emp_Cd='" & rsEmp("Emp_Cd") & "' AND DateApproved IS NOT null AND Paid <> 0"
                    rs = cm.ExecuteReader

                    If rs.Read Then
                        Dim a() As String
                        DaysLeave = rs("DaysLeave")
                        EndDate = rs("EndDate")
                        LeaveCd = rs("LeaveCd")

                        If Not IsDBNull(rs("EffectivityDate")) Then
                            vEffectivityDate = "Late filed (" & rs("EffectivityDate") & ")"
                        End If

                        a = DaysLeave.Split(".")

                        If DaysLeave <= 1 Then
                            vLeave = DaysLeave * vTimeSched
                        Else
                            If a.Length > 1 And a(0) <> 0 And EndDate = iDate Then
                                vLeave = ("." & a(1)) * vTimeSched
                            Else
                                vLeave = 1 * vTimeSched
                            End If
                            ''''''''''''''''''''''''''''''''''''''''''''
                        End If
                    End If
                    rs.Close()
                    '########End Leave Query
                End If

                '########Type Of Day
                cm.CommandText = "SELECT Office_Cd,Descr,Official FROM py_holiday WHERE Holy_Date = '" & _
                    Format(iDate, "yyyy/MM/dd") & "'"
                rs = cm.ExecuteReader
                If rs.Read Then
                    vOfficial = rs("Official")
                    vOfficeCd = rs("Office_Cd")

                    '########Type Of Day
                    If vOfficial Then       'legal
                        vDayType = IIf(IsDBNull(rs("Descr")), "", rs("Descr"))
                    Else    'special or local holiday
                        If vOfficeCd.ToString.IndexOf(vAgencyCd) >= 0 Or vOfficeCd.ToString.Contains("*") Then
                            vDayType = IIf(IsDBNull(rs("Descr")), "", rs("Descr"))
                        End If
                    End If
                    '########Type Of Day
                End If
                rs.Close()

                '#######Type Of Day

                'get actual log
                cm.CommandText = "select Tran_Date,Time_In,Time_Out,Time_OutDate,Hrs_Worked," & _
                    "BreakTimeIn,BreakTimeOut,Reason, OrgTimeIn, OrgTimeOut,EffectivityDate,Date_Approved," & _
                    "OrgTimeOutDate from py_time_log where Emp_Cd='" & _
                    rsEmp("Emp_Cd") & "' and Tran_Date='" & Format(iDate, "yyyy/MM/dd") & "'"
                rs = cm.ExecuteReader

                If rs.Read Then     'with logs
                    vReason = vDayType & " "
                    If Not IsDBNull(rs("Reason")) Then
                        vReason = rs("Reason")
                    End If
                    vRegHrs = 0
                    vND = 0
                    vData += Format(iDate, "MM/dd/yyyy") & "|" & IIf(vIn <> Nothing, Format(vIn, "HH:mm"), "") & "|" & _
                        IIf(vOut <> Nothing, Format(vOut, "HH:mm"), "") & "|"

                    vTemp = 0
                    vOT = 0
                    'retrive the tardy calculated logs
                    iTardy = GetTrans("TARD", iDate, rsEmp("Emp_Cd"))
                    'retrieve the undertime calculated logs
                    vUtime = GetTrans("UT", iDate, rsEmp("Emp_Cd"))
                    vTotalTardy += iTardy
                    iUtime += vUtime
                    vHrsAllowed = 0
                    If Not IsDBNull(rs("Time_In")) Then
                        vData += Format(CDate(rs("Time_In")), "HH:mm:ss") & "|"
                        If Not IsDBNull(rs("Time_Out")) And Not IsDBNull(rs("Time_OutDate")) Then
                            vRegHrs = Math.Round(DateDiff(DateInterval.Minute, CDate(rs("Tran_Date") & " " & rs("Time_in")), _
                                CDate(rs("Time_OutDate") & " " & rs("Time_Out"))) / 60, 2)

                            'check for night differential
                            cmRef.CommandText = "select sum(Hrs_Rendered) from py_time_log_dtl where Emp_Cd='" & _
                                rsEmp("Emp_Cd") & "' and TranDate='" & Format(iDate, "yyyy/MM/dd") & _
                                "' and TranCd in ('A2','A3','A4','B2','B4','C2','C4','D2','D4','E2','E4','F2','F4','G2','G4')"
                            rsRef = cmRef.ExecuteReader
                            vND = 0
                            If rsRef.Read Then
                                If Not IsDBNull(rsRef(0)) Then
                                    vND = rsRef(0)
                                End If
                            End If
                            rsRef.Close()

                            'If CDate(rs("Time_In")).Hour < 6 Then
                            '    'with nightdiff before 6am
                            '    vND = Math.Abs(DateDiff(DateInterval.Minute, CDate(rs("Tran_Date") & " " & rs("Time_In")), _
                            '        CDate(iDate & " 6:00:00"))) / 60
                            'End If
                            'If rs("Time_OutDate") > iDate Or (rs("Time_OutDate") = iDate And CDate(rs("Time_Out")).Hour >= 22) Then
                            '    'with nightdiff after 10pm
                            '    vND += Math.Abs(DateDiff(DateInterval.Minute, CDate(iDate & " 22:00:00"), _
                            '        CDate(rs("Time_OutDate") & " " & _
                            '        IIf(CDate(rs("Time_Out")).Hour <= 6, rs("Time_Out"), "6:00:00")))) / 60
                            'End If
                            'If vND > 4 Then
                            '    If vND < 5 Then  'partial only
                            '        vND = vND - (vND - 4) 'just remove the remaining partial excess hour
                            '    Else
                            '        vND -= 1 'just remove 1 hour break
                            '    End If
                            'End If

                            If vDayType <> "" Or vOut = Nothing Then 'holiday or with no scheule, set entire vreghours as ot
                                vOT = vRegHrs
                            Else
                                vTemp = IIf(vRegHrs >= vTimeSched, (vTimeSched - iTardy) - vUtime, vRegHrs)
                                vTemp = vTemp - IIf(vTemp >= 5, 1, 0)
                                vTemp = IIf(vTemp < 0, 0, vTemp)
                                If vOut < Format(CDate(rs("Time_Outdate")), "MM/dd/yyyy") & " " & Format(CDate(rs("Time_Out")), "HH:mm:00") Then
                                    'Disabled Early Bird
                                    'vOT = vRegHrs - vTimeSched
                                    vOT = Math.Round(DateDiff(DateInterval.Minute, vOut, CDate(rs("Time_Outdate") & " " & rs("Time_Out"))) / 60, 2)
                                    vOT = IIf(vOT < 0, 0, vOT)
                                End If
                            End If
                        End If
                    Else
                        vData += "|"
                    End If

                    '############Start Time Out
                    If Not IsDBNull(rs("Time_Out")) Then
                        vData += Format(CDate(rs("Time_Outdate")), "MM/dd/yyyy") & " " & _
                            Format(CDate(rs("Time_Out")), "HH:mm:ss") & "|"
                    Else
                        vData += "|"
                    End If
                    '###########End TimeOut

                    vData += Math.Round(vUtime, 2) & "|"        'undertime
                    vData += Math.Round(iTardy, 2) & "|"        'tardiness

                    iRegHrs += vTemp
                    iND += vND
                    iOT += vOT
                    vData += Format(Math.Round(vTemp, 2), "#0.00") & "|"       'actual hours rendred
                    vData += Format(Math.Round(vND, 2), "#0.00") & "|"         'night differental
                    vData += Format(Math.Round(vOT, 2), "#0.00") & "|"           'excess hours

                    'get approved ot
                    cmRef.CommandText = "select DaysLeave as TotalOT,EffectivityDate from hr_leave_application where Emp_Cd = '" & _
                        rsEmp("Emp_Cd") & "' AND CONVERT(VARCHAR(10),startdate,111)='" & _
                        Format(iDate, "yyyy/MM/dd") & "' and Void = 0 and LeaveCd='OT' and DateApproved is not null"
                    rsRef = cmRef.ExecuteReader
                    Dim vLateOTFiled As String = ""
                    vHrsAllowed = 0
                    Do While rsRef.Read
                        If Not IsDBNull(rsRef("TotalOT")) Then
                            If IsDBNull(rsRef("EffectivityDate")) Then
                                vHrsAllowed += rsRef("TotalOT")
                            Else
                                vLateOTFiled = "<br/>Late Filed OT=" & rsRef("TotalOT") & "(" & rsRef("EffectivityDate") & ")<br/>"
                            End If
                        End If
                    Loop
                    'If rsRef.Read Then
                    '    If Not IsDBNull(rsRef("TotalOT")) Then
                    '        If IsDBNull(rsRef("EffectivityDate")) Then
                    '            vHrsAllowed = rsRef("TotalOT")
                    '        Else
                    '            vLateOTFiled = "<br/>Late Filed OT=" & rsRef("TotalOT") & "<br/>"
                    '        End If
                    '    End If
                    'End If
                    rsRef.Close()

                    vData += Format(vHrsAllowed, "#0.00") & "|"
                    iApprovedOT += vHrsAllowed

                    If Not IsDBNull(rs("OrgTimeIn")) Then
                        vData += "In: " & rs("OrgTimeIn") & vbCrLf
                    End If

                    If Not IsDBNull(rs("OrgTimeOut")) Then
                        vData += "Out: " & rs("OrgTimeOut") & vbCrLf
                    End If
                    If Not IsDBNull(rs("OrgTimeOutDate")) Then
                        vData += "Out Date: " & rs("OrgTimeOutDate")
                    End If
                    vData += "|"

                    If Not IsDBNull(rs("EffectivityDate")) And Not IsDBNull(rs("Date_Approved")) Then
                        vData += "Late Filed DTR(IN-OUT) "
                    End If
                    vData += vLateOTFiled

                    '''''''''''''''  REMARKS ANALYSIS ''''''''''''''''''''''
                    '######Start Leave Computation
                    If DaysLeave <> "" Then
                        If vHaveSched Then
                            vData += vEffectivityDate & LeaveCd & "=>" & vLeave / vTimeSched & " "
                            If vEffectivityDate = "" Then
                                If LeavesTable.ContainsKey(LeaveCd) Then
                                    If vEffectivityDate = "" Then
                                        LeavesTable.Item(LeaveCd) += vLeave / vTimeSched
                                    End If
                                Else
                                    LeavesTable.Add(LeaveCd, vLeave / vTimeSched)
                                End If
                            End If

                            If vReason <> "" Then
                                vData += vReason.Replace("}", ")").Replace("{", "(")
                            End If

                            vData += "|"
                        ElseIf vReason <> "" Then
                            vData += vReason.Replace("}", ")").Replace("{", "(") & "|"
                        Else
                            vData += "NO SCD|"
                        End If
                    ElseIf vReason <> "" Then
                        vData += vReason.Replace("}", ")").Replace("{", "(") & "|"
                    ElseIf Not vHaveSched And Not IsDBNull(rs("Time_OutDate")) Then
                        vData += "NO SCD|"
                    Else
                        vData += "|"
                    End If

                    '########End Leave Computation

                    vData += vDayType & ";"
                    rsRef.Close()
                Else        'no logs, either absent or leave
                    vData += Format(iDate, "MM/dd/yyyy") & "|" & IIf(vIn <> Nothing, Format(vIn, "HH:mm"), "") & "|" & _
                        IIf(vOut <> Nothing, Format(vOut, "HH:mm"), "") & "|||||||||||"

                    cmRef.CommandText = "SELECT CASE WHEN EL=1 THEN 'EL' ELSE LeaveCd END AS LeaveCd,DaysLeave,Paid,StartDate,EndDate,EffectivityDate FROM hr_leave_application WHERE '" & _
                        Format(iDate, "yyyy/MM/dd") & "' >= StartDate AND '" & Format(iDate, "yyyy/MM/dd") & _
                        "' <= EndDate AND Void=0 AND Emp_Cd='" & rsEmp("Emp_Cd") & "' AND DateApproved IS NOT null AND Paid <> 0 " & _
                        "and exists (select Leave_Cd from py_leave_ref where Leave_Cd not in ('UT','SUSP') and Leave_Cd=LeaveCd)"
                    rsRef = cmRef.ExecuteReader

                    If rsRef.Read Then
                        Dim test As String = rsRef("DaysLeave")
                        Dim a() As String

                        If Not IsDBNull(rsRef("EffectivityDate")) Then
                            vEffectivityDate = "Late filed (" & rsRef("EffectivityDate") & ")"
                        End If

                        a = test.Split(".")

                        If rsRef("DaysLeave") < 1 Then
                            vLeave = vEffectivityDate & rsRef("LeaveCd") & "=>" & rsRef("DaysLeave") & " "
                        Else
                            If a.Length > 1 And a(0) <> 0 And rsRef("EndDate") = iDate Then
                                vLeave = "." & a(1)
                            Else
                                vLeave = 1
                            End If

                            If vEffectivityDate = "" Then
                                If LeavesTable.ContainsKey(rsRef("LeaveCd")) Then

                                    LeavesTable.Item(rsRef("LeaveCd")) = LeavesTable.Item(LeaveCd) + vLeave

                                Else
                                    LeavesTable.Add(rsRef("LeaveCd"), vLeave)
                                End If
                            End If
                        End If
                        vData += rsRef("LeaveCd") & "=>" & vLeave & "|"
                    Else
                        vData += "|"
                    End If
                    rsRef.Close()
                    vData += vDayType & ";"
                End If
                rs.Close()
                iDate = DateAdd(DateInterval.Day, 1, iDate)
            Loop
            vPrn.Table = vFormat & vData
            vPrn.FontBold = True

            vData = "||||Total=>|" & Format(iUtime, "#0.00") & "|" & Format(vTotalTardy, "#0.00") & "|" _
                    & Format(iRegHrs, "##,##0.00") & _
                    "|" & Format(iND, "##,##0.00") & "|" & Format(iOT, "##,##0.00") & "|" & _
                    Format(iApprovedOT, "##,##0.00") & "||"

            Dim objKey As Object
            Dim objValue As Object

            For Each objKey In LeavesTable.Keys
                objValue = LeavesTable.Item(objKey)
                vTLeave += objKey.ToString & "=>" & objValue.ToString & vbNewLine
            Next objKey
            vTLeave = vTLeave.TrimEnd
            vData += vTLeave & ";"

            vPrn.Table = vFormat & vData
            vPrn.FontBold = False
            vPrn.Paragraph = ""
            If iPageCtr = 2 Then
                iPageCtr = 0
                vPrn.NewPage()
            End If
        Loop
        rsEmp.Close()

        c.Close()
        c.Dispose()
        cm.Dispose()
        cmEmp.Dispose()
        cmRef.Dispose()

        vPrn.EndDoc()
        Dim i As Integer
        vPrn.FontSize = 10
        vPrn.FontName = "Arial"
        For i = 1 To vPrn.PageCount
            vPrn.StartOverlay(i)
            vPrn.CurrentX = vPrn.PageWidth - 1500
            vPrn.CurrentY = vPrn.PageHeight - 500
            vPrn.Text = "Page " & i & " of " & vPrn.PageCount
            vPrn.EndOverlay()
        Next


        If Dir(Server.MapPath(".") & "\downloads\" & Session("sessionid") & "-dtr.pdf") <> "" Then
            Try
                Kill(Server.MapPath(".") & "\downloads\" & Session("sessionid") & "-dtr.pdf")
            Catch ex As IO.IOException
            End Try
        End If
        Try
            vPdf.ConvertDocument(vPrn, Server.MapPath(".") & "\downloads\" & Session("sessionid") & "-dtr.pdf")
            vPdfFile = "downloads/" & Session("sessionid") & "-dtr.pdf"
        Catch ex As IO.IOException
            Response.Write("An error occurred while trying to render the DTR. Error is: <br/>" & _
                ex.Message)
        End Try
        vPdf = Nothing
        vPrn = Nothing

        vResult = vPdfFile & "|" & DateDiff(DateInterval.Minute, vStart, Now)
    End Sub

    Private Function GetTrans(ByVal pTranCd As String, ByVal pDate As Date, ByVal pEmpCd As String) As Single
        Dim rslogdtl As SqlClient.SqlDataReader
        Dim vValue As Single = 0

        Dim cmLogDtl As New SqlClient.SqlCommand("select Hrs_Rendered from py_time_log_dtl where Emp_Cd='" & _
            pEmpCd & "' and TranDate='" & Format(pDate, "yyyy/MM/dd") & _
            "' and TranCd='" & pTranCd & "' AND LateFiled=0", c)


        'retrive the tardy calculated logs
        rslogdtl = cmLogDtl.ExecuteReader
        If rslogdtl.Read Then
            vValue = rslogdtl("Hrs_Rendered")
        End If
        rslogdtl.Close()
        cmLogDtl.Dispose()
        Return vValue
    End Function
End Class
