﻿Imports denaro.fis
Partial Class paysumm
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Public vHeaders As String = ""
    Public vData As String = ""
    Protected Sub cmdClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdClose.Click
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Or Session("uid") = Nothing Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If

        If Not IsPostBack Then
            Dim c As New SqlClient.SqlConnection(connStr)
            Dim cm As New SqlClient.SqlCommand
            Dim rs As SqlClient.SqlDataReader

            Try
                c.Open()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                c.Dispose()
                cm.Dispose()
                Exit Sub
            End Try

            cmbYear.Items.Clear()
            cm.Connection = c
            cm.CommandText = "select distinct year(paydate) from py_report order by year(paydate) desc"
            Try
                rs = cm.ExecuteReader
                Do While rs.Read
                    cmbYear.Items.Add(rs(0))
                Loop
                rs.Close()

            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to retrieve the records. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            Finally
                c.Close()
                c.Dispose()
                cm.Dispose()
            End Try
            cmdRefresh.Enabled = False
            If cmbYear.Items.Count > 0 Then
                cmdRefresh.Enabled = True
                GetPeriods()
            End If
        End If
    End Sub
    Private Sub GetPeriods()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        vHeaders = ""
        cm.Connection = c
        'cm.CommandText = "select distinct PayDate from py_report where Year(PayDate)=" & cmbYear.SelectedValue & " order by PayDate"
        cm.CommandText = "select distinct trandate from py_emp_time_log where YEAR(trandate)=2012 and " & _
                "TranCd in ('VL','SL')" & _
                " order by TranDate "

        Try
            rs = cm.ExecuteReader
            Do While rs.Read
                vHeaders += "<th>" & Format(rs(0), "MM/dd") & "</th>"
            Loop
            rs.Close()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to retrieve Payroll periods. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            c.Dispose()
            cm.Dispose()
        End Try

    End Sub

    Protected Sub cmdRefresh_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdRefresh.Click
        GetPeriods()
        'vScript = "getdata();"

        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cmRef As New SqlClient.SqlCommand
        Dim cmDept As New SqlClient.SqlCommand
        Dim rsDept As SqlClient.SqlDataReader
        Dim rsRef As SqlClient.SqlDataReader
        Dim rs As SqlClient.SqlDataReader

        c.Open()
        cm.Connection = c
        cmRef.Connection = c
        cmDept.Connection = c
        
        vData = ""
        'cmDept.CommandText = "select distinct rc_cd,(select Descr from rc where rc.rc_cd=py_report.rc_cd) Rc,Name,Emp_Cd from py_report " & _
        '    "where year(paydate)=" & cmbYear.SelectedValue & _
        '    " and EmploymentType IN ('CNT') order by rc,name"
        cmDept.CommandText = "select distinct (select rc_cd from py_emp_master where py_emp_master.emp_cd=py_emp_time_log.emp_cd)+'=>'+" & _
            "(select descr from rc where rc.Rc_Cd=(select rc_cd from py_emp_master where py_emp_master.emp_cd=py_emp_time_log.emp_cd)) as descr  ," & _
            "emp_cd,(select emp_lname+', '+emp_fname from py_emp_master where py_emp_master.Emp_Cd=py_emp_time_log.Emp_Cd) as Name " & _
            "from py_emp_time_log " & _
            "where TranCd in ('VL','SL')" & _
            " and YEAR(trandate)=2012 order by descr,Name "

        rsDept = cmDept.ExecuteReader
        Do While rsDept.Read
            vData += "<tr><td>" & rsDept("descr") & "</td><td>" & rsDept("Name") & "</td>"
            'cm.CommandText = "select distinct PayDate from py_report where Year(PayDate)=" & cmbYear.SelectedValue & " order by PayDate"
            cm.CommandText = "select distinct trandate from py_emp_time_log where YEAR(trandate)=2012 and " & _
                "TranCd in ('VL','SL')" & _
                " order by TranDate "

            rs = cm.ExecuteReader
            Do While rs.Read
                'basic rate
                'cmRef.CommandText = "select sum(basicrate+absent+tardiness) from py_report where paydate='" & _
                'Format(rs(0), "yyyy/MM/dd") & "' and Emp_Cd='" & rsDept("Emp_Cd") & "'"
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

                'overtime
                'cmRef.CommandText = "select sum(ot) from py_report where paydate='" & _
                '    Format(rs(0), "yyyy/MM/dd") & "' and Emp_Cd='" & rsDept("Emp_Cd") & "'"
                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

                'benefits
                'cmRef.CommandText = "select sum(Other_Incent1+Other_Incent2+Other_Incent3+Other_Incent4+Other_Incent5+Other_Incent6+Other_Incent7+Other_Incent8+Other_Incent9+" & _
                '     "Other_Incent12+Other_Incent13+Other_Incent14+Other_Incent15+Other_Incent16+Other_Incent17+Other_Incent18+Other_Incent19+" & _
                '     "Other_Incent20+Other_Incent22+Other_Incent28+Other_Incent29+Other_Incent30+Other_Incent31+Other_Incent32+Other_Incent33+" & _
                '     "Other_Incent34+Other_Incent35+Other_Incent36+Other_Incent37+Other_Incent39+Other_Incent40+Other_Incent41+Other_Incent42+" & _
                '     "Other_Incent43+Other_Incent44+Other_Incent45+Other_Incent46+Other_Incent47+Other_Incent48+Other_Incent49+Other_Incent50+" & _
                '     "Other_Incent51+Other_Incent52+Other_Incent53+Other_Incent54+Other_Incent55+Other_Incent56+Other_Incent57+Other_Incent58+" & _
                '     "Other_Incent59+Other_Incent60+SeniorAllowance) from py_report where paydate='" & _
                '    Format(rs(0), "yyyy/MM/dd") & "' and Emp_Cd='" & rsDept("Emp_Cd") & "'"
                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

                'net pay
                'cmRef.CommandText = "select sum(amount_per) from py_report where paydate='" & _
                '    Format(rs(0), "yyyy/MM/dd") & "' and Emp_Cd='" & rsDept("Emp_Cd") & "'"
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

                'with backpay

                'cmRef.CommandText = "select sum(Other_Incent10+Other_Incent11+Other_Incent21+Other_Incent23+" & _
                '     "Other_Incent24+Other_Incent25+Other_Incent26+Other_Incent27+Other_Incent38) " & _
                '     " from py_report where paydate='" & _
                '    Format(rs(0), "yyyy/MM/dd") & "' and Emp_Cd='" & rsDept("Emp_Cd") & "'"
                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

                cmRef.CommandText = "select sum(hrs_rendered) from py_emp_time_log where emp_cd='" & _
                    rsDept("Emp_Cd") & "' and trandate='" & _
                    Format(rs(0), "yyyy/MM/dd") & "' and " & _
                    "TranCd in ('VL','SL')"

                'cmRef.CommandText = "select 1 from py_report where paydate='" & _
                'Format(rs(0), "yyyy/MM/dd") & "' and Emp_Cd='" & rsDept("Emp_Cd") & "'"
                rsRef = cmRef.ExecuteReader
                If rsRef.Read Then
                    If Not IsDBNull(rsRef(0)) Then
                        vData += "<td>1</td>"
                    Else
                        vData += "<td>0</td>"
                    End If
                Else
                    vData += "<td>0</td>"
                End If
                rsRef.Close()
            Loop
            rs.Close()
            vData += "</tr>"
        Loop
        rsDept.Close()
        c.Close()
        c.Dispose()
        cm.Dispose()
        cmRef.Dispose()
        cmDept.Dispose()
    End Sub
End Class
