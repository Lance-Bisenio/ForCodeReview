Imports denaro.fis
Partial Class recalc
    Inherits System.Web.UI.Page
    Public vReturn As String = ""

    ''' ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
    ''' MODIFIED BY:  VIC GATCHALIAN                                  ''
    ''' DATE MODIFIED: 4/30/2013                                      ''
    ''' PURPOSE: TO GET THE EMPLOYEES GROUP RANK                      ''
    ''' ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
    Dim vGroupRank As String = ""
    ''' '''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''

    Dim vRank As String = ""
    Dim vGrace As Single = 0
    Dim vBreak As Single = 0
    Dim vRateHr As Single = 0
    Dim vRateDay As Single = 0
    Dim vReqHrs As Single = 8
    Dim vOtHrs As Single = 0
    Dim vOtAfter As Single = 0      'min. # of hours before ot is recognized
    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
    '' DATE MODIFIED: 3/25/2013                                                   ''
    '' MODIFIED BY:  VIC GATCHALIAN                                               ''
    '' PURPOSE: TO DEFINE A VARIABLE THAT WILL HOLD THE VALUE OF PRE-APPROVED     ''
    ''          OVERTIME HOURS                                                    ''
    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
    Dim vPreApprovedOTHrs As Single = 0
    '''''''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''''''''''

    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
    '' DATE MODIFIED: 5/21/2013                                                   ''
    '' MODIFIED BY:  VIC GATCHALIAN                                               ''
    '' PURPOSE: TO DEFINE A VARIABLE THAT WILL HOLD THE VALUE OF PRE-APPROVED     ''
    ''          OVERTIME HOURS FOR LEGAL AND SPECIAL HOLIDAY AS WELL AS RESTDAY   ''
    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
    Dim vPreApprovedOTHrsLegal As Single = 0
    Dim vPreApprovedOTHrsSpecial As Single = 0
    Dim vPreApprovedOTHrsRestday As Single = 0
    '''''''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''''''''''

    Dim vHours As Single = 0
    Dim vEmpStat As String = ""
    Dim vGrade As String = ""
    Dim vName As String = ""
    Dim vHoly As Boolean = False
    Dim vLegal As Boolean = False
    Dim vRest As Boolean = False
    Dim vFullFlexi As Boolean = False
    Dim vFlexi As Boolean = False
    Dim vMaxFlexHrs As Decimal = 0
    Dim vActualIn As Date = Nothing
    Dim vActualOut As Date = Nothing
    Dim vIn As Date = Nothing
    Dim vOut As Date = Nothing
    Dim vOutD As Date = Nothing
    Dim vRegIn As Date = Nothing
    Dim vRegOut As Date = Nothing
    Dim vAllowEarlyOT As Boolean = False
    'Dim vOrgRegIn As Date = Nothing
    'Dim vOrgRegOut As Date = Nothing
    Dim vType As String = "99"
    Dim vCasualCd As String = ""
    Dim vCanOT As Boolean = False
    Dim vOTonLeave As Boolean = False
    Dim vWithLeave As Boolean = False
    Dim vDaysLeave As Decimal = 0
    Dim vScheds(,) As String
    Dim vLateFiledDTR As Boolean = False
    Dim vLateFiledOT As Boolean = False
    Dim vTrans As New Collection
    Dim vEffectivityDate As Date = Nothing
    Dim vRC_Cd As String = ""
    Dim vAgency_Cd As String = ""
    Dim vGroupCd As String = "ADMIN"

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            vReturn = "expired"
            Exit Sub
        End If

        Dim vStartDate As Date = CDate(Request.Form("s"))
        Dim vEndDate As Date = CDate(Request.Form("e"))
        Dim vSQL As String = ""
        Dim vRc As Boolean = False
        Dim vOfc As Boolean = False
        Dim vEmploymentType As Boolean = False
        Dim iDate As Date
        Dim rc As String = ""
        Dim vAgency As String = ""
        Dim vUnionMember As Boolean = False
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cmRef As New SqlClient.SqlCommand
        Dim dr As SqlClient.SqlDataReader
        Dim drRef As SqlClient.SqlDataReader
        Dim iCtr As Integer = 0
        Dim vInRaw As String = ""
        Dim vOutRaw As String = ""
        Dim vDateOutRaw As String = ""

        vLateFiledDTR = Val(Request.Form("ldtr")) = 1
        vLateFiledOT = Val(Request.Form("lot")) = 1
        ' Dim vFilter As String = " where Date_Resign is null and DateSuspended is null and DateHold is null and Date_Retired is null " 

        c.Open()
        cm.Connection = c
        cmRef.Connection = c
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                                      ''
        '' DATE MODIFIED: 6/10/2013                                          ''
        '' PURPOSE: TO CALL THE RESYNC2LOGS MODULE TO UPDATE THE LEAVE       ''
        ''          APPLICATIONS                                             ''
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        cm.CommandText = "select ApplicationNo,Paid from hr_leave_application where Emp_Cd='" & Request.Form("id") & _
            "' and Paid=1 and Void=0 and StartDate between '" & Format(CDate(vStartDate), "yyyy/MM/dd") & _
            " 00:00:00' and '" & Format(CDate(vEndDate), "yyyy/MM/dd") & " 23:59:59' " & _
            " and LeaveCd<>'OT' and " & _
            " ((ApprovedBy is not null and DateApproved is not null and RecommendedBy is null and NotedBy is null)" & _
            " or (ApprovedBy is not null and DateApproved is not null and RecommendedBy is not null and DateRecommended is not null and NotedBy is null)" & _
            " or (ApprovedBy is not null and DateApproved is not null and RecommendedBy is not null and DateRecommended is not null and NotedBy is not null and DateNoted is not null))"
        ''''''''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''''''''

        dr = cm.ExecuteReader
        Do While dr.Read
            ResyncLeave2Logs(dr("ApplicationNo"), False, c)
        Loop
        dr.Close()
        ''''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''''

        'get defaults grace period,Break Hours and other global parameters
        cm.CommandText = "select Grace_Period, Break_Hrs, Casual_Cd,Start_Ot_Time,Allow_EarlyOT from py_syscntrl"
        dr = cm.ExecuteReader
        vGrace = 0
        vBreak = 0
        vOtAfter = 0
        vRank = ""
        vAllowEarlyOT = False

        'get default global parameters
        If dr.Read Then
            If Not IsDBNull(dr("Grace_Period")) Then vGrace = dr("Grace_Period")
            If Not IsDBNull(dr("Break_Hrs")) Then vBreak = dr("Break_Hrs")
            If Not IsDBNull(dr("Casual_Cd")) Then vCasualCd = dr("Casual_Cd")
            If Not IsDBNull(dr("Start_Ot_Time")) Then vOtAfter = dr("Start_Ot_Time")
            If Not IsDBNull(dr("Allow_EarlyOT")) Then vAllowEarlyOT = dr("Allow_EarlyOT")
        End If
        dr.Close()

        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                                                     ''
        '' DATE MODIFIED: 3/25/2013                                                         ''
        '' PURPOSE: TO INCLUDE THE "AutoApprovedOT" field to accommodate pre-approved ot    ''
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '''''''''''''''''''''''''''''' OLD CODE ''''''''''''''''''''''''''''''''''''''''''''''
        'vSQL = "select Emp_Cd,Emp_Lname,Emp_Fname,Req_Hrs_Day,Emp_Status,Rate_Day,OtAllowanceType,EmploymentType," & _
        '    "Allow_Reg_TimeIn,Allow_Req_Hrs,Grade_Cd,EmploymentType,GracePeriod,MinOtHours,MaxFlexHrs,Agency_Cd,Rc_Cd " & _
        '    "from py_emp_master where Emp_Cd='" & Request.Form("id") & "'"
        '''''''''''''''''''''''''''''' END OLD CODE ''''''''''''''''''''''''''''''''''''''''''
        vSQL = "select Emp_Cd,Emp_Lname,Emp_Fname,Req_Hrs_Day,Emp_Status,Rate_Day,OtAllowanceType,EmploymentType," & _
            "Allow_Reg_TimeIn,Allow_Req_Hrs,Grade_Cd,EmploymentType,GracePeriod,MinOtHours,MaxFlexHrs,Agency_Cd,Rc_Cd, " & _
            "AutoApprovedOT,AutoApprovedOT_Legal,AutoApproved_Special,AutoApproved_Restday," & _
            "CumulativeGrace,GroupCd,Allow_UnionDues,Allow_EarlyOT from py_emp_master where Emp_Cd='" & _
            Request.Form("id") & "'"
        '''''''''''''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''''''''''

        cm.CommandText = vSQL
        dr = cm.ExecuteReader
        If dr.Read Then
            vRC_Cd = dr("Rc_Cd")
            vAgency_Cd = dr("Agency_Cd")
            vGroupCd = dr("GroupCd")

            '''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:  VIC GATCHALIAN                      ''
            '' DATE MODIFIED: 3/25/2013                          ''
            '' PURPOSE: TO GET THE AUTO APPROVED OT FIELD        ''
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''
            vPreApprovedOTHrs = dr("AutoApprovedOT")
            '''''''''''''' END OF MODIFICATION ''''''''''''''''''''

            '''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:  VIC GATCHALIAN                      ''
            '' DATE MODIFIED: 3/25/2013                          ''
            '' PURPOSE: TO GET THE AUTO APPROVED OT FOR LEGAL,   ''
            ''          SPECIAL AND RESTDAY FIELDS.              ''
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''
            vPreApprovedOTHrsLegal = dr("AutoApprovedOT_Legal")
            vPreApprovedOTHrsSpecial = dr("AutoApproved_Special")
            vPreApprovedOTHrsRestday = dr("AutoApproved_Restday")
            '''''''''''''' END OF MODIFICATION ''''''''''''''''''''

            'set personalized parameter
            If Not IsDBNull(dr("EmploymentType")) Then vRank = dr("EmploymentType")
            If Not IsDBNull(dr("GracePeriod")) Then
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY:  VIC GATCHALIAN                                        ''
                '' DATE MODIFIED: 4/2/2013                                             ''
                '' PURPPOSE: TO FURTHER CHECK IF THE GRACE PERIOD IS CUMULATIVE OR NOT.''
                ''           IF CUMULATIVE, THE GRACE PERIOD FOR EACH DAY IS           ''
                ''           TEMPORARILY TURNED OFF AND WILL ACCUMULATE ON A PER CUT   ''
                ''           OFF BASIS.                                                ''
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                ''''''''''''''''''''''' OLD CODE ''''''''''''''''''''''''''''''''''''''''
                'vGrace = dr("GracePeriod")
                ''''''''''''''''''''''' END OLD CODE ''''''''''''''''''''''''''''''''''''
                If dr("CumulativeGrace") = 0 Then
                    vGrace = dr("GracePeriod")
                Else
                    vGrace = 0
                End If
                ''''''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''''
            End If

            If Not IsDBNull(dr("MinOtHours")) Then vOtAfter = dr("MinOtHours")
            If Not IsDBNull(dr("Allow_EarlyOT")) Then vAllowEarlyOT = dr("Allow_EarlyOT")
            vName = dr("Emp_Lname") & ", " & dr("Emp_Fname") & " "
            If Not IsDBNull(dr("Allow_Reg_TimeIn")) Then vFlexi = dr("Allow_Reg_TimeIn") = 0 'semi-flexi, no tardy, may or may have undertime
            If Not IsDBNull(dr("Allow_Req_Hrs")) Then vFullFlexi = dr("Allow_Req_Hrs") = 0 'full flexi, no undertime, no tardiness
            If Not IsDBNull(dr("Grade_Cd")) Then vGrade = dr("Grade_Cd")
            If Not IsDBNull(dr("Rc_Cd")) Then rc = dr("Rc_Cd")
            If Not IsDBNull(dr("Agency_Cd")) Then vAgency = dr("Agency_Cd")
            If Not IsDBNull(dr("Allow_UnionDues")) Then vUnionMember = dr("Allow_UnionDues")

            vMaxFlexHrs = dr("MaxFlexHrs")
            If Not IsDBNull(dr("OtAllowanceType")) Then
                If dr("OtAllowanceType") = "2" Then     'employee can have Overtime plus OT Allowance
                    vCanOT = True
                End If
            End If
            If Not IsDBNull(dr("Emp_Status")) Then vEmpStat = dr("Emp_Status")

            'get hourly rate and required hours per day
            If Not IsDBNull(dr("Req_Hrs_Day")) Then vReqHrs = dr("Req_Hrs_Day")
            If Not IsDBNull(dr("Rate_Day")) Then
                vRateDay = dr("Rate_Day")
                vRateHr = vRateDay / vReqHrs
            End If

            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:  VIC GATCHALIAN                                          ''
            '' DATE MODIFIED: 4/30/2013                                              ''
            '' PURPOSE: TO GET EMPLOYEE'S GROUP RANK FROM THE REFERENCE.             ''
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            cmRef.CommandText = "select GroupName from hr_employment_type where " & _
                "EmploymentType='" & vRank & "'"
            drRef = cmRef.ExecuteReader
            vGroupRank = "Ranks"
            If drRef.Read Then
                vGroupRank = drRef("GroupName")
            End If
            drRef.Close()
            ''''''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''''''

            iDate = vStartDate
            Do While iDate <= vEndDate
                vTrans.Clear()

                ''clean up any duplicate time-in null transactions
                'cmRef.CommandText = "delete from py_time_log where Time_In is null and Tran_Date='" & _
                '    Format(iDate, "yyyy/MM/dd") & "' and Emp_Cd='" & dr("Emp_Cd") & "' and EffectivityDate is null"
                'cmRef.ExecuteNonQuery()

                ''re-align  logs with logs raw
                'cmRef.CommandText = "select Time_In,Time_Out,Time_OutDate from py_time_log_raw where Emp_cd='" & dr("Emp_Cd") & _
                '    "' and Time_InDate='" & Format(iDate, "yyyy/MM/dd") & _
                '    "' and Time_In is not null  " & _
                '    "order by Time_InDate,Time_In,Time_Out"
                'drRef = cmRef.ExecuteReader
                'vInRaw = ""
                'vOutRaw = ""
                'vDateOutRaw = ""
                'If drRef.Read Then  'get first record
                '    vInRaw = drRef("Time_In")
                '    If Not IsDBNull(drRef("Time_Out")) Then
                '        vOutRaw = drRef("Time_Out")
                '    End If
                '    If Not IsDBNull(drRef("Time_OutDate")) And vOutRaw <> "" Then
                '        vDateOutRaw = drRef("Time_OutDate")
                '    End If

                '    'get last record
                '    Do While drRef.Read
                '        If Not IsDBNull(drRef("Time_Out")) Then
                '            If vOutRaw = "" Then
                '                vOutRaw = drRef("Time_Out")
                '                vDateOutRaw = drRef("Time_OutDate")
                '            Else
                '                If CDate(vDateOutRaw & " " & vOutRaw) < _
                '                    CDate(drRef("Time_OutDate") & " " & drRef("Time_Out")) Then
                '                    vOutRaw = drRef("Time_Out")
                '                    vDateOutRaw = drRef("Time_OutDate")
                '                End If
                '            End If
                '        End If
                '        'If Not IsDBNull(drRef("Time_OutDate")) And vOutRaw <> "" Then
                '        '    vDateOutRaw = drRef("Time_OutDate")
                '        'End If
                '    Loop
                'End If
                'drRef.Close()

                'get number of schedules in a day
                cmRef.CommandText = "select count(*) from py_emp_time_sched where Emp_Cd='" & _
                    dr("Emp_Cd") & "' and Date_Sched='" & Format(iDate, "yyyy/MM/dd") & "' and Start_Time is not null"
                drRef = cmRef.ExecuteReader
                iCtr = 0
                If drRef.Read Then
                    If Not IsDBNull(drRef(0)) Then
                        iCtr = drRef(0)
                    End If
                End If
                drRef.Close()
                ReDim vScheds(iCtr - 1, 3)

                cmRef.CommandText = "select Start_Time,End_Time,ShiftCd from py_emp_time_sched where Emp_Cd='" & _
                    dr("Emp_Cd") & "' and Date_Sched='" & Format(iDate, "yyyy/MM/dd") & "' and Start_Time is not null"
                drRef = cmRef.ExecuteReader
                iCtr = 0
                Do While drRef.Read
                    vScheds(iCtr, 0) = CDate(iDate & " " & Format(CDate(drRef("Start_Time")), "HH:mm:00"))
                    If CDate(Format(CDate(drRef("End_Time")), "HH:mm:00")) < CDate(Format(CDate(drRef("Start_Time")), "HH:mm:00")) Then
                        vScheds(iCtr, 1) = CDate(iDate.AddDays(1) & " " & Format(CDate(drRef("End_Time")), "HH:mm:00"))
                    Else
                        vScheds(iCtr, 1) = CDate(iDate & " " & Format(CDate(drRef("End_Time")), "HH:mm:00"))
                    End If
                    vScheds(iCtr, 2) = drRef("ShiftCd")
                    iCtr += 1
                Loop
                drRef.Close()

                '''''''''''''''''''''  GET STATUS OF DAY if it falls on a holiday '''''''''''''''''''''''''''''''
                cmRef.CommandText = "select Official,Office_Cd,Rc_Cd,Rank,UnionOnly from " & _
                    "py_holiday where month(Holy_Date)=" & _
                    Month(iDate) & " and day(Holy_Date)=" & Day(iDate) & _
                    " and Year(Holy_Date)=" & Year(iDate) & " order by Holy_Date desc"

                'cmRef.CommandText = "select Official,Office_Cd,Rc_Cd from py_holiday where month(Holy_Date)=" & _
                '    Month(iDate) & " and day(Holy_Date)=" & Day(iDate) & " and " & _
                '    "(Office_Cd like '%" & vAgency & "%' or Office_Cd='*') and " & _
                '    "(Rc_Cd like  '%" & rc & "%' or Rc_Cd='*') order by Holy_Date desc"

                drRef = cmRef.ExecuteReader
                vHoly = False
                vLegal = False
                vOfc = False
                vRc = False
                vEmploymentType = False
                If drRef.Read Then   'DAY IS HOLIDAY
                    If Not IsDBNull(drRef("Official")) Then
                        vLegal = drRef("Official")       '1=LEGAL HOLIDAY;0=SPECIAL HOLIDAY
                    End If
                    Dim vOfficeList() As String
                    Dim vRcList() As String
                    Dim vRankList() As String

                    If Not IsDBNull(drRef("Office_Cd")) Then
                        If drRef("Office_Cd") <> "*" Then
                            vOfficeList = drRef("Office_Cd").ToString.Split(",")
                            For i As Integer = 0 To UBound(vOfficeList)
                                If vOfficeList(i) = vAgency Then
                                    vOfc = True
                                    Exit For
                                End If
                            Next
                        Else
                            vOfc = True
                        End If
                    End If

                    If vOfc Then    'check cost center
                        If Not IsDBNull(drRef("Rc_Cd")) Then
                            If drRef("Rc_Cd") <> "*" Then
                                vRcList = drRef("Rc_Cd").ToString.Split(",")
                                For i As Integer = 0 To UBound(vRcList)
                                    If vRcList(i) = rc Then
                                        vRc = True
                                        Exit For
                                    End If
                                Next
                            Else
                                vRc = True
                            End If
                        End If
                    End If

                    If Not IsDBNull(drRef("Rank")) Then
                        If drRef("Rank") <> "*" Then
                            vRankList = drRef("Rank").ToString.Split(",")
                            For i As Integer = 0 To UBound(vRankList)
                                If vRankList(i) = vRank Then
                                    vEmploymentType = True
                                    Exit For
                                End If
                            Next
                        Else
                            vEmploymentType = True
                        End If
                    End If
                    vHoly = vRc And vOfc And vEmploymentType

                    If drRef("UnionOnly") = 1 And vHoly Then
                        vHoly = vUnionMember
                    End If
                End If

                drRef.Close()
                Analyze(dr("Emp_Cd"), iDate, vInRaw, vOutRaw, vDateOutRaw, c)
                iDate = iDate.AddDays(1)
            Loop
        End If
        dr.Close()
        cmRef.Dispose()
        cm.Dispose()
        c.Close()
        c.Dispose()
        vReturn = "ok"
    End Sub

    Private Sub Analyze(ByVal pID As String, ByVal pDate As Date, _
        ByVal pInRaw As String, ByVal pOutRaw As String, ByVal pDateOutRaw As String, _
        ByRef c As SqlClient.SqlConnection)

        Dim cm As New SqlClient.SqlCommand
        Dim dr As SqlClient.SqlDataReader
        Dim iCtr As Integer = 0
        Dim _2ndPass As Boolean = False
        Dim vNoRecord As Boolean = True
        Dim vSyncLog As Boolean = False
        Dim vDiff As Integer = 0

        vRest = False
        vIn = Nothing
        vOut = Nothing
        vOutD = Nothing
        vRegIn = Nothing
        vRegOut = Nothing
        vType = "99"
        vEffectivityDate = Nothing

        'If vEmpStat <> vCasualCd And vHoly Then Exit Sub

        'get actual logs
        cm.Connection = c
        If Not vLateFiledDTR Then       'get logs from current
again:
            cm.CommandText = "select Type,Time_In,Time_Out,Time_OutDate,Etp,Tran_Date as EffectivityDate,Reason from py_time_log " & _
                "where Tran_Date='" & Format(pDate, "yyyy/MM/dd") & "' and Emp_Cd='" & pID & _
                "' "
        Else                            'get logs from corrections
            cm.CommandText = "select Type,CorrectionTimeIn as Time_In, CorrectionTimeOut as Time_Out," & _
                "CorrectionTimeOutDate as Time_OutDate,Etp,EffectivityDate,Reason from py_time_log " & _
                "where Tran_Date='" & Format(pDate, "yyyy/MM/dd") & "' and Emp_Cd='" & pID & _
                "' and EffectivityDate is not null and Date_Approved is not null and ApprovedBy is not null " & _
                " and DateDisApproved is null"
        End If
        dr = cm.ExecuteReader
        If Not _2ndPass And Not dr.HasRows And vLateFiledDTR Then
            _2ndPass = True
            dr.Close()
            GoTo again
        End If

        If dr.Read Then 'date is either restday overtime or regular day checked later in the code
            vNoRecord = False
            If Not IsDBNull(dr("Reason")) Then
                vSyncLog = Not dr("Reason").ToString.Contains("Edited")
            Else
                vSyncLog = True
            End If
            If Not IsDBNull(dr("Time_In")) Then vIn = CDate(pDate & " " & Format(CDate(dr("Time_In")), "HH:mm:00"))
            If Not IsDBNull(dr("Time_OutDate")) Then
                vOutD = dr("Time_OutDate")
                If Not IsDBNull(dr("Time_Out")) Then
                    vOut = CDate(vOutD & " " & Format(CDate(dr("Time_Out")), "HH:mm:00"))
                Else
                    vOut = vIn  'set out = in if there's no out
                End If
            Else    'no logout, convert it to absent
                'vIn = Nothing
                vOut = Nothing
            End If
            If Not IsDBNull(dr("Type")) Then vType = dr("Type")
            If Not IsDBNull(dr("EffectivityDate")) Then vEffectivityDate = dr("EffectivityDate")
        Else    'no record at all, create a blank record on time log header instead
            vNoRecord = True
        End If
        dr.Close()

        If vNoRecord Then
            cm.CommandText = "insert into py_time_log (Tran_Date,Time_In,Time_Out,Time_OutDate,Etp,Type,Hrs_Worked,Emp_Cd) " & _
                "values ('" & Format(pDate, "yyyy/MM/dd") & "'," & IIf(pInRaw = "", "null", "'" & pInRaw & "'") & _
                "," & IIf(pOutRaw = "", "null", "'" & pOutRaw & "'") & "," & IIf(pDateOutRaw = "", "null", "'" & pDateOutRaw & "'") & _
                ",0,'99',0,'" & pID & "')"
            cm.ExecuteNonQuery()
        Else
            If vSyncLog Then
                'overwrite existing logs
                'Dim vHrs_Worked As Decimal = 0
                'If pOutRaw <> "" And pInRaw <> "" Then
                '    vHrs_Worked = Math.Round(DateDiff(DateInterval.Minute, _
                '        CDate(Format(pDate, "yyyy/MM/dd") & " " & pInRaw), _
                '        CDate(pDateOutRaw & " " & pOutRaw)) / 60, 2)
                'End If
                'cm.CommandText = "update py_time_log set Time_In=" & IIf(pInRaw = "", "null", "'" & pInRaw & "'") & _
                '    ",Time_Out=" & IIf(pOutRaw = "", "null", "'" & pOutRaw & "'") & _
                '    ",Time_OutDate=" & IIf(pDateOutRaw = "", "null", "'" & pDateOutRaw & "'") & _
                '    ",Hrs_Worked=" & vHrs_Worked & " where Emp_Cd='" & pID & "' and Tran_Date='" & Format(pDate, "yyyy/MM/dd") & "'"
                'cm.ExecuteNonQuery()

                'If pInRaw <> "" Then vIn = CDate(pDate & " " & Format(CDate(pInRaw), "HH:mm:00"))
                'If pDateOutRaw <> "" Then
                '    vOutD = CDate(pDateOutRaw)
                '    If pOutRaw <> "" Then
                '        vOut = CDate(vOutD & " " & Format(CDate(pOutRaw), "HH:mm:00"))
                '    Else
                '        vOut = vIn  'set out=in if there's no out
                '    End If
                'End If
            End If
        End If

        If vOut = Nothing And vIn <> Nothing Then
            vOut = vIn
        ElseIf vIn = Nothing And vOut <> Nothing Then
            vIn = vOut
        End If

        ''''' added by vic gatchalian on 7/17/2011 to support early overtime
        vActualIn = vIn
        vActualOut = vOut
        '''''''''' end modification '''''''''''


        '''''''''''update schedules in py_time_log '''''''''''''''
        DetermineSked(pDate, pID, c)
        'Dim a As Integer = vScheds.GetUpperBound(0)

        'Select Case vScheds.GetUpperBound(0)
        '    Case 0  'one schedule, temporary only, should be =0 only
        '        cm.CommandText = "update py_time_log set Sched_In = '" & vScheds(0, 0) & _
        '        "',Sched_Out='" & vScheds(0, 1) & "' where Emp_Cd='" & pID & _
        '        "' and Tran_Date='" & Format(pDate, "yyyy/MM/dd") & "'"
        '        cm.ExecuteNonQuery()
        '        vRegIn = CDate(vScheds(0, 0))
        '        vRegOut = CDate(vScheds(0, 1))
        '        vScheds(0, 2) = 1
        '    Case -1 'no schedule, rest day
        '        cm.CommandText = "update py_time_log set Sched_In = null" & _
        '            ",Sched_Out=null where Emp_Cd='" & pID & _
        '            "' and Tran_Date='" & Format(pDate, "yyyy/MM/dd") & "'"
        '        cm.ExecuteNonQuery()
        '        vRegIn = Nothing
        '        vRegOut = Nothing
        '    Case Else   'more than one schedule in a day
        '        Dim vIdx As Integer = -1
        '        For iCtr = 0 To UBound(vScheds)

        '        Next
        'End Select

        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

        vOtHrs = 0                     'Turn off Overtime approval
        'If vType <> "99" Then 'GET REGULAR TIME IN FROM PY_SHIFT
        '    cm.CommandText = "select Start_Time,End_Time,MaxHrs from py_shift where ShiftCd='" & _
        '        vType & "'"
        '    dr = cm.ExecuteReader
        '    If dr.Read Then
        '        If Not IsDBNull(dr("Start_Time")) Then
        '            vRegIn = CDate(pDate & " " & Format(CDate(dr("Start_Time")), "HH:mm:00"))
        '            If Not IsDBNull(dr("End_Time")) Then
        '                If dr("End_Time") < dr("Start_Time") Then
        '                    vRegOut = CDate(DateAdd(DateInterval.Day, 1, pDate) & " " & _
        '                        Format(CDate(dr("End_Time")), "HH:mm:00"))
        '                Else
        '                    vRegOut = CDate(pDate & " " & Format(CDate(dr("End_Time")), "HH:mm:00"))
        '                End If
        '            End If
        '        End If
        '    End If
        '    dr.Close()
        'Else  'GET REGULAR TIME IN FROM PY_EMP_TIME_SCHED
        '    cm.CommandText = "select Start_Time,End_Time,HrsAllowed from py_emp_time_sched " & _
        '        "where Emp_Cd='" & pID & "' and Date_Sched='" & Format(pDate, "yyyy/MM/dd") & "'"
        '    dr = cm.ExecuteReader
        '    If dr.Read Then   'with schedule
        '        vStartDate = pDate
        '        vEndDate = vStartDate
        '        vReqHrs = IIf(vReqHrs = 0, 8, vReqHrs)

        '        'compute for required hours / day, and get regular shift
        '        If Not IsDBNull(dr("Start_Time")) And Not IsDBNull(dr("End_Time")) Then
        '            vRegIn = CDate(pDate & " " & Format(CDate(dr("Start_Time")), "HH:mm:00"))
        '            If Not IsDBNull(dr("End_Time")) Then
        '                If dr("End_Time") < dr("Start_Time") Then
        '                    vEndDate = DateAdd(DateInterval.Day, 1, pDate)
        '                    vRegOut = CDate(vEndDate & " " & _
        '                        Format(CDate(dr("End_Time")), "HH:mm:00"))
        '                Else
        '                    vEndDate = vStartDate
        '                    vRegOut = CDate(pDate & " " & Format(CDate(dr("End_Time")), "HH:mm:ss"))
        '                End If

        '                ''''' turned off due to conflict in print summary report ''''''''''
        '                'vReqHrs = DateDiff(DateInterval.Hour, _
        '                '    CDate(Format(vEndDate, "yyyy/MM/dd") & " " & Format(dr("Start_Time"), "HH:mm:00")), _
        '                '    CDate(Format(vStartDate, "yyyy/MM/dd") & " " & Format(dr("End_Time"), "HH:mm:00")))
        '                'vReqHrs -= IIf(vReqHrs >= 5, vBreak, 0)    'adjust for break hours
        '                '''''''''''''''''''''' turned off '''''''''''''''''''
        '            End If
        '        End If
        '    End If   'with schedule
        '    dr.Close()

        vRest = vRegIn = Nothing

        'If vFlexi Then             'check if the employee falls on flexi-time (regtimein =0)
        '    If vRegIn <> Nothing And vIn <> Nothing Then
        '        vIn = vRegIn
        '    End If
        'End If

        'If vFullFlexi Then
        '    If vOut <> Nothing And vRegOut <> Nothing Then
        '        vOut = vRegOut
        '    End If
        'End If

        If vFlexi And vFullFlexi Then               'true and true   (no tardiness and no undertime)
            If vIn <> Nothing Then
                If vRegIn <> Nothing Then
                    vIn = vRegIn
                End If
                If vRegOut <> Nothing Then
                    vOut = vRegOut
                Else
                    vOut = vIn.AddHours(vReqHrs + vBreak)
                End If
            End If
            'ElseIf Not vFlexi And Not vFullFlexi Then   'false and false (with tardiness and with undertime)
            'do nothing, just let the actual logs retain
        ElseIf vFlexi And Not vFullFlexi Then       'true  and false (no tardiness and with undertime)
            Dim vLRegIn As Date
            Dim vURegIn As Date

            If vRegIn <> Nothing Then
                vLRegIn = vRegIn.AddHours(vMaxFlexHrs * -1)
                vURegIn = vRegIn.AddHours(vMaxFlexHrs)
            Else
                vLRegIn = vIn
                vURegIn = vIn
            End If

            If vIn <> Nothing Then
                If vIn <= vLRegIn Then
                    'vDiff = Math.Abs(DateDiff(DateInterval.Minute, vRegIn, vIn))
                    'If vDiff >= 30 Then
                    'difference between regular in and actual is at least 30 minutes, system will assume employee will avail the swing
                    vIn = vLRegIn
                    vRegIn = vLRegIn
                    vRegOut = vIn.AddHours(vReqHrs + vBreak)
                    'End If
                ElseIf vIn >= vLRegIn And vIn <= vURegIn Then   'within the # of hour swing alloted
                    vDiff = Math.Abs(DateDiff(DateInterval.Minute, vIn, vRegIn))
                    If vDiff >= 16 Or vMaxFlexHrs >= 99 Then
                        'difference between regular in and actual is at least 16 minutes, system will assume employee will avail the swing
                        vRegIn = vIn
                        vRegOut = vIn.AddHours(vReqHrs + vBreak)
                    End If
                End If
            End If
        ElseIf Not vFlexi And vFullFlexi Then       'false and true  (with tardiness and no undertime)
            If vOut = Nothing Then
                If vRegOut <> Nothing Then
                    vOut = vRegOut
                Else
                    vOut = vIn.AddHours(vReqHrs + vBreak)
                End If
            End If
        End If
        'End If

        ''''''  get approved overtime, if there's any ''''''''''''
        If Not vLateFiledOT Then        'current ot application mode
            cm.CommandText = "select sum(DaysLeave) as DaysLeave from hr_leave_application where " & _
                " Void=0 and ApprovedBy is not null and DateApproved is not null and EffectivityDate is null " & _
                " and LeaveCd='OT' and CreditTo='OT' and Emp_Cd='" & pID & "' and year(StartDate)=" & pDate.Year & _
                " and month(StartDate)=" & pDate.Month & " and day(StartDate)=" & pDate.Day
        Else
            cm.CommandText = "select DaysLeave, EffectivityDate from hr_leave_application where " & _
                " Void=0 and ApprovedBy is not null and DateApproved is not null " & _
                " and LeaveCd='OT' and CreditTo='OT' and Emp_Cd='" & pID & "' and year(StartDate)=" & pDate.Year & _
                " and month(StartDate)=" & pDate.Month & " and day(StartDate)=" & pDate.Day & _
                " and EffectivityDate is not null"
        End If
        dr = cm.ExecuteReader
        vOtHrs = 0
        If dr.Read Then
            If Not IsDBNull(dr("DaysLeave")) Then vOtHrs = dr("DaysLeave")
            If vLateFiledOT Then
                If Not IsDBNull(dr("EffectivityDate")) Then vEffectivityDate = dr("EffectivityDate")
            End If
        End If
        dr.Close()
        cm.Dispose()

        DigestTime(pDate, pID, c)
    End Sub
    Private Sub DetermineSked(ByVal pDate As Date, ByVal pID As String, ByRef c As SqlClient.SqlConnection)
        Dim cm As New SqlClient.SqlCommand
        Dim a As Integer = vScheds.GetUpperBound(0)
        cm.Connection = c
        Dim iCtr As Integer

        Select Case vScheds.GetUpperBound(0)
            Case 0  'one schedule, temporary only, should be =0 only
                cm.CommandText = "update py_time_log set Sched_In = '" & vScheds(0, 0) & _
                "',Sched_Out='" & vScheds(0, 1) & "',ShiftCd='" & vScheds(0, 2) & "' where Emp_Cd='" & pID & _
                "' and Tran_Date='" & Format(pDate, "yyyy/MM/dd") & "'"
                cm.ExecuteNonQuery()
                vRegIn = CDate(vScheds(0, 0))
                vRegOut = CDate(vScheds(0, 1))
                vScheds(0, 2) = 1
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY:  VIC GATCHALIAN                                            ''
                '' DATE MODIFIED: 6/4/2013                                                 ''
                '' PURPOSE: TO OVERRIDE THE DEFAULT # OF REQUIRED HOURS FOR THE DAY        ''
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                vReqHrs = DateDiff(DateInterval.Hour, vRegIn, vRegOut)
                If vReqHrs > 8 Then
                    'vReqHrs -= 1
                    vReqHrs = 8
                End If
                '''''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''''''''''
            Case -1 'no schedule, rest day
                cm.CommandText = "update py_time_log set Sched_In = null" & _
                    ",Sched_Out=null,ShiftCd='RD' where Emp_Cd='" & pID & _
                    "' and Tran_Date='" & Format(pDate, "yyyy/MM/dd") & "'"
                cm.ExecuteNonQuery()
                vRegIn = Nothing
                vRegOut = Nothing
            Case Else   'more than one schedule in a day
                Dim vIdx As Integer = -1
                For iCtr = 0 To UBound(vScheds)

                Next
        End Select
        'vOrgRegIn = vRegIn
        'vOrgRegOut = vRegOut
    End Sub
    Private Sub DigestTime(ByVal pDate As Date, ByVal pID As String, ByRef c As SqlClient.SqlConnection)
        Dim cm As New SqlClient.SqlCommand
        Dim dr As SqlClient.SqlDataReader

        cm.Connection = c
        'CLEAN EXISTING DATA
        If vLateFiledDTR Or vLateFiledOT Then
            'get data from current calculation
            cm.CommandText = "select TranCd,Hrs_Rendered from py_time_log_dtl where TranDate='" & _
                Format(pDate, "yyyy/MM/dd") & "' and Emp_Cd='" & pID & _
                "' and LateFiled=0"
            dr = cm.ExecuteReader
            vTrans.Clear()
            Do While dr.Read
                vTrans.Add(dr("Hrs_Rendered"), dr("TranCd"))
            Loop
            dr.Close()
           
            cm.CommandText = "delete from py_time_log_dtl where cast(Reason as varchar)='Auto-generated' " & _
                "and Emp_Cd='" & pID & "' and TranDate='" & Format(pDate, "yyyy/MM/dd") & "' "
        Else
            
            cm.CommandText = "delete from py_time_log_dtl where cast(Reason as varchar)='Auto-generated' " & _
                "and Emp_Cd='" & pID & "' and TranDate='" & Format(pDate, "yyyy/MM/dd") & "' "
        End If
        
        cm.ExecuteNonQuery()
        'now check if there are leaves for the day
        'cm.CommandText = "select Hrs_Rendered from py_time_log_dtl where cast(Reason as varchar)='Posted-LeaveApp' " & _
        '    "and Emp_Cd='" & pID & "' and TranDate='" & Format(pDate, "yyyy/MM/dd") & "'"
        cm.CommandText = "select Hrs_Rendered from py_time_log_dtl where Emp_Cd='" & pID & _
            "' and TranDate='" & Format(pDate, "yyyy/MM/dd") & "' and TranCd in (select Leave_Cd from py_leave_ref)"
        If vLateFiledDTR Or vLateFiledOT Then
            cm.CommandText += " and LateFiled=1"
        Else
            cm.CommandText += " and LateFiled=0"
        End If
        dr = cm.ExecuteReader
        vWithLeave = dr.HasRows
        vOTonLeave = False
        vDaysLeave = 0
        If dr.Read Then
            vDaysLeave = dr("Hrs_Rendered")
            If vOtHrs > 0 Then
                vOTonLeave = True
                'set it as restday
                If Not vHoly Then
                    If vDaysLeave > 4 Then  'more than half day
                        vRegIn = Nothing
                        vRegOut = Nothing
                    Else    'half day leave only

                    End If
                End If
            End If
        End If
        dr.Close()

        'CHECK FOR RESTDAY
        If vRegIn = Nothing And vIn = Nothing Then cm.Dispose() : Exit Sub


        If vIn = Nothing And vRegIn <> Nothing Then 'with schedule, but with no logs
            'check if it falls on holiday and employee is regular, exit procedure and do nothing
            'If vHoly And vEmpStat <> vCasualCd Then cm.Dispose() : Exit Sub

            If Not vHoly Then  'ABSENT
                Try
                    cm.CommandText = "select 1 from py_time_log where Tran_Date='" & _
                        Format(pDate, "yyyy/MM/dd") & "' and Emp_Cd='" & pID & "'"
                    dr = cm.ExecuteReader
                    If Not dr.HasRows Then
                        dr.Close()
                        cm.CommandText = "insert into py_time_log (Tran_Date,Emp_Cd,Emp_Name," & _
                            "Time_In,Time_Out,Time_OutDate,IsLeavePay,Hrs_Worked) values ('" & _
                            Format(pDate, "yyyy/MM/dd") & "','" & _
                            pID & "','" & vName & "',null,null,null,0,0)"
                        cm.ExecuteNonQuery()
                        'GoTo skip
                        DetermineSked(pDate, pID, c)
                    End If
                    dr.Close()
                    'cm.CommandText = "delete from py_time_log where Tran_Date='" & _
                    '    Format(pDate, "yyyy/MM/dd") & "' and Emp_Cd='" & _
                    '    pID & "'"
                    'cm.ExecuteNonQuery()
                    
                    '''''''''''update schedules in py_time_log '''''''''''''''
                    'skip:
                    'Select Case vScheds.GetUpperBound(0)
                    '    Case Is >= 0  'one schedule, temporary only, should be =0 only
                    '        cm.CommandText = "update py_time_log set Sched_In = '" & vScheds(0, 0) & _
                    '        "',Sched_Out='" & vScheds(0, 1) & "' where Emp_Cd='" & pID & _
                    '        "' and Tran_Date='" & Format(pDate, "yyyy/MM/dd") & "'"
                    '        cm.ExecuteNonQuery()
                    '        vRegIn = CDate(vScheds(0, 0))
                    '        vRegOut = CDate(vScheds(0, 1))
                    '        vScheds(0, 2) = 1
                    '    Case -1 'no schedule, rest day
                    '        cm.CommandText = "update py_time_log set Sched_In = null" & _
                    '            ",Sched_Out=null where Emp_Cd='" & pID & _
                    '            "' and Tran_Date='" & Format(pDate, "yyyy/MM/dd") & "'"
                    '        cm.ExecuteNonQuery()
                    '        vRegIn = Nothing
                    '        vRegOut = Nothing
                    '    Case Else   'more than one schedule in a day
                    '        For iCtr As Integer = 0 To UBound(vScheds)

                    '        Next
                    'End Select

                    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                Catch ex As SqlClient.SqlException
                    'if error occur, it means that there is already a record, disregard the execution
                End Try

                Dim vRemainingHours As Decimal = vReqHrs - vDaysLeave

                'If Not vWithLeave And Not vLateFiledOT And Not vLateFiledDTR Then
                If vRemainingHours > 0 Then
                    dr.Close()
                    cm.CommandText = "delete from py_time_log_dtl where TranDate='" & _
                        Format(pDate, "yyyy/M/dd") & "' and Emp_Cd='" & pID & _
                        "' and TranCd='ABSENT' and LateFiled=0"
                    cm.ExecuteNonQuery()
                    cm.CommandText = "insert into py_time_log_dtl (Emp_Cd,TranDate,TranCd,Reason," & _
                        "Hrs_Rendered,AmtConv,LateFiled,EffectivityDate) " & _
                        "values ('" & pID & "','" & Format(pDate, "yyyy/MM/dd") & "','ABSENT','Auto-generated'," & _
                        vRemainingHours & "," & vRateDay * (vRemainingHours / vReqHrs) * -1 & ",0,'" & Format(pDate, "yyyy/MM/dd") & "')"
                    cm.ExecuteNonQuery()
                    cm.Dispose()
                    Exit Sub
                End If
            Else    'holiday
                If vLegal Then       'HOLIDAY IS A LEGAL HOLIDAY
                    ExtractTime("C1", "C2", "C3", "C4", pDate, pID, c)
                Else                 'HOLIDAY IS A SPECIAL HOLIDAY
                    ExtractTime("F1", "F2", "F3", "F4", pDate, pID, c)
                End If
            End If
            cm.Dispose()
            Exit Sub
        End If


        cm.Dispose()


        'CHECK FOR OVERTIME IN RESTDAY
        If vIn <> Nothing And vRegIn = Nothing Then 'And vCanOT Then
            If Not vHoly Then 'REST DAY DOES NOT FALL ON A HOLIDAY (CODE IS E1 TO E4)
                ExtractTime("E1", "E2", "E3", "E4", pDate, pID, c)
            Else  'REST DAY FALLS ON A HOLIDAY
                If vLegal Then 'HOLIDAY IS A LEGAL HOLIDAY  (CODE IS D1 TO D4)
                    ExtractTime("D1", "D2", "D3", "D4", pDate, pID, c)
                Else  'HOLIDAY IS A SPECIAL HOLIDAY (CODE IS B1 TO B4)
                    ExtractTime("B1", "B2", "B3", "B4", pDate, pID, c)
                End If
            End If
            Exit Sub
        End If

        If vIn <> Nothing And vRegIn <> Nothing Then        'WITH LOGS, WITH SCHEDULE
            If Not vHoly Then 'REGULAR DAY
                CheckRegular(pDate, pID, c)
            Else  'FALLS ON A HOLIDAY
                'If vCanOT Then
                If vLegal Then       'HOLIDAY IS A LEGAL HOLIDAY
                    ExtractTime("C1", "C2", "C3", "C4", pDate, pID, c)
                Else                 'HOLIDAY IS A SPECIAL HOLIDAY
                    ExtractTime("F1", "F2", "F3", "F4", pDate, pID, c)
                End If
                'End If
            End If
        ElseIf vIn = Nothing And vRegIn <> Nothing And vHoly Then
            If vLegal Then       'HOLIDAY IS A LEGAL HOLIDAY
                ExtractTime("C1", "C2", "C3", "C4", pDate, pID, c)
            Else                 'HOLIDAY IS A SPECIAL HOLIDAY
                ExtractTime("F1", "F2", "F3", "F4", pDate, pID, c)
            End If
        End If
    End Sub

    Private Function RoundOff(ByVal pRemainder As Single) As Single
        'If pRemainder >= 0.5 Then
        '    Return 0.5
        'Else
        '    Return 0
        'End If
        Return pRemainder
    End Function

    Private Sub ExtractTime(ByVal p1 As String, ByVal p2 As String, _
        ByVal p3 As String, ByVal p4 As String, ByVal pDate As Date, ByVal pID As String, _
        ByRef c As SqlClient.SqlConnection)

        Dim vTmpOut As Date = vOut
        Dim cm As New SqlClient.SqlCommand("", c)
        Dim rs As SqlClient.SqlDataReader
        Dim vDate As Date = Nothing
        Dim vCanHoliday As Boolean = True


        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                             ''
        '' DATE MODIFIED: 5/21/2013                                 ''
        '' PURPOSE: TO ADD THE PRE-APPROVED OT FOR LEGAL, SPECIAL   ''
        ''          RESTDAY VARIABLES TO APPROVED OT HOURS.         ''
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        If p1.Contains("E") Then    'restday
            vOtHrs += vPreApprovedOTHrsRestday
        ElseIf p1.Contains("C") Or p1.Contains("D") Then    'legal holiday and legal holiday on restday
            vOtHrs += vPreApprovedOTHrsLegal
        ElseIf p1.Contains("F") Or p1.Contains("B") Then    'special holiday and special holiday on restday
            vOtHrs += vPreApprovedOTHrsSpecial
        End If
        '''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''


        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '''''''  MODIFIED BY: VIC GATCHALIAN                         '
        '''''''  DATE MODIFIED: 1/12/2011                            '
        '''''''  REASON:  Checks if employee reported for duty a day '
        '''''''           before the holiday                         '
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                             ''
        '' DATE MODIFIED: 4/30/2013                                 ''
        '' PURPOSE: AS PER PH LAW, THIS CODE SHOULD ONLY APPLY TO   ''
        ''          NON-MANAGERS.                                   ''
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '''''''''''''''''''' OLD CODE '''''''''''''''''''''''''''''''
        'If p1.Contains("C") Or p1.Contains("F") Then
        ''''''''''''''' END OLD CODE '''''''''''''''''''''''''''''
        'If (p1.Contains("C") Or p1.Contains("F")) And (vGroupRank = "Ranks" Or vGroupRank = "Supervisor") Then
        '    ''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''
        '    cm.CommandText = "select TOP 1 Date_Sched from py_emp_time_sched where Start_Time is not null and Date_Sched < '" & _
        '    Format(pDate, "yyyy/MM/dd") & "' and Emp_Cd='" & pID & _
        '    "' and not exists (select Holy_Date from py_holiday where Holy_Date=Date_Sched and " & _
        '    "(Rc_Cd='*' or Rc_Cd like '%" & vRC_Cd & "%') and (Office_Cd='*' or Office_Cd like '%" & vAgency_Cd & _
        '    "%') ) order by Date_Sched desc"

        '    rs = cm.ExecuteReader
        '    If rs.Read Then
        '        vDate = rs("Date_Sched")
        '    End If
        '    rs.Close()
        '    If vDate <> Nothing Then    'employee has last schedule, check logs
        '        cm.CommandText = "select 1 from py_time_log where Emp_Cd='" & pID & _
        '            "' and Tran_Date='" & Format(vDate, "yyyy/MM/dd") & "' and Time_In is not null"
        '        rs = cm.ExecuteReader
        '        vCanHoliday = rs.HasRows
        '        rs.Close()
        '        If Not vCanHoliday Then
        '            'check if there's a filed leave application
        '            cm.CommandText = "select 1 from py_time_log_dtl where Emp_Cd='" & pID & _
        '                "' and TranDate='" & Format(vDate, "yyyy/MM/dd") & "' and TranCd in (" & _
        '                "select Leave_Cd from py_leave_ref) and LateFiled=0"
        '            rs = cm.ExecuteReader
        '            vCanHoliday = rs.HasRows
        '            rs.Close()
        '        End If
        '    End If
        '    'double check if special holiday, and employee is daily paid
        '    If p1.Contains("F") And vCanHoliday And vIn = Nothing Then
        '        Dim vEmpStatus As String = ""
        '        Dim vSysDailyCd As String = ""

        '        cm.CommandText = "select Emp_Status from py_emp_master where Emp_Cd='" & pID & "'"
        '        rs = cm.ExecuteReader
        '        If rs.Read Then
        '            If Not IsDBNull(rs("Emp_Status")) Then
        '                vEmpStatus = rs("Emp_Status")
        '            End If
        '        End If
        '        rs.Close()
        '        cm.CommandText = "select Casual_Cd from py_syscntrl"
        '        rs = cm.ExecuteReader
        '        If rs.Read Then
        '            If Not IsDBNull(rs("Casual_Cd")) Then
        '                vSysDailyCd = rs("Casual_Cd")
        '            End If
        '        End If
        '        rs.Close()

        '        If vEmpStatus = vSysDailyCd Then
        '            vCanHoliday = False
        '        End If
        '    End If
        'End If
        '''''''   END OF MODIFICATIONS ''''''''''''''''''''''''''''''''

        If vCanHoliday Then
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            ''''''  MODIFIED BY:  VIC GATCHALIAN                               '
            ''''''  DATE MODIFIED: 9/12/2011                                   '
            ''''''  PURPOSE:  SETS THE AUTO-APPROVAL OF OVERTIME THAT FALLS    '
            ''''''            ON HOLIDAY (EITHER SPECIAL OR LEGAL)             '
            ''''''  EXCEPTIONS:  THIS IS FOR GWI USE ONLY                      '
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            'If Not p1.Contains("E") Then
            '    vOtHrs = 24 'set default to auto-approved overtime on holidays '
            'End If
            ''''''  END OF MODIFICATION ''''''''''''''''''''''''''''''''''''''''
redirect:
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:  VIC GATCHALIAN                                   ''
            '' DATE MODIFIED: 4/12/2013                                       ''
            '' PURPOSE: TO OVERRIDE THE APPROVED OT HOURS TO AUTO-APPROVE     ''
            ''          HOURS WHEN THE EMPLOYEE BELONGS TO "OPERATIONS" GROUP ''
            '' EXCEPTIONS: FOR MANILA PEN USE ONLY                            ''
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            'If vGroupCd = "OPERATIONS" And (p1.Contains("C") Or p1.Contains("F")) Then
            '    vOtHrs = DateDiff(DateInterval.Hour, vRegIn, vRegOut) 'add the default to auto-approved overtime on holidays
            'End If
            '''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''''''

            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:  VIC GATCHALIAN                                   ''
            '' DATE MODIFIED: 4/11/2012                                       ''
            '' PURPOSE: TO ADJUST THE VIN VALUE IF VIN < VREGIN               ''
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            If vIn < vRegIn Then
                vIn = vRegIn
            End If
            '''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''''''

            vOut = vIn.AddHours(vOtHrs) 'adjust to approved out based on approved ot hours
            vOut = IIf(vOut > vTmpOut, vTmpOut, vOut)

            'vHours = Math.Abs(Math.Round(DateDiff(DateInterval.Minute, vIn, vOut) / 60, 2))
            vHours = Math.Round(DateDiff(DateInterval.Minute, vIn, vOut) / 60, 2)
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            ''''''''''' MODIFIED BY:  VIC GATCHALIAN                    '
            ''''''''''' DATE MODIFIED:  9/26/2011                       '
            ''''''''''' PURPOSE: TO ROUND OFF THE DECIMAL TO NEAREST    '
            '''''''''''          30 MINUTES OR 0.5 HOURS                '
            ''''''''''' EXCEPTION: FOR FASTRAK USE ONLY                 '
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            'vHours = Int(vHours) + RoundOff(vHours - Int(vHours))   'round off the minutes side
            'If vHours < 0.5 Then vHours = 0
            '''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''
            If vHours >= vOtAfter Then
                ''''''''' added by vic on 7/16/2011 ''''''''''''''''
                ''''''''' This will subtract 1 hour when the number of hours is greater than 6 hours
                ''''''''' FOR DSM use only
                'If vHours >= 7 Then
                '    vHours -= 1
                'ElseIf vHours > 6 And vHours < 7 Then
                '    vHours = 6
                'End If
                ''''''''' END MODIFICATIONS ''''''''''''''''''''''

                WriteLog(p1, IIf(vHours > 8, 8, vHours), pID, pDate, IIf(vHours > 8, 8, vHours), c) 'OT FIRST 8HRS
                If vHours > 8 Then WriteLog(p3, vHours - 8, pID, pDate, vHours - 8, c) 'OT IN EXCESS OF 8HRS 

                Dim vNDHrs As Decimal = 0

                'check for night diff before 6 am
                Dim vNDTime As Date = CDate(Format(pDate.AddDays(-1), "yyyy/MM/dd") & " 22:00:00")
                Dim vNDEndTime As Date = CDate(Format(pDate, "yyyy/MM/dd") & " 6:00:00")

                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY: VIC GATCHALIAN                                         ''
                '' DATE MODIFIED: 3/8/2012                                             ''
                '' PURPOSE:  TO SUPPORT 11PM TO 7AM NIGHT DIFFERENTIAL CALCULATION.    ''
                '' EXCEPTIONS: FOR MANILA PENINSULA USE ONLY                           ''
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                If vIn > vNDTime And vIn <= vNDTime.AddHours(1) Then
                    'system assumes that the employee is availing of the 11pm-7am ND swing
                    vNDTime = vIn
                    vNDEndTime = vNDTime.AddHours(8)
                End If
                ''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''''''''

                'If vIn > vNDTime Or vOut >= vNDEndTime Then   'regular schedule has night differential
                If vIn > vNDTime And vIn <= vNDEndTime Then   'regular schedule has night differential
                    Dim vNDActualStart As Date = IIf(vIn > vNDTime, vIn, vNDTime)
                    'vNDActualStart = IIf(vIn > vNDActualStart, vIn, vNDActualStart)
                    Dim vNDActualEnd As Date = IIf(vOut > vNDEndTime, vNDEndTime, vOut)
                    'vNDActualEnd = IIf(vOut > vNDActualEnd, vNDActualEnd, vOut)

                    vNDHrs = Math.Round(DateDiff(DateInterval.Minute, vNDActualStart, vNDActualEnd) / 60, 2)
                End If

                'check for night diff after 10pm
                ''''''''''''''' OLD CODE '''''''''''''''''''''''''
                'If vOut >= CDate(pDate & " 22:00:00") Then  'OUT IS ON OR AFTER 10PM
                '    vTmpOut = vOut
                '    Dim vTmpIn As Date = vIn    'set default to actual in

                '    If vIn < CDate(pDate & " 22:00:00") Then 'IN is before 10PM, adjust tmp in to 10pm
                '        vTmpIn = CDate(pDate & " 22:00:00")
                '    End If

                '    vNDHrs += Math.Abs(Math.Round(DateDiff(DateInterval.Minute, vTmpIn, vTmpOut) / 60, 2))
                '    'vHours = Int(vHours) + RoundOff(vHours - Int(vHours))   'round off the minutes side

                'End If
                '''''''''''''''''' END OLD CODE '''''''''''''''''''
                If vOut >= CDate(pDate & " 22:00:00") Then  'OUT IS ON OR AFTER 10PM
                    Dim vTmpIn As Date = vIn    'set default to actual in
                    Dim vTmpNDEnd As Date = CDate(Format(pDate.AddDays(1), "yyyy/MM/dd") & " 06:00:00")

                    If vIn < CDate(pDate & " 22:00:00") Then 'IN is before 10PM, adjust tmp in to 10pm
                        vTmpIn = CDate(pDate & " 22:00:00")
                        vTmpNDEnd = vTmpIn.AddHours(8)  'set default to 6am next day
                    Else    'actual in is past 10pm
                        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                        '' MODIFIED BY:  VIC GATCHALIAN                        ''
                        '' DATE MODIFIED: 3/9/2012                             ''
                        '' PURPOSE: TO FURTHER CHECK IF THE ACTUAL IN IS       ''
                        ''          BETWEEN 10PM TO 11PM. IF IT IS BETWEEN     ''
                        ''          1OPM-11PM, ADJUST THE ND END ACCORDINGLY.  ''
                        ''          OTHERWISE, IF ACTUAL IN IS PAST 11PM, SET  ''
                        ''          THE END NIGHT DIFFERENTIAL BACK TO 6AM.    ''
                        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                        'check if actual in is between 10pm to 11pm.
                        If vIn <= CDate(pDate & " 23:00:00") Then
                            '''''''' actual in is between 10pm-11pm
                            vTmpNDEnd = vIn.AddHours(8)
                        Else
                            ''''''' actual in is past 11pm, default to 6am
                            vTmpNDEnd = CDate(Format(pDate.AddDays(1), "yyyy/MM/dd") & " 06:00:00")
                        End If
                        ''''''''''''''''' END OF MODIFCATION '''''''''''''''''''
                    End If

                    If vOut < vTmpNDEnd Then
                        vTmpOut = vOut
                    Else
                        vTmpOut = vTmpNDEnd
                    End If

                    vNDHrs += Math.Abs(Math.Round(DateDiff(DateInterval.Minute, vTmpIn, vTmpOut) / 60, 2))
                End If
                '''''''''''''''''' END OF MODIFICATION ''''''''''''

                If vNDHrs > 0 Then
                    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                    '''''  MODIFIED BY :  VIC GATCHALIAN                   ''
                    '''''  DATE MODIFIED:  9/27/2011                       ''
                    '''''  PURPOSE:  TO SEGGREGATE THE FIRST 8 HOURS       ''
                    '''''            AGAINST EXCESS OF 8 HOURS             ''
                    '''''  EXCEPTIONS:  FOR DSM USE ONLY                   ''
                    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                    '''''''' ORIGINAL CODE '''''''' 
                    WriteLog(p2, vNDHrs, pID, pDate, vNDHrs, c)    'ND OT
                    '''''''' END ORIGINAL CODE ''''
                    'subtract 1 hour if vhours > 4 
                    'If vNDHrs >= 7 Then
                    '    vNDHrs -= 1
                    'ElseIf vNDHrs > 6 And vNDHrs < 7 Then
                    '    vNDHrs = 6
                    'End If

                    'WriteLog(p2, IIf(vNDHrs > 8, 8, vNDHrs), pID, pDate, IIf(vNDHrs > 8, 8, vNDHrs), c)    'ND OT
                    'If vNDHrs > 8 Then WriteLog(p4, vNDHrs - 8, pID, pDate, vNDHrs - 8, c) 'ND OT excess of 2 hours
                    ''''''''''''''''''''''''' END OF MODIFICATION ''''''''''''''
                End If
            End If
        Else    'tag as absent 
            If vIn <> Nothing Then
                vOtHrs = 0
                GoTo redirect
            Else
                cm.CommandText = "insert into py_time_log_dtl (Emp_Cd,TranDate,TranCd,Reason," & _
                        "Hrs_Rendered,AmtConv,LateFiled,EffectivityDate) " & _
                        "values ('" & pID & "','" & Format(pDate, "yyyy/MM/dd") & "','ABSENT','Auto-generated'," & _
                        "8," & vRateDay * -1 & ",0,'" & Format(pDate, "yyyy/MM/dd") & "')"
                cm.ExecuteNonQuery()
                cm.Dispose()
            End If
        End If
    End Sub
    Private Sub WriteLog(ByVal pCode As String, ByVal pHrs As Single, ByVal pID As String, _
        ByVal pDate As Date, ByVal pOrgHrs As Single, ByRef c As SqlClient.SqlConnection)

        Dim cm As New SqlClient.SqlCommand
        Dim dr As SqlClient.SqlDataReader
        Dim vFactor As Single = 0
        Dim vWithTardyMatrix As Boolean = False
        Dim vUOM As Integer = 0     '0=percent: 1= amount
        Dim _2ndPass As Boolean = False
        Dim vAmtConv As Decimal = 0
        Dim vHourlyRate As Decimal = vRateHr

        cm.Connection = c

        '''''''''' for fastrak use only ''''''''''''''''''
        '''''''''' MODIFIED BY: VIC GATCHALIAN '''''''''''
        '''''''''' PURPOSE: DETERMINES IF REST DAY       '
        ''''''''''          FALLS ON SATURDAY, IF IT'S   '
        ''''''''''          SATURDAY, SYSTEM WILL CONVERT'
        ''''''''''          THE CODE TO G-SERIES TO      '
        ''''''''''          COMPUTE IT AS 1OO% ONLY      '
        '''''''''' EXCEPTIONS: FOR FASTRAK USE ONLY      '
        ''''''''''''''''''''''''''''''''''''''''''''''''''
        'If pCode.Contains("E") And pCode <> "ABSENT" Then
        '    If pDate.DayOfWeek = DayOfWeek.Saturday Then
        '        pCode = pCode.Replace("E", "G")
        '    End If
        'End If
        '''''''''' end for fastrak use only ''''''''''''''
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                                          ''
        '' DATE MODIFIED: 2/17/2012                                              ''
        '' PURPOSE:  TO SUPPORT THE TARDINESS MATRIX IF THERE ARE ANY            ''
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        'now check in tardiness table
        If pCode = "TARD" Then  'transaction is tardiness
            cm.CommandText = "select * from py_tardiness_table where " & _
                (pHrs * 60) & " between FromMinutes and ToMinutes"
            dr = cm.ExecuteReader

            vWithTardyMatrix = False
            vFactor = 0    'DEFAULT TO 0
            If dr.Read Then
                vWithTardyMatrix = True
                vFactor = dr("Factor")
                If dr("RoundTo") = 1 Then
                    If Not IsDBNull(dr("RoundedTo")) Then pHrs = dr("RoundedTo")
                End If
            End If
            dr.Close()
            If vFactor = 0 Then GoTo def 'use default settings instead  
        ElseIf pCode = "UT" Then    'transaction is undertime
            cm.CommandText = "select * from py_undertime_table where " & _
                (pHrs * 60) & " between FromMinutes and ToMinutes"
            dr = cm.ExecuteReader

            vWithTardyMatrix = False
            vFactor = 0    'DEFAULT TO 0
            If dr.Read Then
                vWithTardyMatrix = True
                vFactor = dr("Factor")
                If dr("RoundTo") = 1 Then
                    If Not IsDBNull(dr("RoundedTo")) Then pHrs = dr("RoundedTo")
                End If
            End If
            dr.Close()
            If vFactor = 0 Then GoTo def 'use default settings instead  
        Else
            If vRank = "" Then  'no rank, use default
def:
                cm.CommandText = "select OtPer, 0 as UOM from py_ot_ref where OtCd='" & pCode & "'"
            Else    'with rank, check the 
                cm.CommandText = "select UOM,Factor as OtPer from py_ot_ref_dtl where OtCd='" & pCode & _
                    "' and EmploymentType='" & vRank & "'"
            End If
            dr = cm.ExecuteReader

            If dr.Read Then
                If Not IsDBNull(dr("OtPer")) Then vFactor = dr("OtPer")
                If Not IsDBNull(dr("UOM")) Then vUOM = dr("UOM")
                ''''''''''''''''''''''''''''''''''''''''''''
                '''''   MODIFIED BY: VIC GATCHALIAN        '
                '''''   PURPOSE: TO COMPUTE TARDY AND UT   '
                '''''            AS 1PESO:1MINUTE RATIO    '
                '''''   EXCEPTIONS:  for fastrak use only  '
                ''''''''''''''''''''''''''''''''''''''''''''
                'If pCode = "TARD" Or pCode = "UT" Then    'unit of measure is by amount, reset rate/hr to 1 peso only
                '    vHourlyRate = 1
                'End If
                '''''''   END OF CODE '''''''''''''''''''''
            ElseIf Not dr.HasRows And Not _2ndPass Then    'no record found, use default settings 
                _2ndPass = True
                dr.Close()
                GoTo def
            End If
            dr.Close()
        End If
        '''''''''''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''

        'ADD NEW DATA
        If vLateFiledOT Or vLateFiledDTR Then
            Dim vOldHrs As Decimal = 0
            Dim vAdjHrs As Decimal = 0
            Try
                vOldHrs = vTrans(pCode)
            Catch ex As Exception   'index does not exist
                vOldHrs = 0
            End Try
            vAdjHrs = pHrs - vOldHrs
            If Not vWithTardyMatrix Then
                vAmtConv = Math.Round(vFactor * vAdjHrs * vHourlyRate, 2)
            Else
                vAmtConv = Math.Round(vFactor * vAdjHrs, 2)
            End If

            If vAmtConv <> 0 Then
                cm.CommandText = "insert into py_time_log_dtl (Emp_Cd,TranDate,TranCd,Hrs_Rendered,AmtConv,Reason," & _
                    "LateFiled,EffectivityDate) values ('" & pID & "','" & Format(pDate, "yyyy/MM/dd") & "','" & pCode & "'," & _
                    vAdjHrs & "," & vAmtConv & ",'Auto-generated',1,'" & _
                    Format(vEffectivityDate, "yyyy/MM/dd") & "')"
            End If
        Else
            If Not vWithTardyMatrix Then
                vAmtConv = Math.Round(vFactor * pHrs * vHourlyRate, 2)
            Else
                vAmtConv = Math.Round(vFactor * vHourlyRate, 2)
            End If

            If vAmtConv <> 0 Then
                cm.CommandText = "insert into py_time_log_dtl (Emp_Cd,TranDate,TranCd,Hrs_Rendered,AmtConv,Reason," & _
                    "LateFiled,EffectivityDate) values ('" & pID & "','" & Format(pDate, "yyyy/MM/dd") & "','" & pCode & "'," & _
                    pOrgHrs & "," & vAmtConv & ",'Auto-generated',0,'" & _
                    Format(pDate, "yyyy/MM/dd") & "')"
            End If
        End If
        Try
            cm.ExecuteNonQuery()
        Catch ex As SqlClient.SqlException
        End Try

        cm.Dispose()
    End Sub

    Private Function AdjustGrace(ByVal pValue As Object, ByVal pGrace As Single) As String
        Dim vHr As Single
        Dim vMin As Single

        vHr = 0 : vMin = 0
        If pGrace > 59 Then
            vHr = pGrace / 60
            vMin = pGrace Mod 60
        Else
            vMin = pGrace
        End If
        vHr = vHr + Hour(pValue)
        vMin = vMin + Minute(pValue)
        AdjustGrace = Format(vHr, "00") & ":" & Format(vMin, "00") & ":00"
    End Function
    Private Sub CheckRegular(ByVal pDate As Date, ByVal pID As String, ByRef c As SqlClient.SqlConnection)
        Dim vTardy As Single = 0
        Dim vUndertime As Single = 0
        Dim vHr As Single = 0
        Dim vMin As Single = 0
        Dim vFactor As Single = 0
        Dim vNDTime As Date
        Dim cm As New SqlClient.SqlCommand
        Dim dr As SqlClient.SqlDataReader
        Dim vLeaveDays As Integer = 0
        Dim vDistance As Integer = 0
        Dim vBalance As Decimal = vDaysLeave
        Dim vActualOTHours As Decimal = 0
        'Dim vActualIn As Date = vIn    'disregarded to support early ot

        cm.Connection = c

        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                                                  ''
        '' DATE MODIFIED: 5/21/2013                                                      ''
        '' PURPOSE:  TO ADD IN THE AUTOMATIC PRE-APPROVED OVERTIME                       ''
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        vOtHrs += vPreApprovedOTHrs
        '''''''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''''''''''''''

        'If vIn <= vRegIn Then vIn = vRegIn 'adjust vin to regular in

        If vOut = Nothing And vIn <> Nothing Then vOut = vIn

        If vIn > vRegIn.AddMinutes(vGrace) Then   'TARDY 
            'check if vin falls on 2nd half or 1st half of the day
            Dim v2ndHalf As Date = vRegIn.AddHours(vReqHrs / 2)
            ''''''''''''' for fastrak use only''''''''''''''
            '''''''' tardiness shall start after the alloted grace period.
            '''''''' e.g. if sched in 9am and grace period is 10mins, system will deduct only 1 min onwards after 9:10am
            'vTardy = Math.Round(Math.Abs(DateDiff(DateInterval.Minute, vIn, vRegIn.AddMinutes(vGrace))), 2)
            '''''''''''''''''''''''''''''''''''''' end fastrak use ''''''''''''''''''''''''
            vTardy = Math.Round(Math.Abs(DateDiff(DateInterval.Minute, vIn, vRegIn)), 2)

            If vIn >= v2ndHalf Then 'actual in falls on 2nd half of the day, deduct the break hours from tardy
                vTardy -= (vBreak * 60)
            End If
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

            'now check in tardiness table
            'cm.CommandText = "select * from py_tardiness_table where " & _
            '    vTardy & " between FromMinutes and ToMinutes"
            'dr = cm.ExecuteReader

            'vFactor = 1    'DEFAULT TO 100%
            'If dr.Read Then
            '    vFactor = dr("Factor")
            '    If dr("RoundTo") Then
            '        If Not IsDBNull(dr("RoundedTo")) Then vTardy = dr("RoundedTo")
            '    End If
            'End If
            'dr.Close()

            'vTardy = (vTardy * vFactor) / 60
            vTardy = vTardy / 60

            If vTardy > 0 Then
                If vBalance >= vTardy Then  'hours leave is still greater than tardiness, remove the tardiness and updat the balance
                    vBalance -= vTardy
                    vTardy = 0
                ElseIf vBalance > 0 And vBalance < vTardy Then    'days leave is less than tardiness,reduce tardiness by hours leave and zero out the hour leave afterwards
                    '''''''''''' code inserted by vic on 6/25/2009 ''''''''''''
                    vTardy -= vBalance
                    vBalance = 0
                End If
            End If
        End If

        If vOut < vRegOut Then      'check for undertime 
            'vUndertime = Math.Round(DateDiff(DateInterval.Minute, vOut, vRegOut) / 60, 2)
            vUndertime = DateDiff(DateInterval.Minute, vOut, vRegOut) / 60
            If vUndertime > 0 Then
                If vBalance >= vUndertime Then 'hours leave is still greater than tardiness, remove the tardiness and updat the balance
                    vBalance -= vUndertime
                    vUndertime = 0
                ElseIf vBalance > 0 And vBalance < vUndertime Then    'days leave is less than tardiness,reduce tardiness by hours leave and zero out the hour leave afterwards
                    '''''''''''' code inserted by vic on 6/25/2009 ''''''''''''
                    vUndertime -= vBalance
                    vBalance = 0
                End If
            End If
        End If

        'Else 'If vOut > vRegOut Then ' And vCanOT Then    'with overtime
        Dim vNDHrs As Decimal = 0
        Dim vNDEndTime As Date
        Dim vUBound As Date = vRegOut
        Dim vNDActualStart As Date = Nothing
        Dim vNDActualEnd As Date = Nothing

        If vOtHrs > 0 Then  'there's an approved overtime
            If vAllowEarlyOT Then
                vActualOTHours = Math.Abs(Math.Round(DateDiff(DateInterval.Minute, vActualIn, vRegIn) / 60, 2))
                vActualOTHours = Int(vActualOTHours) + RoundOff(vActualOTHours - Int(vActualOTHours))

                If vActualOTHours < 0.5 Then
                    vActualOTHours = 0
                End If
            End If

            vUBound = vRegOut
            If vOut < vUBound Then  'adjust upper bound if actual out is less than approved ot
                vUBound = vOut
            End If

            vActualOTHours += Math.Abs(Math.Round(DateDiff(DateInterval.Minute, vUBound, vOut) / 60, 2))
            vActualOTHours = Int(vActualOTHours) + RoundOff(vActualOTHours - Int(vActualOTHours))

            If vActualOTHours > vOtHrs Then
                vActualOTHours = vOtHrs
            End If
        End If

        'check night differential which falls before 6am
        vNDTime = CDate(pDate.AddDays(-1) & " 22:00:00")
        vNDEndTime = CDate(pDate & " 6:00:00")
        If (vRegIn >= vNDTime And vRegIn <= vNDEndTime) Or _
           (vRegIn < vNDTime And (vRegOut > vNDEndTime Or vRegOut <= vNDEndTime)) Then   'regular schedule has night differential
            vNDActualStart = IIf(vRegIn > vNDTime, vRegIn, vNDTime)
            vNDActualStart = IIf(vIn > vNDActualStart, vIn, vNDActualStart)
            vNDActualEnd = IIf(vRegOut > vNDEndTime, vNDEndTime, vRegOut)
            vNDActualEnd = IIf(vOut > vNDActualEnd, vNDActualEnd, vOut)

            vNDHrs = Math.Round(DateDiff(DateInterval.Minute, vNDActualStart, vNDActualEnd) / 60, 2)
            'vNDHrs = Int(vNDHrs) + RoundOff(vNDHrs - Int(vNDHrs))
        End If

        'check night differential which falls on 10pm 
        vNDTime = CDate(pDate & " 22:00:00")
        vNDEndTime = CDate(pDate.AddDays(1) & " 6:00:00")
        If vRegIn >= vNDTime Or vRegOut >= vNDTime Then   'regular schedule has night differential
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:  VIC GATCHALIAN                           ''
            '' DATE MODIFIED: 3/9/2012                                ''
            '' PURPOSE: TO CHECK IF ACTUAL IN IS BETWEEN 10PM-11PM.   ''
            ''          IF ACTUAL IN IS BEYONG 11PM, DEFAULT THE END  ''
            ''          OF NIGHT DIFFERENTIAL TO 6AM DEFAULT,         ''
            ''          OTHERWISE, ADJUST THE END NIGHT DIFF TO 8 HRS ''
            ''          FROM THE START OF NIGHT DIFF AS DEFAULT END.  ''
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            ''''''''''''''''''' OLD CODE '''''''''''''''''''''''''''''''
            'vNDActualStart = IIf(vRegIn > vNDTime, vRegIn, vNDTime)
            'vNDActualStart = IIf(vIn > vNDActualStart, vIn, vNDActualStart)
            'vNDActualEnd = IIf(vRegOut > vNDEndTime, vNDEndTime, vRegOut)
            'vNDActualEnd = IIf(vOut > vNDActualEnd, vNDActualEnd, vOut)
            ''''''''''''''''''' END OLD CODE '''''''''''''''''''''''''''

            'vNDActualStart = IIf(vRegIn > vNDTime, vRegIn, vNDTime)
            vNDActualStart = vNDTime    'default to 10pm
            vNDActualEnd = vNDEndTime

            If vIn >= vNDTime Then
                vNDActualStart = vIn
                If vIn <= vNDTime.AddHours(1) Then
                    'actual in is between 10pm-11pm, adjust the 
                    vNDActualEnd = vIn.AddHours(8)
                Else
                    'actual in is beyond 11pm
                    vNDActualEnd = vNDTime.AddHours(1).AddHours(8)
                End If
            End If
            vNDActualEnd = IIf(vOut > vNDActualEnd, vNDActualEnd, vOut)
            vNDActualEnd = IIf(vNDActualEnd > vRegOut, vRegOut, vNDActualEnd)
            ''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''

            vNDHrs += Math.Round(DateDiff(DateInterval.Minute, vNDActualStart, vNDActualEnd) / 60, 2)
            'vNDHrs = Int(vNDHrs) + RoundOff(vNDHrs - Int(vNDHrs))
        End If

        If vNDHrs > 0 Then
            'If vNDHrs > 4 Then
            '    If vNDHrs < 5 Then  'partial only
            '        vNDHrs = vNDHrs - (vNDHrs - 4) 'just remove the remaining partial excess hour
            '    Else
            '        vNDHrs -= 1 'just remove 1 hour break
            '    End If
            'End If
            'vNDHrs = Int(vNDHrs) + RoundOff(vNDHrs - Int(vNDHrs))     'round off the minutes side
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:  RUDNER DIAZ                                          ''
            '' DATE MODIFIED: 5/17/2013                                           ''
            '' PURPOSE: TO ROUND UP THE NIGHT DIFFERENTIAL TO ONE FULL 8 HOURS    ''
            ''          IF COMPUTED ND IS AT LEAST 4 HOURS                        ''
            '' EXCEPTIONS: FOR CYGNUS USE                                         ''
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            If vNDHrs >= 4 Then
                vNDHrs = 8
            End If
            ''''''''''''''''''''' END OF MODFICATION '''''''''''''''''''''''''''''''

            WriteLog("A4", vNDHrs, pID, pDate, vNDHrs, c)    'ND OT
        End If

        If vActualOTHours >= vOtAfter And vActualOTHours > 0 Then  'overtime is eligible
            'check if overtime falls on night differential
            vUBound = vRegOut.AddHours(vOtHrs)

            vUBound = IIf(vOut > vUBound, vUBound, vOut)

            If vUBound > vNDTime Then  'out falls on night diff ot
                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY:  VIC GATCHALIAN                           ''
                '' DATE MODIFIED: 3/9/2012                                ''
                '' PURPOSE: TO CHECK IF ACTUAL IN IS BETWEEN 10PM-11PM.   ''
                ''          IF ACTUAL IN IS BEYONG 11PM, DEFAULT THE END  ''
                ''          OF NIGHT DIFFERENTIAL TO 6AM DEFAULT,         ''
                ''          OTHERWISE, ADJUST THE END NIGHT DIFF TO 8 HRS ''
                ''          FROM THE START OF NIGHT DIFF AS DEFAULT END.  ''
                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '''''''''''''''''' OLD CODE ''''''''''''''''''''''''''''''''
                'vNDActualStart = IIf(vRegOut > vNDTime, vRegOut, vNDTime)
                'vNDHrs = Math.Abs(Math.Round(DateDiff(DateInterval.Minute, vNDActualStart, _
                '    IIf(vUBound > vNDEndTime, vNDEndTime, vUBound)) / 60, 2))
                'vNDHrs = Int(vNDHrs) + RoundOff(vNDHrs - Int(vNDHrs))
                '''''''''''''''''' END OLD CODE ''''''''''''''''''''''''''''
                'vNDActualStart = vNDTime
                vNDActualStart = vRegOut
                If vUBound > vNDActualStart Then
                    If vUBound <= vNDActualStart.AddHours(1) Then
                        'actual out is between 10pm-11pm, adjust the 
                        vNDActualEnd = vNDActualStart.AddHours(1)
                    Else
                        'actual in is beyond 11pm
                        vNDActualEnd = vNDEndTime
                    End If
                End If
                vNDActualEnd = IIf(vOut > vNDActualEnd, vNDActualEnd, vOut)
                '''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''

                vNDHrs = Math.Abs(Math.Round(DateDiff(DateInterval.Minute, vNDActualStart, _
                    IIf(vUBound > vNDEndTime, vNDEndTime, vUBound)) / 60, 2))

                WriteLog("A2", vNDHrs, pID, pDate, vNDHrs, c)    'ND OT
                'If vNDHrs > 2 Then WriteLog("A3", vNDHrs - 2, pID, pDate, vNDHrs - 2, c) 'ND OT excess of 2 hours
            End If

            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:  VIC GATCHALIAN                                      '
            '' DATE MODIFIED:  10/18/2011                                        '
            '' PURPOSE: TO SEGREGATE THE COMPUTATION OF ND HOURS AGAINST REG OT  '
            ''          HOURS AND NOT THE USUAL ND HOURS ON TOP OF REG OT HRS    '
            '' EXCEPTIONS:  FOR DSM USE ONLY                                     '
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            'subtract computed nd hours from computed ot hours
            'If vNDHrs < vActualOTHours Then
            '    vActualOTHours -= vNDHrs
            'Else
            '    vActualOTHours = 0
            'End If
            '''''''''''''''''' END OF MODIFICATION  ''''''''''''''''''''''''''''''
            WriteLog("A1", vActualOTHours, pID, pDate, vActualOTHours, c)   'OT Regular
        End If


        'check if there's a filed leave without pay
        'Dim vDaysLeaveNoPay As Decimal = 0

        'cm.CommandText = "select DaysLeave from hr_leave_application where Emp_Cd='" & _
        '    pID & "' and StartDate='" & Format(pDate, "yyyy/MM/dd") & _
        '    "' and Void=0 and Paid=0 and DateApproved is not null and EffectivityDate is null"
        'dr = cm.ExecuteReader
        'If dr.Read Then
        '    If Not IsDBNull(dr("DaysLeave")) Then
        '        vDaysLeaveNoPay = dr("DaysLeave") * 8
        '    End If
        'End If

        'check if there's a filed leave with pay
        Dim vDaysLeavePay As Single = 0
        cm.CommandText = "select DaysLeave from hr_leave_application where Emp_Cd='" & _
           pID & "' and '" & Format(pDate, "yyyy/MM/dd") & "' between StartDate and EndDate " & _
           " and Void=0 and Paid=1 and DateApproved is not null and EffectivityDate is null"
        dr = cm.ExecuteReader
        If dr.Read Then
            If Not IsDBNull(dr("DaysLeave")) Then
                vDaysLeavePay = dr("DaysLeave") * 8
            End If
        End If

        dr.Close()
        cm.Dispose()

        'write undertime and tardiness    
        If vDaysLeavePay < 8 Then
            If vTardy > 0 Then
                'If vDaysLeaveNoPay > 0 Then
                '    'If vDaysLeaveNoPay > vTardy Then    'applied leave is more than incurred tardiness, reset the leave to tardiness value
                '    '    vDaysLeaveNoPay = vTardy
                '    'End If
                '    'WriteLog("ABSENT", vDaysLeaveNoPay, pID, pDate, vDaysLeaveNoPay, c)
                '    'vTardy -= vDaysLeaveNoPay
                '    vDaysLeaveNoPay = 0     'reset back to zero since it was already written to the database
                '    If vTardy > 0 Then  'double check if there is still tardiness despite the absent without leave application
                '        WriteLog("TARD", vTardy, pID, pDate, vTardy, c)
                '    End If
                'Else
                'Added by Rudner dated 1/17/2010
                If vTardy >= 5 Then
                    vTardy = vTardy - 1
                ElseIf vTardy > 4 And vTardy < 5 Then
                    vTardy = 4
                End If

                'If vDaysLeavePay > 0 Then
                '    vDaysLeavePay -= vTardy
                '    vTardy = vTardy - vDaysLeavePay
                '    vTardy = 0  'temporary only
                'End If

                If vTardy >= 4 Then 'tardy is more than 4 hours, convert to absences
                    'Rdd--------------------------------------
                    WriteLog("ABSENT", vTardy, pID, pDate, vTardy, c)
                ElseIf vTardy > 0 Then
                    WriteLog("TARD", vTardy, pID, pDate, vTardy, c)
                End If
                'End If
            End If

            If vUndertime > 0 Then
                'double check if there is still values in vdaysleavenopay variable
                'If vDaysLeaveNoPay > 0 Then
                '    If vDaysLeaveNoPay > vUndertime Then
                '        vDaysLeaveNoPay = vUndertime
                '    End If
                '    WriteLog("ABSENT", vDaysLeaveNoPay, pID, pDate, vDaysLeaveNoPay, c)
                '    vUndertime -= vDaysLeaveNoPay
                '    vDaysLeaveNoPay = 0     'reset back to zero since it was already written to the database
                '    If vUndertime > 0 Then  'double check if there is still undertime despite the absent without leave application
                '        WriteLog("UT", vUndertime, pID, pDate, vUndertime, c)
                '    End If
                'Else
                'If vUndertime >= 5 Then
                '    vUndertime = vUndertime - 1
                '    'Else
                '    '    vUndertime = 4
                'End If
                If vUndertime >= 5 Then
                    vUndertime = vUndertime - 1
                ElseIf vTardy > 4 And vTardy < 5 Then
                    vUndertime = 4
                End If

                'If vDaysLeavePay > 0 Then
                '    vUndertime = vUndertime - vDaysLeavePay
                '    vUndertime = 0  'temporary only
                'End If

                If vUndertime >= 4 Then 'undertime is more than 4 hours, convert to absences
                    'Added by Rudner 1/17/2011
                    '------------------
                    WriteLog("ABSENT", vUndertime, pID, pDate, vUndertime, c)
                Else
                    WriteLog("UT", vUndertime, pID, pDate, vUndertime, c)
                End If
                'End If
            End If
        End If
    End Sub
End Class
