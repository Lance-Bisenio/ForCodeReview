Imports denaro
Partial Class logdtl
    Inherits System.Web.UI.Page

    Public vScript As String = "window.focus();"
    Public vList As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            vScript = "alert('Your login session has expired. Please log-in again.'); window.close();"
            Exit Sub
        End If

        If Not IsPostBack Then
            Dim c As New SqlClient.SqlConnection
            Dim cm As New SqlClient.SqlCommand
            Dim dr As SqlClient.SqlDataReader

            lblCaption.Text = "View detailed transaction for the selected log"
            lblId.Text = Session("empid")
            lblName.Text = Session("empname")
            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c
            cm.CommandText = "select EmploymentType,Rate_Day,Req_Hrs_Day from py_emp_master where Emp_Cd='" & _
                lblId.Text & "'"
            dr = cm.ExecuteReader
            If dr.Read Then
                lblRank.Text = dr("EmploymentType")
                lblDaily.Text = dr("Rate_Day")
                lblHourly.Text = dr("Rate_Day") / IIf(IsDBNull(dr("Req_Hrs_Day")), 8, dr("Req_Hrs_Day"))
                txtDaily.Value = lblDaily.Text
                txtHourly.Value = lblHourly.Text
            End If
            dr.Close()
            cm.Dispose()
            c.Close()
            DataRefresh()
        End If
    End Sub
    Private Sub DataRefresh()
        Dim c As New SqlClient.SqlConnection
        'Dim cDtl As New sqlclient.SqlConnection
        Dim cm As New SqlClient.SqlCommand
        Dim dr As SqlClient.SqlDataReader
        Dim vDate As Date = CDate(Session("tdate"))
        Dim vEmpId As String = Session("empid")
        Dim cmDtl As New SqlClient.SqlCommand
        Dim drDtl As SqlClient.SqlDataReader
        Dim vHrs As Single = 0
        Dim vAmt As Single = 0
        Dim vTable As String = IIf(Session("byperiod") = "1", "py_emp_time_log", "py_time_log_dtl")
        Dim vClass As String = "odd"
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                                 '
        '' DATE MODIFIED: 4/26/2012                                     '
        '' PURPOSE: TO SHOW THE FACTOR RATE OF THE CUSTOM SETTINGS      '
        ''          IF THERE ARE ANY.                                   '
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        Dim vFactor As Single = 0
        '''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''''

        c.ConnectionString = connStr

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            cmDtl.Dispose()
            Exit Sub
        End Try

        cm.Connection = c
        cmDtl.Connection = c
        cm.CommandText = "select OtCd,Descr,OtPer from py_ot_ref"

        Try
            dr = cm.ExecuteReader
            vList = ""
            Do While dr.Read
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY:  VIC GATCHALIAN                        ''
                '' DATE MODFIED: 4/26/2012                             ''
                '' PURPOSE: TO CHECK IF THERE ARE ANY CUSTOM SETTINGS  ''
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                'set default factor
                vFactor = IIf(IsDBNull(dr("OtPer")), 0, dr("OtPer"))

                cmDtl.CommandText = "select Factor,Uom from py_ot_ref_dtl where EmploymentType='" & _
                    lblRank.Text & "' and OtCd='" & dr("OtCd") & "'"

                drDtl = cmDtl.ExecuteReader
                If drDtl.Read Then
                    vFactor = IIf(IsDBNull(drDtl("Factor")), vFactor, drDtl("Factor"))
                End If
                drDtl.Close()
                '''''''''''''''''''' END OF MODIFICATION ''''''''''''''''

                cmDtl.CommandText = "select Hrs_Rendered,AmtConv from " & vTable & " where Emp_Cd='" & _
                                vEmpId & "' and TranDate='" & Format(vDate, "yyyy/MM/dd") & "' and TranCd='" & _
                                dr("OtCd") & "' " & IIf(Session("byperiod") = "1", "", "AND LateFiled=0")

                drDtl = cmDtl.ExecuteReader
                vHrs = 0 : vAmt = 0
                If drDtl.Read Then
                    vHrs = IIf(IsDBNull(drDtl("Hrs_Rendered")), 0, drDtl("Hrs_Rendered"))
                    vAmt = IIf(IsDBNull(drDtl("AmtConv")), 0, drDtl("AmtConv"))
                End If
                drDtl.Close()
                vList += "<tr class='" & vClass & "'>" & _
                         "<td style='width: 96px; height: 24px;' class='label'>" & dr("OtCd") & "</td>" & _
                         "<td style='width: 226px; height: 24px;' class='label'>" & dr("Descr") & "</td>" & _
                         "<td style='width: 66px; height: 24px;'>" & _
                         "<input id='txtFactor" & dr("OtCd") & "' class='label' style='width: 56px' type='text' readonly='readonly' value='" & _
                         vFactor & "' /></td>" & _
                         "<td style='width: 80px; height: 24px;'>" & _
                         "<input id='txtHr" & dr("OtCd") & "' name='txtHr" & dr("OtCd") & "' class='label' style='width: 56px' " & _
                         "type='text' onblur='calc(this);' value='" & vHrs & "' /></td>" & _
                         "<td style='width: 87px; height: 24px;'>" & _
                        "<input id='txtVal" & dr("OtCd") & "' class='label' style='width: 56px' type='text' readonly='readonly' " & _
                        "value='" & Math.Round(vAmt, 2) & "'/></td></tr>"
                vClass = IIf(vClass = "odd", "even", "odd")
            Loop
            dr.Close()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to retrieve OT information. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            c.Dispose()
            cm.Dispose()
            cmDtl.Dispose()
        End Try
    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        Dim vEmpid As String = Session("empid")
        Dim vDate As Date = CDate(Session("tdate"))
        Dim vRateHr As Single = Val(lblHourly.Text)
        Dim vFactor As Single = 0
        Dim c As New SqlClient.SqlConnection
        Dim cm As New SqlClient.SqlCommand
        Dim cmQry As New SqlClient.SqlCommand
        Dim dr As SqlClient.SqlDataReader
        Dim drQry As SqlClient.SqlDataReader
        Dim vHrs As Single = 0
        Dim vAmt As Single = 0
        Dim vTable As String = IIf(Session("byperiod") = "1", "py_emp_time_log", "py_time_log_dtl")

        c.ConnectionString = connStr

        c.Open()
        cm.Connection = c
        cmQry.Connection = c
        cm.CommandText = "select OtCd,OtPer from py_ot_ref"
        dr = cm.ExecuteReader
        'clear existing data first
        If Session("byperiod") = "1" Then
            cmQry.CommandText = "delete from py_emp_time_log where Emp_Cd='" & vEmpid & _
                "' and TranDate='" & Format(vDate, "yyyy/MM/dd") & "' "
        Else
            cmQry.CommandText = "delete from py_time_log_dtl where Emp_Cd='" & vEmpid & _
                "' and TranDate='" & Format(vDate, "yyyy/MM/dd") & "' AND  LateFiled=0"
        End If

        cmQry.ExecuteNonQuery()
        Do While dr.Read
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY: VIC GATCHALIAN                                   ''
            '' DATE MODIFIED: 4/26/2012                                      ''
            '' PURPOSE: TO CHECK IF THERE ARE ANY CUSTOM SETTINGS            ''
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            vFactor = IIf(IsDBNull(dr("OtPer")), 0, dr("OtPer"))
            cmQry.CommandText = "select Factor,Uom from py_ot_ref_dtl where EmploymentType='" & _
                            lblRank.Text & "' and OtCd='" & dr("OtCd") & "'"
            drQry = cmQry.ExecuteReader
            If drQry.Read Then
                vFactor = IIf(IsDBNull(drQry("Factor")), vFactor, drQry("Factor"))
            End If
            drQry.Close()
            '''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''''

            vHrs = Val(Request.Form("txtHr" & dr("OtCd")))
            Select Case dr("OtCd")
                Case "G1", "G2", "G3", "G4"
                    vAmt = vFactor * (vHrs / 2)
                    'Case "TARD", "UT"
                    'vAmt = IIf(IsDBNull(dr("OtPer")), 0, dr("OtPer")) * vHrs
                Case Else
                    vAmt = vFactor * vHrs * vRateHr
            End Select

            If vHrs <> 0 Then
                cmQry.CommandText = "insert into " & vTable & " (Emp_Cd,TranDate,TranCd,Hrs_Rendered,AmtConv,Reason,EffectivityDate) values ('" & _
                    vEmpid & "','" & Format(vDate, "yyyy/MM/dd") & "','" & dr("OtCd") & "'," & vHrs & "," & vAmt & ",'Edited','" & Format(vDate, "yyyy/MM/dd") & "')"

                cmQry.ExecuteNonQuery()
            End If
        Loop
        dr.Close()
        cm.Dispose()
        cmQry.Dispose()
        c.Close()
        vscript = "alert('Changes were successfully saved!'); window.close();"
    End Sub
End Class
