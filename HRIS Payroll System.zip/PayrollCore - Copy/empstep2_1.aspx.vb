Imports denaro
Partial Class empstep2_1
    Inherits System.Web.UI.Page

    Public vScript As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            vScript = "alert('Your login session has expired. Please login again.'); window.close();"
        End If
        If Not IsPostBack Then
            cmdPrev.Enabled = CanRun(Session("caption"), "41.1")
            If Not CanRun(Session("caption"), "41.2") Then
                Server.Transfer("empstep3.aspx")
                Exit Sub
            End If
            Session.Remove("oldval")
            Session.Remove("newval")
            Dim c As New SqlClient.SqlConnection(connStr)
            Dim dr As SqlClient.SqlDataReader
            Dim cm As New SqlClient.SqlCommand

            Try
                c.Open()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                c.Dispose()
                cm.Dispose()
                Exit Sub
            End Try

            lblCaption.Text = "Employee Master Information (3 of 6)"
            BuildCombo("select ReligionCd,Descr from hr_religion_ref order by Descr", cmbReligion, c)
            BuildCombo("select BloodType,Descr from hr_bloodtype_ref order by Descr", cmbBloodType, c)
            BuildCombo("select CountryCd,Descr from hr_country_ref order by Descr", cmbCountry, c)
            BuildCombo("select Citizen_Cd,Descr from hr_citizenship_ref order by Descr", cmbCitizenship, c)
            BuildCombo("select RegionCd,Descr from region_ref order by Descr", cmbRegion, c)

            cm.Connection = c
            cm.CommandText = "select Skills,Self_Trainings,Height,Weight,ReligionCd,DialectCd,LanguageCd," & _
                "BloodType,CountryCd,EmergencyContactPerson,CitizenCd,EmergencyContactNo,OtherInfo," & _
                "Spouse_Lname,Spouse_Fname,Spouse_Mname,Spouse_Occupation,Spouse_Emr,Spouse_Bus_Addr," & _
                "Spouse_Tel,Father_Lname,Father_Fname,Father_Mname,Mother_Lname,Mother_Fname,Mother_Mname, " & _
                "Emp_Fname,Emp_Lname,Emp_Mname,RegionCd,ProvCd,City,Zip from py_emp_master where Emp_Cd='" & Session("empid") & "'"
            Dim regncd As String = ""
            Dim provcd As String = ""
            Dim citycd As String = ""
            Dim zip As String = ""
            Try
                dr = cm.ExecuteReader
                If dr.Read Then
                    BuildList("select LanguageCd,Descr from hr_language_ref order by Descr", chkLanguage, _
                        IIf(IsDBNull(dr("LanguageCd")), "", dr("LanguageCd")), c)
                    BuildList("select DialectCd,Descr from hr_dialect_ref order by Descr", chkDialect, _
                        IIf(IsDBNull(dr("DialectCd")), "", dr("DialectCd")), c)
                    lblName.Text = dr("Emp_Lname") & ", " & dr("Emp_Fname") & " " & dr("Emp_Mname")
                    txtSkills.Text = IIf(IsDBNull(dr("Skills")), "", dr("Skills"))
                    txtTraining.Text = IIf(IsDBNull(dr("Self_Trainings")), "", dr("Self_Trainings"))
                    txtHeight.Text = IIf(IsDBNull(dr("Height")), 0, dr("Height"))
                    txtWeight.Text = IIf(IsDBNull(dr("Weight")), 0, dr("Weight"))
                    cmbReligion.SelectedValue = IIf(IsDBNull(dr("ReligionCd")), "", dr("ReligionCd")) 'PointData("select ReligionCd,Descr from hr_religion_ref where " & _
                    '"ReligionCd='" & IIf(IsDBNull(dr("ReligionCd")), "", dr("ReligionCd")) & "'")
                    cmbBloodType.SelectedValue = IIf(IsDBNull(dr("BloodType")), "", dr("BloodType")) 'PointData("select BloodType,Descr from hr_bloodtype_ref where " & _
                    '"BloodType='" & IIf(IsDBNull(dr("BloodType")), "", dr("BloodType")) & "'")
                    cmbCountry.SelectedValue = IIf(IsDBNull(dr("CountryCd")), "", dr("CountryCd"))  'PointData("select CountryCd,Descr from hr_country_ref where " & _
                    '"CountryCd='" & IIf(IsDBNull(dr("CountryCd")), "", dr("CountryCd")) & "'")
                    cmbCitizenship.SelectedValue = IIf(IsDBNull(dr("CitizenCd")), "", dr("CitizenCd")) 'PointData("select Citizen_Cd,Descr from hr_citizenship_ref " & _
                    '"where Citizen_Cd='" & IIf(IsDBNull(dr("CitizenCd")), "", dr("CitizenCd")) & "'")
                    txtContactName.Text = IIf(IsDBNull(dr("EmergencyContactPerson")), "", dr("EmergencyContactPerson"))
                    txtContactNo.Text = IIf(IsDBNull(dr("EmergencyContactNo")), "", dr("EmergencyContactNo"))
                    txtOtherInfo.Text = IIf(IsDBNull(dr("OtherInfo")), "", dr("OtherInfo"))
                    txtSpouseLName.Text = IIf(IsDBNull(dr("Spouse_Lname")), "", dr("Spouse_Lname"))
                    txtSpouseFName.Text = IIf(IsDBNull(dr("Spouse_Fname")), "", dr("Spouse_Fname"))
                    txtSpouseMName.Text = IIf(IsDBNull(dr("Spouse_Mname")), "", dr("Spouse_Mname"))
                    txtSpouseOccupation.Text = IIf(IsDBNull(dr("Spouse_Occupation")), "", dr("Spouse_Occupation"))
                    txtSpouseEmployer.Text = IIf(IsDBNull(dr("Spouse_Emr")), "", dr("Spouse_Emr"))
                    txtSpouseAddr.Text = IIf(IsDBNull(dr("Spouse_Bus_Addr")), "", dr("Spouse_Bus_Addr"))
                    txtSpouseTel.Text = IIf(IsDBNull(dr("Spouse_Tel")), "", dr("Spouse_Tel"))
                    txtFatherLName.Text = IIf(IsDBNull(dr("Father_Lname")), "", dr("Father_Lname"))
                    txtFatherFName.Text = IIf(IsDBNull(dr("Father_Fname")), "", dr("Father_Fname"))
                    txtFatherMName.Text = IIf(IsDBNull(dr("Father_Mname")), "", dr("Father_Mname"))
                    txtMotherLName.Text = IIf(IsDBNull(dr("Mother_Lname")), "", dr("Mother_Lname"))
                    txtMotherFName.Text = IIf(IsDBNull(dr("Mother_Fname")), "", dr("Mother_Fname"))
                    txtMotherMName.Text = IIf(IsDBNull(dr("Mother_Mname")), "", dr("Mother_Mname"))
                    regncd = IIf(IsDBNull(dr("RegionCd")), "", dr("RegionCd"))
                    provcd = IIf(IsDBNull(dr("ProvCd")), "", dr("ProvCd"))
                    citycd = IIf(IsDBNull(dr("City")), "", dr("City"))
                    zip = IIf(IsDBNull(dr("Zip")), "", dr("Zip"))
                    BuildCombo("select ProvCd,Descr from province_ref where RegionCd='" & regncd & "'", cmbProvince, c)
                    BuildCombo("select CityCd,Descr from city_ref where RegionCd='" & regncd & "' and ProvCd='" & provcd _
                        & "' order by Descr", cmbCity, c)
                    BuildCombo("select ZipCd,ZipCd+'=>'+AreaNm as Descr from zip_ref where ZipCd <> '' order by ZipCd", cmbZip, c)

                    Session("oldval") = "Languages Spoken=" & IIf(IsDBNull(dr("LanguageCd")), "", dr("LanguageCd")) & _
                        "|Dialects Spoken=" & IIf(IsDBNull(dr("DialectCd")), "", dr("DialectCd")) & _
                        "|Skills=" & txtSkills.Text & _
                        "|Training=" & txtTraining.Text & _
                        "|Height=" & txtHeight.Text & _
                        "|Weight=" & txtWeight.Text & _
                        "|Religion=" & IIf(IsDBNull(dr("ReligionCd")), "", dr("ReligionCd")) & _
                        "|Blood Type=" & IIf(IsDBNull(dr("BloodType")), "", dr("BloodType")) & _
                        "|County=" & IIf(IsDBNull(dr("CountryCd")), "", dr("CountryCd")) & _
                        "|Citizenship=" & IIf(IsDBNull(dr("CitizenCd")), "", dr("CitizenCd")) & _
                        "|Contact Person=" & txtContactName.Text & _
                        "|Contact Number=" & txtContactNo.Text & _
                        "|Other Information=" & txtOtherInfo.Text & _
                        "|Spouse Last Name=" & txtSpouseLName.Text & _
                        "|Spouse First Name=" & txtSpouseFName.Text & _
                        "|Spouse Middle Name=" & txtSpouseMName.Text & _
                        "|Spouse Occupation=" & txtSpouseOccupation.Text & _
                        "|Spouse Business Name=" & txtSpouseEmployer.Text & _
                        "|Spouse Address=" & txtSpouseAddr.Text & _
                        "|Spouse Telephone=" & txtSpouseTel.Text & _
                        "|Father Last Name=" & txtFatherLName.Text & _
                        "|Father First Name=" & txtFatherFName.Text & _
                        "|Father Middle Name=" & txtFatherMName.Text & _
                        "|Mother Last Name=" & txtMotherLName.Text & _
                        "|Mother First Name=" & txtMotherFName.Text & _
                        "|Region=" & IIf(IsDBNull(dr("RegionCd")), "", dr("RegionCd")) & _
                        "|Province=" & IIf(IsDBNull(dr("ProvCd")), "", dr("ProvCd")) & _
                        "|City=" & IIf(IsDBNull(dr("City")), "", dr("City")) & _
                        "|Zip=" & IIf(IsDBNull(dr("Zip")), "", dr("Zip")) & _
                        "|Mother Middle Name=" & txtMotherMName.Text

                    cmbRegion.SelectedValue = regncd
                    cmbProvince.SelectedValue = provcd
                    cmbCity.SelectedValue = citycd
                    cmbZip.SelectedValue = zip
                End If
                dr.Close()
            Catch ex As sqlclient.sqlexception
                vScript = "alert('Error occurred while trying to retrieve record. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            Finally
                c.Close()
                cm.Dispose()
                c.Dispose()
            End Try
        End If
    End Sub
    Private Sub BuildList(ByVal pSQl As String, ByVal pList As System.Web.UI.WebControls.CheckBoxList, _
        ByVal pValue As String, ByRef c As SqlClient.SqlConnection)

        'Dim c As New SqlClient.SqlConnection
        Dim cm As New SqlClient.SqlCommand
        Dim dr As SqlClient.SqlDataReader
        Dim vList As New System.Web.UI.WebControls.ListItem
        Dim iCtr As Integer = 0
        'c.ConnectionString = connStr
        'c.Open()
        cm.Connection = c
        cm.CommandText = pSQl
        Try
            dr = cm.ExecuteReader
            pList.Items.Clear()
            Do While dr.Read
                'vList.Text = dr(1)
                'vList.Value = dr(0)
                'pList.Items.Add(vList)
                pList.Items.Add(dr(0) & "=>" & dr(1))
                If pValue.IndexOf(dr(0)) > -1 Then
                    pList.Items(pList.Items.Count - 1).Selected = True
                End If
                iCtr += 1
            Loop
            dr.Close()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error building list. Error is: " & ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            cm.Dispose()
        End Try
    End Sub
    Protected Sub cmdCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        Session.Remove("empid")
        Session.Remove("oldval")
        Session.Remove("newval")
        vscript = "window.close();"
    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim vLangList As String = ""
        Dim vDialectList As String = ""
        Dim iCtr As Integer = 0

        For iCtr = 0 To chkLanguage.Items.Count - 1
            If chkLanguage.Items(iCtr).Selected Then
                vLangList += ExtractData(chkLanguage.Items(iCtr).Text) & ","
            End If
        Next iCtr
        If vLangList <> "" Then
            vLangList = vLangList.Substring(0, vLangList.Length - 1)
        End If

        For iCtr = 0 To chkDialect.Items.Count - 1
            If chkDialect.Items(iCtr).Selected Then
                vDialectList += ExtractData(chkDialect.Items(iCtr).Text) & ","
            End If
        Next iCtr
        If vDialectList <> "" Then
            vDialectList = vDialectList.Substring(0, vDialectList.Length - 1)
        End If

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace("'", "").Replace(vbCrLf, "") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        cm.Connection = c
        cm.CommandText = "update py_emp_master set Skills='" & txtSkills.Text & _
            "',Self_Trainings='" & txtTraining.Text & _
            "',Height=" & txtHeight.Text & _
            ",Weight=" & txtWeight.Text & _
            ",ReligionCd='" & cmbReligion.SelectedValue & _
            "',BloodType='" & cmbBloodType.SelectedValue & _
            "',CountryCd='" & cmbCountry.SelectedValue & _
            "',CitizenCd='" & cmbCitizenship.SelectedValue & _
            "',LanguageCd='" & vLangList & _
            "',DialectCd='" & vDialectList & _
            "',EmergencyContactPerson='" & txtContactName.Text & _
            "',EmergencyContactNo='" & txtContactNo.Text & _
            "',OtherInfo='" & txtOtherInfo.Text & _
            "',Spouse_Lname='" & txtSpouseLName.Text & _
            "',Spouse_Fname='" & txtSpouseFName.Text & _
            "',Spouse_Mname='" & txtSpouseMName.Text & _
            "',Spouse_Occupation='" & txtSpouseOccupation.Text & _
            "',Spouse_Emr='" & txtSpouseEmployer.Text & _
            "',Spouse_Bus_Addr='" & txtSpouseAddr.Text & _
            "',Spouse_Tel='" & txtSpouseTel.Text & _
            "',Father_Lname='" & txtFatherLName.Text & _
            "',Father_Fname='" & txtFatherFName.Text & _
            "',Father_Mname='" & txtFatherMName.Text & _
            "',Mother_Lname='" & txtMotherLName.Text & _
            "',Mother_Fname='" & txtMotherFName.Text & _
            "',Mother_Mname='" & txtMotherMName.Text & _
            "',RegionCd='" & cmbRegion.SelectedValue & "',ProvCd='" & cmbProvince.SelectedValue & _
            "',City='" & cmbCity.SelectedValue & "',Zip='" & cmbZip.SelectedValue & _
            "',  Modified_Date='" & Format(Now, "yyyy/MM/dd HH:mm:ss") & _
            "',Modified_By='" & Session("uid") & _
            "' where Emp_Cd='" & Session("empid") & "'"
        Try
            cm.ExecuteNonQuery()
            Session("newval") = "Languages Spoken=" & vLangList & _
                "|Dialects Spoken=" & vDialectList & _
                "|Skills=" & txtSkills.Text & _
                "|Training=" & txtTraining.Text & _
                "|Height=" & txtHeight.Text & _
                "|Weight=" & txtWeight.Text & _
                "|Religion=" & cmbReligion.SelectedValue & _
                "|Blood Type=" & cmbBloodType.SelectedValue & _
                "|County=" & cmbCountry.SelectedValue & _
                "|Citizenship=" & cmbCitizenship.SelectedValue & _
                "|Contact Person=" & txtContactName.Text & _
                "|Contact Number=" & txtContactNo.Text & _
                "|Other Information=" & txtOtherInfo.Text & _
                "|Spouse Last Name=" & txtSpouseLName.Text & _
                "|Spouse First Name=" & txtSpouseFName.Text & _
                "|Spouse Middle Name=" & txtSpouseMName.Text & _
                "|Spouse Occupation=" & txtSpouseOccupation.Text & _
                "|Spouse Business Name=" & txtSpouseEmployer.Text & _
                "|Spouse Address=" & txtSpouseAddr.Text & _
                "|Spouse Telephone=" & txtSpouseTel.Text & _
                "|Father Last Name=" & txtFatherLName.Text & _
                "|Father First Name=" & txtFatherFName.Text & _
                "|Father Middle Name=" & txtFatherMName.Text & _
                "|Mother Last Name=" & txtMotherLName.Text & _
                "|Mother First Name=" & txtMotherFName.Text & _
                "|Region=" & cmbRegion.SelectedValue & _
                "|Province=" & cmbProvince.SelectedValue & _
                "|City=" & cmbCity.SelectedValue & _
                "|Zip=" & cmbZip.SelectedValue & _
                "|Mother Middle Name=" & txtMotherMName.Text
            EventLog(Session("uid"), Request.ServerVariables("REMOTE_ADDR"), "EDIT", Session("oldval"), Session("newval"), _
                "Employee ID: " & Session("empid") & " was added/edited", "201 Profile", c)
            Session.Remove("oldval")
            Session.Remove("newval")
            Server.Transfer("empstep3.aspx")
        Catch ex As sqlclient.sqlexception
            vScript = "alert('Error occurred while trying to save changes. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            cm.Dispose()
            c.Dispose()
        End Try
    End Sub
    Protected Sub cmbRegion_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbRegion.SelectedIndexChanged
        BuildCombo("select ProvCd,Descr from province_ref where RegionCd='" & cmbRegion.SelectedValue & "'", cmbProvince)
        cmbCity.Items.Clear()
        cmbZip.Items.Clear()
        If cmbProvince.Items.Count = 1 Then
            cmbProvince_SelectedIndexChanged(sender, e)
        End If
    End Sub

    Protected Sub cmbProvince_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbProvince.SelectedIndexChanged
        BuildCombo("select CityCd,Descr from city_ref where RegionCd='" & cmbRegion.SelectedValue & _
                    "' and ProvCd='" & cmbProvince.SelectedValue & "' order by Descr", cmbCity)
        cmbZip.Items.Clear()
    End Sub

    Protected Sub cmbCity_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbCity.SelectedIndexChanged
        BuildCombo("select ZipCd,ZipCd+'=>'+AreaNm as Descr from zip_ref where RegionCd='" & cmbRegion.SelectedValue & _
                    "' and ProvCd='" & cmbProvince.SelectedValue & "' and CityCd='" & cmbCity.SelectedValue & _
                    "' order by ZipCd", cmbZip)
    End Sub

    Protected Sub cmdPrev_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdPrev.Click
        Session.Remove("oldval")
        Session.Remove("newval")
        Server.Transfer("empstep2.aspx")
    End Sub

    Protected Sub cmbQuickNavi_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbQuickNavi.SelectedIndexChanged
        Session.Remove("oldval")
        Session.Remove("newval")
        Server.Transfer(cmbQuickNavi.SelectedValue)
    End Sub
End Class
