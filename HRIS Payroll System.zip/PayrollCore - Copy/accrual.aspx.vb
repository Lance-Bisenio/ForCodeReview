﻿Imports denaro.fis
Partial Class accrual
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Public vData As String = ""
    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If

        If Not CanRun(Session("caption"), Request.Item("id")) Then
            Session("denied") = "1"
            Server.Transfer("main.aspx")
            Exit Sub
        End If

        If Not IsPostBack Then
            lblYear.Text = Now.Year

            BuildCombo("select Rc_Cd,Descr from rc where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='rc' and Property_Value=Rc_Cd) order by Descr", cmbRC)
            BuildCombo("select AgencyCd,AgencyName from agency where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='agency' and Property_Value=AgencyCd) order by AgencyName", cmbOfc)
            BuildCombo("select Div_Cd,Descr from hr_div_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='division' and Property_Value=Div_Cd) order by Descr", cmbDiv)
            BuildCombo("select Dept_Cd,Descr from hr_dept_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='department' and Property_Value=Dept_Cd) order by Descr", cmbDept)
            BuildCombo("select Section_Cd,Descr from hr_section_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='section' and Property_Value=Section_Cd) order by Descr", cmbSection)
            BuildCombo("select Unit_Cd,Descr from hr_unit_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='unit' and Property_Value=Unit_Cd) order by Descr", cmbUnit)
            BuildCombo("select EmploymentType,Descr from hr_employment_type where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='employmenttype' and Property_Value=EmploymentType) order by Descr", cmbEmpType)
            BuildCombo("select Pay_Cd, Payment from py_pay_mode order by Payment", cmbPayMode)

            cmbRC.Items.Add("All")
            cmbRC.SelectedValue = "All"
            cmbOfc.Items.Add("All")
            cmbOfc.SelectedValue = "All"
            cmbDiv.Items.Add("All")
            cmbDiv.SelectedValue = "All"
            cmbDept.Items.Add("All")
            cmbDept.SelectedValue = "All"
            cmbSection.Items.Add("All")
            cmbSection.SelectedValue = "All"
            cmbUnit.Items.Add("All")
            cmbUnit.SelectedValue = "All"
            cmbEmpType.Items.Add("All")
            cmbEmpType.SelectedValue = "All"
            cmbPayMode.Items.Add("All")
            cmbPayMode.SelectedValue = "All"
        End If
    End Sub

    Protected Sub cmdReturn_Click(sender As Object, e As EventArgs) Handles cmdReturn.Click
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub cmdGenerate_Click(sender As Object, e As EventArgs) Handles cmdGenerate.Click
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cmRef As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim rsRef As SqlClient.SqlDataReader
        Dim vFilter As String = ""
        Dim vDateHired As String = ""
        Dim vYrsOfSvc As Decimal = 0
        Dim vCredit As Decimal = 0
        Dim vCurrDailyRate As Decimal = 0
        Dim vMonthlyCredit As Decimal = 0
        Dim vMonthlyUsed(12) As Decimal
        Dim vMonthlyDailyRate(12) As Decimal
        Dim vTotalAmtCredit As Decimal = 0
        Dim vTotalAmtUsed As Decimal = 0
        Dim vTotalUsed As Decimal = 0
        Dim vClass As String = "odd"
        Dim iCtr As Integer

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        cm.Connection = c
        cmRef.Connection = c

        Select Case Val(cmbStatus.SelectedValue)
            Case 1  'active employees only
                vFilter += " where Date_Resign is null AND Date_Retired IS NULL AND DateHold IS NULL AND DateDismissed IS NULL"
            Case 0  'inactive employees only
                vFilter += " where (Date_Resign is not null OR Date_Retired IS NOT NULL OR DateHold IS NOT NULL Or DateDismissed IS NOT NULL)"
        End Select

        If rdoGroup.SelectedValue <> "BOTH" Then
            vFilter += " and GroupCd='" & rdoGroup.SelectedValue & "' "
        End If

        If cmbRC.SelectedValue <> "All" Then   'filter by cost center
            vFilter += " and Rc_Cd='" & cmbRC.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='rc' and Property_Value=Rc_Cd) "
        End If

        If cmbOfc.SelectedValue <> "All" Then        'filter by office/agency
            vFilter += " and Agency_Cd='" & cmbOfc.SelectedValue & "' "
        Else
            vFilter += "  and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='agency' and Property_Value=Agency_Cd) "
        End If

        If cmbDiv.SelectedValue <> "All" Then      'filter by division
            vFilter += " and Divcd='" & cmbDiv.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='division' and Property_Value=DivCd) "
        End If

        If cmbDept.SelectedValue <> "All" Then  'filter by departments
            vFilter += " and DeptCd='" & cmbDept.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='department' and Property_Value=DeptCd) "
        End If

        If cmbSection.SelectedValue <> "All" Then 'filter by section
            vFilter += " and SectionCd='" & cmbSection.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='section' and Property_Value=SectionCd) "
        End If

        If cmbUnit.SelectedValue <> "All" Then  'filter by units
            vFilter += " and UnitCd='" & cmbUnit.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='unit' and Property_Value=UnitCd) "
        End If

        If cmbEmpType.SelectedValue <> "All" Then 'filter by employment types
            vFilter += " and EmploymentType='" & cmbEmpType.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='employmenttype' and Property_Value=EmploymentType) "
        End If

        If cmbPayMode.SelectedValue <> "All" Then 'filter by payment mode
            vFilter += " and Pay_Cd='" & cmbPayMode.SelectedValue & "' "
        End If

        cm.CommandText = "select Emp_Cd,Emp_Lname,Emp_Fname,EmploymentType," & _
            "Start_Date,Rate_Day from py_emp_master " & vFilter & _
            " order by Emp_Lname,Emp_Fname"

        vData = ""
        Try
            rs = cm.ExecuteReader
            Do While rs.Read
                vDateHired = "&nbsp;"
                vYrsOfSvc = 0
                vCurrDailyRate = rs("Rate_Day")

                If Not IsDBNull(rs("Start_Date")) Then
                    vDateHired = Format(rs("Start_Date"), "MM/dd/yyyy")
                    vYrsOfSvc = Now.Year - Year(rs("Start_Date"))
                End If

                'get credits for VL
                vCredit = 0
                cmRef.CommandText = "select Credits from py_leave_table where LeaveCd='VL' " & _
                    "and EmploymentType='" & rs("EmploymentType") & "' and " & _
                    vYrsOfSvc & " between YearFrom and YearTo"

                rsRef = cmRef.ExecuteReader
                If rsRef.Read Then
                    vCredit = rsRef("Credits")
                End If
                rsRef.Close()
                vMonthlyCredit = vCredit / 12


                vTotalUsed = 0
                vTotalAmtCredit = 0
                vTotalAmtUsed = 0
                For iCtr = 1 To 12
                    vMonthlyUsed(iCtr - 1) = 0
                    vMonthlyDailyRate(iCtr - 1) = Math.Round(vCurrDailyRate, 2) 'set default to current daily rate 

                    'get monthly daily rate from history
                    cmRef.CommandText = "select Rate_Day from py_emp_salary_hist where YearCd=" & _
                        Now.Year & " and Emp_Cd='" & rs("Emp_Cd") & "' and Month=" & iCtr
                    rsRef = cmRef.ExecuteReader
                    If rsRef.Read Then
                        vMonthlyDailyRate(iCtr - 1) = Math.Round(rsRef("Rate_Day"), 2)
                    End If
                    rsRef.Close()

                    'now get used VL for each month of the current year 
                    cmRef.CommandText = "select sum(DaysLeave) from hr_leave_application where Void=0 " & _
                        " and LeaveCd='VL' and Emp_Cd='" & rs("Emp_Cd") & "' and month(StartDate)=" & iCtr & _
                        " and Year(StartDate)=" & Now.Year & _
                        " and ((ApprovedBy is not null and DateApproved is not null and RecommendedBy is null and NotedBy is null) or " & _
                        "(ApprovedBy is not null and DateApproved is not null and RecommendedBy is not null and DateRecommended is not null and NotedBy is null) or " & _
                        "(ApprovedBy is not null and DateApproved is not null and RecommendedBy is not null and dateRecommended is not null and NotedBy is not null and DateNoted is not null))"
                    rsRef = cmRef.ExecuteReader
                    If rsRef.Read Then
                        If Not IsDBNull(rsRef(0)) Then
                            vMonthlyUsed(iCtr - 1) = rsRef(0)
                        End If
                    End If
                    rsRef.Close()
                    vTotalAmtCredit += vMonthlyCredit * vMonthlyDailyRate(iCtr - 1)
                    vTotalAmtUsed += vMonthlyUsed(iCtr - 1) * vMonthlyDailyRate(iCtr - 1)
                    vTotalUsed += vMonthlyUsed(iCtr - 1)
                Next

                vData += "<tr class='" & vClass & "'>" & _
                    "<td class='labelL'>" & rs("Emp_Cd") & "</td>" & _
                    "<td class='labelL'>" & rs("Emp_Lname") & ", " & rs("Emp_Fname") & "</td>" & _
                    "<td class='labelC'>VL</td>" & _
                    "<td class='labelR'>" & vDateHired & "</td>" & _
                    "<td class='labelR'>" & vYrsOfSvc & "</td>"

                'dump data from january to december
                For iCtr = 0 To 11
                    vData += "<td class='colodd'>" & Format(vMonthlyCredit, "#0.00") & "</td>" & _
                        "<td class='colodd'>" & Format(vMonthlyCredit * vMonthlyDailyRate(iCtr), "###,##0.00") & "</td>" & _
                        "<td class='coleven'>" & Format(vMonthlyUsed(iCtr), "#0.00") & "</td>" & _
                        "<td class='coleven'>" & Format(vMonthlyUsed(iCtr) * vMonthlyDailyRate(iCtr), "###,##0.00") & "</td>" & _
                        "<td class='labelR'>" & Format(vMonthlyCredit - vMonthlyUsed(iCtr), "#0.00") & "</td>"
                Next
                'dump totals column
                vData += "<td class='colodd'>" & Format(vCredit, "00.00") & "</td>" & _
                    "<td class='colodd'>" & Format(vTotalAmtCredit, "###,##0.00") & "</td>" & _
                    "<td class='coleven'>" & Format(vTotalUsed, "#0.00") & "</td>" & _
                    "<td class='coleven'>" & Format(vTotalAmtUsed, "###,##0.00") & "</td>" & _
                    "<td class='labelR'>" & Format(vCredit - vTotalUsed, "#0.00") & "</td></tr>"

                'get credits for SL
                vCredit = 0
                cmRef.CommandText = "select Credits from py_leave_table where LeaveCd='SL' " & _
                    "and EmploymentType='" & rs("EmploymentType") & "' and " & _
                    vYrsOfSvc & " between YearFrom and YearTo"

                rsRef = cmRef.ExecuteReader
                If rsRef.Read Then
                    vCredit = rsRef("Credits")
                End If
                rsRef.Close()
                vMonthlyCredit = vCredit / 12

                vTotalUsed = 0
                vTotalAmtCredit = 0
                vTotalAmtUsed = 0

                For iCtr = 1 To 12
                    vMonthlyUsed(iCtr - 1) = 0
                    vMonthlyDailyRate(iCtr - 1) = Math.Round(vCurrDailyRate, 2) 'set default to current daily rate 

                    'get monthly daily rate from history
                    cmRef.CommandText = "select Rate_Day from py_emp_salary_hist where YearCd=" & _
                        Now.Year & " and Emp_Cd='" & rs("Emp_Cd") & "' and Month=" & iCtr
                    rsRef = cmRef.ExecuteReader
                    If rsRef.Read Then
                        vMonthlyDailyRate(iCtr - 1) = Math.Round(rsRef("Rate_Day"), 2)
                    End If
                    rsRef.Close()

                    'now get used SL for each month of the current year 
                    cmRef.CommandText = "select sum(DaysLeave) from hr_leave_application where Void=0 " & _
                        " and LeaveCd='SL' and Emp_Cd='" & rs("Emp_Cd") & "' and month(StartDate)=" & iCtr & _
                        " and Year(StartDate)=" & Now.Year & _
                        " and ((ApprovedBy is not null and DateApproved is not null and RecommendedBy is null and NotedBy is null) or " & _
                        "(ApprovedBy is not null and DateApproved is not null and RecommendedBy is not null and DateRecommended is not null and NotedBy is null) or " & _
                        "(ApprovedBy is not null and DateApproved is not null and RecommendedBy is not null and dateRecommended is not null and NotedBy is not null and DateNoted is not null))"
                    rsRef = cmRef.ExecuteReader
                    If rsRef.Read Then
                        If Not IsDBNull(rsRef(0)) Then
                            vMonthlyUsed(iCtr - 1) = rsRef(0)
                        End If
                    End If
                    rsRef.Close()
                    vTotalAmtCredit += vMonthlyCredit * vMonthlyDailyRate(iCtr - 1)
                    vTotalAmtUsed += vMonthlyUsed(iCtr - 1) * vMonthlyDailyRate(iCtr - 1)
                    vTotalUsed += vMonthlyUsed(iCtr - 1)
                Next

                vData += "<tr class='" & vClass & "'>" & _
                    "<td class='labelL'>&nbsp;</td>" & _
                    "<td class='labelL'>&nbsp;</td>" & _
                    "<td class='labelC'>SL</td>" & _
                    "<td class='labelR'>&nbsp;</td>" & _
                    "<td class='labelR'>&nbsp;</td>"

                'dump data from january to december
                For iCtr = 0 To 11
                    vData += "<td class='colodd'>" & Format(vMonthlyCredit, "#0.00") & "</td>" & _
                        "<td class='colodd'>" & Format(vMonthlyCredit * vMonthlyDailyRate(iCtr), "###,##0.00") & "</td>" & _
                        "<td class='coleven'>" & Format(vMonthlyUsed(iCtr), "#0.00") & "</td>" & _
                        "<td class='coleven'>" & Format(vMonthlyUsed(iCtr) * vMonthlyDailyRate(iCtr), "###,##0.00") & "</td>" & _
                        "<td class='labelR'>" & Format(vMonthlyCredit - vMonthlyUsed(iCtr), "#0.00") & "</td>"
                Next
                'dump totals column
                vData += "<td class='colodd'>" & Format(vCredit, "00.00") & "</td>" & _
                    "<td class='colodd'>" & Format(vTotalAmtCredit, "###,##0.00") & "</td>" & _
                    "<td class='coleven'>" & Format(vTotalUsed, "#0.00") & "</td>" & _
                    "<td class='coleven'>" & Format(vTotalAmtUsed, "###,##0.00") & "</td>" & _
                    "<td class='labelR'>" & Format(vCredit - vTotalUsed, "#0.00") & "</td></tr>"

                vClass = IIf(vClass = "odd", "even", "odd")
            Loop
            rs.Close()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to retrieve Employee records. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            c.Dispose()
            cm.Dispose()
        End Try
    End Sub
End Class
