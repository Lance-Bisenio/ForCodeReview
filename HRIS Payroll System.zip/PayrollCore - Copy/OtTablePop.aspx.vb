Imports denaro.fis
Partial Class OtTablePop
    Inherits System.Web.UI.Page
    Public vScript As String
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            vScript = "window.close();"
            Exit Sub
        End If
        'txtOtType.Text = Session("OtType")
        'txtDesc.Text = Session("Desc")
        txtOtType.Text = Request.Item("t")
        txtDesc.Text = Request.Item("d")
        Dim vMode As String = Request.Item("m")
        If Not IsPostBack Then
            Dim c As New sqlclient.sqlconnection(connStr)
            Dim cm As New sqlclient.sqlcommand
            Dim rs As sqlclient.sqldatareader

            BuildCombo("select EmploymentType, Descr from hr_employment_type WHERE EmploymentType != '99'", cmbRank)

            c.Open()
            cm.Connection = c

            If vMode = "edit" Then
                'cmbRank.SelectedValue = Session("Rank")
                cmbRank.SelectedValue = Request.Item("r").Replace("|", "&")

                cm.CommandText = "SELECT * FROM py_ot_ref_dtl WHERE OtCd = '" & txtOtType.Text & _
                    "' AND EmploymentType = '" & cmbRank.SelectedValue & "'"
                rs = cm.ExecuteReader

                If rs.Read Then
                    txtFactor.Text = IIf(IsDBNull(rs("Factor")), 0, rs("Factor"))
                    rdoMeasure.SelectedValue = rs("UOM")
                End If
                rs.Close()
            End If

            c.Close()
            c.Dispose()
            cm.Dispose()

        End If
    End Sub

    Protected Sub cmdClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdClose.Click
        vScript = "window.close();"
    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click

        Dim c As New sqlclient.sqlconnection(connStr)
        Dim cm As New sqlclient.sqlcommand
        Dim rs As sqlclient.sqldatareader
        Dim vExist As Boolean = False

        c.Open()
        cm.Connection = c

        If Request.Item("m") = "edit" Then

            cm.CommandText = "UPDATE py_ot_ref_dtl SET Factor = '" & _
                Val(txtFactor.Text) / IIf(rdoMeasure.SelectedValue = 0, 100, 1) & _
                "', EmploymentType='" & cmbRank.SelectedValue & "',UOM=" & rdoMeasure.SelectedValue & _
                " WHERE EmploymentType = '" & Request.Item("r").Replace("|", "&") & "' AND OtCd = '" & txtOtType.Text & "'"

            Try
                cm.ExecuteNonQuery()
                vScript = "alert('Record successfully updated'); window.opener.form1.submit(); window.close();"
            Catch ex As sqlclient.sqlException
                vScript = "alert(""Updating failed due to " & ex.Message.Replace(vbCrLf, " ") & """);"
                Exit Sub
            End Try

        ElseIf Request.Item("m") = "add" Then
            cm.CommandText = "SELECT 1 FROM py_ot_ref_dtl WHERE EmploymentType = '" & cmbRank.SelectedValue & "' AND OtCd = '" & txtOtType.Text & "'"
            rs = cm.ExecuteReader
            vExist = rs.HasRows
            rs.Close()

            If vExist Then
                vScript = "alert('Sorry cannot add the same Rank and OT Code.');"
                Exit Sub
            Else
                cm.CommandText = "INSERT INTO py_ot_ref_dtl (OtCd, EmploymentType, Factor, UOM) VALUES " & _
                     "('" & txtOtType.Text & "', '" & cmbRank.SelectedValue & "', '" & _
                     Val(txtFactor.Text) / IIf(rdoMeasure.SelectedValue = 0, 100, 1) & _
                     "'," & rdoMeasure.SelectedValue & ")"
                Try
                    cm.ExecuteNonQuery()
                    vScript = "alert('Record successfully created'); window.opener.form1.submit(); self.close();"
                Catch ex As sqlclient.sqlException
                    vScript = "alert('Creating new record failed due to " & ex.Message.Replace("'", "") & "');"
                    Exit Sub
                End Try
            End If

        End If
        c.Close()
        c.Dispose()
        cm.Dispose()

    End Sub
End Class
