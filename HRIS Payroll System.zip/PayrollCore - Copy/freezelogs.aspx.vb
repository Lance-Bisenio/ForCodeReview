Imports denaro.fis
Partial Class freezelogs
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Public vList As String = ""

    Public HOSTSERVER As String = System.Configuration.ConfigurationManager.AppSettings.Get("hostserver")
    Public HOMEPAGE As String = System.Configuration.ConfigurationManager.AppSettings.Get("homepage")
    Public HREMAIL As String = System.Configuration.ConfigurationManager.AppSettings.Get("hremail")
    Public HOSTNAME As String = System.Configuration.ConfigurationManager.AppSettings.Get("hostname")
    Public FROMEMAIL As String = System.Configuration.ConfigurationManager.AppSettings.Get("fromemail")
    Public FROMNAME As String = System.Configuration.ConfigurationManager.AppSettings.Get("fromname")
    Public PORT As Integer = Val(System.Configuration.ConfigurationManager.AppSettings.Get("port"))

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Session("returnaddr") = "batchgrace.aspx"
            Server.Transfer("index.aspx")
            Exit Sub
        End If
        If Not IsPostBack Then
            Dim iCtr As Integer
            If Not CanRun(Session("caption"), Request.Item("id")) Then
                Session("denied") = "1"
                Server.Transfer("main.aspx")
                Exit Sub
            End If

            lblCaption.Text = "Freeze Logs"
            For iCtr = 1 To 31      'add days
                cmbDayFr.Items.Add(iCtr)
                cmbDayTo.Items.Add(iCtr)
            Next iCtr
            For iCtr = 1980 To 2030 'add year
                cmbYrFr.Items.Add(iCtr)
                cmbYrTo.Items.Add(iCtr)
            Next iCtr
            'now set the default values
            cmbMonthFr.SelectedValue = Now.Month
            cmbMonthTo.SelectedValue = Now.Month
            cmbDayFr.SelectedValue = 1
            cmbDayTo.SelectedValue = Now.Day
            cmbYrFr.SelectedValue = Now.Year
            cmbYrTo.SelectedValue = Now.Year

            BuildCombo("select Rc_Cd,Descr from rc where Rc_Cd in ('" & _
                Session("rclist").ToString.Replace(",", "','") & "') ORDER BY Descr", cmbRC)
            cmbRC.Items.Add(New ListItem("All", "*"))
            cmbRC.SelectedValue = "*"
            BuildCombo("select AgencyCd,AgencyName from agency where AgencyCd in ('" & _
                Session("agencylist").ToString.Replace(",", "','") & "')  ORDER BY AgencyName", cmbOfc)
            cmbOfc.Items.Add(New ListItem("All", "*"))
            cmbOfc.SelectedValue = "*"
            BuildCombo("select Div_Cd,Descr from hr_div_ref where Div_Cd in ('" & _
                Session("divlist").ToString.Replace(",", "','") & "')  ORDER BY Descr", cmbDiv)
            cmbDiv.Items.Add(New ListItem("All", "*"))
            cmbDiv.SelectedValue = "*"
            BuildCombo("select Dept_Cd,Descr from hr_dept_ref where Dept_Cd in ('" & _
                Session("deptlist").ToString.Replace(",", "','") & "')  ORDER BY Descr", cmbDept)
            cmbDept.Items.Add(New ListItem("All", "*"))
            cmbDept.SelectedValue = "*"
            BuildCombo("select Section_Cd,Descr from hr_section_ref where Section_Cd in ('" & _
                Session("sectionlist").ToString.Replace(",", "','") & "')  ORDER BY Descr", cmbSection)
            cmbSection.Items.Add(New ListItem("All", "*"))
            cmbSection.SelectedValue = "*"
            BuildCombo("select Unit_Cd,Descr from hr_unit_ref where Unit_Cd in ('" & _
                Session("unitlist").ToString.Replace(",", "','") & "')  ORDER BY Descr", cmbUnit)
            cmbUnit.Items.Add(New ListItem("All", "*"))
            cmbUnit.SelectedValue = "*"
            BuildCombo("select EmploymentType,Descr from hr_employment_type where EmploymentType in ('" & _
                Session("typelist").ToString.Replace(",", "','") & "')  ORDER BY Descr", cmbSecurity)
            cmbSecurity.Items.Add(New ListItem("All", "*"))
            cmbSecurity.SelectedValue = "*"
            DataRefresh()
            getNextCutOff()

        End If
    End Sub

    Private Sub DataRefresh()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim da As New SqlClient.SqlDataAdapter
        Dim ds As New DataSet

        Try
            da = New SqlClient.SqlDataAdapter("select * from py_cutoff_frozen", c)
            da.Fill(ds, "freeze")
            tblFreeze.DataSource = ds.Tables("freeze")
            tblFreeze.DataBind()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to bind the data. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            da.Dispose()
            ds.Dispose()
            c.Dispose()
        End Try
    End Sub

    Protected Sub vldDate_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles vldDate.ServerValidate
        Dim vDate As Date
        Dim vFromDate As Date
        Dim vToDate As Date
        Try
            vDate = cmbMonthFr.SelectedValue & "/" & cmbDayFr.SelectedValue & "/" & cmbYrFr.SelectedValue
            vFromDate = vDate
        Catch ex As System.Exception
            args.IsValid = False
            Exit Sub
        End Try
        Try
            vDate = cmbMonthTo.SelectedValue & "/" & cmbDayTo.SelectedValue & "/" & cmbYrTo.SelectedValue
            vToDate = vDate
        Catch ex As System.Exception
            args.IsValid = False
            Exit Sub
        End Try
        args.IsValid = True
    End Sub

    Protected Sub cmdClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdClose.Click
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub cmdFreeze_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdFreeze.Click
        vScript = "OpenPop();"
        GetDisApprovedApplication()
    End Sub

    Private Sub getNextCutOff()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim vSM_ToDate As Date
        Dim vMO_ToDate As Date

        c.Open()
        cm.Connection = c
        cm.CommandText = "select top 1 FromDate,TODATE,PayDate, Pay_Cd from py_report " & _
            "where Pay_Cd='SM' and normalpayroll=1 and posted=1 order by PayDate desc "
        rs = cm.ExecuteReader
        If rs.Read Then
            vSM_ToDate = rs("ToDate")
        End If
        rs.Close()

        cm.CommandText = "select top 1 FromDate,TODATE,PayDate, Pay_Cd from py_report " & _
            "where Pay_Cd='MO' and normalpayroll=1 and posted=1 order by PayDate desc "
        rs = cm.ExecuteReader
        If rs.Read Then
            vMO_ToDate = rs("ToDate")
        End If
        rs.Close()

        txtMODate.Text = vMO_ToDate.AddMonths(2)
        txtSMDate.Text = vSM_ToDate.AddMonths(1)

        c.Close()
        c.Dispose()
        cm.Dispose()
    End Sub

    Private Sub SendEmail_to_ApprovingOfficer(ByRef c As SqlClient.SqlConnection)
        Dim cm As New SqlClient.SqlCommand
        Dim cmRef As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader

        Dim pFrom As Date = CDate(cmbMonthFr.SelectedValue & "/" & cmbDayFr.SelectedValue & "/" & cmbYrFr.SelectedValue)
        Dim pTo As Date = CDate(cmbMonthTo.SelectedValue & "/" & cmbDayTo.SelectedValue & "/" & cmbYrTo.SelectedValue)

        Dim vMail As New System.Net.Mail.SmtpClient
        Dim vBody As String = ""
        Dim vErrorList As String = ""
        Dim vAppNo As String = ""
        Dim vCtr As Integer = 0

        Dim vFilter As String = " Between '" & pFrom & "' and '" & pTo & "' and void= 0 and " & _
        "((ApprovedBy is Not null and DateApproved is null) or " & _
            "(ApprovedBy is Not null and DateApproved is not null and RecommendedBy is Not null and DateRecommended is null) or " & _
            "(ApprovedBy is Not null and DateApproved is not null and RecommendedBy is Not null and DateRecommended is not null and NotedBy is not null and DateNoted is null)) "

        cm.Connection = c
        cmRef.Connection = c
        cm.CommandText = "select distinct ApprovedBy, " & _
            "(select Emp_Email from py_emp_master where py_emp_master.Emp_Cd=hr_leave_application.ApprovedBy) as Emp_Email, " & _
            "(select Emp_Fname+' '+Emp_Lname from py_emp_master where py_emp_master.Emp_Cd=hr_leave_application.ApprovedBy ) as FullName " & _
            " from hr_leave_application where StartDate " & vFilter


        '' Leave Application Notice ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        rs = cm.ExecuteReader
        Do While rs.Read
            If Not IsDBNull(rs("Emp_Email")) Then
                If rs("Emp_Email").ToString.Trim <> "" Then
                    vBody = "Dear Mr/Mrs. " & rs("FullName") & ", " & vbCrLf & vbNewLine & _
                        "The payroll team had frozen the cut off periods from " & pFrom & " to " & pTo & " and there are pending applications that " & _
                        "that still requires your approval. Those pending applications were tagged as late filing and will need your approval " & _
                        "again before it is reflected to the next payroll period." & _
                        vbNewLine & vbNewLine & "Logon on to " & HOMEPAGE & " to Approve or Disapprove the Application." & _
                        vbNewLine & vbNewLine & "PLEASE DO NOT REPLY TO THIS EMAIL!..."

                    vCtr += 1
                    cmRef.CommandText = "insert into email_queue (TransDate, ApplicationNo, FromEmail, ToEmail, Subject, Message, Failed) " & _
                        "values ('" & Now() & "', 'FLOG" & Format(Now(), "MMddyyyy") & "-" & vCtr & "', '" & FROMEMAIL & _
                        "', '" & rs("Emp_Email") & "', 'Leave Application Notice - Resend All Pending Application', '" & vBody & "', 0)"

                    Try
                        cmRef.ExecuteNonQuery()
                    Catch ex As SqlClient.SqlException
                        vScript = "alert('Error occurred while trying to update applications. Error is: " & _
                            ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                        c.Close()
                        cm.Dispose()
                        c.Dispose()
                        Exit Sub
                    End Try

                    'Try
                    '    'With vMail
                    '    '    .Host = HOSTNAME
                    '    '    .Port = PORT
                    '    '    '.Send(FROMEMAIL, rs("Emp_Email"), "Leave Application Notice - Resend All Pending Application", vBody)
                    '    'End With

                    'Catch ex As System.Exception
                    '    vErrorList += rs("Emp_Email") & "\n"
                    '    'vScript = "alert('All pending Leave Applications were resubmitted for late application " & _
                    '    '"but there was an Error in sending mail. Error is: " & ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                    '    'rs.Close()
                    '    'cm.Dispose()
                    '    'Exit Sub
                    'End Try
                End If
            End If
        Loop
        rs.Close()


        '' DTR Correction Notice '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        cm.CommandText = "SELECT distinct ApprovedBy, " & _
            "(select Emp_Fname+', '+Emp_Lname from py_emp_master where py_emp_master.Emp_Cd=py_time_log.ApprovedBy) as FullName, " & _
            "(select Emp_Email from py_emp_master where py_emp_master.Emp_Cd=py_time_log.ApprovedBy) as Emp_Email " & _
            "FROM py_time_log WHERE CorrectionTimeIn IS NOT NULL AND Tran_Date Between '" & pFrom & "' and '" & pTo & "' AND " & _
            "((Date_Approved IS NOT NULL AND DateDisapproved IS NULL) " & _
            "OR (Date_Approved IS NULL AND DateDisapproved IS NOT NULL))"

        rs = cm.ExecuteReader
        Do While rs.Read
            If Not IsDBNull(rs("Emp_Email")) Then
                If rs("Emp_Email").ToString.Trim <> "" Then

                    vBody = "Dear Mr/Mrs. " & rs("FullName") & ", " & vbCrLf & vbNewLine & _
                       "The payroll team had frozen the cut off periods from " & pFrom & " to " & pTo & " and there are pending applications that " & _
                       "that still requires your approval. Those pending applications were tagged as late filing and will need your approval " & _
                       "again before it is reflected to the next payroll period." & _
                       vbNewLine & vbNewLine & "Logon on to " & HOMEPAGE & " to Approve or Disapprove the Application." & _
                           vbNewLine & vbNewLine & "PLEASE DO NOT REPLY TO THIS EMAIL!..."

                    vCtr += 1
                    cmRef.CommandText = "insert into email_queue (TransDate, ApplicationNo, FromEmail, ToEmail, Subject, Message, Failed) " & _
                           "values ('" & Now() & "', 'FLOG" & Format(Now(), "MMddyyyy") & "-" & vCtr & "', '" & FROMEMAIL & _
                           "', '" & rs("Emp_Email") & "', 'DTR Correction Notice - Resend All Pending Application', '" & vBody & "', 0)"

                    Try
                        cmRef.ExecuteNonQuery()
                    Catch ex As SqlClient.SqlException
                        vScript = "alert('Error occurred while trying to update applications. Error is: " & _
                            ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                        c.Close()
                        cm.Dispose()
                        c.Dispose()
                        Exit Sub
                    End Try

                    'With vMail
                    '    .Host = HOSTNAME
                    '    .Port = PORT

                    '    Try
                    '        .Send(FROMEMAIL, rs("Emp_Email"), "DTR Correction Notice - Resend All Pending Application", vBody)
                    '    Catch ex As System.Exception
                    '        vErrorList += rs("Emp_Email") & "\n"
                    '        'vScript = "alert('All pending Leave Applications were resubmitted for late application " & _
                    '        '"but there was an Error in sending mail. Error is: " & ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                    '        'rs.Close()
                    '        'cm.Dispose()
                    '        'Exit Sub
                    '    End Try
                    'End With
                End If

            End If
        Loop
        rs.Close()

        '' Change Shift Notice '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        cm.CommandText = "select distinct ApprovedBy, " & _
            "(select Emp_Fname+', '+Emp_Lname from py_emp_master where py_emp_master.Emp_Cd=py_emp_time_sched.ApprovedBy) as FullName, " & _
            "(select Emp_Email from py_emp_master where py_emp_master.Emp_Cd=py_emp_time_sched.ApprovedBy) as Emp_Email " & _
            "from py_emp_time_sched where Date_Sched " & vFilter

        rs = cm.ExecuteReader

        'Dim vTemp_Id As String = ""
        'vTemp_Id = rs("Emp_Cd") & rs("Date_Sched") & "-" & rs("ShiftCd")
        Do While rs.Read
            If Not IsDBNull(rs("Emp_Email")) Then
                If rs("Emp_Email").ToString.Trim <> "" Then


                    vBody = "Dear Mr/Mrs. " & rs("FullName") & ", " & vbCrLf & vbNewLine & _
                        "The payroll team had frozen the cut off periods from " & pFrom & " to " & pTo & " and there are pending applications that " & _
                        "that still requires your approval. Those pending applications were tagged as late filing and will need your approval " & _
                        "again before it is reflected to the next payroll period." & _
                        vbNewLine & vbNewLine & "Logon on to " & HOMEPAGE & " to Approve or Disapprove the Application." & _
                        vbNewLine & vbNewLine & "PLEASE DO NOT REPLY TO THIS EMAIL!..."

                    vCtr += 1
                    cmRef.CommandText = "insert into email_queue (TransDate, ApplicationNo, FromEmail, ToEmail, Subject, Message, Failed) " & _
                           "values ('" & Now() & "', 'FLOG" & Format(Now(), "MMddyy") & "-" & vCtr & "', '" & FROMEMAIL & _
                           "', '" & rs("Emp_Email") & "', 'Change Shift Notice - Resend All Pending Application', '" & vBody & "', 0)"

                    Try
                        cmRef.ExecuteNonQuery()
                    Catch ex As SqlClient.SqlException
                        vScript = "alert('Error occurred while trying to update applications. Error is: " & _
                            ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                        c.Close()
                        cm.Dispose()
                        c.Dispose()
                        Exit Sub
                    End Try

                    'With vMail
                    '    .Host = HOSTNAME
                    '    .Port = PORT
                    '    'emd_cd + date_sched + shif_de
                    '    v = v.GetHashCode
                    '    Try
                    '        .Send(FROMEMAIL, rs("Emp_Email"), "Change Shift Notice - Resend All Pending Application", vBody)
                    '    Catch ex As System.Exception
                    '        vErrorList += rs("Emp_Email") & "\n"
                    '        'vScript = "alert('All pending Leave Applications were resubmitted for late application " & _
                    '        '"but there was an Error in sending mail. Error is: " & ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                    '        'rs.Close()
                    '        'cm.Dispose()
                    '        'Exit Sub
                    '    End Try
                    'End With
                End If

            End If
        Loop
        rs.Close()
        If vErrorList <> "" Then
            vScript = "alert('All pending Leave Applications were resubmitted for late application " & _
                "but there was an Error in sending mail to the following:\n" & vErrorList & "');"
        Else
            vScript = "alert('All pending Application were successfully resubmitted');"
        End If

        cm.Dispose()
    End Sub

    Private Sub GetDisApprovedApplication()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim vStatus As String = ""
        Dim pFrom As Date = CDate(cmbMonthFr.SelectedValue & "/" & cmbDayFr.SelectedValue & "/" & cmbYrFr.SelectedValue)
        Dim pTo As Date = CDate(cmbMonthTo.SelectedValue & "/" & cmbDayTo.SelectedValue & "/" & cmbYrTo.SelectedValue)
        Dim vCtr As Integer = 1

        Dim vMOList As String = ""
        Dim vSMList As String = ""
        Dim vMOTimelogList As String = ""
        Dim vSMTimelogList As String = ""
        Dim vMOCShiftList As String = ""
        Dim vSMCShiftList As String = ""

        Dim vApproverList As String = ""

        c.Open()
        cm.Connection = c

        'GET ALL PENDING APPLICATION IN hr_leave_application*
        cm.CommandText = "select *, " & _
            "(select Emp_Lname+', '+Emp_Fname  from py_emp_master where py_emp_master.Emp_Cd=hr_leave_application.Emp_Cd) as FullName," & _
            "(select Emp_Lname+', '+Emp_Fname  from py_emp_master where py_emp_master.Emp_Cd=hr_leave_application.ApprovedBy) as vApprovedBy, " & _
            "(select Emp_Lname+', '+Emp_Fname  from py_emp_master where py_emp_master.Emp_Cd=hr_leave_application.RecommendedBy) as vRecommendedBy, " & _
            "(select Emp_Lname+', '+Emp_Fname  from py_emp_master where py_emp_master.Emp_Cd=hr_leave_application.NotedBy) as vNotedBy, " & _
            "(select Pay_Cd from py_emp_master where py_emp_master.Emp_Cd=hr_leave_application.Emp_Cd ) as vPaycode " & _
            "from hr_leave_application where Emp_Cd is not null and Emp_Cd<>'' and Void= 0 and " & _
            "StartDate Between '" & Format(pFrom, "yyyy/MM/dd") & "' and '" & Format(pTo, "yyyy/MM/dd") & "' and EffectivityDate is null and " & _
            "((ApprovedBy is Not null and DateApproved is null) or " & _
            "(ApprovedBy is Not null and DateApproved is not null and RecommendedBy is Not null and DateRecommended is null) or " & _
            "(ApprovedBy is Not null and DateApproved is not null and RecommendedBy is Not null and DateRecommended is not null and NotedBy is not null and DateNoted is null)) " & _
            "order by LeaveCd"
        'Response.Write(cm.CommandText)
        rs = cm.ExecuteReader
        Do While rs.Read

            If IsDBNull(rs("DateApproved")) Then
                vApproverList += "'" & rs("ApprovedBy") & "',"
            ElseIf IsDBNull(rs("DateRecommended")) And Not IsDBNull(rs("RecommendedBy")) Then
                vApproverList += "'" & rs("RecommendedBy") & "',"
            ElseIf IsDBNull(rs("DateNoted")) And Not IsDBNull(rs("NotedBy")) Then
                vApproverList += "'" & rs("NotedBy") & "',"
            End If

            Select Case rs("vPaycode")
                Case "MO"
                    vMOList += "'" & rs("Id") & "',"
                Case "SM"
                    vSMList += "'" & rs("Id") & "',"
            End Select

            vList += "<tr class='linkstyle-row' ><td class='labelBC'>" & vCtr & "</td>" & _
                "<td class='labelBC' style='padding:5px; color: #000000;'>" & rs("TranDate") & "</td>" & _
                "<td class='labelBC' style='padding:5px; color: #000000;'>" & rs("Emp_Cd") & "</td>" & _
                "<td class='labelBL' style='padding:5px; color: #000000;'>" & rs("FullName") & "</td>" & _
                "<td class='labelBC' style='padding:5px; color: #000000;'>" & rs("LeaveCd") & "</td>" & _
                "<td class='labelBC' style='padding:5px; color: #000000;'>" & rs("DaysLeave") & "</td>" & _
                "<td class='labelBC' style='padding:5px; color: #000000;'>" & rs("StartDate") & "</td>" & _
                "<td class='labelBC' style='padding:5px; color: #000000;'>" & rs("EndDate") & "</td>" & _
                "<td class='labelBL' style='padding:5px; color: #000000;'>" & rs("vApprovedBy") & ""

            If Not IsDBNull(rs("DateApproved")) Then
                vList += "<br>" & Format(rs("DateApproved"), "MM/dd/yyyy")
            End If

            vList += "</td>" & _
                "<td class='labelBL' style='padding:5px; color: #000000;'>" & rs("vRecommendedBy") & ""

            If Not IsDBNull(rs("DateRecommended")) Then
                vList += "<br>" & Format(rs("DateRecommended"), "MM/dd/yyyy")
            End If


            vList += "</td>" & _
                "<td class='labelBL' style='padding:5px; color: #000000;'>" & rs("vNotedBy") & ""
            If Not IsDBNull(rs("DateNoted")) Then
                vList += "<br>" & Format(rs("DateNoted"), "MM/dd/yyyy")
            End If

            vList += "</td></tr>"

            vCtr += 1
        Loop

        If vMOList <> "" Then
            txtMOList.Text = Mid(vMOList, 1, Len(vMOList) - 1)
        End If

        If vSMList <> "" Then
            txtSMList.Text = Mid(vSMList, 1, Len(vSMList) - 1)
        End If
        rs.Close()

        'GET ALL PENDING APPLICATION IN py_time_log*
        cm.CommandText = "SELECT Emp_Cd,Tran_Date,Emp_Name,Id,Reason,CorrectionTimeIn,CorrectionTimeOutDate,EffectivityDate, " & _
            "CorrectionTimeOut, ApprovedBy, Date_Approved, Remarks, DateFiled, " & _
            "(select Emp_Lname+', '+Emp_Fname from py_emp_master where py_emp_master.Emp_Cd=py_time_log.Emp_Cd) as FullName, " & _
            "(select Emp_Lname+', '+Emp_Fname from py_emp_master where py_emp_master.Emp_Cd=py_time_log.ApprovedBy) as vApprovedBy, " & _
            "(select Pay_Cd from py_emp_master where py_emp_master.Emp_Cd=py_time_log.Emp_Cd ) as vPaycode " & _
            "FROM py_time_log WHERE CorrectionTimeIn IS NOT NULL AND Tran_Date Between '" & _
            Format(pFrom, "yyyy/MM/dd") & "' and '" & Format(pTo, "yyyy/MM/dd") & "' AND  " & _
            " ApprovedBy IS NOT null and EffectivityDate is null and Date_Approved IS NULL AND DateDisapproved IS NULL  " & _
            "ORDER BY Tran_Date desc"

        rs = cm.ExecuteReader

        Do While rs.Read
            If IsDBNull(rs("Date_Approved")) Then
                vApproverList += "'" & rs("ApprovedBy") & "',"
            End If

            Select Case rs("vPaycode")
                Case "MO"
                    vMOTimelogList += "'" & rs("Id") & "',"
                Case "SM"
                    vSMTimelogList += "'" & rs("Id") & "',"
            End Select

            vList += "<tr class='linkstyle-row' ><td class='labelBC'>" & vCtr & "</td>" & _
                "<td class='labelBC' style='padding:5px; color: #000000;'>" & rs("Tran_Date") & "</td>" & _
                "<td class='labelBC' style='padding:5px; color: #000000;'>" & rs("Emp_Cd") & "</td>" & _
                "<td class='labelBL' style='padding:5px; color: #000000;'>" & rs("FullName") & "</td>" & _
                "<td class='labelBC' style='padding:5px; color: #000000;'>DTR Correction</td>" & _
                "<td class='labelBC' style='padding:5px; color: #000000;'>0</td>" & _
                "<td class='labelBC' style='padding:5px; color: #000000;'>...</td>" & _
                "<td class='labelBC' style='padding:5px; color: #000000;'>...</td>" & _
                "<td class='labelBL' style='padding:5px; color: #000000;'>" & rs("vApprovedBy") & ""

            If Not IsDBNull(rs("Date_Approved")) Then
                vList += "<br>" & Format(rs("Date_Approved"), "MM/dd/yyyy")
            End If

            vList += "</td>" & _
                "<td class='labelBL' style='padding:5px; color: #000000;'></td>" & _
                "<td class='labelBL' style='padding:5px; color: #000000;'></td>" & _
                "</tr>"

            vCtr += 1
        Loop
        If vMOTimelogList <> "" Then
            txtMOTimeLogList.Text = Mid(vMOTimelogList, 1, Len(vMOTimelogList) - 1)
        End If

        If vSMTimelogList <> "" Then
            txtSMTimeLogList.Text = Mid(vSMTimelogList, 1, Len(vSMTimelogList) - 1)
        End If
        rs.Close()

        cm.CommandText = "select *, (select Emp_Lname+', '+Emp_Fname from py_emp_master where py_emp_master.Emp_Cd=py_emp_time_sched.Emp_Cd) as FullName, " & _
            "(select Emp_Lname+', '+Emp_Fname from py_emp_master where py_emp_master.Emp_Cd=py_emp_time_sched.ApprovedBy) as vApprovedBy, " & _
            "(select Emp_Lname+', '+Emp_Fname from py_emp_master where py_emp_master.Emp_Cd=py_emp_time_sched.RecommendedBy) as vRecommendedBy, " & _
            "(select Emp_Lname+', '+Emp_Fname from py_emp_master where py_emp_master.Emp_Cd=py_emp_time_sched.NotedBy) as vNotedBy, " & _
            "(select Pay_Cd from py_emp_master where py_emp_master.Emp_Cd=py_emp_time_sched.Emp_Cd ) as vPaycode " & _
            "from py_emp_time_sched where void= 0 and Date_Sched Between '" & _
            Format(pFrom, "yyyy/MM/dd") & "' and '" & Format(pTo, "yyyy/MM/dd") & "' and " & _
            "Transdate is not null and EffectivityDate is null and  " & _
            "((ApprovedBy is Not null and DateApproved is null) or " & _
            "(ApprovedBy is Not null and DateApproved is not null and RecommendedBy is Not null and DateRecommended is null) or " & _
            "(ApprovedBy is Not null and DateApproved is not null and RecommendedBy is Not null and DateRecommended is not null and NotedBy is not null and DateNoted is null)) "

        rs = cm.ExecuteReader
        Do While rs.Read
            If IsDBNull(rs("DateApproved")) Then
                vApproverList += "'" & rs("ApprovedBy") & "',"
            ElseIf IsDBNull(rs("DateRecommended")) And Not IsDBNull(rs("RecommendedBy")) Then
                vApproverList += "'" & rs("RecommendedBy") & "',"
            ElseIf IsDBNull(rs("DateNoted")) And Not IsDBNull(rs("NotedBy")) Then
                vApproverList += "'" & rs("NotedBy") & "',"
            End If

            Select Case rs("vPaycode")
                Case "MO"
                    vMOCShiftList += " Emp_Cd='" & rs("Emp_Cd") & "' and Date_Sched='" & rs("Date_Sched") & "' and ShiftCd='" & rs("ShiftCd") & "',"
                Case "SM"
                    vSMCShiftList += " Emp_Cd='" & rs("Emp_Cd") & "' and Date_Sched='" & rs("Date_Sched") & "' and ShiftCd='" & rs("ShiftCd") & "',"
            End Select

            vList += "<tr class='linkstyle-row' ><td class='labelBC'>" & vCtr & "</td>" & _
                "<td class='labelBC' style='padding:5px; color: #000000;'>" & rs("TransDate") & "</td>" & _
                "<td class='labelBC' style='padding:5px; color: #000000;'>" & rs("Emp_Cd") & "</td>" & _
                "<td class='labelBL' style='padding:5px; color: #000000;'>" & rs("FullName") & "</td>" & _
                "<td class='labelBC' style='padding:5px; color: #000000;'>Change Shift</td>" & _
                "<td class='labelBC' style='padding:5px; color: #000000;'>0</td>" & _
                "<td class='labelBC' style='padding:5px; color: #000000;'>...</td>" & _
                "<td class='labelBC' style='padding:5px; color: #000000;'>...</td>" & _
                "<td class='labelBL' style='padding:5px; color: #000000;'>" & rs("vApprovedBy") & ""

            If Not IsDBNull(rs("DateApproved")) Then
                vList += "<br>" & Format(rs("DateApproved"), "MM/dd/yyyy")
            End If

            vList += "</td>" & _
                "<td class='labelBL' style='padding:5px; color: #000000;'>" & rs("vRecommendedBy") & ""

            If Not IsDBNull(rs("DateRecommended")) Then
                vList += "<br>" & Format(rs("DateRecommended"), "MM/dd/yyyy") & ""
            End If

            vList += "</td>" & _
                "<td class='labelBL' style='padding:5px; color: #000000;'>" & rs("NotedBy") & ""

            If Not IsDBNull(rs("DateNoted")) Then
                vList += "<br>" & Format(rs("DateNoted"), "MM/dd/yyyy")
            End If

            vList += "</td></tr>"

            vCtr += 1
        Loop
        If vMOCShiftList <> "" Then
            txtMOCShiftList.Text = Mid(vMOCShiftList, 1, Len(vMOCShiftList) - 1)
        End If

        If vSMCShiftList <> "" Then
            txtSMCShiftList.Text = Mid(vSMCShiftList, 1, Len(vSMCShiftList) - 1)
        End If
        rs.Close()

        If vApproverList <> "" Then
            txtAppList.Text = Mid(vApproverList, 1, Len(vApproverList) - 1)
        End If

        c.Close()
        c.Dispose()
        cm.Dispose()
    End Sub

    Protected Sub tblFreeze_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles tblFreeze.PageIndexChanging
        tblFreeze.PageIndex = e.NewPageIndex
        DataRefresh()
    End Sub

    Protected Sub cmdUnfreeze_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdUnfreeze.Click
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while tryiing to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        cm.Connection = c
        Try
            cm.CommandText = "delete from py_cutoff_frozen where Rc_Cd='" & _
                tblFreeze.SelectedRow.Cells(2).Text & "' and Agency_Cd='" & _
                tblFreeze.SelectedRow.Cells(3).Text & "' and Div_Cd='" & _
                tblFreeze.SelectedRow.Cells(4).Text & "' and Dept_Cd='" & _
                tblFreeze.SelectedRow.Cells(5).Text & "' and Section_Cd='" & _
                tblFreeze.SelectedRow.Cells(6).Text & "' and Unit_Cd='" & _
                tblFreeze.SelectedRow.Cells(7).Text & "' and EmploymentType='" & _
                tblFreeze.SelectedRow.Cells(8).Text & "' and StartDate='" & _
                Format(CDate(tblFreeze.SelectedRow.Cells(0).Text), "yyyy/MM/dd") & "' and EndDate='" & _
                Format(CDate(tblFreeze.SelectedRow.Cells(1).Text), "yyyy/MM/dd") & "'"
            cm.ExecuteNonQuery()
            DataRefresh()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to unfreeze the selected row. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            c.Dispose()
            cm.Dispose()
        End Try
    End Sub

    Protected Sub cmbDisAppFreeze_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbDisAppFreeze.Click
        lblTitle.Text = "Are you sure you want to Disapproved all Pending Application and Freeze?"
        vScript = "OpenSubPop();"
    End Sub

    Protected Sub cmbAppFreeze_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbAppFreeze.Click
        lblTitle.Text = "Are you sure you want to Resend all Pending Application and Freeze?"
        vScript = "OpenSubPop();"
    End Sub

    Protected Sub cmdSubmit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSubmit.Click
        Select Case lblTitle.Text
            Case "Are you sure you want to Disapproved all Pending Application and Freeze?"
                DisAppFreeze()              'All pending application will be force Disaproved and freeze logs
            Case "Are you sure you want to Resend all Pending Application and Freeze?"
                ResendAppFreeze()           'All pending application will resend or all application will go back to start and freeze logs
            Case "Are you sure you want to send email?"
                SendEmailNotification()     'Email all approving officer to give time on all pending application 
        End Select
        lblTitle.Text = ""
        'DataRefresh()
    End Sub

    Private Sub DisAppFreeze()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim pFrom As Date = CDate(cmbMonthFr.SelectedValue & "/" & cmbDayFr.SelectedValue & "/" & cmbYrFr.SelectedValue)
        Dim pTo As Date = CDate(cmbMonthTo.SelectedValue & "/" & cmbDayTo.SelectedValue & "/" & cmbYrTo.SelectedValue)
        Dim vRc As String = cmbRC.SelectedValue
        Dim vOfc As String = cmbOfc.SelectedValue
        Dim vDiv As String = cmbDiv.SelectedValue
        Dim vDept As String = cmbDept.SelectedValue
        Dim vSection As String = cmbSection.SelectedValue
        Dim vUnit As String = cmbUnit.SelectedValue
        Dim vRank As String = cmbSecurity.SelectedValue

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert(""" & ex.Message.Replace(vbCrLf, "\n").Replace("'", "") & """);"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        cm.Connection = c
        ' ============================================================================================================================
        ' Create new record to py_cutoff_frozen 
        ' ============================================================================================================================
        cm.CommandText = "INSERT INTO py_cutoff_frozen (StartDate,EndDate,Rc_Cd," & _
            "Agency_Cd,Div_Cd,Dept_Cd,Section_Cd,Unit_Cd,EmploymentType,Date_Freezed,FreezedBy) VALUES ('" & _
            pFrom & "','" & pTo & "','" & vRc & "', '" & vOfc & "', '" & vDiv & _
            "', '" & vDept & "', '" & vSection & "', '" & vUnit & "', '" & vRank & "','" & _
            Format(Now, "yyyy/MM/dd HH:mm:ss") & "','" & Session("uid") & "') "
        Try
            cm.ExecuteNonQuery()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to update applications. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Close()
            cm.Dispose()
            c.Dispose()
            Exit Sub
        End Try

        ' ============================================================================================================================
        ' Force Disaproved all pending TIMELOG APPLICATION
        ' ============================================================================================================================
        cm.CommandText = "UPDATE py_time_log SET ApprovedBy = NULL,DateDisApproved='" & Format(Now, "yyyy/MM/dd HH:mm:ss") & _
            "',Remarks='DISAPPROVED DUE TO : Freeze Logs.' WHERE Tran_Date BETWEEN '" & pFrom & _
            "' AND '" & pTo & "' AND Date_Approved IS NULL AND CorrectionTimeIn IS NOT NULL"
        Try
            cm.ExecuteNonQuery()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to update applications. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Close()
            cm.Dispose()
            c.Dispose()
            Exit Sub
        End Try

        ' ============================================================================================================================
        ' Force Disaproved all pending LEAVE AND OVERTIME APPLICATION
        ' ============================================================================================================================
        cm.CommandText = "UPDATE hr_leave_application SET Void = 1,DateApproved='" & _
            Format(Now, "yyyy/MM/dd HH:mm:ss") & "', Remarks = 'DISAPPROVED DUE TO:Freeze Logs.' WHERE StartDate BETWEEN '" & _
            pFrom & "' AND '" & pTo & "' AND DateApproved IS NULL "
        Try
            cm.ExecuteNonQuery()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to update applications. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Close()
            cm.Dispose()
            c.Dispose()
            Exit Sub
        End Try

        ' ============================================================================================================================
        ' Force Disaproved all pending CHANGE SHIFT APPLICATION
        ' ============================================================================================================================
        cm.CommandText = "update py_emp_time_sched set Void=1,ApprovedBy=null,DateApproved='" & _
            Format(Now, "yyyy/MM/dd HH:mm:ss") & "',Reason='DISAPPROVED DUE TO:Freeze Logs.'+Reason where Date_Sched between '" & _
            pFrom & "' and '" & pTo & "' and DateApproved is null"
        Try
            cm.ExecuteNonQuery()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to update applications. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Close()
            cm.Dispose()
            c.Dispose()
            Exit Sub
        End Try

        vScript = "alert('Cut off Periods were successfully frozen.');"
        DataRefresh()

        'Catch ex As SqlClient.SqlException
        '    vScript = "alert('Error occurred while trying to update record. Error is: " & _
        '        ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        'Finally
        '    c.Close()
        '    c.Dispose()
        '    cm.Dispose()
        'End Try
    End Sub

    Private Sub ResendAppFreeze()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim pFrom As Date = CDate(cmbMonthFr.SelectedValue & "/" & cmbDayFr.SelectedValue & "/" & cmbYrFr.SelectedValue)
        Dim pTo As Date = CDate(cmbMonthTo.SelectedValue & "/" & cmbDayTo.SelectedValue & "/" & cmbYrTo.SelectedValue)
        Dim vRc As String = cmbRC.SelectedValue
        Dim vOfc As String = cmbOfc.SelectedValue
        Dim vDiv As String = cmbDiv.SelectedValue
        Dim vDept As String = cmbDept.SelectedValue
        Dim vSection As String = cmbSection.SelectedValue
        Dim vUnit As String = cmbUnit.SelectedValue
        Dim vRank As String = cmbSecurity.SelectedValue
        Dim vErrorList As String = ""

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert(""" & ex.Message.Replace(vbCrLf, "\n").Replace("'", "") & """);"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        cm.Connection = c
        ' ============================================================================================================================
        ' Create new record to py_cutoff_frozen 
        ' ============================================================================================================================
        cm.CommandText = "INSERT INTO py_cutoff_frozen (StartDate,EndDate,Rc_Cd," & _
            "Agency_Cd,Div_Cd,Dept_Cd,Section_Cd,Unit_Cd,EmploymentType,Date_Freezed,FreezedBy) VALUES ('" & _
            pFrom & "','" & pTo & "','" & vRc & "', '" & vOfc & "', '" & vDiv & _
            "', '" & vDept & "', '" & vSection & "', '" & vUnit & "', '" & vRank & "','" & _
            Format(Now, "yyyy/MM/dd HH:mm:ss") & "','" & Session("uid") & "') "
        'Try
        Try
            cm.ExecuteNonQuery()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to update applications. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Close()
            cm.Dispose()
            c.Dispose()
            Exit Sub
        End Try

        ' ============================================================================================================================
        ' resend all pending application with pay mode MO in "HR LEAVE APPLICATION"
        ' ============================================================================================================================
        If txtMOList.Text <> "" Then
            cm.CommandText = "UPDATE hr_leave_application SET EffectivityDate='" & Format(CDate(txtMODate.Text), "yyyy/MM/dd HH:mm:ss") & _
                "', DateApproved = NULL, DateNoted= NULL, DateRecommended=NULL " & _
                ",Remarks='RESEND ALL PENDING APPLICATION DUE TO:Freeze Logs.' WHERE StartDate BETWEEN '" & Format(pFrom, "yyyy/MM/dd") & _
                " 00:00:00' AND '" & Format(pTo, "yyyy/MM/dd") & " 23:59:59' AND ID in (" & txtMOList.Text & ")"
            Try
                cm.ExecuteNonQuery()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to update applications. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                c.Close()
                cm.Dispose()
                c.Dispose()
                Exit Sub
            End Try
        End If
        ' ============================================================================================================================
        ' resend all pending application with pay mode MO in (PY EMP TIME LOG TABLE)
        ' ============================================================================================================================
        If txtMOTimeLogList.Text <> "" Then
            cm.CommandText = "UPDATE py_time_log SET EffectivityDate='" & Format(CDate(txtMODate.Text), "yyyy/MM/dd HH:mm:ss") & _
                        "', Date_Approved = NULL " & _
                        ",Remarks='RESEND ALL PENDING APPLICATION DUE TO:Freeze Logs.' WHERE Tran_Date BETWEEN '" & Format(pFrom, "yyyy/MM/dd") & _
                        " 00:00:00' AND '" & Format(pTo, "yyyy/MM/dd") & " 23:59:59' AND ID in (" & txtMOTimeLogList.Text & ")"
            Try
                cm.ExecuteNonQuery()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to update applications. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                c.Close()
                cm.Dispose()
                c.Dispose()
                Exit Sub
            End Try
        End If

        ' ============================================================================================================================
        ' resend all pending application with pay mode SM in (HR LEAVE APPLICATION)
        ' ============================================================================================================================
        If txtSMList.Text <> "" Then
            cm.CommandText = "UPDATE hr_leave_application SET EffectivityDate='" & Format(CDate(txtSMDate.Text), "yyyy/MM/dd HH:mm:ss") & _
                        "', DateApproved = NULL, DateNoted= NULL, DateRecommended=NULL " & _
                        ",Remarks='RESEND ALL PENDING APPLICATION DUE TO:Freeze Logs.' WHERE StartDate BETWEEN '" & Format(pFrom, "yyyy/MM/dd") & _
                        " 00:00:00' AND '" & Format(pTo, "yyyy/MM/dd") & " 23:59:59' AND ID in (" & txtSMList.Text & ")"
            Try
                cm.ExecuteNonQuery()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to update applications. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                c.Close()
                cm.Dispose()
                c.Dispose()
                Exit Sub
            End Try

        End If

        ' ============================================================================================================================
        ' resend all pending application with pay mode SM in (PY EMP TIME LOG TABLE)
        ' ============================================================================================================================
        If txtSMTimeLogList.Text <> "" Then
            cm.CommandText = "UPDATE py_time_log SET EffectivityDate='" & Format(CDate(txtSMDate.Text), "yyyy/MM/dd HH:mm:ss") & _
                        "', Date_Approved = NULL " & _
                        ",Remarks='RESEND ALL PENDING APPLICATION DUE TO:Freeze Logs.' WHERE Tran_Date BETWEEN '" & Format(pFrom, "yyyy/MM/dd") & _
                        " 00:00:00' AND '" & Format(pTo, "yyyy/MM/dd") & " 23:59:59' AND ID in (" & txtSMTimeLogList.Text & ")"
            Try
                cm.ExecuteNonQuery()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to update applications. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                c.Close()
                cm.Dispose()
                c.Dispose()
                Exit Sub
            End Try

        End If

        Dim vMOTimeLog() As String
        Dim vSMTimeLog() As String
        Dim i As Integer = 0

        ' ============================================================================================================================
        ' resend all pending application with PAYMODE MONTHLY (MO) in PY_EMP_TIME_LOG TABLE
        ' ============================================================================================================================
        If txtMOCShiftList.Text <> "" Then
            vMOTimeLog = txtMOCShiftList.Text.Split(",")
            For i = 0 To UBound(vMOTimeLog)
                cm.CommandText = "UPDATE py_emp_time_sched SET EffectivityDate='" & _
                    Format(CDate(txtMODate.Text), "yyyy/MM/dd HH:mm:ss") & _
                    "', DateApproved = NULL, Reason='RESEND ALL PENDING APPLICATION DUE TO:Freeze Logs.' WHERE " & vMOTimeLog(i)
                Try
                    cm.ExecuteNonQuery()
                Catch ex As SqlClient.SqlException
                    vScript = "alert('Error occurred while trying to update applications. Error is: " & _
                        ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                    c.Close()
                    cm.Dispose()
                    c.Dispose()
                    Exit Sub
                End Try
            Next
        End If

        ' ============================================================================================================================
        ' resend all pending application with PAYMODE SIMI MONTHLY (SM) in PY_EMP_TIME_LOG TABLE
        ' ============================================================================================================================
        If txtSMCShiftList.Text <> "" Then
            vSMTimeLog = txtSMCShiftList.Text.Split(",")
            For i = 0 To UBound(vSMTimeLog)
                cm.CommandText = "UPDATE py_emp_time_sched SET EffectivityDate='" & _
                    Format(CDate(txtSMDate.Text), "yyyy/MM/dd HH:mm:ss") & _
                    "', DateApproved = NULL, Reason='RESEND ALL PENDING APPLICATION DUE TO:Freeze Logs.' WHERE " & vSMTimeLog(i)
                Try
                    cm.ExecuteNonQuery()
                Catch ex As SqlClient.SqlException
                    vScript = "alert('Error occurred while trying to update applications. Error is: " & _
                        ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                    c.Close()
                    cm.Dispose()
                    c.Dispose()
                    Exit Sub
                End Try
            Next
        End If

        ' ============================================================================================================================
        ' Sending email to all Approving officers
        ' ============================================================================================================================
        vScript = "alert('Cut off Periods were successfully frozen.');"
        SendEmail_to_ApprovingOfficer(c)

        c.Close()
        c.Dispose()
        cm.Dispose()
        DataRefresh()



        ' ============================================================================================================================
        '' DISAPPROVE ALL PENDING LATE APPLICATIONS                          
        ' ============================================================================================================================
        'cm.CommandText = "UPDATE py_time_log SET ApprovedBy = NULL,DateDisApproved='" & Format(Now, "yyyy/MM/dd HH:mm:ss") & _
        '    "',Remarks='DISAPPROVED DUE TO:Freeze Logs.' WHERE EffectivityDate is Not Null AND " & _
        '    "Date_Approved IS NULL AND CorrectionTimeIn IS NOT NULL"
        'Try
        '    cm.ExecuteNonQuery()
        'Catch ex As SqlClient.SqlException
        '    vScript = "alert('Error occurred while trying to update applications. Error is: " & _
        '        ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        '    c.Close()
        '    cm.Dispose()
        '    c.Dispose()
        '    Exit Sub
        'End Try
        ' ============================================================================================================================



        ' ============================================================================================================================
        ' Modify By : LANCE BISENIO 
        ' Date Modify : 04.18.2013
        ' ============================================================================================================================
        ' THIS IS OLD CODE :
        ' cm.CommandText = "UPDATE hr_leave_application SET Void = 1,DateApproved='" & _
        '    Format(Now, "yyyy/MM/dd HH:mm:ss") & "', Remarks = 'DISAPPROVED DUE TO:Freeze Logs.' WHERE " & _
        '    "EffectivityDate is Not Null AND (" & _
        '    "(ApprovedBy is not null and DateApproved IS NULL) or " & _
        '    "(RecommendedBy is not null and DateRecommended is null) or " & _
        '    "(NotedBy is not null and DateNoted is null))"
        'Try
        '    cm.ExecuteNonQuery()
        'Catch ex As SqlClient.SqlException
        '    vScript = "alert('Error occurred while trying to update applications. Error is: " & _
        '        ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        '    c.Close()
        '    cm.Dispose()
        '    c.Dispose()
        '    Exit Sub
        'End Try
        ' ============================================================================================================================



        ' ============================================================================================================================
        ' Modify By : LANCE BISENIO 
        ' Date Modify : 04.18.2013
        ' ============================================================================================================================
        ' THIS IS OLD CODE :
        ' cm.CommandText = "update py_emp_time_sched set Void=1,ApprovedBy=null,DateApproved='" & _
        '    Format(Now, "yyyy/MM/dd HH:mm:ss") & "',Reason='DISAPPROVED DUE TO:Freeze Logs.'+Reason where " & _
        '    "EffectivityDate is Not Null and (" & _
        '    "(ApprovedBy is not null and DateApproved IS NULL) or " & _
        '    "(RecommendedBy is not null and DateRecommended is null) or " & _
        '    "(NotedBy is not null and DateNoted is null))"
        'Try
        '    cm.ExecuteNonQuery()
        'Catch ex As SqlClient.SqlException
        '    vScript = "alert('Error occurred while trying to update applications. Error is: " & _
        '        ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        '    c.Close()
        '    cm.Dispose()
        '    c.Dispose()
        '    Exit Sub
        'End Try
        ' ============================================================================================================================

       

    End Sub

    Private Sub SendEmailNotification()
        If txtAppList.Text.Trim = "" Then
            vScript = "alert('Nothing to email.');"
            Exit Sub
        End If

        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cmRef As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader

        Dim pFrom As Date = CDate(cmbMonthFr.SelectedValue & "/" & cmbDayFr.SelectedValue & "/" & cmbYrFr.SelectedValue)
        Dim pTo As Date = CDate(cmbMonthTo.SelectedValue & "/" & cmbDayTo.SelectedValue & "/" & cmbYrTo.SelectedValue)

        Dim vMail As New System.Net.Mail.SmtpClient
        Dim vBody As String = ""
        Dim vEmailList As String = ""
        Dim vErrorList As String = ""
        Dim vCnt As Integer = 0

        c.Open()
        cm.Connection = c
        cmRef.Connection = c

        cm.CommandText = "select Emp_Fname+' '+Emp_Lname as FullName, Emp_Email, Emp_Cd from py_emp_master " & _
            "where Emp_Cd in (" & txtAppList.Text & ") order by Emp_Email "

        rs = cm.ExecuteReader
        Do While rs.Read
            If Not IsDBNull(rs("Emp_Email")) Then
                If rs("Emp_Email").ToString.Trim <> "" Then
                    Try
                        

                        ' ============================================================================================================================
                        '' MODIFIED BY: LANCE BISENIO                                      
                        '' DATE MODIFIED: 7/29/2012                                        
                        '' PURPOSE: INSERT ALL APPLITION INTO email_queue TABLE            
                        ' ============================================================================================================================
                        '' NEW CODE START HERE 
                        ' ============================================================================================================================
                        vBody = "Dear Mr/Mrs. " & rs("FullName") & ", " & vbCrLf & vbNewLine & _
                            "The payroll team is about to freeze the cut off periods from " & _
                            pFrom & " to " & pTo & " and there are pending applications that " & _
                            "still requires your approval. " & _
                            vbNewLine & vbNewLine & "Logon on to " & HOMEPAGE & " to Approve or Disapprove the Application." & _
                            vbNewLine & vbNewLine & "PLEASE DO NOT REPLY TO THIS EMAIL!..."

                        vCnt += 1
                        cmRef.CommandText = "insert into email_queue (TransDate, ApplicationNo, FromEmail, ToEmail, Subject, Message, Failed) " & _
                            "values ('" & Now() & "', '" & Format(Now(), "MMddyyyy") & "-" & vCnt & "', '" & FROMEMAIL & _
                            "', '" & rs("Emp_Email") & "', 'Notification - Please check your Pending Application', '" & vBody & "', 0)"

                        Try
                            cmRef.ExecuteNonQuery()
                        Catch ex As SqlClient.SqlException
                            vScript = "alert('Error occurred while trying to update applications. Error is: " & _
                                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                            c.Close()
                            cm.Dispose()
                            c.Dispose()
                            Exit Sub
                        End Try

                        '' NEW CODE END HERE ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                        '' OLD CODE START HERE ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

                        'With vMail
                        '.Host = HOSTNAME
                        '.Port = PORT

                        'vBody = "Dear Mr/Mrs. " & rs("FullName") & ", " & vbCrLf & vbNewLine & _
                        '    "The payroll team is about to freeze the cut off periods from " & _
                        '    pFrom & " to " & pTo & " and there are pending applications that " & _
                        '    "still requires your approval. " & _
                        '    vbNewLine & vbNewLine & "Logon on to " & HOMEPAGE & " to Approve or Disapprove the Application." & _
                        '    vbNewLine & vbNewLine & "PLEASE DO NOT REPLY TO THIS EMAIL!..."

                        '.Send(FROMEMAIL, rs("Emp_Email"), "Notification - Please check your Pending Application", vBody)
                        'End With
                        '' OLD CODE END HERE ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

                    Catch ex As System.Exception
                        vErrorList += rs("Emp_EMail") & "\n"
                        'vScript = "alert('Error in sending mail to " & rs("Emp_Email") & ". Error is: " & _
                        'ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                    End Try
                End If
            End If
        Loop
        rs.Close()

        c.Close()
        c.Dispose()
        cm.Dispose()
        If vErrorList <> "" Then
            vScript = "alert('Email notification successfully sent but the following have an error in sending mail:\n" & vErrorList & "');"
        Else
            vScript = "alert('Email notification successfully sent.');"
        End If
    End Sub

    Protected Sub cmdSubCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSubCancel.Click
        vScript = "closeSubMode()"
        lblTitle.Text = ""
    End Sub

    Protected Sub cmbCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbCancel.Click
        vScript = "closeMode()"
    End Sub

    Protected Sub cmbSendEmail_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbSendEmail.Click
        lblTitle.Text = "Are you sure you want to send email?"
        vScript = "OpenSubPop();"
    End Sub

    Protected Sub cmbPrint_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbPrint.Click
        Dim pFrom As Date = CDate(cmbMonthFr.SelectedValue & "/" & cmbDayFr.SelectedValue & "/" & cmbYrFr.SelectedValue)
        Dim pTo As Date = CDate(cmbMonthTo.SelectedValue & "/" & cmbDayTo.SelectedValue & "/" & cmbYrTo.SelectedValue)
        vScript = "OpenPop(); OpenPrint(""" & pFrom & """,""" & pTo & """);"
        GetDisApprovedApplication()
    End Sub

End Class
