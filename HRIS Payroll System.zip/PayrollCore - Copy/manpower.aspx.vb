﻿Imports denaro.fis
Partial Class manpower
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Public vData As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Or Session("uid") = Nothing Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If

        If Not CanRun(Session("caption"), Request.Item("id")) Then
            Session("denied") = "1"
            Server.Transfer("main.aspx")
            Exit Sub
        End If

        If Not IsPostBack Then
            Dim iCtr As Integer
            Dim c As New SqlClient.SqlConnection(connStr)
            Dim cm As New SqlClient.SqlCommand
            Dim rs As SqlClient.SqlDataReader

            cmbYear.Items.Clear()
            cmbPayPeriod.Items.Clear()
            cmbOfc.Items.Clear()

            For iCtr = Now.Year To Now.Year - 5 Step -1
                cmbYear.Items.Add(iCtr)
            Next
            cmbYear.SelectedValue = Now.Year

            Try
                c.Open()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                c.Dispose()
                cm.Dispose()
                Exit Sub
            End Try

            cm.Connection = c

            cm.CommandText = "select distinct PayDate from py_report where Year(PayDate)=" & cmbYear.SelectedValue & _
                " order by PayDate desc "
            Try
                rs = cm.ExecuteReader
                Do While rs.Read
                    cmbPayPeriod.Items.Add(Format(rs("PayDate"), "MM/dd/yyyy"))
                Loop
                rs.Close()

                cm.CommandText = "select * from agency order by AgencyName"
                rs = cm.ExecuteReader
                Do While rs.Read
                    cmbOfc.Items.Add(New ListItem(rs("AgencyName"), rs("AgencyCd")))
                Loop
                rs.Close()
                If cmbOfc.Items.Count > 0 Then
                    cmbOfc.SelectedIndex = 0
                End If
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to retrieve payroll periods. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            Finally
                c.Close()
                c.Dispose()
                cm.Dispose()
            End Try
        End If
    End Sub

    Protected Sub cmdClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdClose.Click
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub cmdGenerate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdGenerate.Click
        Dim vDump As New StringBuilder
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim vRanks As String = ""
        Dim vStatus As String = ""

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        cm.Connection = c
        vData = ""
        vDump.AppendLine("<h2>" & cmbOfc.SelectedItem.Text & "</h2>")
        vDump.AppendLine("<h3>Payroll Details - Number of Staff</h3>")
        vDump.AppendLine("<h4>Payroll Period -- " & cmbPayPeriod.SelectedValue & "</h4><hr>")
        vDump.AppendLine("<table border='1' style='width:100%;border-collapse:collapse;' class='label'>")
        vDump.AppendLine("<tr class='titleBar'><th>Div/Dept/Section/Unit</th>")
        cm.CommandText = "select distinct EmploymentType from py_report where PayDate='" & _
            Format(CDate(cmbPayPeriod.SelectedValue), "yyyy/MM/dd") & "' order by EmploymentType "

        Try
            rs = cm.ExecuteReader
            vRanks = ""
            Do While rs.Read
                vRanks += rs("EmploymentType") & ","
                vDump.AppendLine("<th>" & rs("EmploymentType") & "</th>")
            Loop
            rs.Close()
            If vRanks <> "" Then vRanks = Mid(vRanks, 1, Len(vRanks) - 1)

            cm.CommandText = "select distinct Emp_Status from py_report where PayDate='" & _
                Format(CDate(cmbPayPeriod.SelectedValue), "yyyy/MM/dd") & "' order by Emp_Status "
            rs = cm.ExecuteReader
            vStatus = ""
            Do While rs.Read
                vStatus += rs("Emp_Status") & ","
                vDump.AppendLine("<th>" & rs("Emp_Status") & "</th>")
            Loop
            rs.Close()

            If vStatus <> "" Then vStatus = Mid(vStatus, 1, Len(vStatus) - 1)
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to retrieve headers. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Close()
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try
        vDump.AppendLine("<th>Grand Total</th></tr>")

        cm.CommandText = "select distinct DivCd,(select Descr from hr_div_ref where Div_Cd=DivCd) as Descr " & _
            "from py_report where PayDate='" & Format(CDate(cmbPayPeriod.SelectedValue), "yyyy/MM/dd") & _
            "' order by Descr"

        Try
            rs = cm.ExecuteReader
            Do While rs.Read
                vDump.AppendLine("<tr class='activeBar'><td class='labelL'>" & rs("Descr") & "</td><td class='labelL' colspan='" & _
                    vRanks.Split(",").Length + vStatus.Split(",").Length + 1 & "'>&nbsp;</td></tr>")
                GetDept(rs("DivCd"), vDump, c)
                vDump.AppendLine("<tr class='even'><td class='labelL'>Total - " & rs("Descr") & "</td></tr>")
            Loop
            rs.Close()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to retrieve data. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            c.Dispose()
            cm.Dispose()
        End Try
        
        vDump.AppendLine("</table>")
        vData = vDump.ToString
    End Sub
    Private Sub GetDept(ByVal pDiv As String, ByRef pDump As StringBuilder, ByRef c As SqlClient.SqlConnection)
        Dim cm As New SqlClient.SqlCommand
        Dim cmRef As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim rsRef As SqlClient.SqlDataReader

        cm.Connection = c
        cmRef.Connection = c

        cm.CommandText = "select distinct DeptCd,(select Descr from hr_dept_ref where Dept_Cd=DeptCd) as Descr " & _
            "from py_report where PayDate='" & Format(CDate(cmbPayPeriod.SelectedValue), "yyyy/MM/dd") & _
            "' and DivCd='" & pDiv & "' order by Descr"
        Try
            rs = cm.ExecuteReader
            Do While rs.Read
                'check if dept has secions
                cmRef.CommandText = "select coun(*) from py_report where PayDate='" & Format(CDate(cmbPayPeriod.SelectedValue), "yyyy/MM/dd") & _
                    "' and DivCd='" & pDiv & "' and "
                pDump.AppendLine("<tr class='activ")
            Loop
            rs.Close()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to retrieve Dept List. Error is - " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            cm.Dispose()
        End Try
    End Sub
End Class
