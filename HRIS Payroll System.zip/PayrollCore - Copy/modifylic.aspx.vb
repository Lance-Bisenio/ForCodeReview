Imports denaro
Partial Class modifylic
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Dim c As New sqlclient.sqlconnection
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If
        If Not IsPostBack Then
            Dim cm As New sqlclient.sqlcommand
            Dim dr As sqlclient.sqldatareader
            txtEmpCd.Text = Session("empid")
            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c
            cm.CommandText = "select Emp_Lname,Emp_Fname from py_emp_master where Emp_Cd='" & txtEmpCd.Text & "'"
            dr = cm.ExecuteReader
            lblcaption.text = "Add/Modify License for "
            If dr.Read Then
                lblcaption.Text += dr("Emp_Lname") & ", " & dr("Emp_Fname")
            End If
            dr.Close()

            If Session("mode") = "e" Or Session("mode") = "v" Then
                cm.CommandText = "select * from hr_emp_license_ref where Emp_Cd='" & txtEmpCd.Text & _
                    "' and License_No='" & Session("seqid") & "'"
                dr = cm.ExecuteReader
                If dr.Read Then
                    txtLicNo.Text = IIf(IsDBNull(dr("License_No")), "", dr("License_No"))
                    txtLicName.Text = IIf(IsDBNull(dr("LicenseName")), "", dr("LicenseName"))
                    txtDateIssue.Text = IIf(IsDBNull(dr("Date_Issued")), "", dr("Date_Issued"))
                    txtExpiry.Text = IIf(IsDBNull(dr("Exp_Date")), "", dr("Exp_Date"))
                    txtRemarks.Text = IIf(IsDBNull(dr("Remarks")), "", dr("Remarks"))
                    txtPlaceSem.Text = IIf(IsDBNull(dr("Place_Sem")), "", dr("Place_Sem"))
                    txtDateSem.Text = IIf(IsDBNull(dr("Date_Seminar")), "", dr("Date_Seminar"))
                    txtDateExam.Text = IIf(IsDBNull(dr("Date_Exam")), "", dr("Date_Exam"))
                    txtPlaceExam.Text = IIf(IsDBNull(dr("Place_Exam")), "", dr("Place_Exam"))
                    txtScore.Text = IIf(IsDBNull(dr("Score")), "", dr("Score"))
                End If
                dr.Close()
                If Session("mode") = "v" Then 'freeze fields
                    txtLicNo.ReadOnly = True
                    txtLicName.ReadOnly = True
                    txtDateIssue.ReadOnly = True
                    txtExpiry.ReadOnly = True
                    txtRemarks.ReadOnly = True
                    txtPlaceSem.ReadOnly = True
                    txtDateSem.ReadOnly = True
                    txtDateExam.ReadOnly = True
                    txtPlaceExam.ReadOnly = True
                    txtScore.ReadOnly = True
                End If
            End If
            cm.Dispose()
            c.Close()
        End If
    End Sub

    Protected Sub cmdCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        Session.Remove("empid")
        Session.Remove("seqid")
        'If Session("mode") = "v" Then
        Session.Remove("mode")
        vScript = "window.close();"
        'Else
        'Session.Remove("mode")
        'Server.Transfer("emp.aspx")
        'End If
    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        If Page.IsValid Then
            Dim cm As New sqlclient.sqlcommand
            Dim vDateIssue As String = "null"
            Dim vExpiry As String = "null"
            Dim vDateSem As String = "null"
            Dim vDateExam As String = "null"

            If txtDateIssue.Text <> "" Then
                vDateIssue = "'" & Format(CDate(txtDateIssue.Text), "yyyy/MM/dd") & "'"
            End If
            If txtExpiry.Text <> "" Then
                vExpiry = "'" & Format(CDate(txtExpiry.Text), "yyyy/MM/dd") & "'"
            End If
            If txtDateSem.Text <> "" Then
                vDateSem = "'" & Format(CDate(txtDateSem.Text), "yyyy/MM/dd") & "'"
            End If
            If txtDateExam.Text <> "" Then
                vDateExam = "'" & Format(CDate(txtDateExam.Text), "yyyy/MM/dd") & "'"
            End If

            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c
            If Session("mode") = "e" Then 'edit mode
                cm.CommandText = "update hr_emp_license_ref set Date_Issued=" & vDateIssue & _
                    ",License_No='" & txtLicNo.Text & _
                    "',LicenseName='" & txtLicName.Text & _
                    "',Exp_Date=" & vExpiry & _
                    ",Remarks='" & txtRemarks.Text & _
                    "',Place_Sem='" & txtPlaceSem.Text & _
                    "',Date_Seminar=" & vDateSem & _
                    ",Date_Exam=" & vDateExam & _
                    ",Place_Exam='" & txtPlaceExam.Text & _
                    "',Score='" & txtScore.Text & _
                    "' where Emp_Cd='" & txtEmpCd.Text & "' and License_No='" & Session("seqid") & "'"
            Else                          'add mode
                cm.CommandText = "insert into hr_emp_license_ref (Emp_Cd,Date_Issued,License_No,LicenseName," & _
                    "Exp_Date,Remarks,Place_Sem,Date_Seminar,Date_Exam,Place_Exam,Score) values ('" & _
                    txtEmpCd.Text & "'," & vDateIssue & _
                    ",'" & txtLicNo.Text & "','" & txtLicName.Text & "'," & _
                    vExpiry & ",'" & txtRemarks.Text & _
                    "','" & txtPlaceSem.Text & "'," & vDateSem & _
                    "," & vDateExam & _
                    ",'" & txtPlaceExam.Text & "','" & txtScore.Text & "')"
                'Response.Write(cm.CommandText)
            End If
            cm.ExecuteNonQuery()
            vScript = "alert('Changes where successfully saved.');"
        End If
    End Sub

    Protected Sub CustomValidator1_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles CustomValidator1.ServerValidate
        args.IsValid = IsDate(txtDateExam.Text)
        If Not args.IsValid Then
            vScript = "alert('Invalid date format.');"
        End If
    End Sub

    Protected Sub CustomValidator2_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles CustomValidator2.ServerValidate
        args.IsValid = IsDate(txtDateSem.Text)
        If Not args.IsValid Then
            vScript = "alert('Invalid date format.');"
        End If
    End Sub

    Protected Sub CustomValidator4_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles CustomValidator4.ServerValidate
        args.IsValid = IsDate(txtExpiry.Text)
        If Not args.IsValid Then
            vScript = "alert('Invalid date format.');"
        End If
    End Sub

    Protected Sub CustomValidator3_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles CustomValidator3.ServerValidate
        args.IsValid = IsDate(txtDateIssue.Text)
        If Not args.IsValid Then
            vScript = "alert('Invalid date format.');"
        End If
    End Sub
End Class
