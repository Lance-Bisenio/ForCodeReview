Imports denaro.fis
Partial Class batchshift
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    ' Dim c As New SqlClient.SqlConnection(connstr)
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            vScript = "alert('Your session has expired. Please Log In again.'); window.close();"
            Exit Sub
        End If
        If Not IsPostBack Then
            Dim c As New SqlClient.SqlConnection(connStr)
            Dim cm As New SqlClient.SqlCommand
            Dim rs As SqlClient.SqlDataReader

            Try
                c.Open()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                c.Dispose()
                cm.Dispose()
                Exit Sub
            End Try

            cm.Connection = c
            cm.CommandText = "select ShiftCd,Start_Time,End_Time from py_shift order by Start_Time,End_Time"
            Try
                rs = cm.ExecuteReader
                cmbShift.Items.Clear()
                'cmbShift.Items.Add("Please select shift...")
                Do While rs.Read
                    If IsDBNull(rs("Start_Time")) Or rs("Start_Time") = "" Then
                        cmbShift.Items.Add(New ListItem(IIf(rs("ShiftCd") = "RD", "Restday", "Holiday Off"), rs("ShiftCd")))
                    Else
                        cmbShift.Items.Add(New ListItem(rs("Start_Time") & "-" & rs("End_Time"), rs("ShiftCd")))
                    End If
                Loop
                rs.Close()
                'cmbShift.SelectedValue = "Please select shift..."
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to buil shift reference. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            Finally
                c.Close()
                cm.Dispose()
                c.Dispose()
            End Try

            vScript = "getEmpCd();"
        End If
    End Sub

    Protected Sub cmbShift_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbShift.Init
        'cmbShift.Attributes.Add("onchange", "return validate();")
    End Sub

    Protected Sub cmbShift_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbShift.SelectedIndexChanged
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand("select Descr,Start_Time,End_Time from py_shift where ShiftCd='" & _
            cmbShift.SelectedValue & "'", c)
        Dim rs As SqlClient.SqlDataReader

        c.Open()
        rs = cm.ExecuteReader
        txtNewDescr.Text = ""
        txtNewStart.Text = ""
        txtNewEnd.Text = ""
        If rs.Read Then
            txtNewDescr.Text = rs("Descr")
            txtNewStart.Text = IIf(IsDBNull(rs("Start_Time")), "", rs("Start_Time"))
            txtNewEnd.Text = IIf(IsDBNull(rs("End_Time")), "", rs("End_Time"))
        End If
        rs.Close()
        c.Close()
        c.Dispose()
        cm.Dispose()
    End Sub

    Protected Sub cmdSubmit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSubmit.Click
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim vChanged As Boolean = False
        Dim vData As String = txtEmpCdNdDate.Value
        Dim vFirst() As String
        Dim vSecond() As String
        Dim i As Integer = 0
        Dim j As Integer = 0

        If vData <> "" Then
            c.Open()
            cm.Connection = c
            vData = vData.Substring(0, vData.Length - 1)

            vFirst = vData.Split(",")

            For i = 0 To UBound(vFirst)
                vSecond = vFirst(i).Split("=")
                'If CDate(vSecond(1)) > CDate(Format(Now, "yyyy/MM/dd")) Then    'update only schedules of future dates
                'get old shift
                vChanged = False
                cm.CommandText = "SELECT * FROM py_emp_time_sched WHERE Emp_Cd='" & _
                    vSecond(0) & "' AND Date_Sched='" & Format(CDate(vSecond(1)), "yyyy/MM/dd") & "'"
                rs = cm.ExecuteReader
                If rs.Read Then
                    If rs("ShiftCd") <> cmbShift.SelectedValue Then
                        vChanged = True
                        If IsDBNull(rs("Start_Time")) Then
                            Session("oldval") = "Emp Id=" & vSecond(0) & _
                                "|Shift Date=" & Format(CDate(vSecond(1)), "MM/dd/yyyy") & _
                                "|Shift Code=" & rs("ShiftCd") & _
                                "|Start Time=" & _
                                "|End Time="
                        Else
                            Session("oldval") = "Emp Id=" & vSecond(0) & _
                                "|Shift Date=" & Format(CDate(vSecond(1)), "MM/dd/yyyy") & _
                                "|Shift Code=" & rs("ShiftCd") & _
                                "|Start Time=" & Format(CDate(rs("Start_Time")), "HH:mm:ss") & _
                                "|End Time=" & Format(CDate(rs("End_Time")), "HH:mm:ss")
                        End If
                    End If
                End If
                rs.Close()

                cm.CommandText = "DELETE FROM py_emp_time_sched WHERE Emp_Cd='" & _
                    vSecond(0) & "' AND Date_Sched='" & Format(CDate(vSecond(1)), "yyyy/MM/dd") & "'"

                cm.ExecuteNonQuery()

                If txtNewStart.Text.Trim <> "" Then
                    cm.CommandText = "INSERT INTO py_emp_time_sched (Emp_Cd,Date_Sched,Start_Time," & _
                        "End_Time,ShiftCd,Allow_Ot,HrsAllowed) VALUES ('" & vSecond(0) & "','" & _
                        Format(CDate(vSecond(1)), "yyyy/MM/dd") & "','1899/12/30 " & txtNewStart.Text & _
                        "','1899/12/30 " & txtNewEnd.Text & "','" & cmbShift.SelectedValue & "',1,0)"
                Else
                    cm.CommandText = "INSERT INTO py_emp_time_sched (Emp_Cd,Date_Sched,Start_Time," & _
                        "End_Time,ShiftCd,Allow_Ot,HrsAllowed) VALUES ('" & vSecond(0) & "','" & _
                        Format(CDate(vSecond(1)), "yyyy/MM/dd") & "',null,null,'" & cmbShift.SelectedValue & "',1,0)"
                End If
                cm.ExecuteNonQuery()

                If vChanged Then
                    Session("newval") = "Emp Id=" & vSecond(0) & _
                        "|Shift Date=" & Format(CDate(vSecond(1)), "MM/dd/yyyy") & _
                        "|Shift Code=" & cmbShift.SelectedValue & _
                        "|Start Time=" & txtNewStart.Text & _
                        "|End Time=" & txtNewEnd.Text

                    EventLog(Session("uid"), Request.ServerVariables("REMOTE_ADDR"), "NEXUS-SHIFT MODIFY", _
                        Session("oldval"), Session("newval"), "Employee ID: " & vSecond(0) & _
                        " Shift Schedule was modified", "Shift Schedule", c)
                End If
                'End If
            Next i

            vFirst = Nothing
            vSecond = Nothing

            c.Close()
            c.Dispose()
            Session.Remove("oldval")
            Session.Remove("newval")
            vScript = "alert('Successfully saved.Please click Refresh Button to view the changes'); opener.refresh(); window.close();"
        Else
            vScript = "alert('No Data to update.');window.close();"
        End If
    End Sub

    Protected Sub cmdNew_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdNew.Click
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim vChanged As Boolean = False
        Dim vData As String = txtEmpCdNdDate.Value
        Dim vFirst() As String
        Dim vSecond() As String
        Dim i As Integer = 0
        Dim j As Integer = 0

        If vData <> "" Then
            c.Open()
            cm.Connection = c
            vData = vData.Substring(0, vData.Length - 1)

            vFirst = vData.Split(",")

            For i = 0 To UBound(vFirst)
                vSecond = vFirst(i).Split("=")
                'get old shift
                vChanged = False
                cm.CommandText = "SELECT * FROM py_emp_time_sched WHERE Emp_Cd='" & _
                    vSecond(0) & "' AND Date_Sched='" & Format(CDate(vSecond(1)), "yyyy/MM/dd") & _
                    "' and ShiftCd='" & cmbShift.SelectedValue & "'"
                rs = cm.ExecuteReader
                If rs.Read Then
                    vScript = "alert('Work shift code already exist! Try using a different shift code.');"
                    rs.Close()
                    c.Close()
                    c.Dispose()
                    cm.Dispose()
                    Exit Sub
                End If
                rs.Close()

                If txtNewStart.Text.Trim <> "" Then
                    cm.CommandText = "INSERT INTO py_emp_time_sched (Emp_Cd,Date_Sched,Start_Time," & _
                        "End_Time,ShiftCd,Allow_Ot,HrsAllowed) VALUES ('" & vSecond(0) & "','" & _
                        Format(CDate(vSecond(1)), "yyyy/MM/dd") & "','1899/12/30 " & txtNewStart.Text & _
                        "','1899/12/30 " & txtNewEnd.Text & "','" & cmbShift.SelectedValue & "',1,0)"
                Else
                    cm.CommandText = "INSERT INTO py_emp_time_sched (Emp_Cd,Date_Sched,Start_Time," & _
                        "End_Time,ShiftCd,Allow_Ot,HrsAllowed) VALUES ('" & vSecond(0) & "','" & _
                        Format(CDate(vSecond(1)), "yyyy/MM/dd") & "',null,null,'" & cmbShift.SelectedValue & "',1,0)"
                End If
                cm.ExecuteNonQuery()

                'If vChanged Then
                '    Session("newval") = "Emp Id=" & vSecond(0) & _
                '        "|Shift Date=" & Format(CDate(vSecond(1)), "MM/dd/yyyy") & _
                '        "|Shift Code=" & cmbShift.SelectedValue & _
                '        "|Start Time=" & txtNewStart.Text & _
                '        "|End Time=" & txtNewEnd.Text

                '    EventLog(Session("uid"), Request.ServerVariables("REMOTE_ADDR"), "NEXUS-SHIFT MODIFY", _
                '        Session("oldval"), Session("newval"), "Employee ID: " & vSecond(0) & _
                '        " Shift Schedule was modified", "Shift Schedule", c)
                'End If
            Next i

            vFirst = Nothing
            vSecond = Nothing

            c.Close()
            c.Dispose()
            cm.Dispose()
            Session.Remove("oldval")
            Session.Remove("newval")
            vScript = "alert('Successfully saved.Please click Refresh Button to view the changes'); opener.refresh(); window.close();"
        Else
            vScript = "alert('No Data to update.');window.close();"
        End If
    End Sub
End Class
