﻿Imports denaro.fis
Partial Class importsummary
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Public vData As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            'Server.Transfer("index.aspx")
            'Exit Sub
        End If

        If Not CanRun(Session("caption"), Request.Item("id")) Then
            'Session("denied") = "1"
            'Server.Transfer("main.aspx")
            'Exit Sub
        End If

        If Not IsPostBack Then
            DataRefresh()
        End If
    End Sub

    Private Sub DataRefresh()
        Dim c As New SqlClient.SqlConnection
        Dim cm As New SqlClient.SqlCommand
        'Dim dr As SqlClient.SqlDataReader
        Dim da As SqlClient.SqlDataAdapter
        Dim ds As New DataSet
        Dim vSQL As String = ""
        c.ConnectionString = connStr

        Select Case Request.Item("mode")
            Case "Earnings" 'Onetime Earnings
                vSQL = "select distinct BatchNo, UploadedBy from py_incentives_dtl where BatchNo is not null order by BatchNo desc"
            Case "Deductions" 'Onetime Deductions
                vSQL = "select distinct BatchNo, UploadedBy from py_loan_hdr where BatchNo is not null order by BatchNo desc"
        End Select

        da = New SqlClient.SqlDataAdapter(vSQL, c)
        da.Fill(ds, "EMP")

        tblEmp.DataSource = ds.Tables("EMP")
        tblEmp.DataBind()
        da.Dispose()
        ds.Dispose()
    End Sub

    Protected Sub tblEmp_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles tblEmp.PageIndexChanging
        tblEmp.PageIndex = e.NewPageIndex
        DataRefresh()
    End Sub


    Protected Sub tblEmp_RowDeleting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewDeleteEventArgs) Handles tblEmp.RowDeleting
        vScript = "document.getElementById('trans-a').style.visibility = 'visible';" & _
                    "document.getElementById('divRemove').style.visibility = 'visible';"
    End Sub

    Protected Sub tblEmp_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tblEmp.SelectedIndexChanged
        Select Case Request.Item("mode")
            Case "Earnings" 'Onetime Earnings
                RefreshEarnings()
            Case "Deductions" 'Onetime Deductions
                RefreshDeductions()
        End Select
        ''Response.Write(tblEmp.SelectedRow.Cells(0).Text)
    End Sub

    Private Sub RefreshDeductions()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cmRef As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim rsRef As SqlClient.SqlDataReader
        Dim vClass As String = "odd"
        Dim vName As String = ""

        Dim vTtlLoanAmt As Decimal = 0
        Dim vTtlMPayment As Decimal = 0
        Dim vTtlLoanBal As Decimal = 0

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try
        cm.Connection = c
        cmRef.Connection = c

        vData = ""
        vData = "<tr class='titleBar'>" & _
                "<th>Emp. Id</th>" & _
                "<td>Employee Name</td>" & _
                "<th style='border-left: solid 1px #8b8b8a;'>Loan Code</th>" & _
                "<th style='border-left: solid 1px #8b8b8a;'>Loan Date</th>" & _
                "<th style='border-left: solid 1px #8b8b8a;'>Start Date</th>" & _
                "<th style='border-left: solid 1px #8b8b8a;'>Loan Amount</th>" & _
                "<th style='border-left: solid 1px #8b8b8a;'>Monthly Payment</th>" & _
                "<th style='border-left: solid 1px #8b8b8a;'>Loan Balance</th>" & _
                "<th style='border-left: solid 1px #8b8b8a;'>Remarks</th>" & _
            "</tr>"

        cm.CommandText = "select * from py_loan_hdr where BatchNo=" & tblEmp.SelectedRow.Cells(0).Text

        Try
            rs = cm.ExecuteReader
            Do While rs.Read
                cmRef.CommandText = "select Emp_Lname,Emp_Fname from py_emp_master where Emp_Cd='" & _
                    rs("Emp_Cd") & "'"
                rsRef = cmRef.ExecuteReader
                vName = "Unknown"
                If rsRef.Read Then
                    vName = rsRef("Emp_Lname") & ", " & rsRef("Emp_Fname")
                End If
                rsRef.Close()

                vData += "<tr class='" & vClass & "'>" & _
                    "<td class='labelC'>" & rs("Emp_Cd") & "</td>" & _
                    "<td class='labelL' style='border-left: solid 1px #8b8b8a;'>&nbsp;" & vName & "</td>" & _
                    "<td class='labelC' style='border-left: solid 1px #8b8b8a;'>" & rs("Loan_Cd") & "</td>" & _
                    "<td class='labelC' style='border-left: solid 1px #8b8b8a;'>" & Format(rs("Loan_Date"), "MM/dd/yyyy") & "</td>" & _
                    "<td class='labelC' style='border-left: solid 1px #8b8b8a;'>" & Format(rs("Start_Date"), "MM/dd/yyyy") & "</td>" & _
                    "<td class='labelR' style='border-left: solid 1px #8b8b8a;'>" & Format(rs("Amt_Loan"), "##,##0.00") & "&nbsp;</td>" & _
                    "<td class='labelR' style='border-left: solid 1px #8b8b8a;'>" & Format(rs("MonthlyAmort"), "##,##0.00") & "&nbsp;</td>" & _
                    "<td class='labelR' style='border-left: solid 1px #8b8b8a;'>" & Format(rs("Amt_Bal"), "##,##0.00") & "&nbsp;</td>" & _
                    "<td class='labelL' style='border-left: solid 1px #8b8b8a;'>&nbsp;" & rs("ProdDescr") & "</td></tr>"

                vTtlLoanAmt += rs("Amt_Loan")
                vTtlMPayment += rs("MonthlyAmort")
                vTtlLoanBal += rs("Amt_Bal")

                If vClass = "odd" Then
                    vClass = "even"
                Else
                    vClass = "odd"
                End If
            Loop
            vData += "<tr><td colspan='5' style='padding:5px;' class='labelR'><b>Total :<b />&nbsp;" & _
                "</td><td class='labelR'><b>" & Format(vTtlLoanAmt, "##,##0.00") & _
                "<b />&nbsp;</td><td class='labelR'><b>" & Format(vTtlMPayment, "##,##0.00") & _
                "<b />&nbsp;</td><td class='labelR'><b>" & Format(vTtlLoanBal, "##,##0.00") & "<b />&nbsp;</td><td>&nbsp;</td></tr>"


            rs.Close()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while retrieving the Loans Ledger. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            cm.Dispose()
            cmRef.Dispose()
            c.Dispose()
        End Try

    End Sub

    Private Sub RefreshEarnings()

        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim vClass As String = "odd"
        
        Dim vTtlInc_Amt As Decimal = 0

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try
        cm.Connection = c
        vData = ""
        vData = "<tr class='titleBar'>" & _
                    "<th style='border-left: solid 1px #8b8b8a;'>Emp. Id</th>" & _
                    "<th style='border-left: solid 1px #8b8b8a;'>Employee Name</th>" & _
                    "<th style='border-left: solid 1px #8b8b8a;'>Incentive Code</th>" & _
                    "<th style='border-left: solid 1px #8b8b8a;'>Incentive Amount</th>" & _
                    "<th style='border-left: solid 1px #8b8b8a;'>Start Cutoff Date</th>" & _
                    "<th style='border-left: solid 1px #8b8b8a;'>End Cut off Date</th>" & _
                "</tr>"

        cm.CommandText = "select Emp_Cd,Incentive_Amt,(select Emp_Lname+', '+Emp_Fname from py_emp_master " & _
            " where py_emp_master.Emp_Cd=py_incentives_dtl.Emp_Cd) as Emp_Name,FromDate,ToDate,Incentive_Cd " & _
            "from py_incentives_dtl where BatchNo=" & tblEmp.SelectedRow.Cells(0).Text

        Try
            rs = cm.ExecuteReader
            Do While rs.Read
              
                vData += "<tr class='" & vClass & "'>" & _
                    "<td class='labelC'>" & rs("Emp_Cd") & "</td>" & _
                    "<td class='labelL' style='border-left: solid 1px #8b8b8a;'>&nbsp;" & rs("Emp_Name") & "</td>" & _
                    "<td class='labelL' style='border-left: solid 1px #8b8b8a;'>&nbsp;" & rs("Incentive_Cd") & "</td>" & _
                    "<td class='labelR' style='border-left: solid 1px #8b8b8a;'>" & Format(rs("Incentive_Amt"), "##,##0.00") & "&nbsp;</td>" & _
                    "<td class='labelC' style='border-left: solid 1px #8b8b8a;'>" & Format(rs("FromDate"), "yyyy/MM/dd") & "</td>" & _
                    "<td class='labelC' style='border-left: solid 1px #8b8b8a;'>" & Format(rs("ToDate"), "yyyy/MM/dd") & "</td></tr>"

                vTtlInc_Amt += rs("Incentive_Amt")
                If vClass = "odd" Then
                    vClass = "even"
                Else
                    vClass = "odd"
                End If
            Loop
            rs.Close()

            vData += "<tr><td colspan='3' style='padding:5px;' class='labelR'><b>Total :<b />&nbsp;" & _
                "</td><td class='labelR'><b>" & Format(vTtlInc_Amt, "##,##0.00") & _
                "<b />&nbsp;</td><td class='labelR' colspan='3' ></td></tr>"

        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while retrieving the Incentives. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            cm.Dispose()
            c.Dispose()
        End Try

    End Sub

    Protected Sub cmdRemove_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdRemove.Click
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace("'", "").Replace(vbCrLf, "") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        cm.Connection = c

        Try

            Select Case Request.Item("mode")
                Case "Earnings" 'Onetime Earnings
                    cm.CommandText = "delete from py_incentives_dtl  where BatchNo=" & tblEmp.SelectedRow.Cells(0).Text
                    cm.ExecuteNonQuery()
                Case "Deductions" 'Onetime Deductions
                    cm.CommandText = "delete from py_loan_hdr where BatchNo=" & tblEmp.SelectedRow.Cells(0).Text
                    cm.ExecuteNonQuery()
            End Select
            vScript = "alert('Records successfully Deleted.');"

        Catch ex As SqlClient.SqlException
            vScript = "alert('An error has occurred while trying to retrieve the config table. Error is: " & _
                ex.Message.Replace("'", "").Replace(vbCrLf, "") & "');"
        Finally
            c.Close()
            cm.Dispose()
            c.Dispose()
        End Try
        DataRefresh()
    End Sub
End Class

