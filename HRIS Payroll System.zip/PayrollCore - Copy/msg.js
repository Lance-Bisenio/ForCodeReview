function displaymotd(elem){
	var motd ="";
	//motd = "Server Back Online. Server DownTime Schedule: Every Thursday 12:00AM - 1:00AM LocalTime." + 
	//" Details: NAC & MySQL Database Backup/Server Housekeeping. Thank you.";
	//motd = "Downtime will be run shortly. Please save any information now!";
	elem.innerHTML = motd;
}