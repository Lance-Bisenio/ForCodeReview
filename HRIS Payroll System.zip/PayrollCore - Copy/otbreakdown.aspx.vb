﻿Imports denaro.fis
Partial Class otbreakdown
    Inherits System.Web.UI.Page
    Public vScript As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Or Session("uid") = Nothing Then
            vScript = "alert('Your login session has expired. Please re-login again.'); window.close();"
            Exit Sub
        End If

        If Not IsPostBack Then
            Dim c As New SqlClient.SqlConnection(connStr)
            Dim cm As New SqlClient.SqlCommand
            Dim rs As SqlClient.SqlDataReader

            Try
                c.Open()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                c.Dispose()
                cm.Dispose()
                Exit Sub
            End Try

            cm.Connection = c

            lblPayDate.Text = Format(CDate(Request.Item("p")), "MM/dd/yyyy")
            cm.CommandText = "select * from py_report where Emp_Cd='" & Request.Item("e") & _
                "' and PayDate='" & Format(CDate(Request.Item("p")), "yyyy/MM/dd") & "'"

            Try
                rs = cm.ExecuteReader
                If rs.Read Then
                    lblEmp.Text = rs("Emp_Cd") & "=>" & rs("Name")
                    txtA1.Text = rs("A1")
                    txtA2.Text = rs("A2")
                    txtA3.Text = rs("A3")
                    txtA4.Text = rs("A4") + rs("NdReg")
                    txtB1.Text = rs("B1")
                    txtB2.Text = rs("B2")
                    txtB3.Text = rs("B3")
                    txtB4.Text = rs("B4")
                    txtC1.Text = rs("C1")
                    txtC2.Text = rs("C2")
                    txtC3.Text = rs("C3")
                    txtC4.Text = rs("C4")
                    txtD1.Text = rs("D1")
                    txtD2.Text = rs("D2")
                    txtD3.Text = rs("D3")
                    txtD4.Text = rs("D4")
                    txtE1.Text = rs("E1")
                    txtE2.Text = rs("E2")
                    txtE3.Text = rs("E3")
                    txtE4.Text = rs("E4")
                    txtF1.Text = rs("F1")
                    txtF2.Text = rs("F2")
                    txtF3.Text = rs("F3")
                    txtF4.Text = rs("F4")
                    txtTotal.Text = rs("A1") + rs("A2") + rs("A3") + rs("A4") + rs("NdReg") + _
                        rs("B1") + rs("B2") + rs("B3") + rs("B4") + _
                        rs("C1") + rs("C2") + rs("C3") + rs("C4") + _
                        rs("D1") + rs("D2") + rs("D3") + rs("D4") + _
                        rs("E1") + rs("E2") + rs("E3") + rs("E4") + _
                        rs("F1") + rs("F2") + rs("F3") + rs("F4") + _
                        rs("G1") + rs("G2") + rs("G3")
                End If
                rs.Close()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to retrieve data. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            Finally
                c.Close()
                cm.Dispose()
                c.Dispose()
            End Try
        End If
    End Sub
End Class
