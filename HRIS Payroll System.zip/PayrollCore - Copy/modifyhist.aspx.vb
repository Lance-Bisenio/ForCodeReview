Imports denaro
Partial Class modifyhist
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Dim c As New sqlclient.sqlconnection
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If
        If Not IsPostBack Then
            Dim cm As New sqlclient.sqlcommand
            Dim dr As sqlclient.sqldatareader
            txtEmpCd.Text = Session("empid")
            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c
            cm.CommandText = "select Emp_Lname,Emp_Fname from py_emp_master where Emp_Cd='" & txtEmpCd.Text & "'"
            dr = cm.ExecuteReader
            lblcaption.text = "Add/Modify Employment History for "
            If dr.Read Then
                lblcaption.Text += dr("Emp_Lname") & ", " & dr("Emp_Fname")
            End If
            dr.Close()

            If Session("mode") = "e" Or Session("mode") = "v" Then
                cm.CommandText = "select * from hr_emp_employment_hist where Emp_Id='" & txtEmpCd.Text & _
                    "' and From_Date='" & Format(CDate(Session("seqid")), "yyyy/MM/dd") & "'"
                dr = cm.ExecuteReader
                If dr.Read Then
                    txtFrom.Text = IIf(IsDBNull(dr("From_Date")), "", dr("From_Date"))
                    txtTo.Text = IIf(IsDBNull(dr("To_Date")), "", dr("To_Date"))
                    txtEmployerName.Text = IIf(IsDBNull(dr("Employer")), "", dr("Employer"))
                    txtNature.Text = IIf(IsDBNull(dr("Nature")), "", dr("Nature"))
                    txtAccomplishments.Text = IIf(IsDBNull(dr("Accomplishments")), "", dr("Accomplishments"))
                    txtResponsibilities.Text = IIf(IsDBNull(dr("Function")), "", dr("Function"))
                    txtSalary.Text = IIf(IsDBNull(dr("Annual_Salary")), "0", dr("Annual_Salary"))
                    txtEmpContact.Text = IIf(IsDBNull(dr("EmployerNo")), "", dr("EmployerNo"))
                    txtAddress.Text = IIf(IsDBNull(dr("Address")), "", dr("Address"))
                    txtPosition.Text = IIf(IsDBNull(dr("Position")), "", dr("Position"))
                    'chkGovt.Checked = IIf(IsDBNull(dr("GovServ")), False, dr("GovServ"))
                End If
                dr.Close()
                If Session("mode") = "v" Then 'freeze fields
                    txtFrom.ReadOnly = True
                    txtTo.ReadOnly = True
                    txtEmployerName.ReadOnly = True
                    txtNature.ReadOnly = True
                    txtAccomplishments.ReadOnly = True
                    txtResponsibilities.ReadOnly = True
                    txtSalary.ReadOnly = True
                    txtAddress.ReadOnly = True
                    txtPosition.ReadOnly = True
                    'chkGovt.Enabled = False
                    txtEmpContact.ReadOnly = False
                End If
            End If
            cm.Dispose()
            c.Close()
        End If
    End Sub

    Protected Sub cmdCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        Session.Remove("empid")
        Session.Remove("seqid")
        'If Session("mode") = "v" Then
        Session.Remove("mode")
        vScript = "window.close();"
        'Else
        'Session.Remove("mode")
        'Server.Transfer("emp.aspx")
        'End If
    End Sub
    Private Function CleanVar(ByVal pStr As String) As String
        Return pStr.Replace("'", "''")
    End Function
    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        If Page.IsValid Then
            Dim cm As New sqlclient.sqlcommand
            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c
            If Session("mode") = "e" Then 'edit mode
                cm.CommandText = "update hr_emp_employment_hist set From_Date='" & _
                    Format(CDate(txtFrom.Text), "yyyy/MM/dd") & _
                    "',To_Date='" & Format(CDate(txtTo.Text), "yyyy/MM/dd") & _
                    "',Employer='" & CleanVar(txtEmployerName.Text) & _
                    "',Position='" & CleanVar(txtPosition.Text) & _
                    "',EmployerNo='" & CleanVar(txtEmpContact.Text) & _
                    "',Annual_Salary=" & txtSalary.Text & _
                    ",Accomplishments='" & CleanVar(txtAccomplishments.Text) & _
                    "',[Function]='" & CleanVar(txtResponsibilities.Text) & _
                    "',Address='" & CleanVar(txtAddress.Text) & _
                    "',Reasonforleaving='" & CleanVar(txtReason.Text) & _
                    "',Supervisor='" & CleanVar(txtSupervisor.Text) & _
                    "',Nature='" & CleanVar(txtNature.Text) & _
                    "' where Emp_Id='" & txtEmpCd.Text & "' and From_Date='" & _
                    Format(CDate(Session("seqid")), "yyyy/MM/dd") & "'"
            Else                          'add mode
                cm.CommandText = "insert into hr_emp_employment_hist (Emp_Id,From_Date,To_Date,Employer," & _
                    "Position,Annual_Salary,Accomplishments,[Function],Address,Nature,EmployerNo,Supervisor,Reasonforleaving) values ('" & _
                    txtEmpCd.Text & "','" & Format(CDate(txtFrom.Text), "yyyy/MM/dd") & "','" & _
                    Format(CDate(txtTo.Text), "yyyy/MM/dd") & "','" & CleanVar(txtEmployerName.Text) & _
                    "','" & CleanVar(txtPosition.Text) & "'," & txtSalary.Text & ",'" & CleanVar(txtAccomplishments.Text) & _
                    "','" & CleanVar(txtResponsibilities.Text) & "','" & CleanVar(txtAddress.Text) & "','" & _
                    CleanVar(txtNature.Text) & "','" & CleanVar(txtEmpContact.Text) & "','" & _
                    CleanVar(txtSupervisor.Text) & "','" & txtReason.Text & "')"
            End If
            cm.ExecuteNonQuery()
            vScript = "alert('Changes where successfully saved.');"
        End If
    End Sub

    Protected Sub vldDate_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles vldDate.ServerValidate
        vldDate.ErrorMessage = "Invalid date format."
        If txtFrom.Text = "" Then
            vScript = "alert('From date field should not be empty.');"
            args.IsValid = False
            Exit Sub
        End If
        If txtTo.Text = "" Then
            vScript = "alert('To date field should not be empty.');"
            args.IsValid = False
            Exit Sub
        End If
        If Not IsDate(txtFrom.Text) Then
            vScript = "alert('The From date field has an invalid date format.');"
            args.IsValid = False
            Exit Sub
        End If
        If Not IsDate(txtTo.Text) Then
            vScript = "alert('The To date field has an invalid date format.');"
            args.IsValid = False
            Exit Sub
        End If
        If txtEmployerName.Text = "" Then
            vScript = "alert('Employer name field should not be empty.');"
            vldDate.ErrorMessage = "Employer name field should not be empty."
            args.IsValid = False
            Exit Sub
        End If
        If txtPosition.Text = "" Then
            vScript = "alert('Position field should not be empty.');"
            vldDate.ErrorMessage = "Position field should not be empty."
            args.IsValid = False
            Exit Sub
        End If
        If txtSalary.Text = "" Then
            vScript = "alert('Annual salary field should not be empty.');"
            vldDate.ErrorMessage = "Annual salary field should not be empty."
            args.IsValid = False
            Exit Sub
        End If
        If Not IsNumeric(txtSalary.Text) Then
            vScript = "alert('Annual salary field has an invalid numeric format.');"
            vldDate.ErrorMessage = "Annual salary field has an invalid numeric format."
            args.IsValid = False
            Exit Sub
        End If
        args.IsValid = True
    End Sub
End Class
