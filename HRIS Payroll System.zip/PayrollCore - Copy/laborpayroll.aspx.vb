Imports denaro.fis
Partial Class laborpayroll
    Inherits System.Web.UI.Page
    Public vList As String = ""
    Public vScript As String = ""
    Protected Sub cmdReturn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.Click
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Session("returnaddr") = "dailylog.aspx"
            Server.Transfer("index.aspx")
        End If
        If Not CanRun(Session("caption"), Request.Item("id")) Then
            Session("denied") = "1"
            Server.Transfer("main.aspx")
            Exit Sub
        End If

        If Not IsPostBack Then
           

            Dim c As New SqlClient.SqlConnection(connStr)
            Dim cm As New SqlClient.SqlCommand("delete from py_time_log where Emp_Cd is null or Emp_Cd=''", c)

            c.Open()
            cm.ExecuteNonQuery()
            c.Close()
            c.Dispose()
            cm.Dispose()

            lblCaption.Text = "Labor Logs"
            Dim iCtr As Integer

            For iCtr = Now.Year - 5 To Now.Year  'add year
                cmbYrFr.Items.Add(iCtr)
                cmbYrTo.Items.Add(iCtr)
            Next iCtr
            'now set the default values
            cmbMonthFr.SelectedValue = Now.Month
            cmbMonthTo.SelectedValue = Now.Month
            cmbYrFr.SelectedValue = Now.Year
            cmbYrTo.SelectedValue = Now.Year
            For iCtr = 1 To MonthEND(Now).Day       'add days
                cmbDayFr.Items.Add(iCtr)
                cmbDayTo.Items.Add(iCtr)
            Next iCtr
            cmbDayFr.SelectedValue = 1
            cmbDayTo.SelectedValue = Now.Day

            'now build the reference code
            BuildCombo("select Rc_Cd,Descr from rc where exists (select User_Id from rights_list where User_Id='" & _
              Session("uid") & "' and property='rc' and Property_Value=Rc_Cd) order by Descr", cmbRC)
            BuildCombo("select AgencyCd,AgencyName from agency where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='agency' and Property_Value=AgencyCd) order by AgencyName", cmbOfc)
            BuildCombo("select Div_Cd,Descr from hr_div_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='division' and Property_Value=Div_Cd) order by Descr", cmbDiv)
            BuildCombo("select Dept_Cd,Descr from hr_dept_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='department' and Property_Value=Dept_Cd) order by Descr", cmbDept)
            BuildCombo("select Section_Cd,Descr from hr_section_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='section' and Property_Value=Section_Cd) order by Descr", cmbSection)
            BuildCombo("select Unit_Cd,Descr from hr_unit_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='unit' and Property_Value=Unit_Cd) order by Descr", cmbUnit)
            BuildCombo("select EmploymentType,Descr from hr_employment_type where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='employmenttype' and Property_Value=EmploymentType) order by Descr", cmbRank)
            BuildCombo("select Status_Code,Descr from py_employee_stat order by Descr", cmbEmpStatus)

            cmbRC.Items.Add("All")
            cmbRC.SelectedValue = "All"
            cmbOfc.Items.Add("All")
            cmbOfc.SelectedValue = "All"
            cmbDiv.Items.Add("All")
            cmbDiv.SelectedValue = "All"
            cmbDept.Items.Add("All")
            cmbDept.SelectedValue = "All"
            cmbSection.Items.Add("All")
            cmbSection.SelectedValue = "All"
            cmbUnit.Items.Add("All")
            cmbUnit.SelectedValue = "All"
            cmbRank.Items.Add("All")
            cmbRank.SelectedValue = "All"
            cmbEmpStatus.Items.Add("All")
            cmbEmpStatus.SelectedValue = "All"
            'DataRefresh(Session("letter"))
        End If
    End Sub
    Private Sub PopulateDays(ByVal pMonth As Integer, ByVal pYear As Integer, ByRef pCombo As WebControls.DropDownList)
        pCombo.Items.Clear()
        For iCtr As Integer = 1 To CDate(pMonth & "/1/" & pYear).AddDays(-1).Day        'add days
            pCombo.Items.Add(iCtr)
        Next iCtr
    End Sub

    Protected Sub cmbMonthFr_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbMonthFr.SelectedIndexChanged
        PopulateDays(cmbMonthFr.SelectedValue, cmbYrFr.SelectedValue, cmbDayFr)
    End Sub

    Protected Sub cmbMonthTo_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbMonthTo.SelectedIndexChanged
        PopulateDays(cmbMonthTo.SelectedValue, cmbYrTo.SelectedValue, cmbDayTo)
    End Sub

    Protected Sub cmdSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSearch.Click
        DataRefresh(txtSearch.Text)
    End Sub
    Protected Sub DataRefresh(ByVal pLetter As String)
        Dim c As New sqlclient.sqlConnection(connStr)
        Dim cm As New sqlclient.sqlCommand
        Dim dr As sqlclient.sqlDataReader
        Dim da As sqlclient.sqlDataAdapter
        Dim ds As New DataSet
        Dim vFilter As String = " where " & cmbType.SelectedValue & " like '" & pLetter & "%' "
        Dim vIdList As String = ""
        Dim vSql As String = ""
        Dim vQuery As String = ""

        If tblEmp.SelectedIndex >= 0 Then
            tblEmp.SelectedIndex = 0
        End If

        Select Case Val(cmbStatus.SelectedValue)
            Case 1  'active employees only
                vFilter += " and Date_Resign is null AND Date_Retired IS NULL AND DateHold IS NULL AND DateDismissed IS NULL "
                vQuery += " where Date_Resign is null AND Date_Retired IS NULL AND DateHold IS NULL AND DateDismissed IS NULL "
            Case 0  'inactive employees only
                vFilter += " and (Date_Resign is not null OR Date_Retired IS NOT NULL OR DateHold IS NOT NULL Or DateDismissed IS NOT NULL) "
                vQuery += " where (Date_Resign is not null OR Date_Retired IS NOT NULL OR DateHold IS NOT NULL Or DateDismissed IS NOT NULL) "
            Case 3 'Both
                vQuery += " where Emp_Cd IS NOT NULL"
        End Select

        If cmbEmpStatus.SelectedValue <> "All" Then 'filter by employment status
            vFilter += " and Emp_Status='" & cmbEmpStatus.SelectedValue & "' "
            vQuery += " and Emp_Status='" & cmbEmpStatus.SelectedValue & "' "
        End If

        If cmbRC.SelectedValue <> "All" Then   'filter by cost center
            vFilter += " and Rc_Cd='" & cmbRC.SelectedValue & "' "
            vQuery += " and Rc_Cd='" & cmbRC.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='rc' and Property_Value=Rc_Cd) "
            vQuery += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='rc' and Property_Value=Rc_Cd) "
        End If

        If cmbOfc.SelectedValue <> "All" Then        'filter by office/agency
            vFilter += " and Agency_Cd='" & cmbOfc.SelectedValue & "' "
            vQuery += " and Agency_Cd='" & cmbOfc.SelectedValue & "' "
        Else
            vFilter += "  and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='agency' and Property_Value=Agency_Cd) "
            vQuery += "  and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='agency' and Property_Value=Agency_Cd) "
        End If
        If cmbDiv.SelectedValue <> "All" Then      'filter by division
            vFilter += " and Divcd='" & cmbDiv.SelectedValue & "' "
            vQuery += " and Divcd='" & cmbDiv.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='division' and Property_Value=DivCd) "
            vQuery += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='division' and Property_Value=DivCd) "
        End If
        If cmbDept.SelectedValue <> "All" Then  'filter by departments
            vFilter += " and DeptCd='" & cmbDept.SelectedValue & "' "
            vQuery += " and DeptCd='" & cmbDept.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='department' and Property_Value=DeptCd) "
            vQuery += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='department' and Property_Value=DeptCd) "
        End If
        If cmbSection.SelectedValue <> "All" Then 'filter by section
            vFilter += " and SectionCd='" & cmbSection.SelectedValue & "' "
            vQuery += " and SectionCd='" & cmbSection.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='section' and Property_Value=SectionCd) "
            vQuery += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='section' and Property_Value=SectionCd) "
        End If
        If cmbUnit.SelectedValue <> "All" Then  'filter by units
            vFilter += " and UnitCd='" & cmbUnit.SelectedValue & "' "
            vQuery += " and UnitCd='" & cmbUnit.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='unit' and Property_Value=UnitCd) "
            vQuery += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='unit' and Property_Value=UnitCd) "
        End If
        If cmbRank.SelectedValue <> "All" Then 'filter by employment types
            vFilter += " and EmploymentType='" & cmbRank.SelectedValue & "' "
            vQuery += " and EmploymentType='" & cmbRank.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='employmenttype' and Property_Value=EmploymentType) "
            vQuery += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='employmenttype' and Property_Value=EmploymentType) "
        End If


        vSql = "select Emp_Cd,Emp_Lname,Emp_Fname,Emp_Mname,round(Rate_Day,2) as Rate_Day, " & _
            "CAST(ROUND((Rate_Day / Req_Hrs_Day),2) AS DECIMAL(18,2)) as Hourly_Rate from py_emp_master " & vFilter & _
            " order by Emp_Lname,Emp_Fname,Emp_Mname"

        da = New sqlclient.sqldataadapter(vSql, c)
        da.Fill(ds, "EmpMaster")
        tblEmp.DataSource = ds.Tables("EmpMaster")
        tblEmp.DataBind()

        ds.Dispose()
        da.Dispose()

        c.Open()
        cm.Connection = c
        cm.CommandText = "select distinct substring(Emp_Lname,1,1) as Letters from py_emp_master " & vQuery
        dr = cm.ExecuteReader
        EnableAll()
        Do While dr.Read
            SetLetters(dr("Letters"))
        Loop
        dr.Close()

        cm.CommandText = "select Emp_Cd from py_emp_master " & vQuery & " order by Emp_Lname,Emp_Fname"
        dr = cm.ExecuteReader
        vIdList = ""

        dr.Close()
        cm.Dispose()
        c.Close()
        c.Dispose()
    End Sub
    Protected Sub cmdA_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdA.Click, _
       cmdB.Click, cmdC.Click, cmdD.Click, cmdE.Click, cmdF.Click, cmdG.Click, cmdH.Click, cmdI.Click, _
       cmdJ.Click, cmdK.Click, cmdL.Click, cmdM.Click, cmdN.Click, cmdO.Click, cmdP.Click, cmdQ.Click, _
       cmdR.Click, cmdS.Click, cmdT.Click, cmdU.Click, cmdV.Click, cmdW.Click, cmdX.Click, cmdY.Click, cmdZ.Click
        txtSearch.Text = CType(sender, LinkButton).Text
        tblEmp.SelectedIndex = -1
        DataRefresh(txtSearch.Text)
    End Sub
    Private Sub EnableAll(Optional ByVal pState As Boolean = False)
        cmdA.Visible = pState : cmdB.Visible = pState : cmdC.Visible = pState : cmdD.Visible = pState
        cmdE.Visible = pState : cmdF.Visible = pState : cmdG.Visible = pState : cmdH.Visible = pState
        cmdI.Visible = pState : cmdJ.Visible = pState : cmdK.Visible = pState : cmdL.Visible = pState
        cmdM.Visible = pState : cmdN.Visible = pState : cmdO.Visible = pState : cmdP.Visible = pState
        cmdQ.Visible = pState : cmdR.Visible = pState : cmdS.Visible = pState : cmdT.Visible = pState
        cmdU.Visible = pState : cmdV.Visible = pState : cmdW.Visible = pState : cmdX.Visible = pState
        cmdY.Visible = pState : cmdZ.Visible = pState
    End Sub
    Private Sub SetLetters(ByVal pLetter As String)
        Select Case LCase(pLetter)
            Case "a"
                cmdA.Visible = True
            Case "b"
                cmdB.Visible = True
            Case "c"
                cmdC.Visible = True
            Case "d"
                cmdD.Visible = True
            Case "e"
                cmdE.Visible = True
            Case "f"
                cmdF.Visible = True
            Case "g"
                cmdG.Visible = True
            Case "h"
                cmdH.Visible = True
            Case "i"
                cmdI.Visible = True
            Case "j"
                cmdJ.Visible = True
            Case "k"
                cmdK.Visible = True
            Case "l"
                cmdL.Visible = True
            Case "m"
                cmdM.VISIBLE = True
            Case "n"
                cmdN.Visible = True
            Case "o"
                cmdO.Visible = True
            Case "p"
                cmdP.Visible = True
            Case "q"
                cmdQ.Visible = True
            Case "r"
                cmdR.Visible = True
            Case "s"
                cmdS.Visible = True
            Case "t"
                cmdT.Visible = True
            Case "u"
                cmdU.Visible = True
            Case "v"
                cmdV.Visible = True
            Case "w"
                cmdW.Visible = True
            Case "x"
                cmdX.Visible = True
            Case "y"
                cmdY.Visible = True
            Case "z"
                cmdZ.Visible = True
        End Select
    End Sub

    Protected Sub tblEmp_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles tblEmp.PageIndexChanging
        tblEmp.PageIndex = e.NewPageIndex
        DataRefresh(txtSearch.Text)
    End Sub

    Protected Sub tblEmp_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tblEmp.SelectedIndexChanged
        txtHourly.Value = tblEmp.SelectedRow.Cells(4).Text / 8
        RefreshDetail()
    End Sub
    Private Sub RefreshDetail()
        Dim c As New sqlclient.sqlConnection
        'Dim cDtl As New sqlclient.sqlConnection
        Dim cm As New sqlclient.sqlCommand
        Dim dr As sqlclient.sqlDataReader
        Dim vDate As Date = CDate(cmbMonthTo.SelectedValue & "/" & cmbDayTo.SelectedValue & "/" & cmbYrTo.SelectedValue)
        Dim vDateFr As Date = CDate(cmbMonthFr.SelectedValue & "/" & cmbDayFr.SelectedValue & "/" & cmbYrFr.SelectedValue)
        Dim vEmpId As String = tblEmp.SelectedRow.Cells(0).Text
        Dim cmDtl As New sqlclient.sqlCommand
        Dim drDtl As sqlclient.sqlDataReader
        Dim vHrs As Single = 0
        Dim vAmt As Single = 0
        Dim vTable As String = "py_emp_time_log"
        Dim vClass As String = "even"
        c.ConnectionString = connStr
        'cDtl.ConnectionString = connStr
        'cDtl.Open()
        c.Open()
        cm.Connection = c
        cmDtl.Connection = c

        cm.CommandText = "select Hrs_Rendered,AmtConv from " & vTable & " where Emp_Cd='" & _
            vEmpId & "' and TranDate='" & Format(vDate, "yyyy/MM/dd") & "' and TranCd='BASIC'"
        dr = cm.ExecuteReader
        If dr.Read Then
            txtReg.Text = dr("Hrs_Rendered")
            txtRegAmt.Text = dr("AmtConv")
        End If
        dr.Close()

        cm.CommandText = "select OtCd,Descr,OtPer from py_ot_ref"
        dr = cm.ExecuteReader
        vList = ""
        Do While dr.Read

            cmDtl.CommandText = "select Hrs_Rendered,AmtConv from " & vTable & " where Emp_Cd='" & _
                            vEmpId & "' and TranDate='" & Format(vDate, "yyyy/MM/dd") & "' and TranCd='" & _
                            dr("OtCd") & "' "

            drDtl = cmDtl.ExecuteReader
            vHrs = 0 : vAmt = 0
            If drDtl.Read Then
                vHrs = IIf(IsDBNull(drDtl("Hrs_Rendered")), 0, drDtl("Hrs_Rendered"))
                vAmt = IIf(IsDBNull(drDtl("AmtConv")), 0, drDtl("AmtConv"))
            End If
            drDtl.Close()
            vList += "<tr class='" & vClass & "'>" & _
                     "<td style='width: 96px; height: 24px;' class='labelL'>" & dr("OtCd") & "</td>" & _
                     "<td style='width: 226px; height: 24px;' class='labelL'>" & dr("Descr") & "</td>" & _
                     "<td style='width: 66px; height: 24px;'>" & _
                     "<input id='txtFactor" & dr("OtCd") & "' class='labelR' style='width: 24px' type='text' readonly='readonly' value='" & _
                     IIf(IsDBNull(dr("OtPer")), 0, dr("OtPer")) & "' /></td>" & _
                     "<td style='width: 80px; height: 24px;'>" & _
                     "<input id='txtHr" & dr("OtCd") & "' name='txtHr" & dr("OtCd") & "' class='labelR' style='width: 24px' " & _
                     "type='text' onblur='calc(this);' value='" & vHrs & "' /></td>" & _
                     "<td style='width: 87px; height: 24px;'>" & _
                    "<input id='txtVal" & dr("OtCd") & "' class='labelR' style='width: 48px' type='text' readonly='readonly' " & _
                    "value='" & Math.Round(vAmt, 2) & "'/></td></tr>"
            vClass = IIf(vClass = "even", "odd", "even")
        Loop
        dr.Close()
        cmDtl.Dispose()
        cm.Dispose()
        c.Close()
        'cDtl.Close()
    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        Dim vEmpid As String = tblEmp.SelectedRow.Cells(0).Text
        Dim vDate As Date = CDate(cmbMonthTo.SelectedValue & "/" & cmbDayTo.SelectedValue & "/" & cmbYrTo.SelectedValue)
        Dim vRateHr As Single = Val(tblEmp.SelectedRow.Cells(5).Text)
        Dim c As New sqlclient.sqlConnection(connStr)
        'Dim cQry As New sqlclient.sqlConnection
        Dim cm As New sqlclient.sqlCommand
        Dim cmQry As New sqlclient.sqlCommand
        Dim dr As sqlclient.sqlDataReader
        Dim vHrs As Single = 0
        Dim vAmt As Single = 0
        Dim vTable As String = "py_emp_time_log"

        c.Open()
        cm.Connection = c
        cmQry.Connection = c
        'clear existing data first
        cm.CommandText = "delete from py_emp_time_log where Emp_Cd='" & vEmpid & "' and TranDate='" & Format(vDate, "yyyy/MM/dd") & "'"
        cm.ExecuteNonQuery()

        vHrs = Val(Request.Form("txtReg"))
        vAmt = Math.Round(vHrs * vRateHr, 2)
        cm.CommandText = "insert into " & vTable & " (Emp_Cd,TranDate,TranCd,Hrs_Rendered,AmtConv,Reason,EffectivityDate) values ('" & _
            vEmpid & "','" & Format(vDate, "yyyy/MM/dd") & "','BASIC'," & vHrs & "," & vAmt & ",'Edited','" & Format(vDate, "yyyy/MM/dd") & "')"
        cm.ExecuteNonQuery()

        cm.CommandText = "select OtCd,OtPer from py_ot_ref"
        dr = cm.ExecuteReader
        Do While dr.Read
            vHrs = Val(Request.Form("txtHr" & dr("OtCd")))
            vAmt = IIf(IsDBNull(dr("OtPer")), 0, dr("OtPer")) * vHrs * vRateHr
            If vHrs <> 0 Then
                cmQry.CommandText = "insert into " & vTable & " (Emp_Cd,TranDate,TranCd,Hrs_Rendered,AmtConv,Reason,EffectivityDate) values ('" & _
                    vEmpid & "','" & Format(vDate, "yyyy/MM/dd") & "','" & dr("OtCd") & "'," & vHrs & "," & vAmt & ",'Edited','" & Format(vDate, "yyyy/MM/dd") & "')"

                cmQry.ExecuteNonQuery()
            End If
        Loop
        dr.Close()
        cm.Dispose()

        cmQry.Dispose()
        c.Close()
        vScript = "alert('Changes were saved successfully.');"
    End Sub
End Class
