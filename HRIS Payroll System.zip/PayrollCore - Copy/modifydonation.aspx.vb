Imports System.Data
Imports denaro.fis
Partial Class modifydonation
    Inherits System.Web.UI.Page
    Public vScript As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            vScript = "alert('Session has expired!'); opener.location='index.aspx'; window.close();"
            Exit Sub
        End If
        If Session("descr") = "" And Request.Item("mode") = "e" Then
            vScript = "alert('You must first select a record to edit.'); widow.close();"
            Exit Sub
        End If
        If Session("category") = "" Then
            vScript = "alert('You must first select  category.'); window.close();"
            Exit Sub
        End If
        If Not IsPostBack Then
            lblCaption.Text = "Add/Modify Announcement"
            If Session("category") = "PRIVATE" Then
                cmdSave.Text = "Save & Next"
            End If
            If Request.Item("mode") = "e" Then  'edit mode
                Dim c As New sqlclient.sqlconnection(connStr)
                Dim cm As New SqlClient.SqlCommand("select * from links where Category='" & Session("category") & "' and SeqId=" & _
                    Session("descr").ToString.Replace("'", "''"), c)
                Dim rs As sqlclient.sqldatareader

                Try
                    c.Open()
                    rs = cm.ExecuteReader
                    If rs.Read Then
                        txtDescr.Text = rs("Descr")
                        txtExpiry.Text = IIf(IsDBNull(rs("ExpiryDate")), "", rs("ExpiryDate"))
                        txtContent.Text = IIf(IsDBNull(rs("Remarks")), "", rs("Remarks"))
                        txtUpload.Text = IIf(IsDBNull(rs("ImageFile")), "", rs("ImageFile"))
                    End If
                    rs.Close()
                    c.Close()
                    cm.Dispose()
                    c.Dispose()
                Catch ex As sqlclient.sqlException
                    vScript = "alert('An error has occurred while trying to retrieve the data. Error is: " & _
                        ex.Message.Replace("'", "") & "');"
                End Try
            End If
        End If
    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        If Page.IsValid Then
            Dim c As New sqlclient.sqlConnection(connStr)
            Dim cm As New sqlclient.sqlCommand
            Dim vDate As String = "null"
            Dim vUpload As String = IIf(Request.Form("txtUpload") = "", "null", "'" & Request.Form("txtUpload") & "'")
            If txtExpiry.Text <> "" Then
                vDate = "'" & Format(CDate(txtExpiry.Text), "yyyy/MM/dd") & "'"
            End If

            cm.Connection = c
            If Request.Item("mode") = "e" Then    'update mode
                cm.CommandText = "update links set Descr='" & txtDescr.Text.Replace("'", "''") & "',ExpiryDate=" & _
                    vDate & ",Hyperlink='donate.aspx?d=" & txtDescr.Text.Replace("'", "''") & _
                    "',Remarks='" & txtContent.Text.Replace("'", "''") & "',ImageFile=" & _
                    vUpload & " where SeqId=" & Session("descr").ToString.Replace("'", "''") & _
                    " and Category='" & Session("category") & "'"
            Else
                cm.CommandText = "insert into links (Hyperlink,GeneralInfo,Descr,Category,ExpiryDate," & _
                    "DateFiled,Remarks,ImageFile) values (" & "'donate.aspx?d=" & txtDescr.Text.Replace("'", "''") & _
                    "',0,'" & txtDescr.Text.Replace("'", "''") & "','" & Session("category") & "'," & vDate & ",'" & _
                    Format(Now, "yyyy/MM/dd HH:mm:ss") & "','" & txtContent.Text.Replace("'", "''") & "'," & _
                    vUpload & ")"
            End If
            Try
                c.Open()
                cm.ExecuteNonQuery()
                c.Close()
                cm.Dispose()
                c.Dispose()
                If Session("category") = "PRIVATE" Then
                    Server.Transfer("emplist.aspx")
                Else
                    vScript = "alert('Changes were successfully saved!'); opener.document.form1.submit(); window.close();"
                End If

            Catch ex As sqlclient.sqlException
                vScript = "alert('An error has occurred while trying to save your changes. Error is: " & _
                    ex.Message.Replace("'", "") & "');"
            End Try
        End If
    End Sub

    Protected Sub CustomValidator1_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles CustomValidator1.ServerValidate
        If txtExpiry.Text <> "" Then
            args.IsValid = IsDate(txtExpiry.Text)
        Else
            args.IsValid = True
        End If
    End Sub
End Class
