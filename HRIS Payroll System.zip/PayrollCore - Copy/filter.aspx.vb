Imports System.Data
Imports denaro.fis
Partial Class filter

    Inherits System.Web.UI.Page
    Public vList As String
    Public vScript As String = ""

    Protected Sub cmbFilters_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbFilters.SelectedIndexChanged
        Session("idx") = -1
        RefreshList()
    End Sub

    Private Sub RefreshList()
        Select Case cmbFilters.SelectedValue
            Case 1  'employee status
                buildStatus("select Status_Code, Descr from py_employee_stat")
            Case 2  'by rank/type
                buildStatus("select EmploymentType, Descr from hr_employment_type")
            Case 3  'by Gender
                BuildGender()
            Case 4  'by Civil Status
                buildStatus("select Civil_Cd, Descr from py_civil_ref")
            Case 5  'Age Group
                BuildAge()
            Case 6  'Number of year in Service
                BuildAge()
            Case 7  'Work Group
                buildStatus("select distinct(Alt_Codes) as Alt_Codes, Alt_Codes from hr_div_ref where Alt_Codes is not null")
            Case 8  'Geography

            Case 9  'Company
                buildStatus("select AgencyCd, AgencyName from agency")
            Case 10 'Group
                buildStatus("select Div_Cd, Descr from hr_div_ref")
            Case 11 'Division/Area
                buildStatus("select Dept_Cd, Descr from hr_dept_ref")
            Case 12 'Deptartment
                buildStatus("select Section_Cd, Descr from hr_section_ref")
            Case 13 'Section/Branch
                buildStatus("select Unit_Cd, Descr from hr_unit_ref")
        End Select
    End Sub

    Private Sub buildStatus(ByVal pSQL As String)
        Dim c As New sqlclient.sqlconnection
        Dim cm As New sqlclient.sqlcommand
        Dim rs As sqlclient.sqldatareader

        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c
        cm.CommandText = pSQL
        rs = cm.ExecuteReader

        rdoOption.Items.Clear()
        rdoOption.Items.Add("All")
        Do While rs.Read
            rdoOption.Items.Add(New ListItem(rs(1), rs(0)))
        Loop
        rdoOption.SelectedIndex = 0

        rs.Close()
        cm.Dispose()
        c.Close()
    End Sub

    Public Sub BuildGender()
        rdoOption.Items.Clear()
        rdoOption.Items.Add("All")
        rdoOption.Items.Add("Female")
        rdoOption.Items.Add("Male")
        rdoOption.SelectedValue = "All"
    End Sub

    Public Sub BuildAge()
        rdoOption.Items.Clear()
        rdoOption.Items.Add("All")
        rdoOption.Items.Add("18-20")
        rdoOption.Items.Add("20-25")
        rdoOption.Items.Add("26-30")
        rdoOption.Items.Add("31-35")
        rdoOption.Items.Add("36-40")
        rdoOption.Items.Add("41-45")
        rdoOption.Items.Add("46-50")
        rdoOption.SelectedValue = "All"
    End Sub

    Protected Sub btnSetFilter_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSetFilter.Click
        If Session("idx") = -1 Then
            Dim vExist As Boolean = False

            If rdoOption.SelectedValue = "All" Then
                For i As Integer = 0 To triSelected.Nodes.Count - 1
                    If triSelected.Nodes(i).Value.Contains(rdoOption.SelectedValue) Then
                        vScript = "alert('Cannot select ""All"" because one of the selected filters have already set that option.');"
                        vExist = True
                        Exit Sub
                    End If
                Next
            End If

            For i As Integer = 0 To triSelected.Nodes.Count - 1
                If triSelected.Nodes(i).Value.Contains(cmbFilters.SelectedValue) Then
                    triSelected.Nodes(i).Value = cmbFilters.SelectedValue & ":" & rdoOption.SelectedValue
                    triSelected.Nodes(i).Text = cmbFilters.SelectedItem.ToString & ":" & rdoOption.SelectedValue
                    vExist = True
                    Exit For
                End If
            Next

            If Not vExist Then
                Dim t As New TreeNode
                t.Text = cmbFilters.SelectedItem.ToString & ":" & rdoOption.SelectedValue
                t.Value = cmbFilters.SelectedValue & ":" & rdoOption.SelectedValue
                t.SelectAction = TreeNodeSelectAction.Select
                t.Checked = False
                t.ShowCheckBox = True
                triSelected.Nodes.Add(t)
                Session("idx") = -1
            End If
        Else
            triSelected.SelectedNode.Value = cmbFilters.SelectedValue & ":" & rdoOption.SelectedValue
            triSelected.SelectedNode.Text = cmbFilters.SelectedItem.ToString & ":" & rdoOption.SelectedValue
        End If

    End Sub

    Protected Sub btnOk_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnOk.Click
        Dim vSelected As String = ""
        Dim vf As String = ""
        
        For i As Integer = 0 To triSelected.Nodes.Count - 1
            vSelected += triSelected.Nodes(i).Value & ","
        Next
        Session(vf) = vSelected
        'Session("ChartTitle") = txtChartTitle.Text
        vScript = "opener.document.form1.submit(); window.close();"
        'End If
    End Sub

    Protected Sub triSelected_SelectedNodeChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles triSelected.SelectedNodeChanged
        Session("idx") = -1
        For i As Integer = 0 To triSelected.Nodes.Count - 1
            If triSelected.Nodes(i).Value = triSelected.SelectedValue Then
                Session("idx") = i
                Exit For
            End If
        Next

        Dim vValue() As String = triSelected.SelectedValue.Split(":")
        cmbFilters.SelectedValue = vValue(0)
        RefreshList()
        rdoOption.SelectedValue = vValue(1)

    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        
        Session("idx") = -1
        If Not IsPostBack Then

            RefreshList()

            Dim vf As String = ""

            Dim Dept() As String
            Dim vValue() As String
            Dim t As New TreeNode
            Dim vDescr() As String = {"Employee Status", "Rank/Level", "Gender", "Civil Status", "Age Group", "Number of year in Servie", "Work Group", "Geography", "Company", "Group", "Division/Area", "Department", "Section Brance"}

            If Session("process") = "edit" Then
                If Session(vf).ToString.Trim <> "" Then
                    Session(vf) = Session(vf).ToString.Substring(0, Session(vf).ToString.Length - 1)
                End If

                Dept = Session(vf).ToString.Split(",")
                For i As Integer = 0 To UBound(Dept)
                    vValue = Dept(i).Split(":")
                    t = New TreeNode

                    t.Text = vDescr(vValue(0) - 1) & ":" & vValue(1)
                    t.Value = vValue(0) & ":" & vValue(1)

                    t.Checked = False
                    t.ShowCheckBox = True
                    triSelected.Nodes.Add(t)
                Next

                Session("idx") = -1

            End If
        End If
    End Sub

    Protected Sub btnRemove_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnRemove.Click
        For i As Integer = 0 To triSelected.Nodes.Count - 1
            If triSelected.Nodes(i).Value.Contains(cmbFilters.SelectedValue) Then
                triSelected.Nodes.RemoveAt(i)
                Session("idx") = -1
                Exit For
            End If
        Next
    End Sub

    Protected Sub btnClear_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnClear.Click
        triSelected.Nodes.Clear()
        Session("idx") = -1
    End Sub

End Class
