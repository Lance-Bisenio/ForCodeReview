﻿Imports denaro
Partial Class ftereport
    Inherits System.Web.UI.Page
    Public vDataByGender As New StringBuilder
    Public vDataByAge As New StringBuilder
    Public vScript As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Session("returnaddr") = "viewpayroll.aspx"
            Server.Transfer("index.aspx")
        End If

        If Not CanRun(Session("caption"), Request.Item("id")) Then
            Session("denied") = "1"
            Server.Transfer("main.aspx")
            Exit Sub
        End If

        If Not IsPostBack Then
            cmbYear.Items.Clear()
            For iLoop = Now.Year - 3 To Now.Year
                cmbYear.Items.Add(iLoop)
            Next iLoop
            cmbYear.SelectedValue = Now.Year

            BuildCombo("select Rc_Cd,Descr from rc where exists (select User_Id from rights_list where User_Id='" & _
                   Session("uid") & "' and property='rc' and Property_Value=Rc_Cd) order by Descr", cmbRC)
            BuildCombo("select AgencyCd,AgencyName from agency where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='agency' and Property_Value=AgencyCd) order by AgencyName", cmbOffice)
            BuildCombo("select Div_Cd,Descr from hr_div_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='division' and Property_Value=Div_Cd) order by Descr", cmbDiv)
            BuildCombo("select Dept_Cd,Descr from hr_dept_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='department' and Property_Value=Dept_Cd) order by Descr", cmbDept)
            BuildCombo("select Section_Cd,Descr from hr_section_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='section' and Property_Value=Section_Cd) order by Descr", cmbSection)
            BuildCombo("select Unit_Cd,Descr from hr_unit_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='unit' and Property_Value=Unit_Cd) order by Descr", cmbUnit)

            cmbRC.Items.Add("All")
            cmbOffice.Items.Add("All")
            cmbDiv.Items.Add("All")
            cmbDept.Items.Add("All")
            cmbSection.Items.Add("All")
            cmbUnit.Items.Add("All")

            cmbRC.SelectedValue = "All"
            cmbDiv.SelectedValue = "All"
            cmbDept.SelectedValue = "All"
            cmbSection.SelectedValue = "All"
            cmbUnit.SelectedValue = "All"
        End If
    End Sub

    Protected Sub btnRelaod_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnRelaod.Click
        Dim vQuery As String = ""

        txtRank.Text = Request.Form("txtRank")
        txtStatus.Text = Request.Form("txtStatus")

        If cmbRC.SelectedValue <> "All" Then   'filter by cost center
            vQuery += " and Rc_Cd='" & cmbRC.SelectedValue & "' "
        Else
            vQuery += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='rc' and Property_Value=Rc_Cd) "
        End If

        If cmbOffice.SelectedValue <> "All" Then        'filter by office/agency
            vQuery += " and Agency_Cd='" & cmbOffice.SelectedValue & "' "
        Else
            vQuery += "  and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='agency' and Property_Value=Agency_Cd) "
        End If
        If cmbDiv.SelectedValue <> "All" Then      'filter by division
            vQuery += " and Divcd='" & cmbDiv.SelectedValue & "' "
        Else
            vQuery += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='division' and Property_Value=DivCd) "
        End If
        If cmbDept.SelectedValue <> "All" Then  'filter by departments
            vQuery += " and DeptCd='" & cmbDept.SelectedValue & "' "
        Else
            vQuery += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='department' and Property_Value=DeptCd) "
        End If
        If cmbSection.SelectedValue <> "All" Then 'filter by section
            vQuery += " and SectionCd='" & cmbSection.SelectedValue & "' "
        Else
            vQuery += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='section' and Property_Value=SectionCd) "
        End If
        If cmbUnit.SelectedValue <> "All" Then  'filter by units
            vQuery += " and UnitCd='" & cmbUnit.SelectedValue & "' "
        Else
            vQuery += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='unit' and Property_Value=UnitCd) "
        End If
        If txtStatus.Text = "" Then
            vScript = "alert('You must first select a Status.');"
            Exit Sub
        Else
            vQuery += " and Emp_Status in ('" & txtStatus.Text.Replace(",", "','") & "') "
        End If
        If txtRank.Text = "" Then
            vScript = "alert('You must first select a rank.');"
            Exit Sub
        Else
            vQuery += " and EmploymentType in ('" & txtRank.Text.Replace(",", "','") & "') "
        End If

        generateFTE_BY_Gender(vQuery)
        generateFTE_BY_Age(vQuery)
    End Sub

    Private Sub generateFTE_BY_Gender(ByVal vQuery As String)
        Dim c As New SqlClient.SqlConnection
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader

        Dim iCtr As Integer = 1
        Dim vClass As String = "odd"
        Dim vTtl() As Integer = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}

        Dim vIsMale As Integer = 0
        Dim vMale As Integer = 0
        Dim vFemale As Integer = 0

        Dim vData() As String = {"", "", ""}

        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c
        lblbyGender.Text = "FTE by Gender"

        For i = 1 To 12
            cm.CommandText = "select distinct(emp_cd) as vCntr, " & _
                "(select Male from py_emp_master c where a.Emp_Cd=c.emp_cd) as vGender from py_report a where YEAR(PayDate)=" & _
                cmbYear.SelectedValue & " and MONTH(paydate)=" & i & " and " & _
                "exists (select Emp_Cd from py_emp_master b where a.Emp_Cd=b.Emp_Cd) " & vQuery

            rs = cm.ExecuteReader

            vMale = 0
            vFemale = 0

            Do While rs.Read
                vTtl(i) = 0

                Select Case rs("vGender")
                    Case 1
                        vMale += 1
                    Case 0
                        vFemale += 1
                End Select

                vTtl(i) += vMale + vFemale
            Loop
            rs.Close()

            vData(0) += "<td class='labelR'>" & Format(vMale, "#,##0") & "</td>"
            vData(1) += "<td class='labelR'>" & Format(vFemale, "#,##0") & "</td>"
            vData(2) += "<td class='labelR'><b>" & Format(vTtl(i), "#,##0") & "</b></td>"

        Next i

        vDataByGender.AppendLine("<tr><td class='labelL'>&nbsp;Male</td>" & vData(0) & "</tr>")
        vDataByGender.AppendLine("<tr><td class='labelL'>&nbsp;Female</td>" & vData(1) & "</tr>")
        vDataByGender.AppendLine("<tr><td class='labelR'>&nbsp;<b>Total :</b></td>" & vData(2) & "</tr>")

        cm.Dispose()
        c.Close()
        c.Dispose()

    End Sub

    Private Sub generateFTE_BY_Age(ByVal vQuery As String)
        Dim c As New SqlClient.SqlConnection
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader

        Dim iCtr As Integer = 1
        Dim vClass As String = "odd"
        Dim vTtl() As Integer = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
        Dim vAge As Integer = 0
        Dim v0to30 As Integer = 0
        Dim v31to50 As Integer = 0
        Dim vOver50 As Integer = 0
        Dim vData() As String = {"", "", "", ""}

        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c
        lblbyAge.Text = "FTE by Age Group"

        '        vDataByAge.AppendLine("<tr><td class='labelL'>&nbsp;< 30</td>")
        For i = 1 To 12
            cm.CommandText = "select distinct(emp_cd) as vCntr, " & _
                "(select Bday from py_emp_master c where a.Emp_Cd=c.emp_cd) as Bday from py_report a where YEAR(PayDate)=" & _
                cmbYear.SelectedValue & " and MONTH(paydate)=" & i & " and " & _
                "exists (select Emp_Cd from py_emp_master b where a.Emp_Cd=b.Emp_Cd) " & vQuery

            rs = cm.ExecuteReader

            v0to30 = 0
            v31to50 = 0
            vOver50 = 0


            Do While rs.Read
                vAge = 0
                vTtl(i) = 0

                If Not IsDBNull(rs("Bday")) Then
                    vAge = DateDiff(DateInterval.Day, CDate(rs("Bday")), Now) / 365
                End If

                Select Case vAge
                    Case Is < 30
                        v0to30 += 1
                    Case Is < 50
                        v31to50 += 1
                    Case Else
                        vOver50 += 1
                End Select

                vTtl(i) += v0to30 + v31to50 + vOver50
            Loop
            rs.Close()

            vData(0) += "<td class='labelR'>" & Format(v0to30, "#,##0") & "</td>"
            vData(1) += "<td class='labelR'>" & Format(v31to50, "#,##0") & "</td>"
            vData(2) += "<td class='labelR'>" & Format(vOver50, "#,##0") & "</td>"
            vData(3) += "<td class='labelR'><b>" & Format(vTtl(i), "#,##0") & "</b></td>"

        Next i

        vDataByAge.AppendLine("<tr><td class='labelL'>&nbsp;< 30</td>" & vData(0) & "</tr>")
        vDataByAge.AppendLine("<tr><td class='labelL'>&nbsp;30 - 50</td>" & vData(1) & "</tr>")
        vDataByAge.AppendLine("<tr><td class='labelL'>&nbsp;50 ></td>" & vData(2) & "</tr>")
        vDataByAge.AppendLine("<tr><td class='labelR'>&nbsp;<b>Total :</b></td>" & vData(3) & "</tr>")

        cm.Dispose()
        c.Close()
        c.Dispose()

    End Sub

    Protected Sub cmdReturn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.Click
        Server.Transfer("main.aspx")
    End Sub
End Class


