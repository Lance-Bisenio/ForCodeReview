Imports denaro
Partial Class modifyot
    Inherits System.Web.UI.Page
    Public vScript As String = "window.focus();"
    Dim c As New SqlClient.SqlConnection
    Protected Sub cmdCancel_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCancel.Init
        cmdCancel.Attributes.Add("onclick", "javascript:window.close();")
    End Sub

    Protected Sub cal_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cal.SelectionChanged
        Select Case txtStatus.Value
            Case "trandate"
                txtTranDate.Text = cal.SelectedDate
            Case "start"
                txtStart.Text = cal.SelectedDate
                txtEnd.Text = DateAdd(DateInterval.Weekday, Val(txtDays.Text) - 1, cal.SelectedDate)
            Case "end"
                txtEnd.Text = cal.SelectedDate
            Case "approve"
                txtDateApproved.Text = cal.SelectedDate
        End Select
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Session("returnaddr") = "leavemonitor.aspx"
            Server.Transfer("index.aspx")
        End If
        If Not IsPostBack Then
            lblCaption.Text = "Add/Modify Employee Overtime"
            txtEmpId.Text = Session("empid")

            BuildCombo("select Emp_Cd,Emp_Lname+', '+Emp_Fname as Name from py_emp_master where " & _
                "Date_Resign is null and DateHold is null and DateSuspended is null and Date_Retired is null " & _
                "order by Emp_Lname,Emp_Fname,Emp_Mname", cmbApprovedBy)
            If Session("tdate") = "" Then    'add new record
                txtTranDate.Text = Format(Now, "MM/dd/yyyy HH:mm:ss")
                txtStart.Text = Format(Now, "MM/dd/yyyy")
                txtEnd.Text = Format(Now, "MM/dd/yyyy")
                txtDateApproved.Text = Format(Now, "MM/dd/yyyy HH:mm:ss")
                txtDays.Text = "0.5"
                txtBrkHr.Text = "0"
            Else
                Dim cm As New SqlClient.SqlCommand
                Dim dr As SqlClient.SqlDataReader

                c.ConnectionString = connStr
                c.Open()
                cm.Connection = c
                cm.CommandText = "select * from hr_leave_application where Emp_Cd='" & _
                    ExtractData(Session("empid")) & "' and Trandate='" & _
                    Format(CDate(Session("tdate")), "yyyy/MM/dd HH:mm:ss") & "'"
                dr = cm.ExecuteReader
                If dr.Read Then
                    txtEmpId.Text = Session("empid")
                    txtTranDate.Text = dr("TranDate")
                    txtDays.Text = dr("DaysLeave")
                    cmbCreditTo.SelectedValue = dr("CreditTo")
                    txtBrkHr.Text = IIf(IsDBNull(dr("BreakHrs")), 0, dr("BreakHrs"))
                    txtStart.Text = dr("StartDate")
                    txtEnd.Text = dr("EndDate")
                    txtReason.Text = dr("Reason")
                    txtDateApproved.Text = IIf(IsDBNull(dr("DateApproved")), "", dr("DateApproved"))
                    txtRemarks.Text = IIf(IsDBNull(dr("Remarks")), "", dr("Remarks"))
                    lblVoid.Visible = IIf(dr("Void") = True, True, False)
                    cmbApprovedBy.SelectedValue = PointData("select Emp_Cd,Emp_Lname+', '+Emp_Fname as Name " & _
                        "from py_emp_master where Emp_Cd='" & GetRef("SELECT SupervisorCd FROM py_emp_master WHERE Emp_Cd = '" & dr("Emp_Cd") & "'", dr("Emp_Cd")) & "'")
                End If
                dr.Close()
                cm.Dispose()
                c.Close()
                If Session("mode") = "v" Then
                    txtEmpId.Enabled = False
                    txtTranDate.Enabled = False
                    txtDays.Enabled = False
                    txtBrkHr.Enabled = False
                    txtStart.Enabled = False
                    txtEnd.Enabled = False
                    txtReason.Enabled = False
                    txtDateApproved.Enabled = False
                    txtRemarks.Enabled = False
                    cmbApprovedBy.Enabled = False
                    cmbCreditTo.Enabled = False
                    cmdMore.Disabled = True
                    Button1.Disabled = True
                    Button2.Disabled = True
                    Button3.Disabled = True
                End If
            End If
        End If
    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        If Page.IsValid Then
            Dim vSQL As String = ""
            Dim cm As New sqlclient.sqlcommand
            Dim rs As sqlclient.sqldatareader
            Dim vId As String = ""
            Dim vLastNo As Integer = 1

            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c
            vId = ExtractData(txtEmpId.Text)
            If Session("tdate") = "" Then 'add mode
                cm.CommandText = "select count(*) from hr_leave_application where Emp_Cd='" & vId & "'"
                rs = cm.ExecuteReader
                If rs.Read Then
                    vLastNo = IIf(IsDBNull(rs(0)), 1, rs(0) + 1)
                End If
                rs.Close()

                vSQL = "insert into hr_leave_application (TranDate,LeaveCd,CreditTo,Emp_Cd,DaysLeave,BreakHrs,StartDate,EndDate," & _
                    "Reason,ApprovedBy,DateApproved,Remarks,Paid,Void,Posted,ApplicationNo) values ('" & _
                    Format(CDate(txtTranDate.Text), "yyyy/MM/dd HH:mm:ss") & _
                    "','OT','" & cmbCreditTo.SelectedValue & "','" & ExtractData(txtEmpId.Text) & "'," & txtDays.Text & "," & txtBrkHr.Text & ",'" & _
                    Format(CDate(txtStart.Text), "yyyy/MM/dd HH:mm:ss") & "','" & _
                    Format(CDate(txtEnd.Text), "yyyy/MM/dd HH:mm:ss") & "','" & txtReason.Text & "','" & _
                    cmbApprovedBy.SelectedValue & "','" & _
                    Format(CDate(txtDateApproved.Text), "yyyy/MM/dd HH:mm:ss") & _
                    "','" & txtRemarks.Text & "',0,0,0,'" & vId & "-" & Format(vLastNo, "00000") & "')"
            Else                            'edit mode
                vSQL = "update hr_leave_application set TranDate='" & _
                    Format(CDate(txtTranDate.Text), "yyyy/MM/dd HH:mm:ss") & _
                    "',LeaveCd='OT'" & _
                    ",CreditTo='" & cmbCreditTo.SelectedValue & _
                    "',Emp_Cd='" & ExtractData(txtEmpId.Text) & _
                    "',DaysLeave=" & txtDays.Text & _
                    ",BreakHrs=" & txtBrkHr.Text & _
                    ",StartDate='" & Format(CDate(txtStart.Text), "yyyy/MM/dd HH:mm:ss") & _
                    "',EndDate='" & Format(CDate(txtEnd.Text), "yyyy/MM/dd HH:mm:ss") & _
                    "',Reason='" & txtReason.Text & _
                    "',ApprovedBy='" & cmbApprovedBy.SelectedValue & _
                    "',DateApproved='" & Format(CDate(txtDateApproved.Text), "yyyy/MM/dd") & _
                    "',Remarks='" & txtRemarks.Text & _
                    "',Paid=0 where Emp_Cd='" & ExtractData(Session("empid")) & _
                    "' and Trandate='" & Format(CDate(Session("tdate")), "yyyy/MM/dd HH:mm:ss") & "'"
            End If

            cm.CommandText = vSQL
            cm.ExecuteNonQuery()
            cm.Dispose()
            c.Close()
            vScript = "alert('Changes were successfuly saved.'); window.close();"
        End If
    End Sub

    Protected Sub vldTran_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles vldTran.ServerValidate
        If Not IsDate(txtDateApproved.Text) Then
            vScript = "alert('Invalid date format in Date Approved field.');"
            args.IsValid = False
            Exit Sub
        End If

        If Not IsDate(txtTranDate.Text) Then
            vScript = "alert('Invalid date format in Date filed field.');"
            args.IsValid = False
            Exit Sub
        End If
        If Not IsDate(txtStart.Text) Then
            vScript = "alert('Invalid date format in Start Date and time field.');"
            args.IsValid = False
            Exit Sub
        End If
        If Not IsDate(txtEnd.Text) Then
            vScript = "alert('Invalid date format in End Date and time field.');"
            args.IsValid = False
            Exit Sub
        End If

        'If Session("tdate") <> txtTranDate.Text Then        'date has been changed
        '    Dim cm As New sqlclient.sqlcommand
        '    Dim dr As sqlclient.sqldatareader

        '    c.ConnectionString = connStr
        '    c.Open()
        '    cm.Connection = c
        '    cm.CommandText = "select Emp_Cd from hr_leave_application where Emp_Cd='" & _
        '        ExtractData(txtEmpId.Text) & "' and TranDate='" & _
        '        Format(CDate(txtTranDate.Text), "yyyy/MM/dd") & "'"
        '    dr = cm.ExecuteReader
        '    If dr.Read Then
        '        vScript = "alert('Record already exist. Please select a different filing date.');"
        '        args.IsValid = False
        '    Else
        '        args.IsValid = True
        '    End If
        '    dr.Close()
        '    cm.Dispose()
        '    c.Close()
        '    Exit Sub
        'End If

        args.IsValid = True
    End Sub

    Protected Sub CustomValidator1_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles CustomValidator1.ServerValidate
        args.IsValid = IsNumeric(txtBrkHr.Text)
    End Sub

    Protected Sub cmdCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        Session.Remove("empid")
        Session.Remove("tdate")
        Session.Remove("mode")
    End Sub
End Class
