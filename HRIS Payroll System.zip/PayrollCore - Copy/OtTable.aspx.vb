Imports denaro.fis
Partial Class OtTable
    Inherits System.Web.UI.Page
    Public vTable As String = ""
    Public vScript As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
        End If
        If Not CanRun(Session("caption"), Request.Item("id")) Then
            Session("denied") = "1"
            Server.Transfer("main.aspx")
            Exit Sub
        End If
        If Not IsPostBack Then
            lblCaption.Text = "Overtime Table Matrix"
            getOT()
        Else
            If tblOt.SelectedIndex > -1 Then
                getRanks(tblOt.SelectedRow.Cells(0).Text)
            End If
        End If

    End Sub

    Private Sub getOT()
        Dim c As New sqlclient.sqlconnection(connStr)
        Dim da As sqlclient.sqldataadapter
        Dim ds As New DataSet

        c.Open()

        da = New sqlclient.sqldataadapter("SELECT OtCD, Descr, GroupName, SubTitle FROM py_ot_ref WHERE OtCd in ('A1','A2','A3','A4','B1','B2','B3','B4','C1','C2','C3','C4','D1','D2','D3','D4','E1','E2','E3','E4','F1','F2','F3','F4','G1','G2','G3','G4') ORDER BY GroupName,SubTitle", c)
        da.Fill(ds, "OtTable")
        tblOt.DataSource = ds.Tables("OtTable")
        tblOt.DataBind()
        ds.Dispose()
        da.Dispose()
        c.Close()

    End Sub
    Private Sub getRanks(ByVal pCode As String)
        Dim c As New sqlclient.sqlconnection(connStr)
        Dim da As sqlclient.sqlDataAdapter
        Dim ds As New DataSet

        c.Open()
        da = New sqlclient.sqlDataAdapter("SELECT EmploymentType, Factor * CASE WHEN UOM=0 THEN 100 ELSE 1 END AS Factor," & _
            "CASE WHEN UOM=0 THEN 'Percent' ELSE 'Amount' END AS UOM FROM py_ot_ref_dtl WHERE OtCd = '" & pCode & "'", c)
        da.Fill(ds, "ListTable")
        tblList.DataSource = ds.Tables("ListTable")
        tblList.DataBind()
        ds.Dispose()
        da.Dispose()

        c.Close()
    End Sub

    Protected Sub tblOt_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles tblOt.PageIndexChanging
        tblOt.PageIndex = e.NewPageIndex
        getOT()
        'If tblOt.SelectedIndex > -1 Then
        '    getRanks(tblOt.SelectedRow.Cells(0).Text)
        'End If
        tblOt.SelectedIndex = -1
        tblList.SelectedIndex = -1
    End Sub
    Protected Sub tblList_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles tblList.PageIndexChanging
        tblList.PageIndex = e.NewPageIndex
        getRanks(tblOt.SelectedRow.Cells(0).Text)
    End Sub

    Protected Sub tblOt_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tblOt.SelectedIndexChanged
        getRanks(tblOt.SelectedRow.Cells(0).Text)
        tblList.SelectedIndex = -1
    End Sub

    Protected Sub cmdAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdAdd.Click
        If tblOt.SelectedIndex >= 0 Then
            'Session("OtType") = tblOt.SelectedRow.Cells(0).Text
            'Session("Desc") = tblOt.SelectedRow.Cells(2).Text & "=>" & tblOt.SelectedRow.Cells(3).Text
            'Session("Mode") = "add"
            vScript = "win = window.open('OtTablePop.aspx?t=" & tblOt.SelectedRow.Cells(0).Text & _
                "&d=" & tblOt.SelectedRow.Cells(2).Text & "=>" & tblOt.SelectedRow.Cells(3).Text & _
                "&m=add','win','top=300,left=400,width=350,height=200,scrollbars=no,toolbar=no,resizable=no');win.focus(); win.refre;"
        Else
            vScript = "alert('Please select OT type first.');"
            'Session.Remove("Mode")
            'Session.Remove("Desc")
            'Session.Remove("OtType")
        End If
    End Sub

    Protected Sub cmdClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdClose.Click
        Server.Transfer("main.aspx")
        'Session.Remove("OtType")
        'Session.Remove("Rank")
        'Session.Remove("Mode")
        'Session.Remove("Desc")
    End Sub

    Protected Sub cmdEdit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdEdit.Click
        If tblList.SelectedIndex >= 0 Then
            'Session("OtType") = tblOt.SelectedRow.Cells(0).Text
            'Session("Desc") = tblOt.SelectedRow.Cells(2).Text & "=>" & tblOt.SelectedRow.Cells(3).Text
            'Session("Rank") = tblList.SelectedRow.Cells(0).Text.Replace("&amp;", "&")
            'Session("Mode") = "edit"
            'vScript = "win = window.open('OtTablePop.aspx','win','top=300,left=400,width=350,height=200,scrollbars=no,toolbar=no,resizable=no');win.focus();"
            vScript = "win = window.open('OtTablePop.aspx?t=" & tblOt.SelectedRow.Cells(0).Text & _
                "&d=" & tblOt.SelectedRow.Cells(2).Text & "=>" & tblOt.SelectedRow.Cells(3).Text & _
                "&m=edit&r=" & tblList.SelectedRow.Cells(0).Text.Replace("&amp;", "|") & _
                "','win','top=300,left=400,width=350,height=200,scrollbars=no,toolbar=no,resizable=no');win.focus(); win.refre;"
        Else
            vScript = "alert('Please select rank first.');"
            'Session.Remove("Rank")
            'Session.Remove("Mode")
            'Session.Remove("Desc")
            'Session.Remove("OtType")
        End If
    End Sub

    Protected Sub cmdDel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDel.Click
        If tblList.SelectedIndex >= 0 Then
            Dim c As New sqlclient.sqlconnection(connStr)
            Dim cm As New sqlclient.sqlcommand

            c.Open()
            cm.Connection = c
            cm.CommandText = "DELETE FROM py_ot_ref_dtl WHERE OtCd = '" & tblOt.SelectedRow.Cells(0).Text & "' AND EmploymentType = '" & tblList.SelectedRow.Cells(0).Text.Replace("&amp;", "&") & "'"

            Try
                cm.ExecuteNonQuery()
                vScript = "alert('Record successfully deleted..');"
            Catch ex As sqlclient.sqlException
                vScript = "alert('Cannot delete record due to " & ex.Message.Replace("'", "") & " ');"
            End Try

            c.Close()
            c.Dispose()
            cm.Dispose()
            getRanks(tblOt.SelectedRow.Cells(0).Text)
        Else
            vScript = "alert('Please select rank first.');"
        End If

        tblList.SelectedIndex = -1
    End Sub
End Class
