Imports denaro
Partial Class preview
    Inherits System.Web.UI.Page
    Public vListen As String = ""
    Public vDate As Date = Now
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        vListen = Session("data_emthp")
    End Sub
End Class