Imports denaro.fis

Partial Class batchgrace
    Inherits System.Web.UI.Page
    Public vDetail As String = ""
    Public vScript As String = ""
    Dim vList As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Session("returnaddr") = "batchgrace.aspx"
            Server.Transfer("index.aspx")
            Exit Sub
        End If

        If Request.Form("cmdReturn") = "Return" Then
            Server.Transfer("main.aspx")
            Exit Sub
        End If

        If Not CanRun(Session("caption"), Request.Item("id")) Then
            Session("denied") = "1"
            Server.Transfer("main.aspx")
            Exit Sub
        End If

        Dim c As New SqlClient.SqlConnection(connStr)

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            Exit Sub
        End Try

        If Not IsPostBack Then
            lblCaption.Text = "Mass Update Employee Parameters"
            BuildCombo("select Pos_Cd,Position from py_position_ref order by Position", cmbPos, c)
            BuildCombo("select Rc_Cd,Descr from rc where exists (select User_Id from rights_list where User_Id='" & _
            Session("uid") & "' and property='rc' and Property_Value=Rc_Cd) order by Descr", cmbRC, c)
            BuildCombo("select AgencyCd,AgencyName from agency where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='agency' and Property_Value=AgencyCd) order by AgencyName", cmbOfc, c)
            BuildCombo("select Div_Cd,Descr from hr_div_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='division' and Property_Value=Div_Cd) order by Descr", cmbDiv, c)
            BuildCombo("select Dept_Cd,Descr from hr_dept_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='department' and Property_Value=Dept_Cd) order by Descr", cmbDept, c)
            BuildCombo("select Section_Cd,Descr from hr_section_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='section' and Property_Value=Section_Cd) order by Descr", cmbSection, c)
            BuildCombo("select Unit_Cd,Descr from hr_unit_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='unit' and Property_Value=Unit_Cd) order by Descr", cmbUnit, c)
            BuildCombo("select EmploymentType,Descr from hr_employment_type where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='employmenttype' and Property_Value=EmploymentType) order by Descr", cmbSecurity, c)
            BuildCombo("select Status_Code, Descr from py_employee_stat order by Descr", cmbEmpStatus, c)
            BuildCombo("select Pay_Cd, Payment from py_pay_mode order by Payment", cmbPayMode, c)

            cmbRC.Items.Add("All")
            cmbRC.SelectedValue = "All"
            cmbOfc.Items.Add("All")
            cmbOfc.SelectedValue = "All"
            cmbDiv.Items.Add("All")
            cmbDiv.SelectedValue = "All"
            cmbDept.Items.Add("All")
            cmbDept.SelectedValue = "All"
            cmbSection.Items.Add("All")
            cmbSection.SelectedValue = "All"
            cmbUnit.Items.Add("All")
            cmbUnit.SelectedValue = "All"
            cmbSecurity.Items.Add("All")
            cmbSecurity.SelectedValue = "All"
            cmbPos.Items.Add("All")
            cmbPos.SelectedValue = "All"
            cmbEmpStatus.Items.Add("All")
            cmbEmpStatus.SelectedValue = "All"
            cmbPayMode.Items.Add("All")
            cmbPayMode.SelectedValue = "All"

            c.Close()
            c.Dispose()
            Exit Sub
        End If


        Dim cm As New SqlClient.SqlCommand()
        cm.Connection = c

        Dim rs As sqlclient.sqldatareader
        Dim vLocation As String = ""
        Dim vCompany As String = ""
        Dim vGroup As String = ""
        Dim vDiv As String = ""
        Dim vDept As String = ""
        Dim vSection As String = ""
        Dim vRank As String = ""
        Dim vPosition As String = ""
        Dim vSw As Integer = 0
        Dim vColor As String = "odd"
        Dim iCtr As Integer = 1
        Dim AllowanceType As String = ""
        Dim vMaxOtAmount As Decimal = 0
        Dim vFractionTruncated As Integer = 0
        Dim vCalcMethod As Integer = 1
        Dim vFilter As String = ""

        vDetail = ""
        vList = txtSelectedEmp.Value
        If vList <> "" Then
            vList = vList.Substring(0, vList.Length - 1).Replace(",", "','")
            If Me.txtGrace.Value <> "" Then
                cm.CommandText = "UPDATE py_emp_master SET GracePeriod= " & txtGrace.Value & _
                    " WHERE Emp_Cd IN ('" & vList & "') "
            ElseIf Me.txtMinOt.Value <> "" Then
                cm.CommandText = "UPDATE py_emp_master SET MinOtHours= " & txtMinOt.Value & _
                    " WHERE Emp_Cd IN ('" & vList & "') "
            ElseIf txtPreApprove.Value <> "" Then
                cm.CommandText = "update py_emp_master set AutoApprovedOT=" & txtPreApprove.Value & _
                    " WHERE Emp_Cd in ('" & vList & "') "
            ElseIf txtOTMultiple.Value <> "" Then
                cm.CommandText = "update py_emp_master set OTMultipleMins=" & txtOTMultiple.Value & _
                    " WHERE Emp_Cd in ('" & vList & "') "
            ElseIf txtCumulative.Value <> "" Then
                cm.CommandText = "update py_emp_master set CumulativeGrace=" & txtCumulative.Value & _
                    " WHERE Emp_Cd in ('" & vList & "') "
            ElseIf txtPreApprovedLegal.Value <> "" Then
                cm.CommandText = "update py_emp_master set AutoApprovedOT_Legal=" & txtPreApprovedLegal.Value & _
                    " WHERE Emp_Cd in ('" & vList & "') "
            ElseIf txtPreApprovedSpecial.Value <> "" Then
                cm.CommandText = "update py_emp_master set AutoApproved_Special=" & txtPreApprovedSpecial.Value & _
                " WHERE Emp_Cd in ('" & vList & "') "
            ElseIf txtPreApprovedRestday.Value <> "" Then
                cm.CommandText = "update py_emp_master set AutoApproved_Restday=" & txtPreApprovedRestday.Value & _
                " WHERE Emp_Cd in ('" & vList & "') "
            End If

            Try
                cm.ExecuteNonQuery()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred! Cannot continue update! Error is: " & ex.Message & "');"
            Finally
                Me.txtGrace.Value = ""
                Me.txtMinOt.Value = ""
                txtSelectedEmp.Value = ""
                Me.txtPreApprovedLegal.Value = ""
                Me.txtPreApprovedRestday.Value = ""
                Me.txtPreApprovedSpecial.Value = ""
            End Try

        End If


        If cmbRC.SelectedValue <> "All" Then   'filter by cost center
            vFilter += " and Rc_Cd='" & cmbRC.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='rc' and Property_Value=Rc_Cd) "
        End If

        If cmbOfc.SelectedValue <> "All" Then        'filter by office/agency
            vFilter += " and Agency_Cd='" & cmbOfc.SelectedValue & "' "
        Else
            vFilter += "  and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='agency' and Property_Value=Agency_Cd) "
        End If
        If cmbDiv.SelectedValue <> "All" Then      'filter by division
            vFilter += " and Divcd='" & cmbDiv.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='division' and Property_Value=DivCd) "
        End If
        If cmbDept.SelectedValue <> "All" Then  'filter by departments
            vFilter += " and DeptCd='" & cmbDept.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='department' and Property_Value=DeptCd) "
        End If
        If cmbSection.SelectedValue <> "All" Then 'filter by section
            vFilter += " and SectionCd='" & cmbSection.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='section' and Property_Value=SectionCd) "
        End If
        If cmbUnit.SelectedValue <> "All" Then  'filter by units
            vFilter += " and UnitCd='" & cmbUnit.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='unit' and Property_Value=UnitCd) "
        End If
        If cmbSecurity.SelectedValue <> "All" Then
            vFilter += " and EmploymentType='" & cmbSecurity.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='employmenttype' and Property_Value=EmploymentType) "
        End If
        If rdoGroup.SelectedValue <> "99" Then
            vFilter += " and GroupCd='" & rdoGroup.SelectedValue & "' "
        End If
        If cmbEmpStatus.SelectedValue <> "All" Then
            vFilter += " and Emp_Status='" & cmbEmpStatus.SelectedValue & "' "
        End If
        If cmbPayMode.SelectedValue <> "All" Then
            vFilter += " and Pay_Cd='" & cmbPayMode.SelectedValue & "' "
        End If

        cm.CommandText = "select Rc_Cd,Agency_Cd,DivCd,DeptCd,SectionCd,UnitCd,EmploymentType,Pos_Cd," & _
            "Emp_Cd,Emp_Lname,Emp_Fname,GracePeriod,MinOtHours,Aca,Frequency,OtAllowanceType,AutoApprovedOT," & _
            "MaxOtAmount,FractionTruncated,CalcMethod,RegOt,RegOtUom,RestOt,RestOtUom,RestOtX8,RestOtX8Uom, " & _
            "OTMultipleMins,CumulativeGrace,AutoApprovedOT_Legal, AutoApproved_Special, " & _
            "AutoApproved_Restday from py_emp_master where Date_Resign is null " & vFilter & _
            " order by Emp_Lname,Emp_Fname"
        

        rs = cm.ExecuteReader


        Do While rs.Read
            vLocation = GetRef("select Descr from rc where Rc_Cd='" & rs("Rc_Cd") & "'", rs("Rc_Cd"), c)
            vCompany = GetRef("select AgencyName from agency where AgencyCd='" & rs("Agency_Cd") & "'", rs("Agency_Cd"), c)
            vGroup = GetRef("select Descr from hr_div_ref where Div_Cd='" & rs("DivCd") & "'", rs("DivCd"), c)
            vDiv = GetRef("select Descr from hr_dept_ref where Dept_Cd='" & rs("DeptCd") & "'", rs("DeptCd"), c)
            vDept = GetRef("select Descr from hr_section_ref where Section_Cd='" & rs("SectionCd") & "'", rs("SectionCd"), c)
            vSection = GetRef("select Descr from hr_unit_ref where Unit_Cd='" & rs("UnitCd") & "'", rs("UnitCd"), c)
            vPosition = GetRef("select Position from py_position_ref where Pos_Cd='" & _
                IIf(IsDBNull(rs("Pos_Cd")), "", rs("Pos_Cd")) & "'", IIf(IsDBNull(rs("Pos_Cd")), "", rs("Pos_Cd")), c)
            vRank = GetRef("select Descr from hr_employment_type where EmploymentType='" & _
                IIf(IsDBNull(rs("EmploymentType")), "", rs("EmploymentType")) & "'", _
                IIf(IsDBNull(rs("EmploymentType")), "", rs("EmploymentType")), c)

            AllowanceType = IIf(IsDBNull(rs("OtAllowanceType")), "", rs("OtAllowanceType"))
            vCalcMethod = IIf(IsDBNull(rs("CalcMethod")), 1, rs("CalcMethod"))
            vFractionTruncated = IIf(IsDBNull(rs("FractionTruncated")), 1, rs("FractionTruncated"))

            If AllowanceType = "1" Then
                AllowanceType = "Per Dime"
            ElseIf AllowanceType = "2" Then
                AllowanceType = "Top Of OT"
            End If

            vMaxOtAmount = IIf(IsDBNull(rs("MaxOtAmount")), 0, rs("MaxOtAmount"))

            vDetail += "<tr style='font-size:7pt;color:black;' class='" & vColor & "'>" & _
                "<td class='labelC'><input type='checkbox' id='" & iCtr & "' name='" & rs("Emp_Cd") & _
                "' style='width:20px;' /></td>" & _
                "<td class='labelL'>" & rs("Emp_Cd") & "</td>" & _
                "<td class='labelL'>" & rs("Emp_Lname") & ", " & rs("Emp_Fname") & "</td>" & _
                "<td class='labelL'>" & vRank & "</td>" & _
                "<td class='labelL'>" & vPosition & "</td>" & _
                "<td class='labelR'>" & rs("GracePeriod") & "</td>" & _
                "<th class='labelC'>" & IIf(rs("CumulativeGrace") = 0, "No", "Yes") & "</td>" & _
                "<td class='labelR'>" & rs("MinOtHours") & "</td>" & _
                "<td class='labelR'>" & rs("Aca") & "</td>" & _
                "<td class='labelR'>" & IIf(rs("RegOtUom") = 0, Math.Round(rs("RegOt") * 100, 2) & " %", "P " & rs("RegOt")) & "</td>" & _
                "<td class='labelR'>" & IIf(rs("RestOtUom") = 0, Math.Round(rs("RestOt") * 100, 2) & " %", "P " & rs("RestOt")) & "</td>" & _
                "<td class='labelR'>" & IIf(rs("RestOtX8Uom") = 0, rs("RestOtX8") & " %", "P " & rs("RestOtX8")) & "</td>" & _
                "<td class='labelR'>" & rs("Frequency") & "</td>" & _
                "<td class='labelL'>" & AllowanceType & "</td>" & _
                "<td class='labelR'>" & vMaxOtAmount & "</td>" & _
                "<td class='labelL'>" & IIf(vFractionTruncated = 0, "No", "Yes") & "</td>" & _
                "<td class='labelL'>" & IIf(vCalcMethod = 1, "Per Day", "Per Cut-Off") & "</td>" & _
                "<td class='labelR'>" & rs("AutoApprovedOT") & "</td>" & _
                "<td class='labelR'>" & rs("AutoApprovedOT_Legal") & "</td>" & _
                "<td class='labelR'>" & rs("AutoApproved_Special") & "</td>" & _
                "<td class='labelR'>" & rs("AutoApproved_Restday") & "</td>" & _
                "<td class='labelR'>" & rs("OTMultipleMins") & "</td>" & _
                "</tr>"
            '"<td>" & vLocation & "</td>" & _
            '"<td>" & vCompany & "</td>" & _
            '"<td>" & vGroup & "</td>" & _
            '"<td>" & vDiv & "</td>" & _
            '"<td>" & vDept & "</td>" & _
            '"<td>" & vSection & "</td>" & _
            iCtr += 1
            vColor = IIf(vColor = "odd", "even", "odd")
        Loop
        rs.Close()

        c.Close()
        cm.Dispose()
        c.Dispose()
        txtRows.Value = iCtr
    End Sub

End Class
