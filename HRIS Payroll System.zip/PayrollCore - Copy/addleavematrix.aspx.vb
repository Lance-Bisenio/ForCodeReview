﻿Imports denaro
Partial Class addleavematrix
    Inherits System.Web.UI.Page
    Dim vmode As String = ""
    Dim vCode As String = ""
    Dim vtype As String = ""
    Dim vgroup As String = ""
    Dim vYearFr As Decimal = 0
    Public vscript As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim vranks As String = ""
        'Dim vstatus As String = ""

        vCode = Request.Item("LvCode")
        vmode = Request.Item("mode")
        vtype = Request.Item("type")
        vgroup = Request.Item("group")
        vYearFr = Request.Item("yearfrom")

        If Not IsPostBack Then
            c.Open()
            cm.Connection = c

            txtLeaveCode.Text = vCode
            txtLeaveCode.Enabled = False
            'Response.Write(Request.Item("mode") & " " & Request.Item("value"))
            If Request.Item("mode") = "e" Then
                
                cm.CommandText = "select * from py_leave_table where LeaveCd='" & vCode & _
                "' and EmploymentType='" & vtype & "' and GroupCd='" & vgroup & "' and YearFrom=" & vYearFr
                rs = cm.ExecuteReader
                If rs.Read Then

                    'txtLeaveCode.Text = rs("LeaveCd")
                    rdoGroup.SelectedValue = rs("GroupCd")
                    txtYearFrom.Text = rs("YearFrom")
                    txtYearTo.Text = rs("YearTo")
                    txtCredits.Text = rs("Credits")
                    vranks = IIf(IsDBNull(rs("EmploymentType")), "", rs("EmploymentType"))
                    'vstatus = IIf(IsDBNull(rs("Status")), "", rs("Status"))
                End If
                rs.Close()
            End If
            cm.CommandText = "select EmploymentType,Descr from hr_employment_type"
            rs = cm.ExecuteReader
            Dim vEmploymentType() As String
            Dim iLoop As Integer = 0
            Dim iCtr As Integer = 0

            vEmploymentType = vranks.Split(",")
            iCtr = 0
            drpRanks.Items.Clear()
            Do While rs.Read
                drpRanks.Items.Add(New ListItem(rs(1), rs(0)))

                ''''''drpRanks.Items.Add(rs("EmploymentType") & "=>" & rs("Descr"))
                If vranks <> "" Then
                    '    For iLoop = 0 To UBound(vEmploymentType)
                    If vranks = rs("EmploymentType") Then
                        drpRanks.Items(iCtr).Selected = True
                        '            Exit For
                    End If
                    '    Next
                    iCtr += 1
                End If
            Loop
            rs.Close()

            'cm.CommandText = "select * from py_employee_stat"
            'rs = cm.ExecuteReader
            'Dim vEmpStatus() As String

            'vEmpStatus = vstatus.Split(",")
            'iCtr = 0
            'chkEmpStatus.Items.Clear()
            'Do While rs.Read
            '    chkEmpStatus.Items.Add(rs("Status_Code") & "=>" & rs("Descr"))
            '    If vstatus <> "" Then
            '        For iLoop = 0 To UBound(vEmpStatus)
            '            If vEmpStatus(iLoop) = rs("Status_Code") Then
            '                chkEmpStatus.Items(iCtr).Selected = True
            '            End If
            '        Next
            '        iCtr += 1
            '    End If
            'Loop
            'rs.Close()
            cm.Dispose()
            c.Close()
            c.Dispose()
        End If
    End Sub

    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click

        If Not IsNumeric(txtYearFrom.Text) Then
            vscript = "alert('Please enter a valid number in Year from field.');"
            Exit Sub
        End If

        If Not IsNumeric(txtYearTo.Text) Then
            vscript = "alert('Please enter a valid number in Year to field.');"
            Exit Sub
        End If

        If Not IsNumeric(txtCredits.Text) Then
            vscript = "alert('Please enter a valid number in the credits field.')'"
            Exit Sub
        End If

        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand

        c.Open()
        cm.Connection = c

        If vmode = "e" Then
            cm.CommandText = "update py_leave_table set Employmenttype='" & drpRanks.SelectedValue & _
                             "',GroupCd='" & rdoGroup.SelectedValue & "',YearFrom=" & txtYearFrom.Text & _
                             ",YearTo=" & txtYearTo.Text & ",Credits=" & txtCredits.Text & _
                             " where LeaveCd='" & txtLeaveCode.Text & "' and Employmenttype='" & vtype & "' and " & _
                             " GroupCd='" & vgroup & "' and YearFrom=" & vYearFr

        Else
            cm.CommandText = "insert into py_leave_table(LeaveCd,Employmenttype,GroupCd,YearFrom,YearTo,Credits)values('" & _
                        txtLeaveCode.Text & "','" & drpRanks.SelectedValue & "','" & _
                        rdoGroup.SelectedValue & "'," & txtYearFrom.Text & "," & txtYearTo.Text & "," & txtCredits.Text & ")"
        End If

        Try
            cm.ExecuteNonQuery()
            vscript = "alert('Record saved.');window.opener.document.form1.submit();"
        Catch ex As SqlClient.SqlException
            vscript = "alert('Error occurred while trying to retrieve record. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            cm.Dispose()
            c.Dispose()
        End Try

    End Sub
End Class
