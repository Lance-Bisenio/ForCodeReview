Imports denaro.fis
Partial Class remitrecord
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Session("returnaddr") = "dailylog.aspx"
            Server.Transfer("index.aspx")
        End If
        If Not CanRun(Session("caption"), Request.Item("id")) Then
            Session("denied") = "1"
            Server.Transfer("main.aspx")
            Exit Sub
        End If
        If Not IsPostBack Then
            Dim iCtr As Integer = 0
            For iCtr = 2000 To 2030      'add days
                cmbYear.Items.Add(iCtr)
            Next iCtr
            cmbYear.SelectedValue = Now.Year
            lblCaption.Text = "Record Remittance Receipt"
            BuildCombo("select AgencyCd,AgencyName from agency order by AgencyName", cmbAgency)
            DataRefresh()
        End If
    End Sub

    Protected Sub cmdAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdAdd.Click
        Session("Cont") = cmbContribution.SelectedValue
        Session("Year") = cmbYear.SelectedValue
        Session("mode") = "a"
        vScript = "win = window.open('remitrecordpop.aspx','win','top=0, left=0, height=270, width=300'); win.focus();"
    End Sub

    Protected Sub cmdReturn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.Click
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub cmdSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSearch.Click
        DataRefresh()
    End Sub
    Protected Sub cmdA_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdA.Click, _
    cmdB.Click, cmdC.Click, cmdD.Click, cmdE.Click, cmdF.Click, cmdG.Click, cmdH.Click, cmdI.Click, cmdJ.Click, _
    cmdK.Click, cmdL.Click, cmdM.Click, cmdN.Click, cmdO.Click, cmdP.Click, cmdQ.Click, cmdR.Click, cmdS.Click, _
    cmdT.Click, cmdU.Click, cmdV.Click, cmdW.Click, cmdX.Click, cmdY.Click, cmdZ.Click
        txtSearch.Text = CType(sender, WebControls.LinkButton).Text
        DataRefresh()
    End Sub
    Private Sub DataRefresh()
        Dim vSearchKey As String = Me.txtSearch.Text
        Dim c As New sqlclient.sqlconnection(connStr)
        Dim da As sqlclient.sqlDataAdapter
        Dim ds As New DataSet
        Dim vFilter As String = " WHERE RemitCd='" & cmbContribution.SelectedValue & _
            "' AND YearCd='" & cmbYear.SelectedValue & "' and Agency_Cd='" & cmbAgency.SelectedValue & "' "
        Dim vSql As String = ""

        vSql = "SELECT * FROM hr_remittance_or"
        If txtSearch.Text.Trim() <> "" Then
            vFilter += " AND " & cmbSearchBy.SelectedValue & " LIKE '" & _
                txtSearch.Text & "%' "
        End If
        c.Open()
        da = New sqlclient.sqlDataAdapter(vSql & vFilter & " ORDER BY DatePaid", c)
        da.Fill(ds, "maintenance")
        tblEmp.DataSource = ds.Tables("maintenance")
        tblEmp.DataBind()
        da.Dispose()
        ds.Dispose()
        c.Dispose()
    End Sub

    Protected Sub cmdDel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDel.Click
        If Me.tblEmp.SelectedIndex >= 0 And Me.tblEmp.Rows.Count > Me.tblEmp.SelectedIndex Then
            Dim vOr As String = Me.tblEmp.SelectedRow.Cells(2).Text
            Dim vMonth As String = Me.tblEmp.SelectedRow.Cells(1).Text

            Dim c As New sqlclient.sqlConnection(connStr)
            Dim cm As New sqlclient.sqlcommand

            c.Open()
            cm.Connection = c
            cm.CommandText = "DELETE FROM hr_remittance_or WHERE OrNo='" & vOr & _
                "' AND MonthCd='" & vMonth & "' and Agency_Cd='" & tblEmp.SelectedRow.Cells(0).Text & "'"

            cm.ExecuteNonQuery()
            'Response.Write(cm.CommandText)
            'Exit Sub
            cm.Dispose()
            c.Close()
            c.Dispose()
            DataRefresh()
        Else
            vScript = "alert('Please select  record first');"
            Exit Sub
        End If

    End Sub

    Protected Sub cmdEdit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdEdit.Click
        If Me.tblEmp.SelectedIndex >= 0 And Me.tblEmp.Rows.Count > Me.tblEmp.SelectedIndex Then
            Dim vOr As String = Me.tblEmp.SelectedRow.Cells(2).Text
            Dim vMonth As String = Me.tblEmp.SelectedRow.Cells(1).Text

            Session("Cont") = cmbContribution.SelectedValue
            Session("Year") = cmbYear.SelectedValue
            Session("mode") = "e"
            Session("vOr") = vOr
            Session("vMonth") = vMonth
            Session("ofc") = tblEmp.SelectedRow.Cells(0).Text
            vScript = "win = window.open('remitrecordpop.aspx','win','top=0, left=0, height=270, width=300'); win.focus();"
        Else
            vScript = "alert('Please select  record first');"
            Exit Sub
        End If
    End Sub

    Protected Sub tblEmp_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tblEmp.SelectedIndexChanged

    End Sub
End Class
