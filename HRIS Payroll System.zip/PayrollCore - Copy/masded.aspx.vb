Imports denaro
Partial Class masded
    Inherits System.Web.UI.Page
    Public vScript As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
        End If

        If Not CanRun(Session("caption"), Request.Item("id")) Then
            Session("denied") = "1"
            Server.Transfer("main.aspx")
            Exit Sub
        End If

        If Not IsPostBack Then 'now build the reference code
            lblCaption.Text = "Mass Update Loans and Other Deductions"
            BuildCombo("select Rc_Cd, Descr from rc where Rc_Cd in ('" & _
                Session("rclist").ToString.Replace(",", "','") & "') order by Descr", cmbRC)
            BuildCombo("select AgencyCd,AgencyName from agency where AgencyCd in ('" & _
                Session("agencylist").ToString.Replace(",", "','") & "') order by AgencyName", cmbOfc)
            BuildCombo("select Div_Cd,Descr from hr_div_ref where Div_Cd in ('" & _
                Session("divlist").ToString.Replace(",", "','") & "') order by Descr", cmbDiv)
            BuildCombo("select Dept_Cd,Descr from hr_dept_ref where Dept_Cd in ('" & _
                Session("deptlist").ToString.Replace(",", "','") & "') order by Descr", cmbDept)
            BuildCombo("select Section_Cd,Descr from hr_section_ref where Section_Cd in ('" & _
                Session("sectionlist").ToString.Replace(",", "','") & "') order by Descr", cmbSection)
            BuildCombo("select Unit_Cd,Descr from hr_unit_ref where Unit_Cd in ('" & _
                Session("unitlist").ToString.Replace(",", "','") & "') order by Descr", cmbUnit)
            BuildCombo("select Loan_Cd,Loan_Name from py_loan_ref order by Loan_Name", cmbLoan)
            BuildCombo("select EmploymentType,Descr from hr_employment_type where EmploymentType in ('" & _
                Session("typelist").ToString.Replace(",", "','") & "') order by Descr", cmbSecurity)
            BuildCombo("select Pos_Cd,Position from py_position_ref order by Position", cmbPos)

            cmbRC.Items.Add("All")
            cmbRC.SelectedValue = "All"
            cmbOfc.Items.Add("All")
            cmbOfc.SelectedValue = "All"
            cmbDiv.Items.Add("All")
            cmbDiv.SelectedValue = "All"
            cmbDept.Items.Add("All")
            cmbDept.SelectedValue = "All"
            cmbSection.Items.Add("All")
            cmbSection.SelectedValue = "All"
            cmbUnit.Items.Add("All")
            cmbUnit.SelectedValue = "All"
            cmbSecurity.Items.Add("All")
            cmbSecurity.SelectedValue = "All"
            cmbPos.Items.Add("All")
            cmbPos.SelectedValue = "All"
            DataRefresh()
        End If
    End Sub
    Protected Sub DataRefresh()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim dr As SqlClient.SqlDataReader
        Dim vFilter As String = " where Date_Resign is null "

        If cmbRC.SelectedValue <> "All" Then   'filter by cost center
            vFilter += " and Rc_Cd='" & cmbRC.SelectedValue & "' "
        Else
            vFilter += " and Rc_Cd in ('" & Session("rclist").ToString.Replace(",", "','") & "') "
        End If
        If cmbOfc.SelectedValue <> "All" Then        'filter by office/agency
            vFilter += " and Agency_Cd='" & cmbOfc.SelectedValue & "' "
        Else
            vFilter += " and Agency_Cd in ('" & Session("agencylist").ToString.Replace(",", "','") & "') "
        End If
        If cmbDiv.SelectedValue <> "All" Then      'filter by division
            vFilter += " and DivCd='" & cmbDiv.SelectedValue & "' "
        Else
            vFilter += " and DivCd in ('" & Session("divlist").ToString.Replace(",", "','") & "') "
        End If
        If cmbDept.SelectedValue <> "All" Then  'filter by departments
            vFilter += " and DeptCd='" & cmbDept.SelectedValue & "' "
        Else
            vFilter += " and DeptCd in ('" & Session("deptlist").ToString.Replace(",", "','") & "') "
        End If
        If cmbSection.SelectedValue <> "All" Then 'filter by section
            vFilter += " and SectionCd='" & cmbSection.SelectedValue & "' "
        Else
            vFilter += " and SectionCd in ('" & Session("sectionlist").ToString.Replace(",", "','") & "') "
        End If
        If cmbUnit.SelectedValue <> "All" Then  'filter by units
            vFilter += " and UnitCd='" & cmbUnit.SelectedValue & "' "
        Else
            vFilter += " and UnitCd in ('" & Session("unitlist").ToString.Replace(",", "','") & "') "
        End If
        If cmbSecurity.SelectedValue <> "All" Then
            vFilter += " and EmploymentType='" & cmbSecurity.SelectedValue & "' "
        Else
            vFilter += " and EmploymentType in ('" & Session("typelist").ToString.Replace(",", "','") & "') "
        End If
        If cmbPos.SelectedValue <> "All" Then
            vFilter += " and Pos_Cd='" & cmbPos.SelectedValue & "' "
        End If
        If rdoBAP.SelectedValue <> -1 Then
            vFilter += " and BAPEnrolled=" & rdoBAP.SelectedValue
        End If
        Select Case rdoStatus.SelectedValue
            Case 1  'active
                vFilter += " and Date_Resign is null "
            Case 0  'inactive
                vFilter += " and Date_Resign is not null "
        End Select
        
        Try
            c.Open()
        Catch ex As sqlclient.sqlexception
            vScript = "alert('Error occurred while trying to connect to SQL Server. Error is: " & _
                ex.Message.Replace(vbCrLf, "\n").Replace("'", "\'") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        cm.Connection = c
        cm.CommandText = "select Emp_Cd,Emp_Lname+', '+Emp_Fname as EmpName from py_emp_master " & _
            vFilter & " order by Emp_Lname,Emp_Fname,Emp_Mname"

        chkEmp.Items.Clear()
        Try
            dr = cm.ExecuteReader
            Do While dr.Read
                chkEmp.Items.Add(dr("Emp_Cd") & "=>" & dr("EmpName"))
            Loop
            dr.Close()
        Catch ex As sqlclient.sqlexception
            vScript = "alert('Error occurred while retrieving the list of employees. Error is: " & _
                ex.Message.Replace(vbCrLf, "\n").Replace("'", "\'") & "');"
        Finally
            c.Close()
            c.Dispose()
            cm.Dispose()
        End Try
    End Sub

    Protected Sub cmdRefresh_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdRefresh.Click
        DataRefresh()
    End Sub

    Protected Sub cmdSelect_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSelect.Click
        SetChk(True)
    End Sub
    Private Sub SetChk(ByVal pState As Boolean)
        Dim iCtr As Integer

        For iCtr = 0 To chkEmp.Items.Count - 1
            chkEmp.Items(iCtr).Selected = pState
        Next iCtr
    End Sub

    Protected Sub cmdDeselect_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDeselect.Click
        SetChk(False)
    End Sub

    Protected Sub cmdReturn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.Click
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        If Page.IsValid Then
            Dim c As New sqlclient.sqlconnection(connStr)
            Dim cm As New sqlclient.sqlcommand
            Dim rs As sqlclient.sqldatareader
            Dim vStr As String = ""
            Dim vSelected As Boolean = False
            Dim iCtr As Integer
            Dim vValue As Double = 0
            Dim vExist As Boolean = False

            'ensure that there should be at least one selected employee
            For iCtr = 0 To chkEmp.Items.Count - 1
                If chkEmp.Items(iCtr).Selected Then
                    vSelected = True
                    Exit For
                End If
            Next iCtr
            If Not vSelected Then
                vScript = "alert('You must first select at least one employee.');"
                Exit Sub
            End If

            Try
                c.Open()
            Catch ex As sqlclient.sqlexception
                vScript = "alert('Error occurred while trying to connect to SQL Server. Error is: " & _
                    ex.Message.Replace(vbCrLf, "\n").Replace("'", "\'") & "');"
                c.Dispose()
                cm.Dispose()
                Exit Sub
            End Try

            cm.Connection = c

            vStr = ""
            txtEmpList.Value = ""
            For iCtr = 0 To chkEmp.Items.Count - 1
                If chkEmp.Items(iCtr).Selected Then

                    Try
                        'before inserting the record... ensure that there's no paid transaction in the amortization ledger
                        cm.CommandText = "select 1 from py_loan_dtl where Emp_Cd='" & _
                            ExtractData(chkEmp.Items(iCtr).Text) & "' and Loan_Cd='" & _
                            cmbLoan.SelectedValue & "' and Loan_Date='" & _
                            Format(CDate(txtLoanDate.Text), "yyyy/MM/dd") & "' and Paid=1"
                        rs = cm.ExecuteReader
                        vExist = rs.HasRows
                        rs.Close()

                        If Not vExist Then
                            txtEmpList.Value += ExtractData(chkEmp.Items(iCtr).Text) & ","
                            'clean-up any existing data....
                            cm.CommandText = "delete from py_loan_dtl where Emp_Cd='" & _
                                ExtractData(chkEmp.Items(iCtr).Text) & "' and Loan_Cd='" & _
                                cmbLoan.SelectedValue & "' and Loan_Date='" & _
                                Format(CDate(txtLoanDate.Text), "yyyy/MM/dd") & "'"
                            cm.ExecuteNonQuery()
                            cm.CommandText = "delete from py_loan_hdr where Emp_Cd='" & _
                                ExtractData(chkEmp.Items(iCtr).Text) & "' and Loan_Cd='" & _
                                cmbLoan.SelectedValue & "' and Loan_Date='" & _
                                Format(CDate(txtLoanDate.Text), "yyyy/MM/dd") & "'"
                            cm.ExecuteNonQuery()

                            ''''' now insert the new Loan Ledger settings....
                            cm.CommandText = "insert into py_loan_hdr (Emp_Cd,Loan_Cd,Amt_Bal,Amt_Loan,Amt_Paid," & _
                                "Loan_Date,Start_Date,Int_Rate,Month_to_Pay,Active,ProdDescr,MonthlyAmort," & _
                                "Recurring,End_Date,FreqCd,DocNo) values ('" & _
                                ExtractData(chkEmp.Items(iCtr).Text) & "','" & cmbLoan.SelectedValue & _
                                "'," & txtBal.Text & "," & txtLoanAmt.Text & "," & txtAmtPaid.Text & _
                                ",'" & Format(CDate(txtLoanDate.Text), "yyyy/MM/dd") & "','" & _
                                Format(CDate(txtStartDate.Text), "yyyy/MM/dd") & "'," & txtInterest.Text & _
                                "," & txtNoOfPayments.Text & ",1,'" & txtRemarks.Text & _
                                "'," & txtMonthly.Text & "," & IIf(chkRecurring.Checked, 1, 0) & _
                                ",'" & Format(CDate(txtEndDate.Text), "yyyy/MM/dd") & _
                                "','" & cmbFreq.SelectedValue & "','" & txtDocNo.Text & "')"
                            cm.ExecuteNonQuery()
                        End If
                    Catch ex As sqlclient.sqlexception
                        vScript = "alert('Error occurred while inserting the loan ledger of Employee " & _
                            chkEmp.Items(iCtr).Text & ". Error is: " & _
                            ex.Message.Replace(vbCrLf, "\n").Replace("'", "\'") & "');"
                        c.Close()
                        cm.Dispose()
                        c.Dispose()
                        Exit Sub
                    End Try
                End If
            Next iCtr
            If txtEmpList.Value <> "" Then  'remove last comma
                txtEmpList.Value = Mid(txtEmpList.Value, 1, Len(txtEmpList.Value) - 1)
            End If

            vScript = "alert('Loan Ledgers were successfully posted to target deduction. " & _
                "System will now start building the Loan Amortization Schedule for each selected employee. " & _
                "Click Ok to continue....'); computeLedger();"
            cm.Dispose()
            c.Close()
            c.Dispose()
            cm.Dispose()
            SetChk(False)
        End If
    End Sub

    Protected Sub vldDate_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles vldDate.ServerValidate
        If Not IsDate(txtLoanDate.Text) Then
            vScript = "alert('Invalid date format in Loan Date field.');"
            args.IsValid = False
            Exit Sub
        End If
        If Not IsDate(txtStartDate.Text) Then
            vScript = "alert('Invalid date format in Start Date field.');"
            args.IsValid = False
            Exit Sub
        End If

        If Not IsNumeric(txtLoanAmt.Text) Then
            vScript = "alert('Invalid numeric format in Loan Amount field.');"
            args.IsValid = False
            Exit Sub
        End If
        If Not IsNumeric(txtInterest.Text) Then
            vScript = "alert('Invalid numeric format in Interest field.');"
            args.IsValid = False
            Exit Sub
        End If
        If Not IsNumeric(txtAmtPaid.Text) Then
            vScript = "alert('Invalid numeric format in Amount paid field.');"
            args.IsValid = False
            Exit Sub
        End If
        If Not IsNumeric(txtBal.Text) Then
            vScript = "alert('Invalid numeric format in Balance field.');"
            args.IsValid = False
            Exit Sub
        End If
        If Not IsNumeric(txtNoOfPayments.Text) Then
            vScript = "alert('Invalid numeric format in # of payments field.');"
            args.IsValid = False
            Exit Sub
        End If
        If Not IsNumeric(txtMonthly.Text) Then
            vScript = "alert('Ivalid numeric format in Amortization field.');"
            args.IsValid = False
            Exit Sub
        End If
    End Sub

    Protected Sub txtLoanAmt_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtLoanAmt.Init
        txtLoanAmt.Attributes.Add("onblur", "compute();")
    End Sub

    Protected Sub txtInterest_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtInterest.Init
        txtInterest.Attributes.Add("onblur", "compute();")
    End Sub

    Protected Sub txtAmtPaid_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtAmtPaid.Init
        txtAmtPaid.Attributes.Add("onblur", "compute();")
    End Sub

    Protected Sub txtBal_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtBal.Init
        txtBal.Attributes.Add("onblur", "computeamtpaid();")
    End Sub

    Protected Sub txtNoOfPayments_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtNoOfPayments.Init
        txtNoOfPayments.Attributes.Add("onblur", "computeamort();")
    End Sub

    Protected Sub txtMonthly_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtMonthly.Init
        txtMonthly.Attributes.Add("onblur", "computefreq();")
    End Sub

    Protected Sub cmbFreq_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbFreq.SelectedIndexChanged
        If cmbFreq.SelectedValue <> "-1" Then
            If Not IsDate(txtStartDate.Text) Then
                vScript = "alert('Invalid date format in Start Date field.');"
                Exit Sub
            End If
            If Not IsNumeric(txtNoOfPayments.Text) Then
                vScript = "alert('Invalid numeric format in # of payments field.');"
                Exit Sub
            End If
            txtEndDate.Text = DateAdd(DateInterval.Month, Val(txtNoOfPayments.Text) / 2, CDate(txtStartDate.Text))
            Select Case cmbFreq.SelectedValue
                Case "15"
                    txtEndDate.Text = CDate(txtEndDate.Text).Month & "/15/" & CDate(txtEndDate.Text).Year
                Case "30"
                    txtEndDate.Text = MonthEND(CDate(txtEndDate.Text))
            End Select
        Else
            vScript = "alert('You must select if Every Payroll, or Every 1st or 2nd period.');"
        End If
    End Sub
End Class
