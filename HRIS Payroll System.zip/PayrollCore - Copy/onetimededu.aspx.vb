Imports denaro.fis
Partial Class onetimededu
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Dim Css As String = "odd"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Session("returnaddr") = "dailylog.aspx"
            Server.Transfer("index.aspx")
        End If

        If Not CanRun(Session("caption"), Request.Item("id")) Then
            Session("denied") = "1"
            Server.Transfer("main.aspx")
            Exit Sub
        End If

        lblCaption.Text = "One Time Incentives and Deductions"

        If Not IsPostBack Then
            BuildCombo("select Rc_Cd,Descr from rc where exists (select User_Id from rights_list where User_Id='" & _
                 Session("uid") & "' and property='rc' and Property_Value=Rc_Cd) order by Descr", cmbRC)
            BuildCombo("select AgencyCd,AgencyName from agency where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='agency' and Property_Value=AgencyCd) order by AgencyName", cmbOfc)
            BuildCombo("select Div_Cd,Descr from hr_div_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='division' and Property_Value=Div_Cd) order by Descr", cmbDiv)
            BuildCombo("select Dept_Cd,Descr from hr_dept_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='department' and Property_Value=Dept_Cd) order by Descr", cmbDept)
            BuildCombo("select Section_Cd,Descr from hr_section_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='section' and Property_Value=Section_Cd) order by Descr", cmbSection)
            BuildCombo("select Unit_Cd,Descr from hr_unit_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='unit' and Property_Value=Unit_Cd) order by Descr", cmbUnit)
            BuildCombo("select EmploymentType,Descr from hr_employment_type where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='employmenttype' and Property_Value=EmploymentType) order by Descr", cmbEmpType)

            cmbRC.Items.Add("All")
            cmbRC.SelectedValue = "All"
            cmbOfc.Items.Add("All")
            cmbOfc.SelectedValue = "All"
            cmbDiv.Items.Add("All")
            cmbDiv.SelectedValue = "All"
            cmbDept.Items.Add("All")
            cmbDept.SelectedValue = "All"
            cmbSection.Items.Add("All")
            cmbSection.SelectedValue = "All"
            cmbUnit.Items.Add("All")
            cmbUnit.SelectedValue = "All"
            cmbEmpType.Items.Add("All")
            cmbEmpType.SelectedValue = "All"
            Session("letter") = "A"
            rdoList.SelectedValue = "0"
            cmbMonth.SelectedValue = Now.Month
            getPeriods()
            getDtls()
        End If
    End Sub

    Private Sub getPeriods()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim vCredits() As String

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace("'", "").Replace(vbCrLf, "") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        cm.Connection = c
        cm.CommandText = "select CreditDay from py_pay_mode where Pay_Cd='SM'"
        Try
            rs = cm.ExecuteReader
            If rs.Read Then
                vCredits = rs("CreditDay").ToString.Split(",")
            End If
            rs.Close()
            cmbPayDate.Items.Clear()
            For Each vCredit In vCredits
                If vCredit = "30" Then
                    cmbPayDate.Items.Add(MonthEND(cmbMonth.SelectedValue & "/1/" & Now.Year))
                Else
                    cmbPayDate.Items.Add(cmbMonth.SelectedValue & "/" & vCredit & "/" & Now.Year)
                End If

            Next
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to retrieve Payment modes. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            c.Dispose()
            cm.Dispose()
        End Try
    End Sub
    Protected Sub rdoList_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rdoList.SelectedIndexChanged
        getDtls()
    End Sub
    Private Sub getDtls()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader

        c.Open()
        cm.Connection = c

        lstDtl.Items.Clear()
        If rdoList.SelectedValue = "0" Then
            cm.CommandText = "SELECT Incentive_Cd, Descr FROM py_other_incentvs ORDER BY Descr"
            cmdAdd.Text = "Add Incentive"
            cmdEdit.Text = "Edit Incentive"
            cmdDelete.Text = "Delete Incentive"
            lblType.Text = "Incentive Type"
        Else
            cm.CommandText = "SELECT Loan_Cd, Loan_Name FROM py_loan_ref ORDER BY Loan_Name"
            cmdAdd.Text = "Add Loan"
            cmdEdit.Text = "Edit Loan"
            cmdDelete.Text = "Delete Loan"
            lblType.Text = "Loan Type"

        End If

        rs = cm.ExecuteReader
        Do While rs.Read
            lstDtl.Items.Add(New ListItem(rs(1), rs(0)))
        Loop
        rs.Close()

        cm.Dispose()
        c.Close()
        c.Dispose()
        getTable()
    End Sub

    Private Sub getTable(Optional ByVal pSearch As String = "")
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim da As SqlClient.SqlDataAdapter
        Dim ds As New DataSet
        Dim vSql As String = ""
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader

        Dim vFilter As String = ""
        Dim vStartDate As String = ""
        Dim vEndDate As String = ""


        vFilter += " where Emp_Lname like '" & pSearch & "%' "
        If cmbRC.SelectedValue <> "All" Then   'filter by cost center
            vFilter += " and Rc_Cd='" & cmbRC.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='rc' and Property_Value=Rc_Cd) "
        End If

        If cmbOfc.SelectedValue <> "All" Then        'filter by office/agency
            vFilter += " and Agency_Cd='" & cmbOfc.SelectedValue & "' "
        Else
            vFilter += "  and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='agency' and Property_Value=Agency_Cd) "
        End If
        If cmbDiv.SelectedValue <> "All" Then      'filter by division
            vFilter += " and Divcd='" & cmbDiv.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='division' and Property_Value=DivCd) "
        End If
        If cmbDept.SelectedValue <> "All" Then  'filter by departments
            vFilter += " and DeptCd='" & cmbDept.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='department' and Property_Value=DeptCd) "
        End If
        If cmbSection.SelectedValue <> "All" Then 'filter by section
            vFilter += " and SectionCd='" & cmbSection.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='section' and Property_Value=SectionCd) "
        End If
        If cmbUnit.SelectedValue <> "All" Then  'filter by units
            vFilter += " and UnitCd='" & cmbUnit.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='unit' and Property_Value=UnitCd) "
        End If
        If cmbEmpType.SelectedValue <> "All" Then 'filter by employment types
            vFilter += " and EmploymentType='" & cmbEmpType.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='employmenttype' and Property_Value=EmploymentType) "
        End If

        c.Open()
        cm.Connection = c

        'modified by vic on 6/10/2011
        cm.CommandText = "select CreditDay,Days from py_pay_mode where Pay_Cd='SM'"

        'cm.CommandText = "Select FromDate,ToDate from py_report where paydate='" & _
        '    Format(CDate(cmbPayDate1.SelectedValue), "yyyy/MM/dd") & "'"
        rs = cm.ExecuteReader
        If rs.Read Then
            Dim vCredits() As String
            Dim vDays() As String

            vCredits = rs("CreditDay").ToString.Split(",")
            vDays = rs("Days").ToString.Split(",")
            For i As Integer = 0 To UBound(vCredits)
                If vCredits(i) = CDate(cmbPayDate.SelectedValue).Day Or _
                   (vCredits(i) = 30 And (CDate(cmbPayDate.SelectedValue).Day = 29 Or CDate(cmbPayDate.SelectedValue).Day = 30 Or CDate(cmbPayDate.SelectedValue).Day = 31)) Then
                    If i = UBound(vCredits) Then
                        vEndDate = vDays(0) - 1
                        If vCredits(i) < vDays(i) Then
                            vStartDate = IIf(cmbMonth.SelectedValue - 1 = 0, 12, cmbMonth.SelectedValue - 1) & "/" & vDays(i) & "/" & _
                                IIf(cmbMonth.SelectedValue - 1 = 0, Now.Year - 1, Now.Year)
                            vEndDate = CDate(cmbMonth.SelectedValue & "/" & vDays(0) & "/" & Now.Year).AddDays(-1)
                        End If
                    Else
                        If vCredits(i) > vDays(i + 1) - 1 Then
                            vStartDate = cmbMonth.SelectedValue & "/" & vDays(i) & "/" & Now.Year
                            vEndDate = cmbMonth.SelectedValue & "/" & vDays(i + 1) - 1 & "/" & Now.Year
                        Else
                            vStartDate = IIf(cmbMonth.SelectedValue - 1 = 0, 12, cmbMonth.SelectedValue - 1) & "/" & vDays(i) & "/" & _
                                IIf(cmbMonth.SelectedValue - 1 = 0, Now.Year - 1, Now.Year)
                            vEndDate = IIf(cmbMonth.SelectedValue - 1 = 0, 12, cmbMonth.SelectedValue - 1) & "/" & vDays(i + 1) - 1 & "/" & _
                                IIf(cmbMonth.SelectedValue - 1 = 0, Now.Year - 1, Now.Year)
                        End If
                    End If
                End If
            Next
            'vStartDate = rs(0)
            'vEndDate = rs(1)
            txtStartDate.Value = vStartDate
            txtEndDate.Value = vEndDate
        End If
        rs.Close()

        If vStartDate <> "" Then
            If rdoList.SelectedValue = "0" Then
                vSql = "Select Id,a.Emp_Cd, (Emp_Lname +', '+Emp_Fname) as Name, Incentive_Amt as Amount, " & _
                        "CAST(convert(datetime,FromDate,101) as varchar)+' - '+cast(convert(datetime,ToDate,101) AS VARCHAR) as Cutoff " & _
                       "from py_incentives_dtl a, py_emp_master b" & _
                       vFilter & " and a.Emp_Cd=b.Emp_Cd and Incentive_Cd='" & lstDtl.SelectedValue & "' " & _
                       "and FromDate between '" & Format(CDate(vStartDate), "yyyy/MM/dd") & _
                       "' and '" & Format(CDate(vEndDate), "yyyy/MM/dd") & "' order by Emp_Lname,Emp_Fname"
            Else
                vSql = "Select Id,a.Emp_Cd, (Emp_Lname+', '+Emp_Fname) as Name, Amt_Loan as Amount," & _
                        "convert(datetime,Loan_Date,101) as Cutoff " & _
                       "from py_loan_hdr a, py_emp_master b" & _
                       vFilter & " and Loan_Cd='" & lstDtl.SelectedValue & "' and Loan_Date between '" & _
                       Format(CDate(vStartDate), "yyyy/MM/dd") & "' and '" & _
                       Format(CDate(vEndDate), "yyyy/MM/dd") & "' " & _
                       "and a.Emp_Cd=b.Emp_Cd and Month_to_Pay='1' and Amt_Loan=MonthlyAmort and Loan_Date=a.Start_date" & _
                       " order by Emp_Lname,Emp_Fname"
            End If

            da = New SqlClient.SqlDataAdapter(vSql, c)
            da.Fill(ds, "EmpMaster")
            tblEmp.DataSource = ds.Tables("EmpMaster")
            tblEmp.DataBind()
            ds.Dispose()
            da.Dispose()
        End If
        cm.Dispose()
        c.Close()
        c.Dispose()
        Me.tblEmp.SelectedIndex = -1
    End Sub
    Protected Sub cmdReturn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.Click
        Server.Transfer("main.aspx")
        Session.Remove("letter")
    End Sub

    Protected Sub cmdAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdAdd.Click
        If lstDtl.SelectedIndex >= 0 Then
            vScript = "open('onetimededupop.aspx?sDate=" & txtStartDate.Value & _
                "&eDate=" & txtEndDate.Value & _
                "&Type=" & lstDtl.SelectedValue & _
                "&rdo=" & rdoList.SelectedValue & _
                "&mode=a', 'win', 'width=500,height=240,status=no,resizable=no,top=200,left=300,dependent=yes,alwaysRaised=yes,scrollbars=no')"
        Else
            vScript = "alert('Please select " & lblType.Text.ToLower & " first.');"
        End If
    End Sub

    Protected Sub cmdEdit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdEdit.Click
        If tblEmp.SelectedIndex >= 0 Then
            Dim vID As String = tblEmp.SelectedRow.Cells(0).Text
            Dim vEmp As String = tblEmp.SelectedRow.Cells(1).Text
            Dim vAmt As Decimal = tblEmp.SelectedRow.Cells(3).Text
            vScript = "open('onetimededupop.aspx?sDate=" & txtStartDate.Value & _
                "&eDate=" & txtEndDate.Value & _
                "&Type=" & lstDtl.SelectedValue & _
                "&rdo=" & rdoList.SelectedValue & _
                "&mode=e&vID=" & vID & _
                "&vEmp=" & vEmp & _
                "&vAmt=" & vAmt & _
                "', 'win', 'width=500,height=240,status=no,resizable=no,top=200,left=300,dependent=yes,alwaysRaised=yes,scrollbars=no')"
        Else
            vScript = "alert('Please select employee first.');"
        End If
    End Sub

    Protected Sub cmdDelete_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDelete.Click
        If tblEmp.SelectedIndex >= 0 Then
            Dim c As New sqlclient.sqlconnection(connStr)
            Dim cm As New sqlclient.sqlcommand
            Dim vID As String = tblEmp.SelectedRow.Cells(0).Text
            Dim vEmp As String = tblEmp.SelectedRow.Cells(1).Text
            Dim vAmt As Decimal = tblEmp.SelectedRow.Cells(3).Text
            Dim vTran As String = tblEmp.SelectedRow.Cells(4).Text
            c.Open()
            cm.Connection = c

            If rdoList.SelectedValue = "0" Then
                cm.CommandText = "DELETE FROM py_incentives_dtl WHERE Id = '" & vID & "'"
                Try
                    cm.ExecuteNonQuery()
                    vScript = "alert('Record successfully deleted.');"
                Catch ex As sqlclient.sqlException
                    vScript = "alert('Error occured while deleting.');"
                End Try
            Else
                cm.CommandText = "Delete from py_loan_dtl where Emp_Cd='" & vEmp & "' and Amt_Cost='" & vAmt & "' and Tran_Date='" & vTran & "'"
                Try
                    cm.ExecuteNonQuery()
                    cm.CommandText = "DELETE FROM py_loan_hdr WHERE Id = '" & vID & "'"
                    Try
                        cm.ExecuteNonQuery()
                        vScript = "alert('Record successfully deleted.');"
                    Catch ex As system.exception
                        vScript = "alert('Error occured while deleting.');"
                    End Try

                Catch ex As sqlclient.sqlException
                    vScript = "alert('Error occured while deleting.');"
                End Try
            End If
            cm.Dispose()
            c.Close()
            c.Dispose()
        Else
            vScript = "alert('Please select employee first.');"
        End If
        getTable()
    End Sub

    Protected Sub tblEmp_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles tblEmp.PageIndexChanging
        Me.tblEmp.PageIndex = e.NewPageIndex
        Me.tblEmp.SelectedIndex = -1
        getTable()
    End Sub

    Protected Sub lstDtl_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles lstDtl.SelectedIndexChanged
        getTable()
    End Sub

    Protected Sub cmdSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSearch.Click
        getTable(txtSearch.Text)
    End Sub

    Protected Sub cmbMonth_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbMonth.SelectedIndexChanged
        getPeriods()
    End Sub
End Class
