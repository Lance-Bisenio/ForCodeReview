Imports denaro
Partial Class modifyprofile
    Inherits System.Web.UI.Page
    Public vScript As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            vScript = "alert('Your login session has expired. Please re-login again.'); window.close();"
            Exit Sub
        End If

        If Not IsPostBack Then
            Dim c As New SqlClient.SqlConnection(connStr)
            Dim cm As New SqlClient.SqlCommand
            Dim dr As SqlClient.SqlDataReader
            Dim vList As String = ""
            Dim vIncent(60) As String
            Dim vDeduct(60) As String
            Dim vIncentName(60) As String
            Dim vDeductName(60) As String
            Dim vSelections() As String
            Dim iCtr As Integer
            Dim iLoop As Integer

            txtProfileId.Text = Request.Item("p")
            lblCaption.Text = "Add/Modify Profile"

            Try
                c.Open()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                c.Dispose()
                cm.Dispose()
                Exit Sub
            End Try

            cm.Connection = c

            BuildCombo("select AcctCd,AcctName from coa order by SeqId", cmbCOA, c)

            cm.CommandText = "select * from py_syscntrl"

            Try
                dr = cm.ExecuteReader
                For iCtr = 1 To 60
                    vDeduct(iCtr - 1) = ""
                    vIncent(iCtr - 1) = ""
                Next

                If dr.Read Then
                    For iCtr = 1 To 60
                        If Not IsDBNull(dr("OthDed" & iCtr & "Cd")) Then
                            If dr("OthDed" & iCtr & "Cd").ToString.Trim <> "" Then
                                vDeduct(iCtr - 1) = dr("OthDed" & iCtr & "Cd")
                            End If
                        End If
                        If Not IsDBNull(dr("OthIncent" & iCtr & "Cd")) Then
                            If dr("OthIncent" & iCtr & "Cd").ToString.Trim <> "" Then
                                vIncent(iCtr - 1) = dr("OthIncent" & iCtr & "Cd")
                            End If
                        End If
                    Next iCtr
                End If
                dr.Close()

                For iCtr = 1 To 60
                    cm.CommandText = "select Loan_Name from py_loan_ref where Loan_Cd='" & vDeduct(iCtr - 1) & "'"
                    dr = cm.ExecuteReader
                    If dr.Read Then
                        vDeductName(iCtr - 1) = dr("Loan_Name")
                    Else
                        vDeductName(iCtr - 1) = vDeduct(iCtr)
                    End If
                    dr.Close()

                    cm.CommandText = "select Descr from py_other_incentvs where Incentive_Cd='" & vIncent(iCtr - 1) & "'"
                    dr = cm.ExecuteReader
                    If dr.Read Then
                        vIncentName(iCtr - 1) = dr("Descr")
                    Else
                        vIncentName(iCtr - 1) = vIncent(iCtr)
                    End If
                    dr.Close()
                Next iCtr
            Catch ex As SqlClient.SqlException
                vScript = "alert('An error occurred while trying to retrieve system settings. Error is: " & ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                c.Close()
                c.Dispose()
                cm.Dispose()
                Exit Sub
            End Try

            For iCtr = 1 To 60
                If vIncentName(iCtr - 1) <> "" Then
                    chkField.Items.Add(New ListItem(vIncentName(iCtr - 1), "Other_Incent" & iCtr))
                End If
            Next
            For iCtr = 1 To 60
                If vDeductName(iCtr - 1) <> "" Then
                    chkField.Items.Add(New ListItem(vDeductName(iCtr - 1), "Other_Deduct" & iCtr))
                End If
            Next

            If Request.Item("m") = "a" Then         'add mode
                cm.CommandText = "select TOP 1 SeqId from post_info where CaptionName='" & Request.Item("p") & _
                    "' order by SeqId Desc"
                dr = cm.ExecuteReader
                If dr.Read Then
                    txtSeq.Text = dr("SeqId") + 5
                Else
                    txtSeq.Text = 5
                End If
                dr.Close()
                txtProfileId.Text = Request.Item("p")
            Else                                    'edit mode
                cm.CommandText = "select * from post_info where CaptionName='" & Request.Item("p") & _
                    "' and SeqId=" & Request.Item("id")
                dr = cm.ExecuteReader
                If dr.Read Then
                    txtSeq.Text = dr("SeqId")
                    cmbCOA.SelectedValue = dr("AcctCd")
                    txtGroupBy.Text = IIf(IsDBNull(dr("GroupByDump")), "", dr("GroupByDump"))
                    txtGroup.Text = IIf(IsDBNull(dr("GroupBy")), "", dr("GroupBy"))
                    rdoDrCr.SelectedValue = IIf(dr("DrCr") = 0, 0, 1)
                    rdoByEmp.SelectedValue = IIf(dr("ByEmployee") = 0, 0, 1)
                    vList = dr("FieldName")
                    txtCondition.Text = IIf(IsDBNull(dr("Condition")), "", dr("Condition"))
                End If
                dr.Close()
                If vList <> "" Then
                    vSelections = vList.Split(",")
                    For iCtr = 0 To UBound(vSelections)
                        For iLoop = 0 To chkField.Items.Count - 1
                            If chkField.Items(iLoop).Value = vSelections(iCtr) Then
                                chkField.Items(iLoop).Selected = True
                                Exit For  'iloop
                            End If
                        Next iLoop
                    Next iCtr
                End If
            End If
            cm.Dispose()
            c.Close()
        End If
    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        If txtCondition.Text.Trim <> "" Then
            Dim vStatus As String = ""

            vStatus = CheckSyntax()
            If vStatus <> "" Then
                vScript = vStatus
                Exit Sub
            End If
        End If

        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim vList As String = ""
        Dim iCtr As Integer

        If Not IsNumeric(txtSeq.Text) Then
            vScript = "alert('Invalid numeric value in field Line #. Please enter a valid number.');"
            Exit Sub
        End If
        If rdoDrCr.SelectedIndex < 0 Then
            vScript = "alert('You must select whether Debit or Credit side entry.');"
            Exit Sub
        End If
        For iCtr = 0 To chkField.Items.Count - 1
            If chkField.Items(iCtr).Selected Then
                vList += chkField.Items(iCtr).Value & ","
            End If
        Next iCtr
        If vList <> "" Then vList = vList.Substring(0, vList.Length - 1)

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        cm.Connection = c

        If Request.Item("m") = "a" Then       'add mode
            cm.CommandText = "insert into post_info (SeqId,CaptionName,AcctCd,DrCr,TableName," & _
                "FieldName,GroupBy,GroupByDump,ByEmployee,Condition) " & _
                "values (" & txtSeq.Text & ",'" & txtProfileId.Text & "','" & cmbCOA.SelectedValue & _
                "'," & rdoDrCr.SelectedValue & ",'py_report','" & vList & "', '" & txtGroup.Text & _
                "', '" & txtGroupBy.Text & "', " & rdoByEmp.SelectedValue & ",'" & _
                txtCondition.Text.Replace("'", "''") & "')"

        Else                                'edit mode
            cm.CommandText = "update post_info set SeqId=" & txtSeq.Text & _
                ",CaptionName='" & txtProfileId.Text & _
                "',AcctCd='" & cmbCOA.SelectedValue & _
                "',DrCr=" & rdoDrCr.SelectedValue & _
                ",GroupBy='" & txtGroup.Text & _
                "',GroupByDump='" & txtGroupBy.Text & _
                "',ByEmployee=" & rdoByEmp.SelectedValue & _
                ",FieldName='" & vList & _
                "',Condition='" & txtCondition.Text.Replace("'", "''") & _
                "' where CaptionName='" & txtProfileId.Text & _
                "' and SeqId=" & Request.Item("id")
        End If
        Try
            cm.ExecuteNonQuery()
            vScript = "alert('Changes were successfully saved. Click the Refresh button to reload the data.'); window.close();"
        Catch ex As system.exception
            vScript = "alert('An error occurred while trying to save your changes. The error is: " & _
                ex.Message.Replace("'", "") & ".');"
        End Try
        cm.Dispose()
        c.Close()
        c.Dispose()
    End Sub
    Private Function CheckSyntax() As String
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand("select top 1 * from py_report where " & txtCondition.Text, c)
        Dim rs As SqlClient.SqlDataReader
        Dim vErrMsg As String = ""

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vErrMsg = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            Return vErrMsg
            Exit Function
        End Try

        Try
            rs = cm.ExecuteReader
            If rs.Read Then

            End If
            rs.Close()
            Return vErrMsg
        Catch ex As SqlClient.SqlException
            vErrMsg = "alert('There\'s something wrong with your condition. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "\'") & "');"
        Finally
            c.Close()
            c.Dispose()
            cm.Dispose()
        End Try
        Return vErrMsg
    End Function
    Protected Sub cmdCheck_Click(sender As Object, e As EventArgs) Handles cmdCheck.Click
        If txtCondition.Text.Trim = "" Then
            vScript = "alert('You must have a value in the \'Condition\' field to continue with the syntax checking.');"
            Exit Sub
        End If

        Dim vStatus As String = ""

        vStatus = CheckSyntax()
        If vStatus = "" Then
            vScript = "alert('Syntax is correct.');"
        Else
            vScript = vStatus
        End If
    End Sub
End Class
