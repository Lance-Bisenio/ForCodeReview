﻿Imports denaro.fis
Partial Class rehire
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If
        If Not IsPostBack Then
            If Not CanRun(Session("caption"), Request.Item("id")) Then
                Session("denied") = "1"
                Server.Transfer("main.aspx")
                Exit Sub
            End If
            lblCaption.Text = "Re-hire separated employees"
            DataRefresh()
        End If
    End Sub
    Private Sub DataRefresh()
        Dim c As New sqlclient.sqlConnection(connStr)
        Dim da As sqlclient.sqlDataAdapter
        Dim ds As New DataSet
        Dim vFilter As String = ""

        If txtSearch.Text <> "" Then
            vFilter = " and " & cmbType.SelectedValue & " like '" & txtSearch.Text & "%' "
        End If
        da = New sqlclient.sqlDataAdapter("select Emp_Cd,Emp_Lname,Emp_Fname,Emp_Mname," & _
            "cast(date_format(Date_Resign,'%m/%d/%Y') as char) as Date_Resign,Nickname from py_emp_master " & _
            "where Date_Resign is not null " & vFilter & " order by Emp_Lname,Emp_Fname", c)

        da.Fill(ds, "Emp")
        tblEmp.DataSource = ds.Tables("Emp")
        tblEmp.DataBind()
        da.Dispose()
        ds.Dispose()
        tblEmp.PageIndex = 0
        tblEmp.SelectedIndex = -1
        Session.Remove("id")
    End Sub
    Protected Sub cmdClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdClose.Click
        Session.Remove("id")
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub tblEmp_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles tblEmp.PageIndexChanging
        tblEmp.PageIndex = e.NewPageIndex
        DataRefresh()
    End Sub

    Protected Sub cmdSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSearch.Click
        DataRefresh()
    End Sub
    Private Sub cmdA_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdA.Click, _
            cmdB.Click, cmdC.Click, cmdD.Click, cmdE.Click, cmdF.Click, cmdG.Click, cmdH.Click, cmdI.Click, _
            cmdJ.Click, cmdK.Click, cmdL.Click, cmdM.Click, cmdN.Click, cmdO.Click, cmdP.Click, cmdQ.Click, _
            cmdR.Click, cmdS.Click, cmdT.Click, cmdU.Click, cmdV.Click, cmdW.Click, cmdX.Click, cmdY.Click, cmdZ.Click
        txtSearch.Text = CType(sender, LinkButton).Text
        DataRefresh()
    End Sub

    Protected Sub tblEmp_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tblEmp.SelectedIndexChanged
        Session("id") = tblEmp.SelectedRow.Cells(0).Text
    End Sub

    Protected Sub cmdRehire_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdRehire.Click
        If tblEmp.SelectedIndex = -1 Then
            vScript = "alert('You must first select an employee to re-hire.');"
            Exit Sub
        Else
            vScript = "rehirewin = window.open('rehireprocess.aspx','rehire','toolbars=no,scrollbars=no,top=10,left=10,width=640,height=480,status=no'); rehirewin.focus();"
        End If
    End Sub
End Class
