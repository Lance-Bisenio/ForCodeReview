
Partial Class printpreview
    Inherits System.Web.UI.Page

End Class
