Imports denaro
Partial Class activateopis
    Inherits System.Web.UI.Page
    Public vscript As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        lblCaption.Text = "Activate Online Personnel Information System (OPIS)"
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
        End If
        If Not CanRun(Session("caption"), Request.Item("id")) Then
            Session("denied") = "1"
            Server.Transfer("main.aspx")
            Exit Sub
        End If

        If Not IsPostBack Then
                        'now set the default values

            'now build the reference code
            BuildCombo("select Rc_Cd, Descr from rc where Rc_Cd in ('" & _
                Session("rclist").ToString.Replace(",", "','") & "') order by Descr ", cmbRC)
            BuildCombo("select AgencyCd,AgencyName from agency where Agencycd in ('" & _
                Session("agencylist").ToString.Replace(",", "','") & "') order by AgencyName", cmbOfc)
            BuildCombo("select Div_Cd,Descr from hr_div_ref where Div_Cd in ('" & _
                Session("divlist").ToString.Replace(",", "','") & "') order by Descr", cmbDiv)
            BuildCombo("select Dept_Cd,Descr from hr_dept_ref where Dept_Cd in ('" & _
                Session("deptlist").ToString.Replace(",", "','") & "') order by Descr", cmbDept)
            BuildCombo("select Section_Cd,Descr from hr_section_ref where Section_Cd in ('" & _
                Session("sectionlist").ToString.Replace(",", "','") & "') order by Descr", cmbSection)
            BuildCombo("select Unit_Cd,Descr from hr_unit_ref where Unit_Cd in ('" & _
                Session("unitlist").ToString.Replace(",", "','") & "') order by Descr", cmbUnit)
            cmbRC.Items.Add("All")
            cmbRC.SelectedValue = "All"
            cmbOfc.Items.Add("All")
            cmbOfc.SelectedValue = "All"
            cmbDiv.Items.Add("All")
            cmbDiv.SelectedValue = "All"
            cmbDept.Items.Add("All")
            cmbDept.SelectedValue = "All"
            cmbSection.Items.Add("All")
            cmbSection.SelectedValue = "All"
            cmbUnit.Items.Add("All")
            cmbUnit.SelectedValue = "All"
        End If
    End Sub
    Private Sub cmdA_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdA.Click, _
            cmdB.Click, cmdC.Click, cmdD.Click, cmdE.Click, cmdF.Click, cmdG.Click, cmdH.Click, cmdI.Click, _
            cmdJ.Click, cmdK.Click, cmdL.Click, cmdM.Click, cmdN.Click, cmdO.Click, cmdP.Click, cmdQ.Click, _
            cmdR.Click, cmdS.Click, cmdT.Click, cmdU.Click, cmdV.Click, cmdW.Click, cmdX.Click, cmdY.Click, cmdZ.Click
        Session("letter") = CType(sender, LinkButton).Text
        
        DataRefresh(Session("letter"))
    End Sub
    Private Sub SetLetters(ByVal pLetter As String)
        Select Case pLetter.ToLower
            Case "a"
                cmdA.Visible = True
            Case "b"
                cmdB.Visible = True
            Case "c"
                cmdC.Visible = True
            Case "d"
                cmdD.Visible = True
            Case "e"
                cmdE.Visible = True
            Case "f"
                cmdF.Visible = True
            Case "g"
                cmdG.Visible = True
            Case "h"
                cmdH.Visible = True
            Case "i"
                cmdI.Visible = True
            Case "j"
                cmdJ.Visible = True
            Case "k"
                cmdK.Visible = True
            Case "l"
                cmdL.Visible = True
            Case "m"
                cmdM.Visible = True
            Case "n"
                cmdN.Visible = True
            Case "o"
                cmdO.Visible = True
            Case "p"
                cmdP.Visible = True
            Case "q"
                cmdQ.Visible = True
            Case "r"
                cmdR.Visible = True
            Case "s"
                cmdS.Visible = True
            Case "t"
                cmdT.Visible = True
            Case "u"
                cmdU.Visible = True
            Case "v"
                cmdV.Visible = True
            Case "w"
                cmdW.Visible = True
            Case "x"
                cmdX.Visible = True
            Case "y"
                cmdY.Visible = True
            Case "z"
                cmdZ.Visible = True
        End Select
    End Sub
    Private Sub DataRefresh(ByVal pLetter As String)
        Dim c As New sqlclient.sqlConnection(connStr)
        Dim cm As New sqlclient.sqlCommand
        Dim rs As sqlclient.sqlDataReader

        Dim vfilter As String = ""
        Dim vLtrFilter As String = ""

        c.Open()
        cm.Connection = c

        vfilter = " where " & cmbType.SelectedValue & " like '" & pLetter & "%' "
        vfilter += " and Date_Resign is null AND Date_Retired IS NULL AND DateHold IS NULL AND DateDismissed IS NULL"
        vLtrFilter += " where Date_Resign is null AND Date_Retired IS NULL AND DateHold IS NULL AND DateDismissed IS NULL"

        If cmbRC.SelectedValue <> "All" Then   'filter by cost center
            vfilter += " and Rc_Cd='" & cmbRC.SelectedValue & "' "
            vLtrFilter += " and Rc_Cd='" & cmbRC.SelectedValue & "' "
        Else
            'vfilter += " and Rc_Cd in ('" & Session("rclist").ToString.Replace(",", "','") & "') "
            vfilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='rc' and Property_Value=Rc_Cd) "
            vLtrFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                        "' and Property='rc' and Property_Value=Rc_Cd) "
        End If

        If cmbOfc.SelectedValue <> "All" Then        'filter by office/agency
            vfilter += " and Agency_Cd='" & cmbOfc.SelectedValue & "' "
            vLtrFilter += " and Agency_Cd='" & cmbOfc.SelectedValue & "' "
        Else
            vfilter += "  and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='agency' and Property_Value=Agency_Cd) "
            vLtrFilter += "  and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='agency' and Property_Value=Agency_Cd) "
        End If
        If cmbDiv.SelectedValue <> "All" Then      'filter by division
            vfilter += " and Divcd='" & cmbDiv.SelectedValue & "' "
            vLtrFilter += " and Divcd='" & cmbDiv.SelectedValue & "' "
        Else
            vfilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='division' and Property_Value=DivCd) "
            vLtrFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='division' and Property_Value=DivCd) "
        End If
        If cmbDept.SelectedValue <> "All" Then  'filter by departments
            vfilter += " and DeptCd='" & cmbDept.SelectedValue & "' "
            vLtrFilter += " and DeptCd='" & cmbDept.SelectedValue & "' "
        Else
            vfilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='department' and Property_Value=DeptCd) "
            vLtrFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='department' and Property_Value=DeptCd) "
        End If
        If cmbSection.SelectedValue <> "All" Then 'filter by section
            vfilter += " and SectionCd='" & cmbSection.SelectedValue & "' "
            vLtrFilter += " and SectionCd='" & cmbSection.SelectedValue & "' "
        Else
            vfilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='section' and Property_Value=SectionCd) "
            vLtrFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='section' and Property_Value=SectionCd) "
        End If
        If cmbUnit.SelectedValue <> "All" Then  'filter by units
            vfilter += " and UnitCd='" & cmbUnit.SelectedValue & "' "
            vLtrFilter += " and UnitCd='" & cmbUnit.SelectedValue & "' "
        Else
            vfilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='unit' and Property_Value=UnitCd) "
            vLtrFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='unit' and Property_Value=UnitCd) "
        End If

        vfilter += " and EmploymentType in ('" & Session("typelist").ToString.Replace(",", "','") & "') "

        cm.CommandText = "select Emp_Cd,Emp_Lname,Emp_Fname,Emp_Mname from py_emp_master " & vfilter & _
                         " and Emp_Cd not in(select ApplicantNo from hr_emp_tmp_master) order by Emp_Lname,Emp_Fname"
        rs = cm.ExecuteReader
        chkEmp.Items.Clear()
        Do While rs.Read
            chkEmp.Items.Add(New ListItem(rs("Emp_Cd") & "=>" & rs("Emp_Lname") & ", " & rs("Emp_Fname"), rs("Emp_Cd")))
        Loop
        rs.Close()

        cm.CommandText = "select distinct substring(Emp_Lname,1,1) as Letters from py_emp_master " & vLtrFilter
        rs = cm.ExecuteReader

        EnableAll(False)
        Do While rs.Read
            SetLetters(rs("Letters"))
        Loop
        rs.Close()
        c.Close()
        cm.Dispose()
        c.Dispose()


    End Sub
    Private Sub EnableAll(Optional ByVal pState As Boolean = False)
        cmdA.Visible = pState : cmdB.Visible = pState : cmdC.Visible = pState : cmdD.Visible = pState
        cmdE.Visible = pState : cmdF.Visible = pState : cmdG.Visible = pState : cmdH.Visible = pState
        cmdI.Visible = pState : cmdJ.Visible = pState : cmdK.Visible = pState : cmdL.Visible = pState
        cmdM.Visible = pState : cmdN.Visible = pState : cmdO.Visible = pState : cmdP.Visible = pState
        cmdQ.Visible = pState : cmdR.Visible = pState : cmdS.Visible = pState : cmdT.Visible = pState
        cmdU.Visible = pState : cmdV.Visible = pState : cmdW.Visible = pState : cmdX.Visible = pState
        cmdY.Visible = pState : cmdZ.Visible = pState
    End Sub
    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnRefresh.Click
        Session("letter") = txtSearch.Text
        DataRefresh(txtSearch.Text)
    End Sub

    Protected Sub cmdSelecAll_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSelecAll.Click
        Tick(1)
    End Sub
    Private Sub Tick(Optional ByVal pMode As Integer = 0)
        For i As Integer = 0 To chkEmp.Items.Count - 1
            If pMode = 1 Then
                chkEmp.Items(i).Selected = True
            Else
                chkEmp.Items(i).Selected = False
            End If
        Next
    End Sub

    Protected Sub cmdDeSelectAll_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDeSelectAll.Click
        Tick()
    End Sub

    Protected Sub cmdReturn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.Click
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub cmdActivate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdActivate.Click
        Dim c As New sqlclient.sqlConnection(connStr)
        Dim cExec As New sqlclient.sqlConnection(connStr)
        Dim cm As New sqlclient.sqlCommand
        Dim cmExec As New sqlclient.sqlCommand
        Dim rs As sqlclient.sqlDataReader

        c.Open()
        cExec.Open()
        cm.Connection = c
        cmExec.Connection = cExec
        For i As Integer = 0 To chkEmp.Items.Count - 1
            If chkEmp.Items(i).Selected Then
                'hr_emp_tmp_master
                cmExec.CommandText = "delete from hr_emp_tmp_master where ApplicantNo='" & chkEmp.Items(i).Value & "'"
                cmExec.ExecuteNonQuery()

                'hr_emp_tmp_scholastic
                cmExec.CommandText = "delete from hr_emp_tmp_scholastic where Emp_Cd='" & chkEmp.Items(i).Value & "'"
                cmExec.ExecuteNonQuery()

                'hr_emp_tmp_employment_hist
                cmExec.CommandText = "delete from hr_emp_tmp_employment_hist where Emp_Id='" & chkEmp.Items(i).Value & "'"
                cmExec.ExecuteNonQuery()

                'hr_emp_tmp_siblings(siblings)
                cmExec.CommandText = "delete from hr_emp_tmp_sibling where ApplicantNo='" & chkEmp.Items(i).Value & "'"
                cmExec.ExecuteNonQuery()

                'hr_emp_tmp_dependents (dependents,relatives)
                cmExec.CommandText = "delete from hr_emp_tmp_dependents where Application_No='" & chkEmp.Items(i).Value & "'"
                cmExec.ExecuteNonQuery()

                'hr_emp_tmp_trainings
                cmExec.CommandText = "delete from hr_emp_tmp_training where Emp_Id='" & chkEmp.Items(i).Value & "'"
                cmExec.ExecuteNonQuery()

                'hr_emp_tmp_license_ref
                cmExec.CommandText = "delete from hr_emp_tmp_license_ref where Emp_Cd='" & chkEmp.Items(i).Value & "'"
                cmExec.ExecuteNonQuery()

                cm.CommandText = "select * from py_emp_master where Emp_Cd='" & chkEmp.Items(i).Value & "'"
                rs = cm.ExecuteReader
                If rs.Read Then
                    cmExec.CommandText = "insert into hr_emp_tmp_master (ApplicantNo, Fname, Mname, Lname" & _
                    ", Pos_Cd, Address, Tel, Email" & _
                    ", Res_Cert, Sss_No, Gsis_No, Pagibig_No" & _
                    ", Tin, Usrname , TaxCd, Bday" & _
                    ", Male, Civil_Cd, Passwd, NickName" & _
                    ", Prov_Address, Skills, Self_Trainings, BirthPlace" & _
                    ", Height, Weight,ChildrenNo " & _
                    ", ReligionCd, DialectCd, LanguageCd, BloodType " & _
                    ", CountryCd, EmergencyContactPerson, CitizenCd, EmergencyContactNo " & _
                    ", OtherInfo, Spouse_Lname , Spouse_Fname , Spouse_Mname" & _
                    ", Spouse_Occupation, Spouse_Emr, Spouse_Bus_Addr, Spouse_Tel" & _
                    ", Father_Lname, Father_Fname, Father_Mname" & _
                    ", Mother_Lname, Mother_Fname, Mother_Mname" & _
                    ", PhicNo, Spouse_Prov, MobileNo, Zip" & _
                    ", City, FatherOcc, FatherAddress, FatherContact" & _
                    ", MotherOcc, MotherAddress, MotherContact" & _
                    ", fatherDeathCause, MotherDeathCause, EmergencyRelation" & _
                    ", EmergencyAddress, EmergencyEmail, FatherAlive" & _
                    ", MotherAlive, RegionCd,ProvCd,EyeColor, Haircolor" & _
                    ", DistingMark, ResCertPlaceIssued, RescertDateIssued" & _
                    ", SpouseAddress, SpouseProvAddress, FatherBday, MotherBday,MacOprtd)values('" & _
                    rs("Emp_Cd") & "'," & IIf(IsDBNull(rs("Emp_Fname")), "null", "'" & CleanVar(rs("Emp_Fname")) & "'") & "," & _
                    IIf(IsDBNull(rs("Emp_Mname")), "null", "'" & CleanVar(rs("Emp_Mname")) & "'") & "," & _
                    IIf(IsDBNull(rs("Emp_Lname")), "null", "'" & CleanVar(rs("Emp_Lname")) & "'") & "," & _
                    IIf(IsDBNull(rs("Pos_Cd")), "null", "'" & rs("Pos_Cd") & "'") & "," & _
                    IIf(IsDBNull(rs("Emp_Address")), "null", "'" & CleanVar(rs("Emp_Address")) & "'") & "," & _
                    IIf(IsDBNull(rs("Emp_Tel")), "null", "'" & CleanVar(rs("Emp_Tel")) & "'") & "," & _
                    IIf(IsDBNull(rs("Emp_Email")), "null", "'" & CleanVar(rs("Emp_Email")) & "'") & "," & _
                    IIf(IsDBNull(rs("Res_Cert")), "null", "'" & CleanVar(rs("Res_Cert")) & "'") & "," & _
                    IIf(IsDBNull(rs("Sss_No")), "null", "'" & CleanVar(rs("Sss_No")) & "'") & "," & _
                    IIf(IsDBNull(rs("Gsis_No")), "null", "'" & CleanVar(rs("Gsis_No")) & "'") & "," & _
                    IIf(IsDBNull(rs("Pagibig_No")), "null", "'" & CleanVar(rs("Pagibig_No")) & "'") & "," & _
                    IIf(IsDBNull(rs("Tin")), "null", "'" & CleanVar(rs("Tin")) & "'") & "," & _
                    IIf(IsDBNull(rs("User_Id")), "null", "'" & CleanVar(rs("User_Id")) & "'") & "," & _
                    IIf(IsDBNull(rs("Tax_Cd")), "null", "'" & rs("Tax_Cd") & "'") & "," & _
                    IIf(IsDBNull(rs("Bday")), "null", "'" & Format(rs("Bday"), "yyyy/MM/dd") & "'") & "," & _
                    IIf(IsDBNull(rs("Male")), 0, rs("Male")) & "," & _
                    IIf(IsDBNull(rs("Civil_Cd")), "null", "'" & rs("Civil_Cd") & "'") & "," & _
                    IIf(IsDBNull(rs("Pin")), "null", "'" & CleanVar(rs("Pin")) & "'") & "," & _
                    IIf(IsDBNull(rs("NickName")), "null", "'" & CleanVar(rs("NickName")) & "'") & "," & _
                    IIf(IsDBNull(rs("Prov_Address")), "null", "'" & CleanVar(rs("Prov_Address")) & "'") & "," & _
                    IIf(IsDBNull(rs("Skills")), "null", "'" & rs("Skills") & "'") & "," & _
                    IIf(IsDBNull(rs("Self_Trainings")), "null", "'" & CleanVar(rs("Self_Trainings")) & "'") & "," & _
                    IIf(IsDBNull(rs("BirthPlace")), "null", "'" & rs("BirthPlace") & "'") & "," & _
                    IIf(IsDBNull(rs("Height")), "null", "'" & rs("Height") & "'") & "," & _
                    IIf(IsDBNull(rs("Weight")), "null", "'" & rs("Weight") & "'") & "," & _
                    IIf(IsDBNull(rs("ChildrenNo")), 0, "'" & rs("ChildrenNo") & "'") & "," & _
                    IIf(IsDBNull(rs("ReligionCd")), "null", "'" & rs("ReligionCd") & "'") & "," & _
                    IIf(IsDBNull(rs("DialectCd")), "null", "'" & rs("DialectCd") & "'") & "," & _
                    IIf(IsDBNull(rs("LanguageCd")), "null", "'" & rs("LanguageCd") & "'") & "," & _
                    IIf(IsDBNull(rs("BloodType")), "null", "'" & rs("BloodType") & "'") & "," & _
                    IIf(IsDBNull(rs("CountryCd")), "null", "'" & rs("CountryCd") & "'") & "," & _
                    IIf(IsDBNull(rs("EmergencyContactPerson")), "null", "'" & CleanVar(rs("EmergencyContactPerson")) & "'") & "," & _
                    IIf(IsDBNull(rs("CitizenCd")), "null", "'" & rs("CitizenCd") & "'") & "," & _
                    IIf(IsDBNull(rs("EmergencyContactNo")), "null", "'" & CleanVar(rs("EmergencyContactNo")) & "'") & "," & _
                    IIf(IsDBNull(rs("OtherInfo")), "null", "'" & CleanVar(rs("OtherInfo")) & "'") & "," & _
                    IIf(IsDBNull(rs("Spouse_Lname")), "null", "'" & CleanVar(rs("Spouse_Lname")) & "'") & "," & _
                    IIf(IsDBNull(rs("Spouse_Fname")), "null", "'" & CleanVar(rs("Spouse_Fname")) & "'") & "," & _
                    IIf(IsDBNull(rs("Spouse_Mname")), "null", "'" & CleanVar(rs("Spouse_Mname")) & "'") & "," & _
                    IIf(IsDBNull(rs("Spouse_Occupation")), "null", "'" & CleanVar(rs("Spouse_Occupation")) & "'") & "," & _
                    IIf(IsDBNull(rs("Spouse_Emr")), "null", "'" & CleanVar(rs("Spouse_Emr")) & "'") & "," & _
                    IIf(IsDBNull(rs("Spouse_Bus_Addr")), "null", "'" & CleanVar(rs("Spouse_Bus_Addr")) & "'") & "," & _
                    IIf(IsDBNull(rs("Spouse_Tel")), "null", "'" & CleanVar(rs("Spouse_Tel")) & "'") & "," & _
                    IIf(IsDBNull(rs("Father_Lname")), "null", "'" & CleanVar(rs("Father_Lname")) & "'") & "," & _
                    IIf(IsDBNull(rs("Father_Fname")), "null", "'" & CleanVar(rs("Father_Fname")) & "'") & "," & _
                    IIf(IsDBNull(rs("Father_Mname")), "null", "'" & CleanVar(rs("Father_Mname")) & "'") & "," & _
                    IIf(IsDBNull(rs("Mother_Lname")), "null", "'" & CleanVar(rs("Mother_Lname")) & "'") & "," & _
                    IIf(IsDBNull(rs("Mother_Fname")), "null", "'" & CleanVar(rs("Mother_Fname")) & "'") & "," & _
                    IIf(IsDBNull(rs("Mother_Mname")), "null", "'" & CleanVar(rs("Mother_Mname")) & "'") & "," & _
                    IIf(IsDBNull(rs("PhicNo")), "null", "'" & CleanVar(rs("PhicNo")) & "'") & "," & _
                    IIf(IsDBNull(rs("Spouse_Prov")), "null", "'" & CleanVar(rs("Spouse_Prov")) & "'") & "," & _
                    IIf(IsDBNull(rs("MobileNo")), "null", "'" & CleanVar(rs("MobileNo")) & "'") & "," & _
                    IIf(IsDBNull(rs("Zip")), "null", "'" & CleanVar(rs("Zip")) & "'") & "," & _
                    IIf(IsDBNull(rs("City")), "null", "'" & CleanVar(rs("City")) & "'") & "," & _
                    IIf(IsDBNull(rs("FatherOcc")), "null", "'" & CleanVar(rs("FatherOcc")) & "'") & "," & _
                    IIf(IsDBNull(rs("FatherAddress")), "null", "'" & CleanVar(rs("FatherAddress")) & "'") & "," & _
                    IIf(IsDBNull(rs("FatherContact")), "null", "'" & CleanVar(rs("FatherContact")) & "'") & "," & _
                    IIf(IsDBNull(rs("MotherOcc")), "null", "'" & CleanVar(rs("MotherOcc")) & "'") & "," & _
                    IIf(IsDBNull(rs("MotherAddress")), "null", "'" & CleanVar(rs("MotherAddress")) & "'") & "," & _
                    IIf(IsDBNull(rs("MotherContact")), "null", "'" & CleanVar(rs("MotherContact")) & "'") & "," & _
                    IIf(IsDBNull(rs("fatherDeathCause")), "null", "'" & CleanVar(rs("fatherDeathCause")) & "'") & "," & _
                    IIf(IsDBNull(rs("MotherDeathCause")), "null", "'" & CleanVar(rs("MotherDeathCause")) & "'") & "," & _
                    IIf(IsDBNull(rs("EmergencyRelation")), "null", "'" & CleanVar(rs("EmergencyRelation")) & "'") & "," & _
                    IIf(IsDBNull(rs("EmergencyAddress")), "null", "'" & CleanVar(rs("EmergencyAddress")) & "'") & "," & _
                    IIf(IsDBNull(rs("EmergencyEmail")), "null", "'" & CleanVar(rs("EmergencyEmail")) & "'") & "," & _
                    IIf(IsDBNull(rs("FatherAlive")), 0, rs("FatherAlive")) & "," & _
                    IIf(IsDBNull(rs("MotherAlive")), 0, rs("MotherAlive")) & "," & _
                    IIf(IsDBNull(rs("RegionCd")), "null", "'" & rs("RegionCd") & "'") & "," & _
                    IIf(IsDBNull(rs("ProvCd")), "null", "'" & rs("ProvCd") & "'") & "," & _
                    IIf(IsDBNull(rs("EyeColor")), "null", "'" & CleanVar(rs("EyeColor")) & "'") & "," & _
                    IIf(IsDBNull(rs("Haircolor")), "null", "'" & CleanVar(rs("Haircolor")) & "'") & "," & _
                    IIf(IsDBNull(rs("DistingMark")), "null", "'" & CleanVar(rs("DistingMark")) & "'") & "," & _
                    IIf(IsDBNull(rs("ResCertPlaceIssued")), "null", "'" & CleanVar(rs("ResCertPlaceIssued")) & "'") & "," & _
                    IIf(IsDBNull(rs("RescertDateIssued")), "null", "'" & rs("RescertDateIssued") & "'") & "," & _
                    IIf(IsDBNull(rs("SpouseAddress")), "null", "'" & CleanVar(rs("SpouseAddress")) & "'") & "," & _
                    IIf(IsDBNull(rs("SpouseProvAddress")), "null", "'" & CleanVar(rs("SpouseProvAddress")) & "'") & "," & _
                    IIf(IsDBNull(rs("FatherBday")), "null", "'" & rs("FatherBday") & "'") & "," & _
                    IIf(IsDBNull(rs("MotherBday")), "null", "'" & rs("MotherBday") & "'") & "," & _
                    IIf(IsDBNull(rs("MacOprtd")), "null", "'" & CleanVar(rs("MacOprtd")) & "'") & ")"
                    cmExec.ExecuteNonQuery()
                End If
                rs.Close()
                'hr_emp_scholastic
                cm.CommandText = "select * from hr_emp_scholastic where Emp_Cd='" & _
                                 chkEmp.Items(i).Value & "' order by Emp_Cd,SeqId"
                rs = cm.ExecuteReader
                Do While rs.Read
                    cmExec.CommandText = "insert into hr_emp_tmp_scholastic(Emp_Cd," & _
                                         "Type,From_Date,Course,School,To_Date," & _
                                         "Accomplishments,School_Address,Final_Grade,Year_Grad)values('" & _
                                         rs("Emp_Cd") & "'," & _
                                        IIf(IsDBNull(rs("Type")), "null", "'" & rs("Type") & "'") & "," & _
                                        IIf(IsDBNull(rs("From_Date")), "null", "'" & rs("From_Date") & "'") & "," & _
                                        IIf(IsDBNull(rs("Course")), "null", "'" & CleanVar(rs("Course")) & "'") & "," & _
                                        IIf(IsDBNull(rs("School")), "null", "'" & CleanVar(rs("School")) & "'") & "," & _
                                        IIf(IsDBNull(rs("To_Date")), "null", "'" & CleanVar(rs("To_Date")) & "'") & "," & _
                                        IIf(IsDBNull(rs("Accomplishments")), "null", "'" & CleanVar(rs("Accomplishments")) & "'") & "," & _
                                        IIf(IsDBNull(rs("School_Address")), "null", "'" & CleanVar(rs("School_Address")) & "'") & "," & _
                                        IIf(IsDBNull(rs("Final_Grade")), "null", "'" & CleanVar(rs("Final_Grade")) & "'") & "," & _
                                        IIf(IsDBNull(rs("Year_Grad")), "null", "'" & CleanVar(rs("Year_Grad")) & "'") & ")"
                    cmExec.ExecuteNonQuery()
                Loop
                rs.Close()
                'transmit to hr_emp_tmp_dependent/dependents
                cm.CommandText = "select * from hr_dependents where rel_type='dependents' and Emp_Cd='" & _
                                 chkEmp.Items(i).Value & "' order by SeqId"
                rs = cm.ExecuteReader
                Do While rs.Read
                    cmExec.CommandText = "insert into hr_emp_tmp_dependents(Application_No,Dependent_Name," & _
                                         "Relation,Birth_Date,PlaceofBirth,Address,Sex,rel_type)values('" & rs("Emp_Cd") & "'," & _
                                         IIf(IsDBNull(rs("DependentName")), "null", "'" & CleanVar(rs("DependentName")) & "'") & "," & _
                                         IIf(IsDBNull(rs("Relationship")), "null", "'" & CleanVar(rs("Relationship")) & "'") & "," & _
                                         IIf(IsDBNull(rs("Bday")), "null", "'" & rs("Bday") & "'") & "," & _
                                         IIf(IsDBNull(rs("BPlace")), "null", "'" & CleanVar(rs("BPlace")) & "'") & "," & _
                                         IIf(IsDBNull(rs("Home_Address")), "null", "'" & CleanVar(rs("Home_Address")) & "'") & "," & _
                                         IIf(IsDBNull(rs("Sex")), "null", "'" & rs("Sex") & "'") & "," & _
                                         "'dependents')"
                    cmExec.ExecuteNonQuery()
                Loop
                rs.Close()
                'transmit to hr_emp_tmp_sibling/sibling
                cm.CommandText = "select * from hr_dependents where rel_type='sibling' and Emp_Cd='" & _
                                 chkEmp.Items(i).Value & "' order by SeqId"
                rs = cm.ExecuteReader
                Do While rs.Read
                    cmExec.CommandText = "insert into hr_emp_tmp_sibling(ApplicantNo,Fname," & _
                                         "Relationship,Compschool,Position,ContactNum,birthday,sex)values('" & rs("Emp_Cd") & "'," & _
                                         IIf(IsDBNull(rs("DependentName")), "null", "'" & CleanVar(rs("DependentName")) & "'") & "," & _
                                         IIf(IsDBNull(rs("Relationship")), "null", "'" & CleanVar(rs("Relationship")) & "'") & "," & _
                                         IIf(IsDBNull(rs("School")), "null", "'" & CleanVar(rs("School")) & "'") & "," & _
                                         IIf(IsDBNull(rs("Position")), "null", "'" & CleanVar(rs("Position")) & "'") & "," & _
                                         IIf(IsDBNull(rs("Tel")), "null", "'" & CleanVar(rs("Tel")) & "'") & "," & _
                                         IIf(IsDBNull(rs("Bday")), "null", "'" & rs("Bday") & "'") & "," & _
                                         IIf(IsDBNull(rs("Sex")), "null", "'" & rs("Sex") & "'") & ")"
                    cmExec.ExecuteNonQuery()
                Loop
                rs.Close()
                'transmit to hr_emp_tmp_dependents/relatives
                cm.CommandText = "select * from hr_dependents where rel_type='relatives' and Emp_Cd='" & _
                                 chkEmp.Items(i).Value & "' order by SeqId"
                rs = cm.ExecuteReader
                Do While rs.Read
                    cmExec.CommandText = "insert into hr_emp_tmp_dependents(Application_No,Dependent_Name," & _
                                         "Relation,PlaceofBirth,School,rel_type,Position,contacts,Sex)values('" & rs("Emp_Cd") & "'," & _
                                         IIf(IsDBNull(rs("DependentName")), "null", "'" & CleanVar(rs("DependentName")) & "'") & "," & _
                                         IIf(IsDBNull(rs("Relationship")), "null", "'" & CleanVar(rs("Relationship")) & "'") & "," & _
                                         IIf(IsDBNull(rs("BPlace")), "null", "'" & CleanVar(rs("BPlace")) & "'") & "," & _
                                         IIf(IsDBNull(rs("School")), "null", "'" & CleanVar(rs("School")) & "'") & "," & _
                                         "'relatives'," & IIf(IsDBNull(rs("Position")), "null", "'" & CleanVar(rs("Position")) & "'") & "," & _
                                         IIf(IsDBNull(rs("Tel")), "null", "'" & CleanVar(rs("Tel")) & "'") & "," & _
                                         IIf(IsDBNull(rs("Sex")), "null", "'" & rs("Sex") & "'") & ")"
                    cmExec.ExecuteNonQuery()
                Loop
                rs.Close()
                'transmit to hr_emp_tmp_training
                cm.CommandText = "select * from hr_emp_training where Emp_Id='" & chkEmp.Items(i).Value & "' order by From_Date desc"
                rs = cm.ExecuteReader
                Do While rs.Read
                    cmExec.CommandText = "insert into hr_emp_tmp_training(Emp_Id,From_Date,Fee,Held,Remarks," & _
                                         "Speaker,To_Date,Training_Name,Trainor,No_Of_Hours)values('" & _
                                         rs("Emp_Id") & "'," & _
                                         IIf(IsDBNull(rs("From_Date")), "null", "'" & rs("From_Date") & "'") & "," & _
                                         IIf(IsDBNull(rs("Fee")), "null", CleanVar(rs("Fee"))) & "," & _
                                         IIf(IsDBNull(rs("Held")), "null", "'" & CleanVar(rs("Held")) & "'") & "," & _
                                         IIf(IsDBNull(rs("Remarks")), "null", "'" & CleanVar(rs("Remarks")) & "'") & "," & _
                                         IIf(IsDBNull(rs("Speaker")), "null", "'" & CleanVar(rs("Speaker")) & "'") & "," & _
                                         IIf(IsDBNull(rs("To_Date")), "null", "'" & CleanVar(rs("To_Date")) & "'") & "," & _
                                         IIf(IsDBNull(rs("Training_Name")), "null", "'" & CleanVar(rs("Training_Name")) & "'") & "," & _
                                         IIf(IsDBNull(rs("Trainor")), "null", "'" & CleanVar(rs("Trainor")) & "'") & "," & _
                                         IIf(IsDBNull(rs("No_Of_Hours")), "null", "'" & CleanVar(rs("No_Of_Hours")) & "'") & ")"
                    cmExec.ExecuteNonQuery()
                Loop
                rs.Close()
                'transmit to hr_emp_tmp_license_ref
                cm.CommandText = "select * from hr_emp_license_ref where Emp_Cd='" & chkEmp.Items(i).Value & "' order by Date_Issued"
                rs = cm.ExecuteReader
                Do While rs.Read
                    cmExec.CommandText = "insert into hr_emp_tmp_license_ref(License_No,Emp_Cd,Exp_Date," & _
                                         "Date_Issued,Remarks,Place_Sem,Date_Seminar,Date_Exam,Place_Exam," & _
                                         "LicenseName,Score)values(" & _
                                         IIf(IsDBNull(rs("License_No")), "null", "'" & CleanVar(rs("License_No")) & "'") & "," & _
                                         "'" & rs("Emp_Cd") & "'," & _
                                         IIf(IsDBNull(rs("Exp_Date")), "null", "'" & CleanVar(rs("Exp_Date")) & "'") & "," & _
                                         IIf(IsDBNull(rs("Date_Issued")), "null", "'" & CleanVar(rs("Date_Issued")) & "'") & "," & _
                                         IIf(IsDBNull(rs("Remarks")), "null", "'" & CleanVar(rs("Remarks")) & "'") & "," & _
                                         IIf(IsDBNull(rs("Place_Sem")), "null", "'" & CleanVar(rs("Place_Sem")) & "'") & "," & _
                                         IIf(IsDBNull(rs("Date_Seminar")), "null", "'" & CleanVar(rs("Date_Seminar")) & "'") & "," & _
                                         IIf(IsDBNull(rs("Date_Exam")), "null", "'" & CleanVar(rs("Date_Exam")) & "'") & "," & _
                                         IIf(IsDBNull(rs("Place_Exam")), "null", "'" & CleanVar(rs("Place_Exam")) & "'") & "," & _
                                         IIf(IsDBNull(rs("LicenseName")), "null", "'" & CleanVar(rs("LicenseName")) & "'") & "," & _
                                         IIf(IsDBNull(rs("Score")), "null", "'" & CleanVar(rs("Score")) & "'") & ")"
                    cmExec.ExecuteNonQuery()
                Loop
                rs.Close()
                'transmit to hr_emp_tmp_employment_hist
                cm.CommandText = "select * from hr_emp_employment_hist where Emp_Id='" & _
                                 chkEmp.Items(i).Value & "' order by Emp_Id,SeqId"
                rs = cm.ExecuteReader
                Do While rs.Read
                    cmExec.CommandText = "insert into hr_emp_tmp_employment_hist(Emp_Id,Employer,Annual_Salary," & _
                                         "From_Date,To_Date,Accomplishments," & _
                                         "[Function],Address,Supervisor,EmployerNo,Position,ReasonforLeaving)values('" & _
                                         rs("Emp_Id") & "'," & _
                                         IIf(IsDBNull(rs("Employer")), "null", "'" & CleanVar(rs("Employer")) & "'") & "," & _
                                         IIf(IsDBNull(rs("Annual_Salary")), "null", "'" & CleanVar(rs("Annual_Salary")) & "'") & "," & _
                                         IIf(IsDBNull(rs("From_Date")), "null", "'" & CleanVar(rs("From_Date")) & "'") & "," & _
                                         IIf(IsDBNull(rs("To_Date")), "null", "'" & CleanVar(rs("To_Date")) & "'") & "," & _
                                         IIf(IsDBNull(rs("Accomplishments")), "null", "'" & CleanVar(rs("Accomplishments")) & "'") & "," & _
                                         IIf(IsDBNull(rs("Function")), "null", "'" & CleanVar(rs("Function")) & "'") & "," & _
                                         IIf(IsDBNull(rs("Address")), "null", "'" & CleanVar(rs("Address")) & "'") & "," & _
                                         IIf(IsDBNull(rs("Supervisor")), "null", "'" & CleanVar(rs("Supervisor")) & "'") & "," & _
                                         IIf(IsDBNull(rs("EmployerNo")), "null", "'" & CleanVar(rs("EmployerNo")) & "'") & "," & _
                                         IIf(IsDBNull(rs("Position")), "null", "'" & CleanVar(rs("Position")) & "'") & "," & _
                                         IIf(IsDBNull(rs("ReasonforLeaving")), "null", "'" & CleanVar(rs("ReasonforLeaving")) & "'") & ")"

                    cmExec.ExecuteNonQuery()
                Loop
                rs.Close()

            End If
        Next
        c.Close()
        cExec.Close()
        c.Dispose()
        cExec.Dispose()
        cm.Dispose()
        cmExec.Dispose()

        vscript = "alert('Activation Completed.');"
        Session("letter") = txtSearch.Text
        DataRefresh(txtSearch.Text)
    End Sub

    Protected Sub cmdSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSearch.Click
        Session("letter") = txtSearch.Text
        DataRefresh(txtSearch.Text)
    End Sub
    Private Function CleanVar(ByVal pstr As Object) As String
        If IsDBNull(pstr) Then
            Return ""
        Else
            Return CType(pstr, String).Replace("'", "''")
        End If
    End Function
End Class
