Imports denaro.fis
Partial Class empstep5
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            vScript = "alert('Your login session has expired. Please login again.'); window.close();"
            Exit Sub
        End If

        If Not IsPostBack Then
            cmdPrev.Enabled = CanRun(Session("caption"), "41.2") Or CanRun(Session("caption"), "41.1") Or _
                   CanRun(Session("caption"), "41.3") Or CanRun(Session("caption"), "41.4")
            If Not CanRun(Session("caption"), "41.5") Then
                vScript = "window.close();"
                Exit Sub
            End If

            Session.Remove("oldval")
            Session.Remove("newval")

            Dim c As New SqlClient.SqlConnection(connStr)
            Dim cm As New SqlClient.SqlCommand
            Dim rs As SqlClient.SqlDataReader

            lblCaption.Text = "Employee Master Information (6 of 6)"

            Try
                c.Open()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                c.Dispose()
                cm.Dispose()
                Exit Sub
            End Try

            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:  VIC GATCHALIAN                                                ''
            '' DATE MODIFIED: 3/1/2012                                                     ''
            '' PURPOSE:  TO EXPOSE THE UNION MEMBER REFERENCE                              ''
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            BuildCombo("select UnionCd,Descr from py_union_ref order by Descr", cmbUnionCd, c)
            cmbUnionCd.Items.Add(" ")
            cmbUnionCd.SelectedValue = " "
            '''''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''''''''''''

            cm.Connection = c
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:  VIC GATCHALIAN                                                ''
            '' DATE MODIFIED: 3/1/2012                                                     ''
            '' PURPOSE: TO ADD THE UNIONCD,UNIONBASIS,UNIONVALUE FIELD RETRIEVAL           ''
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:  VIC GATCHALIAN                                                ''
            '' DATE MODIFIED: 5/7/2012                                                     ''
            '' PURPOSE: TO ADD THE SENIOR ALLOWANCE ELIGIBILITY FIELD RETRIEVAL            ''
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '''''''''''''''''''''''' OLDE CODE ''''''''''''''''''''''''''''''''''''''''''''''
            'cm.CommandText = "select Allow_Withtax,Allow_Sss,Allow_Pagibig,Allow_Medicare," & _
            '    "Allow_Life,Allow_Req_Hrs,Allow_Reg_Timein,Emp_Lname,Emp_Fname,Emp_Mname," & _
            '    "BapEnrolled,Allow_UnionDues,SCMember,MaxFlexHrs,TaxFreq,SSSFreq,PagIBIGFreq,PHICFreq, " & _
            '    "UnionCd,UnionBasis,UnionValue from py_emp_master where Emp_Cd='" & Session("empid") & "'"
            '''''''''''''''''''''''' END OLD CODE '''''''''''''''''''''''''''''''''''''''''''
            cm.CommandText = "select Allow_Withtax,Allow_Sss,Allow_Pagibig,Allow_Medicare," & _
                "Allow_Life,Allow_Req_Hrs,Allow_Reg_Timein,Emp_Lname,Emp_Fname,Emp_Mname," & _
                "BapEnrolled,Allow_UnionDues,SCMember,MaxFlexHrs,TaxFreq,SSSFreq,PagIBIGFreq,PHICFreq, " & _
                "UnionCd,UnionBasis,UnionValue,WithSeniorAllow,Allow_EarlyOT,AutoApprovedOT,OTMultipleMins " & _
                "from py_emp_master where Emp_Cd='" & Session("empid") & "'"
            '''''''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''''''''''''
            '''''''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''''''''''''

            Try
                rs = cm.ExecuteReader
                If rs.Read Then
                    lblName.Text = rs("Emp_Lname") & ", " & rs("Emp_Fname") & " " & rs("Emp_Mname")
                    chkTax.Checked = IIf(IsDBNull(rs("Allow_Withtax")), 0, rs("Allow_Withtax"))
                    chkSSS.Checked = IIf(IsDBNull(rs("Allow_Sss")), 0, rs("Allow_Sss"))
                    chkPagibig.Checked = IIf(IsDBNull(rs("Allow_Pagibig")), 0, rs("Allow_Pagibig"))
                    chkPhilhealth.Checked = IIf(IsDBNull(rs("Allow_Medicare")), 0, rs("Allow_Medicare"))
                    chkGsis.Checked = IIf(IsDBNull(rs("Allow_Life")), 0, rs("Allow_Life"))
                    chkReqHrs.Checked = IIf(IsDBNull(rs("Allow_Req_Hrs")), 0, rs("Allow_Req_Hrs"))
                    chkReqTimeIn.Checked = IIf(IsDBNull(rs("Allow_Reg_Timein")), False, rs("Allow_Reg_Timein") = 0)
                    chkEarlyOT.Checked = IIf(IsDBNull(rs("Allow_EarlyOT")), False, rs("Allow_EarlyOt") = 1)
                    txtMaxFlexHrs.Visible = chkReqTimeIn.Checked
                    txtMaxFlexHrs.Text = rs("MaxFlexHrs")
                    chkBAPEnrolled.Checked = rs("BapEnrolled") = 1
                    chkUnion.Checked = rs("Allow_UnionDues") = 1
                    chkSC.Checked = rs("SCMember") = 1
                    chkSenior.Checked = rs("WithSeniorAllow") = 1
                    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                    '' MODIFIED BY:  VIC GATCHALIAN                                       ''
                    '' DATE MODIFIED: 3/1/2012                                            ''
                    '' PURPOSE: TO RETRIEVE AND DISPLAY THE UNION INFORMATINO             ''
                    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                    If Not IsDBNull(rs("UnionCd")) Then
                        cmbUnionCd.SelectedValue = rs("UnionCd")
                    End If
                    If Not IsDBNull(rs("UnionValue")) Then
                        txtUnionValue.Text = rs("UnionValue")
                    End If
                    If Not IsDBNull(rs("UnionBasis")) Then
                        rdoUnionBasis.SelectedValue = rs("UnionBasis")
                    End If
                    ''''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''''''

                    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                    '' MODIFIED BY:  VIC GATCHALIAN                                       ''
                    '' DATE MODIFIED: 3/24/2013                                           ''
                    '' PURPOSE: TO ADD PRE-APPROVED OT                                    ''
                    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                    txtPreApprovedOT.Text = rs("AutoApprovedOT")
                    txtOTMultipleMins.Text = rs("OTMultipleMins")
                    '''''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''''

                    cmbTaxFreq.SelectedValue = rs("TaxFreq")
                    cmbSSSFreq.SelectedValue = rs("SSSFreq")
                    cmbPagIBIGFreq.SelectedValue = rs("PagIBIGFreq")
                    cmbPHICFreq.SelectedValue = rs("PHICFreq")

                    Session("oldval") = "Allow Withholding Tax Deduction?=" & chkTax.Checked & _
                        "|Allow SSS Deduction?=" & chkSSS.Checked & _
                        "|Allow PAGIBIG Deduction?=" & chkPagibig.Checked & _
                        "|Allow PHIC Deduction?=" & chkPhilhealth.Checked & _
                        "|Allow GSIS Deduction?=" & chkGsis.Checked & _
                        "|Required to Render service hours?=" & chkReqHrs.Checked & _
                        "|Required to render regular timein=" & chkReqTimeIn.Checked & _
                        "|Allow Early OT=" & chkEarlyOT.Checked & _
                        "|Max. Allowable Flexi Hours=" & txtMaxFlexHrs.Text & _
                        "|Bap Enrolled=" & chkBAPEnrolled.Checked & _
                        "|Union Member?=" & chkUnion.Checked & _
                        "|Union Code=" & cmbUnionCd.SelectedValue & _
                        "|Union Value=" & txtUnionValue.Text & _
                        "|Union Basis=" & rdoUnionBasis.SelectedItem.Text & _
                        "|SC Eligible?=" & chkSC.Checked & _
                        "|With Senior Allowance?=" & chkSenior.Checked & _
                        "|Pre-Approved OT=" & txtPreApprovedOT.Text & _
                        "|Multiple Mins of OT Filing=" & txtOTMultipleMins.Text & _
                        "|Tax Frequency=" & IIf(rs("TaxFreq") = -1, "[system default]", IIf(rs("TaxFreq") = 0, "every payroll", IIf(rs("TaxFreq") = 1, "every 1st cut off", "every 2nd cut off"))) & _
                        "|SSS Frequency=" & IIf(rs("SSSFreq") = -1, "[system default]", IIf(rs("SSSFreq") = 0, "every payroll", IIf(rs("SSSFreq") = 1, "every 1st cut off", "every 2nd cut off"))) & _
                        "|PagIBIG Frequency=" & IIf(rs("PagIBIGFreq") = -1, "[system default]", IIf(rs("PagIBIGFreq") = 0, "every payroll", IIf(rs("PagIBIGFreq") = 1, "every 1st cut off", "every 2nd cut off"))) & _
                        "|PHIC Frequency=" & IIf(rs("PHICFreq") = -1, "[system default]", IIf(rs("PHICFreq") = 0, "every payroll", IIf(rs("PHICFreq") = 1, "every 1st cut off", "every 2nd cut off")))
                End If
                rs.Close()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to retrieve record. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            Finally
                c.Close()
                c.Dispose()
                cm.Dispose()
            End Try
        End If
    End Sub


    Protected Sub cmdPrev_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdPrev.Click
        Session.Remove("oldval")
        Session.Remove("newval")

        If CanRun(Session("caption"), "41.4") Then
            Server.Transfer("empstep4.aspx")
        ElseIf CanRun(Session("caption"), "41.3") Then
            Server.Transfer("empstep3.aspx")
        ElseIf CanRun(Session("caption"), "41.2") Then
            Server.Transfer("empstep2_1.aspx")
        Else
            Server.Transfer("empstep2.aspx")
        End If
    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        Dim vSQL As String = "update py_emp_master set Allow_Withtax=" & IIf(chkTax.Checked = True, 1, 0) & _
                                ",Allow_Sss=" & IIf(chkSSS.Checked = True, 1, 0) & _
                                ",Allow_Pagibig=" & IIf(chkPagibig.Checked = True, 1, 0) & _
                                ",Allow_Medicare=" & IIf(chkPhilhealth.Checked = True, 1, 0) & _
                                ",Allow_Life=" & IIf(chkGsis.Checked = True, 1, 0) & _
                                ",Allow_Req_Hrs=" & IIf(chkReqHrs.Checked = True, 1, 0) & _
                                ",Modified_Date='" & Format(Now, "yyyy/MM/dd HH:mm:ss") & _
                                "',Modified_By='" & Session("uid") & _
                                "',Allow_Reg_Timein=" & IIf(chkReqTimeIn.Checked = True, 0, 1) & _
                                ",Allow_EarlyOT=" & IIf(chkEarlyOT.Checked, 1, 0) & _
                                ",MaxFlexHrs=" & Val(txtMaxFlexHrs.Text) & _
                                ",BapEnrolled=" & IIf(chkBAPEnrolled.Checked = True, 1, 0) & _
                                ",Allow_UnionDues=" & IIf(chkUnion.Checked, 1, 0) & _
                                ",SCMember=" & IIf(chkSC.Checked, 1, 0) & _
                                ",WithSeniorAllow=" & IIf(chkSenior.Checked, 1, 0) & _
                                ",TaxFreq=" & cmbTaxFreq.SelectedValue & _
                                ",SSSFreq=" & cmbSSSFreq.SelectedValue & _
                                ",PagIBIGFreq=" & cmbPagIBIGFreq.SelectedValue & _
                                ",PHICFreq=" & cmbPHICFreq.SelectedValue & _
                                ",AutoApprovedOT=" & Val(txtPreApprovedOT.Text) & _
                                ",OTMultipleMins=" & Val(txtOTMultipleMins.Text) & _
                                " where Emp_Cd='" & Session("empid") & "'"

        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand

        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                           ''
        '' DATE MODIFIED: 3/1/2012                                ''
        '' PURPOSE: TO CHECK IF UNION MEMBER WAS TICKED           ''
        ''          AND NO UNION CODE WAS SET, RAISE AN ERROR     ''
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        If chkUnion.Checked And cmbUnionCd.SelectedValue = " " Then
            vScript = "alert('You must first select a Union Code.');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End If

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        cm.Connection = c
        cm.CommandText = vSQL
        Try

            cm.ExecuteNonQuery()
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:  VIC GATCHALIAN                           ''
            '' DATE MODIFIED: 3/1/2012                                ''
            '' PURPOSE: TO CHECK IF UNION CODE WAS SELECTED,          ''
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            If cmbUnionCd.SelectedValue <> " " Then
                If Val(txtUnionValue.Text) > 0 Then
                    cm.CommandText = "update py_emp_master set Allow_UnionDues=0," & _
                        "UnionCd='" & cmbUnionCd.SelectedValue & _
                        "',UnionValue=" & Val(txtUnionValue.Text) & _
                        ",UnionBasis=" & rdoUnionBasis.SelectedValue & _
                        " where Emp_Cd='" & Session("empid") & "'"
                Else
                    cm.CommandText = "update py_emp_master set Allow_UnionDues=1," & _
                        "UnionCd='" & cmbUnionCd.SelectedValue & _
                        "',UnionValue=0,UnionBasis=0 " & _
                        " where Emp_Cd='" & Session("empid") & "'"
                End If

                cm.ExecuteNonQuery()
            Else
                cm.CommandText = "update py_emp_master set Allow_UnionDues=0," & _
                    "UnionCd=null,UnionValue=0,UnionBasis=0 where Emp_Cd='" & _
                    Session("empid") & "'"
                cm.ExecuteNonQuery()
            End If
            ''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''

            Session("newval") = "Allow Withholding Tax Deduction?=" & chkTax.Checked & _
                "|Allow SSS Deduction?=" & chkSSS.Checked & _
                "|Allow PAGIBIG Deduction?=" & chkPagibig.Checked & _
                "|Allow PHIC Deduction?=" & chkPhilhealth.Checked & _
                "|Allow GSIS Deduction?=" & chkGsis.Checked & _
                "|Required to Render service hours?=" & chkReqHrs.Checked & _
                "|Required to render regular timein=" & chkReqTimeIn.Checked & _
                "|Allow Early OT=" & chkEarlyOT.Checked & _
                "|Max. Allowable Flexi Hours=" & Val(txtMaxFlexHrs.Text) & _
                "|BapEnrolled?=" & chkBAPEnrolled.Checked & _
                "|Union Member?=" & chkUnion.Checked & _
                "|Union Code=" & cmbUnionCd.SelectedValue & _
                "|Union Value=" & txtUnionValue.Text & _
                "|Union Basis=" & rdoUnionBasis.SelectedItem.Text & _
                "|SC Eligible?=" & chkSC.Checked & _
                "|Pre-Approved OT=" & txtPreApprovedOT.Text & _
                "|Multiple Mins of OT Filing=" & txtOTMultipleMins.Text & _
                "|With Senior Allowance?=" & chkSenior.Checked & _
                "|Tax Frequency=" & IIf(cmbTaxFreq.SelectedValue = -1, "[system default]", IIf(cmbTaxFreq.SelectedValue = 0, "every payroll", IIf(cmbTaxFreq.SelectedValue = 1, "every 1st cut off", "every 2nd cut off"))) & _
                "|SSS Frequency=" & IIf(cmbSSSFreq.SelectedValue = -1, "[system default]", IIf(cmbSSSFreq.SelectedValue = 0, "every payroll", IIf(cmbSSSFreq.SelectedValue = 1, "every 1st cut off", "every 2nd cut off"))) & _
                "|PagIBIG Frequency=" & IIf(cmbPagIBIGFreq.SelectedValue = -1, "[system default]", IIf(cmbPagIBIGFreq.SelectedValue = 0, "every payroll", IIf(cmbPagIBIGFreq.SelectedValue = 1, "every 1st cut off", "every 2nd cut off"))) & _
                "|PHIC Frequency=" & IIf(cmbPHICFreq.SelectedValue = -1, "[system default]", IIf(cmbPHICFreq.SelectedValue = 0, "every payroll", IIf(cmbPHICFreq.SelectedValue = 1, "every 1st cut off", "every 2nd cut off")))

            EventLog(Session("uid"), Request.ServerVariables("REMOTE_ADDR"), "EDIT", Session("oldval"), Session("newval"), _
                "Employee ID: " & Session("empid") & " was added/edited", "201 Profile", c)
            Session.Remove("oldval")
            Session.Remove("newval")
            If Session("fromapplicant") = "1" Then
                PrintEMR(c)
            Else
                vScript = "window.close();"
            End If
            Session.Remove("fromapplicant")
            Session.Remove("applicantno")
            Session.Remove("reqno")
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to save record. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            cm.Dispose()
            c.Dispose()
        End Try
    End Sub
    Private Sub PrintEMR(ByRef c As SqlClient.SqlConnection)
        Dim cm As New SqlClient.SqlCommand

        Dim dr As SqlClient.SqlDataReader
        Dim vPrn As New VSPrinter8Lib.VSPrinter
        Dim vPDF As New VSPDF8Lib.VSPDF8
        Dim vName As String = ""
        Dim vDate As String = ""
        Dim vPrepared As String = ""
        Dim vRecommend As String = ""
        Dim vApproved As String = ""
        Dim vDatePrepared As String = ""
        Dim vDateRecommend As String = ""
        Dim vDateApproved As String = ""
        Dim vNature As String = "New"
        Dim vRemarks As String = ""
        Dim vSSS As String = ""
        Dim vTIN As String = ""
        Dim vStart As String = ""
        Dim vBDate As String = ""
        Dim vRC(2) As String
        Dim vOfc(2) As String
        Dim vDiv(2) As String
        Dim vDept(2) As String
        Dim vSection(2) As String
        Dim vUnit(2) As String
        Dim vPosition(2) As String
        Dim vGrade(2) As String
        Dim vTax(2) As String
        Dim vType(2) As String
        Dim vStatus(2) As String
        Dim vSalary(2) As Decimal
        Dim vACA(2) As Decimal
        Dim vRATA(2) As Decimal
        Dim vPERA(2) As Decimal
        Dim vMeal(2) As Decimal
        Dim vTotal(2) As Decimal
        Dim vFormat As String = ""
        Dim vData As String = ""
        Dim iLoop As Integer

        For iLoop = 0 To 1
            vRC(iLoop) = ""
            vOfc(iLoop) = ""
            vDiv(iLoop) = ""
            vDept(iLoop) = ""
            vSection(iLoop) = ""
            vUnit(iLoop) = ""
            vPosition(iLoop) = ""
            vTax(iLoop) = ""
            vType(iLoop) = ""
            vStatus(iLoop) = ""
            vACA(iLoop) = 0
            vRATA(iLoop) = 0
            vPERA(iLoop) = 0
            vMeal(iLoop) = 0
        Next iLoop
        'c.ConnectionString = connStr
        'c.Open()
        cm.Connection = c
        cm.CommandText = "select * from py_emp_master where Emp_Cd='" & Session("empid") & "'"
        dr = cm.ExecuteReader
        If dr.Read Then
            vName = dr("Emp_Cd") & "=>" & dr("Emp_Lname") & ", " & dr("Emp_Fname") & " " & dr("Emp_Mname")
            vTIN = IIf(IsDBNull(dr("Tin")), "", dr("Tin"))
            vSSS = IIf(IsDBNull(dr("Sss_No")), "", dr("Sss_No"))
            vStart = dr("Start_Date").ToString
            vBDate = IIf(IsDBNull(dr("Bday")), "", dr("Bday").ToString)
            vRC(0) = GetRef("select descr from rc where Rc_Cd='" & dr("Rc_Cd") & "'", dr("Rc_Cd"), c)
            vOfc(0) = GetRef("select AgencyName from agency where AgencyCd='" & dr("Agency_Cd") & "'", dr("Agency_Cd"), c)
            vDiv(0) = GetRef("select Descr from hr_div_ref where Div_Cd='" & dr("DivCd") & "'", dr("DivCd"), c)
            vDept(0) = GetRef("select Descr from hr_dept_ref where Dept_Cd='" & dr("DeptCd") & "'", dr("DeptCd"), c)
            vSection(0) = GetRef("select Descr from hr_section_ref where Section_Cd='" & dr("SectionCd") & "'", dr("SectionCd"), c)
            vUnit(0) = GetRef("select Descr from hr_unit_ref where Unit_Cd='" & dr("UnitCd") & "'", dr("UnitCd"), c)
            vPosition(0) = GetRef("select Position from py_position_ref where Pos_Cd='" & dr("Pos_Cd") & "'", dr("Pos_Cd"), c)
            vTax(0) = GetRef("select Descr from py_tax_ref where Tax_cd='" & dr("Tax_Cd") & "'", dr("Tax_Cd"), c)
            vType(0) = GetRef("select Descr from hr_employment_type where EmploymentType='" & dr("EmploymentType") & "'", dr("EmploymentType"), c)
            vStatus(0) = GetRef("select Descr from py_employee_stat where Status_Code='" & dr("Emp_Status") & "'", dr("Emp_Status"), c)
            vGrade(0) = GetRef("select Descr from py_grade where Grade_Cd='" & dr("Grade_Cd") & "'", dr("Grade_Cd"), c)
            vSalary(0) = dr("Rate_Month")
            vACA(0) = dr("Aca")
            vRATA(0) = dr("Rata")
            vPERA(0) = dr("Pera")
            vMeal(0) = dr("MealAllow")
        End If
        dr.Close()
        cm.CommandText = "select top 1 * from hr_emp_career_movement where Emp_Cd='" & _
            Session("empid") & "' order by From_Date"
        dr = cm.ExecuteReader
        If dr.Read Then 'with records
            vDate = Format(dr("From_Date"), "MM/dd/yyyy")
            vRC(1) = GetRef("select descr from rc where Rc_Cd='" & dr("Rc_Cd") & "'", dr("Rc_Cd"), c)
            vOfc(1) = GetRef("select AgencyName from agency where AgencyCd='" & dr("Office_Cd") & "'", dr("Office_Cd"), c)
            vDiv(1) = GetRef("select Descr from hr_div_ref where Div_Cd='" & dr("Div_Cd") & "'", dr("Div_Cd"), c)
            vDept(1) = GetRef("select Descr from hr_dept_ref where Dept_Cd='" & dr("Dept_Cd") & "'", dr("Dept_Cd"), c)
            vSection(1) = GetRef("select Descr from hr_section_ref where Section_Cd='" & dr("Section_Cd") & "'", dr("Section_Cd"), c)
            vUnit(1) = GetRef("select Descr from hr_unit_ref where Unit_Cd='" & dr("Unit_Cd") & "'", dr("Unit_Cd"), c)
            vPosition(1) = GetRef("select Position from py_position_ref where Pos_Cd='" & dr("Position_Cd") & "'", dr("Position_Cd"), c)
            vTax(1) = GetRef("select Descr from py_tax_ref where Tax_cd='" & dr("TaxCd") & "'", dr("TaxCd"), c)
            vType(1) = GetRef("select Descr from hr_employment_type where EmploymentType='" & dr("EmploymentType") & "'", dr("EmploymentType"), c)
            vStatus(1) = GetRef("select Descr from py_employee_stat where Status_Code='" & dr("Emp_Status") & "'", dr("Emp_Status"), c)
            vGrade(1) = GetRef("select Descr from py_grade where Grade_Cd='" & _
                IIf(IsDBNull(dr("GradeCd")), "", dr("GradeCd")) & "'", _
                IIf(IsDBNull(dr("GradeCd")), "", dr("GradeCd")))
            vSalary(1) = dr("Salary_Amt")
            vACA(1) = dr("Aca")
            vRATA(1) = dr("Rata")
            vPERA(1) = dr("Pera")
            vMeal(1) = dr("MealAllow")
            vNature = IIf(IsDBNull(dr("Nature")), "", dr("Nature"))
            vRemarks = IIf(IsDBNull(dr("Remarks")), "", dr("Remarks"))
            vPrepared = dr("PreparedBy")
            vRecommend = dr("RecommendedBy")
            vApproved = dr("ApprovedBy")
            vDatePrepared = Format(dr("DatePrepared"), "MM/dd/yyyy")
            vDateRecommend = Format(dr("DateRecommended"), "MM/dd/yyyy")
            vDateApproved = Format(dr("DateApproved"), "MM/dd/yyyy")
        End If
        dr.Close()
        vTotal(0) = vSalary(0) + vACA(0) + vRATA(0) + vPERA(0) + vMeal(0)
        vTotal(1) = vSalary(1) + vACA(1) + vRATA(1) + vPERA(1) + vMeal(1)
        cm.CommandText = "select Emp_Lname,Emp_Fname from py_emp_master where Emp_Cd='" & _
            vPrepared & "'"
        dr = cm.ExecuteReader
        If dr.Read Then
            vPrepared = dr("Emp_Lname") & ", " & dr("Emp_Fname")
        End If
        dr.Close()
        cm.CommandText = "select Emp_Lname,Emp_Fname from py_emp_master where Emp_Cd='" & _
            vRecommend & "'"
        dr = cm.ExecuteReader
        If dr.Read Then
            vRecommend = dr("Emp_Lname") & ", " & dr("Emp_Fname")
        End If
        dr.Close()
        cm.CommandText = "select Emp_Lname,Emp_Fname from py_emp_master where Emp_Cd='" & _
            vApproved & "'"
        dr = cm.ExecuteReader
        If dr.Read Then
            vApproved = dr("Emp_Lname") & ", " & dr("Emp_Fname")
        End If
        dr.Close()
        vPrn.Action = VSPrinter8Lib.ActionSettings.paStartDoc
        vPrn.FontBold = True
        vPrn.FontName = "Arial"
        vPrn.FontSize = 14
        vPrn.Header = "||" & vDate
        vPrn.HdrFontSize = 8
        vPrn.TextAlign = VSPrinter8Lib.TextAlignSettings.taCenterBottom
        vPrn.Paragraph = "EMPLOYEE MOVEMENT REPORT"
        vPrn.TextAlign = VSPrinter8Lib.TextAlignSettings.taJustBottom
        vPrn.FontSize = 10
        vPrn.FontBold = False
        vPrn.Paragraph = "NAME: " & vName
        vPrn.Paragraph = "NATURE OF MOVEMENT: " & vNature
        vPrn.Paragraph = "DATE HIRED: " & vStart
        vPrn.Paragraph = "DATE OF BIRTH: " & IIf(vBDate <> "", Format(CDate(vBDate), "yyyy/MM/dd"), vBDate)
        vPrn.Paragraph = "SSS: " & vSSS
        vPrn.Paragraph = "TIN: " & vTIN
        vFormat = "<4000|^3000|^3000;"
        vData = "|FROM|TO;"
        vPrn.FontBold = True
        vPrn.TableBorder = VSPrinter8Lib.TableBorderSettings.tbAll
        vPrn.Table = vFormat & vData
        vData = "COST CENTER|" & vRC(1) & "|" & vRC(0) & ";" & _
                "OFFICE|" & vOfc(1) & "|" & vOfc(0) & ";" & _
                "DIVISION|" & vDiv(1) & "|" & vDiv(0) & ";" & _
                "DEPARTMENT|" & vDept(1) & "|" & vDept(0) & ";" & _
                "SECTION|" & vSection(1) & "|" & vSection(0) & ";" & _
                "UNIT|" & vUnit(1) & "|" & vUnit(0) & ";" & _
                "EMPLOYMENT STATUS|" & vStatus(1) & "|" & vStatus(0) & ";" & _
                "POSITION|" & vPosition(1) & "|" & vPosition(0) & ";" & _
                "TAX EXEMPTION|" & vTax(1) & "|" & vTax(0) & ";" & _
                "JOB LEVEL|" & vGrade(1) & "|" & vGrade(0) & ";" & _
                "SECURITY TYPE|" & vType(1) & "|" & vType(0) & ";" & _
                "BASIC SALARY|" & Format(vSalary(1), "###,##0.00") & "|" & Format(vSalary(0), "###,##0.00") & ";" & _
                "ECOLA|" & Format(vACA(1), "###,##0.00") & "|" & Format(vACA(0), "###,##0.00") & ";" & _
                "REP ALLOW/TRANSPO ALLOW|" & Format(vRATA(1), "###,##0.00") & "|" & Format(vRATA(0), "###,##0.00") & ";" & _
                "TEMPO ALLOW/OT ALLOW|" & Format(vPERA(1), "###,##0.00") & "|" & Format(vPERA(0), "###,##0.00") & ";" & _
                "MEAL ALLOW|" & Format(vMeal(1), "###,##0.00") & "|" & Format(vMeal(0), "###,##0.00") & ";" & _
                "TOTAL==>|" & Format(vTotal(1), "##,##0.00") & "|" & Format(vTotal(0), "##,##0.00") & ";"
        vPrn.FontBold = False
        vPrn.Table = vFormat & vData
        vPrn.Paragraph = vbCrLf & "Remarks: " & vRemarks
        vFormat = "<4000|<3000|<3000;"
        vData = "PREPARED BY:|RECOMMENDED BY:|APPROVED BY:;" & vbCrLf & vbCrLf & vbCrLf & _
                vPrepared & "|" & vbCrLf & vbCrLf & vbCrLf & vRecommend & "|" & vbCrLf & vbCrLf & vbCrLf & _
                vApproved & ";" & _
                vDatePrepared & "|" & vDateRecommend & "|" & vDateApproved & ";"
        vPrn.FontBold = True
        vPrn.Table = vFormat & vData
        vPrn.Action = VSPrinter8Lib.ActionSettings.paEndDoc
        vPDF.ConvertDocument(vPrn, Server.MapPath("") & "\downloads\emr.pdf")
        vScript = "window.close(); viewwin=window.open('downloads/emr.pdf','viewwin','toolbar=no,location=no,width=800,height=600,top=50,left=100,scrollbars=yes');"
        cm.Dispose()
        'c.Close()
        vPDF = Nothing
        vPrn = Nothing
    End Sub
   
    Protected Sub cmbQuickNavi_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbQuickNavi.SelectedIndexChanged
        Session.Remove("oldval")
        Session.Remove("newval")
        Server.Transfer(cmbQuickNavi.SelectedValue)
    End Sub

    Protected Sub cmdCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        Session.Remove("oldval")
        Session.Remove("newval")
        Session.Remove("empid")
        vScript = "window.close();"
    End Sub

    Protected Sub chkReqTimeIn_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkReqTimeIn.CheckedChanged
        txtMaxFlexHrs.Visible = chkReqTimeIn.Checked
    End Sub
End Class
