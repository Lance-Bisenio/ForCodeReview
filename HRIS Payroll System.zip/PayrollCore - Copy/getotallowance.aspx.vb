Imports denaro.fis
Partial Class getotallowance
    Inherits System.Web.UI.Page
    Public vReturn As String = "0"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim c As New sqlclient.sqlconnection(connStr)
        Dim cm As New sqlclient.sqlcommand
        Dim rs As sqlclient.sqldatareader
        Dim vPeriod As String = Request.Form("p")
        Dim vData() As String = vPeriod.Split("/")
        Dim vMonth As Integer = Val(vData(0))
        Dim vYear As Integer = Val(vData(2))
        Dim vDay As Integer = Val(Request.Form("d"))
        Dim vDate As Date = CDate(vMonth & "/" & vDay & "/" & vYear)

        Dim vSchedOut As String = " "
        Dim vActualOut As String = " "
        Dim vActualIn As Date = Nothing
        Dim vExcess As Decimal = 0
        Dim vApprovedOT As Decimal = 0
        Dim vHrsCredit As Decimal = 0
        Dim vAmtCredit As Decimal = 0
        Dim vAdjHrsCredit As Decimal = 0
        Dim vOfc As String = ""
        Dim vRc As String = ""
        Dim vRateHr As Decimal = 0
        Dim vRestHoliday(7) As Integer
        Dim vTruncated As Boolean = False

        Dim vFrequency As Integer = 1   'default to per hour basis
        Dim vMinOt As Decimal = 0       'minimum ot hours
        Dim vMaxOt As Decimal = 0       'maximum ot hours
        Dim vRegOt As Decimal = 0
        Dim vRestOt As Decimal = 0
        Dim vRestOtX8 As Decimal = 0

        Dim vRegOtUom As Integer = 0    '0=percent; 1=amount
        Dim vRestOtUom As Integer = 0   '0=percent; 1=amount
        Dim vRestOtX8Uom As Integer = 0 '0=percent; 1=amount

        Dim vCalcMethod As Integer = 1  '1=per day; 2 = per cut off

        Dim vRestday As Boolean = True  'default to restday
        Dim vHoliday As Boolean = False 'default to regular day

        cm.Connection = c
        vReturn = "Error|Error|0|0|0|0"
        Try
            c.Open()
            Try
                'get schedule
                cm.CommandText = "select Date_Sched,Start_Time,End_Time from py_emp_time_Sched where Emp_Cd='" & _
                    Request.Form("id") & "' and Date_Sched='" & Format(vDate, "yyyy/MM/dd") & "'"
                rs = cm.ExecuteReader
                If rs.Read Then
                    If CDate(Format(CDate(rs("End_Time")), "HH:mm")) < CDate(Format(CDate(rs("Start_Time")), "HH:mm")) Then
                        vSchedOut = Format(vDate.AddDays(1), "MM/dd/yyyy")
                    Else
                        vSchedOut = Format(vDate, "MM/dd/yyyy")
                    End If
                    vSchedOut += " " & Format(CDate(rs("End_Time")), "HH:mm")
                    vRestday = False    'day is a regular day
                End If
                rs.Close()

                'get actual out
                cm.CommandText = "select Time_In, Time_Out,Time_OutDate from py_time_log where Emp_Cd='" & _
                    Request.Form("id") & "' and Tran_Date='" & Format(vDate, "yyyy/MM/dd") & "'"
                rs = cm.ExecuteReader
                If rs.Read Then
                    If Not IsDBNull(rs("Time_Out")) Then
                        vActualOut = Format(CDate(rs("Time_OutDate") & " " & rs("Time_Out")), "MM/dd/yyyy HH:mm")
                    End If
                    If Not IsDBNull(rs("Time_In")) Then
                        vActualIn = CDate(Format(vDate, "yyyy/MM/dd") & " " & rs("Time_In"))
                    End If
                End If
                rs.Close()

                'get excess hours
                If IsDate(vActualOut) And IsDate(vSchedOut) Then
                    If CDate(vActualOut) > CDate(vSchedOut) Then
                        vExcess = Math.Round(DateDiff(DateInterval.Minute, CDate(vSchedOut), CDate(vActualOut)) / 60, 2)
                    End If
                ElseIf vSchedOut.Trim = "" And vActualIn <> Nothing And IsDate(vActualOut.Trim) Then
                    vExcess = Math.Round(DateDiff(DateInterval.Minute, CDate(vActualIn), CDate(vActualOut)) / 60, 2)
                End If

                'get approved hours
                cm.CommandText = "select DaysLeave from hr_leave_application where Emp_Cd='" & _
                    Request.Form("id") & "' and LeaveCd='OT' and  month(StartDate)=" & vDate.Month & _
                    " and day(StartDate)=" & vDate.Day & " and year(StartDate)=" & vDate.Year
                rs = cm.ExecuteReader
                If rs.Read Then
                    If Not IsDBNull(rs("DaysLeave")) Then
                        vApprovedOT = rs("DaysLeave")
                    End If
                End If
                rs.Close()
                vHrsCredit = Math.Min(vExcess, vApprovedOT)
                vAmtCredit = 0

                'now get the matrix parameters of the employee
                'cm.CommandText = "select Agency_Cd,Rc_Cd,Rate_Day,Req_Hrs_Day,Aca,Rest_Holiday1," & _
                '    "Rest_Holiday2,Rest_Holiday3,Rest_Holiday4,Rest_Holiday5,Rest_Holiday6,Rest_Holiday7" & _
                '    " from py_emp_master where Emp_Cd='" & Request.Form("id") & "'"
                cm.CommandText = "select Agency_Cd,Rc_Cd,Rate_Day,Req_Hrs_Day,RegOt," & _
                    "RegOtUom,RestOt,RestOtX8,RestOtUom,RestOtX8Uom,CalcMethod,Frequency, " & _
                    "MinOtHours,MaxOtAmount,FractionTruncated from py_emp_master where Emp_Cd='" & _
                    Request.Form("id") & "'"
                rs = cm.ExecuteReader
                If rs.Read Then
                    vOfc = rs("Agency_Cd")
                    vRc = rs("Rc_Cd")
                    vRateHr = rs("Rate_Day") / rs("Req_Hrs_Day")
                    vFrequency = rs("Frequency")
                    vMinOt = rs("MinOtHours")
                    vMaxOt = rs("MaxOtAmount")
                    vTruncated = rs("FractionTruncated") = 1

                    vRegOt = rs("RegOt")
                    vRestOt = rs("RestOt")
                    vRestOtX8 = rs("RestOtX8")

                    vRegOtUom = rs("RegOtUom")
                    vRestOtUom = rs("RestOtUom")
                    vRestOtX8Uom = rs("RestOtX8Uom")

                    vCalcMethod = rs("CalcMethod")
                End If
                rs.Close()
                'check if date falls on holiday
                cm.CommandText = "select Holy_Date from py_holiday where Holy_Date='" & _
                    Format(vDate, "yyyy/MM/dd") & "' and (Office_Cd='*' or Office_Cd like '%" & vOfc & "%') and " & _
                    "(Rc_Cd='*' or Rc_Cd like '%" & vRc & "%')"
                rs = cm.ExecuteReader
                If rs.Read Then     'day is a holiday
                    vHoliday = True
                End If
                rs.Close()

                If vCalcMethod = 1 Then  'calculation of ot allowance is per day basis
                    'adjust hours credit based on frequency reflection
                    vAdjHrsCredit = vHrsCredit / vFrequency
                    If vTruncated Then
                        vAdjHrsCredit = Math.Floor(vAdjHrsCredit)
                    End If

                    If vAdjHrsCredit >= vMinOt Then  'qualified for calculation
                        If vRestday Or vHoliday Then    'day falls on either restday or holiday or both restday and holiday
                            'check if hours credit is more than 8 hours, get only the excess of 8 hours
                            If vAdjHrsCredit >= 8 Then
                                vAdjHrsCredit = vAdjHrsCredit - 8
                            End If
                            vAdjHrsCredit = Math.Min(vAdjHrsCredit, vMaxOt)
                            ''''''''' commented out by vic on 6/2/2009
                            'turned off, 1st 8 hours should be reflected as OT premium in daily log computation
                            'vAmtCredit = IIf(vRestOtUom = 1, vRestOt, vRestOt * vRateHr) * IIf(vAdjHrsCredit > 8, 8, vAdjHrsCredit)
                            'If vAdjHrsCredit > 8 Then
                            ''''''''''''''''' end comment ''''''''''''''
                            'vAmtCredit += IIf(vRestOtX8Uom = 1, vRestOtX8, vRestOtX8 * vRateHr) * (vAdjHrsCredit - 8)
                            vAmtCredit += IIf(vRestOtX8Uom = 1, vRestOtX8, vRestOtX8 * vRateHr) * (vAdjHrsCredit)
                            '''''''''''' commented out by vic on 6/2/2009
                            'End If
                            '''''''''''''' end comment ''''''''''''''''
                        Else                            'day is a regular day
                            vAdjHrsCredit = Math.Min(vAdjHrsCredit, vMaxOt)
                            vAmtCredit = IIf(vRegOtUom = 1, vRegOt, vRegOt * vRateHr) * vAdjHrsCredit
                        End If
                    End If
                Else    'if per cut off
                    'round off to per 30 mins
                    vAdjHrsCredit = Int(vHrsCredit) + RoundOff(vHrsCredit - Int(vHrsCredit))
                    If vAdjHrsCredit >= vMinOt Then 'qualified ot hours
                        If vRestday Or vHoliday Then    'day falls on either restday or holiday or both restday and holiday
                            If vAdjHrsCredit >= 8 Then
                                vAdjHrsCredit = vAdjHrsCredit - 8
                            End If
                        End If
                        vAdjHrsCredit = Math.Min(vAdjHrsCredit, vMaxOt)
                    Else
                        vAdjHrsCredit = 0
                    End If
                End If
                vAmtCredit = Math.Round(vAmtCredit, 2)
                vAdjHrsCredit = Format(Math.Round(vAdjHrsCredit, 2), "#0.00")
                vReturn = vSchedOut & "|" & vActualOut & "|" & vExcess & "|" & vApprovedOT & "|" & _
                    vAdjHrsCredit & "|" & vAmtCredit
            Catch ex As system.exception
                vReturn = ex.Message.Replace(vbCrLf, " ") & "|Error|0|0|0|0"
            Finally
                c.Close()
                c.Dispose()
                cm.Dispose()
            End Try
        Catch ex As system.exception
            vReturn = "Error|Error|0|0|0|0"
        End Try
    End Sub
    Private Function RoundOff(ByVal pRemainder As Single) As Single
        If pRemainder >= 0.5 Then
            RoundOff = 0.5
        Else
            RoundOff = 0
        End If
    End Function

End Class
