﻿Imports denaro.fis
Partial Class payrollsummdtl
    Inherits System.Web.UI.Page
    Public vDump As String = ""
    Public vScript As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            vScript = "alert('Your login session has expired. Please re-login again.'); window.close();"
            Exit Sub
        End If
        If Not IsPostBack Then
            Dim vSql As String = Session("sqlstr")
            Dim vCond As String = Mid(vSql, InStr(vSql, "where"))
            Dim vClass As String
            Dim vTotal As Decimal = 0
            Dim c As New SqlClient.SqlConnection(connStr)
            Dim cm As New SqlClient.SqlCommand
            Dim rs As SqlClient.SqlDataReader

            lblBank.Text = Request.Item("b")

            Try
                c.Open()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                c.Dispose()
                cm.Dispose()
                Exit Sub
            End Try

            cm.Connection = c

            'get total Payroll amount per bank
            cm.CommandText = "select Name,Amount_Per from py_report " & _
                vCond & " and Amount_Per > 0 and Report_No is not null and Report_No<>'' and " & _
                "Emp_Cd in (select Emp_Cd from py_emp_master where DateHold is null and Date_Resign is null) " & _
                "and BankCd='" & lblBank.Text & "' Order by Name"

            rs = cm.ExecuteReader
            vDump = ""
            vTotal = 0
            vClass = "odd"
            Do While rs.Read
                vDump += "<tr class='" & vClass & "'>" & _
                    "<td class='labelL'>" & rs("Name") & "</td>" & _
                    "<td class='labelR'>" & Format(rs("Amount_Per"), "###,##0.00") & "</td></tr>"
                vTotal += rs("Amount_Per")
                vClass = IIf(vClass = "odd", "even", "odd")
            Loop
            rs.Close()
            vDump += "<tr class='activeBar'>" & _
              "<td class='labelR'>GRAND TOTAL:</td>" & _
              "<td class='labelR'>" & Format(vTotal, "##,###,##0.00") & "</td></tr>"
        End If
    End Sub
End Class
