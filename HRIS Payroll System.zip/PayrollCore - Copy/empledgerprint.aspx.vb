﻿Imports denaro
Partial Class empledgerprint
    Inherits System.Web.UI.Page

    Public vData As New StringBuilder

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Dim c As New sqlclient.sqlConnection
        Dim cm As New sqlclient.sqlCommand
        Dim rs As sqlclient.sqlDataReader

        Dim couter As Integer = 1

        Dim i As Decimal = 1
        Dim v4F As Decimal = 0
        Dim v4J As Decimal = 0
        Dim v7 As Decimal = 0
        Dim vTax_Basic As Decimal = 0
        Dim vTtl_TaxableCompIncome As Decimal = 0

        Dim vDate As String = Request.Item("vDate")
        Dim vSched As String = Request.Item("vSched")
        Dim vAgencyCd As String = Request.Item("vAgencyCd")
        Dim vAgencyName As String = Request.Item("vAgencyName")
        Dim vBranch As String = Request.Item("vBranch")
        Dim vAgencyfld As String = ""

        'lblForm.Text = vSched


        lblDate.Text = "DECEMBER 31 " '& vDate
        lblEmpTin.Text = ""
        lblYear.Text = vDate
        lblCompName.Text = vAgencyName

        c.ConnectionString = connStr
        c.Open()

        If vAgencyCd = "All" Then
            vAgencyCd = ""
        Else
            vAgencyCd = " and AgencyCd='" & vAgencyCd & "'"
        End If

        'Response.Write("select Tin_Emr, Lname, Fname, Mname, Tin_Emp, Salaries_Nontax, NonTax_13th, Fringe_Benefit, " & _
        '"Mandatory, OtherIncent_NonTax, Salaries_Tax, Tax_13th, OtherIncent_Tax, Tax_Cd, Exemption, Premiums, " & _
        '"TaxDue, TaxwithHeld, Variance, TaxwithHeld_Dec, Actual_WithHeld, Subs_Filing, BranchCd_Emp " & _
        '"from [1604f] where Sched_Num='" & vSched & "' and year(ReturnPd)='" & vDate & "' " & vAgencyCd & " ")

        cm.Connection = c
        'cm.CommandText = "select Tin_Emr, Lname, Fname, Mname, Tin_Emp, Salaries_Nontax, NonTax_13th, Fringe_Benefit, " & _
        '"Mandatory, OtherIncent_NonTax, Salaries_Tax, Tax_13th, OtherIncent_Tax, Tax_Cd, Exemption, Premiums, " & _
        '"TaxDue, TaxwithHeld, Variance, TaxwithHeld_Dec, Actual_WithHeld, Subs_Filing, BranchCd_Emp, total_taxable_comp_Income, Tax_Basic_Sal " & _
        '"from [1604f] where Sched_Num='" & vSched & "' and year(ReturnPd)='" & vDate & "' " & vAgencyCd & " order by Lname "


        cm.CommandText = "select Tin_Emp,lname,fname,mname," & _
        "Gross_Comp_Income,Prev_Nontax_13th_Month,Prev_Nontax_De_Minimis,Prev_Nontax_Sss,Prev_Nontax_Salaries," & _
        "Prev_Total_Nontax_Comp_Income, Prev_Taxable_Basic_Salary,Prev_Taxable_13th_Month,Prev_Taxable_Salaries,Prev_Total_Taxable," & _
        "NonTax_13th,Pres_Nontax_De_Minimis,Mandatory,Otherincent_Nontax,Total_Nontax_Comp_Income," & _
        "Tax_Basic_Sal,Tax_13th, Salaries_Tax, Total_Taxable_Comp_Income,Prev_Pres_Total_Taxable," & _
        "Exemption, Premiums,Net_Taxable_Comp_Income,Taxdue,Prev_Tax_Withheld," & _
        "(Taxwithheld - Taxwithheld_Dec) as vJanToNov,Taxwithheld_Dec,Variance,Subs_Filing " & _
        "from [1604f] where Sched_Num='" & vSched & "' and year(ReturnPd)='" & vDate & "' " & vAgencyCd & _
        "order by Lname "

        rs = cm.ExecuteReader
        Dim total(27) As Decimal
        For i = 0 To UBound(total)
            total(i) = 0
        Next

        Do While rs.Read
            If lblEmpTin.Text = "" Then
                lblEmpTin.Text = rs("Tin_Emp")
            End If

            vData.AppendLine("<tr>")
            vData.AppendLine("<td class='label_L'>" & couter & "</td>")
            vData.AppendLine("<td class='label_C'>" & rs("Tin_Emp") & "-" & vBranch & "</td>")
            vData.AppendLine("<td class='label_L'>" & rs("Lname") & "</td>")
            vData.AppendLine("<td class='label_L'>" & rs("Fname") & "</td>")
            vData.AppendLine("<td class='label_L'>" & rs("Mname") & "</td>")

            vData.AppendLine("<td class='label_R'>" & Format(rs("Gross_Comp_Income"), "###,##0.00") & "</td>")
            vData.AppendLine("<td class='label_R'>" & Format(rs("Prev_Nontax_13th_Month"), "###,##0.00") & "</td>")
            vData.AppendLine("<td class='label_R'>" & Format(rs("Prev_Nontax_De_Minimis"), "###,##0.00") & "</td>")
            vData.AppendLine("<td class='label_R'>" & Format(rs("Prev_Nontax_Sss"), "###,##0.00") & "</td>")
            vData.AppendLine("<td class='label_R'>" & Format(rs("Prev_Nontax_Salaries"), "###,##0.00") & "</td>")

            vData.AppendLine("<td class='label_R'>" & Format(rs("Prev_Total_Nontax_Comp_Income"), "###,##0.00") & "</td>")
            vData.AppendLine("<td class='label_R'>" & Format(rs("Prev_Taxable_Basic_Salary"), "###,##0.00") & "</td>")
            vData.AppendLine("<td class='label_R'>" & Format(rs("Prev_Taxable_13th_Month"), "###,##0.00") & "</td>")
            vData.AppendLine("<td class='label_R'>" & Format(rs("Prev_Taxable_Salaries"), "###,##0.00") & "</td>")
            vData.AppendLine("<td class='label_R'>" & Format(rs("Prev_Total_Taxable"), "###,##0.00") & "</td>")

            vData.AppendLine("<td class='label_R'>" & Format(rs("NonTax_13th"), "###,##0.00") & "</td>")
            vData.AppendLine("<td class='label_R'>" & Format(rs("Pres_Nontax_De_Minimis"), "###,##0.00") & "</td>")
            vData.AppendLine("<td class='label_R'>" & Format(rs("Mandatory"), "###,##0.00") & "</td>")
            vData.AppendLine("<td class='label_R'>" & Format(rs("Otherincent_Nontax"), "###,##0.00") & "</td>")
            vData.AppendLine("<td class='label_R'>" & Format(rs("Total_Nontax_Comp_Income"), "###,##0.00") & "</td>")

            vData.AppendLine("<td class='label_R'>" & Format(rs("Tax_Basic_Sal"), "###,##0.00") & "</td>")
            vData.AppendLine("<td class='label_R'>" & Format(rs("Tax_13th"), "###,##0.00") & "</td>")
            vData.AppendLine("<td class='label_R'>" & Format(rs("Salaries_Tax"), "###,##0.00") & "</td>")
            vData.AppendLine("<td class='label_R'>" & Format(rs("Total_Taxable_Comp_Income"), "###,##0.00") & "</td>")
            vData.AppendLine("<td class='label_R'>" & Format(rs("Prev_Pres_Total_Taxable"), "###,##0.00") & "</td>")

            vData.AppendLine("<td class='label_R'>" & Format(rs("Exemption"), "###,##0.00") & "</td>")
            vData.AppendLine("<td class='label_R'>" & Format(rs("Premiums"), "###,##0.00") & "</td>")
            vData.AppendLine("<td class='label_R'>" & Format(rs("Net_Taxable_Comp_Income"), "###,##0.00") & "</td>")
            vData.AppendLine("<td class='label_R'>" & Format(rs("Taxdue"), "###,##0.00") & "</td>")
            vData.AppendLine("<td class='label_R'>" & Format(rs("Prev_Tax_Withheld"), "###,##0.00") & "</td>")

            vData.AppendLine("<td class='label_R'>" & Format(rs("vJanToNov"), "###,##0.00") & "</td>")
            vData.AppendLine("<td class='label_R'>" & Format(rs("Taxwithheld_Dec"), "###,##0.00") & "</td>")
            vData.AppendLine("<td class='label_R'>" & Format(rs("Variance"), "###,##0.00") & "</td>")
            vData.AppendLine("<td class='label_C'>" & rs("Subs_Filing") & "</td>")
            vData.AppendLine("</tr>")

            couter += 1

            total(0) += rs("Gross_Comp_Income")
            total(1) += rs("Prev_Nontax_13th_Month")
            total(2) += rs("Prev_Nontax_De_Minimis")
            total(3) += rs("Prev_Nontax_Sss")
            total(4) += rs("Prev_Nontax_Salaries")

            total(5) += rs("Prev_Total_Nontax_Comp_Income")
            total(6) += rs("Prev_Taxable_Basic_Salary")
            total(7) += rs("Prev_Taxable_13th_Month")
            total(8) += rs("Prev_Taxable_Salaries")
            total(9) += rs("Prev_Total_Taxable")

            total(10) += rs("NonTax_13th")
            total(11) += rs("Pres_Nontax_De_Minimis")
            total(12) += rs("Mandatory")
            total(13) += rs("Otherincent_Nontax")
            total(14) += rs("Total_Nontax_Comp_Income")

            total(15) += rs("Tax_Basic_Sal")
            total(16) += rs("Tax_13th")
            total(17) += rs("Salaries_Tax")
            total(18) += rs("Total_Taxable_Comp_Income")
            total(19) += rs("Prev_Pres_Total_Taxable")

            total(20) += rs("Exemption")
            total(21) += rs("Premiums")
            total(22) += rs("Net_Taxable_Comp_Income")
            total(23) += rs("Taxdue")
            total(24) += rs("Prev_Tax_Withheld")

            total(25) += rs("vJanToNov")
            total(26) += rs("Taxwithheld_Dec")
            total(27) += rs("Variance")




            'GROSS COMPENSATION INCOME
            'vData.AppendLine("<td class='label_R'>" & Format(rs("Salaries_Nontax"), "###,##0.00") & "</td>")

            ''13 MONTH PAY & OTHER DENEFITS
            'vData.AppendLine("<td class='label_R'>" & Format(rs("NonTax_13th"), "###,##0.00") & "</td>")

            ''DE MINIMIS BENEFITS
            'vData.AppendLine("<td class='label_R'>" & Format(rs("Fringe_Benefit"), "###,##0.00") & "</td>")

            ''SS, GSIS, PHIC & PAG-IBIG CONTRIBUTIONS AND UNION DUES
            'vData.AppendLine("<td class='label_R'>" & Format(rs("Mandatory"), "###,##0.00") & "</td>")

            ''SALARIES & OTHER FORMS OF COMPENSATION
            'vData.AppendLine("<td class='label_R'>" & Format(rs("OtherIncent_NonTax"), "###,##0.00") & "</td>")

            ''TOTAL NON-TAXABLE/EXEMPT COMPENSATION INCOME
            'v4F = (rs("NonTax_13th") + rs("Fringe_Benefit") + rs("Mandatory") + rs("OtherIncent_NonTax"))
            'vData.AppendLine("<td class='label_R'>" & Format(v4F, "###,##0.00") & "</td>")                                                                  '4F = (4B + 4C + 4D + 4E)

            ''BASIC SALARY (4G)
            'vTax_Basic = rs("Tax_Basic_Sal") + rs("OtherIncent_Tax") - rs("Mandatory")
            'vData.AppendLine("<td class='label_R'>" & Format(vTax_Basic, "###,##0.00") & "</td>")

            ''13TH MONTH PAY & OTHER BENEFITS (4H)
            'vData.AppendLine("<td class='label_R'>" & Format(rs("Tax_13th"), "###,##0.00") & "</td>")

            ''SALARIES & OTHER FORMS OF COMPENSATION INCOME (4I)
            ''vData.AppendLine("<td class='label_R'>" & Format(rs("OtherIncent_Tax"), "###,##0.00") & "</td>")
            'vData.AppendLine("<td class='label_R'>" & Format(0, "###,##0.00") & "</td>")                                                                    '4I

            ''TOTAL TAXABLE COMPENSATION INCOME (4J)
            'vTtl_TaxableCompIncome = vTax_Basic + rs("Tax_13th") 'rs("total_taxable_comp_Income")
            'vData.AppendLine("<td class='label_R'> " & Format(vTtl_TaxableCompIncome, "###,##0.00") & "</td>")

            ''CODE (5A)
            'vData.AppendLine("<td class='label_C'>" & rs("Tax_Cd") & "</td>")

            ''AMOUNT (5B) 
            'vData.AppendLine("<td class='label_R'>" & Format(rs("Exemption"), "###,##0.00") & "</td>")

            ''PREMIUM PAID ON HEALTH AND/OR HOSPITAL INSURANCE (6)
            'vData.AppendLine("<td class='label_R'>" & Format(rs("Premiums"), "###,##0.00") & "</td>")

            ''NET TAXABLE COMPENSATION INCOME (7)
            'v7 = vTtl_TaxableCompIncome - rs("Exemption")
            'vData.AppendLine("<td class='label_R'>" & Format(v7, "###,##0.00") & "</td>")

            ''TAX DUE (Jan - Dec)
            'vData.AppendLine("<td class='label_R'>" & Format(rs("TaxDue"), "###,##0.00") & "</td>")

            ''TAX WITHHELD (Jan - Dec) (9)
            ''vData.AppendLine("<td class='label_R'>" & Format(rs("TaxwithHeld") - rs("TaxwithHeld_Dec"), "###,##0.00") & "</td>")   
            'vData.AppendLine("<td class='label_R'>" & Format(rs("TaxwithHeld"), "###,##0.00") & "</td>")

            ''OVER WITHHELD TAX EMPLOYEE '(10B)=(9)-(8)
            ''vData.AppendLine("<td class='label_R'>" & Format(rs("TaxwithHeld_Dec"), "###,##0.00") & "</td>")                       
            'vData.AppendLine("<td class='label_R'>" & Format(0, "###,##0.00") & "</td>")

            ''AMOUNT OF TAX WITHHELD AS ADJUSTED (11)=(9+10A) or (9-10B)
            'vData.AppendLine("<td class='label_R'>" & Format(rs("Actual_WithHeld"), "###,##0.00") & "</td>")

            ''SUBSTITUTED FILING? YES/NO
            'vData.AppendLine("<td class='label_C'>" & rs("Subs_Filing") & "</td>")
            'vData.AppendLine("</tr>")
            
        Loop

        vData.AppendLine("</tr>")
        vData.AppendLine("<td colspan='4' class='label_C'></td>")
        vData.AppendLine("<td class='label_R'><b>TOTAL :</b></td>")

        vData.AppendLine("<td class='label_Rb'><b>" & Format(total(0), "###,##0.00") & "</b></td>")
        vData.AppendLine("<td class='label_Rb'><b>" & Format(total(1), "###,##0.00") & "</b></td>")
        vData.AppendLine("<td class='label_Rb'><b>" & Format(total(2), "###,##0.00") & "</b></td>")
        vData.AppendLine("<td class='label_Rb'><b>" & Format(total(3), "###,##0.00") & "</b></td>")
        vData.AppendLine("<td class='label_Rb'><b>" & Format(total(4), "###,##0.00") & "</b></td>")

        vData.AppendLine("<td class='label_Rb'><b>" & Format(total(5), "###,##0.00") & "</b></td>")
        vData.AppendLine("<td class='label_Rb'><b>" & Format(total(6), "###,##0.00") & "</b></td>")
        vData.AppendLine("<td class='label_Rb'><b>" & Format(total(7), "###,##0.00") & "</b></td>")
        vData.AppendLine("<td class='label_Rb'><b>" & Format(total(8), "###,##0.00") & "</b></td>")
        vData.AppendLine("<td class='label_Rb'><b>" & Format(total(9), "###,##0.00") & "</b></td>")

        vData.AppendLine("<td class='label_Rb'><b>" & Format(total(10), "###,##0.00") & "</b></td>")
        vData.AppendLine("<td class='label_Rb'><b>" & Format(total(11), "###,##0.00") & "</b></td>")
        vData.AppendLine("<td class='label_Rb'><b>" & Format(total(12), "###,##0.00") & "</b></td>")
        vData.AppendLine("<td class='label_Rb'><b>" & Format(total(13), "###,##0.00") & "</b></td>")
        vData.AppendLine("<td class='label_Rb'><b>" & Format(total(14), "###,##0.00") & "</b></td>")

        vData.AppendLine("<td class='label_Rb'><b>" & Format(total(15), "###,##0.00") & "</b></td>")
        vData.AppendLine("<td class='label_Rb'><b>" & Format(total(16), "###,##0.00") & "</b></td>")
        vData.AppendLine("<td class='label_Rb'><b>" & Format(total(17), "###,##0.00") & "</b></td>")
        vData.AppendLine("<td class='label_Rb'><b>" & Format(total(18), "###,##0.00") & "</b></td>")
        vData.AppendLine("<td class='label_Rb'><b>" & Format(total(19), "###,##0.00") & "</b></td>")

        vData.AppendLine("<td class='label_Rb'><b>" & Format(total(20), "###,##0.00") & "</b></td>")
        vData.AppendLine("<td class='label_Rb'><b>" & Format(total(21), "###,##0.00") & "</b></td>")
        vData.AppendLine("<td class='label_Rb'><b>" & Format(total(22), "###,##0.00") & "</b></td>")
        vData.AppendLine("<td class='label_Rb'><b>" & Format(total(23), "###,##0.00") & "</b></td>")
        vData.AppendLine("<td class='label_Rb'><b>" & Format(total(24), "###,##0.00") & "</b></td>")

        vData.AppendLine("<td class='label_Rb'><b>" & Format(total(25), "###,##0.00") & "</b></td>")
        vData.AppendLine("<td class='label_Rb'><b>" & Format(total(26), "###,##0.00") & "</b></td>")
        vData.AppendLine("<td class='label_Rb'><b>" & Format(total(27), "###,##0.00") & "</b></td>")
        vData.AppendLine("<td class='label_Rb'></td>")

        vData.AppendLine("</tr>")

        c.Close()
        c.Dispose()
        rs.Close()

    End Sub
End Class
