
Partial Class nojavascript
    Inherits System.Web.UI.Page

End Class
