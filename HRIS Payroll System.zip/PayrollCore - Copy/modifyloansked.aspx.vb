Imports denaro.fis
Partial Class modifyloansked
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Dim c As New sqlclient.sqlconnection(connStr)
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Session("returnaddr") = "loanmonitor.aspx"
            vScript = "self.close();"
        End If
        If Not IsPostBack Then
            lblCaption.Text = "Modify Loan Schedule"
            cmdActivate.Text = Request.Item("vCmd")

            txtEmpCd.Text = Request.Item("Id")
            txtAmt.Text = Request.Item("DueAmt")
            txtDueDate.Text = Request.Item("DueDate")
            txtLoanType.Text = Request.Item("LoanCd")
            Session("amt") = txtAmt.Text
        End If
    End Sub

    Protected Sub cmdActivate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdActivate.Click
        Dim vSql As String = ""
        Dim VEmp As String = Request.Item("Id")
        Dim vTranDate As Date = Request.Item("DueDate")
        Dim vType As String = Request.Item("vCmd")
        Dim vDueAmt As Decimal = Request.Item("DueAmt")
        'Dim rs As sqlclient.sqldatareader
        Dim vLoan As String = Request.Item("LoanCd")
        Dim vLoanDate As Date = Nothing
        Dim cm As New sqlclient.sqlcommand

        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c


        If vType = "Deactivate" Then
            cm.CommandText = "UPDATE py_loan_dtl SET Active=0 WHERE Emp_Cd='" & _
                             VEmp & "' AND Loan_Cd='" & _
                            vLoan & "' AND Tran_Date='" & _
                            vTranDate & "'"
            CalculateLoan()
        Else
            cm.CommandText = "UPDATE py_loan_dtl SET Active=1 WHERE Emp_Cd='" & _
                            VEmp & "' AND Loan_Cd='" & _
                            vLoan & "' AND Tran_Date='" & _
                            vTranDate & "'"
            ActivateLoan()
        End If
        Try
            cm.ExecuteNonQuery()
            vScript = "alert('Changes were successfully saved.');self.close();window.opener.document.form1.submit();"
        Catch ex As system.exception
            vScript = "alert('Error occurred:'" & ex.Message.Replace("'", "") & ");"
        End Try


        cm.Dispose()
        c.Close()
        c.Dispose()
    End Sub

    Private Sub ActivateLoan()
        Dim cm As New sqlclient.sqlcommand("select Tran_Date from py_loan_dtl where Emp_Cd='" & _
            txtEmpCd.Text & "' and Loan_Cd='" & txtLoanType.Text & _
            "' and Loan_Date='" & Request.Item("LoanDate") & "' order by Tran_Date desc", c)
        Dim rs As sqlclient.sqldatareader
        Dim vLastDate(2) As Date

        rs = cm.ExecuteReader

        If rs.Read Then 'get last record
            vLastDate(0) = rs("Tran_Date")
            If rs.Read Then 'get second to the last record
                vLastDate(1) = rs("Tran_Date")
            End If
        End If
        rs.Close()
        cm.CommandText = "delete from py_loan_dtl where Emp_Cd='" & txtEmpCd.Text & _
            "' and Loan_Cd='" & txtLoanType.Text & "' and Loan_Date='" & Request.Item("LoanDate") & _
            "' and Tran_Date='" & vLastDate(1) & "'"
        cm.ExecuteNonQuery()
        cm.CommandText = "update py_loan_dtl set Tran_Date='" & vLastDate(1) & _
            "' where Emp_Cd='" & txtEmpCd.Text & "' and Loan_Cd='" & txtLoanType.Text & _
            "' and Loan_Date='" & Request.Item("LoanDate") & "' and Tran_Date='" & vLastDate(0) & "'"
        cm.ExecuteNonQuery()
        cm.Dispose()
    End Sub
    Private Sub CalculateLoan()
        Dim cm As New sqlclient.sqlcommand
        Dim rs As sqlclient.sqldatareader

        Dim vLastDate As Date
        Dim vLastTmp As Date
        Dim vFreq As Integer

        cm.Connection = c
        cm.CommandText = "SELECT FreqCd FROM py_loan_hdr WHERE Emp_Cd='" & _
            txtEmpCd.Text & "' and Loan_Cd='" & txtLoanType.Text & _
            "' and Loan_Date='" & Request.Item("LoanDate") & "'"
        rs = cm.ExecuteReader
        If rs.Read Then
            vFreq = rs(0)
        End If
        rs.Close()

        cm.CommandText = "select Tran_Date from py_loan_dtl where Emp_Cd='" & _
            txtEmpCd.Text & "' and Loan_Cd='" & txtLoanType.Text & _
            "' and Loan_Date='" & Request.Item("LoanDate") & "' order by Tran_Date desc"
        rs = cm.ExecuteReader
        If rs.Read Then
            vLastDate = rs(0)
        End If
        rs.Close()

        vLastTmp = getNextDate(vFreq, vLastDate)

        cm.CommandText = "UPDATE py_loan_dtl SET Tran_Date='" & vLastTmp & "' WHERE Emp_Cd='" & _
            txtEmpCd.Text & "' and Loan_Cd='" & txtLoanType.Text & _
            "' and Loan_Date='" & Request.Item("LoanDate") & "' AND Tran_Date='" & vLastDate & "'"
        cm.ExecuteNonQuery()

        cm.CommandText = "INSERT INTO py_loan_dtl (Emp_Cd,Tran_Date,Amt_Cost,Loan_Cd,Paid,Loan_Date,Active) " & _
                        " VALUES ('" & txtEmpCd.Text & "','" & vLastDate & "','" & txtAmt.Text.Replace(",", "") & "','" & _
                        txtLoanType.Text & "',0,'" & Request.Item("LoanDate") & "',1)"
        cm.ExecuteNonQuery()
        cm.Dispose()
    End Sub
    Private Function getNextDate(ByVal vfreq As Integer, ByVal vLastDate As Date) As Date
        Dim vLastTmp As Date
        If vfreq = 0 Then
            vLastTmp = vLastDate.AddDays(13)     'get lowest boundary
        Else
            vLastTmp = vLastDate.AddMonths(1)
        End If

        Select Case vLastTmp.Day
            Case Is <= 15
                vLastTmp = CDate(vLastTmp.Month & "/15/" & vLastTmp.Year)
            Case Else
                vLastTmp = MonthEND(vLastTmp)
        End Select
        Return vLastTmp
    End Function
    Private Function IsPosted(ByVal tDate As Date) As Boolean
        Dim cm As New sqlclient.sqlCommand
        Dim rs As sqlclient.sqlDataReader
        Dim vRet As String = ""

        cm.Connection = c
        cm.CommandText = "SELECT DISTINCT FromDate,ToDate FROM py_report WHERE Posted=1 and Emp_Cd='" & tDate & "'"
        rs = cm.ExecuteReader
        If rs.Read Then
            If rs("FromDate") <= tDate And tDate <= rs("ToDate") Then
                vRet = 1
            End If
        End If
        Return vRet
    End Function

    Protected Sub CustomValidator1_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles CustomValidator1.ServerValidate
        txtAmt.Text = txtAmt.Text.Replace(",", "")
        args.IsValid = IsNumeric(txtAmt.Text)
    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        If Session("amt") <> txtAmt.Text Then   'save changes
            Dim vVariance As Decimal = Val(Session("amt")) - Val(txtAmt.Text)
            Dim vLastAmt As Decimal = 0
            Dim vAmt As Decimal = 0
            Dim vLastDate As Date = Nothing
            Dim vFreq As Integer

            Dim cm As New sqlclient.sqlcommand("update py_loan_dtl set Amt_Cost=" & _
                txtAmt.Text & "  WHERE Emp_Cd='" & _
                txtEmpCd.Text & "' and Loan_Cd='" & txtLoanType.Text & _
                "' and Loan_Date='" & Request.Item("LoanDate") & "' AND Tran_Date='" & txtDueDate.Text & "'", c)
            Dim rs As sqlclient.sqldatareader
            Dim vLastTmp As Date

            c.Open()
            cm.ExecuteNonQuery()
            cm.CommandText = "select TOP 1 Amt_Cost,Tran_Date from py_loan_dtl WHERE Emp_Cd='" & _
                txtEmpCd.Text & "' and Loan_Cd='" & txtLoanType.Text & _
                "' and Loan_Date='" & Request.Item("LoanDate") & "' order by Tran_Date desc"
            rs = cm.ExecuteReader
            If rs.Read Then
                vLastAmt = rs("Amt_Cost")
                vLastDate = rs("Tran_Date")
                vLastTmp = vLastDate
            End If
            rs.Close()

            cm.CommandText = "SELECT FreqCd FROM py_loan_hdr WHERE  Emp_Cd='" & _
                txtEmpCd.Text & "' and Loan_Cd='" & txtLoanType.Text & _
                "' and Loan_Date='" & Request.Item("LoanDate") & "'"
            rs = cm.ExecuteReader
            If rs.Read Then
                vFreq = rs(0)
            End If
            rs.Close()

            If vVariance + vLastAmt > Val(Request.Item("amort")) Then  'over
                vAmt = (vVariance + vLastAmt) - Val(Request.Item("amort"))
                Do While vAmt > 0
                    vLastTmp = getNextDate(vFreq, vLastTmp)

                    'insert
                    cm.CommandText = "INSERT INTO py_loan_dtl (Emp_Cd,Tran_Date,Amt_Cost,Loan_Cd,Paid,Loan_Date,Active) " & _
                        " VALUES ('" & txtEmpCd.Text & "','" & vLastTmp & "','" & vAmt & "','" & _
                        txtLoanType.Text & "',0,'" & Request.Item("LoanDate") & "',1)"
                    cm.ExecuteNonQuery()

                    If vAmt - Val(Request.Item("amort")) > 0 Then
                        vAmt -= Val(Request.Item("amort"))
                    Else
                        Exit Do
                    End If
                Loop
                vAmt = Val(Request.Item("amort"))
            Else    'exact or under
                vAmt = vVariance + vLastAmt
            End If
            cm.CommandText = "update py_loan_dtl set Amt_Cost = " & vAmt & _
                    "WHERE Emp_Cd='" & txtEmpCd.Text & "' and Loan_Cd='" & txtLoanType.Text & _
                "' and Loan_Date='" & Request.Item("LoanDate") & "' and Tran_Date='" & vLastDate & "'"
            cm.ExecuteNonQuery()


            c.Close()
            cm.Dispose()
        End If
    End Sub
End Class
