﻿Imports denaro.fis
Partial Class importwhf
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Protected Sub cmdUpload_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdUpload.Click
        If cmdBrowse.FileName = "" Then
            vScript = "alert('You must first supply a file to upload by clicking the Browse button.');"
            Exit Sub
        End If

        Dim vType As String = ""

        If cmdBrowse.FileName.Contains(".") Then
            vType = Mid(cmdBrowse.FileName, cmdBrowse.FileName.LastIndexOf(".") + 1)
        End If

        Dim vFilename As String = Server.MapPath(".") & "\uploaded\" & Session.SessionID & vType

        Try
            cmdBrowse.SaveAs(vFilename)
        Catch ex As IO.IOException
            vScript = "alert('An error has occurred while trying to upload the file. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            Exit Sub
        End Try

        Dim vHeader() As String
        Dim vFields() As String
        Dim vIndeces As String = ""
        Dim vLink As String = ""
        Dim vXrefTable As String = ""
        Dim vEmpCd As String = ""
        Dim vRc_Cd As String = ""
        Dim vAgency_Cd As String = ""
        Dim vDivCd As String = ""
        Dim vDeptCd As String = ""
        Dim vSectionCd As String = ""
        Dim vUnitCd As String = ""
        Dim vEmpType As String = ""
        Dim vIndex As Integer = -1
        Dim vSw As Boolean
        Dim i As Integer
        Dim j As Integer
        Dim c As New Odbc.OdbcConnection(connStr)
        Dim cm As New Odbc.OdbcCommand
        Dim rs As Odbc.OdbcDataReader
        Dim cmRef As New Odbc.OdbcCommand
        Dim rsRef As Odbc.OdbcDataReader
        Dim cmXRef As New Odbc.OdbcCommand
        Dim rsXRef As Odbc.OdbcDataReader
        Dim vSQL As String = ""
        Dim vSqlContent As String = ""
        Dim vContent() As String

        'now open the file for loading
        Try
            vContent = IO.File.ReadAllLines(vFilename)
        Catch ex As IO.IOException
            vScript = "alert('Error occurred while trying to read the contents of the file. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            Exit Sub
        End Try


        'get header fields
        vHeader = vContent(0).Split(txtFieldSeparator.Text)

        Try
            c.Open()
        Catch ex As Odbc.OdbcException
            vScript = "alert('Error occurred while tryint to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            cmRef.Dispose()
            cmXRef.Dispose()
            Exit Sub
        End Try


        cm.Connection = c
        cmRef.Connection = c
        cmXRef.Connection = c
        'find the index key
        cm.CommandText = "select * from _db where TempTable='wfh' and TableKey is not null and IndexKey=1"
        rs = cm.ExecuteReader
        If rs.Read Then
            vLink = rs("TableKey")
        End If
        rs.Close()

        'now insert uploaded file to temp table
        For i = vContent.GetLowerBound(0) + 1 To vContent.GetUpperBound(0)
            vFields = vContent(i).Split(txtFieldSeparator.Text)
            vSqlContent = "update import_emp_master set "
            cm.CommandText = "select * from _db where TempTable='wfh' and TableKey is not null"
            rs = cm.ExecuteReader
            Do While rs.Read
                vSw = False
                If Not IsDBNull(rs("FactKey")) Then
                    For j = vHeader.GetLowerBound(0) To vHeader.GetUpperBound(0)
                        If vHeader(j) = rs("FactKey") Then
                            If rs("TableKey") = vLink Then
                                vIndex = j
                            End If
                            vSw = True
                            Exit For
                        End If
                    Next
                    If vSw Then 'index was found
                        If rs("Required") = 1 And vFields(j) = "" Then  'get default values
                            Select Case rs("Condition").ToString
                                Case "STRING"
                                    vSqlContent += rs("TableKey") & "='" & rs("DefaultValue") & "',"
                                Case "NUMERIC"
                                    vSqlContent += rs("TableKey") & "=" & Val(rs("DefaultValue")) & ","
                                Case "DATE"
                                    vSqlContent += rs("TableKey") & "='" & Format(Now, "yyyy/MM/dd") & "',"
                            End Select
                        Else    'field is not required
                            Select Case rs("Condition").ToString
                                Case "STRING"
                                    vSqlContent += rs("TableKey") & "='" & _
                                        Trim(vFields(j).Replace("'", "").Replace(Chr(241), "n").Replace(Chr(209), "N")) & _
                                        "',"
                                Case "NUMERIC"
                                    If vFields(j) <> "" And IsNumeric(vFields(j)) Then
                                        vSqlContent += rs("TableKey") & "=" & Val(vFields(j)) & ","
                                    Else
                                        vSqlContent += rs("TableKey") & "=0,"
                                    End If
                                Case "DATE"
                                    If vFields(j) <> "" And IsDate(vFields(j)) Then
                                        vSqlContent += rs("TableKey") & "='" & Format(CDate(vFields(j)), "yyyy/MM/dd") & "',"
                                    Else
                                        vSqlContent += rs("TableKey") & "=null,"
                                    End If
                            End Select
                        End If
                    Else 'index was not found, use defaults
                        Select Case rs("Condition").ToString
                            Case "STRING"
                                If Not IsDBNull(rs("DefaultValue")) Then
                                    vSqlContent += rs("TableKey") & "='" & rs("DefaultValue") & "',"
                                Else
                                    vSqlContent += rs("TableKey") & "='',"
                                End If
                            Case "NUMERIC"
                                If Not IsDBNull(rs("DefaultValue")) Then
                                    vSqlContent += rs("TableKey") & "=" & Val(rs("DefaultValue")) & ","
                                Else
                                    vSqlContent += rs("TableKey") & "=0,"
                                End If
                            Case "DATE"
                                vSqlContent += rs("TableKey") & "='" & Format(Now, "yyyy/MM/dd") & "',"
                        End Select
                    End If
                Else
                    If rs("Required") = 1 Then
                        Select Case rs("Condition").ToString
                            Case "STRING"
                                vSqlContent += rs("TableKey") & "='" & rs("DefaultValue") & "',"
                            Case "NUMERIC"
                                vSqlContent += rs("TableKey") & "=" & Val(rs("DefaultValue")) & ","
                            Case "DATE"
                                vSqlContent += rs("TableKey") & "='" & Format(Now, "yyyy/MM/dd") & "',"
                        End Select
                    Else
                        Select Case rs("Condition").ToString
                            Case "STRING"
                                If Not IsDBNull(rs("DefaultValue")) Then
                                    vSqlContent += rs("TableKey") & "='" & rs("DefaultValue") & "',"
                                Else
                                    vSqlContent += rs("TableKey") & "='',"
                                End If
                            Case "NUMERIC"
                                If Not IsDBNull(rs("DefaultValue")) Then
                                    vSqlContent += rs("TableKey") & "=" & Val(rs("DefaultValue")) & ","
                                Else
                                    vSqlContent += rs("TableKey") & "=0,"
                                End If
                            Case "DATE"
                                vSqlContent += rs("TableKey") & "='" & Format(Now, "yyyy/MM/dd") & "',"
                        End Select
                    End If
                End If
            Loop
            rs.Close()
            vSqlContent = Mid(vSqlContent, 1, Len(vSqlContent) - 1)
            vSqlContent += " where Emp_Email='" & vFields(vIndex) & "'"
            cmRef.CommandText = vSqlContent
            Try
                cmRef.ExecuteNonQuery()
            Catch ex As Odbc.OdbcException
                'Response.Write(cmRef.CommandText & "<br/>")
                Exit Sub
            End Try
        Next

        'determine the status of each record
        cm.CommandText = "select * from import_emp_master"
        rs = cm.ExecuteReader
        Do While rs.Read
            cmXRef.CommandText = "select * from py_emp_master where Emp_Cd='" & _
                rs("Emp_Cd") & "'"
            rsXRef = cmXRef.ExecuteReader
            If rsXRef.HasRows Then
                rsXRef.Read()
                'compare each field if there are changes
                cmRef.CommandText = "select TableKey from _db where TempTable='wfh' and TableKey is not null"
                rsRef = cmRef.ExecuteReader
                vSw = False
                Do While rsRef.Read
                    If Not IsDBNull(rs(rsRef("TableKey"))) And _
                        Not IsDBNull(rsXRef(rsRef("TableKey"))) Then
                        If rs(rsRef("TableKey")) <> rsXRef(rsRef("TableKey")) Then  'field value was changed
                            vSw = True
                            Exit Do
                        End If
                    Else
                        If (IsDBNull(rs(rsRef("TableKey"))) And Not IsDBNull(rsXRef(rsRef("TableKey")))) Or _
                           (Not IsDBNull(rs(rsRef("TableKey"))) And IsDBNull(rsXRef(rsRef("TableKey")))) Then
                            vSw = True
                            Exit Do
                        End If
                    End If
                Loop
                rsRef.Close()
                If vSw Then
                    cmRef.CommandText = "update import_emp_master set Ecard='modified' where " & _
                        vLink & "='" & rs(vLink) & "'"
                Else
                    cmRef.CommandText = "update import_emp_master set Ecard='unchanged' where " & _
                        vLink & "='" & rs(vLink) & "'"
                End If
            Else
                cmRef.CommandText = "update import_emp_master set Ecard='new' where " & _
                    vLink & "='" & rs(vLink) & "'"
            End If
            rsXRef.Close()
            cmRef.ExecuteNonQuery()
        Loop
        rs.Close()
        c.Close()
        vScript = "document.getElementById('divWait').style.visibility='hidden'; " & _
            "alert('File successfully uploaded.'); window.close();"
       
        c.Dispose()
        cm.Dispose()
        cmRef.Dispose()
        cmXRef.Dispose()
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            vScript = "alert('Your login session has expired. Please re-login again.'); window.close();"
            Exit Sub
        End If
    End Sub
End Class
