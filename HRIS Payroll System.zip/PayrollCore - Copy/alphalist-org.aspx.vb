Imports denaro
Partial Class alphalist
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Dim c As New sqlclient.sqlConnection
    Dim cmSysCntrl As New sqlclient.sqlCommand
    Dim rsSysCntrl As sqlclient.sqlDataReader
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Session("returnaddr") = "massupdateincent.aspx"
            Server.Transfer("index.aspx")
        End If
        If Not IsPostBack Then 'now build the reference code
            'If Not CanRun(Session("caption"), Request.Item("id")) Then
            '    Session("denied") = "1"
            '    Server.Transfer("main.aspx")
            '    Exit Sub
            'End If
            lblCaption.Text = "13th Month,Bonus and Other Incentives Computation"
            BuildCombo("select AgencyCd,AgencyName from agency where AgencyCd in ('" & _
                Session("agencylist").ToString.Replace(",", "','") & "') order by AgencyName", cmbOfc)
            BuildCombo("select EmploymentType,Descr from hr_employment_type where EmploymentType in ('" & _
                Session("typelist").ToString.Replace(",", "','") & "') order by Descr", cmbSecurity)
            cmbOfc.Items.Add("All Office")
            cmbOfc.SelectedValue = "All Office"
            cmbSecurity.Items.Add("All")
            cmbSecurity.SelectedValue = "All"
            txtPeriod.Text = "12/31/" & Year(Now)
        End If
    End Sub
    Private Sub GetOfcInfo()
        Dim cm As New sqlclient.sqlcommand
        Dim rs As sqlclient.sqldatareader

        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c
        cm.CommandText = "select Tin,TaxBranchCd from glsyscntrl where AgencyCd='" & _
            cmbOfc.SelectedValue & "'"
        rs = cm.ExecuteReader
        If rs.Read Then
            txtTIN.Text = IIf(IsDBNull(rs("Tin")), "", rs("Tin"))
            txtBranchCd.Text = IIf(IsDBNull(rs("TaxBranchCd")), "", rs("TaxBranchCd"))
        Else
            vScript = "alert('Please define the company information first in " & _
                "System Parameters=>Company Information menu.');"
        End If
        rs.Close()

        cm.Dispose()
        c.Close()
    End Sub
    Protected Sub cmdReturn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.Click
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub cmbOfc_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbOfc.SelectedIndexChanged
        If cmbOfc.SelectedValue <> "All Office" Then
            GetOfcInfo()
        Else
            txtBranchCd.Text = ""
            txtTIN.Text = ""
        End If
    End Sub

    Protected Sub cmdRefresh_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdRefresh.Click
        If cmbOfc.SelectedValue <> "All Office" Then
            DataRefresh()
        Else
            vScript = "alert('You must first select a specific Office/Branch');"
        End If
    End Sub
    Private Sub DataRefresh()
        Dim da As sqlclient.sqlDataAdapter
        Dim ds As New DataSet
        Dim vSql As String = ""
        Dim vQry As String = ""

        If cmbReportType.SelectedValue <> "0" Then
            vQry = cmbReportType.SelectedValue
        End If

        c.ConnectionString = connStr
        vSql = "select * from 1604f where AgencyCd='" & cmbOfc.SelectedValue & _
            "' and ReturnPd='" & Format(CDate(txtPeriod.Text), "yyyy/MM/dd") & "' " & _
            vQry & " order by Sched_Num,SeqId"
        da = New sqlclient.sqlDataAdapter(vSql, c)
        da.Fill(ds, "1604")

        tbl1604.Datasource = ds.Tables("1604")
        tbl1604.DataBind()
        ds.Dispose()
        da.Dispose()
        If tbl1604.Rows.Count > 0 Then
            Dump()
            vScript = "document.getElementById(""divWait"").style.visibility = ""hidden"";"
        Else
            vScript = "alert('No records retrieved. Click the `Process Alphalist` button first.');"
        End If

    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        If cmbOfc.SelectedValue = "All Office" Then
            vScript = "alert('You must first select an Office/Branch');"
            Exit Sub
        End If

        Dim cm As New sqlclient.sqlCommand
        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c
        Try
            cm.CommandText = "update glsyscntrl set Tin='" & txtTIN.Text & _
                "',TaxBranchCd='" & txtBranchCd.Text & _
                "' where AgencyCd='" & cmbOfc.SelectedValue & "'"
            cm.ExecuteNonQuery()
        Catch ex As sqlclient.sqlException
            vScript = "alert('An error occurred while the system is trying to save the settings. " & _
                "Error code is: " & ex.Message.Replace("'", "") & "');"
            GoTo close
        End Try
        vScript = "alert('Changes were successfully saved');"
close:
        cm.Dispose()
        c.Close()
    End Sub
    Private Function GetNonTaxableSalary(ByVal pNonTaxIncentive As String, ByRef pRef As sqlclient.sqldatareader) As Decimal
        Dim vNTaxIncentive As String() = pNonTaxIncentive.Split(",")
        Dim vTot As Decimal = 0
        Dim iCtr As Integer
        Dim vIdx As Integer

        For iCtr = 0 To UBound(vNTaxIncentive)
            vIdx = GetNumber(vNTaxIncentive(iCtr))
            If vIdx <> 0 Then
                vTot = vTot + IIf(IsDBNull(pRef("Incent" & vIdx)), 0, pRef("Incent" & vIdx))
            End If
        Next iCtr
        GetNonTaxableSalary = vTot
    End Function
    Protected Sub cmdProcess_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdProcess.Click
        'validate each fields first
        If cmbOfc.SelectedValue = "All Office" Then
            vScript = "alert('You must first select an Office/Branch');"
            Exit Sub
        End If
        If Trim(txtTIN.Text) = "" Then
            vScript = "alert('Employers TIN should not be empty.');"
            Exit Sub
        End If
        If Trim(txtBranchCd.Text) = "" Then
            vScript = "alert('RDO code should not be empty.');"
            Exit Sub
        End If
        If txtTIN.Text.Length > 16 Then
            vScript = "alert('TIN should be less 16 characters.');"
            Exit Sub
        End If
        If txtBranchCd.Text.Length > 5 Then
            vScript = "alert('RDO code should be less than 6 characters.');"
            Exit Sub
        End If

        Dim cm As New sqlclient.sqlCommand
        Dim rs As sqlclient.sqlDataReader
        Dim vDump As String = ""
        Dim vNTaxIncentives As String
        Dim vTaxGroup() As Double
        Dim vIncentives() As String
        Dim iCtr As Integer

        c.ConnectionString = connStr
        c.Open()
        cmSysCntrl.Connection = c
        cm.Connection = c

        cmSysCntrl.CommandText = "select * from py_syscntrl"
        rsSysCntrl = cmSysCntrl.ExecuteReader
        rsSysCntrl.Read()

        'configure and group the taxable icentives
        'get list of nontax incentives first
        cm.CommandText = "select Incentive_Cd from py_other_incentvs where Taxable=0 and Declared<>0"
        rs = cm.ExecuteReader
        vNTaxIncentives = ""
        Do While rs.Read
            vNTaxIncentives += rs("Incentive_Cd") & ","
        Loop
        rs.Close()
        If vNTaxIncentives <> "" Then
            vNTaxIncentives = Mid(vNTaxIncentives, 1, Len(vNTaxIncentives) - 1)
        End If

        'get list of TAXABLE groups
        cm.CommandText = "select count(distinct MaxTaxExempt) from py_other_incentvs where Taxable <> 0 and " & _
           "MaxTaxExempt is not null and Grouped <> 0"
        rs = cm.ExecuteReader
        If rs.Read Then
            If Not IsDBNull(rs(0)) Then
                ReDim vTaxGroup(rs(0) - 1)
                ReDim vIncentives(rs(0) - 1)
            Else
                vScript = "alert('The system cannot continue because Exemption group is not defined.');"
                rsSysCntrl.Close()
                cmSysCntrl.Dispose()
                c.Close()
                Exit Sub
            End If
        End If
        rs.Close()
        cm.CommandText = "select distinct MaxTaxExempt from py_other_incentvs where Taxable <> 0 and " & _
                   "MaxTaxExempt is not null and Grouped <> 0"
        rs = cm.ExecuteReader
        iCtr = 0
        Do While rs.Read
            vTaxGroup(iCtr) = rs("MaxTaxExempt")
            iCtr += 1
        Loop
        rs.Close()

        'asSIGN LIST OF INCENTIVES FOR EACH GROUP
        For iCtr = 0 To UBound(vTaxGroup)
            cm.CommandText = "select Incentive_Cd from py_other_incentvs where Declared <> 0 and Taxable <> 0 and Grouped <> 0 " & _
               "and MaxTaxExempt=" & vTaxGroup(iCtr) & " order by Incentive_Cd"
            vIncentives(iCtr) = ""
            rs = cm.ExecuteReader
            Do While rs.Read
                vIncentives(iCtr) += rs("Incentive_Cd") & ","
            Loop
            rs.Close()
            If vIncentives(iCtr) <> "" Then
                vIncentives(iCtr) = Mid(vIncentives(iCtr), 1, Len(vIncentives(iCtr)) - 1)
            End If
        Next iCtr

        Dim vDateResign As String = "null"
        Dim cmExec As New sqlclient.sqlCommand
        Dim cmRef As New sqlclient.sqlCommand
        Dim rsRef As sqlclient.sqlDataReader
        Dim iSched(4) As Integer
        Dim iSeq As Integer
        Dim iGrp As Integer
        Dim iCount As Integer = 0
        Dim vStr As String
        Dim vDate As Date = CDate(txtPeriod.Text)
        Dim vTot As Double
        Dim vIdx As Integer
        Dim vTaxableAmt As Double
        Dim vSchedNum As String
        Dim vWithPrevEmployer As Boolean

        'VARIABLES NEEDED FOR 1604
        Dim vSubFiling As String
        Dim vPremium As Double
        Dim vCurrTaxableSalary As Double
        Dim vCurrTaxable13th As Double
        Dim vCurrTaxWithheld As Double
        Dim vCurrNTaxableSalary As Double
        Dim vCurrNTaxable13th As Double
        Dim vCurrMandatory As Double

        Dim vPrevTaxableSalary As Double
        Dim vPrevTaxable13th As Double
        Dim vPrevTaxWithheld As Double
        Dim vPrevNTaxableSalary As Double
        Dim vPrevNTaxable13th As Double
        Dim vPrevMandatory As Double

        Dim vOverUnder As Double
        Dim vTaxDue As Double
        Dim vExempt As Double
        Dim vTaxWithheldDec As Double

        cmRef.Connection = c
        cmExec.Connection = c

        'delete existing 1604f records
        cmExec.CommandText = "delete from 1604f where AgencyCd='" & cmbOfc.SelectedValue & _
            "' and ReturnPd='" & Format(vDate, "yyyy/MM/dd") & "'"
        cmExec.ExecuteNonQuery()

        'get list of employees for the year
        cm.CommandText = "select * from py_emp_master where Agency_Cd='" & cmbOfc.SelectedValue & _
            "' and (Date_Resign is null or " & _
            "(Date_Resign is not null and year(Date_Resign)=" & vDate.Year & _
            ")) order by Emp_Lname,Emp_Fname"
        iSeq = 1
        iSched(0) = 0 : iSched(1) = 0 : iSched(2) = 0 : iSched(3) = 0
        rs = cm.ExecuteReader
        Do While rs.Read
            'get tax exemption of employee
            cmRef.CommandText = "select Exemption from py_tax_ref where Tax_Cd='" & _
               rs("Tax_Cd") & "'"
            rsRef = cmRef.ExecuteReader
            vExempt = 0
            If rsRef.Read Then
                vExempt = IIf(IsDBNull(rsRef("Exemption")), 0, rsRef("Exemption"))
            End If
            rsRef.Close()
            'GET PREV EMPLOYER'S INCOME
            cmRef.CommandText = "select GrossTaxable,Tax13th,TaxWithHeld,GrossNonTax,NonTax13th,NonTaxSss" & _
               " from py_prev_employer_income where Emp_Cd='" & rs("Emp_Cd") & _
               "' and YearCd=" & vDate.Year
            rsRef = cmRef.ExecuteReader
            vWithPrevEmployer = False
            If rsRef.Read Then
                vWithPrevEmployer = True
                vPrevTaxableSalary = IIf(IsDBNull(rsRef("GrossTaxable")), 0, rsRef("GrossTaxable"))
                vPrevTaxable13th = IIf(IsDBNull(rsRef("Tax13th")), 0, rsRef("Tax13th"))
                vPrevTaxWithheld = IIf(IsDBNull(rsRef("TaxWithHeld")), 0, rsRef("TaxWithHeld"))
                vPrevNTaxableSalary = IIf(IsDBNull(rsRef("GrossNonTax")), 0, rsRef("GrossNonTax"))
                vPrevNTaxable13th = IIf(IsDBNull(rsRef("NonTax13th")), 0, rsRef("NonTax13th"))
                vPrevMandatory = IIf(IsDBNull(rsRef("NonTaxSss")), 0, rsRef("NonTaxSss"))
            Else
                vPrevTaxableSalary = 0
                vPrevTaxable13th = 0
                vPrevTaxWithheld = 0
                vPrevNTaxableSalary = 0
                vPrevNTaxable13th = 0
                vPrevMandatory = 0
            End If
            rsRef.Close()

            'settings for locales/branches that is treated as different company
            'check if employee has payroll from other locale
            '''' the following code is used only for victoria court use wherein the branch is considered
            '''' as another type of company 
            'cmRef.CommandText = "select count(*) from py_report where Emp_Cd='" & rs("Emp_Cd") & _
            '    "' and Agency_Cd<>'" & rs("Agency_Cd") & "' and year(PayDate)=" & vDate.Year
            'rsRef = cmRef.ExecuteReader
            'iCount = 0
            'If rsRef.Read Then
            '    iCount = IIf(IsDBNull(rsRef(0)), 0, rsRef(0))
            'End If
            'rsRef.Close()
            'If iCount > 0 Then 'has income from previous locale, set as previous employer income
            '    vWithPrevEmployer = True
            '    cmRef.CommandText = "select sum(Month_Rate) as Gross, sum(Absent+Tardiness) as Absents," & _
            '       "sum(Ot) as OtTotal, sum(0) as Transpo,sum(Aca+Pera) as Fnd,sum(G1+G2+G3) as OfcOt," & _
            '       "sum(MealAllow) as Meal,sum(Other_Incent1) as Incent1, sum(Other_Incent2) as Incent2," & _
            '       "sum(Other_Incent3) as Incent3, sum(Other_Incent4) as Incent4," & _
            '       "sum(Other_Incent5) as Incent5, sum(Other_Incent6) as Incent6," & _
            '       "sum(Other_Incent7) as Incent7, sum(Other_Incent8) as Incent8," & _
            '       "sum(Other_Incent9) as Incent9, sum(Other_Incent10) as Incent10," & _
            '       "sum(Other_Incent11) as Incent11, sum(Other_Incent12) as Incent12," & _
            '       "sum(Other_Incent13) as Incent13, sum(Other_Incent14) as Incent14," & _
            '       "sum(Other_Incent15) as Incent15, sum(Other_Incent16) as Incent16," & _
            '       "sum(Other_Incent17) as Incent17, sum(Other_Incent18) as Incent18," & _
            '       "sum(Other_Incent19) as Incent19, sum(Other_Incent20) as Incent20," & _
            '       "sum(Other_Incent21) as Incent21, sum(Other_Incent22) as Incent22," & _
            '       "sum(Other_Incent23) as Incent23, sum(Other_Incent24) as Incent24," & _
            '       "sum(Other_Incent25) as Incent25, sum(Other_Incent26) as Incent26," & _
            '       "sum(Other_Incent27) as Incent27, sum(Other_Incent28) as Incent28," & _
            '       "sum(Other_Incent29) as Incent29, sum(Other_Incent30) as Incent30," & _
            '       "sum(Other_Incent31) as Incent31, sum(Other_Incent32) as Incent32," & _
            '       "sum(Other_Incent33) as Intent33, sum(Other_Incent34) as Incent34," & _
            '       "sum(Other_Incent35) as Intent35, sum(Other_Incent36) as Incent36," & _
            '       "sum(Other_Incent37) as Intent37, sum(Other_Incent38) as Incent38," & _
            '       "sum(Other_Incent39) as Intent39, sum(Other_Incent40) as Incent40," & _
            '       "sum(Other_Incent41) as Intent41, sum(Other_Incent42) as Incent42," & _
            '       "sum(Other_Incent43) as Intent43, sum(Other_Incent44) as Incent44," & _
            '       "sum(Other_Incent45) as Intent45, sum(Other_Incent46) as Incent46," & _
            '       "sum(Other_Incent47) as Intent47, sum(Other_Incent48) as Incent48," & _
            '       "sum(Other_Incent49) as Intent49, sum(Other_Incent50) as Incent50," & _
            '       "sum(Other_Incent51) as Intent51, sum(Other_Incent52) as Incent52," & _
            '       "sum(Other_Incent53) as Intent53, sum(Other_Incent54) as Incent54," & _
            '       "sum(Other_Incent55) as Intent55, sum(Other_Incent56) as Incent56," & _
            '       "sum(Other_Incent57) as Intent57, sum(Other_Incent58) as Incent58," & _
            '       "sum(Other_Incent59) as Intent59, sum(Other_Incent60) as Incent60," & _
            '       "sum(With_Tax) as WithTax, sum(Sss_Per) as SssEmp,  " & _
            '       "sum(PagIbig_Per) as PagIbigEmp,sum(Medicare_Per) as MedEmp " & _
            '       "from py_report where year(PayDate)=" & vDate.Year & " and Emp_Cd='" & _
            '       rs("Emp_Cd") & "' and Agency_Cd<>'" & rs("Agency_Cd") & "'"
            '    rsRef = cmRef.ExecuteReader
            '    If rsRef.Read Then
            '        vPrevTaxableSalary += IIf(IsDBNull(rsRef("Gross")), 0, rsRef("Gross")) + _
            '           IIf(IsDBNull(rsRef("Absents")), 0, rsRef("Absents")) + _
            '           IIf(IsDBNull(rsRef("Transpo")), 0, rsRef("Transpo")) + _
            '           IIf(IsDBNull(rsRef("Fnd")), 0, rsRef("Fnd")) + _
            '           IIf(IsDBNull(rsRef("OtTotal")), 0, rsRef("OtTotal")) - _
            '           IIf(IsDBNull(rsRef("OfcOt")), 0, rsRef("OfcOt"))
            '        vPrevTaxWithheld += IIf(IsDBNull(rsRef("WithTax")), 0, rsRef("WithTax"))
            '        vPrevNTaxableSalary += GetNonTaxableSalary(vNTaxIncentives, rsRef)
            '        'vPrevNTaxableSalary += IIf(IsDBNull(rsRef("Meal")), 0, rsRef("Meal"))
            '        vPrevMandatory += IIf(IsDBNull(rsRef("SssEmp")), 0, rsRef("SssEmp")) + _
            '            IIf(IsDBNull(rsRef("PagIbigEmp")), 0, rsRef("PagIbigEmp")) + _
            '            IIf(IsDBNull(rsRef("MedEmp")), 0, rsRef("MedEmp"))
            '        'GET TAXABLE INCOME BY GROUP
            '        Dim vIncent As String()
            '        vCurrTaxable13th = 0
            '        vCurrNTaxable13th = 0
            '        For iGrp = 0 To UBound(vTaxGroup)
            '            vTot = 0
            '            vIncent = vIncentives(iGrp).Split(",")
            '            For iCtr = 0 To UBound(vIncent)
            '                vIdx = GetNumber(vIncent(iCtr))
            '                If vIdx <> 0 Then
            '                    vTot += IIf(IsDBNull(rsRef("Incent" & vIdx)), 0, rsRef("Incent" & vIdx))
            '                End If
            '            Next iCtr
            '            If vTaxGroup(iGrp) <> 30000 Then 'INCLUDE TO TAXABLE SALARY
            '                vPrevTaxableSalary += vTot
            '            Else  'TAXGROUP IS 30000   (THIS IS 13TH MONTH AND OTHER BENEFITS)
            '                If vTot - vTaxGroup(iGrp) < 0 Then
            '                    vPrevNTaxable13th += vTot
            '                    'vCurrTaxable13th = 0
            '                Else
            '                    vPrevNTaxable13th += vTaxGroup(iGrp)
            '                    vPrevTaxable13th += (vTot - vTaxGroup(iGrp))
            '                End If
            '            End If
            '        Next iGrp
            '    End If
            '    rsRef.Close()
            'End If

            'GET DECEMBER TAXWITHHELD
            cmRef.CommandText = "select sum(With_Tax) as TaxDec from py_report where Emp_Cd='" & _
               rs("Emp_Cd") & "' and month(PayDate)=12 and year(PayDate)=" & vDate.Year & _
               " and Agency_Cd='" & rs("Agency_Cd") & "'"
            rsRef = cmRef.ExecuteReader
            vTaxWithheldDec = 0
            If rsRef.Read Then
                vTaxWithheldDec = IIf(IsDBNull(rsRef("TaxDec")), 0, rsRef("TaxDec"))
            End If
            rsRef.Close()

            'get health premiums exemptions
            cmRef.CommandText = "select sum(Amount) as Amt from py_other_premiums where Emp_Id='" & _
                rs("Emp_Cd") & "'"
            rsRef = cmRef.ExecuteReader
            vPremium = 0
            If rsRef.Read Then
                vPremium = IIf(IsDBNull(rsRef("Amt")), 0, rsRef("Amt"))
            End If
            rsRef.Close()

            'GET CURRENT INCOME
            cmRef.CommandText = "select sum(Month_Rate) as Gross, sum(Absent+Tardiness) as Absents," & _
               "sum(Ot) as OtTotal, sum(0) as Transpo,sum(Aca+Pera) as Fnd,sum(G1+G2+G3) as OfcOt," & _
               "sum(MealAllow) as Meal,sum(Other_Incent1) as Incent1, sum(Other_Incent2) as Incent2," & _
               "sum(Other_Incent3) as Incent3, sum(Other_Incent4) as Incent4," & _
               "sum(Other_Incent5) as Incent5, sum(Other_Incent6) as Incent6," & _
               "sum(Other_Incent7) as Incent7, sum(Other_Incent8) as Incent8," & _
               "sum(Other_Incent9) as Incent9, sum(Other_Incent10) as Incent10," & _
               "sum(Other_Incent11) as Incent11, sum(Other_Incent12) as Incent12," & _
               "sum(Other_Incent13) as Incent13, sum(Other_Incent14) as Incent14," & _
               "sum(Other_Incent15) as Incent15, sum(Other_Incent16) as Incent16," & _
               "sum(Other_Incent17) as Incent17, sum(Other_Incent18) as Incent18," & _
               "sum(Other_Incent19) as Incent19, sum(Other_Incent20) as Incent20," & _
               "sum(Other_Incent21) as Incent21, sum(Other_Incent22) as Incent22," & _
               "sum(Other_Incent23) as Incent23, sum(Other_Incent24) as Incent24," & _
               "sum(Other_Incent25) as Incent25, sum(Other_Incent26) as Incent26," & _
               "sum(Other_Incent27) as Incent27, sum(Other_Incent28) as Incent28," & _
               "sum(Other_Incent29) as Incent29, sum(Other_Incent30) as Incent30," & _
               "sum(Other_Incent31) as Incent31, sum(Other_Incent32) as Incent32," & _
               "sum(Other_Incent33) as Intent33, sum(Other_Incent34) as Incent34," & _
               "sum(Other_Incent35) as Intent35, sum(Other_Incent36) as Incent36," & _
               "sum(Other_Incent37) as Intent37, sum(Other_Incent38) as Incent38," & _
               "sum(Other_Incent39) as Intent39, sum(Other_Incent40) as Incent40," & _
               "sum(Other_Incent41) as Intent41, sum(Other_Incent42) as Incent42," & _
               "sum(Other_Incent43) as Intent43, sum(Other_Incent44) as Incent44," & _
               "sum(Other_Incent45) as Intent45, sum(Other_Incent46) as Incent46," & _
               "sum(Other_Incent47) as Intent47, sum(Other_Incent48) as Incent48," & _
               "sum(Other_Incent49) as Intent49, sum(Other_Incent50) as Incent50," & _
               "sum(Other_Incent51) as Intent51, sum(Other_Incent52) as Incent52," & _
               "sum(Other_Incent53) as Intent53, sum(Other_Incent54) as Incent54," & _
               "sum(Other_Incent55) as Intent55, sum(Other_Incent56) as Incent56," & _
               "sum(Other_Incent57) as Intent57, sum(Other_Incent58) as Incent58," & _
               "sum(Other_Incent59) as Intent59, sum(Other_Incent60) as Incent60," & _
               "sum(With_Tax) as WithTax, sum(Sss_Per) as SssEmp,  " & _
               "sum(PagIbig_Per) as PagIbigEmp,sum(Medicare_Per) as MedEmp " & _
               "from py_report where year(PayDate)=" & vDate.Year & " and Emp_Cd='" & _
               rs("Emp_Cd") & "' and Agency_Cd='" & rs("Agency_Cd") & "'"
            rsRef = cmRef.ExecuteReader
            If rsRef.Read Then
                vCurrTaxableSalary = IIf(IsDBNull(rsRef("Gross")), 0, rsRef("Gross")) + _
                   IIf(IsDBNull(rsRef("Absents")), 0, rsRef("Absents")) + _
                   IIf(IsDBNull(rsRef("Transpo")), 0, rsRef("Transpo")) + _
                   IIf(IsDBNull(rsRef("Fnd")), 0, rsRef("Fnd")) + _
                   IIf(IsDBNull(rsRef("OtTotal")), 0, rsRef("OtTotal")) - _
                   IIf(IsDBNull(rsRef("OfcOt")), 0, rsRef("OfcOt"))
                vCurrTaxWithheld = IIf(IsDBNull(rsRef("WithTax")), 0, rsRef("WithTax")) - vTaxWithheldDec
                vCurrMandatory = IIf(IsDBNull(rsRef("SssEmp")), 0, rsRef("SssEmp")) + _
                   IIf(IsDBNull(rsRef("PagibigEmp")), 0, rsRef("PagibigEmp")) + _
                   IIf(IsDBNull(rsRef("MedEmp")), 0, rsRef("MedEmp"))

                'GET NONTAXABLE SALARIES
                vCurrNTaxableSalary = GetNonTaxableSalary(vNTaxIncentives, rsRef)
                'vCurrNTaxableSalary += IIf(IsDBNull(rsRef("Meal")), 0, rsRef("Meal"))
                'GET TAXABLE INCOME BY GROUP
                Dim vIncent As String()
                vCurrTaxable13th = 0
                vCurrNTaxable13th = 0
                For iGrp = 0 To UBound(vTaxGroup)
                    vTot = 0
                    vIncent = vIncentives(iGrp).Split(",")
                    For iCtr = 0 To UBound(vIncent)
                        vIdx = GetNumber(vIncent(iCtr))
                        If vIdx <> 0 Then
                            vTot = vTot + IIf(IsDBNull(rsRef("Incent" & vIdx)), 0, rsRef("Incent" & vIdx))
                        End If
                    Next iCtr
                    If vTaxGroup(iGrp) <> 30000 Then 'INCLUDE TO TAXABLE SALARY
                        vCurrTaxableSalary += vTot
                    Else  'TAXGROUP IS 30000   (THIS IS 13TH MONTH AND OTHER BENEFITS)
                        If vTot - vTaxGroup(iGrp) < 0 Then
                            vCurrNTaxable13th = vTot
                            vCurrTaxable13th = 0
                        Else
                            vCurrNTaxable13th = vTaxGroup(iGrp)
                            vCurrTaxable13th = vTot - vTaxGroup(iGrp)
                        End If
                    End If
                Next iGrp
            End If
            rsRef.Close()

            'GET TAXDUE BasED ON ANNUAL TAX
            vTaxableAmt = vCurrTaxableSalary + vCurrTaxable13th + vPrevTaxableSalary + _
               vPrevTaxable13th - vCurrMandatory - vPrevMandatory - vExempt - vPremium

            'GET TAX TABLE BasED ON GROSS AND ANNUAL TAX
            vStr = "select * from py_tax_table where Freq_Cd = 'ANNUAL' " & _
                 "and Tax_Cd='ANNUAL' and " & vTaxableAmt & " >= Check_Amt order by Check_Amt desc"

            cmRef.CommandText = vStr
            rsRef = cmRef.ExecuteReader
            If rsRef.Read Then
                vTaxDue = rsRef("Add_Amt") + (rsRef("Factor") * (vTaxableAmt - rsRef("Check_Amt")))
            Else  'NEGATIVE
                vTaxDue = 0
            End If
            rsRef.Close()

            vOverUnder = vTaxDue - (vCurrTaxWithheld + vTaxWithheldDec + vPrevTaxWithheld)

            'get schedule number
            iCtr = 0
            vSubFiling = ""
            If Not IsDBNull(rs("Date_Resign")) Then     'employee is resigned
                vSchedNum = "D7.1"
                vSubFiling = "N"
                iSched(1) = iSched(1) + 1
                iCtr = iSched(1)
            Else    'employee is active
                If vTaxDue = 0 Then 'no tax due
                    vSchedNum = "D7.2"
                    iSched(2) = iSched(2) + 1
                    iCtr = iSched(2)
                Else    'with tax due payable or refund
                    If vWithPrevEmployer Then   'with previous employer
                        vSchedNum = "D7.4"
                        iSched(4) = iSched(4) + 1
                        iCtr = iSched(4)
                    Else  'without previous employer
                        vSchedNum = "D7.3"
                        vSubFiling = "N"
                        iSched(3) = iSched(3) + 1
                        iCtr = iSched(3)
                    End If
                End If
            End If

            'clean records first
            cmExec.CommandText = "delete from 1604f where Emp_Cd='" & rs("Emp_Cd") & "'"
            cmExec.ExecuteNonQuery()

            'NOW SAVE EVERYTHING IN THE 1604F TABLE
            vDateResign = "null"
            If Not IsDBNull(rs("Date_Resign")) Then
                vDateResign = "'" & Format(CDate(rs("Date_Resign")), "yyyy/MM/dd") & "'"
            End If

            cmExec.CommandText = "insert into 1604f (Ftype_Cd,Tin_Emr,BranchCd_Emr,ReturnPd,Sched_Num,SeqId," & _
               "Fname,Lname,Mname,Tin_Emp,BranchCd_Emp,DateHired,DateResigned,Actual_Withheld," & _
               "Salaries_Tax,OtherIncent_Tax,TaxWithheld,Salaries_NonTax,OtherIncent_NonTax," & _
               "Prev_Taxable_Salaries,Prev_Taxable_13th_Month,Prev_Tax_Withheld,Prev_NonTax_Salaries," & _
               "Prev_NonTax_13th_Month,Mandatory,Prev_NonTax_Sss,Variance,TaxWithheld_Dec," & _
               "Exemption,TaxDue,Emp_Cd,AgencyCd,Premiums,Tax_Cd,Subs_Filing) values ('1604CF','" & txtTIN.Text & "','" & txtBranchCd.Text & _
               "','" & Format(vDate, "yyyy/MM/dd") & "','" & vSchedNum & "'," & iCtr & ",'" & rs("Emp_Fname") & _
               "','" & rs("Emp_Lname") & "','" & rs("Emp_Mname") & "','" & rs("Tin") & _
               "','" & txtBranchCd.Text & "','" & Format(CDate(rs("Start_Date")), "yyyy/MM/dd") & "'," & _
               vDateResign & "," & Math.Round(vCurrTaxWithheld + vTaxWithheldDec + vPrevTaxWithheld, 2) & "," & _
               Math.Round(vCurrTaxableSalary - vCurrMandatory, 2) & "," & Math.Round(vCurrTaxable13th, 2) & "," & _
               Math.Round(vCurrTaxWithheld, 2) & "," & Math.Round(vCurrNTaxableSalary, 2) & "," & _
               Math.Round(vCurrNTaxable13th, 2) & "," & Math.Round(vPrevTaxableSalary - vPrevMandatory, 2) & "," & _
               Math.Round(vPrevTaxable13th, 2) & "," & Math.Round(vPrevTaxWithheld, 2) & "," & _
               Math.Round(vPrevNTaxableSalary, 2) & "," & Math.Round(vPrevNTaxable13th, 2) & "," & _
               Math.Round(vCurrMandatory, 2) & "," & Math.Round(vPrevMandatory, 2) & "," & _
               Math.Round(vOverUnder, 2) & "," & Math.Round(vTaxWithheldDec, 2) & "," & _
               Math.Round(vExempt, 2) & "," & Math.Round(vTaxDue, 2) & ",'" & rs("Emp_Cd") & "','" & _
               cmbOfc.SelectedValue & "'," & vPremium & ",'" & rs("Tax_Cd") & "','" & vSubFiling & "')"

            cmExec.ExecuteNonQuery()
            iSeq = iSeq + 1
        Loop
        rs.Close()

        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        ''''''''''''       now get employees who are moved to different locale during the year '''''''''
        ''''''''''''      THIS CODE WAS INSERTED FOR VICTORIA COURT POLICY ONLY!               '''''''''
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        'get list of employees for the year
        'cm.CommandText = "select Emp_Cd,Emp_Lname,Emp_Fname,Emp_Mname,Tax_Cd,Start_Date,Tin " & _
        '    "from py_emp_master where Emp_Cd in (" & _
        '    "select distinct Emp_Cd from py_report where Agency_Cd='" & cmbOfc.SelectedValue & _
        '    "' and year(PayDate)=" & vDate.Year & " and Emp_Cd not in " & _
        '    "(select Emp_Cd from py_emp_master where Agency_Cd='" & cmbOfc.SelectedValue & _
        '    "')) order by Emp_Lname,Emp_Fname,Emp_Mname"

        'iSeq = 1
        'rs = cm.ExecuteReader
        'Do While rs.Read
        '    'get last payroll date
        '    cmRef.CommandText = "select ToDate from py_report where Agency_Cd='" & cmbOfc.SelectedValue & _
        '        "' and year(PayDate)=" & vDate.Year & " and Emp_Cd='" & rs("Emp_Cd") & _
        '        "' order by PayDate desc limit 1"
        '    rsRef = cmRef.ExecuteReader
        '    vDateResign = "null"
        '    If rsRef.Read Then
        '        vDateResign = "'" & Format(CDate(rsRef("ToDate")), "yyyy/MM/dd") & "'"
        '    End If
        '    rsRef.Close()

        '    'get tax exemption of employee
        '    cmRef.CommandText = "select Exemption from py_tax_ref where Tax_Cd='" & _
        '       rs("Tax_Cd") & "'"
        '    rsRef = cmRef.ExecuteReader
        '    vExempt = 0
        '    If rsRef.Read Then
        '        vExempt = IIf(IsDBNull(rsRef("Exemption")), 0, rsRef("Exemption"))
        '    End If
        '    rsRef.Close()
        '    'GET PREV EMPLOYER'S INCOME
        '    cmRef.CommandText = "select GrossTaxable,Tax13th,TaxWithHeld,GrossNonTax,NonTax13th,NonTaxSss" & _
        '       " from py_prev_employer_income where Emp_Cd='" & rs("Emp_Cd") & _
        '       "' and YearCd=" & vDate.Year
        '    rsRef = cmRef.ExecuteReader
        '    vWithPrevEmployer = False
        '    If rsRef.Read Then
        '        vWithPrevEmployer = True
        '        vPrevTaxableSalary = IIf(IsDBNull(rsRef("GrossTaxable")), 0, rsRef("GrossTaxable"))
        '        vPrevTaxable13th = IIf(IsDBNull(rsRef("Tax13th")), 0, rsRef("Tax13th"))
        '        vPrevTaxWithheld = IIf(IsDBNull(rsRef("TaxWithHeld")), 0, rsRef("TaxWithHeld"))
        '        vPrevNTaxableSalary = IIf(IsDBNull(rsRef("GrossNonTax")), 0, rsRef("GrossNonTax"))
        '        vPrevNTaxable13th = IIf(IsDBNull(rsRef("NonTax13th")), 0, rsRef("NonTax13th"))
        '        vPrevMandatory = IIf(IsDBNull(rsRef("NonTaxSss")), 0, rsRef("NonTaxSss"))
        '    Else
        '        vPrevTaxableSalary = 0
        '        vPrevTaxable13th = 0
        '        vPrevTaxWithheld = 0
        '        vPrevNTaxableSalary = 0
        '        vPrevNTaxable13th = 0
        '        vPrevMandatory = 0
        '    End If
        '    rsRef.Close()

        '    vTaxWithheldDec = 0

        '    'GET CURRENT INCOME
        '    cmRef.CommandText = "select sum(Month_Rate) as Gross, sum(Absent+Tardiness) as Absents," & _
        '       "sum(Ot) as OtTotal, sum(0) as Transpo,sum(Aca+Pera) as Fnd,sum(G1+G2+G3) as OfcOt," & _
        '       "sum(Other_Incent1) as Incent1, sum(Other_Incent2) as Incent2," & _
        '       "sum(Other_Incent3) as Incent3, sum(Other_Incent4) as Incent4," & _
        '       "sum(Other_Incent5) as Incent5, sum(Other_Incent6) as Incent6," & _
        '       "sum(Other_Incent7) as Incent7, sum(Other_Incent8) as Incent8," & _
        '       "sum(Other_Incent9) as Incent9, sum(Other_Incent10) as Incent10," & _
        '       "sum(Other_Incent11) as Incent11, sum(Other_Incent12) as Incent12," & _
        '       "sum(Other_Incent13) as Incent13, sum(Other_Incent14) as Incent14," & _
        '       "sum(Other_Incent15) as Incent15, sum(Other_Incent16) as Incent16," & _
        '       "sum(Other_Incent17) as Incent17, sum(Other_Incent18) as Incent18," & _
        '       "sum(Other_Incent19) as Incent19, sum(Other_Incent20) as Incent20," & _
        '       "sum(Other_Incent21) as Incent21, sum(Other_Incent22) as Incent22," & _
        '       "sum(Other_Incent23) as Incent23, sum(Other_Incent24) as Incent24," & _
        '       "sum(Other_Incent25) as Incent25, sum(Other_Incent26) as Incent26," & _
        '       "sum(Other_Incent27) as Incent27, sum(Other_Incent28) as Incent28," & _
        '       "sum(Other_Incent29) as Incent29, sum(Other_Incent30) as Incent30," & _
        '       "sum(Other_Incent31) as Incent31, sum(Other_Incent32) as Incent32," & _
        '       "sum(Other_Incent33) as Intent33, sum(Other_Incent34) as Incent34," & _
        '       "sum(Other_Incent35) as Intent35, sum(Other_Incent36) as Incent36," & _
        '       "sum(Other_Incent37) as Intent37, sum(Other_Incent38) as Incent38," & _
        '       "sum(Other_Incent39) as Intent39, sum(Other_Incent40) as Incent40," & _
        '       "sum(Other_Incent41) as Intent41, sum(Other_Incent42) as Incent42," & _
        '       "sum(Other_Incent43) as Intent43, sum(Other_Incent44) as Incent44," & _
        '       "sum(Other_Incent45) as Intent45, sum(Other_Incent46) as Incent46," & _
        '       "sum(Other_Incent47) as Intent47, sum(Other_Incent48) as Incent48," & _
        '       "sum(Other_Incent49) as Intent49, sum(Other_Incent50) as Incent50," & _
        '       "sum(Other_Incent51) as Intent51, sum(Other_Incent52) as Incent52," & _
        '       "sum(Other_Incent53) as Intent53, sum(Other_Incent54) as Incent54," & _
        '       "sum(Other_Incent55) as Intent55, sum(Other_Incent56) as Incent56," & _
        '       "sum(Other_Incent57) as Intent57, sum(Other_Incent58) as Incent58," & _
        '       "sum(Other_Incent59) as Intent59, sum(Other_Incent60) as Incent60," & _
        '       "sum(With_Tax) as WithTax, sum(Sss_Per) as SssEmp,  " & _
        '       "sum(PagIbig_Per) as PagIbigEmp,sum(Medicare_Per) as MedEmp " & _
        '       "from py_report where Agency_Cd='" & cmbOfc.SelectedValue & _
        '       "' and year(PayDate)=" & vDate.Year & " and Emp_Cd='" & rs("Emp_Cd") & "'"

        '    rsRef = cmRef.ExecuteReader
        '    If rsRef.Read Then
        '        vCurrTaxableSalary = IIf(IsDBNull(rsRef("Gross")), 0, rsRef("Gross")) + _
        '           IIf(IsDBNull(rsRef("Absents")), 0, rsRef("Absents")) + _
        '           IIf(IsDBNull(rsRef("Transpo")), 0, rsRef("Transpo")) + _
        '           IIf(IsDBNull(rsRef("Fnd")), 0, rsRef("Fnd")) + _
        '           IIf(IsDBNull(rsRef("OtTotal")), 0, rsRef("OtTotal")) - _
        '           IIf(IsDBNull(rsRef("OfcOt")), 0, rsRef("OfcOt"))
        '        vCurrTaxWithheld = IIf(IsDBNull(rsRef("WithTax")), 0, rsRef("WithTax")) - vTaxWithheldDec
        '        vCurrMandatory = IIf(IsDBNull(rsRef("SssEmp")), 0, rsRef("SssEmp")) + _
        '           IIf(IsDBNull(rsRef("PagibigEmp")), 0, rsRef("PagibigEmp")) + _
        '           IIf(IsDBNull(rsRef("MedEmp")), 0, rsRef("MedEmp"))

        '        'GET NONTAXABLE SALARIES
        '        vCurrNTaxableSalary = GetNonTaxableSalary(vNTaxIncentives, rsRef)

        '        'GET TAXABLE INCOME BY GROUP
        '        Dim vIncent As String()
        '        vCurrTaxable13th = 0
        '        vCurrNTaxable13th = 0
        '        For iGrp = 0 To UBound(vTaxGroup)
        '            vTot = 0
        '            vIncent = vIncentives(iGrp).Split(",")
        '            For iCtr = 0 To UBound(vIncent)
        '                vIdx = GetNumber(vIncent(iCtr))
        '                If vIdx <> 0 Then
        '                    vTot = vTot + IIf(IsDBNull(rsRef("Incent" & vIdx)), 0, rsRef("Incent" & vIdx))
        '                End If
        '            Next iCtr
        '            If vTaxGroup(iGrp) <> 30000 Then 'INCLUDE TO TAXABLE SALARY
        '                vCurrTaxable13th += vTot
        '            Else  'TAXGROUP IS 30000   (THIS IS 13TH MONTH AND OTHER BENEFITS)
        '                If vTot - vTaxGroup(iGrp) < 0 Then
        '                    vCurrNTaxable13th = vTot
        '                    vCurrTaxable13th = 0
        '                Else
        '                    vCurrNTaxable13th = vTaxGroup(iGrp)
        '                    vCurrTaxable13th = vTot - vTaxGroup(iGrp)
        '                End If
        '            End If
        '        Next iGrp
        '    End If
        '    rsRef.Close()

        '    'GET TAXDUE BasED ON ANNUAL TAX
        '    vTaxableAmt = vCurrTaxableSalary + vCurrTaxable13th + vPrevTaxableSalary + _
        '       vPrevTaxable13th - vCurrMandatory - vPrevMandatory - vExempt - vPremium

        '    'GET TAX TABLE BasED ON GROSS AND ANNUAL TAX
        '    vStr = "select * from py_tax_table where Freq_Cd = 'ANNUAL' " & _
        '         "and Tax_Cd='ANNUAL' and " & vTaxableAmt & " >= Check_Amt order by Check_Amt desc"

        '    cmRef.CommandText = vStr
        '    rsRef = cmRef.ExecuteReader
        '    If rsRef.Read Then
        '        vTaxDue = rsRef("Add_Amt") + (rsRef("Factor") * (vTaxableAmt - rsRef("Check_Amt")))
        '    Else  'NEGATIVE
        '        vTaxDue = 0
        '    End If
        '    rsRef.Close()

        '    vOverUnder = vTaxDue - (vCurrTaxWithheld + vTaxWithheldDec + vPrevTaxWithheld)

        '    'set schedule number
        '    vSchedNum = "D7.1"
        '    iSched(1) += 1
        '    iCtr = iSched(1)

        '    'NOW SAVE EVERYTHING IN THE 1604F TABLE
        '    cmExec.CommandText = "insert into 1604f (Ftype_Cd,Tin_Emr,BranchCd_Emr,ReturnPd,Sched_Num,SeqId," & _
        '       "Fname,Lname,Mname,Tin_Emp,BranchCd_Emp,DateHired,DateResigned,Actual_Withheld," & _
        '       "Salaries_Tax,OtherIncent_Tax,TaxWithheld,Salaries_NonTax,OtherIncent_NonTax," & _
        '       "Prev_Taxable_Salaries,Prev_Taxable_13th_Month,Prev_Tax_Withheld,Prev_NonTax_Salaries," & _
        '       "Prev_NonTax_13th_Month,Mandatory,Prev_NonTax_Sss,Variance,TaxWithheld_Dec," & _
        '       "Exemption,TaxDue,Emp_Cd,AgencyCd,Premiums) values ('1604CF','" & txtTIN.Text & "','" & txtBranchCd.Text & _
        '       "','" & Format(vDate, "yyyy/MM/dd") & "','" & vSchedNum & "'," & iCtr & ",'" & rs("Emp_Fname") & _
        '       "','" & rs("Emp_Lname") & "','" & rs("Emp_Mname") & "','" & rs("Tin") & _
        '       "','" & txtBranchCd.Text & "','" & Format(CDate(rs("Start_Date")), "yyyy/MM/dd") & "'," & _
        '       vDateResign & "," & Math.Round(vCurrTaxWithheld + vTaxWithheldDec + vPrevTaxWithheld, 2) & "," & _
        '       Math.Round(vCurrTaxableSalary - vCurrMandatory, 2) & "," & Math.Round(vCurrTaxable13th, 2) & "," & _
        '       Math.Round(vCurrTaxWithheld, 2) & "," & Math.Round(vCurrNTaxableSalary, 2) & "," & _
        '       Math.Round(vCurrNTaxable13th, 2) & "," & Math.Round(vPrevTaxableSalary - vPrevMandatory, 2) & "," & _
        '       Math.Round(vPrevTaxable13th, 2) & "," & Math.Round(vPrevTaxWithheld, 2) & "," & _
        '       Math.Round(vPrevNTaxableSalary, 2) & "," & Math.Round(vPrevNTaxable13th, 2) & "," & _
        '       Math.Round(vCurrMandatory, 2) & "," & Math.Round(vPrevMandatory, 2) & "," & _
        '       Math.Round(vOverUnder, 2) & "," & Math.Round(vTaxWithheldDec, 2) & "," & _
        '       Math.Round(vExempt, 2) & "," & Math.Round(vTaxDue, 2) & ",'" & rs("Emp_Cd") & "','" & _
        '       cmbOfc.SelectedValue & "'," & vPremium & ")"

        '    cmExec.ExecuteNonQuery()
        '    iSeq = iSeq + 1
        'Loop
        'rs.Close()


        vScript = "alert('Process complete!'); document.getElementById('divWait').style.visibility='hidden';"
        '''''''''''' close connections
        rsSysCntrl.Close()
        cmSysCntrl.Dispose()
        cm.Dispose()
        cmExec.Dispose()
        cmRef.Dispose()
        c.Close()
        DataRefresh()
    End Sub

    Private Function GetNumber(ByVal pIncentive As String) As Integer
        Dim iCtr As Integer
        For iCtr = 1 To 30
            If rsSysCntrl("OthIncent" & iCtr & "Cd") = pIncentive Then
                GetNumber = iCtr
                Exit For
            End If
        Next iCtr
    End Function

    Protected Sub cmbReportType_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbReportType.SelectedIndexChanged
        DataRefresh()
    End Sub
    Private Sub Dump()
        Dim cm As New sqlclient.sqlcommand
        Dim rs As sqlclient.sqldatareader
        Dim vDump As String = ""
        Dim vDateResign As String = ""

        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c
        cm.CommandText = "select * from 1604f where AgencyCd='" & cmbOfc.SelectedValue & _
            "' and ReturnPd='" & Format(CDate(txtPeriod.Text), "yyyy/MM/dd") & "'"
        rs = cm.ExecuteReader
        Do While rs.Read
            vDateResign = ""
            If Not IsDBNull(rs("DateResigned")) Then
                vDateResign = Format(CDate(rs("DateResigned")), "MM/dd/yyyy")
            End If
            vDump += rs("Emp_Cd") & "," & rs("Ftype_Cd") & "," & rs("Tin_Emr") & "," & rs("BranchCd_Emr") & _
                "," & Format(CDate(rs("ReturnPd")), "MM/dd/yyyy") & "," & rs("Sched_Num") & "," & _
                rs("SeqId") & "," & rs("Fname") & "," & rs("Lname") & "," & rs("Mname") & "," & _
                rs("Tin_Emp") & "," & rs("BranchCd_Emp") & "," & Format(CDate(rs("DateHired")), "MM/dd/yyyy") & _
                "," & vDateResign & "," & rs("Actual_Withheld") & "," & _
                rs("Salaries_Tax") & "," & rs("OtherIncent_Tax") & "," & rs("TaxWithheld") & "," & _
                rs("Salaries_NonTax") & "," & rs("OtherIncent_NonTax") & "," & rs("Prev_Taxable_Salaries") & _
                "," & rs("Prev_Taxable_13th_Month") & "," & rs("Prev_Tax_Withheld") & "," & _
                rs("Prev_NonTax_Salaries") & "," & rs("Prev_NonTax_13th_Month") & "," & rs("Mandatory") & "," & _
                rs("Prev_NonTax_SSS") & "," & rs("Variance") & "," & rs("TaxWithheld_Dec") & "," & _
                rs("Exemption") & "," & rs("TaxDue") & "," & rs("Premiums") & "," & rs("AgencyCd") & vbCrLf
        Loop
        rs.Close()

        If Dir(Server.MapPath(".") & "\downloads\" & Session.SessionID & "-bir.txt") <> "" Then
            Try
                IO.File.Delete(Server.MapPath(".") & "\downloads\" & Session.SessionID & "-bir.txt")
            Catch ex As IO.IOException
            End Try
        End If
        IO.File.WriteAllText(Server.MapPath(".") & "\downloads\" & Session.SessionID & "-bir.txt", vDump)
        lnkDownload.NavigateUrl = "downloads/" & Session.SessionID & "-bir.txt"
    End Sub

    Protected Sub cmdProcess_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdProcess.Init
        cmdProcess.Attributes.Add("onclick", "javascript:document.getElementById('divWait').style.visibility='visible';")
    End Sub

    Protected Sub tbl1604_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles tbl1604.PageIndexChanging
        tbl1604.PageIndex = e.NewPageIndex
        DataRefresh()
    End Sub

End Class
