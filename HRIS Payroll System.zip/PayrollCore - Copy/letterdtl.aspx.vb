Imports denaro
Partial Class letterdtl
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Dim c As New sqlclient.sqlconnection

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            vScript = "alert('Your login session has expired. Please re-login again.'); window.close();"
            Exit Sub
        End If
        If Not IsPostBack Then
            lblCaption.Text = "Macro keyword maintenance"
            txtLetter.Text = Session("lettercd")

            DataRefresh()
        End If
    End Sub

    Private Sub DataRefresh()
        Dim da As sqlclient.sqldataadapter
        Dim ds As New DataSet

        c.ConnectionString = connStr
        da = New sqlclient.sqldataadapter("select * from hr_letter_dtl where Letter_Cd='" & _
            ExtractData(txtLetter.Text) & "'", c)
        da.Fill(ds, "dtl")
        tblmacro.DataSource = ds.Tables("dtl")
        tblmacro.DataBind()
        da.Dispose()
        ds.Dispose()
    End Sub

    Protected Sub cmdAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdAdd.Click
        Session("mode") = "a"
        Server.Transfer("modifyletterdtl.aspx")
    End Sub

    Protected Sub cmdEdit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdEdit.Click
        If tblmacro.SelectedIndex > -1 And tblmacro.SelectedIndex <= tblmacro.Rows.Count Then
            Session("mode") = "e"
            Session("keyword") = tblmacro.SelectedRow.Cells(0).Text
            Server.Transfer("modifyletterdtl.aspx")
        Else
            vScript = "alert('You must first select a keyword to edit.');"
        End If
    End Sub

    Protected Sub cmdDel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDel.Click
        If tblmacro.SelectedIndex > -1 And tblmacro.SelectedIndex <= tblmacro.Rows.Count Then
            Dim cm As New sqlclient.sqlcommand

            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c
            cm.CommandText = "delete from hr_letter_dtl where Letter_Cd='" & _
                ExtractData(txtLetter.Text) & "' and Find_Var='" & _
                tblmacro.SelectedRow.Cells(0).Text & "'"
            cm.ExecuteNonQuery()
            cm.Dispose()
            c.Close()
            vScript = "alert('Record was successfully deleted');"
            DataRefresh()
        Else
            vScript = "alert('You must first select a keyword to delete.');"
        End If
    End Sub
End Class
