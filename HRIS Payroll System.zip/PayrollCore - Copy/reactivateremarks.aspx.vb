Imports denaro

Partial Class reactivateremars

    Inherits System.Web.UI.Page
    Public vscript As String = ""
    Protected Sub cmdClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdClose.Click
        vscript = "window.close();"
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        Dim c As New sqlclient.sqlconnection(connStr)
        Dim cm As New sqlclient.sqlcommand

        c.Open()
        cm.Connection = c
        cm.CommandText = "update hr_emp_tmp_master set remarks=remarks+'" & txtRemarks.Text & "|" & _
                         "',rem_counter=rem_counter+1,Frozen=0 where ApplicantNo='" & Session("id") & "'"
        cm.ExecuteNonQuery()

        c.Close()
        c.Dispose()
        cm.Dispose()
        vscript = "alert('Reactivation Complete');window.close();"
    End Sub
End Class
