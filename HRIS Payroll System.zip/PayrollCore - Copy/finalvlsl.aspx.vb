﻿Imports denaro.fis
Partial Class finalvlsl
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Session("uid") = Nothing Or Session("uid") = "" Then
            vScript = "alert('Your login session has expired. Please re-login again to continue.'); parent.parent.window.location='login.aspx';"
            Exit Sub
        End If

        If Not IsPostBack Then
            txtPostDate.Text = Session("paydate")
            Dim c As New SqlClient.SqlConnection(connStr)

            Try
                c.Open()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                c.Dispose()
                Exit Sub
            End Try

            BuildCombo("select Incentive_Cd,Descr from py_other_incentvs order by Descr", cmbSLPost, c)
            BuildCombo("select Incentive_Cd,Descr from py_other_incentvs order by Descr", cmbVLPost, c)
            c.Close()
            c.Dispose()

            ComputeVLSL()
        End If
    End Sub
    Private Sub ComputeVLSL()

    End Sub
End Class
