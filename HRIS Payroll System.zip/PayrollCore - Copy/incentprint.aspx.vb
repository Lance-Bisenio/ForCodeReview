Imports denaro.fis
Partial Class incentprint
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Public vDump As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            vScript = "alert('Your login session has expired. Please re-login again.');"
            Exit Sub
        End If

        Dim c As New sqlclient.sqlConnection(connStr)
        Dim cm As New sqlclient.sqlCommand
        Dim rs As sqlclient.sqlDataReader
        Dim iCtr As Integer = 0
        Dim vClass As String = "odd"
        Dim vTotal As Decimal = 0

        Try
            c.Open()
        Catch ex As sqlclient.sqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace("'", "").Replace(vbCrLf, "") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try
        cm.Connection = c
        cm.CommandText = Session("sql_print")
        Try
            rs = cm.ExecuteReader

            Do While rs.Read
                iCtr += 1
                lblIncent.Text = rs("Incentive_Cd")
                vDump += "<tr class='" & vClass & "'>" & _
                    "<td class='labelR'>" & iCtr & ".</td>" & _
                    "<td class='labelL'>" & rs("Emp_Cd") & "</td>" & _
                    "<td class='labelL'>" & rs("EmpName") & "</td>" & _
                    "<td class='labelR'>" & Format(rs("IncentiveAmt"), "##,##0.00") & "</td>" & _
                    "<td class='labelR'>" & rs("From_Date") & "</td>" & _
                    "<td class='labelR'>" & rs("To_Date") & "</td>" & _
                    "<td class='labelL'>" & IIf(rs("FreqCd") = 0, "Every Payroll", "Every " & rs("FreqCd")) & "</td>" & _
                    "</tr>"
                vClass = IIf(vClass = "odd", "even", "odd")
                vTotal += rs("IncentiveAmt")
            Loop
            rs.Close()
            vDump += "<tr class='titleBar'><td>&nbsp;</td><td>&nbsp;</td><td class='labelR'>Total:</td>" & _
                    "<td class='labelR'>" & Format(vTotal, "##,###,##0.00") & "</td>" & _
                    "<td>&nbsp;</td>" & _
                    "<td>&nbsp;</td>" & _
                    "<td>&nbsp;</td>" & _
                    "</tr>"
            If lblIncent.Text <> "" Then
                cm.CommandText = "select Descr from py_other_incentvs where Incentive_Cd='" & lblIncent.Text & "'"
                rs = cm.ExecuteReader
                If rs.Read Then
                    lblIncent.Text = rs("Descr")
                End If
                rs.Close()
            End If
        Catch ex As sqlclient.sqlException
            vScript = "alert('Error occurred while trying to retrieve database. Error is: " & _
                ex.Message.Replace("'", "").Replace(vbCrLf, "") & "');"
        Finally
            c.Close()
            c.Dispose()
            cm.Dispose()
        End Try
    End Sub
End Class
