Imports System.Data
Imports denaro.fis
Partial Class modifyuserapproval
    Inherits System.Web.UI.Page
    Public vScript As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            vScript = "alert('Session has expired!'); opener.location='index.aspx'; window.close();"
            Exit Sub
        End If
        If Session("user") = "" And Request.Item("mode") = "e" Then
            vScript = "alert('You must first select a record to edit.'); widow.close();"
            Exit Sub
        End If
        If Session("category") = "" Then
            vScript = "alert('You must first select  category.'); window.close();"
            Exit Sub
        End If
        If Not IsPostBack Then
            lblCaption.Text = "Add/Modify User Approval"
            txtCategory.Text = Session("category")
            BuildCombo("select Emp_Cd,Emp_Lname+', '+Emp_Fname as Name from py_emp_master " & _
                "where Date_Resign is null order by Emp_Lname,Emp_Fname", cmbEmp)
            If Request.Item("mode") = "e" Then  'edit mode
                Dim c As New sqlclient.sqlconnection(connStr)
                Dim cm As New sqlclient.sqlcommand("select * from user_approval where TagName='" & _
                    Session("category") & "' and User_Id='" & Session("user") & "'", c)
                Dim rs As sqlclient.sqldatareader

                Try
                    c.Open()
                    rs = cm.ExecuteReader
                    If rs.Read Then
                        cmbEmp.SelectedValue = Session("user")
                        cmbEmp.Enabled = False
                        txtFrom.Text = IIf(IsDBNull(rs("FromAmt")), 0, rs("FromAmt"))
                        txtTo.Text = IIf(IsDBNull(rs("ToAmt")), 9999999.99, rs("ToAmt"))
                    End If
                    rs.Close()
                    c.Close()
                    cm.Dispose()
                    c.Dispose()
                Catch ex As sqlclient.sqlException
                    vScript = "alert('An error has occurred while trying to retrieve the data. Error is: " & _
                        ex.Message.Replace("'", "") & "');"
                End Try
            End If
        End If
    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        If Page.IsValid Then
            Dim c As New sqlclient.sqlConnection(connStr)
            Dim cm As New sqlclient.sqlCommand

            cm.Connection = c
            If Request.Item("mode") = "e" Then    'update mode
                cm.CommandText = "update user_approval set FromAmt=" & _
                    Val(txtFrom.Text) & ",ToAmt=" & Val(txtTo.Text) & _
                    " where User_Id='" & Session("user") & _
                    "' and TagName='" & Session("category") & "'"
            Else
                cm.CommandText = "insert into user_approval (User_Id,TagName,FromAmt,ToAmt) values ('" & _
                    cmbEmp.SelectedValue & "','" & txtCategory.Text & "'," & txtFrom.Text & "," & _
                    txtTo.Text & ")"
            End If
            Try
                c.Open()
                cm.ExecuteNonQuery()
                c.Close()
                cm.Dispose()
                c.Dispose()
                vScript = "alert('Changes were successfully saved!'); opener.document.form1.submit(); window.close();"
            Catch ex As sqlclient.sqlException
                vScript = "alert('An error has occurred while trying to save your changes. Error is: " & _
                    ex.Message.Replace("'", "") & "');"
            End Try
        End If
    End Sub

    Protected Sub vldUser_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles vldUser.ServerValidate
        If txtFrom.Text = "" Or txtTo.Text = "" Then
            args.IsValid = False
            Exit Sub
        End If
        If Not IsNumeric(txtFrom.Text) Or Not IsNumeric(txtTo.Text) Then
            args.IsValid = False
            Exit Sub
        End If
    End Sub
End Class
