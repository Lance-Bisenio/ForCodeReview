Imports denaro
Partial Class _13thSettings
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Dim c As New sqlclient.sqlconnection
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'If Session("uid") = "" Then
        '    vScript = "window.close();"
        '    Exit Sub
        'End If
        If Not IsPostBack Then
            lblCaption.Text = "13th Month Settings"
            Dim cRef As New SqlClient.SqlConnection(connStr)
            Dim cm As New SqlClient.SqlCommand
            Dim cmRef As New SqlClient.SqlCommand
            Dim rs As SqlClient.SqlDataReader
            Dim rsRef As SqlClient.SqlDataReader
            Dim iCtr As Integer

            c.ConnectionString = connStr
            c.Open()
            cRef.Open()
            cm.Connection = c
            cmRef.Connection = cRef
            cm.CommandText = "select * from py_syscntrl"
            rs = cm.ExecuteReader
            rs.Read()
            chkIncentives.Items.Clear()
            chkIncentives.Items.Add(New ListItem("ECOLA/ACA", "Aca"))
            chkIncentives.Items.Add(New ListItem("Rep/Transpo", "Rata"))
            chkIncentives.Items.Add(New ListItem("Tempo/OT/PERA", "Pera"))
            chkIncentives.Items.Add(New ListItem("Meal Allowance", "Meal"))
            For iCtr = 1 To 30
                cmRef.CommandText = "select Incentive_Cd,Descr from py_other_incentvs where " & _
                    "Incentive_Cd='" & rs("OthIncent" & iCtr & "Cd") & "'"
                rsRef = cmRef.ExecuteReader
                If rsRef.Read Then
                    chkIncentives.Items.Add(New ListItem(rsRef("Incentive_Cd") & "=>" & rsRef("Descr"), iCtr))
                End If
                rsRef.Close()
            Next iCtr
            rs.Close()
            cm.Dispose()
            cmRef.Dispose()
            cRef.Close()
            cRef.Dispose()
            c.Close()
            rdoBasic.SelectedValue = IIf(Session("basis") = Nothing, 0, Session("basis"))
            rdoHiring.SelectedValue = IIf(Session("1stMonthCredit") = Nothing, 0, Session("1stMonthCredit"))
            txtCond1.Text = Session("cond1")
            txtCond2.Text = Session("cond2")
            txtCond3.Text = Session("cond3")
            txtFrom1.Text = Session("start1")
            txtFrom2.Text = Session("start2")
            txtFrom3.Text = Session("start3")
            txtTo1.Text = Session("end1")
            txtTo2.Text = Session("end2")
            txtTo3.Text = Session("end3")
            chkAbsences.Checked = Session("absences") = 1
            txtDivisor.Text = IIf(Session("divisor") = Nothing, 12, Session("divisor"))
        End If
    End Sub

    Protected Sub rdoHiring_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rdoHiring.SelectedIndexChanged
        pnlRange.Enabled = rdoHiring.SelectedIndex = 1
    End Sub

    Protected Sub cmdSet_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSet.Click
        Dim vIncentList As String = ", sum("
        Dim vIncList As String = ""
        Dim iCtr As Integer

        Session("basis") = rdoBasic.SelectedValue
        Session("1stMonthCredit") = rdoHiring.SelectedValue
        Session("cond1") = txtCond1.Text
        Session("cond2") = txtCond2.Text
        Session("cond3") = txtCond3.Text
        Session("start1") = txtFrom1.Text
        Session("start2") = txtFrom2.Text
        Session("start3") = txtFrom3.Text
        Session("end1") = txtTo1.Text
        Session("end2") = txtTo2.Text
        Session("end3") = txtTo3.Text
        Session("absences") = IIf(chkAbsences.Checked, 1, 0)
        Session("divisor") = txtDivisor.Text
        If chkIncentives.Items(0).Selected Then
            vIncList += ",sum(Aca) as Acas"
        Else
            vIncList += ",0 as Acas"
        End If
        If chkIncentives.Items(1).Selected Then
            vIncList += ",sum(Rata) as Ratas"
        Else
            vIncList += ",0 as Ratas"
        End If
        If chkIncentives.Items(2).Selected Then
            vIncList += ",sum(Pera) as Peras"
        Else
            vIncList += ",0 as Peras"
        End If
        If chkIncentives.Items(3).Selected Then
            vIncList += ",sum(MealAllow) as Meals"
        Else
            vIncList += ",0 as Meals"
        End If
        For iCtr = 4 To chkIncentives.Items.Count - 1
            If chkIncentives.Items(iCtr).Selected Then
                vIncentList += "Other_Incent" & chkIncentives.Items(iCtr).Value & "+"
            End If
        Next iCtr
        If vIncentList.Length > 6 Then
            vIncentList = vIncentList.Substring(0, vIncentList.Length - 1) & ") as Incent"
        Else
            vIncentList = ",0 as Incent"
        End If

        Session("incentives") = vIncList & vIncentList
        vScript = "window.close();"
    End Sub
End Class
