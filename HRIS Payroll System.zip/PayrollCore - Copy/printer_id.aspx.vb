Imports System.Data.SqlClient
Imports denaro
Imports System.IO
Partial Class printer_id
    Inherits System.Web.UI.Page
    Public displaydata As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim c As New SqlConnection
        Dim cm As New SqlCommand
        Dim rs As SqlDataReader
        Dim vEmpId As String = Session("vEmpId")
        Dim totalrecords As Long = 0
        Session.Remove("vEmpId")
        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c
        'count the total selected employees
        cm.CommandText = "SELECT COUNT(*) FROM py_emp_master WHERE Emp_Cd IN(" & vEmpId & ")"
        rs = cm.ExecuteReader
        If rs.HasRows Then
            rs.Read()
            If rs(0) > 0 Then
                totalrecords = CLng(rs(0))
            End If
        End If
        rs.Close()
        Dim x As Integer = 0
        '
        For x = 0 To totalrecords Step 4
            cm.CommandText = "SELECT TOP " & x & " Emp_Cd, Emp_Fname, Emp_Lname, Emp_Mname, NickName, AgencyName, Emp_Tel, Emp_Address FROM py_emp_master, agency WHERE agency.agencycd=py_emp_master.agency_cd AND Emp_Cd IN(" & vEmpId & ")"
            rs = cm.ExecuteReader
            displaydata += "<table class='outerbox'>"
            If rs.HasRows Then
                Dim ctr As Integer = 0
                Dim rowdata As String = ""
                Do While rs.Read
                    If ctr = 0 Then
                        rowdata = "<tr>"
                    ElseIf ctr = 2 Then
                        rowdata += "</tr>"
                        ctr = 0
                    End If
                    rowdata += "<td class='quarterfold'>"
                    rowdata += "<table class='innerbox' align='center'>"
                    rowdata += "<tr><td class='picholder'>"
                    If File.Exists(Server.MapPath("") & "\pics\" & rs("Emp_Cd") & ".jpg") Then
                        rowdata += "<img src='pics/" & rs("Emp_Cd") & ".jpg' class='picture' />"
                    Else
                        rowdata += "<img src='pics/none.jpg' class='picture' />"
                    End If
                    rowdata += "</td></tr>"
                    rowdata += "<tr><td class='locale'>" & rs("AgencyName") & "</td></tr>"
                    If Not IsDBNull(rs("AgencyName")) Then
                        rowdata += "<tr><td class='address'>" & rs("Emp_Address") & "</td></tr>"
                    Else
                        rowdata += "<tr><td class='address'>No Address Specified</td></tr>"
                    End If
                    If Not IsDBNull(rs("Emp_Tel")) Then
                        If rs("Emp_Tel") = "" Then
                            rowdata += "<tr><td class='phone'>-- -- --</td></tr>"
                        Else
                            rowdata += "<tr><td class='phone'>" & rs("Emp_Tel") & "</td></tr>"
                        End If
                    Else
                        rowdata += "<tr><td class='phone'>-- -- --</td></tr>"
                    End If
                    If Not IsDBNull(rs("NickName")) Then
                        rowdata += "<tr><td class='nickname'>" & rs("NickName") & "</td></tr>"
                    Else
                        rowdata += "<tr><td class='nickname'>-- -- --</td></tr>"
                    End If
                    rowdata += "<tr><td class='emp_id'>" & rs("Emp_Cd") & "</td></tr>"
                    rowdata += "</table>"
                    rowdata += "</td>"
                    ctr += 1
                Loop
                displaydata += rowdata
            End If
            displaydata += "</table><br /><br /><br /><br /><br /><br /><br /><br /><br />"
            rs.Close()
        Next
    End Sub
End Class
