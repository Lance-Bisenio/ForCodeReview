Imports denaro
Partial Class modifyviolate
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Dim c As New sqlclient.sqlconnection
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If
        If Not IsPostBack Then
            Dim cm As New sqlclient.sqlcommand
            Dim dr As sqlclient.sqldatareader
            txtEmpCd.Text = Session("empid")
            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c
            cm.CommandText = "select Emp_Lname,Emp_Fname from py_emp_master where Emp_Cd='" & txtEmpCd.Text & "'"
            dr = cm.ExecuteReader
            lblCaption.Text = "Add/Modify Commendation for "
            If dr.Read Then
                lblcaption.Text += dr("Emp_Lname") & ", " & dr("Emp_Fname")
            End If
            dr.Close()
            BuildCombo("SELECT Article_Cd,Descr FROM hr_violate_article order by Article_Cd", droparticle)
            txtType.Text = Session("type")
            If Session("mode") = "e" Then
                cm.CommandText = "select * from hr_emp_violate_commend where Emp_Id='" & txtEmpCd.Text & _
                    "' and Event_Date='" & Format(CDate(Session("seqid")), "yyyy/MM/dd") & _
                    "' and Event_Type='" & txtType.Text & "'"
                dr = cm.ExecuteReader
                If dr.Read Then
                    If IsDBNull(dr("Date_Resolved")) Then
                        txtDateResolved.Text = ""
                    Else
                        txtDateResolved.Text = dr("Date_Resolved")
                    End If
                    txtTdate.Text = dr("Event_Date")
                    txtEvent.Text = dr("Event")
                    txtAction.Text = dr("Actions")
                    txtRemarks.Text = dr("Remarks")
                    droparticle.SelectedValue = dr("Article_Cd")
                End If
                dr.Close()
            Else
                droparticle.SelectedIndex = 0
            End If
            cm.Dispose()
            c.Close()

        End If
    End Sub

    Protected Sub cmdCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        Session.Remove("empid")
        Session.Remove("mode")
        Session.Remove("seqid")
        Session.Remove("type")
        vScript = "window.close();"
    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        If Page.IsValid Then
            Dim cm As New sqlclient.sqlcommand
            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c
            If Session("mode") = "e" Then 'edit mode
                cm.CommandText = "update hr_emp_violate_commend set Event_Date='" & Format(CDate(txtTdate.Text), "yyyy/MM/dd") & _
                    "',Event='" & txtEvent.Text & _
                    "',Date_Resolved='" & Format(CDate(txtDateResolved.Text), "yyyy/MM/dd") & _
                    "',Actions='" & txtAction.Text & _
                   "',Remarks='" & txtRemarks.Text & _
                    "', Article_Cd='" & droparticle.SelectedValue & "' where Emp_Id='" & txtEmpCd.Text & "' and Event_Date='" & Format(CDate(Session("seqid")), "yyyy/MM/dd") & _
                    "' and Event_Type='" & txtType.Text & "'"
            Else                          'add mode
                cm.CommandText = "insert into hr_emp_violate_commend (Emp_Id,Event_Type,Event_Date,Event," & _
                    "Actions,Remarks, Article_Cd,Date_Resolved) values ('" & txtEmpCd.Text & "','" & txtType.Text & _
                    "','" & Format(CDate(txtTdate.Text), "yyyy/MM/dd") & "','" & txtEvent.Text & "','" & _
                    txtAction.Text & "','" & txtRemarks.Text & "','" & droparticle.SelectedValue & _
                    "','" & Format(CDate(txtDateResolved.Text), "yyyy/MM/dd") & "')"
            End If
            cm.ExecuteNonQuery()
            Session.Remove("empid")
            Session.Remove("mode")
            Session.Remove("seqid")
            Session.Remove("type")
            cm.Dispose()
            c.Close()
            vScript = "alert('Changes were successfully saved.'); window.close();"
        End If
    End Sub

    Protected Sub vld_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles vld.ServerValidate
        If Not IsDate(txtTdate.Text) Then
            vScript = "alert('Invalid date format in Event Date field.');"
            args.IsValid = False
            Exit Sub
        Else
            args.IsValid = True
        End If

        If Not IsDate(txtDateResolved.Text) Then
            vScript = "alert('Invalid date format in Date Resolved field.');"
            args.IsValid = False
        Else
            args.IsValid = True
        End If
    End Sub
End Class
