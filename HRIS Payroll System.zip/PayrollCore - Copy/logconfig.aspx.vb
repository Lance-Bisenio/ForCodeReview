﻿
Partial Class logconfig
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim vRegTerminals As String = System.Configuration.ConfigurationManager.AppSettings.Get("terminals")
            Dim vReadMode As String = System.Configuration.ConfigurationManager.AppSettings.Get("readmode")
            Dim vLogIn As String = System.Configuration.ConfigurationManager.AppSettings.Get("login")
            Dim vLogOut As String = System.Configuration.ConfigurationManager.AppSettings.Get("logout")
            Dim vStepOut As String = System.Configuration.ConfigurationManager.AppSettings.Get("stepout")
            Dim vStepIn As String = System.Configuration.ConfigurationManager.AppSettings.Get("stepin")

            txtRegTerm.Text = vRegTerminals
            rdoMode.SelectedValue = Val(vReadMode)
            If rdoMode.SelectedValue = 0 Then   'use function mode
                txtLogIn.Visible = False
                txtLogOut.Visible = False
                txtStepOut.Visible = False
                txtStepIn.Visible = False
                rdoLogIn.Visible = True
                rdoLogOut.Visible = True
                rdoStepIn.Visible = True
                rdoStepOut.Visible = True
                rdoLogIn.SelectedValue = vLogIn
                rdoLogOut.SelectedValue = vLogOut
                rdoStepIn.SelectedValue = vStepIn
                rdoStepOut.SelectedValue = vStepOut
            Else                                'user terminal mode
                txtLogIn.Visible = True
                txtLogOut.Visible = True
                txtStepOut.Visible = True
                txtStepIn.Visible = True
                rdoLogIn.Visible = False
                rdoLogOut.Visible = False
                rdoStepIn.Visible = False
                rdoStepOut.Visible = False
                txtLogIn.Text = vLogIn
                txtLogOut.Text = vLogOut
                txtStepIn.Text = vStepIn
                txtStepOut.Text = vStepOut
            End If
        End If
    End Sub

    Protected Sub rdoMode_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rdoMode.SelectedIndexChanged
        If rdoMode.SelectedValue = 0 Then   'use function mode
            txtLogIn.Visible = False
            txtLogOut.Visible = False
            txtStepOut.Visible = False
            txtStepIn.Visible = False
            rdoLogIn.Visible = True
            rdoLogOut.Visible = True
            rdoStepIn.Visible = True
            rdoStepOut.Visible = True
        Else                                'user terminal mode
            txtLogIn.Visible = True
            txtLogOut.Visible = True
            txtStepOut.Visible = True
            txtStepIn.Visible = True
            rdoLogIn.Visible = False
            rdoLogOut.Visible = False
            rdoStepIn.Visible = False
            rdoStepOut.Visible = False
        End If
    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        System.Configuration.ConfigurationManager.AppSettings.Set("terminals", txtRegTerm.Text)
        System.Configuration.ConfigurationManager.AppSettings.Set("readmode", rdoMode.SelectedValue)

        If rdoMode.SelectedValue = 0 Then   'use function keys
            System.Configuration.ConfigurationManager.AppSettings.Set("login", rdoLogIn.SelectedValue)
            System.Configuration.ConfigurationManager.AppSettings.Set("logout", rdoLogOut.SelectedValue)
            System.Configuration.ConfigurationManager.AppSettings.Set("stepout", rdoStepOut.SelectedValue)
            System.Configuration.ConfigurationManager.AppSettings.Set("stepin", rdoStepIn.SelectedValue)
        Else                                'use terminals
            System.Configuration.ConfigurationManager.AppSettings.Set("login", txtLogIn.Text)
            System.Configuration.ConfigurationManager.AppSettings.Set("logout", txtLogOut.Text)
            System.Configuration.ConfigurationManager.AppSettings.Set("stepout", txtStepOut.Text)
            System.Configuration.ConfigurationManager.AppSettings.Set("stepin", txtStepIn.Text)
        End If
        vScript = "alert('Changes were successfully saved.'); window.close();"
    End Sub
End Class
