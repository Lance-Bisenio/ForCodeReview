Imports denaro
Partial Class nacsync
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Dim c As New sqlclient.sqlConnection

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            lblCaption.Text = "Employee Synchronization to Biometrics"
            BuildCombo("select Rc_Cd, Descr from rc  order by Descr ", cmbRC)
            BuildCombo("select AgencyCd,AgencyName from agency order by AgencyName", cmbOfc)
            BuildCombo("select Div_Cd,Descr from hr_div_ref  order by Descr", cmbDiv)
            BuildCombo("select Dept_Cd,Descr from hr_dept_ref  order by Descr", cmbDept)
            BuildCombo("select Section_Cd,Descr from hr_section_ref  order by Descr", cmbSection)
            BuildCombo("select Unit_Cd,Descr from hr_unit_ref  order by Descr", cmbUnit)
            BuildCombo("select EmploymentType,Descr from hr_employment_type order by Descr", cmbEmpType)
            cmbRC.Items.Add("All Cost Centers")
            cmbRC.SelectedValue = "All Cost Centers"
            cmbOfc.Items.Add("All Office")
            cmbOfc.SelectedValue = "All Office"
            cmbDiv.Items.Add("All Division")
            cmbDiv.SelectedValue = "All Division"
            cmbDept.Items.Add("All Departments")
            cmbDept.SelectedValue = "All Departments"
            cmbSection.Items.Add("All Section")
            cmbSection.SelectedValue = "All Section"
            cmbUnit.Items.Add("All Units")
            cmbUnit.SelectedValue = "All Units"
            cmbEmpType.Items.Add("All Types")
            cmbEmpType.SelectedValue = "All Types"
        End If
    End Sub

    Private Sub DataRefresh()
        Dim cNAC As New sqlclient.sqlConnection
        Dim cmNAC As New sqlclient.sqlCommand
        Dim cm As New sqlclient.sqlCommand
        Dim drNAC As sqlclient.sqlDataReader
        Dim dr As sqlclient.sqlDataReader
        Dim vSQL As String = ""
        Dim vFilter As String = ""


        vFilter = " where Date_Resign is null "

        If cmbRC.SelectedValue <> "All Cost Centers" Then   'filter by cost center
            vFilter += " and Rc_Cd='" & cmbRC.SelectedValue & "' "
        Else
            'vFilter += " and Rc_Cd in ('" & Session("rclist").ToString.Replace(",", "','") & "') "
        End If
        If cmbOfc.SelectedValue <> "All Office" Then        'filter by office/agency
            vFilter += " and Agency_Cd='" & cmbOfc.SelectedValue & "' "
        Else
            'vFilter += " and Agency_Cd in ('" & Session("agencylist").ToString.Replace(",", "','") & "') "
        End If
        If cmbDiv.SelectedValue <> "All Division" Then      'filter by division
            vFilter += " and Divcd='" & cmbDiv.SelectedValue & "' "
        Else
            'vFilter += " and DivCd in ('" & Session("divlist").ToString.Replace(",", "','") & "') "
        End If
        If cmbDept.SelectedValue <> "All Departments" Then  'filter by departments
            vFilter += " and DeptCd='" & cmbDept.SelectedValue & "' "
        Else
            'vFilter += " and DeptCd in ('" & Session("deptlist").ToString.Replace(",", "','") & "') "
        End If
        If cmbSection.SelectedValue <> "All Section" Then 'filter by section
            vFilter += " and SectionCd='" & cmbSection.SelectedValue & "' "
        Else
            'vFilter += " and SectionCd in ('" & Session("sectionlist").ToString.Replace(",", "','") & "') "
        End If
        If cmbUnit.SelectedValue <> "All Units" Then  'filter by units
            vFilter += " and UnitCd='" & cmbUnit.SelectedValue & "' "
        Else
            'vFilter += " and UnitCd in ('" & Session("unitlist").ToString.Replace(",", "','") & "') "
        End If
        If cmbEmpType.SelectedValue <> "All Types" Then 'filter by employment types
            vFilter += " and EmploymentType='" & cmbEmpType.SelectedValue & "' "
        Else
            'vFilter += " and EmploymentType in ('" & Session("typelist").ToString.Replace(",", "','") & "') "
        End If
        vSQL = "select Emp_Cd,Emp_Lname,Emp_Fname,Emp_Mname from py_emp_master " & vFilter & _
            " order by Emp_Lname,Emp_Fname,Emp_Mname"
        c.ConnectionString = connStr
        cNAC.ConnectionString = "DSN=nac; pwd=nac3000;"
        cNAC.Open()
        c.Open()
        cm.Connection = c
        cmNAC.Connection = cNAC
        cm.CommandText = vSQL
        dr = cm.ExecuteReader
        chkEmp.Items.Clear()

        Dim a As New DataSourceSelectArguments
        a.TotalRowCount = 10000

        Do While dr.Read
            cmNAC.CommandText = "select employeeno from ngac_userinfo where employeeno='" & _
               dr("Emp_Cd") & "'"

            drNAC = cmNAC.ExecuteReader
            If Not drNAC.Read Then
                chkEmp.Items.Add(dr("Emp_Cd") & "=>" & dr("Emp_Lname") & ", " & dr("Emp_Fname") & " " _
                    & dr("Emp_Mname"))
            End If
            drNAC.Close()
        Loop
        dr.Close()
        cm.Dispose()
        cmNAC.Dispose()
        c.Close()
        cNAC.Close()
    End Sub

    Protected Sub cmdRefresh_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdRefresh.Click
        DataRefresh()
    End Sub

    Protected Sub cmdSelect_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSelect.Click
        Dim iLoop As Integer

        For iLoop = 0 To chkEmp.Items.Count - 1
            chkEmp.Items(iLoop).Selected = True
        Next iLoop
    End Sub

    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDeselect.Click
        Dim iLoop As Integer

        For iLoop = 0 To chkEmp.Items.Count - 1
            chkEmp.Items(iLoop).Selected = False
        Next iLoop

    End Sub

    Protected Sub cmdReturn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.Click
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub cmdSync_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSync.Click
        Dim iLoop As Integer
        Dim cNac As New sqlclient.sqlConnection
        Dim cmAccsys As New sqlclient.sqlCommand
        Dim cm As New sqlclient.sqlCommand
        Dim dr As sqlclient.sqlDataReader
        Dim vId As String = ""
        Dim vName As String = ""
        Dim vEmpCd As String = ""
        Dim vLastNo As Integer

        c.ConnectionString = connStr
        cNac.ConnectionString = "DSN=nitgenacdb; pwd=nac3000;"
        cNac.Open()
        c.Open()
        cm.Connection = cNac
        cmAccsys.Connection = c
        cm.CommandText = "select userid from ngac_userinfo order by userid desc"
        dr = cm.ExecuteReader
        If dr.Read Then
            vLastNo = Val(Mid(dr("userid"), 1, txtLength.Text)) + 1
        End If
        dr.Close()
        For iLoop = 0 To chkEmp.Items.Count - 1
            If chkEmp.Items(iLoop).Selected Then
                vId = chkEmp.Items(iLoop).Text
                vName = Mid(vId, InStr(vId, "=>") + 2)
                vEmpCd = Mid(vId, 1, InStr(vId, "=>") - 1)
                vId = Format(vLastNo, "0000") & "00000000000"
                cm.CommandText = "insert into ngac_userinfo (userid,username,employeeno,privilege," & _
                  "authtype,groupid,regdate,expdate,rfid,tzcode) values ('" & vId & "','" & _
                  vName & "','" & vEmpCd & "',2,1,0,'" & Format(Now, "MM/dd/yyyy") & _
                  "','1/1/9999',0,0)"

                cm.ExecuteNonQuery()
                cmAccsys.CommandText = "update py_emp_master set BarcodeId='" & _
                    Format(vLastNo, "0000") & "' where Emp_Cd='" & vEmpCd & "'"
                cmAccsys.ExecuteNonQuery()
                vLastNo += 1
            End If
        Next iLoop
        cNac.Close()
        cm.Dispose()
        vScript = "alert('Synchronization to biometrics complete! Launch the Remote Manager program " & _
            "to enroll the fingerprints of the newly uploaded employees.');"
    End Sub
End Class
