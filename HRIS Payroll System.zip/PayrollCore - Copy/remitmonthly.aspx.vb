Imports denaro
Partial Class remitmonthly
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If
        If Not CanRun(Session("caption"), Request.Item("id")) Then
            Session("denied") = "1"
            Server.Transfer("main.aspx")
            Exit Sub
        End If

        txtRank.Text = Request.Form("txtRank")
        If Not IsPostBack Then
            
            lblCaption.Text = "Generate Monthly Remittance Report"
            BuildCombo("select Rc_Cd,Descr from rc where exists (select User_Id from rights_list where User_Id='" & _
                    Session("uid") & "' and property='rc' and Property_Value=Rc_Cd) order by Descr", cmbRC)
            BuildCombo("select AgencyCd,AgencyName from agency where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='agency' and Property_Value=AgencyCd) order by AgencyName", cmbOfc)
            BuildCombo("select Div_Cd,Descr from hr_div_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='division' and Property_Value=Div_Cd) order by Descr", cmbDiv)
            BuildCombo("select Dept_Cd,Descr from hr_dept_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='department' and Property_Value=Dept_Cd) order by Descr", cmbDept)
            BuildCombo("select Section_Cd,Descr from hr_section_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='section' and Property_Value=Section_Cd) order by Descr", cmbSection)
            BuildCombo("select Unit_Cd,Descr from hr_unit_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='unit' and Property_Value=Unit_Cd) order by Descr", cmbUnit)
            BuildCombo("select Loan_Cd,Loan_Name from py_loan_ref order by Loan_Name", cmbReport)

            cmbOfc.Items.Add("All")
            cmbOfc.SelectedValue = "All"
            cmbRC.Items.Add("All")
            cmbRC.SelectedValue = "All"
            cmbDiv.Items.Add("All")
            cmbDiv.SelectedValue = "All"
            cmbDept.Items.Add("All")
            cmbDept.SelectedValue = "All"
            cmbSection.Items.Add("All")
            cmbSection.SelectedValue = "All"
            cmbUnit.Items.Add("All")
            cmbUnit.SelectedValue = "All"

            cmbReport.Items.Add(New ListItem("Union Dues Remittance (Members)", "union_member"))
            cmbReport.Items.Add(New ListItem("Union Dues Remittance (Non-Members)", "union_nonmember"))
            cmbReport.Items.Add(New ListItem("SSS=>SSS Remittance (Agency Format)", "SSS_CONT"))
            cmbReport.Items.Add(New ListItem("SSS=>SSS Remittance (EDINET Format)", "SSS_EDINET"))
            cmbReport.Items.Add(New ListItem("EPF=>Employee Pre-validation File (EDINET Format)", "EPF"))
            cmbReport.Items.Add(New ListItem("PAGIBIG=>PagIbig Remittance", "Pagibig"))
            cmbReport.Items.Add(New ListItem("PAGIBIG=>PagIbig Remittance (EDINET)", "Pagibig_EDINET"))
            cmbReport.Items.Add(New ListItem("PHILHEALTH=>Philhealth Remittance (Excel format)", "Philhealth"))
            cmbReport.Items.Add(New ListItem("PHILHEALTH=>Philhealth Remittance (EDINET format)", "PHICTXT"))
            cmbReport.Items.Add(New ListItem("TAX=>Tax Remittance", "Tax"))
            cmbReport.Items.Add("Select type of report...")
            cmbReport.SelectedValue = "Select type of report..."
            cmbYear.Items.Clear()
            cmbYearTo.Items.Clear()
            For i As Integer = Now.Year - 2 To Now.Year
                cmbYear.Items.Add(i)
                cmbYearTo.Items.Add(i)
            Next
            cmbYear.SelectedValue = Now.Year
            cmbYearTo.SelectedValue = Now.Year
            cmbMonth.SelectedValue = Now.Month
            cmbMonthTo.SelectedValue = Now.Month
            CreateDays(cmbMonth.SelectedValue, cmbYear.SelectedValue, cmbDay)
            CreateDays(cmbMonthTo.SelectedValue, cmbYearTo.SelectedValue, cmbDayTo)
        End If
    End Sub

    Protected Sub cmdReturn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.Click
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub cmdRefresh_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdRefresh.Click
        divReport.Attributes.Remove("src")
        DataRefresh()
    End Sub
    Private Sub DataRefresh()
        Dim vFilter As String = ""
        Dim vRptName As String = ""

        If cmbRC.SelectedValue <> "All" Then   'filter by cost center
            vFilter += " and Rc_Cd='" & cmbRC.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='rc' and Property_Value=Rc_Cd) "
        End If

        If cmbOfc.SelectedValue <> "All" Then        'filter by office/agency
            vFilter += " and Agency_Cd='" & cmbOfc.SelectedValue & "' "
        Else
            vFilter += "  and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='agency' and Property_Value=Agency_Cd) "
        End If
        If cmbDiv.SelectedValue <> "All" Then      'filter by division
            vFilter += " and Divcd='" & cmbDiv.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='division' and Property_Value=DivCd) "
        End If
        If cmbDept.SelectedValue <> "All" Then  'filter by departments
            vFilter += " and DeptCd='" & cmbDept.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='department' and Property_Value=DeptCd) "
        End If
        If cmbSection.SelectedValue <> "All" Then 'filter by section
            vFilter += " and SectionCd='" & cmbSection.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='section' and Property_Value=SectionCd) "
        End If
        If cmbUnit.SelectedValue <> "All" Then  'filter by units
            vFilter += " and UnitCd='" & cmbUnit.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='unit' and Property_Value=UnitCd) "
        End If

        vFilter += " and EmploymentType in ('" & txtRank.Text.Replace(",", "','") & "') "
        'vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
        '   "' and Property='employmenttype' and Property_Value=EmploymentType) "

        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                                             ''
        '' DATE MODIFIED: 5/9/2013                                                  ''
        '' PURPOSE: TO INCLUDE THE EMPLOYEE'S STATUS AS PART OF THE FILTER.         ''
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        Select Case rdoStatus.SelectedValue
            Case 0  'active
                vFilter += " and Emp_Status not in ('R','HOLD','TERM') "
            Case 1 'inactive
                vFilter += " and Emp_Status in ('R','HOLD','TERM') "
        End Select
        '''''''''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''''''

        Select Case cmbReport.SelectedValue.ToLower
            Case "sss_cont"
                SSS_REMIT_MONTHLY(vFilter)
            Case "sss_edinet"
                SSS_EDINET(vFilter)
            Case "philhealth"
                PHILHEALTH_REMITTANCE_REVISED(vFilter)
            Case "phictxt"
                PHILHEALTH_REMITTANCE(vFilter)
            Case "pagibig"
                PAGIBIG_REMITTANCE(vFilter)
            Case "pagibig_edinet"
                PAGIBIG_EDINET(vFilter)
            Case "tax"
                TAX_REMITTANCE(vFilter)
            Case "hdmfln", "PIBIG_LN"
                PAGIBIG_LOAN(vFilter, "HDMFLN")
            Case "housng"
                PAGIBIG_LOAN(vFilter, "HOUSNG")
            Case "epf"
                EPF(vFilter, "EPF")
                EPF_PDF(vFilter)
            Case "union_member"
                Union_Remittance("member", vFilter)
            Case "union_nonmember"
                Union_Remittance("non-member", vFilter)
            Case Else
                LOAN_REMITTANCE(cmbReport.SelectedValue.ToLower, vFilter)
                'frame.Attributes("src") = "downloads/" & Session.SessionID & "-" & cmbReport.SelectedValue.ToLower & ".pdf"
        End Select
        lnkDownload.Visible = True

        'Select Case cmbReport.SelectedValue.ToLower
        '    Case "sss"
        '        SSS_REMIT_MONTHLY(vEmpList)
        '        vRptName = "reports/sss_report.rpt"
        '        'vFilter = "{sss_info.PayDate}=#" & Format(CDate(cmbPayDate.selectedvalue, "yyyy/MM/dd") & _
        '        '    "# and {sss_info.Emp_Cd} in (" & vEmpList.Replace("','", ",") & ")"
        '        vFilter = "{sss_info.PayDate}=#" & Format(CDate(cmbPayDate.SelectedValue), "yyyy/MM/dd") & _
        '            "# and {comp_info.AgencyCd}='" & cmbOfc.SelectedValue & "' "
        '        If cmbOfc.SelectedValue <> "All" Then
        '            vFilter += " and {sss_info.Agency_Cd} = '" & cmbOfc.SelectedValue & "'"
        '        Else
        '            vFilter += " and {sss_info.Agency_Cd} in (" & Session("agencylist") & ")"
        '        End If
        '    Case "philhealth"
        '        PHILHEALTH_REMITTANCE(vEmpList)
        '        vRptName = "reports/philhealth_report.rpt"
        '        'vFilter = "{philhealth_info.PayDate}=#" & Format(CDate(cmbPayDate.selectedvalue, "yyyy/MM/dd") & _
        '        '"# and {philhealth_info.Emp_Cd} in (" & vEmpList.Replace("','", ",") & ")"
        '        vFilter = "{philhealth_info.PayDate}=#" & Format(CDate(cmbPayDate.SelectedValue), "yyyy/MM/dd") & _
        '            "# and {comp_info.AgencyCd}='" & cmbOfc.SelectedValue & "' "
        '        If cmbOfc.SelectedValue <> "All" Then
        '            vFilter += " and {philhealth_info.Agency_Cd} = '" & cmbOfc.SelectedValue & "'"
        '        Else
        '            vFilter += " and {philhealth_info.Agency_Cd} in (" & Session("agencylist") & ")"
        '        End If
        '    Case "pagibig"
        '        PAGIBIG_REMITTANCE(vEmpList)
        '        vRptName = "reports/pagibig_report.rpt"
        '        'vFilter = "{pagibig_info.PayDate}=#" & Format(CDate(cmbPayDate.selectedvalue, "yyyy/MM/dd") & _
        '        '"# and {pagibig_info.Emp_Cd} in (" & vEmpList.Replace("','", ",") & ")"
        '        vFilter = "{pagibig_info.PayDate}=#" & Format(CDate(cmbPayDate.SelectedValue), "yyyy/MM/dd") & _
        '            "# and {comp_info.AgencyCd}='" & cmbOfc.SelectedValue & "' "
        '        If cmbOfc.SelectedValue <> "All" Then
        '            vFilter += " and {pagibig_info.Agency_Cd} = '" & cmbOfc.SelectedValue & "'"
        '        Else
        '            vFilter += " and {pagibig_info.Agency_Cd} in (" & Session("agencylist") & ")"
        '        End If
        '    Case "tax"
        '        TAX_REMITTANCE(vEmpList)
        '        vRptName = "reports/tax_report.rpt"
        '        'vFilter = "{tax_info.PayDate}=#" & Format(CDate(cmbPayDate.selectedvalue, "yyyy/MM/dd") & _
        '        '"# and {tax_info.Emp_Cd} in (" & vEmpList.Replace("','", ",") & ")"
        '        vFilter = "{tax_info.PayDate}=#" & Format(CDate(cmbPayDate.SelectedValue), "yyyy/MM/dd") & _
        '            "# and {comp_info.AgencyCd}='" & cmbOfc.SelectedValue & "' "
        '        If cmbOfc.SelectedValue <> "All" Then
        '            vFilter += " and {tax_info.Agency_Cd} = '" & cmbOfc.SelectedValue & "'"
        '        Else
        '            vFilter += " and {tax_info.Agency_Cd} in (" & Session("agencylist") & ")"
        '        End If
        '    Case "pgsal"        'pagibig salary loan (short term)
        '        PAGIBIG_LOAN(vEmpList, "PGSAL")
        '        vScript = "viewwin=window.open('downloads/pagibigst.pdf','viewwin','toolbar=no,location=no,width=800,height=600');"
        '        lnkDownload.Visible = True
        '        Exit Sub
        '    Case "pghos"    'pagibig housing loan (LT)
        '        PAGIBIG_LOAN(vEmpList, "PGHOS")
        '        vScript = "viewwin=window.open('downloads/pagibighl.pdf','viewwin','toolbar=no,location=no,width=800,height=600');"
        '        lnkDownload.Visible = True
        '        Exit Sub
        '    Case "epf"      'employee pre-validation file
        '        vRptName = "reports/epf.rpt"
        '        EPF(vEmpList, "EPF")
        '    Case Else
        '        LOAN_REMITTANCE(cmbReport.SelectedValue.ToLower, vEmpList)
        '        vScript = "viewwin=window.open('downloads/" & _
        '             Session.SessionID & "-" & cmbReport.SelectedValue.ToLower & ".pdf','viewwin','toolbar=no,location=no,width=800,height=600');"
        '        lnkDownload.Visible = True
        '        Exit Sub
        'End Select
        'rpt.SelectionFormula = vFilter
        'rptSource.Report.FileName = vRptName
        'rpt.RefreshReport()
        vScript += "document.getElementById('divWait').style.visibility='hidden';"
    End Sub
    Private Sub Union_Remittance(ByVal pMode As String, ByVal pFilter As String)
        Dim vPrn As New VSPrinter8Lib.VSPrinter
        Dim vPDF As New VSPDF8Lib.VSPDF8
        Dim vCompanyName As String = ""
        Dim vAddress As String = ""
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cmReport As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim rsReport As SqlClient.SqlDataReader
        Dim vData As String = ""
        Dim vFormat As String = ""
        Dim iCtr As Integer = 1
        Dim vTotal As Decimal = 0
        Dim vClass As String = "odd"
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '''' Added by   :   Rudner D. Diaz, Jr.                  ''
        '''' Date       :   July 17, 2012                        ''
        '''' Reason     :   To accomodate the HTML format        ''
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        Dim vTypeLoan As String = IIf(pMode = "member", "MembersUDRR", "PayingNonMembersUDRR")
        Dim vHeader = IIf(pMode = "member", "Members'", "Paying Non-Members'") & " Union Dues Remittance Report"
        Dim vpdfFile As String = ""
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            cmReport.Dispose()
            Exit Sub
        End Try

        cm.Connection = c
        cmReport.Connection = c

        ''''''''''''''''''''''''''''''''''
        If cmbOfc.SelectedValue <> "All" Then
            cm.CommandText = "SELECT Company_Name, Address,AgencyCd FROM glsyscntrl WHERE CompanyCd='" & cmbOfc.SelectedValue & "'"
        Else
            cm.CommandText = "SELECT TOP 1Company_Name, Address,AgencyCd FROM glsyscntrl"
        End If

        Try
            rs = cm.ExecuteReader
            If rs.Read Then
                vCompanyName = IIf(IsDBNull(rs("Company_Name")), "UNKNOWN", rs("Company_Name"))
                vAddress = IIf(IsDBNull(rs("Address")), "UNKNOWN", rs("Address"))
            End If
            rs.Close()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to read System Control. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Close()
            c.Dispose()
            cm.Dispose()
            cmReport.Dispose()
            Exit Sub
        End Try

        vData = "<html><head><title>Union Dues Remittance Report</title><link href='../redtheme/red.css' rel='stylesheet' tyle='text/css'/></head><body><center>"
        vData += "<h2>" & Trim(vCompanyName) & "</h2>"
        vData += "<h4>" & vAddress & "</h4>"
        vData += "<h3>" & vHeader & "</h3>"
        vData += "<h4>from " & cmbMonth.SelectedItem.Text & " " & cmbDay.SelectedValue & ", " & cmbYear.SelectedValue & _
            " to " & cmbMonthTo.SelectedItem.Text & " " & cmbDayTo.SelectedValue & ", " & cmbYearTo.SelectedValue & "</h4>"
        vData += "<table border='1' style='border-collapse:collapse; width:100%;' class='label'>"
        vData += "<tr class='titleBar'><th>No.</th>" & _
                 "<th>Emp. Id</th><th>Name of Employee</th><th>Union Code</th>" & _
                 "<th>Amount</th></tr>"
        ''''''''''''''''''BODY''''''''''''''''''
        cm.CommandText = "SELECT Emp_Lname, Emp_Fname, Emp_Cd, UnionCd FROM py_emp_master " & _
            " WHERE  Allow_UnionDues=" & IIf(pMode = "member", 1, 0) & " and UnionCd is not null " & _
            pFilter & "  ORDER BY Emp_Lname,Emp_Fname"

        rs = cm.ExecuteReader
        Do While rs.Read
            cmReport.CommandText = "select sum(UnionDues) as TotalUnionDues,UnionCd from py_report where PayDate between '" & _
                cmbYear.SelectedValue & "/" & cmbMonth.SelectedValue & "/" & cmbDay.SelectedValue & _
                "' and '" & cmbYearTo.SelectedValue & "/" & cmbMonthTo.SelectedValue & "/" & cmbDayTo.SelectedValue & _
                "' and Emp_Cd='" & rs("Emp_Cd") & "' group by UnionCd"
            rsReport = cmReport.ExecuteReader
            Do While rsReport.Read
                If Not IsDBNull(rsReport("TotalUnionDues")) Then
                    If rsReport("TotalUnionDues") <> 0 Then
                        vData += "<tr class='" & vclass & "'><td class='labelL'>" & iCtr & ".</td><td class='labelC'>" & rs("Emp_Cd") & _
                                 "</td><td class='labelL'>" & rs("Emp_Lname") & ", " & rs("Emp_Fname") & _
                                 "</td><td class='labelC'>" & rs("UnionCd") & "</td><td class='labelR'>" & _
                            Format(rsReport("TotalUnionDues"), "##,##0.00") & "</td></tr>"
                        iCtr = iCtr + 1
                        vTotal += rsReport("TotalUnionDues")
                        vClass = IIf(vClass = "odd", "even", "odd")
                    End If
                End If
            Loop
            rsReport.Close()
        Loop
        rs.Close()
        c.Close()
        cm.Dispose()
        cmReport.Dispose()
        ''''''''''''''''''''''''''''''''''''''''
        vData += "<tr class='activeBar'><td class='labelC'>&nbsp;</td>" & _
                      "<td class='labelC'>&nbsp;</td>" & _
                      "<td class='labelL'><strong>Total Amount==></strong></td>" & _
                      "<td class='labelC'>&nbsp;</td>" & _
                      "<td class='labelR'><strong>" & Format(vTotal, "###,##0.00") & "</strong></td></tr>"
        vData += "</table>"
        vData += "</body></center></html>"

        vpdfFile = Server.MapPath(".") & "\downloads\" & Session.SessionID & "-union" & vTypeLoan.ToLower & ".html"
        Try
            If IO.File.Exists(vpdfFile) Then
                Kill(vpdfFile)
            End If
        Catch ex As IO.IOException
            vScript = "alert('Error while trying to save HTML file. " & ex.Message.Replace("'", "\'").Replace(vbCrLf, "\n") & "');"
        End Try

        IO.File.WriteAllText(vpdfFile, vData)
        divReport.Attributes.Add("src", "downloads/" & Session.SessionID & "-union" & vTypeLoan.ToLower & ".html")

        'Dim vPrn As New VSPrinter8Lib.VSPrinter
        'Dim vPDF As New VSPDF8Lib.VSPDF8
        'Dim vCompanyName As String = ""
        'Dim vAddress As String = ""
        'Dim c As New SqlClient.SqlConnection(connStr)
        'Dim cm As New SqlClient.SqlCommand
        'Dim cmReport As New SqlClient.SqlCommand
        'Dim rs As SqlClient.SqlDataReader
        'Dim rsReport As SqlClient.SqlDataReader
        'Dim vData As String = ""
        'Dim vFormat As String = ""
        'Dim iCtr As Integer = 1
        'Dim vTotal As Decimal = 0

        'Try
        '    c.Open()
        'Catch ex As SqlClient.SqlException
        '    vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
        '        ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        '    c.Dispose()
        '    cm.Dispose()
        '    cmReport.Dispose()
        '    Exit Sub
        'End Try

        'cm.Connection = c
        'cmReport.Connection = c
        'If cmbOfc.SelectedValue <> "All" Then
        '    cm.CommandText = "SELECT Company_Name, Address,AgencyCd FROM glsyscntrl WHERE CompanyCd='" & cmbOfc.SelectedValue & "'"
        'Else
        '    cm.CommandText = "SELECT TOP 1Company_Name, Address,AgencyCd FROM glsyscntrl"
        'End If

        'Try
        '    rs = cm.ExecuteReader
        '    If rs.Read Then
        '        vCompanyName = IIf(IsDBNull(rs("Company_Name")), "UNKNOWN", rs("Company_Name"))
        '        vAddress = IIf(IsDBNull(rs("Address")), "UNKNOWN", rs("Address"))
        '    End If
        '    rs.Close()
        'Catch ex As SqlClient.SqlException
        '    vScript = "alert('Error occurred while trying to read System Control. Error is: " & _
        '        ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        '    c.Close()
        '    c.Dispose()
        '    cm.Dispose()
        '    cmReport.Dispose()
        '    Exit Sub
        'End Try

        'vPrn.HdrFontSize = 8
        'vPrn.Footer = "||Page %d"
        'vPrn.Action = VSPrinter8Lib.ActionSettings.paStartDoc
        'vPrn.Orientation = VSPrinter8Lib.OrientationSettings.orPortrait
        'vPrn.TableBorder = VSPrinter8Lib.TableBorderSettings.tbAll
        'vPrn.FontSize = 9
        'vPrn.FontBold = True
        'vPrn.FontName = "Arial"
        'vPrn.TextAlign = VSPrinter8Lib.TextAlignSettings.taCenterBottom
        'vPrn.Paragraph = vCompanyName
        'vPrn.FontBold = False
        'vPrn.FontSize = 8
        'vPrn.Paragraph = vAddress
        'vPrn.FontBold = True
        'vPrn.FontSize = 12
        'vPrn.Paragraph = ""
        'vPrn.Paragraph = IIf(pMode = "member", "Members'", "Paying Non-Members'") & " Union Dues Remittance Report"
        'vPrn.FontSize = 9
        'vPrn.Paragraph = "from " & cmbMonth.SelectedItem.Text & " " & cmbDay.SelectedValue & ", " & cmbYear.SelectedValue & _
        '    " to " & cmbMonthTo.SelectedItem.Text & " " & cmbDayTo.SelectedValue & ", " & cmbYearTo.SelectedValue
        'vPrn.Paragraph = ""
        'vPrn.FontSize = 8

        'vFormat = "^+800|^+1300|^+3000|^+1100|^+1400;"
        'vData = "NO.|EMP ID|NAME OF EMPLOYEE|UNION CD|AMOUNT;"
        'vPrn.Table = vFormat & vData
        'vPrn.FontBold = False
        'vData = ""
        'vFormat = "<+800|<+1300|<+3000|<+1100|>+1400;"

        'cm.CommandText = "SELECT Emp_Lname, Emp_Fname, Emp_Cd, UnionCd FROM py_emp_master " & _
        '    " WHERE  Allow_UnionDues=" & IIf(pMode = "member", 1, 0) & " and UnionCd is not null " & _
        '    pFilter & "  ORDER BY Emp_Lname,Emp_Fname"

        'rs = cm.ExecuteReader
        'Do While rs.Read
        '    cmReport.CommandText = "select sum(UnionDues) as TotalUnionDues,UnionCd from py_report where PayDate between '" & _
        '        cmbYear.SelectedValue & "/" & cmbMonth.SelectedValue & "/" & cmbDay.SelectedValue & _
        '        "' and '" & cmbYearTo.SelectedValue & "/" & cmbMonthTo.SelectedValue & "/" & cmbDayTo.SelectedValue & _
        '        "' and Emp_Cd='" & rs("Emp_Cd") & "' group by UnionCd"
        '    rsReport = cmReport.ExecuteReader
        '    Do While rsReport.Read
        '        If Not IsDBNull(rsReport("TotalUnionDues")) Then
        '            If rsReport("TotalUnionDues") <> 0 Then
        '                vData += iCtr & ".|" & rs("Emp_Cd") & "|" & rs("Emp_Lname") & ", " & rs("Emp_Fname") & "|" & rs("UnionCd") & "|" & _
        '                    Format(rsReport("TotalUnionDues"), "##,##0.00") & ";"
        '                iCtr = iCtr + 1
        '                vTotal += rsReport("TotalUnionDues")
        '            End If
        '        End If
        '    Loop
        '    rsReport.Close()
        'Loop
        'rs.Close()
        'c.Close()
        'cm.Dispose()
        'cmReport.Dispose()

        'vData += "||TOTAL AMOUNT==>||" & Format(vTotal, "#,###,##0.00") & ";"
        'vPrn.Table = vFormat & vData
        'vPrn.Action = VSPrinter8Lib.ActionSettings.paEndDoc

        'Dim vFilename As String = Server.MapPath(".") & "\downloads\" & Session.SessionID & "-uniondues.pdf"

        'If IO.File.Exists(vFilename) Then
        '    Try
        '        IO.File.Delete(vFilename)
        '    Catch ex As IO.IOException
        '        vScript = "alert('Error while deleting temp file. " & ex.Message.Replace("'", "\'").Replace(vbCrLf, "\n") & "');"
        '        Exit Sub
        '    End Try
        'End If
        'Try
        '    vPDF.ConvertDocument(vPrn, vFilename)
        '    divReport.Attributes("src") = "downloads/" & Session.SessionID & "-uniondues.pdf"
        'Catch ex as system.exception
        '    vScript = "alert('Error while writing to PDF file. " & ex.Message.Replace("'", "\'").Replace(vbCrLf, "\n") & "');"
        'Finally
        '    vPDF = Nothing
        '    vPrn = Nothing
        'End Try
    End Sub
    Private Sub EPF_PDF(ByVal vEmpList As String)
        Dim vPrn As New VSPrinter8Lib.VSPrinter
        Dim vPDF As New VSPDF8Lib.VSPDF8
        Dim vCompanyName As String = ""
        Dim vAddress As String = ""
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim vData As String = ""
        Dim vFormat As String = ""
        Dim iCtr As Integer = 1

        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c
        If cmbOfc.SelectedValue <> "All" Then
            cm.CommandText = "SELECT Company_Name, Address,AgencyCd FROM glsyscntrl WHERE CompanyCd='" & cmbOfc.SelectedValue & "'"
        Else
            cm.CommandText = "SELECT TOP 1 Company_Name, Address,AgencyCd FROM glsyscntrl"
        End If

        rs = cm.ExecuteReader
        If rs.Read Then
            vCompanyName = IIf(IsDBNull(rs("Company_Name")), "UNKNOWN", rs("Company_Name"))
            vAddress = IIf(IsDBNull(rs("Address")), "UNKNOWN", rs("Address"))
        End If
        rs.Close()
        vPrn.HdrFontSize = 8
        vPrn.Footer = "||Page %d"
        vPrn.Action = VSPrinter8Lib.ActionSettings.paStartDoc
        vPrn.Orientation = VSPrinter8Lib.OrientationSettings.orPortrait
        vPrn.TableBorder = VSPrinter8Lib.TableBorderSettings.tbAll
        vPrn.FontSize = 9
        vPrn.FontBold = True
        vPrn.FontName = "Arial"
        vPrn.TextAlign = VSPrinter8Lib.TextAlignSettings.taCenterBottom
        vPrn.Paragraph = vCompanyName
        vPrn.FontBold = False
        vPrn.FontSize = 8
        vPrn.Paragraph = vAddress
        vPrn.FontBold = True
        vPrn.FontSize = 12
        vPrn.Paragraph = ""
        vPrn.Paragraph = "Employee Pre-validation File"
        vPrn.Paragraph = ""
        vPrn.FontSize = 8

        vFormat = "^+1400|^+900|^+2500|^+1400|^+1400;"
        vData = "NO.|EMP ID|NAME OF EMPLOYEE|SSS No.|BIRTHDAY;"
        vPrn.Table = vFormat & vData
        vPrn.FontBold = False
        vData = ""
        vFormat = "<+1400|<+900|<+2500|<+1400|>+1400;"
        cm.CommandText = "SELECT Emp_Lname, Emp_Fname, Emp_Cd, Sss_No, Bday FROM py_emp_master " & _
            " WHERE  month(Start_Date)=" & cmbMonth.SelectedValue & _
            " and year(Start_Date)=" & cmbYear.SelectedValue & vEmpList & "  ORDER BY Emp_Lname,Emp_Fname"

        rs = cm.ExecuteReader
        Do While rs.Read
            vData += iCtr & "|" & rs("Emp_Cd") & "|" & rs("Emp_Lname") & ", " & rs("Emp_Fname") & "|" & rs("Sss_No") & "|"
            If Not IsDBNull(rs("Bday")) Then
                vData += Format(rs("Bday"), "MM/dd/yyyy") & ";"
            Else
                vData += ";"
            End If
            iCtr = iCtr + 1
        Loop
        rs.Close()
        c.Close()
        cm.Dispose()
        vPrn.Table = vFormat & vData
        vPrn.Action = VSPrinter8Lib.ActionSettings.paEndDoc

        Dim vFilename As String = Server.MapPath(".") & "\downloads\" & Session.SessionID & "-pagibig_report.pdf"

        If IO.File.Exists(vFilename) Then
            Try
                IO.File.Delete(vFilename)
            Catch ex As IO.IOException
                vScript = "alert('Error while deleting temp file. " & ex.Message.Replace("'", "\'").Replace(vbCrLf, "\n") & "');"
                Exit Sub
            End Try
        End If
        Try
            vPDF.ConvertDocument(vPrn, vFilename)
            divReport.Attributes("src") = "downloads/" & Session.SessionID & "-pagibig_report.pdf"
        Catch ex As system.exception
            vScript = "alert('Error while writing to PDF file. " & ex.Message.Replace("'", "\'").Replace(vbCrLf, "\n") & "');"
        Finally
            vPDF = Nothing
            vPrn = Nothing
        End Try
    End Sub
    Private Sub EPF(ByVal pEmpList As String, ByVal pCode As String)
        Dim vOut As String = "00EDIEELST"
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim dr As SqlClient.SqlDataReader
        Dim vTemp As String = ""
        Dim iCtr As Integer = 0

        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c

        If cmbOfc.SelectedValue <> "All" Then
            cm.CommandText = "select Employer_SssNo,Company_Name from glsyscntrl where AgencyCd='" & _
                cmbOfc.SelectedValue & "'"
        Else
            cm.CommandText = "select TOP 1 Employer_SssNo,Company_Name from glsyscntrl"
        End If

        dr = cm.ExecuteReader
        If dr.Read Then
            vOut += Mid(dr("Employer_SssNo"), 1, 10) & Mid(dr("Company_Name"), 1, 30) & vbCrLf
        Else
            vOut += Space(10) & Space(30) & vbCrLf
        End If
        dr.Close()
        'cm.CommandText = "select Emp_Lname,Emp_Fname,Emp_Mname,Sss_No,Bday from py_emp_master " & _
        '    "where Date_Resign is null and DateHold is null and DateSuspended is null and Date_Retired " & _
        '    "is null and Emp_Cd in (" & pEmpList & ") order by Emp_Lname, Emp_Fname"
        'cm.CommandText = "select Emp_Lname,Emp_Fname,Emp_Mname,Sss_No,Bday from py_emp_master " & _
        '    "where Date_Resign is null and DateHold is null and Date_Retired " & _
        '    "is null " & pEmpList & " and Emp_Cd in (select Emp_Cd from py_report where month(paydate)=" & _
        '    cmbMonth.SelectedValue & " AND year(paydate)=" & cmbYear.SelectedValue & ")"

        cm.CommandText = "SELECT Emp_Lname, Emp_Fname, Emp_Mname,Emp_Cd, Sss_No, Bday FROM py_emp_master " & _
           " WHERE  month(Start_Date)=" & cmbMonth.SelectedValue & _
           " and year(Start_Date)=" & cmbYear.SelectedValue & pEmpList & "  ORDER BY Emp_Lname,Emp_Fname"


        'If cmbOfc.SelectedValue <> "All" Then
        '    cm.CommandText += " and Agency_Cd='" & cmbOfc.SelectedValue & "' "
        'Else
        '    cm.CommandText += " and Agency_Cd in ('" & Session("agencylist").ToString.Replace(",", "','") & "') "
        'End If
        'cm.CommandText += " order by Emp_Lname, Emp_Fname"

        dr = cm.ExecuteReader
        Do While dr.Read
            iCtr += 1
            vTemp = IIf(IsDBNull(dr("Sss_No")), Space(10), dr("Sss_No"))
            vTemp = vTemp.Replace("-", "")
            vOut += "20" & Mid(vTemp, 1, 10) & Space(10 - Mid(vTemp, 1, 10).Length)
            vTemp = Mid(IIf(IsDBNull(dr("Emp_Lname")), Space(15), dr("Emp_Lname")), 1, 15)
            vOut += Mid(vTemp, 1, 15) & Space(15 - vTemp.Length)
            vTemp = Mid(IIf(IsDBNull(dr("Emp_Fname")), Space(15), dr("Emp_Fname")), 1, 15)
            vOut += Mid(vTemp, 1, 15) & Space(15 - vTemp.Length)
            vTemp = Mid(IIf(IsDBNull(dr("Emp_Mname")), " ", dr("Emp_Mname")), 1, 1)
            vOut += Mid(vTemp, 1, 1) & Space(1 - vTemp.Length)
            vTemp = IIf(IsDBNull(dr("Bday")), Space(8), dr("Bday"))
            If Trim(vTemp) <> "" Then
                vOut += Format(CDate(vTemp).Month, "00") & Format(CDate(vTemp).Day, "00") & _
                    Format(CDate(vTemp).Year, "0000") & vbCrLf
            Else
                vOut += vbCrLf
            End If
        Loop
        dr.Close()
        cm.Dispose()
        c.Close()
        vOut += "99" & Space(6 - Format(iCtr, "######").Length) & Format(iCtr, "######")

        Dim vFilename As String = Server.MapPath("") & "\downloads\" & Session.SessionID & "-edieelst.txt"
        If IO.File.Exists(vFilename) Then
            Try
                IO.File.Delete(vFilename)
            Catch ex As IO.IOException
                vScript = "alert('Error deleting temp file. " & ex.Message.Replace("'", "\'").Replace(vbCrLf, "\n") & "');"
                Exit Sub
            End Try
        End If
        Try
            IO.File.WriteAllText(vFilename, vOut)
            lnkDownload.NavigateUrl = "downloads/" & Session.SessionID & "-edieelst.txt"
        Catch ex As IO.IOException
            vScript = "alert('Error writing to text file. " & ex.Message.Replace("'", "\'").Replace(vbCrLf, "\n") & "');"
        End Try
    End Sub
    Private Sub PAGIBIG_LOAN(ByVal pEmpList As String, ByVal pCode As String)

        Dim vOut As String = "EH"
        Dim vPer As Single = 0
        Dim vGov As Single = 0
        Dim vSalLoan As Double = 0
        Dim vTypeLoan As String = IIf(pCode = "HDMFLN", "ST", "HL")
        Dim i As Integer
        Dim vEmrSSS As String = ""
        Dim vCompanyName As String = Space(100)
        Dim vAddress As String = Space(100)
        Dim vZip As String = Space(7)
        Dim vTel As String = Space(15)
        Dim vTmp As String = Space(12)
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim vCMonth(12) As String
        Dim vData As String = ""
        Dim vTot As Decimal = 0
        Dim vName As String = "_______________________"
        Dim vPosition As String = ""
        Dim vClass As String = "odd"
        Dim vpdfFile As String = ""

        vCMonth(1) = "January" : vCMonth(2) = "February" : vCMonth(3) = "March" : vCMonth(4) = "April"
        vCMonth(5) = "May" : vCMonth(6) = "June" : vCMonth(7) = "July" : vCMonth(8) = "August"
        vCMonth(9) = "September" : vCMonth(10) = "October" : vCMonth(11) = "November" : vCMonth(12) = "December"
        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c

        If cmbOfc.SelectedValue <> "All" Then
            cm.CommandText = "select Company_Name,Address,Phone,Zip,PagibigBranchCd," & _
                         "Employer_SssNo,Attention,AttentionPos from glsyscntrl where AgencyCd='" & _
                         cmbOfc.SelectedValue & "'"
        Else
            cm.CommandText = "select TOP 1 Company_Name,Address,Phone,Zip,PagibigBranchCd," & _
                         "Employer_SssNo,Attention,AttentionPos from glsyscntrl"
        End If

        rs = cm.ExecuteReader
        rs.Read()

        vCompanyName = IIf(IsDBNull(rs("Company_Name")), Space(100), Mid(rs("Company_Name"), 1, 100))

        vName = IIf(IsDBNull(rs("Attention")), "____________________", rs("Attention"))
        vPosition = IIf(IsDBNull(rs("AttentionPos")), "", rs("AttentionPos"))
        vAddress = IIf(IsDBNull(rs("Address")), Space(100), Mid(rs("Address"), 1, 100))
        vZip = IIf(IsDBNull(rs("Zip")), Space(7), Mid(rs("Zip"), 1, 7))
        vTel = IIf(IsDBNull(rs("Phone")), Space(15), Mid(rs("Phone"), 1, 15))
        vCompanyName = vCompanyName & Space(100 - vCompanyName.Length)
        vAddress = vAddress & Space(100 - vAddress.Length)
        vZip = vZip & Space(7 - vZip.Length)
        vTel = vTel & Space(15 - vTel.Length)
        vOut += IIf(IsDBNull(rs("PagibigBranchCd")), "00", Mid(rs("PagibigBranchCd"), 1, 2)) & _
                Format(cmbYear.SelectedValue, "0000") & _
                Format(cmbMonth.SelectedValue, "00") & _
                Format(Val(IIf(IsDBNull(rs("Employer_SssNo")), 0, rs("Employer_SssNo").ToString.Replace("-", ""))), "000000000000000") & _
                "P" & vTypeLoan & vCompanyName & vAddress & vZip & vTel & vbCrLf

        vData = "<html><head><title>Witholding Tax Report</title><link href='../redtheme/red.css' rel='stylesheet' tyle='text/css'/></head><body><center>"
        vData += "<table border='1' style='border-collapse:collapse;'>"
        vData += "<tr class='titleBar'>" & _
                  "<td class='labelC' colspan='5'><h2>" & Trim(vCompanyName) & "</h2></td></tr>"
        vData += "<tr class='titleBar'>" & _
                  "<td class='labelC' colspan='5'><h4>" & vAddress & "</h4></td></tr>"

        rs.Close()
        cm.CommandText = "select Loan_Name from py_loan_ref where Loan_Cd='" & pCode & "'"
        rs = cm.ExecuteReader
        If rs.Read Then
            'vPrn.Paragraph = vbCrLf & rs("Loan_Name") & " For " & _
            '    vCMonth(cmbMonth.SelectedValue) & ", " & _
            '    Year(Now) & vbCrLf
            vData += "<tr class='titleBar'><td class='labelC' colspan='4'>" & rs("Loan_Name") & " For " & _
                vCMonth(cmbMonth.SelectedValue) & ", " & _
                cmbYear.SelectedValue & "</td></tr>"
        End If
        rs.Close()
        cm.CommandText = "select * from py_syscntrl"
        rs = cm.ExecuteReader
        rs.Read()
        For i = 1 To 60
            If rs("OthDed" & i & "Cd").ToString.ToUpper = pCode.ToUpper Then
                Exit For
            End If
        Next i
        rs.Close()


        cm.CommandText = "select Emp_Cd,Name,sum(Other_Deduct" & i & ") as Amount, " & _
                         "sum(PagIbig_Gov) as Pag_Emr, " & _
                         "cast((SELECT Bday FROM py_emp_master WHERE Emp_Cd=py_report.Emp_Cd) as DATETIME) AS Bday," & _
                         "(SELECT PagIbig_No FROM py_emp_master WHERE Emp_Cd=py_report.Emp_Cd) AS PagIbig_No," & _
                         "(SELECT Emp_Lname FROM py_emp_master WHERE Emp_Cd=py_report.Emp_Cd) AS Emp_Lname," & _
                         "(SELECT Emp_Fname FROM py_emp_master WHERE Emp_Cd=py_report.Emp_Cd) AS Emp_Fname," & _
                         "(SELECT Emp_Mname FROM py_emp_master WHERE Emp_Cd=py_report.Emp_Cd) AS Emp_Mname," & _
                         "(SELECT Tin FROM py_emp_master WHERE Emp_Cd=py_report.Emp_Cd) AS Tin " & _
                         "FROM py_report WHERE Other_Deduct" & i & "<>0 " & pEmpList & _
                         " AND PayDate between '" & cmbYear.SelectedValue & "/" & cmbMonth.SelectedValue & _
                         "/" & cmbDay.SelectedValue & "' and '" & cmbYearTo.SelectedValue & "/" & _
                         cmbMonthTo.SelectedValue & "/" & cmbDayTo.SelectedValue & _
                         "' GROUP BY Emp_Cd,Name ORDER BY Name"

        vData += "<tr class='titleBar'><th>#</th>" & _
                                     "<th>EMP ID</th>" & _
                                     "<th>NAME OF EMPLOYEE</th>" & _
                                     "<th>MO. LOAN AMOUNT</th>" & _
                                     "</tr>"

        rs = cm.ExecuteReader
        i = 1
        Do While rs.Read
            vPer = IIf(IsDBNull(rs("Amount")), 0, rs("Amount"))
            'vGov = IIf(IsDBNull(rs("Pag_Emr")), 0, rs("Pag_Emr"))
            vGov = 0
            vOut += "DT"
            'pagibig no
            vTmp = IIf(IsDBNull(rs("PagIbig_No")), Space(12), Mid(rs("PagIbig_No").ToString.Replace("-", ""), 1, 12))
            vTmp = vTmp & Space(12 - vTmp.Length)
            vOut += vTmp
            'emp id
            vTmp = Mid(rs("Emp_Cd"), 1, 15)
            vTmp = vTmp & Space(15 - vTmp.Length)
            vOut += vTmp
            'last name
            vTmp = Mid(rs("Emp_Lname"), 1, 30)
            vTmp = vTmp & Space(30 - vTmp.Length)
            vOut += vTmp
            'first name
            vTmp = Mid(rs("Emp_Fname"), 1, 30)
            vTmp = vTmp & Space(30 - vTmp.Length)
            vOut += vTmp
            'middle name
            vTmp = Mid(rs("Emp_Mname"), 1, 30)
            vTmp = vTmp & Space(30 - vTmp.Length)
            vOut += vTmp
            'employee share
            vTmp = Space(13 - Format(vPer, "#########0.00").ToString.Length) & Format(vPer, "#########0.00")
            vOut += vTmp
            'employer share
            vTmp = Space(13 - Format(vGov, "##0.00").ToString.Length) & Format(vGov, "##0.00")
            vOut += vTmp
            'tin
            vTmp = IIf(IsDBNull(rs("Tin")), Space(15), Mid(rs("Tin").ToString.Replace("-", ""), 1, 15))
            vTmp = vTmp & Space(15 - vTmp.Length)
            vOut += vTmp
            'bday
            If IsDBNull(rs("Bday")) Then
                vTmp = Space(8)
            Else
                vTmp = Format(rs("Bday"), "yyyy/MM/dd")
            End If
            vTmp = vTmp.Replace("/", "")
            vOut += vTmp & vbCrLf

            vData += "<tr class='" & vClass & "'><td class='labelR'>" & i & ".</td>" & _
                       "<td class='labelL'>" & rs("Emp_Cd") & "</td><td class='labelL'>" & IIf(IsDBNull(rs("Name")), "", _
                    rs("Name")) & "</td><td class='labelR'>" & Format(vPer, "##,##0.00") & "</td></tr>"
            vTot += vPer
            i += 1

            vClass = IIf(vClass = "odd", "even", "odd")
        Loop
        rs.Close()
        cm.Dispose()
        c.Close()

        vData += "<tr class='activeBar'><td class='labelR' colspan='3'>TOTAL</td><td class='labelR'>" & Format(vTot, "###,##0.00") & "</td></tr>"
        vData += "</br></br>"
        vData += "<tr><td class='labelR' colspan='2' valign='top'>Certified Correct:</td><td colspan='2' class='labelC'>" & vName & "</br>____________________</br>" & vPosition & "</td></tr>"


        vData += "</body></center></html>"
        Dim vFilename As String = Server.MapPath(".") & "\downloads\" & Session.SessionID & "-pagibig" & vTypeLoan & ".txt"

        If IO.File.Exists(vFilename) Then
            Try
                IO.File.Delete(vFilename)
            Catch ex As IO.IOException
                vScript = "alert('Error occurred while trying to delete temp file. " & _
                    ex.Message.Replace("'", "\'").Replace(vbCrLf, "\n") & "');"
            End Try
        End If
        Try
            IO.File.WriteAllText(vFilename, vOut)
        Catch ex As IO.IOException
            vScript = "alert('Error occurred while trying to save text file. " & ex.Message.Replace("'", "\'").Replace(vbCrLf, "\n") & "');"
        End Try

        lnkDownload.NavigateUrl = "downloads/" & Session.SessionID & "-pagibig" & vTypeLoan & ".txt"

        vpdfFile = Server.MapPath(".") & "\downloads\" & Session.SessionID & "-pagibig" & vTypeLoan.ToLower & ".html"
        Try
            If IO.File.Exists(vpdfFile) Then
                Kill(vpdfFile)
            End If
        Catch ex As system.exception
            vScript = "alert('Error while trying to save PDF file. " & ex.Message.Replace("'", "\'").Replace(vbCrLf, "\n") & "');"
        End Try

        IO.File.WriteAllText(vpdfFile, vData)
        divReport.Attributes.Add("src", "downloads/" & Session.SessionID & "-pagibig" & vTypeLoan.ToLower & ".html")

    End Sub

    Private Sub SSS_EDINET(ByVal pFilter As String)
        Dim vCompanyName As String = ""
        Dim vAddress As String = ""
        Dim vLname As String = ""
        Dim vFname As String = ""
        Dim vMI As String = " "
        Dim vCount As Integer = 1
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cmRef As New SqlClient.SqlCommand
        Dim dr As SqlClient.SqlDataReader
        Dim drRef As SqlClient.SqlDataReader
        Dim vData As String = ""
        Dim vFormat As String = ""
        Dim v_tot(3) As Decimal
        Dim vTotal As Decimal = 0
        Dim vEc As Decimal = 0
        Dim vPer As Decimal = 0
        Dim vGov As Decimal = 0
        Dim vOut As String = ""
        Dim vDate As String = ""
        Dim vSSS As String = ""
        Dim vTrailer As String = ""
        Dim vClass As String = "odd"
        Dim Count As Integer = 0
        Dim vPdfFile As String = ""
        v_tot(0) = 0
        v_tot(1) = 0
        v_tot(2) = 0
        v_tot(3) = 0

        c.ConnectionString = connStr
        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "\n").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            cmRef.Dispose()
            Exit Sub
        End Try

        cm.Connection = c
        cmRef.Connection = c

        If cmbOfc.SelectedValue <> "All" Then
            cm.CommandText = "select Company_Name,Address,AgencyCd,HeaderNo,TrailerNo,Employer_SssNo,StubNo from " & _
                "glsyscntrl where AgencyCd='" & cmbOfc.SelectedValue & "'"
        Else
            cm.CommandText = "select TOP 1 Company_Name,Address,AgencyCd,HeaderNo,TrailerNo,Employer_SssNo,StubNo from " & _
                "glsyscntrl"
        End If

        dr = cm.ExecuteReader

        If dr.Read() Then
            vTrailer = IIf(IsDBNull(dr("TrailerNo")), "", dr("TrailerNo"))
            vCompanyName = IIf(IsDBNull(dr("Company_Name")), "UNKNOWN", dr("Company_Name"))
            vAddress = IIf(IsDBNull(dr("Address")), "UNKNOWN", dr("Address"))
        End If

        If vTrailer = "" And IsDBNull(dr("HeaderNo")) Then
            dr.Close()
            cm.Dispose()
            cmRef.Dispose()
            c.Close()
            c.Dispose()
            vScript = "alert('Trailer and Header numbers are empty. Please set it up first.');"
            Response.Write("Trailer and Header numbers are empty. Please set it up first.")
            Exit Sub
        End If

        vData = "<html><head><title>SSS Remittance Report</title><link href='../redtheme/red.css' rel='stylesheet' type='text/css' /></head><body><center>"
        vData += "<h2>" & vCompanyName & "</h2>"
        vData += "<h5>" & vAddress & "</h5>"
        vData += "<h3>SSS Contribution Report</h3>"
        vData += "<h4>For the Month of : " & cmbMonth.SelectedItem.Text & ", " & cmbYear.SelectedValue & "</h4>"
        vData += "<table border='1' style='border-collapse:collapse;width:100%;' class='label'><tr class='titleBar'>" & _
                 "<th>#</th><th>SSS NO.</th><th>EMP ID</th>" & _
                 "<th>NAME OF EMPLOYEE</th><th>EMP. SHARE</th>" & _
                 "<th>EMR. SHARE</th><th>EC</th><th>TOTAL</th></tr>"

        vOut = "00   1" & Format(Val(dr("HeaderNo")), "000000") & Space(9) & Format(Now, "yyyyMMdd") & _
            Format(Val(cmbYear.SelectedValue), "0000") & Format(Val(cmbMonth.SelectedValue), "00") & _
            Mid(vCompanyName, 1, 40) & Space(40 - Len(Mid(vCompanyName, 1, 40))) & _
            Mid(dr("Employer_SssNo").ToString.Replace("-", ""), 1, 10) & Space(3) & _
            dr("StubNo") & vbNewLine

        dr.Close()

        cm.CommandText = "select Emp_Cd,Name, sum(Sss_Per) as Sss_Emp, sum(Sss_Gov) as Sss_Emr, " & _
                         "sum(Ec) as E_C from py_report where PayDate between '" & _
                         cmbYear.SelectedValue & "/" & cmbMonth.SelectedValue & "/" & cmbDay.SelectedValue & _
                         "' and '" & cmbYearTo.SelectedValue & "/" & cmbMonthTo.SelectedValue & "/" & cmbDayTo.SelectedValue & _
                         "' " & pFilter & "  group by Name,Emp_Cd order by Name"

        dr = cm.ExecuteReader
        v_tot(0) = 0 : v_tot(1) = 0 : v_tot(2) = 0 : v_tot(3) = 0
        Dim total As String
        Dim vPadding As Integer

        Do While dr.Read
            vEc = IIf(IsDBNull(dr("E_C")), 0, dr("E_C"))
            vPer = IIf(IsDBNull(dr("Sss_Emp")), 0, dr("Sss_Emp"))
            vGov = IIf(IsDBNull(dr("Sss_Emr")), 0, dr("Sss_Emr"))
            vTotal = vPer + vGov + vEc

            If vTotal <> 0 Then
                vSSS = Space(10)

                cmRef.CommandText = "select Sss_No,Emp_Fname,Emp_Lname,Emp_Mname,Start_Date,Date_Resign from py_emp_master where " & _
                                    "Emp_Cd='" & dr("Emp_Cd") & "' " & rdoSSOption.SelectedValue
                drRef = cmRef.ExecuteReader

                If drRef.Read Then
                    If Not IsDBNull(drRef("Sss_No")) Then
                        vSSS = Format(Val(Mid(Replace(drRef("Sss_No"), "-", ""), 1, 10)), "0000000000")
                    End If
                    vLname = drRef("Emp_Lname").ToString.ToUpper
                    vLname = Mid(vLname.Replace(Chr(165), "N"), 1, 20)
                    vLname = vLname & Space(20 - Len(vLname))

                    vFname = drRef("Emp_Fname").ToString.ToUpper
                    vFname = Mid(vFname.Replace(Chr(165), "N"), 1, 20)
                    vFname = vFname & Space(20 - Len(vFname))

                    vMI = Mid(drRef("Emp_Mname"), 1, 1).ToUpper
                    vMI = IIf(Asc(vMI) >= 65 And Asc(vMI) <= 90, vMI, " ")  'change special characters to blank

                    'vOut += "20" & vLname & Space(15 - Len(vLname)) & vFname & Space(15 - Len(vFname)) & _
                    '    vMI & vSSS
                    total = Format(vPer + vGov, "####0.00")
                    vPadding = 8 - total.ToString.Length

                    vOut += "20   " & vLname & vFname & vMI & vSSS & Space(vPadding) & total & _
                        Space(5 - vEc.ToString.Length) & Format(vEc, "####0.00")

                    If Not IsDBNull(drRef("Date_Resign")) Then      'separated
                        vOut += Format(CDate(drRef("Date_Resign")), "yyyyMMdd") & "2" & vbNewLine
                    Else
                        If Not IsDBNull(drRef("Start_Date")) Then
                            vOut += Format(CDate(drRef("Start_Date")), "yyyyMMdd")
                            If CDate(drRef("Start_Date")).Month = cmbMonth.SelectedValue And _
                               CDate(drRef("Start_Date")).Year = cmbYear.SelectedValue Then   'employee is newly hired for that month
                                vOut += "1" & vbNewLine
                            Else
                                'vOut += "3" & vbNewLine
                                vOut += "N" & vbNewLine
                            End If
                        Else
                            vOut += "No Date Hired" & vbNewLine
                        End If
                    End If

                    vData += "<tr class='" & vClass & "'><td class='labelR'>" & vCount & ".</td><td class='labelR'>" & IIf(IsDBNull(drRef("Sss_No")), "", drRef("Sss_No")) & _
                        "</td><td class='labelL'>" & dr("Emp_Cd") & "</td><td class='labelL'>" & dr("Name") & "</td><td class='labelR'>" & Format(vPer, "##,##0.00") & _
                        "</td><td class='labelR'>" & Format(vGov, "##,##0.00") & "</td><td class='labelR'>" & Format(vEc, "##,##0.00") & _
                        "</td><td class='labelR'>" & Format(vTotal, "###,##0.00") & "</td></tr>"

                    v_tot(0) += vPer
                    v_tot(1) += vGov
                    v_tot(2) += vEc
                    v_tot(3) += (vPer + vGov + vEc)
                    vCount += 1
                    vClass = IIf(vClass = "odd", "even", "odd")
                End If
                drRef.Close()
            End If
        Loop
        dr.Close()

        vData += "<tr class='activeBar' style='font-weight:bold;'><td colspan='4' align='right'>Grand Total</td><td align='right'>" & Format(v_tot(0), "#,###,##0.00") & "</td>" & _
                 "<td align='right'>" & Format(v_tot(1), "#,###,##0.00") & "</td><td align='right'>" & Format(v_tot(2), "#,###,##0.00") & _
                "</td><td align='right'>" & Format(v_tot(3), "#,###,##0.00") & "</td></tr>"
        vData += "</table></center></body></html>"
        cm.Dispose()
        cmRef.Dispose()
        c.Close()
        c.Dispose()

        vOut += "99   " & Space(11 - (v_tot(0) + v_tot(1)).ToString.Length) & Format(v_tot(0) + v_tot(1), "########0.00") & _
            Space(9 - v_tot(2).ToString.Length) & Format(v_tot(2), "#####0.00") & Format(Val(vTrailer), "00000000") & Space(7)

        Dim vFilename As String = Server.MapPath(".") & "\downloads\" & Session.SessionID & "-nr3001dk.txt"

        IO.File.WriteAllText(vFilename, vOut)

        lnkDownload.NavigateUrl = "downloads/" & Session.SessionID & "-nr3001dk.txt"


        vPdfFile = Server.MapPath(".") & "\downloads\" & Session.SessionID & "-sss_report.html"
        Try
            If IO.File.Exists(vPdfFile) Then
                Kill(vPdfFile)
            End If
        Catch ex As system.exception
            vScript = "alert('An error occurred while trying to save to HTML file. Error code is:\n" & _
                ex.Message.Replace("'", "") & "');"
        End Try
        IO.File.WriteAllText(vPdfFile, vData)
        'vScript = "document.getElementById('frame').src = 'downloads/" & Session.SessionID & "-sss_report.html';"
        divReport.Attributes.Add("src", "downloads/" & Session.SessionID & "-sss_report.html")
    End Sub
    Private Sub SSS_REMIT_MONTHLY(ByVal pFilter As String)
        Dim vCompanyName As String = ""
        Dim vAddress As String = ""
        Dim vEmrSSSNo As String = ""
        Dim vLname As String = ""
        Dim vFname As String = ""
        Dim vMI As String = " "
        Dim vCount As Integer = 1
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cmRef As New SqlClient.SqlCommand
        Dim dr As SqlClient.SqlDataReader
        Dim drRef As SqlClient.SqlDataReader
        Dim vData As String = ""
        Dim vFormat As String = ""
        Dim v_tot(3) As Decimal
        Dim vTotal As Decimal = 0
        Dim vEc As Decimal = 0
        Dim vPer As Decimal = 0
        Dim vGov As Decimal = 0
        Dim vOut As String = ""
        Dim vDate As String = ""
        Dim vSSS As String = ""
        Dim vTrailer As String = ""
        Dim vClass As String = "odd"
        Dim Count As Integer = 0
        Dim vPdfFile As String = ""
        v_tot(0) = 0
        v_tot(1) = 0
        v_tot(2) = 0
        v_tot(3) = 0

        c.ConnectionString = connStr
        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "\n").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            cmRef.Dispose()
            Exit Sub
        End Try

        cm.Connection = c
        cmRef.Connection = c

        If cmbOfc.SelectedValue <> "All" Then
            cm.CommandText = "select Company_Name,Address,AgencyCd,HeaderNo,TrailerNo,Employer_SssNo,StubNo from " & _
                "glsyscntrl where AgencyCd='" & cmbOfc.SelectedValue & "'"
        Else
            cm.CommandText = "select TOP 1 Company_Name,Address,AgencyCd,HeaderNo,TrailerNo,Employer_SssNo,StubNo from " & _
                "glsyscntrl"
        End If

        dr = cm.ExecuteReader

        If dr.Read() Then
            vTrailer = IIf(IsDBNull(dr("TrailerNo")), "", dr("TrailerNo"))
            vCompanyName = IIf(IsDBNull(dr("Company_Name")), "UNKNOWN", dr("Company_Name"))
            vAddress = IIf(IsDBNull(dr("Address")), "UNKNOWN", dr("Address"))
        End If

        If vTrailer = "" And IsDBNull(dr("HeaderNo")) Then
            dr.Close()
            cm.Dispose()
            cmRef.Dispose()
            c.Close()
            c.Dispose()
            vScript = "alert('Trailer and Header numbers are empty.Please set it up first.');"
            Exit Sub
        End If

        vData = "<html><head><title>SSS Remittance Report</title><link href='../redtheme/red.css' rel='stylesheet' type='text/css' /></head><body><center>"
        vData += "<h2>" & vCompanyName & "</h2>"
        vData += "<h5>" & vAddress & "</h5>"
        vData += "<h3>SSS Contribution Report</h3>"
        vData += "<h4>For the Month of : " & cmbMonth.SelectedItem.Text & ", " & cmbYear.SelectedValue & "</h4>"
        vData += "<table border='1' style='border-collapse:collapse;width:100%' class='label'><tr class='titleBar'>" & _
                 "<th>#</th><th>SSS NO.</th><th>EMP ID</th>" & _
                 "<th>NAME OF EMPLOYEE</th><th>EMP. SHARE</th>" & _
                 "<th>EMR. SHARE</th><th>EC</th><th>TOTAL</th></tr>"

        vEmrSSSNo = dr("Employer_SssNo").ToString.Replace("-", "")
        vEmrSSSNo = Mid(vEmrSSSNo, 1, 10) & Space(10 - Len(vEmrSSSNo))
        vOut = "00" & Mid(dr("Company_Name"), 1, 30) & Space(30 - Len(Mid(dr("Company_Name"), 1, 30))) & _
            Format(Val(cmbMonth.SelectedValue), "00") & cmbYear.SelectedValue & vEmrSSSNo & Space(68) & vbNewLine
        dr.Close()


        cm.CommandText = "select Emp_Cd,Name, sum(Sss_Per) as Sss_Emp, sum(Sss_Gov) as Sss_Emr, " & _
                         "sum(Ec) as E_C from py_report where PayDate between '" & _
                         cmbYear.SelectedValue & "/" & cmbMonth.SelectedValue & "/" & cmbDay.SelectedValue & _
                         "' and '" & cmbYearTo.SelectedValue & "/" & cmbMonthTo.SelectedValue & "/" & cmbDayTo.SelectedValue & _
                         "' " & pFilter & "  group by Name,Emp_Cd order by Name"
        dr = cm.ExecuteReader
        v_tot(0) = 0 : v_tot(1) = 0 : v_tot(2) = 0 : v_tot(3) = 0
        Dim total As String
        Dim vPadding As Integer

        Do While dr.Read
            vEc = IIf(IsDBNull(dr("E_C")), 0, dr("E_C"))
            vPer = IIf(IsDBNull(dr("Sss_Emp")), 0, dr("Sss_Emp"))
            vGov = IIf(IsDBNull(dr("Sss_Emr")), 0, dr("Sss_Emr"))
            vTotal = vPer + vGov + vEc

            If vTotal <> 0 Then
                vSSS = Space(10)

                cmRef.CommandText = "select Sss_No,Emp_Fname,Emp_Lname,Emp_Mname,Start_Date from py_emp_master where " & _
                                    "Emp_Cd='" & dr("Emp_Cd") & "' " & rdoSSOption.SelectedValue
                drRef = cmRef.ExecuteReader

                If drRef.Read Then
                    If Not IsDBNull(drRef("Sss_No")) Then
                        vSSS = Format(Val(Mid(Replace(drRef("Sss_No"), "-", ""), 1, 10)), "0000000000")
                    End If
                    vLname = drRef("Emp_Lname").ToString.ToUpper
                    vLname = Mid(vLname.Replace(Chr(165), "N"), 1, 15)

                    vFname = drRef("Emp_Fname").ToString.ToUpper
                    vFname = Mid(vFname.Replace(Chr(165), "N"), 1, 15)
                    vMI = Mid(drRef("Emp_Mname"), 1, 1).ToUpper
                    vMI = IIf(Asc(vMI) >= 65 And Asc(vMI) <= 90, vMI, " ")  'change special characters to blank
                    vOut += "20" & vLname & Space(15 - Len(vLname)) & vFname & Space(15 - Len(vFname)) & _
                        vMI & vSSS

                    '7 - is the standard length in the format of vPer+vGov
                    total = Format(vPer + vGov, "###0.00")
                    vPadding = 7 - total.ToString.Length
                    If vPadding < 1 Then
                        vPadding = 0
                    End If
                    Select Case Val(cmbMonth.SelectedValue)

                        Case 1, 4, 7, 10  'first quarter
                            vOut += Space(1) & Space(vPadding) & total & Space(4) & "0.00" & Space(4) & "0.00" & _
                                Space(2) & "0.00" & Space(2) & "0.00" & Space(2) & "0.00" & Space(1) & _
                                Format(vEc, "00.00") & Space(2) & "0.00" & Space(2) & "0.00" & Space(6) & "N"
                        Case 2, 5, 8, 11  'second quarter
                            vOut += Space(4) & "0.00" & Space(1) & Space(vPadding) & total & Space(4) & "0.00" & _
                                Space(2) & "0.00" & Space(2) & "0.00" & Space(2) & "0.00" & Space(2) & _
                                "0.00" & Space(1) & Format(vEc, "00.00") & Space(2) & "0.00" & Space(6) & "N"
                        Case 3, 6, 9, 12  'third quarter
                            vOut += Space(4) & "0.00" & Space(4) & "0.00" & Space(1) & Space(vPadding) & total & _
                                Space(2) & "0.00" & Space(2) & "0.00" & Space(2) & "0.00" & Space(2) & _
                                "0.00" & Space(2) & "0.00" & Space(1) & Format(vEc, "00.00") & Space(6) & "N"
                    End Select
                    If Not IsDBNull(drRef("Start_Date")) Then
                        If Month(drRef("Start_Date")) = cmbMonth.SelectedValue And Year(drRef("Start_Date")) = cmbYear.SelectedValue Then
                            'vOut += Format(drRef("Start_Date"), "MMddyy") & vbNewLine
                            vOut += vbNewLine
                        Else
                            'vOut += "0     " & vbNewLine
                            vOut += vbNewLine
                        End If
                    Else
                        'vOut += "0     " & vbNewLine
                        vOut += vbNewLine
                    End If

                    vData += "<tr class='" & vClass & "'><td class='labelR'>" & vCount & ".</td><td class='labelR'>" & IIf(IsDBNull(drRef("Sss_No")), "", drRef("Sss_No")) & _
                        "</td><td class='labelL'>" & dr("Emp_Cd") & "</td><td class='labelL'>" & dr("Name") & "</td><td class='labelR'>" & Format(vPer, "##,##0.00") & _
                        "</td><td class='labelR'>" & Format(vGov, "##,##0.00") & "</td><td class='labelR'>" & Format(vEc, "##,##0.00") & _
                        "</td><td class='labelR'>" & Format(vTotal, "###,##0.00") & "</td></tr>"

                    v_tot(0) += vPer
                    v_tot(1) += vGov
                    v_tot(2) += vEc
                    v_tot(3) += (vPer + vGov + vEc)
                    vCount += 1
                    vClass = IIf(vClass = "odd", "even", "odd")
                End If
                drRef.Close()
            End If
        Loop
        dr.Close()

        vData += "<tr class='activeBar' style='font-weight:bold;'><td colspan='4' align='right'>Grand Total</td><td align='right'>" & Format(v_tot(0), "#,###,##0.00") & "</td>" & _
                 "<td align='right'>" & Format(v_tot(1), "#,###,##0.00") & "</td><td align='right'>" & Format(v_tot(2), "#,###,##0.00") & _
                "</td><td align='right'>" & Format(v_tot(3), "#,###,##0.00") & "</td></tr>"
        vData += "</table></center></body></html>"
        cm.Dispose()
        cmRef.Dispose()
        c.Close()
        c.Dispose()

        Select Case Val(cmbMonth.SelectedValue)
            Case 1, 4, 7, 10
                vOut += "99" & Space(2) & Format(v_tot(0) + v_tot(1), "0000000.00") & Space(8) & "0.00" & Space(8) & "0.00" & _
                    Space(6) & "0.00" & Space(6) & "0.00" & Space(6) & "0.00" & _
                    Space(1) & Format(v_tot(2), "000000.00") & Space(6) & "0.00" & Space(6) & "0.00"
                'Space(2) & Format(v_tot(2), "000000.00") & Space(6) & "0.00" & Space(6) & "0.00" '& Space(18)
            Case 2, 5, 8, 11
                vOut += "99" & Space(8) & "0.00" & Space(2) & Format(v_tot(0) + v_tot(1), "0000000.00") & Space(8) & "0.00" & _
                    Space(6) & "0.00" & Space(6) & "0.00" & Space(6) & "0.00" & _
                    Space(6) & "0.00" & Space(1) & Format(v_tot(2), "000000.00") & Space(6) & "0.00"
                'Space(6) & "0.00" & Space(2) & Format(v_tot(2), "000000.00") & Space(6) & "0.00" & Space(18)
            Case 3, 6, 9, 12
                vOut += "99" & Space(8) & "0.00" & Space(8) & "0.00" & Space(2) & Format(v_tot(0) + v_tot(1), "0000000.00") & _
                    Space(6) & "0.00" & Space(6) & "0.00" & Space(6) & "0.00" & _
                    Space(6) & "0.00" & Space(6) & "0.00" & Space(1) & Format(v_tot(2), "000000.00")
                'Space(6) & "0.00" & Space(6) & "0.00" & Space(1) & Format(v_tot(2), "000000.00") & Space(18)
        End Select

        Dim vFilename As String = Server.MapPath(".") & "\downloads\" & Session.SessionID & "-nr3001dk.txt"

        IO.File.WriteAllText(vFilename, vOut)

        lnkDownload.NavigateUrl = "downloads/" & Session.SessionID & "-nr3001dk.txt"


        vPdfFile = Server.MapPath(".") & "\downloads\" & Session.SessionID & "-sss_report.html"
        Try
            If IO.File.Exists(vPdfFile) Then
                Kill(vPdfFile)
            End If
        Catch ex As system.exception
            vScript = "alert('An error occurred while trying to save to HTML file. Error code is:\n" & _
                ex.Message.Replace("'", "") & "');"
        End Try
        IO.File.WriteAllText(vPdfFile, vData)
        'vScript = "document.getElementById('frame').src = 'downloads/" & Session.SessionID & "-sss_report.html';"
        divReport.Attributes.Add("src", "downloads/" & Session.SessionID & "-sss_report.html")

    End Sub

    Private Sub LOAN_REMITTANCE(ByVal p_loancd As String, ByVal pEmplist As String)
        Dim v_tot As Double = 0
        Dim vDate As Date
        Dim vLoanAmt As Double = 0
        Dim iCtr As Integer = 0
        Dim vIndex As Integer
        Dim vOut As String = ""
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cmRef As New SqlClient.SqlCommand
        Dim cmLoans As New SqlClient.SqlCommand
        Dim drLoans As SqlClient.SqlDataReader
        Dim drRef As SqlClient.SqlDataReader
        Dim dr As SqlClient.SqlDataReader
        'Dim vRpt As New VSPDF8Lib.VSPDF8
        'Dim vPrn As New VSPrinter8Lib.VSPrinter
        Dim vCMonth() As String = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"}
        Dim vFormat As String = ""
        Dim vData As New StringBuilder
        Dim vPdfFile As String = ""
        Dim vCompanyName As String = ""
        Dim vAddress As String = ""
        Dim vClass As String = "odd"
        Dim vLoanName As String = p_loancd

        c.ConnectionString = connStr

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            cmRef.Dispose()
            cmLoans.Dispose()
            Exit Sub
        End Try

        cmRef.Connection = c
        cmLoans.Connection = c
        cm.Connection = c

        cm.CommandText = "select * from py_syscntrl"
        dr = cm.ExecuteReader
        dr.Read()
        vIndex = 0
        For iCtr = 1 To 60
            If Not IsDBNull(dr("OthDed" & iCtr & "Cd")) Then
                If dr("OthDed" & iCtr & "Cd").ToString.ToLower = p_loancd Then
                    vIndex = iCtr
                    Exit For
                End If
            End If
        Next iCtr
        dr.Close()

        If vIndex = 0 Then
            vScript = "alert('Loan reference not found in system control parameter.');"
            cm.Dispose()
            c.Close()
            c.Dispose()
            cm.Dispose()
            cmRef.Dispose()
            cmLoans.Dispose()
            Exit Sub
        End If

        'vPrn.Action = VSPrinter8Lib.ActionSettings.paStartDoc
        'vPrn.Orientation = VSPrinter8Lib.OrientationSettings.orPortrait
        'vPrn.TableBorder = VSPrinter8Lib.TableBorderSettings.tbAll
        'vPrn.FontSize = 8
        'vPrn.FontName = "Arial"
        'vPrn.TextAlign = VSPrinter8Lib.TextAlignSettings.taCenterBottom

        If cmbOfc.SelectedValue <> "All" Then
            cm.CommandText = "select Employer_SssNo,Company_Name,Address from glsyscntrl where AgencyCd='" & _
                cmbOfc.SelectedValue & "'"
        Else
            cm.CommandText = "select TOP 1 Employer_SssNo,Company_Name,Address from glsyscntrl"
        End If

        dr = cm.ExecuteReader
        If dr.Read() Then
            'vPrn.FontBold = True '
            vCompanyName = IIf(IsDBNull(dr("Company_Name")), "Unknown Company", dr("Company_Name"))
            'vPrn.FontBold = False
            vAddress = IIf(IsDBNull(dr("Address")), "Unknown Address", dr("Address"))
            vOut = "00" & Mid(dr("Employer_SssNo").ToString.Replace("-", ""), 1, 10) & Mid(dr("Company_Name"), 1, 30) & _
                Space(30 - Len(Mid(dr("Company_Name"), 1, 30))) & _
                Format(Now.Year - 2000, "00") & Format(Val(cmbMonth.SelectedValue), "00") & vbCrLf
        Else
            vCompanyName = "Unknown Company"
            vCompanyName = "Unknown Address"
        End If

        dr.Close()

        cm.CommandText = "select Loan_Name from py_loan_ref where Loan_Cd='" & p_loancd & "'"

        dr = cm.ExecuteReader
        If dr.Read Then
            vLoanName = dr("Loan_Name")
        End If
        dr.Close()

        vData.AppendLine("<html><head><title>Remittance Report for " & vLoanName & _
            "</title><link href='../redtheme/red.css' rel='stylesheet' tyle='text/css'/></head><body><center>")
        vData.AppendLine("<h2>" & vCompanyName & "</h2>" & _
                "<h4>" & vAddress & "</h4>" & _
                "<h3>for the period " & cmbMonth.SelectedValue & "/" & cmbDay.SelectedValue & "/" & cmbYear.SelectedValue & _
                "-" & cmbMonthTo.SelectedValue & "/" & cmbDayTo.SelectedValue & "/" & cmbYearTo.SelectedValue & "</h3><hr/>")


        'vPrn.TextAlign = VSPrinter8Lib.TextAlignSettings.taJustBottom
        cm.CommandText = "select Emp_Cd,Name,sum(Other_Deduct" & vIndex & ") as Tot_Ded " & _
                         "from py_report WHERE Other_Deduct" & vIndex & " <> 0 and PayDate between '" & _
                         cmbYear.SelectedValue & "/" & cmbMonth.SelectedValue & "/" & cmbDay.SelectedValue & _
                         "' AND '" & cmbYearTo.SelectedValue & "/" & cmbMonthTo.SelectedValue & "/" & _
                         cmbDayTo.SelectedValue & "' " & pEmplist & " GROUP BY Emp_Cd,Name ORDER BY Name"

        dr = cm.ExecuteReader
        'vFormat = "^+1000|^+1200|^+6000|^+2000;"
        vData.AppendLine("<table class='label' border='1' style='border-collapse:collapse; width:100%;'>" & _
                     "<tr class='titleBar'>" & _
                     "<th>LINE #</th>" & _
                     "<th>EMP ID</th>" & _
                     "<th>NAME OF EMPLOYEE</th>" & _
                     "<th>AMOUNT</th></tr>")

        'vPrn.Table = vFormat & vData
        'vFormat = ">+1000|<+1200|<+6000|>+2000;"

        iCtr = 0
        Do While dr.Read
            iCtr += 1
            cmRef.CommandText = "select Emp_Fname,Emp_Mname,Emp_Lname,Sss_No from py_emp_master where Emp_Cd='" & _
               dr("Emp_Cd") & "'"
            drRef = cmRef.ExecuteReader
            If drRef.Read Then
                cmLoans.CommandText = "select Loan_Date,Amt_Loan from py_loan_hdr where Emp_Cd='" & dr("Emp_Cd") & _
                   "' and Loan_Cd='" & p_loancd & "' and Active=1"
                drLoans = cmLoans.ExecuteReader
                If drLoans.Read Then
                    vDate = drLoans(0)
                    vLoanAmt = IIf(IsDBNull(drLoans(1)), 0, drLoans(1))
                End If
                drLoans.Close()
                vData.AppendLine("<tr class='" & vClass & "'>" & _
                             "<td class='labelR'>" & iCtr & ".</td>" & _
                             "<td class='labelL'>" & dr("Emp_Cd") & "</td>" & _
                             "<td class='labelL'>" & IIf(IsDBNull(dr("Name")), "", dr("Name")) & "</td>" & _
                             "<td class='labelL'>" & Format(dr("Tot_Ded"), "#,###,##0.00") & "</td></tr>")

                'vData += iCtr & ".|" & dr("Emp_Cd") & "|" & IIf(IsDBNull(dr("Name")), "", dr("Name")) & "|" & _
                'Format(dr("Tot_Ded"), "#,###,##0.00") & ";"

                v_tot += dr("Tot_Ded")

                vOut += "10" & Mid(Replace(IIf(IsDBNull(drRef("Sss_No")), "0000000000", drRef("Sss_No")), "-", ""), 1, 10) & _
                    Mid(drRef("Emp_Lname"), 1, 15) & Space(15 - Len(Mid(drRef("Emp_Lname"), 1, 15))) & _
                    Mid(drRef("Emp_Fname"), 1, 15) & Space(15 - Len(Mid(drRef("Emp_Fname"), 1, 15))) & _
                    Mid(drRef("Emp_Mname"), 1, 1) & " S"

                If vDate.Year < 2000 Then
                    vOut += Format(vDate.Year - 1900, "00")
                Else
                    vOut += Format(vDate.Year - 2000, "00")
                End If

                vOut += Format(vDate, "MMdd") & _
                    Format(vLoanAmt * 100, "00000000") & _
                    Format(dr("Tot_Ded") * 100, "000000000000") & vbCrLf
            End If
            vclass = IIf(vclass = "odd", "even", "odd")
            drRef.Close()
        Loop
        dr.Close()
        cm.Dispose()
        cmRef.Dispose()
        cmLoans.Dispose()
        c.Close()

        c.Dispose()
        cm.Dispose()
        cmRef.Dispose()
        cmLoans.Dispose()

        vOut += "99" & Format(iCtr, "0000") & Format(v_tot * 100, "000000000000000000") & vbCrLf

        'vPrn.Table = vFormat & vData

        'vPrn.FontBold = True
        vData.AppendLine("<tr class='activeBar'><td colspan='3' class='labelR'>TOTAL</td>" & _
                 "<td class='labelL'>" & Format$(v_tot, "##,###,##0.00") & "</td></tr></table><br/><br/><br/>")
        'vData = "||TOTAL:|" & Format(v_tot, "##,###,##0.00") & ";"
        'vPrn.Table = vFormat & vData
        'vPrn.FontBold = False
        'vPrn.Paragraph = vbCrLf & vbCrLf & vbCrLf

        vData.AppendLine("Certified Correct:<br/><br/><br/><br/>___________________</br>ACCOUNTANT" & _
            "</body></center></html>")
        'vPrn.Paragraph = "Certified Correct:" & vbCrLf & vbCrLf & vbCrLf & vbCrLf
        'vPrn.Paragraph = "___________________"
        'vPrn.Paragraph = "ACCOUNTANT"
        'vPrn.Action = VSPrinter8Lib.ActionSettings.paEndDoc


        Dim vFilename As String = Server.MapPath(".") & "\downloads\" & Session.SessionID & "-" & p_loancd & ".txt"
        If IO.File.Exists(vFilename) Then
            Try
                IO.File.Delete(vFilename)
            Catch ex As IO.IOException
                vScript = "alert('Error while trying to delete temp file. " & ex.Message.Replace("'", "\'").Replace(vbCrLf, "\n") & "');"
                GoTo skip
            End Try
        End If
        Try
            IO.File.WriteAllText(vFilename, vOut)

        Catch ex As IO.IOException
            vScript = "alert('Error while writing to text file. " & ex.Message.Replace("'", "\'").Replace(vbCrLf, "\n") & "');"
        End Try
skip:
        lnkDownload.NavigateUrl = "downloads/" & Session.SessionID & "-" & p_loancd & ".txt"

        'Try
        '    vRpt.ConvertDocument(vPrn, Server.MapPath(".") & "\downloads\" & Session.SessionID & "-" & p_loancd & ".pdf")
        'Catch ex as system.exception
        '    vScript = "alert('Error while trying to create PDF file. " & ex.Message.Replace("'", "'").Replace(vbCrLf, "\n") & "');"
        'Finally
        '    vPrn = Nothing
        '    vRpt = Nothing
        'End Try

        vPdfFile = Server.MapPath(".") & "\downloads\" & Session.SessionID & "-" & p_loancd & ".html"
        Try
            If IO.File.Exists(vPdfFile) Then
                Kill(vPdfFile)
            End If
        Catch ex As system.exception
            vScript = "alert('An error occurred while trying to save to HTML file. Error code is:\n" & _
                ex.Message.Replace("'", "") & "');"
        End Try
        IO.File.WriteAllText(vPdfFile, vData.ToString)

        'vScript = "document.getElementById('frame').src = 'downloads/" & Session.SessionID & "-sss_report.html';"
        divReport.Attributes.Add("src", "downloads/" & Session.SessionID & "-" & p_loancd & ".html")
    End Sub

    Private Sub TAX_REMITTANCE(ByVal pEmplist As String)
        Dim vTot As Decimal = 0
        Dim vOut As String = ""
        Dim iCtr As Integer = 0
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        'Dim vPrn As New VSPrinter8Lib.VSPrinter
        'Dim vPDF As New VSPDF8Lib.VSPDF8
        Dim vCompanyName As String = ""
        Dim vAddress As String = ""
        Dim vData As String = ""
        Dim vFormat As String = ""
        Dim vTax As Decimal = 0
        Dim vPdfFile As String = ""
        Dim vClass As String = "odd"

        Dim vFrom As Date = cmbYear.SelectedValue & "/" & cmbMonth.SelectedValue & "/" & cmbDay.SelectedValue
        Dim vTo As Date = cmbYearTo.SelectedValue & "/" & cmbMonthTo.SelectedValue & "/" & cmbDayTo.SelectedValue

        c.Open()
        cm.Connection = c

        If cmbOfc.SelectedValue <> "All" Then
            cm.CommandText = "SELECT Company_Name, Address,AgencyCd FROM glsyscntrl WHERE AgencyCd='" & cmbOfc.SelectedValue & "'"
        Else
            cm.CommandText = "SELECT TOP 1 Company_Name, Address,AgencyCd FROM glsyscntrl"
        End If

        rs = cm.ExecuteReader
        If rs.Read Then
            vCompanyName = IIf(IsDBNull(rs("Company_Name")), "UNKNOWN", rs("Company_Name"))
            vAddress = IIf(IsDBNull(rs("Address")), "UNKNOWN", rs("Address"))
        End If
        rs.Close()


        vData = "<html><head><title>Witholding Tax Report</title><link href='../redtheme/red.css' rel='stylesheet' tyle='text/css'/></head><body><center>"

        vData += "<h2>" & vCompanyName & "</h2>"
        vData += "<h4>" & vAddress & "</h4>"
        vData += "<h3>Witholding Tax Report </h3>" & _
                 "<h4>for the month of " & cmbMonth.SelectedItem.Text & ", " & cmbYear.SelectedValue & "</h4>"

        vData += "<table border='1' style='border-collapse:collapse; width:100%;' class='label'>"
        vData += "<tr class='titleBar'><th>#</th>" & _
                                     "<th>TIN NO.</th>" & _
                                     "<th>EMP ID</th>" & _
                                     "<th>NAME OF EMPLOYEE</th>" & _
                                     "<th>WITHOLDING TAX</th>" & _
                                     "</tr>"

        cm.CommandText = "select Emp_Cd,Name,SUM(With_Tax) as Tax, " & _
                         "(SELECT Tin FROM py_emp_master WHERE Emp_Cd=py_report.Emp_Cd) AS Tin " & _
                         "FROM py_report WHERE With_Tax <> 0 " & pEmplist & _
                         "AND PayDate between '" & cmbYear.SelectedValue & "/" & cmbMonth.SelectedValue & _
                         "/" & cmbDay.SelectedValue & "' and '" & cmbYearTo.SelectedValue & "/" & _
                         cmbMonthTo.SelectedValue & "/" & cmbDayTo.SelectedValue & _
                         "' group by Emp_Cd,Name ORDER BY Name"
        Try
            rs = cm.ExecuteReader
            iCtr = 0
            Do While rs.Read
                iCtr = iCtr + 1
                vData += "<tr class='" & vClass & "'>" & _
                            "<td class='labelR'>" & iCtr & ".</td>" & _
                            "<td class='labelL'>" & IIf(IsDBNull(rs("Tin")), "", rs("Tin")) & "</td>" & _
                            "<td class='labelL'>" & rs("Emp_Cd") & "</td>" & _
                            "<td class='labelL'>" & rs("Name") & "</td>" & _
                            "<td class='labelR'>" & Format(rs("Tax"), "#,###,##0.00") & "</td></tr>"
                vTax += rs("Tax")
                '--------

                vOut += iCtr & "." & vbTab & IIf(IsDBNull(rs("Name")), "", rs("Name")) & vbTab & _
                   Format(IIf(IsDBNull(rs("Tax")), 0, rs("Tax")), "#,###,##0.00") & vbCrLf
                vTot += IIf(IsDBNull(rs("Tax")), 0, rs("Tax"))

                vClass = IIf(vClass = "odd", "even", "odd")
            Loop
            rs.Close()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to retrieve record. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            cm.Dispose()
        End Try

        vData += " <tr class='activeBar'><td colspan='4' class='labelR'><strong>Grand Total</strong></td>" & _
                                         "<td class='labelR'><strong>" & Format(vTot, "##,###,##0.00") & "</strong></td></tr>"
        vData += "</table></body></center></html>"

        vOut += vbTab & "TOTAL:" & vbTab & Format(vTot, "##,###,##0.00")

        Dim vFilename As String = Server.MapPath(".") & "\downloads\" & Session.SessionID & "-tax.txt"

        If IO.File.Exists(vFilename) Then
            Try
                IO.File.Delete(vFilename)
            Catch ex As IO.IOException
                vScript = "alert('Error in deleting temp file. " & ex.Message.Replace("'", "\'").Replace(vbCrLf, "\n") & "');"
            End Try
        End If
        Try
            IO.File.WriteAllText(vFilename, vOut)
        Catch ex As IO.IOException
            vScript = "alert('Error in writing to text file. " & ex.Message.Replace("'", "\'").Replace(vbCrLf, "\n") & "');"
        Finally
            'lnkDownload.NavigateUrl = "downloads/" & Session.SessionID & "-tax.txt"
            lnkDownload.NavigateUrl = "downloads/" & Session.SessionID & "-WithHoldingTax.html"
        End Try

        '---------accessing pdf
        'Dim vFilenamepdf As String = Server.MapPath(".") & "\downloads\" & Session.SessionID & "-pagibig_report.pdf"

        'Try
        '    vPDF.ConvertDocument(vPrn, vFilenamepdf)
        'Catch ex as system.exception
        '    vScript = "alert('Error occurred in saving PDF file. " & ex.Message.Replace("'", "\'").Replace(vbCrLf, "\n") & "');"
        'Finally
        '    vPDF = Nothing
        '    vPrn = Nothing

        '    frame.Attributes("src") = "downloads/" & Session.SessionID & "-pagibig_report.pdf"
        'End Try

        vPdfFile = Server.MapPath(".") & "\downloads\" & Session.SessionID & "-tax.html"
        Try
            If IO.File.Exists(vPdfFile) Then
                Kill(vPdfFile)
            End If
        Catch ex As system.exception
            vScript = "alert('An error occurred while trying to save to HTML file. Error code is:\n" & _
                ex.Message.Replace("'", "") & "');"
        End Try
        IO.File.WriteAllText(vPdfFile, vData)
        'vScript = "document.getElementById('frame').src = 'downloads/" & Session.SessionID & "-sss_report.html';"
        divReport.Attributes.Add("src", "downloads/" & Session.SessionID & "-tax.html")

        vScript = "winprev = window.open('1601temp.aspx?f=" & vFrom & "&t=" & vTo & _
            "&vRanks=" & txtRank.Text & "','RemitTax','top=10,left=10,width=830,height=640,scrollbars=yes,resizable=yes'); winprev.focus();"

    End Sub

    Private Sub PHILHEALTH_REMITTANCE(ByVal pEmplist As String)
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cmRef As New SqlClient.SqlCommand
        Dim dr As SqlClient.SqlDataReader
        Dim drRef As SqlClient.SqlDataReader
        Dim vTmp As String = ""
        Dim vOut As String = "REMITTANCE REPORT" & vbCrLf
        Dim vCompanyName As String = Space(60)
        Dim vName As String = Space(40)
        Dim vPosition As String = Space(20)
        Dim vAddress As String = Space(100)
        Dim vPHICNo As String = Format(0, "000000000000")
        Dim iCtr As Integer = 0
        Dim vNo As Integer = 0
        Dim vGov As Integer = 0
        Dim vPer As Integer = 0
        Dim vTot As Decimal = 0

        Dim vData As String = ""
        Dim vEShareTotal As Decimal = 0
        Dim vEmShareTotal As Decimal = 0
        Dim vMonthRate As Decimal = 0
        Dim vTotal As Decimal = 0
        Dim vTotalTotal As Decimal = 0
        Dim vPdfFile As String = ""
        Dim vClass As String = "odd"

        vData = "<html><head><title>Philhealth Summary Report</title>" & _
                "<link href='../redtheme/red.css' rel='stylesheet' type='text/css'/>" & _
                "</head><body><center><h1>Philhealth Summary Report</h1>" & _
                "<h2>for the month of " & cmbMonth.SelectedItem.Text & ", " & cmbYear.SelectedValue & _
                "</h2><hr/>"

        vData += "<table border='1' style='width:100%;border-collapse:collapse;'>" & _
            "<tr class='titleBar'>" & _
            "<th>PHIC NO.</th><th>EMP ID</th>" & _
            "<th>NAME OF EMPLOYEE</th>" & _
            "<th>EMPLOYEE SHARE</th>" & _
            "<th>EMPLOYER SHARE</th>" & _
            "<th>TOTAL</th></tr>"

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurrred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "\n").Replace("'", "\'") & "');"
            c.Dispose()
            cm.Dispose()
            cmRef.Dispose()
            Exit Sub
        End Try

        cm.Connection = c
        cmRef.Connection = c

        If cmbOfc.SelectedValue <> "All" Then
            cm.CommandText = "select Company_Name,Address,AgencyCd,PhicNo,Attention,AttentionPos from " & _
                "glsyscntrl where AgencyCd='" & cmbOfc.SelectedValue & "'"
        Else
            cm.CommandText = "select TOP 1 Company_Name,Address,AgencyCd,PhicNo,Attention,AttentionPos from " & _
                "glsyscntrl"
        End If

        dr = cm.ExecuteReader
        If dr.Read Then
            vCompanyName = Space(60)
            vAddress = Space(100)
            vName = Space(40)
            vPosition = Space(20)
            vPHICNo = "000000000000"

            If Not IsDBNull(dr("Company_Name")) Then
                vCompanyName = Mid(dr("Company_Name").ToString.Trim, 1, 60)
            End If
            If Not IsDBNull(dr("Address")) Then
                vAddress = Mid(dr("Address").ToString.Trim, 1, 100)
            End If
            If Not IsDBNull(dr("Attention")) Then
                vName = Mid(dr("Attention").ToString.Trim, 1, 40)
            End If
            If Not IsDBNull(dr("AttentionPos")) Then
                vPosition = Mid(dr("AttentionPos").ToString.Trim, 1, 20)
            End If
            If Not IsDBNull(dr("PhicNo")) Then
                vPHICNo = Format(Val(dr("PhicNo")), "000000000000")
            End If

            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY: LANCE BISENIO                                     ''
            '' DATE MODIFIED: 6/30/2012                                        ''
            '' PURPOSE: FOR RICHMONDE HOTEL USE ONLY                           ''
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            ''== START ========================================================''
            vCompanyName = vCompanyName.ToUpper
            ''== END ==========================================================''
            ''== OLD CODE =====================================================''
            'vCompanyName = vCompanyName.ToUpper & Space(60 - vCompanyName.Length)
            ''== END ==========================================================''

            vAddress = vAddress.ToUpper ' & Space(100 - vAddress.Length)
            vName = vName.ToUpper ' & Space(40 - vName.Length)
            vPosition = vPosition.ToUpper ' & Space(20 - vPosition.Length)
        End If
        dr.Close()
        vOut += vCompanyName & vbCrLf & vAddress & vbCrLf & vPHICNo
        Select Case Val(cmbMonth.SelectedValue)
            Case Is < 4     '1,2,3 - first quarter
                vOut += "1"
            Case Is < 7     '4,5,6 - second quarter
                vOut += "2"
            Case Is < 10    '7,8,9 - third quarter
                vOut += "3"
            Case Else   '10,11,12 - fourth quarter
                vOut += "4"
        End Select
        vOut += Format(Val(cmbYear.SelectedValue), "0000") & "R" & vbCrLf & "MEMBERS" & vbCrLf

        cm.CommandText = "select Sum(Medicare_Per) AS Medicare_Per, Emp_Cd,SUM(Medicare_Gov) AS Medicare_Gov, " & _
            "Emp_Cd,Name from py_report where Medicare_Per <> 0 " & pEmplist & _
            "AND PayDate between '" & cmbYear.SelectedValue & "/" & cmbMonth.SelectedValue & "/" & _
            cmbDay.SelectedValue & "' and '" & cmbYearTo.SelectedValue & "/" & _
            cmbMonthTo.SelectedValue & "/" & cmbDayTo.SelectedValue & _
            "' group by Emp_Cd,Name ORDER BY Name"

        dr = cm.ExecuteReader
        Do While dr.Read
            vMonthRate = 0
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:  VIC GATCHALIAN                             ''
            '' DATE MODIFIED: 5/10/2013                                 ''
            '' PURPOSE: TO GET THE CEILING BOUNDARIES IN THE PHIC TABLE ''
            ''          BASED ON THE CONTRIBUTIONS                      ''
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            cmRef.CommandText = "select top 1 FromAmt,ToAmt from py_philhealth_table  where " & _
                dr("Medicare_Per") & "<= Per_Share"
            drRef = cmRef.ExecuteReader

            If drRef.Read Then
                If drRef("FromAmt") = 0 Then
                    vMonthRate = drRef("ToAmt")
                Else
                    vMonthRate = drRef("FromAmt")
                End If
            Else
                'get the maximum contribution instead
                drRef.Close()
                cmRef.CommandText = "select top 1 FromAmt from py_philhealth_table order by ToAmt desc"
                drRef = cmRef.ExecuteReader
                If drRef.Read Then
                    vMonthRate = drRef("FromAmt")
                End If
            End If
            drRef.Close()
            '''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''

            cmRef.CommandText = "select PhicNo,Sss_no,Emp_Lname,Emp_Fname,Emp_Mname,Rate_Month from py_emp_master " & _
                "where Emp_Cd='" & dr("Emp_Cd") & "'"
            drRef = cmRef.ExecuteReader
            If drRef.Read Then
                vTotal = dr("Medicare_Per") + dr("Medicare_Gov")

                vData += "<tr class='" & vClass & "'>" & _
                    "<td class='labelL'>" & IIf(IsDBNull(drRef("PhicNo")), "", drRef("PhicNo")) & "</td>" & _
                    "<td class='labelL'>" & dr("Emp_Cd") & "</td>" & _
                    "<td class='labelL'>" & dr("Name") & "</td>" & _
                    "<td class='labelR'>" & Format(dr("Medicare_Per"), "##,##0.00") & "</td>" & _
                    "<td class='labelR'>" & Format(dr("Medicare_Gov"), "##,##0.00") & "</td>" & _
                    "<td class='labelR'>" & Format(vTotal, "##,##0.00") & "</td></tr>"

                vTotalTotal += vTotal
                vEShareTotal += dr("Medicare_Per")
                vEmShareTotal += dr("Medicare_Gov")
                '--------
                vPHICNo = Space(12)
                If Not IsDBNull(drRef("PhicNo")) Then
                    vPHICNo = Mid(drRef("PhicNo").ToString.Replace("-", "").Replace(" ", ""), 1, 12)
                    vPHICNo = vPHICNo & Space(12 - vPHICNo.Length)
                Else
                    If Not IsDBNull(drRef("Sss_No")) Then
                        vPHICNo = Mid(drRef("Sss_No").ToString.Replace("-", "").Replace(" ", ""), 1, 10)
                        vPHICNo = vPHICNo & Space(12 - vPHICNo.Length)
                    End If
                End If

                vPer = IIf(IsDBNull(dr("Medicare_Per")), 0, dr("Medicare_Per")) * 100
                vGov = IIf(IsDBNull(dr("Medicare_Gov")), 0, dr("Medicare_Gov")) * 100

                vOut += vPHICNo
                vTmp = Mid(drRef("Emp_Lname"), 1, 30).ToUpper
                vTmp = vTmp & Space(30 - vTmp.Length)
                vOut += vTmp
                vTmp = Mid(drRef("Emp_Fname"), 1, 30).ToUpper
                vTmp = vTmp & Space(30 - vTmp.Length)
                vOut += vTmp & Mid(drRef("Emp_Mname"), 1, 1).Replace(".", " ").ToUpper

                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY:  VIC GATCHALIAN                                       ''
                '' DATE MODIFIED: 5/10/2013                                           ''
                '' PURPOSE: TO DISPLAY THE CEILING OR FLOOR BOUNDARIES RETRIEVED FROM ''
                ''          PHIC TABLE INSTEAD OF EXPOSING THE REAL MONTHLY RATE OF   ''
                ''          THE EMPLOYEE.                                             ''
                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                ''''''''''''''''''' OLD CODE  ''''''''''''''''''''''''''''''''''''''''''
                'vOut += Format(drRef("Rate_Month") * 100, "00000000")
                ''''''''''''''''''' END OLD CODE '''''''''''''''''''''''''''''''''''''''
                vOut += Format(vMonthRate * 100, "00000000")
                ''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''''''''

                Select Case cmbMonth.SelectedValue
                    Case 1, 4, 7, 10         'first months of each quarter
                        vOut += Format(vPer, "000000") & Format(vGov, "000000") & "000000000000000000000000"
                        vNo = 1
                    Case 2, 5, 8, 11         'second months of each quarter
                        vOut += "000000000000" & Format(vPer, "000000") & Format(vGov, "000000") & "000000000000"
                        vNo = 2
                    Case 3, 6, 9, 12      'third months of each quarter
                        vOut += "000000000000000000000000" & Format(vPer, "000000") & Format(vGov, "000000")
                        vNo = 3
                End Select

                vOut += vbCrLf
                'vOut += Space(10) & vbCrLf
                iCtr = iCtr + 1
                vTot += vPer + vGov
                vClass = IIf(vClass = "odd", "even", "odd")
            End If
            drRef.Close()
        Loop
        dr.Close()

        vData += "<tr class='activeBar'>" & _
            "<td class='labelR' colspan='3'>Grand Total</td>" & _
            "<td class='labelR'>" & Format(vEShareTotal, "###,##0.00") & "</td>" & _
            "<td class='labelR'>" & Format(vEmShareTotal, "###,##0.00") & "</td>" & _
            "<td class='labelR'>" & Format(vTotalTotal, "###,##0.00") & "</td></tr>" & _
            "</table><center/></body></html>"

        cm.Dispose()
        cmRef.Dispose()
        c.Close()
        c.Dispose()

        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY: LANCE BISENIO                                      ''
        '' DATE MODIFIED: 6/30/2012                                        ''
        '' PURPOSE: FOR RICHMONDE HOTEL USE ONLY                           ''
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        ''== START ========================================================''
        vOut += "M5-SUMMARY" & vbCrLf
        vOut += vNo & Format(vTot, "00000000") & Space(10 - Format(vTot, "00000000").Length) & Space(1)
        vOut += Format(Val(cmbMonth.SelectedValue), "00") & Space(29 - Format(Val(cmbMonth.SelectedValue), "00").Length) & Space(1)
        vOut += Format(MonthEND(cmbMonth.SelectedValue & "/1/" & cmbYear.SelectedValue).Day, "00") & _
            Space(29 - Format(MonthEND(cmbMonth.SelectedValue & "/1/" & cmbYear.SelectedValue).Day, "00").Length) & Space(1)
        vOut += Format(Val(cmbMonth.SelectedValue), "0000") & _
        iCtr & vbCrLf & _
        "GRAND TOTAL" & _
        Format(vTot, "0000000000") & vbCrLf
        vOut += vName & Space(32 - vName.Length) & Space(1) & vPosition
        ''== END ==========================================================''
        ''== OLD CODE =====================================================''
        'vOut += "M5-SUMMARY" & vbCrLf & vNo & vbCrLf & Format(vTot, "00000000") & Space(15) & _
        '    vbCrLf & Format(Val(cmbMonth.SelectedValue), "00") & _
        '    Format(MonthEND(cmbMonth.SelectedValue & "/1/" & cmbYear.SelectedValue).Day, "00") & _
        '    Format(Val(cmbMonth.SelectedValue), "0000") & _
        '    iCtr & vbCrLf & _
        '    "GRAND TOTAL" & _
        '    Format(vTot, "0000000000") & vbCrLf & vName & vbCrLf & vPosition
        ''== END ==========================================================''

        Dim vFilename As String = Server.MapPath(".") & "\downloads\" & Session.SessionID & "-philhealth.txt"
        If IO.File.Exists(vFilename) Then
            Try
                IO.File.Delete(vFilename)
            Catch ex As IO.IOException
                vScript = "alert('Error while deleting temp file. " & ex.Message.Replace("'", "\'").Replace(vbCrLf, "\n") & "');"
            End Try
        End If
        Try
            IO.File.WriteAllText(vFilename, vOut)
        Catch ex As IO.IOException
            vScript = "alert('Error while trying to save text file. " & ex.Message.Replace("'", "\'").Replace(vbCrLf, "\n") & "');"
        Finally
            lnkDownload.NavigateUrl = "downloads/" & Session.SessionID & "-philhealth.txt"
        End Try

        vPdfFile = Server.MapPath(".") & "\downloads\" & Session.SessionID & "-philhealth_revised_report.html"
        Try
            If IO.File.Exists(vPdfFile) Then
                Kill(vPdfFile)
            End If
        Catch ex As System.Exception
            vScript = "alert('An error occurred while trying to save to HTML file. Error code is:\n" & _
                ex.Message.Replace("'", "") & "');"
        End Try
        IO.File.WriteAllText(vPdfFile, vData)
        'vScript = "document.getElementById('frame').src = 'downloads/" & Session.SessionID & "-sss_report.html';"
        divReport.Attributes.Add("src", "downloads/" & Session.SessionID & "-philhealth_revised_report.html")

    End Sub
    Private Function GetContr(ByVal pEmpCd As String, ByRef pNo As Integer, ByRef pPer As Integer, ByRef pGov As Integer, ByRef c As SqlClient.SqlConnection) As String

        Dim cm As New SqlClient.SqlCommand
        Dim dr As SqlClient.SqlDataReader
        Dim vPer As Integer
        Dim vGov As Integer
        Dim vMonth As Integer = Format(cmbMonth.SelectedValue, "00")

        cm.Connection = c
        cm.CommandText = "select sum(Medicare_Per) as Med_Emp, sum(Medicare_Gov) as Med_Emr " & _
            "from py_report where PayDate between '" & cmbYear.SelectedValue & "/" & cmbMonth.SelectedValue & _
            "/" & cmbDay.SelectedValue & "' and '" & cmbYearTo.SelectedValue & "/" & cmbMonthTo.SelectedValue & _
            "/" & cmbDayTo.SelectedValue & "' and Emp_Cd='" & pEmpCd & "'"
        dr = cm.ExecuteReader
        vPer = 0 : vGov = 0
        If dr.Read Then
            vPer = IIf(IsDBNull(dr("Med_Emp")), 0, dr("Med_Emp")) * 100
            vGov = IIf(IsDBNull(dr("Med_Emr")), 0, dr("Med_Emr")) * 100
        End If
        dr.Close()
        pPer = vPer
        pGov = vGov
        GetContr = Format(0, "000000000000000000000000000000000000")
        Select Case vMonth
            Case 1, 4, 7, 10         'first months of each quarter
                GetContr = Format(vPer, "000000") & Format(vGov, "000000") & "000000000000000000000000"
                pNo = 1
            Case 2, 5, 8, 11         'second months of each quarter
                GetContr = "000000000000" & Format(vPer, "000000") & Format(vGov, "000000") & "000000000000"
                pNo = 2
            Case 3, 6, 9, 12      'third months of each quarter
                GetContr = "000000000000000000000000" & Format(vPer, "000000") & Format(vGov, "000000")
                pNo = 3
        End Select
        cm.Dispose()
    End Function
    Private Sub PAGIBIG_EDINET(ByVal pEmplist As String)
        Dim vData As String = ""
        Dim vFormat As String = ""
        Dim vEShareTotal As Decimal = 0
        Dim vEmShareTotal As Decimal = 0
        Dim vTotal As Decimal = 0
        Dim vTotalTotal As Decimal = 0
        Dim vClass As String = "odd"
        Dim vOut As String = "EH"
        Dim vPer As Single = 0
        Dim vGov As Single = 0
        Dim vSalLoan As Double = 0
        Dim vEmrSSS As String = ""
        Dim vCompanyName As String = Space(100)
        Dim vAddress As String = Space(100)
        Dim vZip As String = Space(7)
        Dim vTel As String = Space(15)
        Dim vTmp As String = Space(12)
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cmRef As New SqlClient.SqlCommand
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim emrTIN As String = ""
        Dim philhealthPagibig As String = ""
        Dim vPdfFile As String = ""


        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c
        cmRef.Connection = c

        If cmbOfc.SelectedValue <> "All" Then
            cm.CommandText = "select Tin,Company_Name,Address,Phone,Zip,PagibigBranchCd,Employer_SssNo,AgencyCd " & _
                "from glsyscntrl where AgencyCd='" & cmbOfc.SelectedValue & "'"
        Else
            cm.CommandText = "select TOP 1 Tin,Company_Name,Address,Phone,Zip,PagibigBranchCd,Employer_SssNo,AgencyCd " & _
                "from glsyscntrl"
        End If

        rs = cm.ExecuteReader
        rs.Read()

        emrTIN = IIf(IsDBNull(rs("Tin")), "999-999-999", rs("Tin")) & "-000"

        vCompanyName = IIf(IsDBNull(rs("Company_Name")), Space(100), Mid(rs("Company_Name"), 1, 100))
        vAddress = IIf(IsDBNull(rs("Address")), Space(100), Mid(rs("Address"), 1, 100))
        vZip = IIf(IsDBNull(rs("Zip")), Space(7), Mid(rs("Zip"), 1, 7))
        vTel = IIf(IsDBNull(rs("Phone")), Space(15), Mid(rs("Phone"), 1, 15))
        vCompanyName = vCompanyName & Space(100 - vCompanyName.Length)
        vAddress = vAddress & Space(100 - vAddress.Length)
        vZip = vZip & Space(7 - vZip.Length)
        vTel = vTel & Space(15 - vTel.Length)

        vData = "<html><head><title>Pagibig Contribution Report</title>" & _
                "<link href='../redtheme/red.css' rel='stylesheet' type='text/css'/></head><body><center>"
        vData += "<h2>" & vCompanyName & "</h2>"
        vData += "<h3>" & vAddress & "</h3>"
        vData += "<h4>Pagibig Contribution Report</h4>"
        vData += "<h5>for the month of " & cmbMonth.SelectedItem.Text & ", " & cmbYear.SelectedValue & "</h5>"

        vData += "<table border='1' style='border-collapse:collapse;width:100%;' class='label'><tr class='titleBar'>" & _
                 "<th>#</th><th>PAGIBIG/TIN NO.</th><th>EMP ID</th>" & _
                     "<th>NAME OF EMPLOYEE</th><th>EMPLOYEE SHARE</th>" & _
                     "<th>EMPLOYER SHARE</th><th>EC</th></tr>"

        If IsDBNull(rs("PagibigBranchCd")) Then
            rs.Close()
            cm.Dispose()
            cmRef.Dispose()
            c.Close()
            vScript = "alert('PagIbig branch code is empty.Please set it up first.');"
            Exit Sub
        End If

        vOut += IIf(IsDBNull(rs("PagibigBranchCd")), "00", Mid(rs("PagibigBranchCd"), 1, 2)) & _
                Format(cmbYear.SelectedValue, "0000") & _
                Format(cmbMonth.SelectedValue, "00") & _
                Format(Val(IIf(IsDBNull(rs("Employer_SssNo")), 0, rs("Employer_SssNo").ToString.Replace("-", ""))), "000000000000000") & _
                "PMC" & vCompanyName & vAddress & vZip & vTel & vbCrLf
        rs.Close()

        cm.CommandText = "SELECT (Select PagIbig_No FROM py_emp_master WHERE py_emp_master.Emp_Cd=py_report.Emp_Cd) AS PagIbig_No,Emp_Cd," & _
                        "(Select Emp_Lname FROM py_emp_master WHERE py_emp_master.Emp_Cd=py_report.Emp_Cd) AS Emp_Lname," & _
                        "(Select Emp_Fname FROM py_emp_master WHERE py_emp_master.Emp_Cd=py_report.Emp_Cd) AS Emp_Fname," & _
                        "(Select Emp_Mname FROM py_emp_master WHERE py_emp_master.Emp_Cd=py_report.Emp_Cd) AS Emp_Mname," & _
                        "(Select Tin FROM py_emp_master WHERE py_emp_master.Emp_Cd=py_report.Emp_Cd) AS Tin," & _
                        "CAST((Select Bday FROM py_emp_master WHERE py_emp_master.Emp_Cd=py_report.Emp_Cd) AS DATETIME) AS Bday," & _
                        "Name,PayDate," & _
                         "Sum(PagIbig_Per) As Pag_Emp,Sum(PagIbig_Gov) AS Pag_Emr from py_report where PagIbig_Per <> 0 " & pEmplist & _
                         "AND PayDate between '" & cmbYear.SelectedValue & "/" & cmbMonth.SelectedValue & _
                         "/" & cmbDay.SelectedValue & "' and '" & cmbYearTo.SelectedValue & "/" & cmbMonthTo.SelectedValue & _
                         "/" & cmbDayTo.SelectedValue & "' group by Emp_Cd,Name,PayDate ORDER BY Name"

        rs = cm.ExecuteReader
        Dim count As Integer = 1
        Do While rs.Read
            If IsDBNull(rs("PagIbig_No")) Then
tin:
                If IsDBNull(rs("Tin")) Then
                    philhealthPagibig = ""
                Else
                    If rs("Tin").ToString.Trim = "" Then
                        philhealthPagibig = ""
                    Else
                        philhealthPagibig = rs("Tin")
                    End If
                End If
            Else
                If rs("PagIbig_No").ToString.Trim = "" Then
                    GoTo tin
                End If
                philhealthPagibig = rs("PagIbig_No")
            End If

            ''''pdf processing
            vTotal = rs("Pag_Emp") + rs("Pag_Emr")
            vData += "<tr class='" & vClass & "'><td class='labelR'>" & count & ".</td>" & _
                     "<td class='labelL'>" & philhealthPagibig & "</td>" & _
                     "<td class='labelL'>" & rs("Emp_Cd") & "</td>" & _
                     "<td class='labelL'>" & rs("Name") & "</td>" & _
                     "<td class='labelR'>" & Format(rs("Pag_Emp"), "##,##0.00") & "</td>" & _
                     "<td class='labelR'>" & Format(rs("Pag_Emr"), "##,##0.00") & "</td>" & _
                     "<td class='labelR'>" & Format(vTotal, "##,##0.00") & "</td>" & _
                     "</tr>"

            vTotalTotal += vTotal
            vEShareTotal += rs("Pag_Emp")
            vEmShareTotal += rs("Pag_Emr")
            vClass = IIf(vClass = "odd", "even", "odd")
            count += 1
            '-----------------------------------------------
            vPer = IIf(IsDBNull(rs("Pag_Emp")), 0, rs("Pag_Emp"))
            vGov = IIf(IsDBNull(rs("Pag_Emr")), 0, rs("Pag_Emr"))

            vOut += "DT"
            'pagibig no
            vTmp = IIf(IsDBNull(rs("PagIbig_No")), Space(12), Mid(rs("PagIbig_No").ToString.Replace("-", ""), 1, 12))
            vTmp = vTmp & Space(12 - vTmp.Length)
            vOut += vTmp
            'emp id
            vTmp = Mid(rs("Emp_Cd"), 1, 15)
            vTmp = vTmp & Space(15 - vTmp.Length)
            vOut += vTmp
            'last name
            vTmp = Mid(rs("Emp_Lname"), 1, 30).ToUpper
            vTmp = vTmp & Space(30 - vTmp.Length)
            vOut += vTmp
            'first name
            vTmp = Mid(rs("Emp_Fname"), 1, 30).ToUpper
            vTmp = vTmp & Space(30 - vTmp.Length)
            vOut += vTmp
            'middle name
            vTmp = Mid(rs("Emp_Mname"), 1, 30).ToUpper
            vTmp = vTmp & Space(30 - vTmp.Length)
            vOut += vTmp
            'employee share
            vTmp = Space(13 - Format(vPer, "#,##0.00").ToString.Length) & Format(vPer, "#,##0.00")
            vOut += vTmp
            'employer share
            vTmp = Space(13 - Format(vGov, "#,##0.00").ToString.Length) & Format(vGov, "#,##0.00")
            vOut += vTmp
            'tin
            vTmp = IIf(IsDBNull(rs("Tin")), Space(15), Mid(rs("Tin").ToString.Replace("-", ""), 1, 15))
            vTmp = vTmp & Space(15 - vTmp.Length)
            vOut += vTmp
            'bday
            If IsDBNull(rs("Bday")) Then
                vTmp = Space(8)
            Else
                vTmp = Format(rs("Bday"), "yyyy/MM/dd")
            End If
            vTmp = vTmp.Replace("/", "")
            vOut += vTmp & vbCrLf
        Loop
        rs.Close()
        cm.Dispose()
        cmRef.Dispose()
        c.Close()

        '-------------------------
        Dim vFileName As String = Server.MapPath(".") & "\downloads\" & Session.SessionID & "-pagibig.txt"
        If IO.File.Exists(vFileName) Then
            Try
                IO.File.Delete(vFileName)
            Catch ex As IO.IOException
                vScript = "alert('Error deleting temp file. " & ex.Message.Replace("'", "\'").Replace(vbCrLf, "\n") & "');"
            End Try
        End If

        Try
            IO.File.WriteAllText(vFileName, vOut)
        Catch ex As IO.IOException
            vScript = "alert('Error writing text file. " & ex.Message.Replace("'", "\'").Replace(vbCrLf, "\n") & "');"
        End Try
        lnkDownload.NavigateUrl = "downloads/" & Session.SessionID & "-pagibig.txt"
        '--------------------------------------------

        vData += "<tr class='activeBar' style='font-weight:bold'>" & _
                     "<td class='labelR' colspan='4'>Grand Total</td>" & _
                     "<td class='labelR'>" & Format(vEShareTotal, "#,###,##0.00") & "</td>" & _
                     "<td class='labelR'>" & Format(vEmShareTotal, "#,###,##0.00") & "</td>" & _
                     "<td class='labelR'>" & Format(vTotalTotal, "#,###,##0.00") & "</td>" & _
                 "</tr>"
        vData += "</table></center></body></html>"

        vPdfFile = Server.MapPath(".") & "\downloads\" & Session.SessionID & "-pagibig_report.html"
        Try
            If IO.File.Exists(vPdfFile) Then
                Kill(vPdfFile)
            End If
        Catch ex As system.exception
            vScript = "alert('An error occurred while trying to save to HTML file. Error code is:\n" & _
                ex.Message.Replace("'", "") & "');"
        End Try
        IO.File.WriteAllText(vPdfFile, vData)
        divReport.Attributes.Add("src", "downloads/" & Session.SessionID & "-pagibig_report.html")
    End Sub
    Private Sub PAGIBIG_REMITTANCE(ByVal pEmplist As String)
        Dim vData As String = ""
        Dim vFormat As String = ""
        Dim vEShareTotal As Decimal = 0
        Dim vEmShareTotal As Decimal = 0
        Dim vTotal As Decimal = 0
        Dim vTotalTotal As Decimal = 0
        Dim vClass As String = "odd"
        'Dim vOut As String = "EH"
        Dim vOut As String = "EYERID,HDMFID,LNAME,FNAME,MID,PERCC,PFRNO,PFRDATE,EE,ER,PFRAMT,REM" & vbNewLine
        Dim vPer As Single = 0
        Dim vGov As Single = 0
        Dim vSalLoan As Double = 0
        Dim vEmrSSS As String = ""
        Dim vCompanyName As String = Space(100)
        Dim vAddress As String = Space(100)
        Dim vZip As String = Space(7)
        Dim vTel As String = Space(15)
        Dim vTmp As String = Space(12)
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cmRef As New SqlClient.SqlCommand
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim emrTIN As String = ""
        Dim philhealthPagibig As String = ""
        Dim vPdfFile As String = ""


        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c
        cmRef.Connection = c

        If cmbOfc.SelectedValue <> "All" Then
            cm.CommandText = "select Tin,Company_Name,Address,Phone,Zip,PagibigBranchCd,Employer_SssNo,AgencyCd " & _
                "from glsyscntrl where AgencyCd='" & cmbOfc.SelectedValue & "'"
        Else
            cm.CommandText = "select TOP 1 Tin,Company_Name,Address,Phone,Zip,PagibigBranchCd,Employer_SssNo,AgencyCd " & _
                "from glsyscntrl"
        End If

        rs = cm.ExecuteReader
        rs.Read()

        emrTIN = IIf(IsDBNull(rs("Tin")), "999-999-999", rs("Tin")) & "-000"

        vCompanyName = IIf(IsDBNull(rs("Company_Name")), Space(100), Mid(rs("Company_Name"), 1, 100))
        vAddress = IIf(IsDBNull(rs("Address")), Space(100), Mid(rs("Address"), 1, 100))
        vZip = IIf(IsDBNull(rs("Zip")), Space(7), Mid(rs("Zip"), 1, 7))
        vTel = IIf(IsDBNull(rs("Phone")), Space(15), Mid(rs("Phone"), 1, 15))
        vCompanyName = vCompanyName & Space(100 - vCompanyName.Length)
        vAddress = vAddress & Space(100 - vAddress.Length)
        vZip = vZip & Space(7 - vZip.Length)
        vTel = vTel & Space(15 - vTel.Length)

        vData = "<html>" & vbNewLine & _
                "<head>" & vbNewLine & _
                "<title>Pagibig Contribution Report</title>" & vbNewLine & _
                "<link href='../redtheme/red.css' rel='stylesheet' type='text/css'/>" & vbNewLine & _
                "</head>" & vbNewLine & _
                "<body> <center> " & vbNewLine
        vData += "<h2>" & vCompanyName & "</h2>" & vbNewLine
        vData += "<h3>" & vAddress & "</h3>" & vbNewLine
        vData += "<h4>Pagibig Contribution Report</h4>" & vbNewLine
        vData += "<h5>for the month of " & cmbMonth.SelectedItem.Text & ", " & cmbYear.SelectedValue & "</h5>" & vbNewLine

        vData += "<table border='1' style='border-collapse:collapse; width:100%;' class='label'>" & vbNewLine & _
                "<tr class='titleBar'>" & vbNewLine & _
                 "<th>#</th>" & vbNewLine & _
                 "<th>PAGIBIG/TIN NO.</th>" & vbNewLine & _
                 "<th>EMP ID</th>" & _
                 "<th>NAME OF EMPLOYEE</th>" & vbNewLine & _
                 "<th>EMPLOYEE SHARE</th>" & vbNewLine & _
                 "<th>EMPLOYER SHARE</th>" & vbNewLine & _
                 "<th>EC</th></tr>"

        If IsDBNull(rs("PagibigBranchCd")) Then
            rs.Close()
            cm.Dispose()
            cmRef.Dispose()
            c.Close()
            vScript = "alert('PagIbig branch code is empty.Please set it up first.');"
            Exit Sub
        End If

        'vOut += IIf(IsDBNull(rs("PagibigBranchCd")), "00", Mid(rs("PagibigBranchCd"), 1, 2)) & _
        '        Format(cmbYear.SelectedValue, "0000") & _
        '        Format(cmbMonth.SelectedValue, "00") & _
        '        Format(Val(IIf(IsDBNull(rs("Employer_SssNo")), 0, rs("Employer_SssNo").ToString.Replace("-", ""))), "000000000000000") & _
        '        "PMC" & vCompanyName & vAddress & vZip & vTel & vbCrLf
        rs.Close()

        cm.CommandText = "SELECT (Select PagIbig_No FROM py_emp_master WHERE py_emp_master.Emp_Cd=py_report.Emp_Cd) AS PagIbig_No,Emp_Cd," & _
                        "(Select Emp_Lname FROM py_emp_master WHERE py_emp_master.Emp_Cd=py_report.Emp_Cd) AS Emp_Lname," & _
                        "(Select Emp_Fname FROM py_emp_master WHERE py_emp_master.Emp_Cd=py_report.Emp_Cd) AS Emp_Fname," & _
                        "(Select Emp_Mname FROM py_emp_master WHERE py_emp_master.Emp_Cd=py_report.Emp_Cd) AS Emp_Mname," & _
                        "(Select Tin FROM py_emp_master WHERE py_emp_master.Emp_Cd=py_report.Emp_Cd) AS Tin," & _
                        "CAST((Select Bday FROM py_emp_master WHERE py_emp_master.Emp_Cd=py_report.Emp_Cd) AS DATETIME) AS Bday," & _
                        "Name,PayDate," & _
                         "Sum(PagIbig_Per) As Pag_Emp,Sum(PagIbig_Gov) AS Pag_Emr from py_report where PagIbig_Per <> 0 " & pEmplist & _
                         "AND PayDate between '" & cmbYear.SelectedValue & "/" & cmbMonth.SelectedValue & _
                         "/" & cmbDay.SelectedValue & "' and '" & cmbYearTo.SelectedValue & "/" & cmbMonthTo.SelectedValue & _
                         "/" & cmbDayTo.SelectedValue & "' group by Emp_Cd,Name,PayDate ORDER BY Name"

        rs = cm.ExecuteReader
        Dim count As Integer = 1
        Do While rs.Read
            If IsDBNull(rs("PagIbig_No")) Then
tin:
                If IsDBNull(rs("Tin")) Then
                    philhealthPagibig = ""
                Else
                    If rs("Tin").ToString.Trim = "" Then
                        philhealthPagibig = ""
                    Else
                        philhealthPagibig = rs("Tin")
                    End If
                End If
            Else
                If rs("PagIbig_No").ToString.Trim = "" Then
                    GoTo tin
                End If
                philhealthPagibig = rs("PagIbig_No")
            End If

            ''''pdf processing
            vTotal = rs("Pag_Emp") + rs("Pag_Emr")
            vData += "<tr class='" & vClass & "'><td class='labelR'>" & count & ".</td>" & _
                     "<td class='labelL'>" & philhealthPagibig & "</td>" & _
                     "<td class='labelL'>" & rs("Emp_Cd") & "</td>" & _
                     "<td class='labelL'>" & rs("Name") & "</td>" & _
                     "<td class='labelR'>" & Format(rs("Pag_Emp"), "##,##0.00") & "</td>" & _
                     "<td class='labelR'>" & Format(rs("Pag_Emr"), "##,##0.00") & "</td>" & _
                     "<td class='labelR'>" & Format(vTotal, "##,##0.00") & "</td>" & _
                     "</tr>" & vbNewLine

            vTotalTotal += vTotal
            vEShareTotal += rs("Pag_Emp")
            vEmShareTotal += rs("Pag_Emr")
            vClass = IIf(vClass = "odd", "even", "odd")
            count += 1
            '-----------------------------------------------
            vPer = IIf(IsDBNull(rs("Pag_Emp")), 0, rs("Pag_Emp"))
            vGov = IIf(IsDBNull(rs("Pag_Emr")), 0, rs("Pag_Emr"))


            vOut += emrTIN & "," & philhealthPagibig & "," & rs("Emp_Lname") & "," & rs("Emp_Fname") & "," & rs("Emp_Mname") & _
                    "," & Format(rs("PayDate"), "yyyyMM") & ",,," & Format(rs("Pag_Emp"), "#,##0.00") & "," & _
                    Format(rs("Pag_Emr"), "#,##0.00") & "," & Format(rs("Pag_Emp") + rs("Pag_Emr"), "#,##0.00") & "," & vbNewLine
            '-------------------comment out lang
            'vOut += "DT"
            ''pagibig no
            'vTmp = IIf(IsDBNull(rs("PagIbig_No")), Space(12), Mid(rs("PagIbig_No").ToString.Replace("-", ""), 1, 12))
            'vTmp = vTmp & Space(12 - vTmp.Length)
            'vOut += vTmp
            ''emp id
            'vTmp = Mid(rs("Emp_Cd"), 1, 15)
            'vTmp = vTmp & Space(15 - vTmp.Length)
            'vOut += vTmp
            ''last name
            'vTmp = Mid(rs("Emp_Lname"), 1, 30)
            'vTmp = vTmp & Space(30 - vTmp.Length)
            'vOut += vTmp
            ''first name
            'vTmp = Mid(rs("Emp_Fname"), 1, 30)
            'vTmp = vTmp & Space(30 - vTmp.Length)
            'vOut += vTmp
            ''middle name
            'vTmp = Mid(rs("Emp_Mname"), 1, 30)
            'vTmp = vTmp & Space(30 - vTmp.Length)
            'vOut += vTmp
            ''employee share
            'vTmp = Space(13 - Format(vPer, "#,##0.00").ToString.Length) & Format(vPer, "#,##0.00")
            'vOut += vTmp
            ''employer share
            'vTmp = Space(13 - Format(vGov, "#,##0.00").ToString.Length) & Format(vGov, "#,##0.00")
            'vOut += vTmp
            ''tin
            'vTmp = IIf(IsDBNull(rs("Tin")), Space(15), Mid(rs("Tin").ToString.Replace("-", ""), 1, 15))
            'vTmp = vTmp & Space(15 - vTmp.Length)
            'vOut += vTmp
            ''bday
            'If IsDBNull(rs("Bday")) Then
            '    vTmp = Space(8)
            'Else
            '    vTmp = Format(rs("Bday"), "yyyy/MM/dd")
            'End If
            'vTmp = vTmp.Replace("/", "")
            'vOut += vTmp & vbCrLf
            '--------------
        Loop
        rs.Close()
        cm.Dispose()
        cmRef.Dispose()
        c.Close()

        '-------------------------
        Dim vFileName As String = Server.MapPath(".") & "\downloads\" & Session.SessionID & "-pagibig.csv"
        If IO.File.Exists(vFileName) Then
            Try
                IO.File.Delete(vFileName)
            Catch ex As IO.IOException
                vScript = "alert('Error deleting temp file. " & ex.Message.Replace("'", "\'").Replace(vbCrLf, "\n") & "');"
            End Try
        End If

        Try
            IO.File.WriteAllText(vFileName, vOut)
        Catch ex As IO.IOException
            vScript = "alert('Error writing text file. " & ex.Message.Replace("'", "\'").Replace(vbCrLf, "\n") & "');"
        End Try
        lnkDownload.NavigateUrl = "downloads/" & Session.SessionID & "-pagibig.csv"
        '--------------------------------------------

        vData += "<tr class='activeBar' style='font-weight:bold'>" & _
                     "<td class='labelR' colspan='4'>Grand Total</td>" & _
                     "<td class='labelR'>" & Format(vEShareTotal, "#,###,##0.00") & "</td>" & _
                     "<td class='labelR'>" & Format(vEmShareTotal, "#,###,##0.00") & "</td>" & _
                     "<td class='labelR'>" & Format(vTotalTotal, "#,###,##0.00") & "</td>" & _
                 "</tr>"
        vData += "</table></center></body></html>"

        vPdfFile = Server.MapPath(".") & "\downloads\" & Session.SessionID & "-pagibig_report.html"
        Try
            If IO.File.Exists(vPdfFile) Then
                Kill(vPdfFile)
            End If
        Catch ex As system.exception
            vScript = "alert('An error occurred while trying to save to HTML file. Error code is:\n" & _
                ex.Message.Replace("'", "") & "');"
        End Try
        IO.File.WriteAllText(vPdfFile, vData)
        divReport.Attributes.Add("src", "downloads/" & Session.SessionID & "-pagibig_report.html")

    End Sub

    Protected Sub cmbReport_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbReport.SelectedIndexChanged
        rdoSSOption.Visible = False
        Select Case cmbReport.SelectedValue.ToLower
            Case "sss_edinet"
                cmdSetup.Text = "SSS Setup"
                cmdSetup.Visible = True
                'ssoption.Style.visibility = "hidden"
                rdoSSOption.Visible = True
            Case "sss_cont"
                cmdSetup.Text = "SSS Setup"
                cmdSetup.Visible = True
                'ssoption.Style.visibility = "hidden"
                rdoSSOption.Visible = True
            Case "philhealth"
                cmdSetup.Text = "Philhealth Setup"
                cmdSetup.Visible = True
            Case "pagibig", "pgsal", "pghos"
                cmdSetup.Text = "Pagibig Setup"
                cmdSetup.Visible = True
            Case Else
                cmdSetup.Text = ""
                cmdSetup.Visible = False
        End Select
    End Sub

    Protected Sub cmdSetup_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSetup.Click
        Session("office") = cmbOfc.SelectedValue
        Select Case cmdSetup.Text.ToLower
            Case "sss setup"
                If cmbReport.SelectedValue.ToLower = "sss_cont" Then
                    vScript = "editwin=window.open('sssetup.aspx','ssswin','toolbar=no,location=no,width=500,height=200,top=100,left=100');"
                Else
                    vScript = "editwin=window.open('sssetup_edinet.aspx','ssswin','toolbar=no,location=no,width=500,height=200,top=100,left=100');"
                End If

            Case "philhealth setup"
                vScript = "editwin=window.open('phicsetup.aspx','phicwin','toolbar=no,location=no,width=500,height=200,top=100,left=100');"
            Case "pagibig setup"
                vScript = "editwin=window.open('pagibigsetup.aspx','pagibigwin','toolbar=no,location=no,width=500,height=200,top=100,left=100');"
        End Select
    End Sub

    Private Sub PHILHEALTH_REMITTANCE_REVISED(ByVal pEmpList As String)
        'Dim vPrn As New VSPrinter8Lib.VSPrinter
        'Dim vPDF As New VSPDF8Lib.VSPDF8
        Dim vFormat As String = ""
        Dim vData As String = ""
        Dim vCompanyName As String = ""
        Dim vEmplyrAddress As String = ""
        Dim vEmplyrSSSNo As String = ""
        Dim vEmplyrTin As String = ""
        Dim vEmplyrPhicNo As String = ""
        Dim vEmplyrTelNo As String = ""
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim cmRef As New SqlClient.SqlCommand
        Dim rsRef As SqlClient.SqlDataReader



        Dim app_quater As Integer = 0
        Dim vName As String = ""
        Dim vmonth(3) As Integer

        Dim medicare_per1 As Double = 0  '1st month of the chosen quarter of the employee
        Dim medicare_gov1 As Double = 0  '1st month of the chosen quarter of the government
        Dim medicare_per2 As Double = 0  '2st month of the chosen quarter of the employee   
        Dim medicare_gov2 As Double = 0  '2st month of the chosen quarter of the employer
        Dim medicare_per3 As Double = 0  '3rd month of the chosen quarter of the employee   
        Dim medicare_gov3 As Double = 0  '3rd month of the chosen quarter of the employer
        Dim SalaryBracket1 As Double = 0  '1st month bracket of the chosen quarter of the employee base in philhealth table
        Dim SalaryBracket2 As Double = 0  '2st month bracket of the chosen quarter of the employee base in philhealth table
        Dim SalaryBracket3 As Double = 0  '3rd month bracket of the chosen quarter of the of the employee base in philhealth table
        Dim TotalPS1stmonth As Double = 0
        Dim TotalES1stmonth As Double = 0
        Dim TotalPS2ndmonth As Double = 0
        Dim TotalES2ndmonth As Double = 0
        Dim TotalPS3rdmonth As Double = 0
        Dim TotalES3rdmonth As Double = 0
        Dim Total1stMonth As Double = 0
        Dim Total2ndMonth As Double = 0
        Dim Total3rdMonth As Double = 0
        Dim TotalEmp1stMonth As Integer = 0
        Dim TotalEmp2ndMonth As Integer = 0
        Dim TotalEmp3rdMonth As Integer = 0
        Dim vPdfFile As String = ""
        Dim vOut As String = ""
        Dim vClass As String = "odd"

        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c

        If cmbOfc.SelectedValue <> "All" Then
            cm.CommandText = "SELECT Company_Name,Address,Employer_SssNo,Tin,PhicNo,Phone " & _
                         "FROM glsyscntrl WHERE AgencyCd='" & cmbOfc.SelectedValue & "'"
        Else
            cm.CommandText = "SELECT TOP 1 Company_Name,Address,Employer_SssNo,Tin,PhicNo,Phone " & _
                         "FROM glsyscntrl"
        End If

        rs = cm.ExecuteReader
        If rs.Read Then
            vCompanyName = IIf(IsDBNull(rs("Company_Name")), "UNKNOWN", rs("Company_Name"))
            vEmplyrAddress = IIf(IsDBNull(rs("Address")), "UNKNOWN", rs("Address"))
            vEmplyrSSSNo = IIf(IsDBNull(rs("Employer_SssNo")), "UNKNOWN", rs("Employer_SssNo"))
            vEmplyrTin = IIf(IsDBNull(rs("Tin")), "UNKNOWN", rs("Tin"))
            vEmplyrPhicNo = IIf(IsDBNull(rs("PhicNo")), "UNKNOWN", rs("PhicNo"))
            vEmplyrTelNo = IIf(IsDBNull(rs("Phone")), "UNKNOWN", rs("Phone"))
        End If
        rs.Close()
        cm.Dispose()
        c.Close()

        'vData = "<html><head><title>Employer's Quarterly Remittance Report</title><link href='../redtheme/red.css' rel='stylesheet' type='text/css'/></head><body><center>"
        'vData += "<h2>RF1</h2>"
        'vData += "<h4>Employer's Quarterly Remittance Report</h4>"

        vData = "<html><head><title>Employer's Quarterly Remittance Report</title><link href='../redtheme/red.css' rel='stylesheet' type='text/css'/></head><body><center>"

        vData += "<br/><table border='0' style='border-collapse:collapse; border: solid 0px #000000; width: 950px; height: 100;'>"
        vData += "<tr><td rowspan='4' style='width:40px;'></td><td rowspan='4' style='border: solid 1px #000000; width: 100px; text-align:center; font-size: 35px; background: #cccccc;'>RF1</td><td rowspan='2' style='width: 150px; height: 50px; border: solid 1px #000000; text-align:center; font-size: 10px;'>Employer's Quarterly </br>Remittance Report</td><td colspan='11' class='labelC' style='border-top: solid 1px #000000; border-bottom: solid 1px #000000;'>F O R&nbsp;&nbsp;&nbsp;P H I L H E A L T H &nbsp;&nbsp;&nbsp;  U S E</td></tr>"
        vData += "<tr><td rowspan='2' colspan='6' class='labelL' valign='top' style='padding-top: 10px;'>Date Screened :</br></br></br>By :</td><td rowspan='3' class='labelL' valign='top' style='padding-top: 10px; width: 150px; border-bottom: solid 1px #000000;'>Action Taken :</td><td rowspan='2' class='labelL' valign='top' style='padding-top: 10px; border-left: solid 1px #000000;'>Date Received :</br></br></br>By :</td><td colspan='3'>&nbsp;</td></tr>"
        vData += "<tr><td rowspan='2' style='height: 50px; text-align:center; font-size: 13px; border: solid 1px #000000;'><b>DISKETTE</br>REPORTING</b></td><td colspan='3' style='border-bottom: solid 1px #000000;'>&nbsp;</td></tr>"
        vData += "<tr><td colspan='6' class='labelL' style='padding-left: 20px; border-top: solid 1px #000000; border-bottom: solid 1px #000000;'>Signature over Printed Name</td><td class='labelL' style='padding-left: 20px; border-left: solid 1px #000000; border-bottom: solid 1px #000000; border-top: solid 1px #000000;'>Signature over Printed Name</td><td colspan='3' style='border-bottom: solid 1px #000000;'>&nbsp;</td></tr>"
        vData += "</table><br/>"



        'vData += "<tr><td></td></tr>"
        'vData += "<tr><td></td></tr>"
        'vData += "<tr><td>Date Screened:</td><td>&nbsp;</td><td>Action Taken:</td><td>&nbsp;</td><td>Date Received:</td><td>&nbsp;</td></tr>"
        'vData += "<tr><td>By:</td><td>&nbsp;</td><td>By:</td><td>&nbsp;</td></tr>"
        'vData += "<tr><td>Signature over Printed Name</td><td>Signature over Printed Name</td></tr>"


        Select Case Val(cmbMonth.SelectedValue)

            Case 1  'January
                app_quater = 1
                vmonth(1) = 1
                vmonth(2) = 0
                vmonth(3) = 0
            Case 2  'February
                app_quater = 1

                vmonth(1) = 1
                vmonth(2) = 2
                vmonth(3) = 0
            Case 3  'March
                app_quater = 1
                vmonth(1) = 1
                vmonth(2) = 2
                vmonth(3) = 3
            Case 4  'April
                app_quater = 2
                vmonth(1) = 4
                vmonth(2) = 0
                vmonth(3) = 0
            Case 5  'May
                app_quater = 2
                vmonth(1) = 4
                vmonth(2) = 5
                vmonth(3) = 0
            Case 6  'June
                app_quater = 2
                vmonth(1) = 4
                vmonth(2) = 5
                vmonth(3) = 6
            Case 7  'July
                app_quater = 3
                vmonth(1) = 7
                vmonth(2) = 0
                vmonth(3) = 0
            Case 8  'August
                app_quater = 3
                vmonth(1) = 7
                vmonth(2) = 8
                vmonth(3) = 0
            Case 9  'September
                app_quater = 3
                vmonth(1) = 7
                vmonth(2) = 8
                vmonth(3) = 9
            Case 10 'October
                app_quater = 4
                vmonth(1) = 10
                vmonth(2) = 0
                vmonth(3) = 0
            Case 11 'November
                app_quater = 4
                vmonth(1) = 10
                vmonth(2) = 11
                vmonth(3) = 0
            Case 12 'December
                app_quater = 4
                vmonth(1) = 10
                vmonth(2) = 11
                vmonth(3) = 12
        End Select

        vData += "<table border='1' style='border-collapse:collapse; width: 950px;' class='label'>"
        vData += "<tr>" & _
                      "<td rowspan='5' class='labelL' style='width:40px'></td>" & _
                      "<td class='labelL' style='width:100px;'>PHILHEALTH NO.:</td>" & _
                      "<td colspan='12' class='labelL' >" & vEmplyrPhicNo & "</td>" & _
                 "</tr>"
        vData += "<tr>" & _
                      "<td class='labelL'>EMPLOYER TIN:</td>" & _
                      "<td colspan='12' class='labelL'>" & vEmplyrTin & "</td>" & _
                 "</tr>"
        vData += "<tr>" & _
                      "<td class='labelL'>EMPLOYER SSS:</td>" & _
                      "<td colspan='12' class='labelL'>" & vEmplyrSSSNo & "</td>" & _
                 "</tr>"
        vData += "<tr><td class='labelL'>EMPLOYER NAME:</td>" & _
                     "<td class='labelL' colspan='7'>" & vCompanyName & "</td>" & _
                            "<td class='labelR' colspan='2'>EMPLOYER TYPE: P</td>" & _
                            "<td class='labelR' colspan='2'>PRIVATE</td>" & _
                            "<td class='labelR' colspan='2'>APPLICABLE QTR:" & Format(app_quater, "##") & "</td>" & _
                        "</tr>"
        vData += "<tr><td class='labelL'>MAILING ADDRESS:</td>" & _
                      "<td class='labelL' colspan='7'>" & vEmplyrAddress & "</td>" & _
                      "<td class='labelL' colspan='3'>TYPE OF REPORT:R</td>" & _
                      "<td class='labelR' colspan='2'>REGULAR RF1</td>" & _
                      "<td class='labelR'>YEAR:</td>" & _
                            "<td class='labelL'>" & cmbYear.SelectedValue & "</td>" & _
                 "</tr>"

        vData += "<tr class='titleBar'>" & _
                      "<th rowspan='3'>#</th>" & _
                      "<th colspan='3' rowspan='2'>NAME OF EMPLOYEES</th>" & _
                      "<th rowspan='2'>&nbsp;</th>" & _
                      "<th rowspan='2' colspan ='3'>Salary Bracket</th>" & _
                      "<th colspan ='6' >NHIP PREMIUM CONTRIBUTIONS</th>" & _
                      "<th colspan ='3'>REMARKS</th>" & _
                      "</tr>"

        vData += "<tr class='titleBar'>" & _
                      "<th colspan ='2'>1st Month </th>" & _
                      "<th colspan ='2'>2st Month </th>" & _
                      "<th colspan ='2'>3st Month </th>" & _
                      "<th colspan ='3'>SP  Separated / NE  No Earnings</th>" & _
                      "</tr>"


        vData += "<tr class='titleBar'>" & _
                      "<th>SURNAME</th>" & _
                      "<th>GIVEN NAME</th>" & _
                      "<th>MIDDLE NAME</th>" & _
                      "<th>Phil_No/SSS</th>" & _
                      "<th>1ST</th>" & _
                      "<th>2ND</th>" & _
                      "<th>3RD</th>" & _
                      "<th>PS</th>" & _
                      "<th>ES</th>" & _
                      "<th>PS</th>" & _
                      "<th>ES</th>" & _
                      "<th>PS</th>" & _
                      "<th>ES</th>" & _
                      "<th colspan ='3'>NH  Newly Hired + MMDDYYYY</th>" & _
                      "</tr>"

        '------------------
        c.Open()
        cm.Connection = c
        cm.CommandText = "SELECT distinct Emp_Cd,Name FROM py_report WHERE month(PayDate) in (" & _
                          vmonth(1) & "," & vmonth(2) & "," & vmonth(3) & ") AND year(PayDate)=" & cmbYear.SelectedValue & _
                          pEmpList & " ORDER BY Name"

        rs = cm.ExecuteReader
        Dim count As Integer = 1
        Dim SSSPhilHealth As String = ""
        Do While rs.Read
            cmRef.Connection = c
            cmRef.CommandText = "SELECT Emp_Lname,Emp_Fname,Emp_Mname,SSS_No,PhicNo,Rate_Month FROM py_emp_master" & _
                                " WHERE Emp_Cd='" & rs("Emp_Cd") & "'"
            rsRef = cmRef.ExecuteReader

            If rsRef.Read Then
                If IsDBNull(rsRef("PhicNo")) Then
tin:
                    If IsDBNull(rsRef("SSS_No")) Then
                        SSSPhilHealth = "Unknown"
                    Else
                        If rsRef("SSS_No").ToString.Trim = "" Then
                            SSSPhilHealth = "Unknown"
                        Else
                            SSSPhilHealth = rsRef("SSS_No")
                        End If
                    End If
                Else
                    If rsRef("PhicNo").ToString.Trim = "" Then
                        GoTo tin
                    End If
                    SSSPhilHealth = rsRef("PhicNo")
                End If
                vName += "<tr class='" & vClass & "'>" & _
                             "<td class='labelC' style='border-collapse:collapse; border-left: solid 1px #000000;'>" & count & ".</td>" & _
                             "<td class='labelL' style='border-collapse:collapse; border-left: solid 1px #000000;'>" & IIf(IsDBNull(rsRef("Emp_Lname")), "UNKNOWN", rsRef("Emp_Lname").ToString.Replace(".", "").Replace("-", "")) & "</td>" & _
                             "<td class='labelL' style='border-collapse:collapse; border-left: solid 1px #000000;'>" & IIf(IsDBNull(rsRef("Emp_Fname")), "UNKNOWN", rsRef("Emp_Fname").ToString.Replace(".", "").Replace("-", "")) & "</td>" & _
                             "<td class='labelL' style='border-collapse:collapse; border-left: solid 1px #000000;'>" & IIf(IsDBNull(rsRef("Emp_Mname")), "UNKNOWN", rsRef("Emp_Mname").ToString.Replace(".", "").Replace("-", "")) & "</td>" & _
                             "<td class='labelL' style='border-collapse:collapse; border-left: solid 1px #000000;'>" & SSSPhilHealth.ToString.Replace("-", "") & "</td>"

            Else
                vName += "<tr class='" & vClass & "'>" & _
                              "<td class='labelC' style='border-collapse:collapse; border-left: solid 1px #000000;'>" & count & ".</td>" & _
                              "<td class='labelL' style='border-collapse:collapse; border-left: solid 1px #000000;'>UNKNOWN</td>" & _
                              "<td class='labelL' style='border-collapse:collapse; border-left: solid 1px #000000;'>UNKNOWN</td>" & _
                              "<td class='labelL' style='border-collapse:collapse; border-left: solid 1px #000000;'>UNKNOWN</td>" & _
                              "<td class='labelL' style='border-collapse:collapse; border-left: solid 1px #000000;'>UNKNOWN</td>"

            End If

            rsRef.Close()

            medicare_per1 = 0
            medicare_gov1 = 0
            cmRef.CommandText = "SELECT SUM(Medicare_Per) AS Medicare_Per, SUM(Medicare_Gov) AS Medicare_Gov " & _
                                "FROM py_report WHERE month(PayDate)=" & vmonth(1) & " AND year(PayDate)=" & cmbYear.SelectedValue & _
                                " AND Emp_Cd='" & rs("Emp_Cd") & "'"
            rsRef = cmRef.ExecuteReader

            If rsRef.Read Then
                If Not IsDBNull(rsRef("Medicare_Per")) Then
                    If rsRef("Medicare_Per") <> 0 Then
                        TotalEmp1stMonth += 1
                    End If
                End If
                medicare_per1 = IIf(IsDBNull(rsRef("Medicare_Per")), 0, rsRef("Medicare_Per"))
                medicare_gov1 = IIf(IsDBNull(rsRef("Medicare_Gov")), 0, rsRef("Medicare_Gov"))
            End If
            rsRef.Close()

            cmRef.CommandText = "SELECT Salary_Bracket FROM py_philhealth_table WHERE Per_Share=" & medicare_per1
            rsRef = cmRef.ExecuteReader
            SalaryBracket1 = 0
            If rsRef.Read Then
                SalaryBracket1 = rsRef("Salary_Bracket")
            End If
            rsRef.Close()
            '----------------------
            medicare_per2 = 0
            medicare_gov2 = 0
            If vmonth(2) <> 0 Then
                cmRef.CommandText = "SELECT SUM(Medicare_Per) AS Medicare_Per, SUM(Medicare_Gov) AS Medicare_Gov " & _
                                "FROM py_report WHERE month(PayDate)=" & vmonth(2) & " AND year(PayDate)=" & cmbYear.SelectedValue & _
                                " AND Emp_Cd='" & rs("Emp_Cd") & "'"
                rsRef = cmRef.ExecuteReader

                If rsRef.Read Then
                    If Not IsDBNull(rsRef("Medicare_Per")) Then
                        If rsRef("Medicare_Per") <> 0 Then
                            TotalEmp2ndMonth += 1
                        End If
                    End If
                    medicare_per2 = IIf(IsDBNull(rsRef("Medicare_Per")), 0, rsRef("Medicare_Per"))
                    medicare_gov2 = IIf(IsDBNull(rsRef("Medicare_Gov")), 0, rsRef("Medicare_Gov"))
                End If
                rsRef.Close()

                cmRef.CommandText = "SELECT Salary_Bracket FROM py_philhealth_table WHERE Per_Share=" & medicare_per2
                rsRef = cmRef.ExecuteReader
                SalaryBracket2 = 0
                If rsRef.Read Then
                    SalaryBracket2 = rsRef("Salary_Bracket")
                End If
                rsRef.Close()
            End If

            '----------------
            medicare_per3 = 0
            medicare_gov3 = 0
            If vmonth(3) <> 0 Then
                cmRef.CommandText = "SELECT SUM(Medicare_Per) AS Medicare_Per, SUM(Medicare_Gov) AS Medicare_Gov " & _
                                "FROM py_report WHERE month(PayDate)=" & vmonth(3) & " AND year(PayDate)=" & cmbYear.SelectedValue & _
                                " AND Emp_Cd='" & rs("Emp_Cd") & "'"
                rsRef = cmRef.ExecuteReader

                If rsRef.Read Then
                    If Not IsDBNull(rsRef("Medicare_Per")) Then
                        If rsRef("Medicare_Per") <> 0 Then
                            TotalEmp3rdMonth += 1
                        End If
                    End If
                    medicare_per3 = IIf(IsDBNull(rsRef("Medicare_Per")), 0, rsRef("Medicare_Per"))
                    medicare_gov3 = IIf(IsDBNull(rsRef("Medicare_Gov")), 0, rsRef("Medicare_Gov"))
                End If
                rsRef.Close()

                cmRef.CommandText = "SELECT Salary_Bracket FROM py_philhealth_table WHERE Per_Share=" & medicare_per3
                rsRef = cmRef.ExecuteReader
                SalaryBracket3 = 0
                If rsRef.Read Then
                    SalaryBracket3 = rsRef("Salary_Bracket")
                End If
                rsRef.Close()
            End If

            If medicare_per1 <> 0 Or medicare_per2 <> 0 Or medicare_per3 <> 0 Then
                vData += vName
                vData += "<td class='labelC' style='border-collapse:collapse; border-left: solid 1px #000000;'>" & SalaryBracket1 & "</td>" & _
                         "<td class='labelC' style='border-collapse:collapse; border-left: solid 1px #000000;'>" & SalaryBracket2 & "</td>" & _
                         "<td class='labelC' style='border-collapse:collapse; border-left: solid 1px #000000;'>" & SalaryBracket3 & "</td>" & _
                         "<td class='" & IIf(medicare_per1 = 0, "labelC", "labelR") & "' style='border-collapse:collapse; border-left: solid 1px #000000;'>" & IIf(medicare_per1 = 0, "-", Format(medicare_per1, "##0.00")) & "</td>" & _
                         "<td class='" & IIf(medicare_gov1 = 0, "labelC", "labelR") & "' style='border-collapse:collapse; border-left: solid 1px #000000;'>" & IIf(medicare_gov1 = 0, "-", Format(medicare_gov1, "##0.00")) & "</td>" & _
                         "<td class='" & IIf(medicare_per2 = 0, "labelC", "labelR") & "' style='border-collapse:collapse; border-left: solid 1px #000000;'>" & IIf(medicare_per2 = 0, "-", Format(medicare_per2, "##0.00")) & "</td>" & _
                         "<td class='" & IIf(medicare_gov2 = 0, "labelC", "labelR") & "' style='border-collapse:collapse; border-left: solid 1px #000000;'>" & IIf(medicare_gov2 = 0, "-", Format(medicare_gov2, "##0.00")) & "</td>" & _
                         "<td class='" & IIf(medicare_per3 = 0, "labelC", "labelR") & "' style='border-collapse:collapse; border-left: solid 1px #000000;'>" & IIf(medicare_per3 = 0, "-", Format(medicare_per3, "##0.00")) & "</td>" & _
                         "<td class='" & IIf(medicare_gov3 = 0, "labelC", "labelR") & "' style='border-collapse:collapse; border-left: solid 1px #000000; border-right: solid 1px #000000;'>" & IIf(medicare_gov3 = 0, "-", Format(medicare_gov3, "##0.00")) & "</td>" & _
                         "<td>&nbsp;</td>" & _
                         "<td>&nbsp;</td>" & _
                         "<td style='border-collapse; border-right: solid 1px #000000;'>&nbsp;</td>" & _
                         "</tr>"
                count += 1

                TotalPS1stmonth += medicare_per1
                TotalES1stmonth += medicare_gov1
                TotalPS2ndmonth += medicare_per2
                TotalES2ndmonth += medicare_gov2
                TotalPS3rdmonth += medicare_per3
                TotalES3rdmonth += medicare_gov3
            End If
            vName = ""
            vClass = IIf(vClass = "odd", "even", "odd")
        Loop
        Total1stMonth = TotalPS1stmonth + TotalES1stmonth
        Total2ndMonth = TotalPS2ndmonth + TotalES2ndmonth
        Total3rdMonth = TotalPS3rdmonth + TotalES3rdmonth

        cmRef.Dispose()
        rs.Close()
        cm.Dispose()
        c.Close()

        vData += "<tr><td colspan='5' style='border-top: solid 1px #000000;'></td><td class='labelR' colspan='3' style='border-left: 1px solid #000000; border-bottom: solid 1px #000000; border-top: solid 1px #000000;'>SUBTOTAL </td><td style='border-left: 1px solid #000000; border-bottom: solid 1px #000000; border-top: solid 1px #000000;' class='labelC'>" & Format(TotalPS1stmonth, "0.00") & "</td><td class='labelC' style='border-left: 1px solid #000000; border-bottom: solid 1px #000000; border-top: solid 1px #000000;'>" & Format(TotalES1stmonth, "0.00") & _
                "</td><td style='border-left: 1px solid #000000; border-bottom: solid 1px #000000; border-top: solid 1px #000000;' class='labelC'>" & Format(TotalPS2ndmonth, "0.00") & "</td><td style='border-left: 1px solid #000000; border-bottom: solid 1px #000000; border-top: solid 1px #000000;' class='labelC'>" & Format(TotalES2ndmonth, "0.00") & _
                "</td><td style='border-left: 1px solid #000000; border-bottom: solid 1px #000000; border-top: solid 1px #000000;' class='labelC'>" & Format(TotalPS3rdmonth, "0.00") & "</td><td style='border-left: 1px solid #000000; border-right: 1px solid #000000; border-bottom: solid 1px #000000; border-top: solid 1px #000000;' class='labelC'>" & Format(TotalES3rdmonth, "0.00") & "</td>" & _
                "<td style='border-top: 1px solid #000000'></td>" & _
                "<td style='border-top: 1px solid #000000'></td>" & _
                "<td style='border-top: 1px solid #000000'></td>" & _
                "</tr>"
        vData += "<tr><td colspan='5'></td><td class='labelR' colspan='3' style='border-left: solid 1px #000000; border-bottom: solid 1px #000000;'>PS+ES </td>" & _
                 "<td colspan='2' class='labelC' style='border-left: solid 1px #000000; border-bottom: solid 1px #000000;'>" & Format(Total1stMonth, "0.00") & "</td><td colspan='2' class='labelC' style='border-left: solid 1px #000000;  border-bottom: solid 1px #000000;'>" & Format(Total2ndMonth, "0.00") & _
                 "</td><td colspan='2' class='labelC' style='border-left: 1px solid #000000; border-right: 1px solid #000000;  border-bottom: solid 1px #000000;'>" & Format(Total3rdMonth, "0.00") & "</td>" & _
                 "<td></td>" & _
                "<td></td>" & _
                "<td></td>" & _
                 "</tr>"

        vData += "<tr><td colspan='5'></td><td class='labelC'colspan='3' style='border-left: solid 1px #000000; border-bottom: solid 1px #000000;'>GRAND<br/> TOTAL: </td>" & _
                                       "<td colspan='2' class='labelC' style='border-right: solid 1px #000000; border-bottom: solid 1px #000000;'><b>" & Format(Total1stMonth + Total2ndMonth + Total3rdMonth, "###,###,##0.00") & "</b></td>" & _
                                       "<td colspan='4' class='labelC'>Certified Correct:</td>" & _
                                       "<td colspan='3'></td>" & _
                                       "</tr>"

        'vData += "<tr><td colspan='14'>&nbsp;</td></tr>"
        vData += "</table><br/>"

        'border-collapse:collapse; border: solid 1px #000000;
        vData += "<table border='0' cellpadding='0' cellspacing='0' style='width: 950px; height: 100;'>"

        vData += "<tr><td rowspan='6' style='width:40px;'></td>" & _
                      "<td colspan='3' class='labelC' style='border-collapse:collapse; border-left: solid 1px #000000; border-top:solid 1px #000000;'>ME5 SUMMARY OF CONTRIBUTION PAYMENTS</td><td rowspan='2' class='labelC' style='border-collapse:collapse; border-top: solid 1px #000000;border-left: solid 1px #000000; border-right: solid 1px #000000;'>No of </br>Employees</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td colspan='4' class='labelC'>_____________________________</td><td>&nbsp;</td></tr>"
        vData += "<tr><td  class='labelC' style='border-collapse:collapse; border-top: solid 1px #000000;border-left: solid 1px #000000;'>Monthly/Quarterly</td><td class='labelC' style='border-collapse:collapse; border-top: solid 1px #000000;border-left: solid 1px #000000;'>Total Contribution</td><td class='labelC' style='border-collapse:collapse; border-top: solid 1px #000000;border-left: solid 1px #000000;'>Rec.No./Date Paid</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td class='labelC' colspan='4'>Signature over Printed Name</td><td>&nbsp;</td></tr>"
        vData += "<tr><td  class='labelC' style='border-collapse:collapse; border-top: solid 1px #000000;border-left: solid 1px #000000;'>1st Month</td><td  class='labelC' style='border-collapse:collapse; border-top: solid 1px #000000;border-left: solid 1px #000000;'>" & Format(Total1stMonth, "0.00") & "</td><td class='labelC' style='border-collapse:collapse; border-top: solid 1px #000000;border-left: solid 1px #000000;'>&nbsp;</td><td class='labelC' style='border-top: solid 1px #000000;border-left: solid 1px #000000; border-right: solid 1px #000000;'>" & TotalEmp1stMonth & "</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td colspan='4' class='labelC'>_____________________________</td><td>&nbsp;</td></tr>"
        vData += "<tr><td  class='labelC' style='border-collapse:collapse; border-top: solid 1px #000000;border-left: solid 1px #000000;'>2nd Month</td><td  class='labelC' style='border-collapse:collapse; border-top: solid 1px #000000;border-left: solid 1px #000000;'>" & Format(Total2ndMonth, "0.00") & "</td><td class='labelC' style='border-collapse:collapse; border-top: solid 1px #000000;border-left: solid 1px #000000;'>&nbsp;</td><td class='labelC' style='border-top: solid 1px #000000;border-left: solid 1px #000000; border-right: solid 1px #000000;'>" & TotalEmp2ndMonth & "</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td class='labelC' colspan='4'>Official Designation</td><td>&nbsp;</td></tr>"
        vData += "<tr><td  class='labelC' style='border-collapse:collapse; border-top: solid 1px #000000;border-left: solid 1px #000000;'>3rd Month</td><td  class='labelC' style='border-collapse:collapse; border-top: solid 1px #000000;border-left: solid 1px #000000;'>" & Format(Total3rdMonth, "0.00") & "</td><td class='labelC' style='border-collapse:collapse; border-top: solid 1px #000000;border-left: solid 1px #000000;'>&nbsp;</td><td class='labelC' style='border-top: solid 1px #000000;border-left: solid 1px #000000; border-right: solid 1px #000000;'>" & TotalEmp3rdMonth & "</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td colspan='4' class='labelC'>_____________________________</td><td>&nbsp;</td></tr>"
        vData += "<tr><td  style='border-collapse:collapse; border-bottom: solid 1px #000000;border-left: solid 1px #000000;'>&nbsp;</td><td style='border-collapse:collapse; border-bottom: solid 1px #000000;border-left: solid 1px #000000;'>&nbsp;</td><td style='border-collapse:collapse; border-bottom: solid 1px #000000;border-left: solid 1px #000000;'>&nbsp;</td><td style='border-collapse:collapse; border-bottom: solid 1px #000000;border-left: solid 1px #000000; border-right: solid 1px #000000;'>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td colspan='4' class='labelC'>Date</td><td>&nbsp;</td></tr>"
        vData += "</table><br/><br/>"



        vData += "</body></html>"
        vPdfFile = Server.MapPath(".") & "\downloads\" & Session.SessionID & "-philhealth_revised_report.html"
        Try
            If IO.File.Exists(vPdfFile) Then
                Kill(vPdfFile)
            End If
        Catch ex As system.exception
            vScript = "alert('An error occurred while trying to save to HTML file. Error code is:\n" & _
                ex.Message.Replace("'", "") & "');"
        End Try
        IO.File.WriteAllText(vPdfFile, vData)
        'vScript = "document.getElementById('frame').src = 'downloads/" & Session.SessionID & "-sss_report.html';"
        divReport.Attributes.Add("src", "downloads/" & Session.SessionID & "-philhealth_revised_report.html")


    End Sub

    Protected Sub cmbMonth_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles _
        cmbMonth.SelectedIndexChanged, cmbYear.SelectedIndexChanged

        CreateDays(cmbMonth.SelectedValue, cmbYear.SelectedValue, cmbDay)
    End Sub
    Private Sub CreateDays(ByVal pMonth As Integer, ByVal pYear As Integer, ByRef pCombo As WebControls.DropDownList)
        Dim i As Integer

        pCombo.Items.Clear()
        For i = 1 To MonthEND(CDate(pYear & "/" & pMonth & "/1")).Day
            pCombo.Items.Add(i)
        Next
    End Sub

    Protected Sub cmbMonthTo_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles _
        cmbMonthTo.SelectedIndexChanged, cmbYearTo.SelectedIndexChanged
        CreateDays(cmbMonthTo.SelectedValue, cmbYearTo.SelectedValue, cmbDayTo)
    End Sub
End Class