Imports denaro
Imports System.Data.SqlClient
Partial Class leave_to_cash
    Inherits System.Web.UI.Page
    Public vMsg As String = ""
    Public vData As String = ""
    Public vScript As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Session.RemoveAll()
            Server.Transfer("index.aspx")
        End If

        If Not CanRun(Session("caption"), Request.Item("id")) Then
            Session("denied") = "1"
            Server.Transfer("main.aspx")
            Exit Sub
        End If

        If Not IsPostBack Then
            Dim c As New SqlClient.SqlConnection(connStr)

            Try
                c.Open()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                c.Dispose()
                Exit Sub
            End Try

            BuildCombo("select Rc_Cd, Descr from rc where Rc_Cd in ('" & _
                Session("rclist").ToString.Replace(",", "','") & "') order by Descr ", cmbRC, c)
            BuildCombo("select AgencyCd,AgencyName from agency where Agencycd in ('" & _
                Session("agencylist").ToString.Replace(",", "','") & "') order by AgencyName", cmbOfc, c)
            BuildCombo("select Div_Cd,Descr from hr_div_ref where Div_Cd in ('" & _
                Session("divlist").ToString.Replace(",", "','") & "') order by Descr", cmbDiv, c)
            BuildCombo("select Dept_Cd,Descr from hr_dept_ref where Dept_Cd in ('" & _
                Session("deptlist").ToString.Replace(",", "','") & "') order by Descr", cmbDept, c)
            BuildCombo("select Section_Cd,Descr from hr_section_ref where Section_Cd in ('" & _
                Session("sectionlist").ToString.Replace(",", "','") & "') order by Descr", cmbSection, c)
            BuildCombo("select Unit_Cd,Descr from hr_unit_ref where Unit_Cd in ('" & _
                Session("unitlist").ToString.Replace(",", "','") & "') order by Descr", cmbUnit, c)
            BuildCombo("select EmploymentType,Descr from hr_employment_type where EmploymentType in ('" & _
                Session("typelist").ToString.Replace(",", "','") & "') order by Descr", cmbEmpType, c)
            BuildCombo("SELECT Leave_Cd, Descr FROM py_leave_ref", dropleavecd, c)
            BuildCombo("SELECT Incentive_Cd, Descr FROM py_other_incentvs", droptargetinc, c)

            c.Close()
            c.Dispose()

            txtpostdate.Text = Date.Now.ToString("MM/dd/yyyy")
            cmbRC.Items.Add("All")
            cmbRC.SelectedValue = "All"
            cmbOfc.Items.Add("All")
            cmbOfc.SelectedValue = "All"
            cmbDiv.Items.Add("All")
            cmbDiv.SelectedValue = "All"
            cmbDept.Items.Add("All")
            cmbDept.SelectedValue = "All"
            cmbSection.Items.Add("All")
            cmbSection.SelectedValue = "All"
            cmbUnit.Items.Add("All")
            cmbUnit.SelectedValue = "All"
            cmbEmpType.Items.Add("All Ranks")
            cmbEmpType.SelectedValue = "All Ranks"
            'DataRefresh(txtSearch.Text)
        End If
    End Sub
    Protected Sub cmdSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSearch.Click
        DataRefresh(txtSearch.Text)
    End Sub
    Private Sub DataRefresh(ByVal vLetter As String)
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim dr As SqlClient.SqlDataReader

        Dim cmRef As New SqlClient.SqlCommand
        Dim rsRef As sqlclient.sqldatareader

        Dim vSQL As String = ""
        Dim vFilter As String = ""
        Dim vEmpData As String = ""
        Dim vClass As String = "odd"
        Dim iCtr As Integer = 0
        Dim vCredit As Decimal = 0
        Dim vFundCredit As Decimal = 0

        vMsg = ""
        vData = ""

        cmRef.Connection = c
        vFilter = " where " & cmbType.SelectedValue & " like '" & vLetter & "%' "
        Select Case Val(cmbStatus.SelectedValue)
            Case 1  'active employees only
                vFilter += " and Date_Resign is null "
            Case 0  'inactive employees only
                vFilter += " and Date_Resign is not null "
        End Select

        If cmbRC.SelectedValue <> "All" Then   'filter by cost center
            vFilter += " and Rc_Cd='" & cmbRC.SelectedValue & "' "
        Else
            vFilter += " and Rc_Cd in ('" & Session("rclist").ToString.Replace(",", "','") & "') "
        End If
        If cmbOfc.SelectedValue <> "All" Then        'filter by office/agency
            vFilter += " and Agency_Cd='" & cmbOfc.SelectedValue & "' "
        Else
            vFilter += " and Agency_Cd in ('" & Session("agencylist").ToString.Replace(",", "','") & "') "
        End If
        If cmbDiv.SelectedValue <> "All" Then      'filter by division
            vFilter += " and Divcd='" & cmbDiv.SelectedValue & "' "
        Else
            vFilter += " and DivCd in ('" & Session("divlist").ToString.Replace(",", "','") & "') "
        End If
        If cmbDept.SelectedValue <> "All" Then  'filter by departments
            vFilter += " and DeptCd='" & cmbDept.SelectedValue & "' "
        Else
            vFilter += " and DeptCd in ('" & Session("deptlist").ToString.Replace(",", "','") & "') "
        End If
        If cmbSection.SelectedValue <> "All" Then 'filter by section
            vFilter += " and SectionCd='" & cmbSection.SelectedValue & "' "
        Else
            vFilter += " and SectionCd in ('" & Session("sectionlist").ToString.Replace(",", "','") & "') "
        End If
        If cmbUnit.SelectedValue <> "All" Then  'filter by units
            vFilter += " and UnitCd='" & cmbUnit.SelectedValue & "' "
        Else
            vFilter += " and UnitCd in ('" & Session("unitlist").ToString.Replace(",", "','") & "') "
        End If
        If cmbEmpType.SelectedValue <> "All Ranks" Then 'filter by employment types
            vFilter += " and EmploymentType='" & cmbEmpType.SelectedValue & "' "
        Else
            vFilter += " and EmploymentType in ('" & Session("typelist").ToString.Replace(",", "','") & "') "
        End If
        
        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            cmRef.Dispose()
            Exit Sub
        End Try

        cm.Connection = c
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                                            ''
        '' DATE MODIFIED: 3/6/2012                                                 ''
        '' PURPOSE: TO DETERMINE THE MAX CREDIT TO ROLL OVER FOR NEXT YEAR         ''
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        cm.CommandText = "select CashLeaveCredit from py_leave_ref where Leave_Cd='" & _
            dropleavecd.SelectedValue & "'"
        Try
            dr = cm.ExecuteReader
            If dr.Read Then
                vFundCredit = IIf(IsDBNull(dr("CashLeaveCredit")), 0, dr("CashLeaveCredit"))
            End If
            dr.Close()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to retrieve leave reference. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Close()
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try
        ''''''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''''''''

        cm.CommandText = "select Emp_Cd, Emp_Lname, Emp_Fname, Emp_Mname from py_emp_master " & vFilter & _
            " order by Emp_Lname,Emp_Fname,Emp_Mname"
        'chklist.Items.Clear()

        Try
            dr = cm.ExecuteReader

            If dr.HasRows Then
                vMsg = ""
                vEmpData = ""

                Do While dr.Read
                    iCtr += 1
                    vCredit = 0
                    cmRef.CommandText = "Select sum(BalanceLastYear) as Balance from py_emp_leave where  Emp_Cd='" & dr("Emp_Cd") & _
                        "' and Leave_Cd='" & dropleavecd.SelectedValue & "'"
                    rsRef = cmRef.ExecuteReader
                    If rsRef.Read Then
                        vCredit = IIf(IsDBNull(rsRef("Balance")), 0, rsRef("Balance"))
                    End If
                    rsRef.Close()

                    If vCredit > 0 Then
                        vMsg += "<tr class='" & vClass & "'>" & _
                            "<td class='labelC'><input class='labelC' type='checkbox' id='chk" & dr("Emp_Cd") & _
                            "' name='chk" & dr("Emp_Cd") & "'/></td>" & _
                            "<td class='labelL'>" & dr("Emp_Cd") & "</td>" & _
                            "<td class='labelL'>" & dr("Emp_Lname") & ", " & dr("Emp_Fname") & "</td>" & _
                            "<td class='labelL'>" & dropleavecd.SelectedValue & "</td>" & _
                            "<td class='labelR'>" & vCredit & "</td>" & _
                            "<td class='labelR'>" & vFundCredit & "</td>" & _
                            "<td class='labelR'>" & IIf(vCredit - vFundCredit < 0, 0, vCredit - vFundCredit) & "</td></tr>"
                        vClass = IIf(vClass = "odd", "even", "odd")
                        vEmpData += dr("Emp_Cd") & ","
                    End If
                Loop
                cmdpost.Enabled = True
            Else
                vMsg = "<span style='color:skyblue;font-size:1.1em;font-weight:bold;'>No records to display...</span>"
                cmdpost.Enabled = Not True
            End If
            dr.Close()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to retrieve Employee Leave Credits. Error is: " & ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            cm.Dispose()
            cmRef.Dispose()
            c.Close()
            c.Dispose()
        End Try
        txtCount.Value = iCtr
        If vEmpData <> "" Then
            vEmpData = Mid(vEmpData, 1, Len(vEmpData) - 1)
        End If
        txtEmpList.Value = vEmpData
    End Sub

    Protected Sub cmdReturn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.Click
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub cmdpost_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdpost.Click
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader

        'Dim cRef As New SqlClient.SqlConnection(connStr)
        Dim cmRef As New SqlClient.SqlCommand
        Dim rsRef As SqlClient.SqlDataReader

        Dim vEmpCd As String = ""
        Dim iCtr As Integer = 0
        Dim vEmp As String = ""
        Dim vLeave As String = dropleavecd.SelectedValue
        Dim vID As String
        Dim vRate As Decimal
        Dim vLeaveBal As Decimal
        Dim vAlert As String = ""
        Dim vConvAmt As Decimal
        Dim vIncent As String = droptargetinc.SelectedValue
        Dim vFundCredit As Decimal = 0

        c.Open()
        cm.Connection = c

        'cRef.Open()
        cmRef.Connection = c

        'For iCtr = 0 To Me.chklist.Items.Count - 1
        '    If chklist.Items(iCtr).Selected = True Then
        '        vEmp += chklist.Items(iCtr).Value & "','"
        '    End If
        'Next iCtr

        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                                            ''
        '' DATE MODIFIED: 3/6/2012                                                 ''
        '' PURPOSE: TO DETERMINE THE MAX CREDIT TO ROLL OVER FOR NEXT YEAR         ''
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        cm.CommandText = "select CashLeaveCredit from py_leave_ref where Leave_Cd='" & _
            dropleavecd.SelectedValue & "'"
        Try
            rs = cm.ExecuteReader
            If rs.Read Then
                vFundCredit = IIf(IsDBNull(rs("CashLeaveCredit")), 0, rs("CashLeaveCredit"))
            End If
            rs.Close()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to retrieve leave reference. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Close()
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try
        ''''''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''''''''

        cm.CommandText = "Select Emp_Cd,Rate_Day from py_emp_master where Date_Resign is null"
        rs = cm.ExecuteReader
        Do While rs.Read
            vID = rs("Emp_Cd")
            vConvAmt = 0
            If Request.Form("chk" & vID) <> Nothing Then
                vRate = IIf(IsDBNull(rs("Rate_Day")), 0, rs("Rate_Day"))

                If vRate = 0 Then
                    vAlert += "Emp_Code = " & vID & "\n"
                Else
                    cmRef.CommandText = "SELECT SUM(BalanceLastYear) AS Balance FROM py_emp_Leave WHERE Emp_Cd='" & _
                        vID & "' AND Leave_Cd='" & vLeave & "'"
                    rsRef = cmRef.ExecuteReader
                    If rsRef.Read Then
                        vLeaveBal = IIf(IsDBNull(rsRef("Balance")), 0, rsRef("Balance"))
                        vLeaveBal = vLeaveBal - vFundCredit
                        If vLeaveBal > 0 Then
                            vConvAmt = Math.Round(vLeaveBal * vRate, 2)
                        End If
                    End If
                    rsRef.Close()

                    If vConvAmt > 0 Then
                        cmRef.CommandText = "Insert into py_incentives_dtl(Incentive_Cd,Incentive_Amt, Emp_Cd, FromDate, ToDate, Recurring)" & _
                             "values('" & vIncent & "','" & vConvAmt & "','" & vID & "','" & _
                             Format(CDate(txtpostdate.Text), "yyyy/MM/dd") & "','" & _
                             Format(CDate(txtpostdate.Text), "yyyy/MM/dd") & "','0')"
                        cmRef.ExecuteNonQuery()

                        cmRef.CommandText = "Update py_emp_leave SET BalanceLastYear=0 where Emp_Cd='" & vID & "' and Leave_Cd='" & vLeave & "'"
                        cmRef.ExecuteNonQuery()
                    End If
                End If
            End If
        Loop
        rs.Close()

        vScript = "alert('Coverting leave to cash successful. You may see the posted results in Other Compensation monitoring module.');"

        If vAlert <> "" Then
            vAlert = vAlert.Substring(0, vAlert.Length - 2)
            vScript = "alert('Cannot proceed..Please correct first the corresponding salary of : \n\n" & vAlert & "');"
        End If

        'cRef.Close()
        cmRef.Dispose()
        'cRef.Dispose()

        c.Close()
        c.Dispose()
        cm.Dispose()

    End Sub
End Class
