﻿Imports denaro.fis
Partial Class emplist
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Or Session("uid") = Nothing Then
            vScript = "alert('Your login session has expired. Please re-login again.'); window.close();"
            Exit Sub
        End If

        If Not IsPostBack Then
            Dim c As New SqlClient.SqlConnection(connStr)
            Try
                c.Open()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                c.Dispose()
                Exit Sub
            End Try

            BuildCombo("select Rc_Cd,Descr from rc order by Descr", cmbRc, c)
            BuildCombo("select AgencyCd,AgencyName from agency order by AgencyName", cmbOfc, c)
            BuildCombo("select Div_Cd,Descr from hr_div_ref order by Descr", cmbDiv, c)
            BuildCombo("select Dept_Cd,Descr from hr_dept_ref order by Descr", cmbDept, c)
            BuildCombo("select Section_Cd,Descr from hr_section_ref order by Descr", cmbSection, c)
            BuildCombo("select Unit_Cd,Descr from hr_unit_ref order by Descr", cmbUnit, c)
            BuildCombo("select EmploymentType,Descr from hr_employment_type order by Descr", cmbRank, c)

            cmbRc.Items.Add("All")
            cmbOfc.Items.Add("All")
            cmbDiv.Items.Add("All")
            cmbDept.Items.Add("All")
            cmbSection.Items.Add("All")
            cmbUnit.Items.Add("All")
            cmbRank.Items.Add("All")

            cmbRc.SelectedValue = "All"
            cmbOfc.SelectedValue = "All"
            cmbDiv.SelectedValue = "All"
            cmbDept.SelectedValue = "All"
            cmbSection.SelectedValue = "All"
            cmbUnit.SelectedValue = "All"
            cmbRank.SelectedValue = "All"

            c.Close()
            c.Dispose()
            DataRefresh()
        End If
    End Sub
    Private Sub DataRefresh()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim vFilter As String = ""

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        cm.Connection = c
        If cmbRc.SelectedValue <> "All" Then
            vFilter += " and Rc_Cd='" & cmbRc.SelectedValue & "' "
        End If
        If cmbOfc.SelectedValue <> "All" Then
            vFilter += " and Agency_Cd='" & cmbOfc.SelectedValue & "' "
        End If
        If cmbDiv.SelectedValue <> "All" Then
            vFilter += " and DivCd='" & cmbDiv.SelectedValue & "' "
        End If
        If cmbDept.SelectedValue <> "All" Then
            vFilter += " and DeptCd='" & cmbDept.SelectedValue & "' "
        End If
        If cmbSection.SelectedValue <> "All" Then
            vFilter += " and SectionCd='" & cmbSection.SelectedValue & "' "
        End If
        If cmbUnit.SelectedValue <> "All" Then
            vFilter += " and UnitCd='" & cmbUnit.SelectedValue & "' "
        End If
        If cmbRank.SelectedValue <> "All" Then
            vFilter += " and EmploymentType='" & cmbRank.SelectedValue & "' "
        End If

        cm.CommandText = "select Emp_Cd,Emp_Lname,Emp_Fname from py_emp_master where Date_Resign is null " & _
            vFilter & " order by Emp_Lname,Emp_Fname"

        chkEmpList.Items.Clear()
        Try
            rs = cm.ExecuteReader
            Do While rs.Read
                chkEmpList.Items.Add(New ListItem(rs("Emp_Cd") & "=>" & rs("Emp_Lname") & ", " & rs("Emp_Fname"), rs("Emp_Cd")))
            Loop
            rs.Close()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to retrieve records. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            c.Dispose()
            cm.Dispose()
        End Try
    End Sub

    Protected Sub cmdSelect_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSelect.Click
        Dim i As Integer

        For i = 0 To chkEmpList.Items.Count - 1
            chkEmpList.Items(i).Selected = True
        Next
    End Sub

    Protected Sub cmdDeselect_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDeselect.Click
        Dim i As Integer

        For i = 0 To chkEmpList.Items.Count - 1
            chkEmpList.Items(i).Selected = False
        Next
    End Sub

    Protected Sub cmdRefresh_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdRefresh.Click
        DataRefresh()
    End Sub

    Protected Sub cmdSelect0_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSelect0.Click
        Dim vList As String = ""
        Dim i As Integer
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand

        For i = 0 To chkEmpList.Items.Count - 1
            If chkEmpList.Items(i).Selected Then
                vList += chkEmpList.Items(i).Value & ","
            End If
        Next
        If vList <> "" Then
            vList = Mid(vList, 1, Len(vList) - 1)
            Try
                c.Open()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                c.Dispose()
                cm.Dispose()
                Exit Sub
            End Try

            cm.Connection = c
            cm.CommandText = "update links set Emp_Cd='" & vList & "' where SeqId=" & Session("descr")
            Try
                cm.ExecuteNonQuery()
                vScript = "alert('Changes were successfully saved.'); window.close();"
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to execute query. Error is: " & ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            Finally
                c.Close()
                c.Dispose()
                cm.Dispose()
            End Try
        Else
            vScript = "alert('No Employees selected yet');"
        End If
    End Sub
End Class
