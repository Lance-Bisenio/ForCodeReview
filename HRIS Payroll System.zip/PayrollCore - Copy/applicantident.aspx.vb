Imports denaro
Partial Class applicantident
    Inherits System.Web.UI.Page
    Dim c As New sqlclient.sqlconnection
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If

        If Not IsPostBack Then
            Dim cm As New sqlclient.sqlcommand
            Dim dr As sqlclient.sqldatareader
            lblCaption.Text = "Applicant's Identification Information"
            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c
            cm.CommandText = "select * from hr_applicant_master where ApplicantNo=" & _
                Session("applicantno")
            dr = cm.ExecuteReader
            If dr.Read Then
                txtTIN.Text = IIf(IsDBNull(dr("Tin")), "", dr("Tin"))
                txtSSS.Text = IIf(IsDBNull(dr("Sss_No")), "", dr("Sss_No"))
                txtPagIbig.Text = IIf(IsDBNull(dr("PagIbig_No")), "", dr("PagIbig_No"))
                txtPhilHealth.Text = IIf(IsDBNull(dr("PhicNo")), "", dr("PhicNo"))
                txtGSIS.Text = IIf(IsDBNull(dr("Gsis_No")), "", dr("Gsis_No"))
                txtResCert.Text = IIf(IsDBNull(dr("Res_Cert")), "", dr("Res_Cert"))
            End If
            dr.Close()
            cm.Dispose()
            c.Close()
        End If
    End Sub

End Class
