Namespace denaro

    Partial Class empstep4
        Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub


        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region
        Public vScript As String = ""
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load, Me.Load
            If Session("uid") = "" Then
                vScript = "alert('Your login session has expired. Please login again.'); window.close();"
            End If
            If Not IsPostBack Then
                cmdPrev.Enabled = CanRun(Session("caption"), "41.2") Or CanRun(Session("caption"), "41.1") Or _
                    CanRun(Session("caption"), "41.3")
                If Not CanRun(Session("caption"), "41.4") Then
                    Server.Transfer("empstep5.aspx")
                    Exit Sub
                End If
                Session.Remove("oldval")
                Session.Remove("newval")

                Dim c As New SqlClient.SqlConnection(connStr)
                Dim cm As New SqlClient.SqlCommand
                Dim rs As SqlClient.SqlDataReader

                lblCaption.Text = "Employee Master Information (5 of 6)"

                Try
                    c.Open()
                Catch ex As SqlClient.SqlException
                    vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                        ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                    c.Dispose()
                    cm.Dispose()
                    Exit Sub
                End Try

                cm.Connection = c
                'cm.CommandText = "select Res_Cert,Gsis_No,Sss_No,Pagibig_No,PhicNo,Tin,Start_Date,Date_Resign," & _
                '    "EOCDate,DateSuspended,DateHold,Date_Retired,Emp_Lname,Emp_Fname,Emp_Mname,DateRegularized " & _
                '    "from py_emp_master where emp_cd='" & Session("empid") & "'"
                cm.CommandText = "select Res_Cert,Gsis_No,Sss_No,Pagibig_No,PhicNo,Tin,Start_Date,Date_Resign," & _
                    "EOCDate,DateSuspended,DateHold,Date_Retired,Emp_Lname,Emp_Fname,Emp_Mname,DateRegularized " & _
                    "from py_emp_master where emp_cd='" & Session("empid") & "'"
                Try
                    rs = cm.ExecuteReader
                    If rs.Read Then
                        lblName.Text = rs("Emp_Lname") & ", " & rs("Emp_Fname") & " " & rs("Emp_Mname")
                        txtResCert.Text = IIf(IsDBNull(rs("Res_Cert")), "", rs("Res_Cert"))
                        txtGSIS.Text = IIf(IsDBNull(rs("Gsis_No")), "", rs("Gsis_No"))
                        txtSSS.Text = IIf(IsDBNull(rs("Sss_No")), "", rs("Sss_No"))
                        txtPAGIBIG.Text = IIf(IsDBNull(rs("Pagibig_No")), "", rs("Pagibig_No"))
                        txtPHIC.Text = IIf(IsDBNull(rs("PhicNo")), "", rs("PhicNo"))
                        txtTIN.Text = IIf(IsDBNull(rs("Tin")), "", rs("Tin"))
                        txtDateStart.Text = IIf(IsDBNull(rs("Start_Date")), "", rs("Start_Date"))
                        txtDismissed.Text = IIf(IsDBNull(rs("EOCDate")), "", rs("EOCDate"))
                        txtDateEnd.Text = IIf(IsDBNull(rs("Date_Resign")), "", rs("Date_Resign"))
                        txtDateRetired.Text = IIf(IsDBNull(rs("Date_Retired")), "", rs("Date_Retired"))
                        txtDateHold.Text = IIf(IsDBNull(rs("DateHold")), "", rs("DateHold"))
                        txtDateSuspend.Text = IIf(IsDBNull(rs("DateSuspended")), "", rs("DateSuspended"))
                        txtRegularized.Text = IIf(IsDBNull(rs("DateRegularized")), "", rs("DateRegularized"))
                    End If
                    rs.Close()
                    Session("oldval") = "Res. Cert=" & txtResCert.Text & _
                        "|GSIS #=" & txtGSIS.Text & _
                        "|SSS #=" & txtSSS.Text & _
                        "|PAGIBIG #=" & txtPAGIBIG.Text & _
                        "|PHIC #=" & txtPHIC.Text & _
                        "|TIN=" & txtTIN.Text & _
                        "|Date Hired=" & txtDateStart.Text & _
                        "|Date Dismissed=" & txtDismissed.Text & _
                        "|Date Resigned=" & txtDateEnd.Text & _
                        "|Date Retired=" & txtDateRetired.Text & _
                        "|Date Hold=" & txtDateHold.Text & _
                        "|Date Regularized=" & txtRegularized.Text & _
                        "|Date Suspended=" & txtDateSuspend.Text
                Catch ex As SqlClient.SqlException
                    vScript = "alert('Error occurred while trying to retrieve record. Error is: " & _
                        ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                Finally
                    c.Close()
                    cm.Dispose()
                    c.Dispose()
                End Try
            End If
        End Sub

        Private Sub cmdPrev_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdPrev.Click
            Session.Remove("oldval")
            Session.Remove("newval")
            Server.Transfer("empstep3.aspx")
            If CanRun(Session("caption"), "41.3") Then
                Server.Transfer("empstep3.aspx")
            ElseIf CanRun(Session("caption"), "41.2") Then
                Server.Transfer("empstep2_1.aspx")
            Else
                Server.Transfer("empstep2.aspx")
            End If
        End Sub

        Private Sub cmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
            Session.Remove("oldval")
            Session.Remove("newval")
            Session.Remove("empid")
            vScript = "window.close();"
        End Sub

        Private Sub cmdSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSave.Click
            If Page.IsValid Then
                Dim c As New SqlClient.SqlConnection(connStr)
                Dim cm As New SqlClient.SqlCommand
                Dim vSQL As String
                Dim vDateStart As String = "null"
                Dim vDateEnd As String = "null"
                Dim vEOCDate As String = "null"
                Dim vDateSuspend As String = "null"
                Dim vDateHold As String = "null"
                Dim vDateRetired As String = "null"
                Dim vDateRegularized As String = "null"
                Dim vClearSup As String = ""

                If txtDateStart.Text <> "" Then vDateStart = "'" & Format(CDate(txtDateStart.Text), "yyyy/MM/dd") & "'"
                If txtDateEnd.Text <> "" Then
                    vDateEnd = "'" & Format(CDate(txtDateEnd.Text), "yyyy/MM/dd") & "'"
                    vClearSup = ",SupervisorCd='99' "
                End If

                If txtDismissed.Text <> "" Then vEOCDate = "'" & Format(CDate(txtDismissed.Text), "yyyy/MM/dd") & "'"
                If txtDateSuspend.Text <> "" Then vDateSuspend = "'" & Format(CDate(txtDateSuspend.Text), "yyyy/MM/dd") & "'"
                If txtDateHold.Text <> "" Then vDateHold = "'" & Format(CDate(txtDateHold.Text), "yyyy/MM/dd") & "'"
                If txtDateRetired.Text <> "" Then vDateRetired = "'" & Format(CDate(txtDateRetired.Text), "yyyy/MM/dd") & "'"
                If txtRegularized.Text <> "" Then vDateRegularized = "'" & Format(CDate(txtRegularized.Text), "yyyy/MM/dd") & "'"

                vSQL = "update py_emp_master set " & _
                    "Res_Cert='" & txtResCert.Text & _
                    "',Gsis_No='" & txtGSIS.Text & _
                    "',Sss_No='" & txtSSS.Text & _
                    "',Pagibig_No='" & txtPAGIBIG.Text & _
                    "',PhicNo='" & txtPHIC.Text & _
                    "',Tin='" & txtTIN.Text & _
                    "',Start_Date=" & vDateStart & _
                    ",Date_Resign=" & vDateEnd & _
                    ",EOCDate=" & vEOCDate & _
                    ",DateSuspended=" & vDateSuspend & _
                    ",DateHold=" & vDateHold & _
                    ",Date_Retired=" & vDateRetired & _
                    ",Modified_Date='" & Format(Now, "yyyy/MM/dd HH:mm:ss") & _
                    "',Modified_By='" & Session("uid") & _
                    "',DateRegularized=" & vDateRegularized & vClearSup & _
                    " where emp_cd='" & Session("empid") & "'"
                Try
                    c.Open()
                Catch ex As SqlClient.SqlException
                    vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                        ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                    c.Dispose()
                    cm.Dispose()
                    Exit Sub
                End Try

                cm.Connection = c
                cm.CommandText = vSQL
                Try
                    cm.ExecuteNonQuery()
                    Session("newval") = "Res. Cert=" & txtResCert.Text & _
                        "|GSIS #=" & txtGSIS.Text & _
                        "|SSS #=" & txtSSS.Text & _
                        "|PAGIBIG #=" & txtPAGIBIG.Text & _
                        "|PHIC #=" & txtPHIC.Text & _
                        "|TIN=" & txtTIN.Text & _
                        "|Date Hired=" & txtDateStart.Text & _
                        "|Date Dismissed=" & txtDismissed.Text & _
                        "|Date Resigned=" & txtDateEnd.Text & _
                        "|Date Retired=" & txtDateRetired.Text & _
                        "|Date Hold=" & txtDateHold.Text & _
                        "|Date Regularized=" & txtRegularized.Text & _
                        "|Date Suspended=" & txtDateSuspend.Text
                    EventLog(Session("uid"), Request.ServerVariables("REMOTE_ADDR"), "EDIT", Session("oldval"), Session("newval"), _
                        "Employee ID: " & Session("empid") & " was added/edited", "201 Profile", c)
                    Session.Remove("oldval")
                    Session.Remove("newval")
                    Server.Transfer("empstep5.aspx")
                Catch ex As SqlClient.SqlException
                    vScript = "alert('Error occurred while trying to save record. Error is: " & _
                        ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                Finally
                    c.Close()
                    cm.Dispose()
                    c.Dispose()
                End Try
            End If
        End Sub

        Private Sub vldDate_ServerValidate(ByVal source As System.Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles vldDate.ServerValidate
            args.IsValid = False
            If txtDateStart.Text <> "" And Not IsDate(txtDateStart.Text) Then
                vldDate.ErrorMessage = "Invalid date format in Start date field."
                Exit Sub
            End If
            If txtDateEnd.Text <> "" And Not IsDate(txtDateEnd.Text) Then
                vldDate.ErrorMessage = "Invalid date format in Date resign field."
                Exit Sub
            End If
            If txtDismissed.Text <> "" And Not IsDate(txtDismissed.Text) Then
                vldDate.ErrorMessage = "Invalid date format in Date Dismissed field."
                Exit Sub
            End If
            If txtDateSuspend.Text <> "" And Not IsDate(txtDateSuspend.Text) Then
                vldDate.ErrorMessage = "Invalid date format in Date suspended field."
                Exit Sub
            End If
            If txtDateHold.Text <> "" And Not IsDate(txtDateHold.Text) Then
                vldDate.ErrorMessage = "Invalid date format in Date hold field."
                Exit Sub
            End If
            If txtRegularized.Text <> "" And Not IsDate(txtRegularized.Text) Then
                vldDate.ErrorMessage = "Invalid date format in Date hold field."
                Exit Sub
            End If
            If txtDateRetired.Text <> "" And Not IsDate(txtDateRetired.Text) Then
                vldDate.ErrorMessage = "Invalid date format in Dat retired field."
                Exit Sub
            End If

            Dim c As New SqlClient.SqlConnection(connStr)
            Dim cm As New SqlClient.SqlCommand
            Dim rs As sqlclient.sqldatareader

            Try
                c.Open()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                c.Dispose()
                cm.Dispose()
                Exit Sub
            End Try

            cm.Connection = c
            If txtSSS.Text.Trim <> "" Then
                cm.CommandText = "select Emp_Cd,Emp_Lname,Emp_Fname from py_emp_master where Sss_No='" & _
                    txtSSS.Text & "' and Emp_Cd <> '" & Session("empid") & "'"
                rs = cm.ExecuteReader
                If rs.Read Then
                    vldDate.ErrorMessage = "SSS already in use by Employee: " & rs("Emp_Cd") & "->" & _
                        rs("Emp_Lname") & ", " & rs("Emp_Fname") & "."
                    vScript = "alert('SSS already in use by Employee: " & rs("Emp_Cd") & "->" & _
                        rs("Emp_Lname") & ", " & rs("Emp_Fname") & "');"
                    rs.Close()
                    c.Close()
                    cm.Dispose()
                    c.Dispose()
                    Exit Sub
                End If
                rs.Close()
            End If
            If txtPAGIBIG.Text.Trim <> "" Then
                cm.CommandText = "select Emp_Cd,Emp_Lname,Emp_Fname from py_emp_master where PagIbig_No='" & _
                    txtPAGIBIG.Text & "' and Emp_Cd <> '" & Session("empid") & "'"
                rs = cm.ExecuteReader
                If rs.Read Then
                    vldDate.ErrorMessage = "PagIBIG No. already in use by Employee: " & rs("Emp_Cd") & "->" & _
                        rs("Emp_Lname") & ", " & rs("Emp_Fname") & "."
                    vScript = "alert('PagIBIG No. already in use by Employee: " & rs("Emp_Cd") & "->" & _
                        rs("Emp_Lname") & "," & rs("Emp_Fname") & "');"
                    rs.Close()

                    c.Close()
                    c.Dispose()
                    cm.Dispose()
                    Exit Sub
                End If
                rs.Close()
            End If

            If txtTIN.Text.Trim <> "" Then
                cm.CommandText = "select Emp_Cd,Emp_Lname,Emp_Fname from py_emp_master where Tin='" & _
                    txtTIN.Text & "' and Emp_Cd <> '" & Session("empid") & "'"
                rs = cm.ExecuteReader
                If rs.Read Then
                    vldDate.ErrorMessage = "TIN already in use by Employee: " & rs("Emp_Cd") & "->" & _
                        rs("Emp_Lname") & ", " & rs("Emp_Fname") & "."
                    vScript = "alert('TIN already in use by Employee: " & rs("Emp_Cd") & "->" & _
                        rs("Emp_Lname") & ", " & rs("Emp_Fname") & "');"
                    rs.Close()

                    c.Close()
                    c.Dispose()
                    cm.Dispose()
                    Exit Sub
                End If
                rs.Close()
            End If

            If txtPHIC.Text.Trim <> "" Then
                cm.CommandText = "select Emp_Cd,Emp_Lname,Emp_Fname from py_emp_master where PhicNo='" & _
                    txtPHIC.Text & "' and Emp_Cd <> '" & Session("empid") & "'"
                rs = cm.ExecuteReader
                If rs.Read Then
                    vldDate.ErrorMessage = "Philhealth No. already in use by Employee: " & rs("Emp_Cd") & "->" & _
                        rs("Emp_Lname") & ", " & rs("Emp_Fname") & "."
                    vScript = "alert('Philhelath No. already in use by Employee: " & rs("Emp_Cd") & "->" & _
                        rs("Emp_Lname") & ", " & rs("Emp_Fname") & "');"
                    rs.Close()

                    c.Close()
                    c.Dispose()
                    cm.Dispose()
                    Exit Sub
                End If
                rs.Close()
            End If
            c.Close()
            cm.Dispose()
            c.Dispose()
            args.IsValid = True
        End Sub

        Protected Sub cmbQuickNavi_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbQuickNavi.SelectedIndexChanged
            Session.Remove("oldval")
            Session.Remove("newval")
            Server.Transfer(cmbQuickNavi.SelectedValue)
        End Sub
    End Class

End Namespace
