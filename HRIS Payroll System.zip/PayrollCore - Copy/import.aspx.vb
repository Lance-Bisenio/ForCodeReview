﻿Imports denaro
Partial Class import
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Dim vSQL As String = ""

    Private Sub BtnUpload_ServerClick(sender As Object, e As EventArgs) Handles BtnUpload.ServerClick

        Dim vFilename As String = ""

        If TxtBrowseFile.FileName = "" Then
            vScript = "alert('You must first supply a file to upload by clicking the Browse button.');"
            Exit Sub
        End If

        'If TxtBrows Then

        '    If TxtBrowseFile.va = "" Then
        '        vScript = "alert('You must first supply a file to upload by clicking the Browse button.');"
        '        Exit Sub
        '    End If

        '    Dim vType As String = ""

        'If cmdBrowse.FileName.Contains(".") Then
        '    vType = Mid(cmdBrowse.FileName, cmdBrowse.FileName.LastIndexOf(".") + 1)
        'End If


        If DdlTemplateList.SelectedValue = "" Then
            vScript = "alert('Please select file template reference.');"
            Exit Sub
        End If

        vFilename = Server.MapPath(".") & "\uploaded\import-files\" & DdlTemplateList.SelectedValue & "-" & Format(Now, "MMddyyyyHHmmss") & ".csv"

        Try
            TxtBrowseFile.SaveAs(vFilename)
        Catch ex As IO.IOException
            vScript = "alert('An error has occurred while trying to upload the file. Error is: " _
                & ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            Exit Sub
        End Try



        Select Case DdlTemplateList.SelectedValue
            Case "OptionDeductions"

            Case "OptionEarnings"

            Case "OptionAttendance"
                UploadAttendance(vFilename)

            Case "OptionAttendance"

        End Select



    End Sub
    Private Sub UploadAttendance(ByVal pFilename As String)
        Dim c As New SqlClient.SqlConnection(connStr)

        Dim cm As New SqlClient.SqlCommand
        Dim cmRef As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader

        Dim vContents() As String
        Dim vFields() As String
        Dim vRemarks As String = ""
        Dim i As Integer = 0

        cm.Connection = c
        cmRef.Connection = c
        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error has occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            cmRef.Dispose()
            Exit Sub
        End Try

        Try
            vContents = IO.File.ReadAllLines(pFilename)
        Catch ex As IO.FileLoadException
            vScript = "alert('Error reading uploaded file. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            cmRef.Dispose()
            Exit Sub
        End Try

        vSql = "delete from import_emp_time_log"
        cm.CommandText = vSql
        cm.ExecuteNonQuery()

        For i = vContents.GetLowerBound(0) To vContents.GetUpperBound(0)
            vFields = vContents(i).Split(",")
            Try

                vSQL = "delete from py_time_log where Emp_Cd='" & vFields(0) & "' and Tran_Date='" & Format(CDate(vFields(1)), "yyyy/MM/dd") & "' "
                cm.CommandText = vSQL
                Try
                    cm.ExecuteNonQuery()
                Catch ex As SqlClient.SqlException
                    vRemarks += "<br />" & ex.Message.Replace(vbCrLf, "").Replace("'", "")
                End Try



                vSQL = "insert into py_time_log (Emp_Cd, Tran_Date, Time_In, Time_Out, Time_OutDate, Reason,ShiftCd,Meal,no_edited,Transpo,EarlyOut) " _
                    & " values ('" & vFields(0) & "', '" & vFields(1) & "', '" & vFields(2) _
                    & "', '" & vFields(3) & "','" & vFields(4) & "','Uploaded using Import Utility',0,0,0,0,0)"


                cm.CommandText = vSQL
                Try
                    cm.ExecuteNonQuery()
                Catch ex As SqlClient.SqlException
                    vRemarks += "<br />" & vSQL 'ex.Message.Replace(vbCrLf, "").Replace("'", "") 
                End Try

            Catch ex As System.Exception
                'vError += "Error in Row " & i & ": " & _
                '    ex.Message.Replace(vbCrLf, "").Replace("'", "") & ". Record skipped.<br/>"
            End Try
        Next

        vScript = "alert('Attendance Template successfully loaded.');"

        c.Close()
        c.Dispose()
        cm.Dispose()
        cmRef.Dispose()

        Response.Write(vRemarks)

        'divError.Visible = vError <> ""
        'CreateCSVFile()
        'RefreshLogs()
    End Sub

    Private Sub BtnSeach_ServerClick(sender As Object, e As EventArgs) Handles BtnSeach.ServerClick

    End Sub
End Class
