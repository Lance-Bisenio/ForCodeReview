﻿Imports denaro.fis
Partial Class randompick
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Or Session("uid") = Nothing Then
            vScript = "alert('Your login session has expired. Please re-login again.'); window.close();"
            Exit Sub
        End If
        If Not IsPostBack Then
            lblRC.Text = Request.Item("rc")
            lblOfc.Text = Request.Item("ofc")
            lblDiv.Text = Request.Item("div")
            lblDept.Text = Request.Item("dept")
            lblSection.Text = Request.Item("section")
            lblUnit.Text = Request.Item("unit")
            lblRank.Text = Request.Item("rank")
            lblEmpStatus.Text = Request.Item("status")
            lblPayDate.Text = Request.Item("paydate")
            DataRefresh()
        End If
    End Sub
    Private Sub DataRefresh()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        
        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        cm.Connection = c

        cm.CommandText = "select Emp_Cd, Name from py_report " & Session("limit") & " order by Name"

        chkList.Items.Clear()
        chkPick.Items.Clear()
        Try
            rs = cm.ExecuteReader
            Do While rs.Read
                chkList.Items.Add(New ListItem(rs("Emp_Cd") & "=>" & rs("Name"), rs("Emp_Cd")))
            Loop
            rs.Close()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to retrieve records. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            c.Dispose()
            cm.Dispose()
        End Try
    End Sub
    Protected Sub cmdPick_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdPick.Click
        Dim vPick As New Random()
        Dim iPick As Integer
        Dim iCtr As Integer

        chkPick.Items.Clear()
        For iCtr = 1 To Val(txtNo.Text)
            iPick = vPick.Next(chkList.Items.Count - 1)
            chkPick.Items.Add(New ListItem(chkList.Items(iPick).Text, chkList.Items(iPick).Value))
        Next
    End Sub

    Protected Sub cmdRefresh_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdRefresh.Click
        DataRefresh()
    End Sub

    Protected Sub cmdAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdAdd.Click
        Dim ictr As Integer

        For ictr = 0 To chkList.Items.Count - 1
            If chkList.Items(ictr).Selected Then
                chkPick.Items.Add(New ListItem(chkList.Items(ictr).Text, chkList.Items(ictr).Value))
            End If
        Next
    End Sub
    Private Function GetOT(ByVal pOTCd As String, ByVal pFromDate As Date, ByVal pDate As Date, _
                           ByVal pEmpCd As String, ByRef c As SqlClient.SqlConnection, _
                           Optional ByRef pAmount As Decimal = 0) As Decimal
        Dim cmTimeLog As New SqlClient.SqlCommand
        Dim rsTimeLog As SqlClient.SqlDataReader

        cmTimeLog.Connection = c
        cmTimeLog.CommandText = "select sum(Hrs_Rendered), sum(AmtConv) from py_emp_time_log where Emp_Cd='" & _
           pEmpCd & "' and TranDate between '" & Format(pFromDate, "yyyy/MM/dd") & "' and '" & _
           Format(pDate, "yyyy/MM/dd") & "' and TranCd in (" & _
           pOTCd & ")"
        rsTimeLog = cmTimeLog.ExecuteReader
        If rsTimeLog.Read Then
            GetOT = IIf(IsDBNull(rsTimeLog(0)), 0, rsTimeLog(0))
            pAmount = IIf(IsDBNull(rsTimeLog(1)), 0, rsTimeLog(1))
        Else
            GetOT = 0
            pAmount = 0
        End If
        rsTimeLog.Close()
        cmTimeLog.Dispose()
    End Function

    Private Function GetOTName(ByVal pOTCd As String, ByRef c As SqlClient.SqlConnection) As String
        Dim cmRef As New SqlClient.SqlCommand
        Dim rsRef As SqlClient.SqlDataReader

        cmRef.Connection = c
        cmRef.CommandText = "select Descr from py_ot_ref where OtCd='" & pOTCd & "'"
        rsRef = cmRef.ExecuteReader
        If rsRef.Read Then
            GetOTName = rsRef("Descr")
        Else
            GetOTName = ""
        End If
        rsRef.Close()
        cmRef.Dispose()
    End Function
    Private Sub DumpOT(ByRef pHourly As Decimal, ByVal pPrefix As String, ByVal pFrom As Date, ByVal pTo As Date, ByVal pEmpCd As String, _
                    ByRef rs As SqlClient.SqlDataReader, ByRef pDump As StringBuilder, ByRef c As SqlClient.SqlConnection)

        Dim i_Loop As Integer
        Dim vHrsRendered As Decimal
        Dim cmRef As New SqlClient.SqlCommand
        Dim rsRef As SqlClient.SqlDataReader
        Dim vMultiplier As Decimal = 0

        cmRef.Connection = c
        For i_Loop = 1 To 4
            If rs(pPrefix & i_Loop) <> 0 Then
                vHrsRendered = GetOT("'" & pPrefix & i_Loop & "'", pFrom, pTo, pEmpCd, c)
                cmRef.CommandText = "select OtPer from py_ot_ref where OtCd='" & pPrefix & i_Loop & "'"
                rsRef = cmRef.ExecuteReader
                vMultiplier = 0
                If rsRef.Read Then
                    vMultiplier = rsRef("OtPer")
                End If
                rsRef.Close()

                'now check if there's a custom settings
                cmRef.CommandText = "select Factor from py_ot_ref_dtl where OtCd='" & pPrefix & i_Loop & "' and EmploymentType='" & _
                    rs("EmploymentType") & "'"
                rsRef = cmRef.ExecuteReader
                If rsRef.Read Then
                    vMultiplier = rsRef("Factor")
                End If
                rsRef.Close()

                pDump.AppendLine("<tr><td class='labelR'>&nbsp;</td>")
                pDump.AppendLine("<td class='labelL'>" & GetOTName(pPrefix & i_Loop, c) & ":</td>" & _
                    "<td class='labelR'>" & Format(vHrsRendered, "##,##0.00") & "</td>" & _
                    "<td class='labelR'>" & Format(rs(pPrefix & i_Loop), "##,##0.00") & "</td>" & _
                    "<td>&nbsp;</td><td>&nbsp;</td><td class='labelR'>(" & _
                    pHourly & " * " & vHrsRendered & " * " & vMultiplier & ")</td></tr>")
            End If
        Next i_Loop

        cmRef.Dispose()
    End Sub
    Private Function GetIncentDeductName(ByVal pDeductionCd As String, ByRef pIncentCd As String, _
                                         ByRef c As SqlClient.SqlConnection) As String
        Dim cmPYSysCntrl As New SqlClient.SqlCommand
        Dim rsPYSysCntrl As SqlClient.SqlDataReader

        cmPYSysCntrl.Connection = c
        cmPYSysCntrl.CommandText = "select * from py_syscntrl"
        rsPYSysCntrl = cmPYSysCntrl.ExecuteReader

        rsPYSysCntrl.Read()
        If Not IsDBNull(rsPYSysCntrl(pDeductionCd)) Then
            pIncentCd = rsPYSysCntrl(pDeductionCd)
            If InStr(1, pDeductionCd, "Ded") > 0 Then
                GetIncentDeductName = GetLoanName(rsPYSysCntrl(pDeductionCd), c)
            Else
                GetIncentDeductName = GetIncentName(rsPYSysCntrl(pDeductionCd), c)
            End If
        Else
            GetIncentDeductName = ""
        End If
        rsPYSysCntrl.Close()
        cmPYSysCntrl.Dispose()
    End Function
    Private Function GetIncentName(ByVal pIncentCd As String, ByRef c As SqlClient.SqlConnection) As String
        If Trim(pIncentCd <> "") Then
            Dim cmRef As New SqlClient.SqlCommand
            Dim rsRef As SqlClient.SqlDataReader

            cmRef.Connection = c
            cmRef.CommandText = "select Descr from py_other_incentvs where Incentive_Cd='" & pIncentCd & "'"
            rsRef = cmRef.ExecuteReader
            GetIncentName = ""
            If rsRef.Read Then
                GetIncentName = rsRef("Descr")
            End If
            rsRef.Close()
            cmRef.Dispose()
        Else
            GetIncentName = ""
        End If
    End Function
    Private Function GetLoanName(ByVal LoanCd As String, ByRef c As SqlClient.SqlConnection) As String
        If Trim(LoanCd <> "") Then
            Dim cmRef As New SqlClient.SqlCommand
            Dim rsRef As SqlClient.SqlDataReader

            cmRef.Connection = c
            cmRef.CommandText = "select Loan_Name from py_loan_ref where Loan_Cd='" & LoanCd & "'"
            rsRef = cmRef.ExecuteReader
            GetLoanName = ""
            If rsRef.Read Then
                GetLoanName = rsRef("Loan_Name")
            End If
            rsRef.Close()
            cmRef.Dispose()
        Else
            GetLoanName = ""
        End If
    End Function

    Protected Sub cmdGenerate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdGenerate.Click
        Dim iCtr As Integer
        Dim vEmpCd As String
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cmRef As New SqlClient.SqlCommand
        Dim cmMatrix As New SqlClient.SqlCommand
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim rsRef As SqlClient.SqlDataReader
        Dim rsMatrix As SqlClient.SqlDataReader
        Dim vDump As New StringBuilder
        Dim vMonthlyRate As Decimal = 0
        Dim vUnionFactor As Decimal = 0
        Dim vTardiness As Decimal = 0
        Dim vUndertime As Decimal = 0
        Dim vHourly As Decimal = 0
        Dim vUnitAmt As Decimal = 0
        Dim vHrsRendered As Decimal = 0
        Dim vAbsentHrs As Decimal = 0
        Dim vAbsentAmt As Decimal = 0
        Dim vTardyHrs As Decimal = 0
        Dim vTardyAmt As Decimal = 0
        Dim vUTHrs As Decimal = 0
        Dim vUTAmt As Decimal = 0
        Dim vMultiplier As Decimal = 0
        Dim vIncentCd As String
        Dim vIncentName As String
        Dim vDeductName As String
        Dim vTotalIncome As Decimal
        Dim vTotalDed As Decimal
        Dim vPayDate As Date
        Dim vDetail As String = ""
        Dim vLOS As Decimal = 0
        Dim vStartDate As String = ""
        Dim vRC As String = ""
        Dim vDaysMonth As Decimal = 0

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            cmRef.Dispose()
            cmMatrix.Dispose()
            Exit Sub
        End Try

        cm.Connection = c
        cmRef.Connection = c
        cmMatrix.Connection = c

        cm.CommandText = "select Dates_to_Month from py_syscntrl"
        rs = cm.ExecuteReader
        If rs.Read Then
            vDaysMonth = rs("Dates_to_Month")
        End If
        rs.Close()

        vDump.AppendLine("<html>")
        vDump.AppendLine("<head>")
        vDump.AppendLine("<title>Random Picklist of Employee Payroll</title>")
        vDump.AppendLine("<link href='../redtheme/red.css' rel='stylesheet' type='text/css' />")
        vDump.AppendLine("</head>")
        vDump.AppendLine("<body><center>")
        vDump.AppendLine("<h4>Random Picklist of Employee Payroll</h4>")
        vDump.AppendLine("<h5>for payroll period %paydate%</h5><hr>")
        vDump.AppendLine("<table border='1' style='border-collapse:collapse; width:100%'>")
        For iCtr = 0 To chkPick.Items.Count - 1
            vEmpCd = chkPick.Items(iCtr).Value
            cm.CommandText = "select * from py_report " & Session("limit") & " and Emp_Cd='" & vEmpCd & "'"
            Try
                rs = cm.ExecuteReader
                If rs.Read Then
                    vPayDate = rs("PayDate")
                    vTotalIncome = 0
                    vTotalDed = 0

                    cmRef.CommandText = "select Start_Date from py_emp_master where Emp_Cd='" & vEmpCd & "'"
                    rsRef = cmRef.ExecuteReader
                    If rsRef.Read Then
                        vLOS = Math.Round(DateDiff(DateInterval.Month, rsRef("Start_Date"), Now) / 12, 2)
                        vStartDate = Format(rsRef("Start_Date"), "MM/dd/yyyy")
                    End If
                    rsRef.Close()

                    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                    '' MODIFIED BY:  VIC GATCHALIAN                       ''
                    '' DATE MODIFIED: 10/30/2012                          ''
                    '' PURPOSE: TO ADD THE COST CENTER OF THE EMPLOYEE    ''
                    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                    cmRef.CommandText = "select Descr from rc where Rc_Cd='" & rs("Rc_Cd") & "'"
                    rsRef = cmRef.ExecuteReader
                    If rsRef.Read Then
                        vRC = rs("Rc_Cd") & "=>" & rsRef("Descr")
                    End If
                    rsRef.Close()
                    '''''''''''''''' END OF MODIFICATION '''''''''''''''''''

                    vMultiplier = 1
                    cmRef.CommandText = "select Divisor from py_pay_mode where Pay_Cd='" & rs("Pay_Cd") & "'"
                    rsRef = cmRef.ExecuteReader
                    If rsRef.Read Then
                        vMultiplier = rsRef("Divisor")
                    End If
                    rsRef.Close()

                    vTotalIncome = rs("BasicRate")
                    vMonthlyRate = rs("BasicRate") * vMultiplier
                    vHourly = Math.Round(vMonthlyRate / vDaysMonth / 8, 3)
                    '''''''''''''''''''''''''''''''''''''''''''''''''''''''
                    '' MODIFIED BY:  VIC GATCHALIAN                      ''
                    '' DATE MODIFIED: 10/30/2012                         ''
                    '' PURPOSE: TO DISPLAY THE RETRIEVED COST CENTER     ''
                    '''''''''''''''''''''''''''''''''''''''''''''''''''''''
                    ''''''''''''''' OLD CODE ''''''''''''''''''''''''''''''
                    'vDump.AppendLine("<tr><td class='labelL' colspan=5>" & rs("Name") & _
                    '    "</td><td class='labelR'>Length of Service:</td><td class='labelL'>" & vLOS & _
                    '    " yrs. (Date Hired: " & vStartDate & ")</td></tr>")
                    ''''''''''''''' END OLD CODE ''''''''''''''''''''''''''
                    vDump.AppendLine("<tr class='activeBar'><td class='labelL' colspan=3>" & rs("Name") & _
                        "</td><td class='labelL' colspan=2>" & vRC & _
                        "</td><td class='labelR'>Length of Service:</td><td class='labelL'>" & vLOS & _
                        " yrs. (Date Hired: " & vStartDate & ")</td></tr>")
                    ''''''''''''''' END OF MODIFICATION '''''''''''''''''''

                    vDump.AppendLine("<tr><td class='labelL'>Hourly Rate</td>")

                    vDump.AppendLine("<td class='labelL'>Monthly Rate</td><td>&nbsp;</td>" & _
                        "<td class='labelR'>" & Format(vMonthlyRate, "###,##0.00") & "</td>" & _
                        "<td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>")

                    vDump.AppendLine("<tr><td class='labelR'>" & Format(vHourly, "##,##0.00") & "</td>")
                    vDump.AppendLine("<td class='labelL'>Basic Salary</td><td>&nbsp;</td>" & _
                        "<td class='labelR'>" & Format(rs("BasicRate"), "###,##0.00") & "</td>" & _
                        "<td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>")
                    vDump.AppendLine("<td>&nbsp;</td><td class='labelL'>Seniority Allowance:</td><td>&nbsp;</td>" & _
                        "<td class='labelR'>" & Format(rs("SeniorAllowance"), "###,##0.00") & "</td>" & _
                        "<td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>")

                    vTotalIncome += rs("SeniorAllowance")
                    vTotalIncome += rs("Absent")
                    vHrsRendered = GetOT("'ABSENT'", rs("FromDate"), rs("ToDate"), vEmpCd, c)
                    vDump.AppendLine("<tr><td class='labelR'>&nbsp;</td>")
                    vDump.AppendLine("<td class='labelL'>Absences:</td>" & _
                        "<td class='labelR'>" & Format(vHrsRendered, "##,##0.00") & "</td>" & _
                        "<td class='labelR'>" & Format(rs("Absent"), "##,##0.00") & "</td>" & _
                        "<td>&nbsp;</td><td>&nbsp;</td><td class='labelR'>" & _
                        IIf(rs("Absent") <> 0, "(" & vHrsRendered & " * " & vHourly & ")", "&nbsp;") & "</td></tr>")

                    vTotalIncome += rs("Tardiness") 'includes undertime

                    'get tardiness
                    vHrsRendered = GetOT("'TARD'", rs("FromDate"), rs("ToDate"), vEmpCd, c, vTardiness)

                    'get detailed info of tardiness 
                    cmRef.CommandText = "select TranDate,Hrs_Rendered from py_time_log_dtl where Emp_Cd='" & _
                        rs("Emp_Cd") & "' and TranCd='TARD' and TranDate between '" & Format(rs("FromDate"), "yyyy/MM/dd") & _
                        "' and '" & Format(rs("ToDate"), "yyyy/MM/dd") & "' and Hrs_Rendered <> 0"

                    vDetail = ""
                    rsRef = cmRef.ExecuteReader
                    Do While rsRef.Read
                        'get reference in the table 
                        vMultiplier = 1
                        cmMatrix.CommandText = "select Factor from py_tardiness_table where " & (rsRef("Hrs_Rendered") * 60) & _
                            " between FromMinutes and ToMinutes"
                        rsMatrix = cmMatrix.ExecuteReader
                        If rsMatrix.Read Then
                            vMultiplier = rsMatrix("Factor")
                        End If
                        rsMatrix.Close()
                        vDetail += Format(rsRef("TranDate"), "MM/dd/yyyy") & " (" & vHourly & " * " & vMultiplier & ")<br/>"
                    Loop
                    rsRef.Close()

                    
                    vDump.AppendLine("<tr valign='top'><td class='labelR'>&nbsp;</td>")
                    vDump.AppendLine("<td class='labelL'>Tardiness:</td>" & _
                        "<td class='labelR'>" & Format(vHrsRendered, "##,##0.00") & "</td>" & _
                        "<td class='labelR'>" & Format(vTardiness, "##,##0.00") & "</td>" & _
                        "<td>&nbsp;</td><td>&nbsp;</td><td class='labelR'>" & _
                        IIf(vTardiness <> 0, vDetail, "&nbsp;") & "</td></tr>")

                    'get undertime
                    vHrsRendered = GetOT("'UT'", rs("FromDate"), rs("ToDate"), vEmpCd, c, vUndertime)
                    'get detailed info of undertime 
                    cmRef.CommandText = "select TranDate,Hrs_Rendered from py_time_log_dtl where Emp_Cd='" & _
                        rs("Emp_Cd") & "' and TranCd='UT' and TranDate between '" & Format(rs("FromDate"), "yyyy/MM/dd") & _
                        "' and '" & Format(rs("ToDate"), "yyyy/MM/dd") & "' and Hrs_Rendered <> 0"

                    vDetail = ""
                    rsRef = cmRef.ExecuteReader
                    Do While rsRef.Read
                        'get reference in the table 
                        vMultiplier = 1
                        cmMatrix.CommandText = "select Factor from py_tardiness_table where " & (rsRef("Hrs_Rendered") * 60) & _
                            " between FromMinutes and ToMinutes"
                        rsMatrix = cmMatrix.ExecuteReader
                        If rsMatrix.Read Then
                            vMultiplier = rsMatrix("Factor")
                        End If
                        rsMatrix.Close()
                        vDetail += Format(rsRef("TranDate"), "MM/dd/yyyy") & " (" & vHourly & " * " & vMultiplier & ")<br/>"
                    Loop
                    rsRef.Close()


                    vDump.AppendLine("<tr valign='top'><td class='labelR'>&nbsp;</td>")
                    vDump.AppendLine("<td class='labelL'>Undertime:</td>" & _
                        "<td class='labelR'>" & Format(vHrsRendered, "##,##0.00") & "</td>" & _
                        "<td class='labelR'>" & Format(vUndertime, "##,##0.00") & "</td>" & _
                        "<td>&nbsp;</td><td>&nbsp;</td><td class='labelR'>" & _
                        IIf(vUndertime <> 0, vDetail, "&nbsp;") & "</td></tr>")


                    vTotalIncome += rs("Ot")
                    'get night differential
                    If rs("NDREG") + rs("A2") + rs("A3") + rs("A4") <> 0 Then
                        vHrsRendered = GetOT("'A2','A3','A4','NDREG'", rs("FromDate"), rs("ToDate"), vEmpCd, c)
                        cmRef.CommandText = "select OtPer from py_ot_ref where OtCd='A4'"
                        rsRef = cmRef.ExecuteReader
                        vMultiplier = 0
                        If rsRef.Read Then
                            vMultiplier = rsRef("OtPer")
                        End If
                        rsRef.Close()

                        'now check if there's a custom settings
                        cmRef.CommandText = "select Factor from py_ot_ref_dtl where OtCd in ('A1','A3','A4','NDREG') " & _
                            "and EmploymentType='" & rs("EmploymentType") & "'"
                        rsRef = cmRef.ExecuteReader
                        If rsRef.Read Then
                            vMultiplier = rsRef("Factor")
                        End If
                        rsRef.Close()

                        vDump.AppendLine("<tr><td class='labelR'>&nbsp;</td>")
                        vDump.AppendLine("<td class='labelL'>Night Diff:</td>" & _
                            "<td class='labelR'>" & Format(vHrsRendered, "##,##0.00") & "</td>" & _
                            "<td class='labelR'>" & Format(rs("NDREG") + rs("A2") + rs("A3") + rs("A4"), "##,##0.00") & "</td>" & _
                            "<td>&nbsp;</td><td>&nbsp;</td><td class='labelR'>(" & _
                            vHourly & " * " & vHrsRendered & " * " & vMultiplier & ")</td></tr>")
                    End If

                    'overtime
                    If rs("A1") <> 0 Then
                        vHrsRendered = GetOT("'A1'", rs("FromDate"), rs("ToDate"), vEmpCd, c)
                        cmRef.CommandText = "select OtPer from py_ot_ref where OtCd='A1'"
                        rsRef = cmRef.ExecuteReader
                        vMultiplier = 0
                        If rsRef.Read Then
                            vMultiplier = rsRef("OtPer")
                        End If
                        rsRef.Close()

                        'now check if there's a custom settings
                        cmRef.CommandText = "select Factor from py_ot_ref_dtl where OtCd='A1' and EmploymentType='" & _
                            rs("EmploymentType") & "'"
                        rsRef = cmRef.ExecuteReader
                        If rsRef.Read Then
                            vMultiplier = rsRef("Factor")
                        End If
                        rsRef.Close()

                        vDump.AppendLine("<tr><td class='labelR'>&nbsp;</td>")
                        vDump.AppendLine("<td class='labelL'>Regular OT:</td>" & _
                            "<td class='labelR'>" & Format(vHrsRendered, "##,##0.00") & "</td>" & _
                            "<td class='labelR'>" & Format(rs("A1"), "##,##0.00") & "</td>" & _
                            "<td>&nbsp;</td><td>&nbsp;</td><td class='labelR'>(" & _
                            vHourly & " * " & vHrsRendered & " * " & vMultiplier & ")</td></tr>")
                    End If

                    'HOLIDAYS AND RESTDAYS
                    DumpOT(vHourly, "B", rs("FromDate"), rs("ToDate"), vEmpCd, rs, vDump, c)
                    DumpOT(vHourly, "C", rs("FromDate"), rs("ToDate"), vEmpCd, rs, vDump, c)
                    DumpOT(vHourly, "D", rs("FromDate"), rs("ToDate"), vEmpCd, rs, vDump, c)
                    DumpOT(vHourly, "E", rs("FromDate"), rs("ToDate"), vEmpCd, rs, vDump, c)
                    DumpOT(vHourly, "F", rs("FromDate"), rs("ToDate"), vEmpCd, rs, vDump, c)

                    'other income
                    For i_loop = 1 To 60
                        If rs("Other_Incent" & i_loop) <> 0 Then
                            vIncentName = GetIncentDeductName("OthIncent" & i_loop & "Cd", vIncentCd, c).Trim
                            cmRef.CommandText = "select * from py_incentives_dtl where " & _
                                "Incentive_Cd='" & vIncentCd & "' and Emp_Cd='" & rs("Emp_Cd") & "' and FromDate between '" & _
                                Format(CDate(rs("FromDate")), "yyyy/MM/dd") & "' and '" & Format(CDate(rs("ToDate")), "yyyy/MM/dd") & "'"
                            rsRef = cmRef.ExecuteReader

                            vHrsRendered = 0
                            vUnitAmt = 0
                            Dim vString As String = ""
                            Do While rsRef.Read
                                vHrsRendered += rsRef("HrsWorked")
                                vUnitAmt = rsRef("UnitAmt")
                                vAbsentHrs = rsRef("AbsentHr")
                                vAbsentAmt = rsRef("AbsentAmt")
                                vTardyAmt = rsRef("TardyAmt")
                                vTardyHrs = rsRef("TardyHr")
                                vUTHrs = rsRef("UTHr")
                                vUTAmt = rsRef("UTAmt")
                                If Not IsDBNull(rsRef("EndDate")) Then
                                    vString += Format(rsRef("EndDate"), "MM/dd/yyyy") & "=(" & rsRef("HrsWorked") & " * " & vUnitAmt / 8 & ")<br/>"
                                Else
                                    vString += Format(rsRef("FromDate"), "MM/dd/yyyy") & "=(" & rsRef("HrsWorked") & " * " & vUnitAmt / 8 & ")<br/>"
                                End If

                            Loop
                            rsRef.Close()

                            vDump.AppendLine("<tr><td class='labelR'>&nbsp;</td>")
                            vDump.AppendLine("<td class='labelL'>" & vIncentName & "</td>" & _
                                "<td class='labelR'>" & IIf(vHrsRendered <> 0, Format(vHrsRendered, "#,##0.00"), "&nbsp;") & "</td>" & _
                                "<td class='labelR'>" & Format(rs("Other_Incent" & i_loop), "##,##0.00") & "</td>" & _
                                "<td>&nbsp;</td><td>&nbsp;</td>" & _
                                "<td class='labelR'>" & IIf(vHrsRendered <> 0, vString, "&nbsp;") & _
                                "</td></tr>")
                        End If
                        vTotalIncome += rs("Other_Incent" & i_loop)
                    Next i_loop

                    'union dues

                    cmRef.CommandText = "select TOP 1 Value from py_union_ref "
                    rsRef = cmRef.ExecuteReader
                    vUnionFactor = 0
                    If rsRef.Read Then
                        vUnionFactor = IIf(Not IsDBNull(rsRef("Value")), rsRef("Value"), 0) / 100
                    End If
                    rsRef.Close()

                    vTotalDed = rs("UnionDues") + rs("With_Tax") + rs("Sss_Per") + rs("Pagibig_Per") + rs("Medicare_Per")
                    If rs("UnionDues") <> 0 Then
                        vDump.AppendLine("<tr><td class='labelR'>&nbsp;</td>")
                        vDump.AppendLine("<td class='labelL'>Union Dues:</td>" & _
                            "<td class='labelR'>&nbsp;</td>" & _
                            "<td>&nbsp;</td>" & _
                            "<td class='labelR'>" & Format(rs("UnionDues"), "##,##0.00") & "</td>" & _
                            "<td>&nbsp;</td><td class='labelR'>" & Format(vMonthlyRate, "##,##0.00") & _
                            " * " & vUnionFactor & "</td></tr>")
                    End If
                    'tax
                    If rs("With_Tax") <> 0 Then
                        vDump.AppendLine("<tr><td class='labelR'>&nbsp;</td>")
                        vDump.AppendLine("<td class='labelL'>Withholding Tax:</td>" & _
                            "<td class='labelR'>&nbsp;</td>" & _
                            "<td>&nbsp;</td>" & _
                            "<td class='labelR'>" & Format(rs("With_Tax"), "##,##0.00") & "</td>" & _
                            "<td>&nbsp;</td><td>&nbsp;</td></tr>")
                    End If
                    'sss
                    If rs("Sss_Per") <> 0 Then
                        vDump.AppendLine("<tr><td class='labelR'>&nbsp;</td>")
                        vDump.AppendLine("<td class='labelL'>SSS Premium:</td>" & _
                            "<td class='labelR'>&nbsp;</td>" & _
                            "<td>&nbsp;</td>" & _
                            "<td class='labelR'>" & Format(rs("Sss_Per"), "##,##0.00") & "</td>" & _
                            "<td>&nbsp;</td><td>&nbsp;</td></tr>")
                    End If
                    'pagibig
                    If rs("PagIbig_Per") <> 0 Then
                        vDump.AppendLine("<tr><td class='labelR'>&nbsp;</td>")
                        vDump.AppendLine("<td class='labelL'>PAGIBIG Premium:</td>" & _
                            "<td class='labelR'>&nbsp;</td>" & _
                            "<td>&nbsp;</td>" & _
                            "<td class='labelR'>" & Format(rs("PagIbig_Per"), "##,##0.00") & "</td>" & _
                            "<td>&nbsp;</td><td>&nbsp;</td></tr>")
                    End If
                    'Philhealth
                    If rs("Medicare_Per") <> 0 Then
                        vDump.AppendLine("<tr><td class='labelR'>&nbsp;</td>")
                        vDump.AppendLine("<td class='labelL'>PhilHealth Premium:</td>" & _
                            "<td class='labelR'>&nbsp;</td>" & _
                            "<td>&nbsp;</td>" & _
                            "<td class='labelR'>" & Format(rs("Medicare_Per"), "##,##0.00") & "</td>" & _
                            "<td>&nbsp;</td><td>&nbsp;</td></tr>")
                    End If

                    'other deductions
                    For i_loop = 1 To 60
                        If rs("Other_Deduct" & i_loop) <> 0 Then
                            'v_data = v_data & GetIncentDeductName("OthDed" & i_loop & "Cd", c) & _
                            '   "|" & IIf(chkLoanBal.Checked, _
                            '   Format(GetBalance(rsRef("OthDed" & i_loop & "Cd"), rsReport("Emp_Cd"), c), "###,##0.00"), "") & _
                            '   "|" & Format(rsReport("Other_Deduct" & i_loop), "##,##0.00") & ";"
                            vDeductName = GetIncentDeductName("OthDed" & i_loop & "Cd", vIncentCd, c)
                            vDump.AppendLine("<tr><td class='labelR'>&nbsp;</td>")
                            vDump.AppendLine("<td class='labelL'>" & vDeductName & ":</td>" & _
                                "<td class='labelR'>&nbsp;</td>" & _
                                "<td class='labelR'>&nbsp;</td>" & _
                                "<td class='labelR'>" & Format(rs("Other_Deduct" & i_loop), "##,##0.00") & _
                                "</td><td>&nbsp;</td><td>&nbsp;</td></tr>")
                        End If
                        vTotalDed += rs("Other_Deduct" & i_loop)
                    Next i_loop

                    'dump totals
                    vDump.AppendLine("<tr class='even'><td class='labelR'>&nbsp;</td>")
                    vDump.AppendLine("<td class='labelL'>&nbsp;</td>" & _
                        "<td class='labelR'>&nbsp;</td>" & _
                        "<td class='labelR'>" & Format(vTotalIncome, "###,##0.00") & "</td>" & _
                        "<td class='labelR'>" & Format(vTotalDed, "###,##0.00") & _
                        "</td><td class='labelR'>" & Format(rs("Amount_Per"), "###,##0.00") & _
                        "</td><td>&nbsp;</td></tr>")
                End If
                rs.Close()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to retrieve record. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                GoTo skip
            End Try
            vDump.AppendLine("<tr><td class='labelL' colspan=8><hr/></td></tr>")
        Next
        vDump.AppendLine("</table><br/><br/>")

        vDump.AppendLine("<table border='0' style='border-collapse:collapsed;width:100%;' class='label'>")
        vDump.AppendLine("<tr><td>" & Session("uid") & "</td><td></td><td></td></tr>")
        vDump.AppendLine("<tr><td>Prepared By</td><td>Checked By</td><td>Noted By</td></tr>")
        vDump.AppendLine("</table></center></body></html>")
        vDump.Replace("%paydate%", vPayDate)

        If IO.File.Exists(Server.MapPath(".") & "\downloads\picklist-" & Session.SessionID & ".html") Then
            Try
                IO.File.Delete(Server.MapPath(".") & "\downloads\picklist-" & Session.SessionID & ".html")
            Catch ex As IO.IOException
                vScript = "alert('File cannot be deleted. Reason: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                Exit Sub
            End Try
        End If

        Try
            IO.File.WriteAllText(Server.MapPath(".") & "\downloads\picklist-" & Session.SessionID & ".html", vDump.ToString)
            vScript = "pickreport = window.open('downloads/picklist-" & Session.SessionID & _
                ".html','pickreport','top=10,left=200,width=800,height=600,resizable=yes,scrollbars=yes'); pickreport.focus();"
        Catch ex As IO.IOException
            vScript = "alert('Data cannot be written to file. Reason: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        End Try

skip:
        c.Close()
        cm.Dispose()
        cmRef.Dispose()
        cmMatrix.Dispose()
        c.Dispose()
    End Sub
End Class
