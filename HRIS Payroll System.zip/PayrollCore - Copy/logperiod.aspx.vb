Imports denaro
Partial Class logperiod
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Dim vClass As String = "odd"
    Protected Sub cmdReturn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.Click
        Session.Remove("tdate")
        Session.Remove("byperiod")
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Session("returnaddr") = "dailylog.aspx"
            Server.Transfer("index.aspx")
        End If
        txtRank.Text = Request.Form("txtRank")
        If Not IsPostBack Then
            If Not CanRun(Session("caption"), Request.Item("id")) Then
                Session("denied") = "1"
                Server.Transfer("main.aspx")
                Exit Sub
            End If

            'now build the reference code
            Dim c As New SqlClient.SqlConnection(connStr)
            Try
                c.Open()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                c.Dispose()
                Exit Sub
            End Try

            BuildCombo("select Rc_Cd,Descr from rc where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='rc' and Property_Value=Rc_Cd) order by Descr", cmbRC, c)
            BuildCombo("select AgencyCd,AgencyName from agency where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='agency' and Property_Value=AgencyCd) order by AgencyName", cmbOfc, c)
            BuildCombo("select Div_Cd,Descr from hr_div_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='division' and Property_Value=Div_Cd) order by Descr", cmbDiv, c)
            BuildCombo("select Dept_Cd,Descr from hr_dept_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='department' and Property_Value=Dept_Cd) order by Descr", cmbDept, c)
            BuildCombo("select Section_Cd,Descr from hr_section_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='section' and Property_Value=Section_Cd) order by Descr", cmbSection, c)
            BuildCombo("select Unit_Cd,Descr from hr_unit_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='unit' and Property_Value=Unit_Cd) order by Descr", cmbUnit, c)
            
            c.Close()
            c.Dispose()

            cmbRC.Items.Add("All")
            cmbRC.SelectedValue = "All"
            cmbOfc.Items.Add("All")
            cmbOfc.SelectedValue = "All"
            cmbDiv.Items.Add("All")
            cmbDiv.SelectedValue = "All"
            cmbDept.Items.Add("All")
            cmbDept.SelectedValue = "All"
            cmbSection.Items.Add("All")
            cmbSection.SelectedValue = "All"
            cmbUnit.Items.Add("All")
            cmbUnit.SelectedValue = "All"

            RefreshDates()
            DataRefresh("A")
        End If
    End Sub
    Private Sub RefreshDates()
        Dim c As New sqlclient.sqlConnection(connStr)
        Dim cm As New sqlclient.sqlCommand
        Dim dr As sqlclient.sqlDataReader

        cmbPostDates.Items.Clear()
        c.Open()
        cm.Connection = c
        cm.CommandText = "select distinct TranDate from py_emp_time_log order by TranDate desc"
        dr = cm.ExecuteReader
        Do While dr.Read
            cmbPostDates.Items.Add(dr("TranDate"))
        Loop
        dr.Close()
        cm.Dispose()
        c.Close()
        c.Dispose()
        If cmbPostDates.Items.Count > 0 Then
            If cmbPostDates.SelectedIndex <> -1 Then
                Session("tdate") = cmbPostDates.SelectedValue
            End If
        End If
    End Sub
    Protected Sub DataRefresh(ByVal pLetter As String)
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim dr As SqlClient.SqlDataReader
        Dim da As SqlClient.SqlDataAdapter
        Dim ds As New DataSet
        Dim vFilter As String = " where " & cmbType.SelectedValue & " like '" & pLetter & "%' "
        Dim vSql As String = ""
        Dim vLtrFilter As String = ""

        vFilter = " where " & cmbType.SelectedValue & " like '" & pLetter & "%' "
        Select Case Val(cmbStatus.SelectedValue)
            Case 1  'active employees only
                vFilter += " and Date_Resign is null AND Date_Retired IS NULL AND DateHold IS NULL AND DateDismissed IS NULL"
                vLtrFilter += " where Date_Resign is null AND Date_Retired IS NULL AND DateHold IS NULL AND DateDismissed IS NULL"
            Case 0  'inactive employees only
                vFilter += " and (Date_Resign is not null OR Date_Retired IS NOT NULL OR DateHold IS NOT NULL Or DateDismissed IS NOT NULL)"
                vLtrFilter += " where (Date_Resign is not null OR Date_Retired IS NOT NULL OR DateHold IS NOT NULL OR DateDismissed IS NOT NULL)"
        End Select

        If cmbRC.SelectedValue <> "All" Then   'filter by cost center
            vFilter += " and Rc_Cd='" & cmbRC.SelectedValue & "' "
            If cmbStatus.SelectedValue = 3 Then
                vLtrFilter += " Where Rc_Cd='" & cmbRC.SelectedValue & "' "
            Else
                vLtrFilter += " and Rc_Cd='" & cmbRC.SelectedValue & "' "
            End If
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='rc' and Property_Value=Rc_Cd) "

            If cmbStatus.SelectedValue = 3 Then
                vLtrFilter += " where exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='rc' and Property_Value=Rc_Cd) "
            Else
                vLtrFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='rc' and Property_Value=Rc_Cd) "
            End If
        End If

        If cmbOfc.SelectedValue <> "All" Then        'filter by office/agency
            vFilter += " and Agency_Cd='" & cmbOfc.SelectedValue & "' "
            vLtrFilter += " and Agency_Cd='" & cmbOfc.SelectedValue & "' "
        Else
            vFilter += "  and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='agency' and Property_Value=Agency_Cd) "
            vLtrFilter += "  and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='agency' and Property_Value=Agency_Cd) "
        End If
        If cmbDiv.SelectedValue <> "All" Then      'filter by division
            vFilter += " and Divcd='" & cmbDiv.SelectedValue & "' "
            vLtrFilter += " and Divcd='" & cmbDiv.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='division' and Property_Value=DivCd) "
            vLtrFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='division' and Property_Value=DivCd) "
        End If
        If cmbDept.SelectedValue <> "All" Then  'filter by departments
            vFilter += " and DeptCd='" & cmbDept.SelectedValue & "' "
            vLtrFilter += " and DeptCd='" & cmbDept.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='department' and Property_Value=DeptCd) "
            vLtrFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='department' and Property_Value=DeptCd) "
        End If
        If cmbSection.SelectedValue <> "All" Then 'filter by section
            vFilter += " and SectionCd='" & cmbSection.SelectedValue & "' "
            vLtrFilter += " and SectionCd='" & cmbSection.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='section' and Property_Value=SectionCd) "
            vLtrFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='section' and Property_Value=SectionCd) "
        End If
        If cmbUnit.SelectedValue <> "All" Then  'filter by units
            vFilter += " and UnitCd='" & cmbUnit.SelectedValue & "' "
            vLtrFilter += " and UnitCd='" & cmbUnit.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='unit' and Property_Value=UnitCd) "
            vLtrFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='unit' and Property_Value=UnitCd) "
        End If
        
        vFilter += " and EmploymentType in ('" & txtRank.Text.Replace(",", "','") & "') "
        vLtrFilter += " and EmploymentType in ('" & txtRank.Text.Replace(",", "','") & "') "

        If chkShow.Checked Then 'show only employees with transactions on the selected transaction date
            vFilter += " and exists (select distinct py_emp_time_log.Emp_Cd from py_emp_time_log where TranDate='" & _
                Format(CDate(cmbPostDates.SelectedValue), "yyyy/MM/dd") & "' and py_emp_time_log.Emp_Cd=py_emp_master.Emp_Cd) "
            vLtrFilter += " and exists (select distinct py_emp_time_log.Emp_Cd from py_emp_time_log where TranDate='" & _
                Format(CDate(cmbPostDates.SelectedValue), "yyyy/MM/dd") & "' and py_emp_time_log.Emp_Cd=py_emp_master.Emp_Cd) "
        End If

        Session("filter") = vFilter
        vSql = "select Emp_Cd,Emp_Lname,Emp_Fname,Emp_Mname,Req_Hrs_Day from py_emp_master" & vFilter & _
            " order by Emp_Lname,Emp_Fname,Emp_Mname"
        Session("sql") = "select Emp_Cd,Emp_Lname,Emp_Fname,Emp_Mname,Req_Hrs_Day from py_emp_master" & vLtrFilter & _
            " order by Emp_Lname,Emp_Fname,Emp_Mname"
        da = New SqlClient.SqlDataAdapter(vSql, c)
        da.Fill(ds, "EmpMaster")
        tblEmp.DataSource = ds.Tables("EmpMaster")
        tblEmp.DataBind()
        ds.Dispose()
        da.Dispose()
        c.Open()
        cm.Connection = c
        cm.CommandText = "select distinct substring(Emp_Lname,1,1) as Letters from py_emp_master " & vLtrFilter
        dr = cm.ExecuteReader
        EnableAll()
        Do While dr.Read
            SetLetters(dr("Letters"))
        Loop
        dr.Close()

        cmdUnpost.Enabled = True
        cmdEdit.Enabled = True
        cm.CommandText = "select TOP 1 PayDate from py_emp_time_log where TranDate='" & _
            Format(CDate(cmbPostDates.SelectedValue), "yyyy/MM/dd") & "'"
        dr = cm.ExecuteReader
        If dr.Read Then
            cmdUnpost.Enabled = IsDBNull(dr("PayDate"))
            cmdEdit.Enabled = cmdUnpost.Enabled
        End If
        dr.Close()

        cm.Dispose()
        c.Close()
        c.Dispose()
    End Sub
    Private Sub SetLetters(ByVal pLetter As String)
        Select Case LCase(pLetter)
            Case "a"
                cmdA.Visible = True
            Case "b"
                cmdB.Visible = True
            Case "c"
                cmdC.Visible = True
            Case "d"
                cmdD.Visible = True
            Case "e"
                cmdE.Visible = True
            Case "f"
                cmdF.Visible = True
            Case "g"
                cmdG.Visible = True
            Case "h"
                cmdH.Visible = True
            Case "i"
                cmdI.Visible = True
            Case "j"
                cmdJ.Visible = True
            Case "k"
                cmdK.Visible = True
            Case "l"
                cmdL.Visible = True
            Case "m"
                cmdM.VISIBLE = True
            Case "n"
                cmdN.Visible = True
            Case "o"
                cmdO.Visible = True
            Case "p"
                cmdP.Visible = True
            Case "q"
                cmdQ.Visible = True
            Case "r"
                cmdR.Visible = True
            Case "s"
                cmdS.Visible = True
            Case "t"
                cmdT.Visible = True
            Case "u"
                cmdU.Visible = True
            Case "v"
                cmdV.Visible = True
            Case "w"
                cmdW.Visible = True
            Case "x"
                cmdX.Visible = True
            Case "y"
                cmdY.Visible = True
            Case "z"
                cmdZ.Visible = True
        End Select
    End Sub

    Protected Sub cmdA_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdA.Click, _
        cmdB.Click, cmdC.Click, cmdD.Click, cmdE.Click, cmdF.Click, cmdG.Click, cmdH.Click, cmdI.Click, _
        cmdJ.Click, cmdK.Click, cmdL.Click, cmdM.Click, cmdN.Click, cmdO.Click, cmdP.Click, cmdQ.Click, _
        cmdR.Click, cmdS.Click, cmdT.Click, cmdU.Click, cmdV.Click, cmdW.Click, cmdX.Click, cmdY.Click, cmdZ.Click
        'Session("letter") = CType(sender, LinkButton).Text
        tblEmp.SelectedIndex = -1
        DataRefresh(CType(sender, LinkButton).Text)
    End Sub
    Private Sub EnableAll(Optional ByVal pState As Boolean = False)
        cmdA.Visible = pState : cmdB.Visible = pState : cmdC.Visible = pState : cmdD.Visible = pState
        cmdE.Visible = pState : cmdF.Visible = pState : cmdG.Visible = pState : cmdH.Visible = pState
        cmdI.Visible = pState : cmdJ.Visible = pState : cmdK.Visible = pState : cmdL.Visible = pState
        cmdM.Visible = pState : cmdN.Visible = pState : cmdO.Visible = pState : cmdP.Visible = pState
        cmdQ.Visible = pState : cmdR.Visible = pState : cmdS.Visible = pState : cmdT.Visible = pState
        cmdU.Visible = pState : cmdV.Visible = pState : cmdW.Visible = pState : cmdX.Visible = pState
        cmdY.Visible = pState : cmdZ.Visible = pState
    End Sub
    Protected Sub tblEmp_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles tblEmp.PageIndexChanging
        tblEmp.PageIndex = e.NewPageIndex
        DataRefresh(txtSearch.Text)
    End Sub

    Protected Sub tblEmp_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tblEmp.SelectedIndexChanged
        RefreshDtl()
    End Sub
    Private Sub RefreshDtl()
        If tblEmp.SelectedIndex <> -1 Then  'an employee is selected
            Dim c As New SqlClient.SqlConnection(connStr)
            Dim cm As New SqlClient.SqlCommand
            Dim da As SqlClient.SqlDataAdapter
            Dim ds As New DataSet
            Dim dr As SqlClient.SqlDataReader

            c.ConnectionString = connStr
            da = New SqlClient.SqlDataAdapter("select * from py_emp_time_log,py_ot_ref where " & _
                "OtCd=TranCd and Emp_Cd='" & tblEmp.SelectedRow.Cells(0).Text & "' and TranDate='" & _
                Format(CDate(Session("tdate")), "yyyy/MM/dd") & "'", c)
            da.Fill(ds, "Trans")
            tblTran.DataSource = ds.Tables("Trans")
            tblTran.DataBind()
            da.Dispose()
            ds.Dispose()

            c.Open()
            cm.Connection = c
            cmdUnpost.Enabled = True
            cmdEdit.Enabled = True
            cm.CommandText = "select TOP 1 PayDate from py_emp_time_log where TranDate='" & _
                Format(CDate(cmbPostDates.SelectedValue), "yyyy/MM/dd") & "'"
            dr = cm.ExecuteReader
            If dr.Read Then
                cmdUnpost.Enabled = IsDBNull(dr("PayDate"))
                cmdEdit.Enabled = cmdUnpost.Enabled
            End If
            dr.Close()
            c.Close()
            cm.Dispose()
            c.Dispose()
        End If
    End Sub
    Public Function Conv(ByVal pDate As String) As String
        If pDate.Trim = "" Then
            Return ""
        ElseIf Not IsDate(pDate) Then
            Return ""
        Else
            Return Format(CDate(pDate), "MM/dd/yyyy")
        End If
    End Function
    Protected Sub cal_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cal.SelectionChanged
        Session("tdate") = cal.SelectedDate
        RefreshDtl()
    End Sub

    Protected Sub cmbPostDates_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbPostDates.SelectedIndexChanged
        Session("tdate") = cmbPostDates.SelectedValue
        RefreshDtl()
    End Sub

    Protected Sub cmdEdit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdEdit.Click
        If Me.tblEmp.SelectedIndex >= 0 Then
            Session("empid") = tblEmp.SelectedRow.Cells(0).Text
            Session("empname") = tblEmp.SelectedRow.Cells(1).Text & ", " & _
                tblEmp.SelectedRow.Cells(2).Text
            Session("byperiod") = "1"
            vScript = "logwin=window.open('logdtl.aspx','logwin','location=no,toolber=no,width=600,height=768');"
        Else
            vScript = "alert('Please select employee to edit!');"
        End If
    End Sub

    Protected Sub cmdUnpost_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdUnpost.Click
        'If tblEmp.SelectedIndex <> -1 And tblTran.Rows.Count > 0 Then
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand

        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c
        cm.CommandText = "delete from py_emp_time_log where TranDate='" & Format(CDate(Session("tdate")), "yyyy/MM/dd") & "'"
        cm.ExecuteNonQuery()
        c.Close()
        c.Dispose()
        RefreshDates()
        'Else
        '    vScript = "alert('No employee and transaction date was selected. Please select first.');"
        'End If
    End Sub

    Protected Sub cmdUnpost_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdUnpost.Init
        cmdUnpost.Attributes.Add("onclick", "javascript:return confirm('Are you sure you want to unpost the selected date?');")
    End Sub

    Protected Sub cmdSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSearch.Click
        DataRefresh(txtSearch.Text)
    End Sub

    Protected Sub cmdHours_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdHours.Click, cmdAmount.Click
        Dim vRptType As String = ""

        Select Case CType(sender, System.Web.UI.WebControls.Button).ID
            Case "cmdHours"
                vRptType = "Hours"
            Case Else
                vRptType = "Amount"
        End Select
        printSumm(vRptType, 0)
    End Sub
    Private Sub printSumm(ByVal vRptType As String, ByVal isLate As Integer)
        Session.Remove("VFILTER")
        Dim vStartDate As Date = CDate(Session("tdate"))
        Dim vEndDate As Date = vStartDate

        Session("startdate") = Format(vStartDate, "yyyy/MM/dd")
        Session("enddate") = Format(vEndDate, "yyyy/MM/dd")
        
        vScript = "document.getElementById('divBlur').style.visibility='hidden'; " & _
            "document.getElementById('divMsgBox').style.visibility = 'hidden'; " & _
            "winsumm=window.open('printsumm.aspx?r=" & vRptType & "&l=" & isLate & _
            "&m=1','winsumm','toolbar=no,scrollbars=yes,width=1020,height=700,top=30,left=0');"
    End Sub
End Class
