Imports denaro
Partial Class massupdateemr
    Inherits System.Web.UI.Page

    Public vScript As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'If Session("uid") = "" Then
        '    Server.Transfer("index.aspx")
        '    Exit Sub
        'End If
        If Not IsPostBack Then 'now build the reference code
            lblCaption.Text = "Mass Update Employee Movement"
            Dim c As New SqlClient.SqlConnection(connStr)

            Try
                c.Open()
            Catch ex As SqlClient.SqlException
                vScript = "alert('An error occurred while trying to connect to database. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & ");"
                c.Dispose()
                Exit Sub
            End Try

            BuildCombo("select Rc_Cd, Descr from rc order by Descr", cmbRC, c)
            BuildCombo("select AgencyCd,AgencyName from agency order by AgencyName", cmbOfc, c)
            BuildCombo("select Div_Cd,Descr from hr_div_ref order by Descr", cmbDiv, c)
            BuildCombo("select Dept_Cd,Descr from hr_dept_ref order by Descr", cmbDept, c)
            BuildCombo("select Section_Cd,Descr from hr_section_ref order by Descr", cmbSection, c)
            BuildCombo("select Unit_Cd,Descr from hr_unit_ref order by Descr", cmbUnit, c)
            BuildCombo("select Pos_Cd,Position from py_position_ref order by Position", cmbPosition, c)
            BuildCombo("select EmploymentType,Descr from hr_employment_type order by Descr", cmbRank, c)
            BuildCombo("select Emp_Cd,Emp_Lname+', '+Emp_Fname as Name from py_emp_master where " & _
                "Date_Resign is null and DateHold is null and DateSuspended is null and Date_Retired is null " & _
                "order by Emp_Lname,Emp_Fname", cmbPreparedBy, c)
            BuildCombo("select Emp_Cd,Emp_Lname+', '+Emp_Fname as Name from py_emp_master where " & _
                "Date_Resign is null and DateHold is null and DateSuspended is null and Date_Retired is null " & _
                "order by Emp_Lname,Emp_Fname", cmbRecommendedBy, c)
            BuildCombo("select Emp_Cd,Emp_Lname+', '+Emp_Fname as Name from py_emp_master where " & _
                "Date_Resign is null and DateHold is null and DateSuspended is null and Date_Retired is null " & _
                "order by Emp_Lname,Emp_Fname", cmbApprovedBy, c)

            c.Close()
            c.Dispose()

            cmbRC.Items.Add("All")
            cmbRC.SelectedValue = "All"
            cmbOfc.Items.Add("All")
            cmbOfc.SelectedValue = "All"
            cmbDiv.Items.Add("All")
            cmbDiv.SelectedValue = "All"
            cmbDept.Items.Add("All")
            cmbDept.SelectedValue = "All"
            cmbSection.Items.Add("All")
            cmbSection.SelectedValue = "All"
            cmbUnit.Items.Add("All")
            cmbUnit.SelectedValue = "All"
            cmbRank.Items.Add("All")
            cmbRank.SelectedValue = "All"
            cmbPosition.Items.Add("All")
            cmbPosition.SelectedValue = "All"
            cmbPreparedBy.Items.Add("")
            cmbRecommendedBy.Items.Add("")
            cmbApprovedBy.Items.Add("")
            cmbPreparedBy.SelectedValue = ""
            cmbRecommendedBy.SelectedValue = ""
            cmbApprovedBy.SelectedValue = ""
            DataRefresh()
        End If
    End Sub
    Protected Sub DataRefresh()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim dr As SqlClient.SqlDataReader
        Dim vFilter As String = " where Date_Resign is null "

        If cmbRC.SelectedValue <> "All" Then   'filter by cost center
            vFilter += " and Rc_Cd='" & cmbRC.SelectedValue & "' "
        End If
        If cmbOfc.SelectedValue <> "All" Then        'filter by office/agency
            vFilter += " and Agency_Cd='" & cmbOfc.SelectedValue & "' "
        End If
        If cmbDiv.SelectedValue <> "All" Then      'filter by division
            vFilter += " and Divcd='" & cmbDiv.SelectedValue & "' "
        End If
        If cmbDept.SelectedValue <> "All" Then  'filter by departments
            vFilter += " and DeptCd='" & cmbDept.SelectedValue & "' "
        End If
        If cmbSection.SelectedValue <> "All" Then 'filter by section
            vFilter += " and SectionCd='" & cmbSection.SelectedValue & "' "
        End If
        If cmbUnit.SelectedValue <> "All" Then  'filter by units
            vFilter += " and UnitCd='" & cmbUnit.SelectedValue & "' "
        End If
        If cmbRank.SelectedValue <> "All" Then 'filter by rank
            vFilter += " and EmploymentType='" & cmbRank.SelectedValue & "' "
        End If
        If cmbPosition.SelectedValue <> "All" Then  'filter by position
            vFilter += " and Pos_Cd='" & cmbPosition.SelectedValue & "' "
        End If

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('An error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        cm.Connection = c
        cm.CommandText = "select Emp_Cd,Emp_Lname+', '+Emp_Fname as EmpName from py_emp_master " & _
            vFilter & " order by Emp_Lname,Emp_Fname,Emp_Mname"
        Try
            dr = cm.ExecuteReader
            chkEmp.Items.Clear()
            Do While dr.Read
                chkEmp.Items.Add(New ListItem(dr("Emp_Cd") & "=>" & dr("EmpName"), dr("Emp_Cd")))
            Loop
            dr.Close()
        Catch ex As SqlClient.SqlException
            vScript = "alert('An error occurred while trying to retrieve employee records. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            c.Dispose()
            cm.Dispose()
        End Try
    End Sub

    Protected Sub cmdRefresh_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdRefresh.Click
        DataRefresh()
    End Sub

    Protected Sub cmdSelect_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSelect.Click
        SetChk(True)
    End Sub
    Private Sub SetChk(ByVal pState As Boolean)
        Dim iCtr As Integer

        For iCtr = 0 To chkEmp.Items.Count - 1
            chkEmp.Items(iCtr).Selected = pState
        Next iCtr
    End Sub

    Protected Sub cmdDeselect_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDeselect.Click
        SetChk(False)
    End Sub

    Protected Sub cmdReturn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.Click
        Server.Transfer("emr.aspx")
    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        If Page.IsValid Then
            Dim c As New SqlClient.SqlConnection(connStr)
            Dim cm As New SqlClient.SqlCommand
            Dim dr As SqlClient.SqlDataReader
            Dim vEmpty As Boolean = True
            Dim iCtr As Integer
            Dim vValue As Double = 0
            Dim vDays As Single = 1

            Try
                c.Open()
            Catch ex As SqlClient.SqlException
                vScript = "alert('An error occurred while trying to connect to database. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                c.Dispose()
                cm.Dispose()
                Exit Sub
            End Try

            cm.Connection = c
            cm.CommandText = "select Dates_to_Month from py_syscntrl"
            Try
                dr = cm.ExecuteReader
                If dr.Read Then
                    vDays = IIf(IsDBNull(dr("Dates_to_Month")), 1, dr("Dates_to_Month"))
                End If
                dr.Close()
                cm.Dispose()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to retrieve system control parameters. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                c.Close()
                cm.Dispose()
                c.Dispose()
                Exit Sub
            End Try

            For iCtr = 0 To chkEmp.Items.Count - 1
                If chkEmp.Items(iCtr).Selected Then
                    vEmpty = False
                    Exit For
                End If
            Next iCtr
            If vEmpty Then
                vScript = "alert('You must first select at least one employee to continue...');"
                c.Close()
                c.Dispose()
                Exit Sub
            End If

            For iCtr = 0 To chkEmp.Items.Count - 1
                If chkEmp.Items(iCtr).Selected Then
                    SaveData(vDays, ExtractData(chkEmp.Items(iCtr).Text), c)
                End If
            Next iCtr
            vScript = "alert('Changes were successfully saved. You may go to 201 Masterfile and " & _
                "check the Career History profile of each affected employee.');"
            c.Close()
            c.Dispose()
        End If
    End Sub
    Private Sub SaveData(ByVal pDays As Single, ByVal pEmpCd As String, ByRef c As SqlClient.SqlConnection)
        Dim cm As New SqlClient.SqlCommand
        Dim cmExec As New SqlClient.SqlCommand
        Dim dr As SqlClient.SqlDataReader
        Dim vSalary As Double = 0
        Dim vMeal As Double = 0
        Dim vACA As Double = 0
        Dim vRATA As Double = 0
        Dim vPERA As Double = 0
        Dim vStr As String = ""

        cm.Connection = c
        cmExec.Connection = c
        cm.CommandText = "select Emp_Cd,Rate_Month,MealAllow,Aca,Rata,Pera,Emp_Status,Pos_Cd,Tax_Cd,Rc_Cd," & _
            "Agency_Cd,DivCd,DeptCd,SectionCd,UnitCd,EmploymentType from py_emp_master where Emp_Cd='" & _
            pEmpCd & "'"
        dr = cm.ExecuteReader
        If dr.Read Then
            Select Case rdoSalary.SelectedValue
                Case "0"    'use specific amount
                    vSalary = Val(txtSalary.Text)
                Case "1"    'use percentage
                    vSalary = dr("Rate_Month") + ((Val(txtSalary.Text) / 100) * dr("Rate_Month"))
                Case "2"    'use additional amount
                    vSalary = Val(txtSalary.Text) + dr("Rate_Month")
            End Select
            
            Select Case rdoMeal.SelectedValue
                Case "0"    'use specific amount 
                    vMeal = Val(txtMeal.Text)
                Case "1"    'use percentage
                    vMeal = Val(txtMeal.Text) * dr("Rate_Month")
                Case "2"    'use additional amount
                    vMeal = Val(txtMeal.Text) + dr("MealAllow")
            End Select

            Select Case rdoACA.SelectedValue
                Case "0"    'use specific amount 
                    vACA = Val(txtACA.Text)
                Case "1"    'use percentage
                    vACA = Val(txtACA.Text) * dr("Rate_Month")
                Case "2"    'use additional amount 
                    vACA = Val(txtACA.Text) + dr("Aca")
            End Select

            Select Case rdoRATA.SelectedValue
                Case "0"
                    vRATA = Val(txtRATA.Text)
                Case "1"
                    vRATA = Val(txtRATA.Text) * dr("Rate_Month")
                Case "2"
                    vRATA = Val(txtRATA.Text) + dr("Rata")
            End Select
            
            Select Case rdoPERA.SelectedValue
                Case "0"
                    vPERA = Val(txtPERA.Text)
                Case "1"
                    vPERA = Val(txtPERA.Text) * dr("Rate_Month")
                Case "2"
                    vPERA = Val(txtPERA.Text) + dr("Pera")
            End Select

            If chkSalary.Checked Then
                vStr += IIf(vStr = "", " ", ",") & "Rate_Month=" & vSalary & ",Rate_Year=" & vSalary * 12 & _
                    ",Rate_Day=" & vSalary / pDays
            End If
            If chkMeal.Checked Then
                vStr += IIf(vStr = "", " ", ",") & "MealAllow=" & vMeal
            End If
            If chkACA.Checked Then
                vStr += IIf(vStr = "", " ", ",") & "Aca=" & vACA
            End If
            If chkRATA.Checked Then
                vStr += IIf(vStr = "", " ", ",") & "Rata=" & vRATA
            End If
            If chkPERA.Checked Then
                vStr += IIf(vStr = "", " ", ",") & "Pera=" & vPERA
            End If
            'clean existing data
            cmExec.CommandText = "delete from hr_emp_career_movement where Emp_Cd='" & _
                pEmpCd & "' and From_Date='" & Format(Now, "yyyy/MM/dd") & "'"
            cmExec.ExecuteNonQuery()
            'now insert new data

            cmExec.CommandText = "insert into hr_emp_career_movement (Emp_Cd,From_Date,Remarks,Salary_Amt," & _
                "Emp_Status,Position_Cd,TaxCd,Rc_Cd,Office_Cd,Div_Cd,Dept_Cd,Section_Cd,Unit_Cd,Aca," & _
                "Rata,Pera,MealAllow,EmploymentType,PreparedBy,RecommendedBy,ApprovedBy,DatePrepared," & _
                "DateRecommended,DateApproved,Nature,EffectivityDate) values ('" & dr("Emp_Cd") & "','" & _
                Format(Now, "yyyy/MM/dd") & "','" & txtRemarks.Text & "'," & dr("Rate_Month") & _
                ",'" & dr("Emp_Status") & "','" & dr("Pos_Cd") & _
                "','" & dr("Tax_Cd") & "','" & dr("Rc_Cd") & _
                "','" & dr("Agency_Cd") & "','" & dr("DivCd") & _
                "','" & dr("DeptCd") & "','" & dr("SectionCd") & _
                "','" & dr("UnitCd") & "'," & dr("Aca") & "," & dr("Rata") & _
                "," & dr("Pera") & "," & dr("MealAllow") & ",'" & dr("EmploymentType") & "','" & _
                cmbPreparedBy.SelectedValue & "','" & cmbRecommendedBy.SelectedValue & _
                "','" & cmbApprovedBy.SelectedValue & "','" & _
                Format(CDate(txtDatePrepared.Text), "yyyy/MM/dd") & "','" & _
                Format(CDate(txtDateRecommended.Text), "yyyy/MM/dd") & "','" & _
                Format(CDate(txtDateApproved.Text), "yyyy/MM/dd") & "','" & txtNature.Text & "','" & _
                Format(CDate(txtEffecDate.Text), "yyyy/MM/dd") & "')"
            cmExec.ExecuteNonQuery()

            cmExec.CommandText = "update py_emp_master set " & vStr & _
                " where Emp_Cd='" & dr("Emp_Cd") & "'"
            cmExec.ExecuteNonQuery()
        End If
        dr.Close()
        cm.Dispose()
        cmExec.Dispose()
    End Sub
    Protected Sub vldDate_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles vldDate.ServerValidate
        If Not IsNumeric(txtSalary.Text) Then
            vScript = "alert('Invalid numeric format in Salary field.');"
            args.IsValid = False
            Exit Sub
        End If
        If Not IsNumeric(txtMeal.Text) Then
            vScript = "alert('Invalid numeric format in Meal Allowance field.');"
            args.IsValid = False
            Exit Sub
        End If
        If Not IsNumeric(txtACA.Text) Then
            vScript = "alert('Invalid numeric format in ACA field.');"
            args.IsValid = False
            Exit Sub
        End If
        If Not IsNumeric(txtRATA.Text) Then
            vScript = "alert('Invalid numeric format in RATA field.');"
            args.IsValid = False
            Exit Sub
        End If
        If Not IsNumeric(txtPERA.Text) Then
            vScript = "alert('Invalid numeric format in PERA field.');"
            args.IsValid = False
            Exit Sub
        End If
        If cmbPreparedBy.SelectedValue = "" Then
            vScript = "alert('Please select who prepared the request.');"
            args.IsValid = False
            Exit Sub
        End If
        If cmbRecommendedBy.SelectedValue = "" Then
            vScript = "alert('Please select who recommended the request.');"
            args.IsValid = False
            Exit Sub
        End If
        If cmbApprovedBy.SelectedValue = "" Then
            vScript = "alert('Please select who approved the request.');"
            args.IsValid = False
            Exit Sub
        End If
        If Not IsDate(txtDatePrepared.Text) Then
            vScript = "alert('Invalid date format in Date Prepared field.');"
            args.IsValid = False
            Exit Sub
        End If
        If Not IsDate(txtDateRecommended.Text) Then
            vScript = "alert('Invalid date format in Date Recommended field.');"
            args.IsValid = False
            Exit Sub
        End If
        If Not IsDate(txtDateApproved.Text) Then
            vScript = "alert('Invalid date format in Date Approved field.');"
            args.IsValid = False
            Exit Sub
        End If
        If txtRemarks.Text.Length = 0 Then
            vScript = "alert('Remarks field is required.');"
            args.IsValid = False
            Exit Sub
        End If
        If Not IsDate(txtEffecDate.Text) Then
            vScript = "alert('Please enter Effectivity Date.');"
            args.IsValid = False
            Exit Sub
        End If

        txtSalary.Text.Replace(",", "")
        txtMeal.Text.Replace(",", "")
        txtACA.Text.Replace(",", "")
        txtRATA.Text.Replace(",", "")
        txtPERA.Text.Replace(",", "")
        args.IsValid = True
    End Sub

    Protected Sub txtEffecDate_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtEffecDate.Init
        txtEffecDate.Attributes.Add("onfocus", "showCalendarControl(this);")
    End Sub

    Protected Sub txtDatePrepared_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtDatePrepared.Init
        txtDatePrepared.Attributes.Add("onfocus", "showCalendarControl(this);")
    End Sub

    Protected Sub txtDateRecommended_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtDateRecommended.Init
        txtDateRecommended.Attributes.Add("onfocus", "showCalendarControl(this);")
    End Sub

    Protected Sub txtDateApproved_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtDateApproved.Init
        txtDateApproved.Attributes.Add("onfocus", "showCalendarControl(this);")
    End Sub

End Class
