Imports denaro.fis
Partial Class checkhash
    Inherits System.Web.UI.Page
    Public vDump As String = ""
   
    Protected Sub cmdCheck_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCheck.Click
        Dim c As New sqlclient.sqlconnection(connstr)
        Dim cm As New sqlclient.sqlcommand
        Dim rs As sqlclient.sqldatareader
        Dim vColor As String = "white"
        Dim vHash As String = ""

        c.Open()
        cm.Connection = c
        cm.CommandText = "select Emp_Cd,Emp_Lname,Emp_Fname,Pin,PinExpiry from py_emp_master where Date_Resign is null order by " & _
            "Emp_Lname,Emp_Fname"
        rs = cm.ExecuteReader
        vDump = ""
        Do While rs.Read
            vColor = "white"
            vHash = Math.Abs(rs("Emp_Cd").ToString.GetHashCode)
            If Not IsDBNull(rs("Pin")) Then
                If rs("Pin") <> vHash Then
                    vColor = "cyan"
                End If
            End If
            vDump += "<tr style='background-color: " & vColor & "'>" & _
                "<td>" & rs("Emp_Cd") & "</td>" & _
                "<td>" & rs("Emp_Lname") & ", " & rs("Emp_Fname") & "</td>" & _
                "<td>" & rs("Pin") & "</td>" & _
                "<td>" & vHash & "</td>" & _
                "<td>" & rs("PinExpiry") & "</td></tr>"
        Loop
        rs.Close()
        c.Close()
        cm.Dispose()
        c.Dispose()
    End Sub
End Class
