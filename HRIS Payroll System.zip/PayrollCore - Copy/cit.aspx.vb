﻿Imports denaro.fis
Partial Class cit
    Inherits System.Web.UI.Page
    Public vResponse As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            vResponse = "expired"
            Exit Sub
        End If

        Dim vCutOff As Date = CDate(Request.Form("cutoff"))
        Dim vPayOut As Date = CDate(Request.Form("payout"))
        Dim vCredit As Date = CDate(Request.Form("credit"))
        Dim vAcctType As String = Request.Form("acct")
        Dim vBank As String = Request.Form("bank")
        Dim vRc As String = Request.Form("rc")
        Dim vAgency As String = Request.Form("agency")
        Dim vDiv As String = Request.Form("div")
        Dim vRank As String = Request.Form("rank")
        Dim vStatus As String = Request.Form("stat")

        Dim vCompanyName As String = vAgency
        Dim vGrandTotal As Decimal
        Dim iCtr As Integer
        Dim vErr As String = ""
        Dim vPreparedBy As String = ""
        Dim vApprovedBy As String = ""
        Dim vPosition As String = "Unknown"
        Dim vPositionApproved As String = "Unknown"
        Dim vFilter As String
        Dim vDump As String = ""
        Dim vCompanyCd As String
        Dim vBranchCd As String = ""
        Dim vBankCd As String = ""
        Dim vClass As String = "odd"
        Dim vData As New StringBuilder

        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader


        vFilter = " where PayDate='" & Format(vPayOut, "yyyy/MM/dd") & "' and FromDate='" & _
            Format(vCutOff, "yyyy/MM/dd") & "' "
        Select Case vAcctType
            Case "SA", "CA"
                vFilter += " and Report_No is not null and Report_No<>'' "
                'filter by bank code
                'vFilter += " and exists (select Emp_Cd from py_emp_master where Bank_Code='" & vBank & "' and Bank_Type='" & _
                '    vAcctType & "' and Date_Resign is null) "
                vFilter += " and BankCd='" & vBank & "' and BankType='" & vAcctType & "' "
            Case Else
                vFilter += " and (Report_No is null or Report_No='') "
        End Select

        If vRc <> "All" Then   'filter by cost center
            vFilter += " and Rc_Cd='" & vRc & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='rc' and Property_Value=Rc_Cd) "
        End If

        If vAgency <> "All" Then        'filter by office/agency
            vFilter += " and Agency_Cd='" & vAgency & "' "
        Else
            vFilter += "  and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='agency' and Property_Value=Agency_Cd) "
        End If
        If vDiv <> "All" Then      'filter by division
            vFilter += " and Divcd='" & vDiv & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='division' and Property_Value=DivCd) "
        End If
        If vRank <> "All" Then 'filter by employment types
            vFilter += " and EmploymentType='" & vRank & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='employmenttype' and Property_Value=EmploymentType) "
        End If

        vData.Remove(0, vData.Length)
        vData.AppendLine("<html>")
        vData.AppendLine("<title>Bank Advise Report</title>")
        vData.AppendLine("<link rel='stylesheet' href='../redtheme/red.css' type='text/css' />")
        vData.AppendLine("<body><center>")

        cm.Connection = c
        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vResponse = "error"
            vData.AppendLine(ex.Message)
            GoTo dump
        End Try

        Try
            cm.CommandText = "select AgencyName from agency where AgencyCd='" & vAgency & "'"
            rs = cm.ExecuteReader
            If rs.Read Then
                vCompanyName = rs("AgencyName")
            End If
            rs.Close()
            cm.CommandText = "select CompanyCd,Company_Name,BranchCd,BankCd,Attention,AttentionPos  from glsyscntrl where AgencyCd='" & _
                vAgency & "'"
            rs = cm.ExecuteReader
            vCompanyCd = vAgency        'set initial value
            vApprovedBy = "Unknown"
            vPositionApproved = "Unknown"
            If rs.Read Then
                vCompanyCd = IIf(IsDBNull(rs("CompanyCd")), "Unknown Company", rs("CompanyCd"))
                vBranchCd = IIf(IsDBNull(rs("BranchCd")), "Unknown Branch", rs("BranchCd"))
                vBankCd = IIf(IsDBNull(rs("BankCd")), "Unknown Bank", rs("BankCd"))
                vCompanyName = IIf(IsDBNull(rs("Company_Name")), "", Mid(rs("Company_Name"), 1, 40))
                vCompanyName += Space(40 - Len(vCompanyName))
                vApprovedBy = IIf(IsDBNull(rs("Attention")), "Unknown", rs("Attention"))
                vPositionApproved = IIf(IsDBNull(rs("AttentionPos")), "Unknown", rs("AttentionPos"))
            End If
            rs.Close()

            vData.AppendLine("<h2>Bank Advise Report for " & vCompanyName & "</h2>")
            vData.AppendLine("<h3>Emloyees " & IIf(vAcctType = "NA", "without", "with") & " Account Numbers" & "</h3>")
            vData.AppendLine("<h4>for the " & vPayOut & " payroll</h4><br/>")

            vData.AppendLine("<table border='1' style='border-collapse:collapse;' class='mainGridView'><tr class='titleBar'>" & _
                "<th class='labelC'>Line No.</th><th class='labelC'>Account Name</th>" & _
                "<th class='labelC'>Account Number</th><th class='labelC'>Credited Amount</th></tr>")

            vGrandTotal = 0
            iCtr = 1
            cm.CommandText = "select FullName,Position from user_list where User_Id='" & Session("uid") & "'"
            rs = cm.ExecuteReader
            vPreparedBy = Session("uid")
            vPosition = "Uknown"
            If rs.Read Then
                vPreparedBy = IIf(IsDBNull(rs("FullName")), Session("uid"), rs("FullName"))
                vPosition = IIf(IsDBNull(rs("Position")), "Unknown", rs("Position"))
            End If
            rs.Close()

            'cm.CommandText = "select Name,Report_No,Amount_Per from py_report " & vFilter & _
            '    " and Amount_Per is not null and Amount_Per > 0 and exists " & _
            '    "(select Emp_Cd from py_emp_master where py_emp_master.Emp_Cd=py_report.Emp_Cd and " & _
            '    "Bank_Code='CIT'"
            cm.CommandText = "select Name,Report_No,Amount_Per from py_report " & vFilter & _
               " and Amount_Per is not null and Amount_Per > 0 "

            Select Case vStatus
                Case 0  'inactive
                    cm.CommandText += " and Emp_Status='R' "
                Case 1  'active
                    cm.CommandText += " and Emp_Status not in ('R','HOLD') "
                Case 2  'hold
                    cm.CommandText += " and Emp_Status='HOLD' "
            End Select
            cm.CommandText += " order by Name"

            rs = cm.ExecuteReader
            vDump = ""
            Do While rs.Read
                vData.AppendLine("<tr class='" & vClass & "'><td class='labelR'>" & iCtr & ".</td>" & _
                    "<td class='labelL'>" & rs("Name") & "</td><td class='labelC'>" & IIf(IsDBNull(rs("Report_No")), "", rs("Report_No")) & _
                    "</td><td class='labelR'>" & Format(rs("Amount_Per"), "###,##0.00") & "</td></tr>")

                If rs("Report_No").ToString.Trim <> "" Then
                    vDump += rs("Report_No").ToString.Replace("-", "").Substring(0, 10)
                Else
                    vDump += "0000000000"
                End If

                vDump += Format(rs("Amount_Per") * 100, "0000000000000") & vbNewLine
                iCtr += 1
                vGrandTotal += rs("Amount_Per")
                vClass = IIf(vClass = "odd", "even", "odd")
            Loop
            rs.Close()

            vData.AppendLine("<tr class='activeBar'><td colspan='3' class='labelR'>Grand Total:</td>" & _
                "<td class='labelR'>" & Format(vGrandTotal, "###,###,##0.00") & "</td></tr></table><br/<br/>")

            vData.AppendLine("<table border='0' class='mainGridView'><tr valign='top'><td class='labelL'>Prepared By:<br/><br/><br/><br/></td>" & _
                "<td></td><td class='labelL'>Approved By:</td></tr>")
            vData.AppendLine("<tr><td class='labelL'>_________________________</td><td>&nbsp;&nbsp;&nbsp;</td>" & _
                "<td class='labelL'>______________________</td></tr>" & _
                 "<tr><td class='labelL'>" & vPreparedBy & "</td><td></td><td class='labelL'>" & vApprovedBy & "</td></tr>" & _
                 "<tr><td class='labelL'>" & vPosition & "</td><td></td><td class='labelL'>" & vPositionApproved & "</td></tr></table>")
            If vDump <> "" Then
                'remove last newline character
                vDump = Mid(vDump, 1, Len(vDump) - 2)
            End If
        Catch ex As SqlClient.SqlException
            vResponse = "error"
            vData.AppendLine(ex.Message)
            GoTo dump
        End Try
dump:
        vData.AppendLine("</center></body>")
        vData.AppendLine("</html>")
        Try
            IO.File.WriteAllText(Server.MapPath(".") & "\downloads\" & Session.SessionID & "-bankadvise.html", vData.ToString)
            IO.File.WriteAllText(Server.MapPath(".") & "\downloads\" & Session.SessionID & "-bankadvise.txt", vDump)
            vResponse = "downloads/" & Session.SessionID & "-bankadvise.html~" & _
                "downloads/" & Session.SessionID & "-bankadvise.txt"
        Catch ex As system.exception
            vResponse = "error"
        Finally
            c.Close()
            cm.Dispose()
            c.Dispose()
        End Try
    End Sub
End Class
