Namespace denaro
    Partial Class empstep2
        Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub


        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        Public vScript As String = ""
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load, Me.Load
            If Session("uid") = "" Or Session("uid") = Nothing Then
                vScript = "alert('Your login session has expired. Please login again.'); window.close();"
                Exit Sub
            End If

            Dim vSupervisors As String = ""
            Dim vNotings As String = ""
            Dim vRecommendings As String = ""

            cmbSupervisor.Items.Clear()
            cmbApproving.Items.Clear()
            cmbNoting.Items.Clear()
            If Not IsPostBack Then
                Dim c As New SqlClient.SqlConnection(connStr)
                Dim cm As New SqlClient.SqlCommand
                Dim rs As SqlClient.SqlDataReader
                Dim vBankType As String = ""
                lblCaption.Text = "Employee Master Information (2 of 6)"

                Try
                    c.Open()
                Catch ex As SqlClient.SqlException
                    vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                        ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                    c.Dispose()
                    cm.Dispose()
                    Exit Sub
                End Try

                BuildCombo("select Civil_Cd,Descr from py_civil_ref", cmbCivil, c)
                BuildCombo("select Bank_Code,Bank_Name from bank_codes order by Bank_Name", cmbBank, c)
                'BuildCombo("select zonecd,area from tripzones order by zonecd", cmbZone)
                cmbSupervisor.Items.Add(New ListItem("99=>Unknown", "99"))
                cmbCivil.Items.Add(New ListItem("99=>Unknown", "99"))
                cmbBank.Items.Add(New ListItem("99=>Unknown", "99"))

                cm.Connection = c
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY:  VIC GATCHALIAN                                ''
                '' DATE MODIFIED: 4/22/2013                                    ''
                '' PURPOSE: TO EXPOSE THE MOBILE NUMBER AS WELL AS THE TAG     ''
                ''          FOR OPTIONAL APPROVERS 2 AND 3.                    ''
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                ''''''''''''''''''''''' OLD CODE ''''''''''''''''''''''''''''''''
                'cm.CommandText = "select Emp_Tel,Emp_Email,Emp_Address,Prov_Address,BirthPlace,SupervisorCd,Noting,Approving,User_Id,Male," & _
                '    "Civil_Cd,Bday,Pin,Acct_No,Bank_Type,Bank_Code,Emp_Fname,Emp_Lname,Emp_Mname,Fir,Rc_Cd " & _
                '    "from py_emp_master where emp_cd='" & Session("empid") & "'"
                ''''''''''''''''''''''' END OLD CODE ''''''''''''''''''''''''''''
                cm.CommandText = "select Emp_Tel,Emp_Email,Emp_Address,Prov_Address,BirthPlace," & _
                    "SupervisorCd,Noting,Approving,User_Id,Male,MobileNo,OptionalApprover2,OptionalApprover3," & _
                    "Civil_Cd,Bday,Pin,Acct_No,Bank_Type,Bank_Code,Emp_Fname,Emp_Lname,Emp_Mname,Fir,Rc_Cd " & _
                    "from py_emp_master where emp_cd='" & Session("empid") & "'"
                ''''''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''

                
                Try
                    rs = cm.ExecuteReader
                    If rs.Read Then
                        lblName.Text = rs("Emp_Lname") & ", " & rs("Emp_Fname") & " " & rs("Emp_Mname")
                        txtRC.Text = rs("Rc_Cd")
                        txtContact.Text = IIf(IsDBNull(rs("Emp_Tel")), "", rs("Emp_Tel"))
                        txtemail.Text = IIf(IsDBNull(rs("Emp_Email")), "", rs("Emp_Email"))
                        txtAddr.Text = IIf(IsDBNull(rs("Emp_Address")), "", rs("Emp_Address"))
                        txtProvAddr.Text = IIf(IsDBNull(rs("Prov_Address")), "", rs("Prov_Address"))
                        txtBDate.Text = IIf(IsDBNull(rs("Bday")), "", rs("Bday"))
                        txtAcct.Text = IIf(IsDBNull(rs("Acct_No")), "", rs("Acct_No"))
                        txtBPlace.Text = IIf(IsDBNull(rs("BirthPlace")), "", rs("BirthPlace"))
                        If IsDBNull(rs("Bank_Type")) Then
                            vBankType = "Unknown"
                        Else
                            If rs("Bank_Type") = "" Then
                                vBankType = "Unknown"
                            Else
                                vBankType = rs("Bank_Type")
                            End If
                        End If
                        cmbType.SelectedValue = vBankType
                        cmbBank.SelectedValue = IIf(IsDBNull(rs("Bank_Code")), "99", rs("Bank_Code"))
                        vNotings = IIf(IsDBNull(rs("Noting")), "", rs("Noting"))
                        vRecommendings = IIf(IsDBNull(rs("Approving")), "", rs("Approving"))
                        vSupervisors = IIf(IsDBNull(rs("SupervisorCd")), "", rs("SupervisorCd"))

                        If IsDBNull(rs("Male")) Then
                            optMale.Checked = True
                        Else
                            optMale.Checked = rs("Male") = 1
                            optFemale.Checked = rs("Male") <> 1
                        End If

                        cmbCivil.SelectedValue = IIf(IsDBNull(rs("Civil_Cd")), "99", rs("Civil_Cd"))

                        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                        '' MODIFIED BY:  VIC GATCHALIAN                                     ''
                        '' DATE MODIFIED: 4/22/2013                                         ''
                        '' PURPOSE: TO EXPOSE THE MOBILE NUMBER AND TAG FOR OPTIONAL        ''
                        ''          APPROVERS 2 AND 3                                       ''
                        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                        txtMobile.Text = IIf(IsDBNull(rs("MobileNo")), "", rs("MobileNo"))
                        chkOptional2.Checked = rs("OptionalApprover2") = 1
                        chkOptional3.Checked = rs("OptionalApprover3") = 1
                        '''''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''
                    End If

                    Session("oldval") = "Contact Numbers=" & txtContact.Text.Replace("'", "") & _
                       "|Mobile Numbers=" & txtMobile.Text.Replace("'", "") & _
                       "|email address=" & txtemail.Text.Replace("'", "") & _
                       "|Home Address=" & txtAddr.Text.Replace("'", "") & _
                       "|Provincial Address=" & txtProvAddr.Text.Replace("'", "") & _
                       "|Birthdate=" & txtBDate.Text & _
                       "|Birth Place=" & txtBPlace.Text.Replace("'", "") & _
                       "|Account #=" & txtAcct.Text.Replace("'", "") & _
                       "|Account Type=" & vBankType & _
                       "|Bank Name=" & cmbBank.SelectedValue & _
                       "|Gender=" & IIf(rs("Male") = 1, "Male", "Female") & _
                       "|Civil Status=" & cmbCivil.SelectedValue & _
                       "|1st Approver=" & vSupervisors & _
                       "|2nd Approver=" & vRecommendings & _
                       "|3rd Approver=" & vNotings & _
                       "|2nd Approver is Optional?=" & IIf(chkOptional2.Checked, "yes", "no") & _
                       "|3rd Approver is Optional?=" & IIf(chkOptional3.Checked, "yes", "no")

                    rs.Close()
                Catch ex As SqlClient.SqlException
                    Response.Write("Error in SQL Statement.<br>" & ex.Message)
                End Try
                
                BuildCombo("select Emp_Cd,Emp_Lname+', '+Emp_Fname as name from py_emp_master where Emp_Cd in ('" & _
                    vSupervisors.Replace(",", "','") & "')", cmbSupervisor, c)
                BuildCombo("select Emp_Cd,Emp_Lname+', '+Emp_Fname as name from py_emp_master where Emp_Cd in ('" & _
                    vNotings.Replace(",", "','") & "')", cmbNoting, c)
                BuildCombo("select Emp_Cd,Emp_Lname+', '+Emp_Fname as name from py_emp_master where Emp_Cd in ('" & _
                    vRecommendings.Replace(",", "','") & "')", cmbApproving, c)
                c.Close()
                c.Dispose()
                cm.Dispose()
            End If
        End Sub

        Private Sub cmdPrev_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdPrev.Click
            Session.Remove("oldval")
            Session.Remove("newval")
            Server.Transfer("empstep1.aspx")
        End Sub

        Private Sub cmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
            Session.Remove("empid")
            Session.Remove("oldval")
            Session.Remove("newval")
            vScript = "window.close();"
        End Sub

        Private Sub cmdSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSave.Click
            Page.Validate()

            If txtAcct.Text.Trim.Length > 1 And txtAcct.Text.Trim.Length < 10 Then
                vScript = "alert('Account number must be at least 10 digits long.');"
                Exit Sub
            End If
            If Page.IsValid Then
                Dim c As New SqlClient.SqlConnection
                Dim cm As New SqlClient.SqlCommand
                Dim vBDate As String = "null"
                Dim vSQL As String
                Dim vList As String = ""
                Dim i As Integer

                If txtBDate.Text <> "" Then
                    vBDate = "'" & Format(CDate(txtBDate.Text), "yyyy/MM/dd") & "'"
                End If
                vSQL = "update py_emp_master set " & _
                    "Emp_Tel='" & txtContact.Text.Replace("'", "") & _
                    "',MobileNo='" & txtMobile.Text.Replace("'", "") & _
                    "',Emp_Email='" & txtemail.Text.Replace("'", "") & _
                    "',Emp_Address='" & txtAddr.Text.Replace("'", "''") & _
                    "',Prov_Address='" & txtProvAddr.Text.Replace("'", "''") & _
                    "',BirthPlace='" & txtBPlace.Text.Replace("'", "''") & _
                    "',Male=" & IIf(optMale.Checked, 1, 0) & _
                    ",Civil_Cd='" & cmbCivil.SelectedValue & _
                    "',Bday=" & vBDate & _
                    ",Acct_No='" & txtAcct.Text.Replace("'", "''") & _
                    "',Bank_Type='" & IIf(cmbType.SelectedValue = "Unknown", "", cmbType.SelectedValue) & _
                    "',Bank_Code='" & cmbBank.SelectedValue & _
                    "',Modified_Date='" & Format(Now, "yyyy/MM/dd HH:mm:ss") & _
                    "',Modified_By='" & Session("uid") & _
                    "',OptionalApprover2=" & IIf(chkOptional2.Checked, 1, 0) & _
                    ",OptionalApprover3=" & IIf(chkOptional3.Checked, 1, 0) & _
                    " where Emp_Cd='" & Session("empid") & "'"
                c.ConnectionString = connStr
                c.Open()
                cm.Connection = c
                cm.CommandText = vSQL
                Try
                    cm.ExecuteNonQuery()
                    Session("newval") = "Contact Numbers=" & txtContact.Text.Replace("'", "") & _
                       "|Mobile Numbers=" & txtMobile.Text.Replace("'", "") & _
                       "|email address=" & txtemail.Text.Replace("'", "") & _
                       "|Home Address=" & txtAddr.Text.Replace("'", "") & _
                       "|Provincial Address=" & txtProvAddr.Text.Replace("'", "") & _
                       "|Birthdate=" & txtBDate.Text & _
                       "|Birth Place=" & txtBPlace.Text.Replace("'", "") & _
                       "|Account #=" & txtAcct.Text.Replace("'", "") & _
                       "|Account Type=" & IIf(cmbType.SelectedValue = "Unknown", "", cmbType.SelectedValue) & _
                       "|Bank Name=" & cmbBank.SelectedValue & _
                       "|Gender=" & IIf(optMale.Checked, "Male", "Female") & _
                       "|Civil Status=" & cmbCivil.SelectedValue & _
                       "|1st Approver="

                    For i = 0 To cmbSupervisor.Items.Count - 1
                        Session("newval") += cmbSupervisor.Items(0).Value & ","
                    Next
                    Session("newval") = Mid(Session("newval"), 1, Len(Session("newval")) - 1) & "|2nd Approver="
                    For i = 0 To cmbApproving.Items.Count - 1
                        Session("newval") += cmbApproving.Items(0).Value & ","
                    Next
                    Session("newval") = Mid(Session("newval"), 1, Len(Session("newval")) - 1) & "|3rd Approver="
                    For i = 0 To cmbNoting.Items.Count - 1
                        Session("newval") += cmbNoting.Items(0).Value & ","
                    Next
                    Session("newval") = Mid(Session("newval"), 1, Len(Session("newval")) - 1)
                    Session("newval") += "|2nd Approver is Optional?=" & IIf(chkOptional2.Checked, "yes", "no") & _
                       "|3rd Approver is Optional?=" & IIf(chkOptional3.Checked, "yes", "no")

                    EventLog(Session("uid"), Request.ServerVariables("REMOTE_ADDR"), "EDIT", Session("oldval"), Session("newval"), _
                        "Employee ID: " & Session("empid") & " was added/edited", "201 Profile")
                    Session.Remove("oldval")
                    Session.Remove("newval")
                    Server.Transfer("empstep2_1.aspx")
                Catch ex As SqlClient.SqlException
                    Response.Write("Error in SQL statement.<br>" & ex.Message)
                Finally
                    c.Close()
                    cm.Dispose()
                    c.Dispose()
                End Try
            End If
        End Sub

        Private Sub vldBDate_ServerValidate(ByVal source As System.Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles vldBDate.ServerValidate
            If txtBDate.Text <> "" Then
                args.IsValid = IsDate(txtBDate.Text)
            Else
                args.IsValid = True
            End If
        End Sub

        Protected Sub vldAcct_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles vldAcct.ServerValidate
            Dim c As New SqlClient.SqlConnection(connStr)
            Dim cm As New SqlClient.SqlCommand
            Dim rs As SqlClient.SqlDataReader

            Try
                c.Open()
            Catch ex As sqlclient.sqlException
                vScript = "alert('Error occurred while trying to connect to database.');"
                args.IsValid = False
                Exit Sub
            End Try

            cm.Connection = c
            cm.CommandText = "select Emp_Cd,Emp_Lname,Emp_Fname from py_emp_master where " & _
                "replace(replace(Acct_No,' ',''),'-','')='" & txtAcct.Text.Replace("-", "").Replace(" ", "") & _
                "' and Date_Resign is null and Emp_Cd<>'" & Session("empid") & "'"
            Try
                rs = cm.ExecuteReader
                If rs.Read Then
                    args.IsValid = False

                    'check if account number is equal to company bank account number
                    Dim vCompanyAcctNo As String = ""
                    rs.Close()
                    cm.CommandText = "select BankAcctNo from glsyscntrl"
                    rs = cm.ExecuteReader
                    If rs.Read Then
                        If Not IsDBNull(rs("BankAcctNo")) Then
                            vCompanyAcctNo = rs("BankAcctNo").ToString.Replace("'", "").Replace(" ", "")
                        End If
                    End If
                    If vCompanyAcctNo = txtAcct.Text.Replace("-", "").Replace(" ", "") Then
                        args.IsValid = True
                    Else
                        vScript = "alert('Account # already is use by " & _
                            rs("Emp_Cd") & "->" & rs("Emp_Lname") & ", " & rs("Emp_Fname") & "');"
                    End If
                Else
                    args.IsValid = True
                End If
                rs.Close()
            Catch ex As sqlclient.sqlException
                vScript = "alert('Error executing query: " & cm.CommandText & "');"
                args.IsValid = False
            Finally
                c.Close()
                cm.Dispose()
                c.Dispose()
            End Try

        End Sub

        Protected Sub cmbQuickNavi_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbQuickNavi.SelectedIndexChanged
            Server.Transfer(cmbQuickNavi.SelectedValue)
        End Sub
    End Class

End Namespace
