Imports denaro.fis
Partial Class loanmonitorbyemp
    Inherits System.Web.UI.Page

    Public vScript As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Session("returnaddr") = "loanmonitor.aspx"
            Server.Transfer("index.aspx")
        End If
        If Not CanRun(Session("caption"), Request.Item("id")) Then
            Session("denied") = "1"
            Server.Transfer("main.aspx")
            Exit Sub
        End If
        If Not IsPostBack Then
            'now build the reference code
            BuildCombo("select Rc_Cd,Descr from rc where exists (select User_Id from rights_list where User_Id='" & _
                    Session("uid") & "' and property='rc' and Property_Value=Rc_Cd) order by Descr", cmbRC)
            BuildCombo("select AgencyCd,AgencyName from agency where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='agency' and Property_Value=AgencyCd) order by AgencyName", cmbOfc)
            BuildCombo("select Div_Cd,Descr from hr_div_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='division' and Property_Value=Div_Cd) order by Descr", cmbDiv)
            BuildCombo("select Dept_Cd,Descr from hr_dept_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='department' and Property_Value=Dept_Cd) order by Descr", cmbDept)
            BuildCombo("select Section_Cd,Descr from hr_section_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='section' and Property_Value=Section_Cd) order by Descr", cmbSection)
            BuildCombo("select Unit_Cd,Descr from hr_unit_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='unit' and Property_Value=Unit_Cd) order by Descr", cmbUnit)
            BuildCombo("select EmploymentType,Descr from hr_employment_type where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='employmenttype' and Property_Value=EmploymentType) order by Descr", cmbType)

           
            cmbRC.Items.Add("All")
            cmbRC.SelectedValue = "All"
            cmbOfc.Items.Add("All")
            cmbOfc.SelectedValue = "All"
            cmbDiv.Items.Add("All")
            cmbDiv.SelectedValue = "All"
            cmbDept.Items.Add("All")
            cmbDept.SelectedValue = "All"
            cmbSection.Items.Add("All")
            cmbSection.SelectedValue = "All"
            cmbUnit.Items.Add("All")
            cmbUnit.SelectedValue = "All"
            cmbType.Items.Add("All")
            cmbType.SelectedValue = "All"

            lblCaption.Text = "Loan and Other Deductions Monitoring"
            RefreshEmp("A")
            
        End If
    End Sub
    Private Sub RefreshEmp(ByVal pLetter As String)
        Dim c As New sqlclient.sqlconnection(connStr)
        Dim cm As New sqlclient.sqlcommand
        Dim dr As sqlclient.sqldatareader
        Dim da As sqlclient.sqldataadapter
        Dim ds As New DataSet
        Dim vQry = " where Date_Resign is null "
        Dim vFilter = " where Date_Resign is null and  " & cmbFilter.SelectedValue & " like '" & pLetter & "%' "
        Dim vSql As String = ""

        If cmbRC.SelectedValue <> "All" Then   'filter by cost center
            vFilter += " and Rc_Cd='" & cmbRC.SelectedValue & "' "
            vQry += " and Rc_Cd='" & cmbRC.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='rc' and Property_Value=Rc_Cd) "
            vQry += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='rc' and Property_Value=Rc_Cd) "
        End If
        If cmbOfc.SelectedValue <> "All" Then        'filter by office/agency
            vFilter += " and Agency_Cd='" & cmbOfc.SelectedValue & "' "
            vQry += " and Agency_Cd='" & cmbOfc.SelectedValue & "' "
        Else
            vFilter += "  and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='agency' and Property_Value=Agency_Cd) "
            vQry += "  and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='agency' and Property_Value=Agency_Cd) "
        End If
        If cmbDiv.SelectedValue <> "All" Then      'filter by division
            vFilter += " and Divcd='" & cmbDiv.SelectedValue & "' "
            vQry += " and Divcd='" & cmbDiv.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='division' and Property_Value=DivCd) "
            vQry += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='division' and Property_Value=DivCd) "
        End If
        If cmbDept.SelectedValue <> "All" Then  'filter by departments
            vFilter += " and DeptCd='" & cmbDept.SelectedValue & "' "
            vQry += " and DeptCd='" & cmbDept.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='department' and Property_Value=DeptCd) "
            vQry += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='department' and Property_Value=DeptCd) "
        End If
        If cmbSection.SelectedValue <> "All" Then 'filter by section
            vFilter += " and SectionCd='" & cmbSection.SelectedValue & "' "
            vQry += " and SectionCd='" & cmbSection.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='section' and Property_Value=SectionCd) "
            vQry += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='section' and Property_Value=SectionCd) "
        End If
        If cmbUnit.SelectedValue <> "All" Then  'filter by units
            vFilter += " and UnitCd='" & cmbUnit.SelectedValue & "' "
            vQry += " and UnitCd='" & cmbUnit.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='unit' and Property_Value=UnitCd) "
            vQry += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='unit' and Property_Value=UnitCd) "
        End If

        If cmbType.SelectedValue <> "All" Then
            vFilter += " and EmploymentType='" & cmbType.SelectedValue & "' "
            vQry += " and EmploymentType='" & cmbType.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='employmenttype' and Property_Value=EmploymentType) "
            vQry += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='employmenttype' and Property_Value=EmploymentType) "
        End If


        vSql = "select Emp_Cd,Emp_Lname,Emp_Fname from py_emp_master " & vFilter & _
            " order by Emp_Lname,Emp_Fname"

        da = New sqlclient.sqldataadapter(vSql, c)
        Try
            da.Fill(ds, "Master")
            tblEmpList.DataSource = ds.Tables("Master")
            tblEmpList.DataBind()
            tblEmpList.SelectedIndex = -1
            DataRefresh()
            getDetail()
        Catch ex As sqlclient.sqlexception
            vScript = "alert('Error occurred while binding the Employee masterfile to grid. Error is: " & _
                ex.Message.Replace(vbCrLf, "\n").Replace("'", "\'") & "');"
            ds.Dispose()
            da.Dispose()
            cm.Dispose()
            c.Dispose()
            Exit Sub
        End Try


        Try
            c.Open()
        Catch ex As sqlclient.sqlexception
            vScript = "alert('Error occurred while trying to connect to SQL Server. Error is: " & _
                ex.Message.Replace(vbCrLf, "\n").Replace("'", "\'") & "');"
            c.Dispose()
            ds.Dispose()
            cm.Dispose()
            da.Dispose()
            Exit Sub
        End Try

        cm.Connection = c
        EnableAll(False)
        cm.CommandText = "select distinct substring(Emp_Lname,1,1) as Letters from py_emp_master " & vQry

        Try
            dr = cm.ExecuteReader
            Do While dr.Read
                SetLetters(dr("Letters"))
            Loop
            dr.Close()
        Catch ex As sqlclient.sqlexception
            vScript = "alert('Error occurred while trying to classify letter hyperlinks. Error is: " & _
                ex.Message.Replace(vbCrLf, "\n").Replace("'", "\'") & "');"
        Finally
            cm.Dispose()
            c.Close()
            c.Dispose()
            ds.Dispose()
            da.Dispose()
        End Try
    End Sub
    Private Sub DataRefresh()
        If tblEmpList.SelectedIndex > -1 And tblEmpList.SelectedIndex < tblEmpList.Rows.Count Then
            cmdApprove.Visible = cmbLoanStatus.SelectedValue = 2

            Dim c As New sqlclient.sqlConnection(connStr)
            Dim ds As New DataSet
            Dim da As New SqlClient.SqlDataAdapter("select Loan_Cd,DocNo,Amt_Bal," & _
                "Amt_Loan,Amt_Paid,Loan_Date as LoanDate," & _
                "py_loan_hdr.Start_Date as StartDate,Int_Rate,Month_To_Pay,MonthlyAmort as Amort " & _
                "from py_loan_hdr where Emp_Cd='" & tblEmpList.SelectedRow.Cells(0).Text & "' and Active=" & _
                IIf(cmbLoanStatus.SelectedValue = 2, 0, cmbLoanStatus.SelectedValue) & _
                IIf(cmbLoanStatus.SelectedValue = 2, " and UploadedBy is not null ", " ") & _
                "order by Loan_Cd,Loan_Date desc,Start_Date desc", c)
            Try
                da.Fill(ds, "LoanMaster")
                tblEmp.DataSource = ds.Tables("LoanMaster")
                tblEmp.DataBind()
                tblEmp.SelectedIndex = -1
            Catch ex As sqlclient.sqlexception
                vScript = "alert('Error occurred while trying to retrieve employee loan ledger. Error is: " & _
                    ex.Message.Replace(vbCrLf, "\n").Replace("'", "\'") & "');"
            Finally
                c.Dispose()
                da.Dispose()
                ds.Dispose()
                cmdEdit.Enabled = tblEmp.Rows.Count > 0
                cmdDel.Enabled = cmdEdit.Enabled
                cmdPrint.Enabled = cmdEdit.Enabled
                cmdDeactivate.Enabled = cmdEdit.Enabled
            End Try
        Else
            vScript = "alert('Please select an employee first.');"
        End If
    End Sub
    Private Sub SetLetters(ByVal pLetter As String)
        Select Case LCase(pLetter)
            Case "a"
                cmdA.Visible = True
            Case "b"
                cmdB.Visible = True
            Case "c"
                cmdC.Visible = True
            Case "d"
                cmdD.Visible = True
            Case "e"
                cmdE.Visible = True
            Case "f"
                cmdF.Visible = True
            Case "g"
                cmdG.Visible = True
            Case "h"
                cmdH.Visible = True
            Case "i"
                cmdI.Visible = True
            Case "j"
                cmdJ.Visible = True
            Case "k"
                cmdK.Visible = True
            Case "l"
                cmdL.Visible = True
            Case "m"
                cmdM.VISIBLE = True
            Case "n"
                cmdN.Visible = True
            Case "o"
                cmdO.Visible = True
            Case "p"
                cmdP.Visible = True
            Case "q"
                cmdQ.Visible = True
            Case "r"
                cmdR.Visible = True
            Case "s"
                cmdS.Visible = True
            Case "t"
                cmdT.Visible = True
            Case "u"
                cmdU.Visible = True
            Case "v"
                cmdV.Visible = True
            Case "w"
                cmdW.Visible = True
            Case "x"
                cmdX.Visible = True
            Case "y"
                cmdY.Visible = True
            Case "z"
                cmdZ.Visible = True
        End Select
    End Sub
    Protected Sub cmdReturn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.Click
        Session.Remove("sql")
        Session.Remove("postdate")
        Session.Remove("fromdate")
        Session.Remove("todate")
        Session.Remove("letter")
        Server.Transfer("main.aspx")
    End Sub


    Protected Sub cmdA_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdA.Click, _
        cmdB.Click, cmdC.Click, cmdD.Click, cmdE.Click, cmdF.Click, cmdG.Click, cmdH.Click, cmdI.Click, _
       cmdJ.Click, cmdK.Click, cmdL.Click, cmdM.Click, cmdN.Click, cmdO.Click, cmdP.Click, cmdQ.Click, _
       cmdR.Click, cmdS.Click, cmdT.Click, cmdU.Click, cmdV.Click, cmdW.Click, cmdX.Click, cmdY.Click, cmdZ.Click

        txtSearch.Text = CType(sender, LinkButton).Text
        tblEmp.SelectedIndex = -1
        RefreshEmp(txtSearch.Text)
    End Sub
    Private Sub EnableAll(Optional ByVal pState As Boolean = True)
        cmdA.Visible = pState : cmdB.Visible = pState : cmdC.Visible = pState : cmdD.Visible = pState
        cmdE.Visible = pState : cmdF.Visible = pState : cmdG.Visible = pState : cmdH.Visible = pState
        cmdI.Visible = pState : cmdJ.Visible = pState : cmdK.Visible = pState : cmdL.Visible = pState
        cmdM.Visible = pState : cmdN.Visible = pState : cmdO.Visible = pState : cmdP.Visible = pState
        cmdQ.Visible = pState : cmdR.Visible = pState : cmdS.Visible = pState : cmdT.Visible = pState
        cmdU.Visible = pState : cmdV.Visible = pState : cmdW.Visible = pState : cmdX.Visible = pState
        cmdY.Visible = pState : cmdZ.Visible = pState
    End Sub

    Protected Sub cmdEdit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdEdit.Click
        Dim vEmpId As String = ""
        Dim vLoanDate As String = ""
        Dim vLoanType As String = ""
        If tblEmp.SelectedIndex >= 0 And tblEmp.SelectedIndex < tblEmp.Rows.Count And _
            tblEmpList.SelectedIndex >= 0 And tblEmpList.SelectedIndex < tblEmpList.Rows.Count Then
            vEmpId = tblEmpList.SelectedRow.Cells(0).Text
            vLoanDate = tblEmp.SelectedRow.Cells(2).Text
            vLoanType = tblEmp.SelectedRow.Cells(0).Text
            vScript = "editwin=window.open('modifyloan.aspx?Mode=e&EmpId=" & vEmpId & "&LoanDate=" & vLoanDate & "&LoanType=" & vLoanType & "','empwin','toolbar=no,location=no,width=600,height=500,top=100,left=100');"
        Else
            vScript = "alert('You must first select an employee and a Loan Ledger to edit.');"
        End If
    End Sub

    Protected Sub cmdAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdAdd.Click
        If tblEmpList.SelectedIndex >= 0 And tblEmpList.SelectedIndex < tblEmpList.Rows.Count Then
            Dim vLoanType As String = "new"

            'set filters
            Session("selrc") = cmbRC.SelectedValue
            Session("selofc") = cmbOfc.SelectedValue
            Session("seldiv") = cmbDiv.SelectedValue
            Session("seldept") = cmbDept.SelectedValue
            Session("selsection") = cmbSection.SelectedValue
            Session("selunit") = cmbUnit.SelectedValue
            Session("seltype") = cmbType.SelectedValue
            vScript = "editwin=window.open('modifyloan.aspx?LoanType=" & vLoanType & "&Mode=a&empid=" & _
                tblEmpList.SelectedRow.Cells(0).Text & "','empwin','toolbar=no,location=no,width=600,height=500,top=100,left=100');"
        Else
            vScript = "alert('You must first select an employee.');"
        End If
    End Sub

    Protected Sub cmdDel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDel.Click
        If tblEmp.SelectedIndex >= 0 And tblEmp.Rows.Count - 1 >= tblEmp.SelectedIndex And _
            tblEmpList.SelectedIndex >= 0 And tblEmpList.Rows.Count - 1 >= tblEmpList.SelectedIndex Then
            Dim c As New sqlclient.sqlConnection(connStr)
            Dim cm As New sqlclient.sqlCommand

            c.ConnectionString = connStr
            Try
                c.Open()
            Catch ex As sqlclient.sqlexception
                vScript = "alert('Error occurred while trying to connect to SQL Server. Error is: " & _
                    ex.Message.Replace(vbCrLf, "\n").Replace("'", "\'") & "');"
                c.Dispose()
                cm.Dispose()
                Exit Sub
            End Try

            cm.Connection = c
            cm.CommandText = "delete from py_loan_hdr where Emp_Cd='" & _
                tblEmpList.SelectedRow.Cells(0).Text & "' and Loan_Cd='" & _
                tblEmp.SelectedRow.Cells(0).Text & "' and Loan_Date='" & _
                Format(CDate(tblEmp.SelectedRow.Cells(2).Text), "yyyy/MM/dd") & "'"
            Try
                cm.ExecuteNonQuery()
            Catch ex As sqlclient.sqlexception
                vScript = "alert('Error occurred while trying to clean-up Loan Ledger. Error is: " & _
                    ex.Message.Replace(vbCrLf, "\n").Replace("'", "\'") & "');"
                c.Close()
                c.Dispose()
                cm.Dispose()
                Exit Sub
            End Try


            cm.CommandText = "delete from py_loan_dtl where Emp_Cd='" & _
                tblEmpList.SelectedRow.Cells(0).Text & "' and Loan_Cd='" & _
                tblEmp.SelectedRow.Cells(0).Text & "' and Loan_Date='" & _
                Format(CDate(tblEmp.SelectedRow.Cells(2).Text), "yyyy/MM/dd") & "'"
            Try
                cm.ExecuteNonQuery()
            Catch ex As sqlclient.sqlexception
                vScript = "alert('Error occurred while trying to clean-up Loan amortization schedule. Error is: " & _
                    ex.Message.Replace(vbCrLf, "\n").Replace("'", "\'") & "');"
            Finally
                c.Close()
                c.Dispose()
                cm.Dispose()
                DataRefresh()
                getDetail()
            End Try
        Else
            vScript = "alert('You must first select an Employee and Loan Ledger to delete.');"
        End If
    End Sub

    Protected Sub cmdDel_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDel.Init
        cmdDel.Attributes.Add("onclick", "return ask();")
    End Sub

    Protected Sub tblEmp_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles tblEmp.PageIndexChanging
        tblEmp.PageIndex = e.NewPageIndex
        DataRefresh()
        getDetail()
    End Sub

    Protected Sub cmdDeactivate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDeactivate.Click
        Dim vActive = IIf(cmdDeactivate.Text = "Deactivate Loan", 0, 1)     'reverse the state

        If tblEmp.SelectedIndex <> -1 And tblEmp.SelectedIndex <= tblEmp.Rows.Count And _
            tblEmpList.SelectedIndex > -1 And tblEmpList.SelectedIndex <= tblEmpList.Rows.Count - 1 Then
            Dim cm As New sqlclient.sqlCommand
            Dim c As New sqlclient.sqlConnection(connStr)
            Try
                c.Open()
                cm.Connection = c
                cm.CommandText = "update py_loan_hdr set Active=" & vActive & " where Loan_Cd='" & _
                    tblEmp.SelectedRow.Cells(0).Text & "' and Emp_Cd='" & _
                    tblEmpList.SelectedRow.Cells(0).Text & "' and Loan_Date='" & _
                    Format(CDate(tblEmp.SelectedRow.Cells(2).Text), "yyyy/MM/dd") & "'"
                cm.ExecuteNonQuery()
                c.Close()
                vScript = "alert('Loan has been " & IIf(vActive = 1, "deactivated", "reactivated") & " successfully');"
                DataRefresh()
                getDetail()
            Catch ex As system.exception
                vScript = "alert('An error occurred while trying to execute your request. Error is: " & _
                    ex.Message.Replace("'", "") & "');"
            Finally
                c.Dispose()
                cm.Dispose()
            End Try
        Else
            vScript = "alert('You must first select an employee and a Loan ledger before deactivating/reactivating the loan.');"
        End If
    End Sub

    Protected Sub cmdSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSearch.Click
        RefreshEmp(txtSearch.Text)
    End Sub

    Protected Sub cmdPrint_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdPrint.Click
        vScript = "prevwin=window.open('preview.aspx','incentwin','location=no,toolber=no,width=492,height=300');"
    End Sub

    Protected Sub cmdApprove_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdApprove.Click
        If tblEmp.SelectedIndex >= 0 And tblEmp.SelectedIndex <= tblEmp.Rows.Count Then
            Dim c As New sqlclient.sqlConnection(connStr)
            Dim cm As New sqlclient.sqlCommand("update py_loan_hdr set Active=1 where Loan_Cd='" & _
                tblEmp.SelectedRow.Cells(0).Text & "' and Emp_Cd='" & tblEmpList.SelectedRow.Cells(0).Text & _
                "' and Loan_Date='" & Format(CDate(tblEmp.SelectedRow.Cells(2).Text), "yyyy/MM/dd") & _
                "' and Active=0 and UploadedBy is not null", c)
            Try
                c.Open()
                cm.ExecuteNonQuery()
                c.Close()
                vScript = "alert('Your selected row has been activated.  It will now be included in the Deduction Schedule.');"
                DataRefresh()
                getDetail()
            Catch ex As sqlclient.sqlException
                vScript = "alert('Error occurred while trying to approve the loan application. Error is: " & _
                    ex.Message.Replace(vbCrLf, "\n").Replace("'", "\'") & "');"
            Finally
                c.Dispose()
                cm.Dispose()
            End Try
        Else
            vScript = "alert('You must first select a record to active.');"
        End If
    End Sub

    Protected Sub tblEmp_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tblEmp.SelectedIndexChanged
        getDetail()
    End Sub
    Private Sub getDetail()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim vStr As String = "SELECT Emp_Cd,CAST(Tran_Date AS DATETIME) as TranDate," & _
            " CASE WHEN Paid=1 THEN 'Paid' ELSE 'Unpaid' END AS Paid,round(Amt_Paid,2) AS Amt_Paid,Date_Paid," & _
            "CASE WHEN Active='True' THEN 'Active' ELSE 'Hold' END AS Active " & _
            ",round(Amt_Cost,2) AS Amt_Cost FROM py_loan_dtl WHERE Emp_Cd is null"

        If tblEmp.SelectedIndex >= 0 And tblEmp.Rows.Count > tblEmp.SelectedIndex Then
            Dim vDocNo As String
            'vDocNo = tblEmp.SelectedRow.Cells(2).Text
            'vStr = "SELECT Emp_Cd,CAST(Tran_Date AS DATE) as TranDate," & _
            '        " CASE WHEN Paid=1 THEN 'Paid' ELSE 'Unpaid' END AS Paid," & _
            '        "round(Amt_Paid,2) AS Amt_Paid,Date_Paid,CASE WHEN Active='True' THEN 'Active' ELSE 'Hold' END AS Active " & _
            '        ",round(Amt_Cost,2) AS Amt_Cost FROM py_loan_dtl WHERE Emp_Cd='" & _
            '        tblEmpList.SelectedRow.Cells(0).Text & "' and Loan_Cd='" & _
            '        tblEmp.SelectedRow.Cells(0).Text & "' and Loan_Date='" & _
            '        Format(CDate(tblEmp.SelectedRow.Cells(2).Text), "yyyy/MM/dd") & "' ORDER BY Tran_Date ASC"
            vStr = "SELECT Emp_Cd,CAST(Tran_Date AS DATETIME) as TranDate," & _
                " CASE WHEN Paid=1 THEN 'Paid' ELSE 'Unpaid' END AS Paid," & _
                "round(Amt_Paid,2) AS Amt_Paid,Date_Paid,CASE WHEN Active=1 THEN 'Active' ELSE 'Hold' END AS Active " & _
                ",round(Amt_Cost,2) AS Amt_Cost FROM py_loan_dtl WHERE Emp_Cd='" & _
                tblEmpList.SelectedRow.Cells(0).Text & "' and Loan_Cd='" & _
                tblEmp.SelectedRow.Cells(0).Text & "' and Loan_Date='" & _
                Format(CDate(tblEmp.SelectedRow.Cells(2).Text), "yyyy/MM/dd") & _
                "' ORDER BY Tran_Date DESC"

        End If
        Dim da As New SqlClient.SqlDataAdapter(vStr, c)
        Dim ds As New DataSet

        Try
            da.Fill(ds, "Detail")
            tblDetail.DataSource = ds.Tables("Detail")
            tblDetail.DataBind()
        Catch ex As sqlclient.sqlException
            vScript = "alert('Error occurred while trying to bind the Loan Amortization schedule to the grid. Error is: " & _
                ex.Message.Replace(vbCrLf, "\n").Replace("'", "\'") & "');"
        Finally
            ds.Dispose()
            da.Dispose()
            c.Dispose()
        End Try
    End Sub

    Protected Sub tblDetail_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles tblDetail.PageIndexChanging
        tblDetail.PageIndex = e.NewPageIndex
        getDetail()
    End Sub

    Protected Sub cmdModifyLoan_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdModifyLoan.Click
        If tblDetail.SelectedIndex >= 0 And tblDetail.SelectedIndex <= tblDetail.Rows.Count Then
            Dim vCmd As String = ""
            Dim VEmp As String = tblEmpList.SelectedRow.Cells(0).Text
            Dim vAmort As Decimal = Val(tblEmp.SelectedRow.Cells(10).Text)
            Dim vLoanDate As Date = CDate(tblEmp.SelectedRow.Cells(2).Text)
            Dim vTranDate As Date = CDate(tblDetail.SelectedRow.Cells(0).Text)
            Dim vAmt As Decimal = CDbl(tblDetail.SelectedRow.Cells(1).Text)

            If tblDetail.SelectedRow.Cells(5).Text = "Hold" Then
                vCmd = "Activate"
            Else
                vCmd = "Deactivate"
            End If
            vScript = "win=window.open('modifyloansked.aspx?Id=" & VEmp & "&LoanCd=" & tblEmp.SelectedRow.Cells(0).Text & _
                      "&DueDate=" & vTranDate & "&amort=" & vAmort & "&DueAmt=" & vAmt & "&LoanDate=" & vLoanDate & "&vCmd=" & vCmd & "','ModifyLoanSchedule','toolbar=no,scrollbars=yes,top=200,left=200,width=300,height=200');win.focus();"
        Else
            vScript = "alert('You must first select a loan schedule.');"
        End If
    End Sub

    Protected Sub lnkView_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles lnkView.Click
        Server.Transfer("loanmonitor.aspx")
    End Sub

    Protected Sub tblEmpList_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles tblEmpList.PageIndexChanging
        tblEmpList.PageIndex = e.NewPageIndex
        RefreshEmp(txtSearch.Text)
    End Sub

    Protected Sub tblEmpList_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tblEmpList.SelectedIndexChanged
        DataRefresh()
        getDetail()
    End Sub
End Class
