Imports denaro.fis
Partial Class accsys
    Inherits System.Web.UI.UserControl
    Dim vDSN As String
    Public vMenu As String = ""
    Protected Sub cmdSignOut_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSignOut.Click
        Session.RemoveAll()
        Server.Transfer("index.aspx")
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim c As New sqlclient.sqlconnection(connStr)
        Dim cm As New sqlclient.sqlCommand
        Dim rs As sqlclient.sqlDataReader

        cm.Connection = c
        c.Open()
        cm.CommandText = "select Label_Caption,Menu_Caption from accsysmenus where ParentId is null and SystemName='ACCSYS'"
        rs = cm.ExecuteReader
        Do While rs.Read
            vMenu += "<li><a href='#' class='parent_first_level'>" & rs("Label_Caption") & "</a>"
            GetChild(rs("Menu_Caption"))
            vMenu += "</li>" & vbCrLf
        Loop
        rs.Close()
        cm.Dispose()
        c.Close()
        c.Dispose()
    End Sub
    Private Sub GetChild(ByVal pId As String)
        Dim c As New sqlclient.sqlConnection(connStr)
        Dim cm As New sqlclient.sqlCommand
        Dim rs As sqlclient.sqlDataReader
        Dim vClass As String = ""

        cm.Connection = c
        c.Open()
        cm.CommandText = "select Label_Caption,Menu_Caption,Dependencies,FormTag from accsysmenus " & _
            "where SystemName='ACCSYS' and ParentId='" & pId & "'"
        rs = cm.ExecuteReader
        If rs.HasRows Then
            vMenu += "<ul>" & vbCrLf
        End If
        Do While rs.Read
            vClass = "class='parent_second_level'"
            If Not IsDBNull(rs("Dependencies")) Then
                vClass = " href='" & rs("Dependencies") & "'"
            End If
            vMenu += "<li><a " & vClass & " >" & rs("Label_Caption") & "</a>"
            GetChild(rs("Menu_Caption"))
            vMenu += "</li>" & vbCrLf
        Loop
        If rs.HasRows Then
            vMenu += "</ul>" & vbCrLf
        End If
        rs.Close()
        c.Close()
        c.Dispose()
    End Sub
    Public Property DSN() As String
        Get
            Return vDSN
        End Get
        Set(ByVal value As String)
            vDSN = value
        End Set
    End Property

    Protected Sub cmdPassword_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdPassword.Click
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If
        Server.Transfer("changepass.aspx")
    End Sub
End Class
