﻿
Partial Class selectpaydate
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Protected Sub cmdSet_Click(sender As Object, e As EventArgs) Handles cmdSet.Click
        Session("paydate") = calPayOut.SelectedDate
        vScript = "parent.document.getElementById('cmdSelectPayDate').value='Select Payout Date (" & _
            calPayOut.SelectedDate & ")';" & _
            "parent.document.getElementById('cmdSelectPayDate').style.backgroundColor = 'blue';" & _
            "parent.document.getElementById('cmdSLVL').disabled='';"
    End Sub

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Session("uid") = Nothing Or Session("uid") = "" Then
            vScript = "alert('Your login session has expired. Please re-login again to continue.'); parent.parent.window.location='login.aspx';"
            Exit Sub
        End If
    End Sub
End Class
