Imports denaro
Partial Class exception
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Public vData As String = ""
    Dim vEmpID As String = ""
    Dim vCnt As Integer = -1

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Session("returnaddr") = "philhealth_er2.aspx"
            Server.Transfer("index.aspx")
        End If
        If Not IsPostBack Then
            Session.Remove("vHeader")
            Session.Remove("vPeriod")
            Session.Remove("vFilter")

            lblCaption.Text = "Exception Report"

            If Not CanRun(Session("caption"), Request.Item("id")) Then
                Session("denied") = "1"
                Server.Transfer("main.aspx")
                Exit Sub
            End If

            BuildCombo("select Rc_Cd, Descr from rc where Rc_Cd in ('" & _
                Session("rclist").ToString.Replace(",", "','") & "') order by Descr ", cmbRC)
            BuildCombo("select AgencyCd,AgencyName from agency where Agencycd in ('" & _
                Session("agencylist").ToString.Replace(",", "','") & "') order by AgencyName", cmbOfc)
            BuildCombo("select Div_Cd,Descr from hr_div_ref where Div_Cd in ('" & _
                Session("divlist").ToString.Replace(",", "','") & "') order by Descr", cmbDiv)
            BuildCombo("select Dept_Cd,Descr from hr_dept_ref where Dept_Cd in ('" & _
                Session("deptlist").ToString.Replace(",", "','") & "') order by Descr", cmbDept)
            BuildCombo("select Section_Cd,Descr from hr_section_ref where Section_Cd in ('" & _
                Session("sectionlist").ToString.Replace(",", "','") & "') order by Descr", cmbSection)
            BuildCombo("select Unit_Cd,Descr from hr_unit_ref where Unit_Cd in ('" & _
                Session("unitlist").ToString.Replace(",", "','") & "') order by Descr", cmbUnit)
            cmbRC.Items.Add("All")
            cmbRC.SelectedValue = "All"
            cmbOfc.Items.Add("All")
            cmbOfc.SelectedValue = "All"
            cmbDiv.Items.Add("All")
            cmbDiv.SelectedValue = "All"
            cmbDept.Items.Add("All")
            cmbDept.SelectedValue = "All"
            cmbSection.Items.Add("All")
            cmbSection.SelectedValue = "All"
            cmbUnit.Items.Add("All")
            cmbUnit.SelectedValue = "All"

            Dim iCtr As Integer
            cmbDayTo.Items.Clear()
            cmbDayFr.Items.Clear()
            cmbYrFr.Items.Clear()
            cmbYrTo.Items.Clear()
            For iCtr = 1 To 31
                cmbDayFr.Items.Add(iCtr)
                cmbDayTo.Items.Add(iCtr)
            Next iCtr
            cmbDayTo.SelectedValue = Now.Day
            cmbDayFr.SelectedValue = Now.AddDays(-15)
            For iCtr = 2000 To 2030
                cmbYrFr.Items.Add(iCtr)
                cmbYrTo.Items.Add(iCtr)
            Next iCtr
            cmbYrFr.SelectedValue = Now.Year
            cmbYrTo.SelectedValue = Now.Year
            cmbMonthFr.SelectedValue = Now.Month
            cmbMonthTo.SelectedValue = Now.Month
        Else
            If Me.cmbReport.SelectedValue = "6" Then
                Me.lblDays.Visible = True
                Me.txtDays.Visible = True
                rdoType.Visible = True
            Else
                Me.lblDays.Visible = False
                Me.txtDays.Visible = False
                rdoType.Visible = False
            End If
        End If
    End Sub
    Protected Sub cmdReturn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.Click
        Session.Remove("vHeader")
        Session.Remove("vPeriod")
        Session.Remove("vFilter")
        Server.Transfer("main.aspx")
    End Sub

    Private Sub DataRefresh(ByVal pLetter As String)
        Dim vFrom As String = cmbMonthFr.SelectedValue & "/" & cmbDayFr.SelectedValue & "/" & cmbYrFr.SelectedValue
        Dim vTo As String = cmbMonthTo.SelectedValue & "/" & cmbDayTo.SelectedValue & "/" & cmbYrTo.SelectedValue
        Dim vOrder As String = ""
        Dim vFilter As String = ""
        Dim vLtrFilter As String = ""

        Session.Remove("vHeader")
        Session.Remove("vPeriod")
        Session.Remove("vFilter")

        If Not IsDate(vFrom) Or Not IsDate(vTo) Then
            Exit Sub
        Else
            vFrom = CDate(vFrom)
            vTo = CDate(vTo)
        End If

        Select Case cmbSort.SelectedValue
            Case 0  'by name, by date
                'If Me.cmbReport.SelectedIndex = 0 Then
                vOrder = " order by Emp_Lname,Emp_Fname,TDate desc"
                'ElseIf Me.cmbReport.SelectedIndex = 1 Then
                'vOrder = " order by , Emp_Lname,Emp_Fname,Tran_Date desc"
                'End If
            Case 1  'by date, by name
                vOrder = " order by TDate desc,Emp_Lname,Emp_Fname"
            Case 2  'by Name, Department
                vOrder = " order by DeptName,Emp_Lname,Emp_Fname,TDate desc"
            Case 3
                vOrder = " order by DeptName,TDate desc,Emp_Lname,Emp_Fname"
        End Select

        vFilter = " And py_emp_master." & cmbType.SelectedValue & " like '" & pLetter & "%' "
        vLtrFilter = vFilter

        If cmbRC.SelectedValue <> "All" Then   'filter by cost center
            vFilter += " and py_emp_master.Rc_Cd='" & cmbRC.SelectedValue & "' "
            vLtrFilter += " and py_emp_master.Rc_Cd='" & cmbRC.SelectedValue & "' "
            Session("vFilter") += GetRef("SELECT Descr FROM rc WHERE Rc_Cd = '" & cmbRC.SelectedValue & "'", cmbRC.SelectedValue) & ", "
        Else
            vFilter += " and py_emp_master.Rc_Cd in ('" & Session("rclist").ToString.Replace(",", "','") & "') "
            vLtrFilter += " and py_emp_master.Rc_Cd in ('" & Session("rclist").ToString.Replace(",", "','") & "') "
        End If

        If cmbOfc.SelectedValue <> "All" Then        'filter by office/agency
            vFilter += " and py_emp_master.Agency_Cd='" & cmbOfc.SelectedValue & "' "
            vLtrFilter += " and py_emp_master.Agency_Cd='" & cmbOfc.SelectedValue & "' "
            Session("vFilter") += GetRef("SELECT AgencyName FROM agency WHERE AgencyCd = '" & cmbOfc.SelectedValue & "'", cmbOfc.SelectedValue) & ", "
        Else
            vFilter += " and py_emp_master.Agency_Cd in ('" & Session("agencylist").ToString.Replace(",", "','") & "') "
            vLtrFilter += " and py_emp_master.Agency_Cd in ('" & Session("agencylist").ToString.Replace(",", "','") & "') "
        End If
        If cmbDiv.SelectedValue <> "All" Then      'filter by division
            vFilter += " and py_emp_master.Divcd='" & cmbDiv.SelectedValue & "' "
            vLtrFilter += " and py_emp_master.Divcd='" & cmbDiv.SelectedValue & "' "
            Session("vFilter") += GetRef("SELECT Descr FROM hr_div_ref WHERE Div_Cd = '" & cmbDiv.SelectedValue & "'", cmbDiv.SelectedValue) & ", "
        Else
            vFilter += " and py_emp_master.DivCd in ('" & Session("divlist").ToString.Replace(",", "','") & "') "
            vLtrFilter += " and py_emp_master.DivCd in ('" & Session("divlist").ToString.Replace(",", "','") & "') "
        End If
        If cmbDept.SelectedValue <> "All" Then  'filter by departments
            vFilter += " and py_emp_master.DeptCd='" & cmbDept.SelectedValue & "' "
            vLtrFilter += " and py_emp_master.DeptCd='" & cmbDept.SelectedValue & "' "
            Session("vFilter") += GetRef("SELECT Descr FROM hr_dept_ref WHERE Dept_Cd = '" & cmbDept.SelectedValue & "'", cmbDept.SelectedValue) & ", "
        Else
            vFilter += " and py_emp_master.DeptCd in ('" & Session("deptlist").ToString.Replace(",", "','") & "') "
            vLtrFilter += " and py_emp_master.DeptCd in ('" & Session("deptlist").ToString.Replace(",", "','") & "') "
        End If
        If cmbSection.SelectedValue <> "All" Then 'filter by section
            vFilter += " and py_emp_master.SectionCd='" & cmbSection.SelectedValue & "' "
            vLtrFilter += " and py_emp_master.SectionCd='" & cmbSection.SelectedValue & "' "
            Session("vFilter") += GetRef("SELECT Descr FROM hr_section_ref WHERE Section_Cd = '" & cmbSection.SelectedValue & "'", cmbSection.SelectedValue) & ", "
        Else
            vFilter += " and py_emp_master.SectionCd in ('" & Session("sectionlist").ToString.Replace(",", "','") & "') "
            vLtrFilter += " and py_emp_master.SectionCd in ('" & Session("sectionlist").ToString.Replace(",", "','") & "') "
        End If

        If cmbUnit.SelectedValue <> "All" Then  'filter by units
            vFilter += " and py_emp_master.UnitCd='" & cmbUnit.SelectedValue & "' "
            vLtrFilter += " and py_emp_master.UnitCd='" & cmbUnit.SelectedValue & "' "
            Session("vFilter") += GetRef("SELECT Descr FROM hr_unit_ref WHERE Unit_Cd = '" & cmbUnit.SelectedValue & "'", cmbUnit.SelectedValue) & ", "
        Else
            vFilter += " and py_emp_master.UnitCd in ('" & Session("unitlist").ToString.Replace(",", "','") & "') "
            vLtrFilter += " and py_emp_master.UnitCd in ('" & Session("unitlist").ToString.Replace(",", "','") & "') "
        End If

        vFilter += " and EmploymentType in ('" & Session("typelist").ToString.Replace(",", "','") & "') "
        If Session("vFilter") <> "" Then
            Session("vFilter") = Session("vFilter").ToString.Substring(0, Session("vFilter").ToString.Length - 2)
        End If
        Session("vPeriod") = Format(CDate(vFrom), "MM/dd/yyyy") & " - " & Format(CDate(vTo), "MM/dd/yyyy")
        Session("vHeader") = "Exception Report - " & cmbReport.SelectedItem.ToString

        vOrder = vFilter & vOrder
        Select Case cmbReport.SelectedValue
            Case 0      'employees who are absent
                GetAbsent(vFrom, vTo, vOrder)
            Case 1      'employees w/o logout
                GetNoLogOut(vFrom, vTo, vOrder)
            Case 2      'employees with no schedules but with login
                GetNoSked(vFrom, vTo, vOrder)
            Case 3      'get active employees
                GetActiveEmp(vOrder)
            Case 4
                GetOrphanEmp(vOrder)
            Case 5, 7
                GetModified(vFrom, vTo, vOrder)
            Case 6
                GetLongLeave(vFrom, vTo, vFilter)
            Case 8
                GetLeaveWithOT(vFrom, vTo, vFilter)
            Case 9      'employee with modified schedule (approved)
                GetModifiedSched(vFrom, vTo, vOrder, "approved")
            Case 10     'employee with modified schedule (disapproved)
                GetModifiedSched(vFrom, vTo, vOrder, "disapproved")
            Case 11
                getlatefiled(vFrom, vTo, vFilter)
        End Select
        Session("vList") = vData
    End Sub
    Private Sub GetLateFiled(ByVal pFrom As Date, ByVal pTo As Date, ByVal pFilter As String)
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim vClass As String = "odd"
        Dim vDateRecommended As String = ""
        Dim vDateNoted As String = ""
        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        cm.Connection = c

        cm.CommandText = "select *,  " & _
            "(select Emp_Lname+', '+Emp_Fname from py_emp_master where py_emp_master.Emp_Cd=hr_leave_application.Emp_Cd) as EmpName, " & _
            "(select Emp_Lname+', '+Emp_Fname from py_emp_master where Emp_Cd=ApprovedBy) as ApprovedByName, " & _
            "(select Emp_Lname+', '+Emp_Fname from py_emp_master where Emp_Cd=RecommendedBy) as RecommendedByName, " & _
            "(select Emp_Lname+', '+Emp_Fname from py_emp_master where Emp_Cd=NotedBy) as NotedByName " & _
            "from hr_leave_application where Paid=1 and Void=0 and " & _
            "((ApprovedBy is Not null and DateApproved is Not null and RecommendedBy is null) or " & _
            "(ApprovedBy is Not null and DateApproved is not null and RecommendedBy is Not null and DateRecommended is Not null and NotedBy is null) or " & _
            "(ApprovedBy is Not null and DateApproved is Not null and RecommendedBy is Not null and DateRecommended is Not null and NotedBy is not null and DateNoted is Not null)) " & _
            "and EffectivityDate is not null and EffectivityDate between '" & cmbYrFr.SelectedValue & "/" & _
            cmbMonthFr.SelectedValue & "/" & cmbDayFr.SelectedValue & "' and '" & cmbYrTo.SelectedValue & "/" & _
            cmbMonthTo.SelectedValue & "/" & cmbDayTo.SelectedValue & "' order by EmpName"

        vData = "<table border='1' cellspacing='0' cellpadding='0' width='100%' style='border-collapse:collapse; border-color:#000000'>" & _
            "<tr class='titleBar'>" & _
            "<th>Date Filed</th>" & _
            "<th>Emp. Id</th>" & _
            "<th>Name of Employee</th>" & _
            "<th>Application Type</th>" & _
            "<th>Value</th>" & _
            "<th>UOM</th>" & _
            "<th>Start Date</th>" & _
            "<th>End Date</th>" & _
            "<th>Effectivity Date</th>" & _
            "<th>Reason</th>" & _
            "<th>Approved By</th>" & _
            "<th>Date Approved</th>" & _
            "<th>Recommended By</th>" & _
            "<th>Date Recommended</th>" & _
            "<th>Noted By</th>" & _
            "<th>Date Noted</th></tr>"

        Try
            rs = cm.ExecuteReader
            Do While rs.Read
                vDateNoted = "&nbsp;"
                vDateRecommended = "&nbsp;"
                If Not IsDBNull(rs("DateRecommended")) Then
                    vDateRecommended = Format(rs("DateRecommended"), "MM/dd/yyyy HH:mm")
                End If
                If Not IsDBNull(rs("DateNoted")) Then
                    vDateNoted = Format(rs("DateNoted"), "MM/dd/yyyy HH:mm")
                End If

                vData += "<tr class='" & vClass & "'>" & _
                    "<td class='labelR'>" & Format(rs("TranDate"), "MM/dd/yyyy HH:mm") & "</td>" & _
                    "<td class='labelL'>" & rs("Emp_Cd") & "</td>" & _
                    "<td class='labelL'>" & rs("EmpName") & "</td>" & _
                    "<td class='labelC'>" & rs("LeaveCd") & "</td>" & _
                    "<td class='labelR'>" & rs("DaysLeave") & "</td>" & _
                    "<td class='labelC'>Days</td>" & _
                    "<td class='labelR'>" & Format(rs("StartDate"), "MM/dd/yyyy") & "</td>" & _
                    "<td class='labelR'>" & Format(rs("EndDate"), "MM/dd/yyyy") & "</td>" & _
                    "<td class='labelR'>" & rs("EffectivityDate") & "</td>" & _
                    "<td class='labelL'>" & IIf(IsDBNull(rs("Reason")), "&nbsp;", rs("Reason")) & "</td>" & _
                    "<td class='labelL'>" & IIf(IsDBNull(rs("ApprovedByName")), "&nbsp;", rs("ApprovedByName")) & "</td>" & _
                    "<td class='labelR'>" & Format(rs("DateApproved"), "MM/dd/yyyy HH:mm") & "</td>" & _
                    "<td class='labelL'>" & IIf(IsDBNull(rs("RecommendedByName")), "&nbsp;", rs("RecommendedByName")) & "</td>" & _
                    "<td class='labelR'>" & vDateRecommended & "</td>" & _
                    "<td class='labelL'>" & IIf(IsDBNull(rs("NotedByName")), "&nbsp;", rs("NotedByName")) & "</td>" & _
                    "<td class='labelR'>" & vDateNoted & "</td></tr>"

                vClass = IIf(vClass = "odd", "even", "odd")
            Loop
            rs.Close()

            'now get late filed DTR correction
            cm.CommandText = "select *, " & _
                "(select Emp_Lname+', '+Emp_Fname from py_emp_master where Emp_Cd=ApprovedBy) as ApprovedByName " & _
                "from py_time_log  where EffectivityDate is not null and EffectivityDate between '" & _
                cmbYrFr.SelectedValue & "/" & cmbMonthFr.SelectedValue & "/" & cmbDayFr.SelectedValue & _
                "' and '" & cmbYrTo.SelectedValue & "/" & cmbMonthTo.SelectedValue & "/" & cmbDayTo.SelectedValue & _
                "' and ApprovedBy is not null and Date_Approved is not null"

            rs = cm.ExecuteReader
            Do While rs.Read
                vData += "<tr class='" & vClass & "'>" & _
                    "<td class='labelR'>" & Format(rs("DateFiled"), "MM/dd/yyyy HH:mm") & "</td>" & _
                    "<td class='labelL'>" & rs("Emp_Cd") & "</td>" & _
                    "<td class='labelL'>" & rs("Emp_Name") & "</td>" & _
                    "<td class='labelC'>DTR</td>" & _
                    "<td class='labelR' colspan='4'>" & rs("Time_In") & "-" & Format(rs("Time_OutDate"), "MM/dd/yyyy") & " " & rs("Time_Out") & "</td>" & _
                    "<td class='labelR'>" & rs("EffectivityDate") & "</td>" & _
                    "<td class='labelL'>" & IIf(IsDBNull(rs("Reason")), "&nbsp;", rs("Reason")) & "</td>" & _
                    "<td class='labelL'>" & IIf(IsDBNull(rs("ApprovedByName")), "&nbsp;", rs("ApprovedByName")) & "</td>" & _
                    "<td class='labelR'>" & Format(rs("Date_Approved"), "MM/dd/yyyy HH:mm") & "</td>" & _
                    "<td class='labelL'>&nbsp;</td>" & _
                    "<td class='labelR'>&nbsp;</td>" & _
                    "<td class='labelL'>&nbsp;</td>" & _
                    "<td class='labelR'>&nbsp;</td></tr>"

                vClass = IIf(vClass = "odd", "even", "odd")
            Loop
            rs.Close()

        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to retrieve record. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            c.Dispose()
            cm.Dispose()
        End Try
    End Sub
    Private Sub GetModifiedSched(ByVal pFrom As Date, ByVal pTo As Date, ByVal pOrder As String, ByVal pMode As String)
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        cm.Connection = c
        cm.CommandText = "select TransDate,Date_Sched,Start_Time,End_Time,Emp_Cd,(select Emp_Lname+', '+Emp_Fname as Name from py_emp_master " & _
            "where py_emp_master.Emp_Cd=py_emp_time_sched.Emp_Cd) as Name,ApprovedBy,DateApprove from py_emp_time_sched where Date_Sched between '" & _
            Format(pFrom, "yyyy/MM/dd") & "' and '" & Format(pTo, "yyyy/MM/dd") & _
            "' and ApprovedBy is not null  "
        Select Case pMode
            Case "approved"
                cm.CommandText += " and DateApprove is not null and Void=0 "
            Case "disapproved"
                cm.CommandText += " and DateApprove is not null and Void=1 "
        End Select
        cm.CommandText += " order by Name"

        Try
            rs = cm.ExecuteReader

            vData = "<table border='1' cellspacing='0' cellpadding='0' width='100%' style='border-collapse:collapse; border-color:#000000'>" & _
                    "<tr class='titleBar'>" & _
                    "<th>Schedule Date</th>" & _
                    "<th>Date Filed</th>" & _
                    "<th>Emp. Id</th>" & _
                    "<th>Name of Employee</th>" & _
                    "<th>To Be Approved By</th>" & _
                    "<th>Date " & IIf(pMode = "approved", "Approved", "Disapproved") & "</th></tr>"

            Dim vClass As String = "odd"
            Do While rs.Read
                vData += "<tr class='" & vClass & "'>"
                vData += "<td class='labelC' style='widht:100px;'>" & IIf(IsDBNull(rs("Date_Sched")), "", Format(rs("Date_Sched"), "MM/dd/yyyy")) & "</td>"
                vData += "<td class='labelC' style='widht:100px;'>"
                If Not IsDBNull(rs("TransDate")) Then
                    vData += Format(CDate(rs("TransDate")), "MM/dd/yyyy")
                Else
                    vData += "&nbsp;"
                End If

                vData += "</td>"
                vData += "<td class='labelL' style='widht:100px;'>" & rs("Emp_Cd") & "</td>"
                vData += "<td class='labelL' width='20%'>" & rs("Name") & "</td>"

                vData += "<td class='labelL'>" & rs("ApprovedBy") & " => " & GetName(rs("ApprovedBy")) & "</td>"
                vData += "<td class='labelL'>" & Format(rs("DateApprove"), "MM/dd/yyyy") & "</td>"

                vData += "</tr>"

                vClass = IIf(vClass = "odd", "even", "odd")
            Loop

            vData += "</table>"
            rs.Close()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to retrieve schedule records. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            cm.Dispose()
            c.Dispose()
        End Try
    End Sub
    Private Sub cmdA_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdA.Click, _
    cmdB.Click, cmdC.Click, cmdD.Click, cmdE.Click, cmdF.Click, cmdG.Click, cmdH.Click, cmdI.Click, _
    cmdJ.Click, cmdK.Click, cmdL.Click, cmdM.Click, cmdN.Click, cmdO.Click, cmdP.Click, cmdQ.Click, _
    cmdR.Click, cmdS.Click, cmdT.Click, cmdU.Click, cmdV.Click, cmdW.Click, cmdX.Click, cmdY.Click, cmdZ.Click
        Session("letter") = CType(sender, LinkButton).Text
        DataRefresh(Session("letter"))
    End Sub
    Private Sub GetOrphanEmp(ByVal pOrder As String)
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cmRef As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim rsRef As SqlClient.SqlDataReader
        Dim vName As String
        Dim vSupName As String
        Dim vRc As String
        Dim vOfc As String
        Dim vDiv As String
        Dim vUnit As String
        Dim vSection As String
        Dim vDept As String
        Dim vWithSked As Boolean = False

        c.Open()
        cm.Connection = c
        cmRef.Connection = c
        cm.CommandText = "select Emp_Cd,Emp_Lname,Emp_Fname,SupervisorCd,DeptCd,SectionCd," & _
            "Rc_Cd,Agency_Cd,DivCd,UnitCd from py_emp_master where Date_Resign is null AND Date_Retired IS NULL AND DateHold IS NULL AND DateDismissed IS NULL " & _
            "and (SupervisorCd is null or SupervisorCd='') order by Emp_Lname,Emp_Fname,Emp_Mname"
        rs = cm.ExecuteReader
        vData = "<table border='1' cellspacing='0' cellpadding='0' width='100%' style='border-collapse:collapse'><tr class='odd'>" & _
            "<th>Emp. Id</th><th>Name of Employee</th>" & _
            "<th>Immediate Superior</th>" & _
            "<th>Department</th><th>Section</th></tr>"

        Dim vClass As String = "even"
        Do While rs.Read
            vSupName = IIf(IsDBNull(rs("SupervisorCd")), "", rs("SupervisorCd"))
            vName = rs("Emp_Lname") & ", " & rs("Emp_Fname")
            vRc = IIf(IsDBNull(rs("Rc_Cd")), "", rs("Rc_Cd"))
            vOfc = IIf(IsDBNull(rs("Agency_Cd")), "", rs("Agency_Cd"))
            vDiv = IIf(IsDBNull(rs("DivCd")), "", rs("DivCd"))
            vDept = IIf(IsDBNull(rs("DeptCd")), "", rs("DeptCd"))
            vSection = IIf(IsDBNull(rs("SectionCd")), "", rs("SectionCd"))
            vUnit = IIf(IsDBNull(rs("UnitCd")), "", rs("UnitCd"))
            cmRef.CommandText = "select Emp_Lname,Emp_Fname from py_emp_master where " & _
                "Emp_Cd='" & vSupName & "'"
            rsRef = cmRef.ExecuteReader
            If rsRef.Read Then
                vSupName = rsRef("Emp_Lname") & ", " & rsRef("Emp_Fname")
            End If
            rsRef.Close()
            'vRc = GetRef("select Descr from rc where Rc_Cd='" & vRc & "'", vRc)
            'vOfc = GetRef("select AgencyName from agency where AgencyCd='" & _
            '    vOfc & "'", vOfc)
            'vDiv = GetRef("select Descr from hr_div_ref where Div_Cd='" & _
            '    vDiv & "'", vDiv)
            vSection = GetRef("select Descr from hr_section_ref where Section_Cd='" & _
                vSection & "'", vSection)
            vDept = GetRef("select Descr from hr_dept_ref where Dept_Cd='" & _
                vDept & "'", vDept)
            'vUnit = GetRef("select Unit_Cd from hr_unit_ref where Unit_Cd='" & _
            '    vUnit & "'", vUnit)
            vData += "<tr class='" & vClass & "'><td align='left'>" & rs("Emp_Cd") & "</td>" & _
                "<td align='left'>" & vName & "</td>" & _
                "<td align='left'>" & vSupName & "</td>" & _
                "<td align='left'>" & vDept & "</td>" & _
                "<td align='left'>" & vSection & "</td></tr>"
            If vClass = "even" Then
                vClass = "odd"
            Else
                vClass = "even"
            End If
        Loop
        vData += "</table>"
        rs.Close()
        c.Close()
        cm.Dispose()
        cmRef.Dispose()
        c.Dispose()
    End Sub
    Private Sub GetLongLeave(ByVal vFrom As Date, ByVal vTo As Date, ByVal vfilter As String)
        If Not IsNumeric(txtDays.Text) And txtDays.Text <> "0" Then
            vScript = "alert('Please input valid day(s).');"
            Exit Sub
        End If
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim vDays As Decimal = txtDays.Text
        Dim vDaysLeave As Decimal = 0
        Dim vAppNoEmp As String = ""
        Dim vType As String = rdoType.SelectedValue
        Dim vFilterType As String = ""
        Dim vAppNo As String = ""

        Select Case vType
            Case "Paid"
                vFilterType = "AND Paid='1'"
            Case "Unpaid"
                vFilterType = "AND Paid='0'"
        End Select

        c.Open()
        cm.Connection = c
        cm.CommandText = "SELECT DISTINCT ApplicationNo, COUNT(ApplicationNo) AS DaysL " & _
            "FROM hr_leave_application WHERE LeaveCd IN (SELECT Leave_Cd FROM py_leave_ref WHERE Leave_Cd NOT IN ('SUSP','UT')) " & _
            "AND Void=0 AND CAST(TranDate AS DATE) >= '" & Format(vFrom, "yyyy/MM/dd") & _
            "' AND CAST(TranDate AS DATE) <= '" & Format(vTo, "yyyy/MM/dd") & "' AND DateApproved IS NOT NULL " & _
            "GROUP BY ApplicationNo"
        rs = cm.ExecuteReader
        Do While rs.Read
            If rs(1) >= vDays Then
                vAppNo += rs(0) & "','"
            End If
        Loop
        rs.Close()

        If vAppNo <> "" Then
            vAppNo = vAppNo.Substring(0, vAppNo.Length.ToString - 3)
        End If

        cm.CommandText = "SELECT hr_leave_application.LeaveCd,hr_leave_application.ApplicationNo,hr_leave_application.Emp_Cd,hr_leave_application.DaysLeave," & _
                         "hr_leave_application.StartDate AS TDate,hr_leave_application.EndDate,hr_leave_application.ApprovedBy,hr_leave_application.DateApproved " & _
                         "FROM hr_leave_application,py_emp_master WHERE ApplicationNo IN ('" & vAppNo & "') " & vfilter & _
                         "GROUP BY hr_leave_application.LeaveCd,hr_leave_application.Emp_Cd,hr_leave_application.DaysLeave,hr_leave_application.StartDate," & _
                         "hr_leave_application.EndDate,hr_leave_application.ApprovedBy,hr_leave_application.DateApproved,hr_leave_application.ApplicationNo ORDER BY ApplicationNo ASC"
        rs = cm.ExecuteReader

        vData = "<table border='1' cellspacing='0' cellpadding='0' width='100%' style='border-collapse:collapse'><tr class='titleBar'>" & _
                "<td><b>Emp. ID</b></td><td><b>Name of Employee</b></td>" & _
                "<td><b>Leave Type</b></td><td><b>Days Leave</b></td>" & _
                "<td><b>Application No.</b></td><td><b>Start Date<b></td><td><b>End Date</b></td><td><b>Approved By</b></td><td><b>Date Approved</b></td></tr>"
        Dim vClass As String = "even"
        Do While rs.Read
            If vAppNoEmp = "" Then
                vAppNoEmp = rs("ApplicationNo")
                vDaysLeave = 0
            End If

            If vAppNoEmp <> rs("ApplicationNo") Then
                vData += "<tr style='background-color:#FFFF99;'><td align='center' colspan='3'><b>TOTAL DAYS<b/></td><td align='right'><b>"
                vData += Format(Math.Round(vDaysLeave, 2), "#0.00") & "</b></td><td colspan='5'></td>"
                vData += "</tr>"
                vAppNoEmp = rs("ApplicationNo")
                vDaysLeave = 0
            End If

            vDaysLeave += rs("DaysLeave")
            vData += "<tr class='" & vClass & "'>"
            vData += "<td>" & rs("Emp_Cd") & "</td>"
            vData += "<td>" & GetName(rs("Emp_Cd")) & "</td>"
            vData += "<td>" & rs("LeaveCd") & "</td>"
            vData += "<td style='text-align:right'>" & Format(Math.Round(rs("DaysLeave"), 2), "#0.00") & "</td>"
            vData += "<td>" & rs("ApplicationNo") & "</td>"
            vData += "<td style='text-align:right'>" & Format(rs("TDate"), "yyyy/MM/dd") & "</td>"
            vData += "<td style='text-align:right'>" & Format(rs("EndDate"), "yyyy/MM/dd") & "</td>"
            vData += "<td style='text-align:left'>" & rs("ApprovedBy") & "=>" & GetName(rs("ApprovedBy")) & "</td>"
            vData += "<td style='text-align:right'>" & Format(rs("DateApproved"), "yyyy/MM/dd") & "</td>"
            vData += "</tr>"


            If vClass = "even" Then
                vClass = "odd"
            Else
                vClass = "even"
            End If
        Loop

        vData += "<tr style='background-color:#FFFF99;'><td align='center' colspan='3'><b>TOTAL DAYS<b/></td><td align='right'><b>"
        vData += Format(Math.Round(vDaysLeave, 2), "#0.00") & "</b></td><td colspan='5'></td>"
        vData += "</tr>"

        rs.Close()

        vData += "</table>"
        c.Close()
        c.Dispose()
        cm.Dispose()
    End Sub
    Private Sub GetActiveEmp(ByVal pOrder As String)
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cmRef As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim rsRef As SqlClient.SqlDataReader
        Dim vName As String
        Dim vSupName As String
        Dim vRc As String
        Dim vOfc As String
        Dim vDiv As String
        Dim vUnit As String
        Dim vSection As String
        Dim vDept As String
        Dim vWithSked As Boolean = False

        c.Open()
        cm.Connection = c
        cmRef.Connection = c
        cm.CommandText = "select Emp_Cd,BarcodeId,Emp_Lname,Emp_Fname,SupervisorCd,DeptCd,SectionCd," & _
            "Rc_Cd,Agency_Cd,DivCd,UnitCd,GetDate() AS TDate,(select Descr from hr_dept_ref where Dept_Cd=DeptCd) as DeptName " & _
            "from py_emp_master where Date_Resign is null " & pOrder

        rs = cm.ExecuteReader
        
        vData = "<table border='1' cellspacing='0' cellpadding='0' style='width:100%'style='border-collapse:collapse;'><tr class='titleBar'>" & _
            "<td><b>Emp. ID</b></td><td><b>Barcode ID</b></td><td><b>Name of Employee</b></td>" & _
            "<td><b>Immediate Superior</b></td>" & _
            "<td><b>Department</b></td><td><b>Section</b></td></tr>"
        Dim vClass As String = "even"
        Do While rs.Read
            vSupName = IIf(IsDBNull(rs("SupervisorCd")), "", rs("SupervisorCd"))
            vName = rs("Emp_Lname") & ", " & rs("Emp_Fname")
            vRc = IIf(IsDBNull(rs("Rc_Cd")), "", rs("Rc_Cd"))
            vOfc = IIf(IsDBNull(rs("Agency_Cd")), "", rs("Agency_Cd"))
            vDiv = IIf(IsDBNull(rs("DivCd")), "", rs("DivCd"))
            vDept = IIf(IsDBNull(rs("DeptCd")), "", rs("DeptCd"))
            vSection = IIf(IsDBNull(rs("SectionCd")), "", rs("SectionCd"))
            vUnit = IIf(IsDBNull(rs("UnitCd")), "", rs("UnitCd"))
            cmRef.CommandText = "select Emp_Lname,Emp_Fname from py_emp_master where " & _
                "Emp_Cd='" & vSupName & "'"
            rsRef = cmRef.ExecuteReader
            If rsRef.Read Then
                vSupName = rsRef("Emp_Lname") & ", " & rsRef("Emp_Fname")
            End If
            rsRef.Close()
            'vRc = GetRef("select Descr from rc where Rc_Cd='" & vRc & "'", vRc)
            'vOfc = GetRef("select AgencyName from agency where AgencyCd='" & _
            '    vOfc & "'", vOfc)
            'vDiv = GetRef("select Descr from hr_div_ref where Div_Cd='" & _
            '    vDiv & "'", vDiv)
            vSection = GetRef("select Descr from hr_section_ref where Section_Cd='" & _
                vSection & "'", vSection)
            vDept = GetRef("select Descr from hr_dept_ref where Dept_Cd='" & _
                vDept & "'", vDept)
            'vUnit = GetRef("select Unit_Cd from hr_unit_ref where Unit_Cd='" & _
            '    vUnit & "'", vUnit)
            vData += "<tr class='" & vClass & "'><td class='labelC'>" & rs("Emp_Cd") & "</td>" & _
                "<td class='lableC'>" & IIf(IsDBNull(rs("BarcodeId")), "", rs("BarcodeId")) & "</td>" & _
                "<td class='labelL'>" & vName & "</td>" & _
                "<td class='labelL'>" & vSupName & "</td>" & _
                "<td class='labelL'>" & vDept & "</td>" & _
                "<td class='labelL'>" & vSection & "</td></tr>"
            If vClass = "even" Then
                vClass = "odd"
            Else
                vClass = "even"
            End If
        Loop
        vData += "</table>"
        rs.Close()
        c.Close()
        c.Dispose()
        cm.Dispose()
        cmRef.Dispose()
    End Sub
    Private Sub GetModified(ByVal pFrom As Date, ByVal pTo As Date, ByVal pOrder As String)
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader

        c.Open()
        cm.Connection = c
        If cmbReport.SelectedValue = 5 Then
            cm.CommandText = "SELECT Tran_Date as TDate,DateFiled, py_time_log.Emp_Cd, Emp_Lname,Emp_Fname,ApprovedBy, Date_Approved," & _
                            "(select Descr from hr_dept_ref where Dept_Cd=py_emp_master.DeptCd) as DeptName " & _
                            "FROM py_time_log,py_emp_master " & _
                "WHERE py_time_log.Emp_Cd=py_emp_master.Emp_Cd and Date_Approved IS NOT NULL" & _
                             " AND ApprovedBy IS NOT NULL and ApprovedBy <> '' AND Tran_Date >= '" & pFrom & "' AND Tran_Date <= '" & pTo & _
                             "' " & pOrder
        Else
            cm.CommandText = "SELECT Tran_Date as TDate,DateFiled, py_time_log.Emp_Cd, Emp_Lname,Emp_Fname,ApprovedBy, Date_Approved,Reason, Remarks,DateDisApproved," & _
            "(select Descr from hr_dept_ref where Dept_Cd=py_emp_master.DeptCd) as DeptName " & _
            "FROM py_time_log,py_emp_master " & _
            "WHERE py_time_log.Emp_Cd=py_emp_master.Emp_Cd and Date_Approved IS NULL" & _
                         " AND CorrectionTimeIn IS NOT NULL AND ApprovedBy IS NULL AND Tran_Date >= '" & pFrom & "' AND Tran_Date <= '" & pTo & _
                         "' " & pOrder
        End If
        rs = cm.ExecuteReader

        vData = "<table border='1' cellspacing='0' cellpadding='0' width='100%' style='border-collapse:collapse; border-color:#000000'><tr class='titleBar'>" & _
                   "<th><b>Modified Date</th><th><b>Date Filed</b></th><th><b>Emp. ID</b></th><th><b>Name of Employee</b></th>" & _
                   IIf(cmbReport.SelectedValue = 5, "<th><b>To Be Approved By</b></th><th><b>Date Approved</b></th>", "<th><b>Date Disapproved</b></th><th><b>Reason</b></th><th><b>Remarks</b></th>") & "</tr>"

        Dim vClass As String = "even"
        Do While rs.Read

            vData += "<tr class='" & vClass & "'>"
            vData += "<td class='labelC' style='widht:100px;'>" & IIf(IsDBNull(rs(0)), "", Format(rs(0), "MM/dd/yyyy")) & "</td>"
            vData += "<td class='labelC' style='widht:100px;'>"
            If Not IsDBNull(rs(1)) Then vData += Format(rs(1), "MM/dd/yyyy")
            vData += "</td>"
            vData += "<td class='labelL' style='widht:100px;'>" & IIf(IsDBNull(rs(2)), "", rs(2)) & "</td>"
            vData += "<td class='labelL' width='20%'>" & rs("Emp_Lname") & ", " & rs("Emp_Fname") & "</td>"

            If cmbReport.SelectedValue = 5 Then
                vData += "<td class='labelL'>" & rs("ApprovedBy") & " => " & GetName(rs("ApprovedBy")) & "</td>"
                vData += "<td class='labelL'>" & Format(rs("Date_Approved"), "MM/dd/yyyy") & "</td>"
            Else
                vData += "<td class='labelL'>" & IIf(IsDBNull(rs("DateDisApproved")), "", rs("DateDisApproved")) & "</td>"
                vData += "<td class='labelL'>" & IIf(IsDBNull(rs("Reason")), "", rs("Reason")) & "</td>"
                vData += "<td class='labelL'>" & IIf(IsDBNull(rs("Remarks")), "", rs("Remarks")) & "</td>"
            End If
            vData += "</tr>"

            If vClass = "even" Then
                vClass = "odd"
            Else
                vClass = "even"
            End If
        Loop

        vData += "</table>"
        rs.Close()
        c.Close()
        cm.Dispose()
        c.Dispose()
    End Sub
    Private Sub GetNoSked(ByVal pFrom As Date, ByVal pTo As Date, ByVal pOrder As String)
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cmRef As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim rsRef As SqlClient.SqlDataReader
        Dim vName As String
        Dim vSupName As String
        Dim vSection As String
        Dim vDept As String
        Dim vWithSked As Boolean = False
        'Dim vCnt As Integer = 0
        c.Open()
        cm.Connection = c
        cmRef.Connection = c
        cm.CommandText = "select py_time_log.Emp_Cd,Tran_Date AS TDate,Time_In,Emp_Lname,Emp_Fname," & _
                         "(select Descr from hr_dept_ref where Dept_Cd=py_emp_master.DeptCd) as DeptName " & _
                        "from py_time_log,py_emp_master where " & _
            "Time_In is not null and Tran_Date between '" & _
            Format(pFrom, "yyyy/MM/dd") & "' and '" & Format(pTo, "yyyy/MM/dd") & _
            "' and py_time_log.Emp_Cd=py_emp_master.Emp_cd " & pOrder
        rs = cm.ExecuteReader
        vData = "<table border='1' cellspacing='0' cellpadding='0' width='100%' style='border-collapse:collapse'><tr class='titleBar'>" & _
            "<td><b>Date</td><td><b>Log In</td><td><b>Emp. ID</td><td><b>Name of Employee</td>" & _
            "<td><b>Immediate Superior<b></td><td><b>Department</td><td><b>Section</td></tr>"

        Dim vClass As String = "even"
        Do While rs.Read
            vCnt += 1

            'check if no schedule
            cmRef.CommandText = "select Start_Time from py_emp_time_sched where Date_Sched='" & _
                Format(rs("TDate"), "yyyy/MM/dd") & "' and Emp_Cd='" & rs("Emp_Cd") & "'"
            rsRef = cmRef.ExecuteReader
            vWithSked = False
            If rsRef.Read Then  'with sched
                'vWithSked = IIf(IsDBNull(rsRef("Start_Time")), False, True)
                vWithSked = True
            End If
            rsRef.Close()
            If Not vWithSked Then
                cmRef.CommandText = "select Emp_Lname,Emp_Fname,SupervisorCd,Emp_Cd,DeptCd,SectionCd " & _
                    "from py_emp_master where " & "Emp_Cd='" & rs("Emp_Cd") & "'"
                rsRef = cmRef.ExecuteReader
                rsRef.Read()
                vSupName = IIf(IsDBNull(rsRef("SupervisorCd")), "", rsRef("SupervisorCd"))
                vName = rsRef("Emp_Lname") & ", " & rsRef("Emp_Fname")
                vSection = IIf(IsDBNull(rsRef("SectionCd")), "", rsRef("SectionCd"))
                vDept = IIf(IsDBNull(rsRef("DeptCd")), "", rsRef("DeptCd"))
                rsRef.Close()
                cmRef.CommandText = "select Emp_Lname,Emp_Fname from py_emp_master where " & _
                    "Emp_Cd='" & vSupName & "'"
                rsRef = cmRef.ExecuteReader
                If rsRef.Read Then
                    vSupName = rsRef("Emp_Lname") & ", " & rsRef("Emp_Fname")
                End If
                rsRef.Close()
                vSection = GetRef("select Descr from hr_section_ref where Section_Cd='" & _
                vSection & "'", vSection)
                vDept = GetRef("select Descr from hr_dept_ref where Dept_Cd='" & _
                    vDept & "'", vDept)

                If vEmpID <> rs("Emp_Cd") Then
                    vData += "<tr><td style='padding: 4px; color: #000000; background-color: #cccccc' colspan='7'>" & _
                    " Total of No Schedules : " & vCnt & "</td></tr>"
                    vEmpID = rs("Emp_Cd")
                    vCnt = 0
                End If

                vData += "<tr class='" & vClass & "'><td>" & Format(rs("TDate"), "MM/dd/yyyy") & "</td>" & _
                    "<td class='labelC'>" & rs("Time_In") & "</td>" & _
                    "<td class='labelC'>" & rs("Emp_Cd") & "</td>" & _
                    "<td class='labelL'>" & vName & "</td>" & _
                    "<td class='labelL'>" & vSupName & "</td>" & _
                    "<td class='labelL'>" & vDept & "</td>" & _
                    "<td class='labelL'>" & vSection & "</td></tr>"
            End If
            If vClass = "even" Then
                vClass = "odd"
            Else
                vClass = "even"
            End If
        Loop
        vData += "</table>"
        rs.Close()
        c.Close()
        c.Dispose()
        cm.Dispose()
        cmRef.Dispose()
    End Sub
    Private Sub GetAbsent(ByVal pFrom As Date, ByVal pTo As Date, ByVal pOrder As String)
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cmRef As New SqlClient.SqlCommand

        Dim rs As SqlClient.SqlDataReader
        Dim rsRef As SqlClient.SqlDataReader

        Dim vName As String
        Dim vSupName As String
        Dim vSection As String
        Dim vDept As String

        c.Open()
        cm.Connection = c
        cmRef.Connection = c

        '''''''''''''''''''''''''''''''''''OLD CODE''''''''''''''''''''''''''''''''''
        'cm.CommandText = "select py_time_log_dtl.Emp_Cd,TranDate AS TDate,Emp_Lname,Emp_Fname from py_time_log_dtl,py_emp_master where TranCd = 'ABSENT' AND LateFiled=0 and TranDate between '" & _
        '    Format(pFrom, "yyyy/MM/dd") & "' and '" & Format(pTo, "yyyy/MM/dd") & _
        '    "' and py_time_log_dtl.Emp_Cd=py_emp_master.Emp_cd " & pOrder
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        ''''Modified by:    Rudner Diaz, Jr.                                       ''
        ''''Date       :    To change the look up to py_time_log                   ''
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        cm.CommandText = "select py_time_log.Emp_Cd,Tran_Date as TDATE," & _
                         "(select Descr from hr_dept_ref where Dept_Cd=py_emp_master.DeptCd) as DeptName " & _
                         "from py_time_log,py_emp_master where Time_In is null and Time_Out is null " & _
                         "and Sched_In is not null and Tran_Date between '" & Format(pFrom, "yyyy/MM/dd") & "' and '" & Format(pTo, "yyyy/MM/dd") & _
                         "' and not exists (select Holy_Date from py_holiday where Holy_Date=Tran_Date) " & _
                         "and not exists (select Emp_Cd from hr_leave_application where hr_leave_application.Emp_Cd=py_time_log.Emp_Cd and " & _
                         "Tran_Date between StartDate and EndDate and Paid=1 and Void=0 and " & _
                         "((ApprovedBy is Not null and DateApproved is not null and RecommendedBy is null) or " & _
                         "(ApprovedBy is Not null and DateApproved is not null and RecommendedBy is Not null " & _
                         "and DateRecommended is Not null and NotedBy is null) or " & _
                         "(ApprovedBy is Not null and DateApproved is Not null and RecommendedBy is Not null " & _
                         "and DateRecommended is not null and NotedBy is Not null and DateNoted is Not null))) " & _
                         "and py_time_log.Emp_Cd=py_emp_master.Emp_Cd " & _
                         pOrder
        'Response.Write(cm.CommandText)

        rs = cm.ExecuteReader

        vData = "<table style='width: 100%; border-collapse:collapse; border: solid 0px #8b8b8a;'>" & _
            "<tr class='titleBar'>" & _
            "<td><b>Date</b></td>" & _
            "<td><b>Emp. Id</b></td>" & _
            "<td><b>Name of Employee</b></td>" & _
            "<td><b>Immediate Superior</b></td>" & _
            "<td><b>Department</b></td>" & _
            "<td><b>Section</b></td></tr>"

        Dim vClass As String = "even"

        Do While rs.Read

            vCnt += 1
            If vEmpID = "" Then vEmpID = rs("Emp_Cd")
            cmRef.CommandText = "select Emp_Lname,Emp_Fname,SupervisorCd,Emp_Cd,DeptCd,SectionCd " & _
                "from py_emp_master where " & "Emp_Cd='" & rs("Emp_Cd") & "'"
            rsRef = cmRef.ExecuteReader
            rsRef.Read()
            vSupName = IIf(IsDBNull(rsRef("SupervisorCd")), "", rsRef("SupervisorCd"))

            vName = rsRef("Emp_Lname") & ", " & rsRef("Emp_Fname")
            vSection = IIf(IsDBNull(rsRef("SectionCd")), "", rsRef("SectionCd"))
            vDept = IIf(IsDBNull(rsRef("DeptCd")), "", rsRef("DeptCd"))

            rsRef.Close()

            cmRef.CommandText = "select Emp_Lname,Emp_Fname from py_emp_master where " & _
                "Emp_Cd='" & vSupName & "'"
            rsRef = cmRef.ExecuteReader

            If rsRef.Read Then
                vSupName = rsRef("Emp_Lname") & ", " & rsRef("Emp_Fname")
            End If
            rsRef.Close()

            vDept = GetRef("select Descr from hr_dept_ref where Dept_Cd='" & _
                vDept & "'", vDept)
            vSection = GetRef("select Descr from hr_section_ref where Section_Cd='" & _
                vSection & "'", vSection)

            If vEmpID <> rs("Emp_Cd") Then
                vData += "<tr><td style='padding: 4px; color: #000000; border-top: solid 1px #999999; background-color: #cccccc' colspan='6'>" & _
                " Total Absences of " & vEmpID & " : " & vCnt & " " & IIf(vCnt = 1, "day", "days") & " </td></tr>"
                vEmpID = rs("Emp_Cd")
                vCnt = 0
            End If

            vData += "<tr class='" & vClass & "'><td class='labelC'>" & Format(rs("TDate"), "MM/dd/yyyy") & "</td>" & _
                "<td class='labelC'>" & rs("Emp_Cd") & "</td>" & _
                "<td align='labelL'>" & vName & "</td>" & _
                "<td align='labelL'>" & vSupName & "</td>" & _
                "<td align='labelL'>" & vDept & "</td>" & _
                "<td align='labelL'>" & vSection & "</td></tr>"

            If vClass = "even" Then
                vClass = "odd"
            Else
                vClass = "even"
            End If


            'Response.Write(vEmpID)


            'set EmpID as string = ""
            'if empId is not != ""
            'total count ng adsent per employee start here..

        Loop
        If vCnt > -1 Then
            vCnt += 1
            vData += "<tr><td style='padding: 4px; color: #000000; border-top: solid 1px #999999; background-color: #cccccc' colspan='6'>" & _
               " Total Absences of " & vEmpID & " : " & vCnt & " " & IIf(vCnt = 1, "day", "days") & " </td></tr></table>"
        End If


        rs.Close()
        c.Close()
        c.Dispose()
        cm.Dispose()
        cmRef.Dispose()
    End Sub
    Private Sub GetNoLogOut(ByVal pFrom As Date, ByVal pTo As Date, ByVal pOrder As String)
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cmRef As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim rsRef As SqlClient.SqlDataReader
        Dim vName As String
        Dim vSupName As String
        Dim vSection As String
        Dim vDept As String
        Dim vCandidate As Boolean = True

        c.Open()
        cm.Connection = c
        cmRef.Connection = c
        cm.CommandText = "select py_time_log.Emp_Cd,Tran_Date AS TDate,Time_In,Time_Out,Emp_Lname,Emp_Fname," & _
            "(select Descr from hr_dept_ref where Dept_Cd=DeptCd) as DeptName " & _
            "from py_time_log,py_emp_master where " & _
            "(Time_In is null or Time_Out is null) and Sched_In is not null and Tran_Date between '" & _
            Format(pFrom, "yyyy/MM/dd") & "' and '" & Format(pTo, "yyyy/MM/dd") & _
            "' and py_time_log.Emp_Cd=py_emp_master.Emp_cd " & pOrder

        rs = cm.ExecuteReader

        vData = "<table border='1' cellspacing='0' cellpadding='0' width='100%' style='border-collapse:collapse'><tr class='titleBar'>" & _
            "<th>Date</th><th>Log In</th><th>Log Out</th><th>Emp. ID</th><th>Name of Employee</th>" & _
            "<th>Immediate Superior</th><th>Department</th><th>Section</th></tr>"

        Dim vClass As String = "even"
        Do While rs.Read
            vCnt += 1
            'check in detail if it has a filed leave or OB
            cmRef.CommandText = "select 1 from py_time_log_dtl where Emp_Cd='" & _
                rs("Emp_Cd") & "' and TranDate='" & Format(CDate(rs("TDate")), "yyyy/MM/dd") & _
                "' and TranCd in (select Leave_Cd from py_leave_ref) "
            rsRef = cmRef.ExecuteReader
            vCandidate = True
            If rsRef.Read Then  'no filed leave, ddisplay the record
                vCandidate = False
            End If
            rsRef.Close()

            If vCandidate Then
                'check if holiday
                cmRef.CommandText = "select 1 from py_holiday where Holy_Date='" & Format(CDate(rs("TDate")), "yyyy/MM/dd") & "'"
                rsRef = cmRef.ExecuteReader
                If rsRef.Read Then
                    vCandidate = False
                End If
                rsRef.Close()
            End If

            If vCandidate Then
                cmRef.CommandText = "select Emp_Lname,Emp_Fname,SupervisorCd,Emp_Cd,DeptCd,SectionCd,Allow_Req_Hrs " & _
                    "from py_emp_master where " & "Emp_Cd='" & rs("Emp_Cd") & "'"
                rsRef = cmRef.ExecuteReader
                rsRef.Read()
                If rsRef("Allow_Req_Hrs") = 1 Then
                    vSupName = IIf(IsDBNull(rsRef("SupervisorCd")), "", rsRef("SupervisorCd"))
                    vName = rsRef("Emp_Lname") & ", " & rsRef("Emp_Fname")
                    vSection = IIf(IsDBNull(rsRef("SectionCd")), "", rsRef("SectionCd"))
                    vDept = IIf(IsDBNull(rsRef("DeptCd")), "", rsRef("DeptCd"))
                    rsRef.Close()
                    cmRef.CommandText = "select Emp_Lname,Emp_Fname from py_emp_master where " & _
                        "Emp_Cd='" & vSupName & "'"
                    rsRef = cmRef.ExecuteReader
                    If rsRef.Read Then
                        vSupName = rsRef("Emp_Lname") & ", " & rsRef("Emp_Fname")
                    End If
                    rsRef.Close()
                    vSection = GetRef("select Descr from hr_section_ref where Section_Cd='" & _
                        vSection & "'", vSection, c)
                    vDept = GetRef("select Descr from hr_dept_ref where Dept_Cd='" & _
                        vDept & "'", vDept, c)

                    If vEmpID <> rs("Emp_Cd") Then
                        vData += "<tr><td style='padding: 4px; color: #000000; background-color: #cccccc' colspan='8'>" & _
                        " Incomplete Logs Total : " & vCnt & IIf(vCnt >= 1, "day", "days") & " Days</td><td>&nbsp;</td><td>&nbsp;</td></tr>"
                        vEmpID = rs("Emp_Cd")
                        vCnt = 0
                    End If

                    vData += "<tr class='" & vClass & "'><td>" & Format(rs("TDate"), "MM/dd/yyyy") & "</td>" & _
                        "<td class='labelC'>" & IIf(IsDBNull(rs("Time_In")), "&nbsp;", rs("Time_In")) & "</td>" & _
                        "<td class='labelC'>" & IIf(IsDBNull(rs("Time_Out")), "&nbsp;", rs("Time_Out")) & "</td>" & _
                        "<td class='labelC'>" & rs("Emp_Cd") & "</td>" & _
                        "<td class='labelC'>" & vName & "</td>" & _
                        "<td class='labelL'>" & vSupName & "</td>" & _
                        "<td class='labelL'>" & vDept & "</td>" & _
                        "<td class='labelL'>" & vSection & "</td></tr>"

                    vClass = IIf(vClass = "odd", "even", "odd")
                Else
                    rsRef.Close()
                End If
            End If
        Loop
        vData += "</table>"
        rs.Close()
        c.Close()
        c.Dispose()
        cm.Dispose()
        cmRef.Dispose()
    End Sub

    Private Sub GetLeaveWithOT(ByVal pFrom As Date, ByVal pTo As Date, ByVal pfilter As String)
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cmRef As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim rsRef As SqlClient.SqlDataReader
        Dim vName As String = ""

        c.Open()
        cm.Connection = c
        cmRef.Connection = c

        vData = "<table border='1' cellspacing='0' cellpadding='0' width='100%' style='border-collapse:collapse'><tr class='odd'>" & _
                    "<th>Transaction Date</th><th>Emp. Id</th><th>Name of Employee</th><th>Leave Type</th><th>OT Hours</th>" & _
                    "<th>Amount Converted</th><th>Late Filed?</th><th>Effectivity Date</th></tr>"

        cm.CommandText = "select * from py_time_log_dtl where Hrs_Rendered > 0 and TranDate between '" & _
            Format(pFrom, "yyyy/MM/dd") & _
            "' and '" & Format(pTo, "yyyy/MM/dd") & "' and TranCd not in ('ABSENT','TARD','UT','SUSP','OB') and " & _
            "exists (select Leave_Cd from py_leave_ref where Leave_Cd=TranCd) and exists (" & _
            "select OtCd from py_ot_ref where OtCd=TranCd) and exists (" & _
            "select Emp_Cd from py_emp_master where py_emp_master.Emp_Cd=py_time_log_dtl.Emp_Cd " & _
            pfilter & ")"
        rs = cm.ExecuteReader

        Do While rs.Read
            cmRef.CommandText = "select Emp_Lname,Emp_Fname from py_emp_master where Emp_Cd='" & rs("Emp_Cd") & "'"
            rsRef = cmRef.ExecuteReader()
            If rsRef.Read Then
                vName = rsRef("Emp_Lname") & ", " & rsRef("Emp_Fname")
            End If
            rsRef.Close()

            vData += "<tr>"
            vData += "<td>" & Format(rs("TranDate"), "yyyy/MM/dd") & "</td>" & _
                     "<td>" & rs("Emp_Cd") & "</td>" & _
                     "<td>" & vName & "</td>" & _
                     "<td>" & rs("TranCd") & "</td>" & _
                     "<td>" & rs("Hrs_Rendered") & "</td>" & _
                     "<td>" & rs("AmtConv") & "</td>" & _
                     "<td>" & IIf(rs("LateFiled") = 0, "No", "Yes") & "</td>" & _
                     "<td>" & IIf(rs("LateFiled") = 0, "&nbsp;", Format(rs("EffectivityDate"), "yyyy/MM/dd")) & "</td>"
            vData += "</tr>"
        Loop
        vData += "</table>"
        rs.Close()
        c.Close()
        c.Dispose()
        cm.Dispose()
    End Sub

    Protected Sub cmdSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSearch.Click
        DataRefresh(txtSearch.Text)
    End Sub

    Protected Sub vldDate_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles vldDate.ServerValidate
        Dim vDate As String
        vDate = cmbMonthTo.SelectedValue & " " & cmbDayTo.SelectedValue & ", " & cmbYrTo.SelectedValue
        If IsDate(vDate) Then
            args.IsValid = True
        Else
            args.IsValid = False
        End If
    End Sub

    Protected Sub CustomValidator1_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles CustomValidator1.ServerValidate
        Dim vDate As String
        vDate = cmbMonthFr.SelectedValue & " " & cmbDayFr.SelectedValue & ", " & cmbYrFr.SelectedValue
        If IsDate(vDate) Then
            args.IsValid = True
        Else
            args.IsValid = False
        End If
    End Sub
End Class
