Imports denaro.fis
Partial Class emppop
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Protected Sub tblEmp_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tblEmp.SelectedIndexChanged
        vScript = "window.opener.document.getElementById('txtEmp').value = '" & tblEmp.SelectedRow.Cells(0).Text & "'; "
        vScript += "window.opener.document.getElementById('txtEmpName').value = '" & tblEmp.SelectedRow.Cells(1).Text & _
            "'; window.opener.document.getElementById('txtEmp').focus(); self.close();"
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            DataRefresh(Me.TextBox1.Value)
            vScript = "document.getElementById('TextBox1').focus();"
        End If
    End Sub

    Protected Sub cmdSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSearch.Click
        DataRefresh(TextBox1.Value)
    End Sub
    Private Sub DataRefresh(ByVal pLetter As String)
        Dim c As New sqlclient.sqlConnection(connStr)
        Dim ds As New DataSet
        Dim da As sqlclient.sqlDataAdapter
        Dim vSQL As String = ""
        Dim vCond As String = ""

        c.Open()
        vSQL = "select Emp_Cd,(Emp_Lname+', '+Emp_Fname) as Name from py_emp_master " & _
                    "where " & cmbType.SelectedValue & " like '" & pLetter & "%' and Date_Resign is null and DateHold is null " & _
                    "and Date_Retired is null "

       

        'set cost center rights 
        If Session("selectedrc") <> "All" Then
            vSQL += " and Rc_Cd = '" & Session("selectedrc") & "' "
        End If
        If Session("selectedagency") <> "All" Then
            vSQL += " and Agency_Cd='" & Session("selectedagency") & "' "
        End If
        If Session("selecteddiv") <> "All" Then
            vSQL += " and DivCd='" & Session("selecteddiv") & "' "
        End If
        If Session("selecteddept") <> "All" Then
            vSQL += " and DeptCd='" & Session("selecteddept") & "' "
        End If
        If Session("selectedsection") <> "All" Then
            vSQL += " and SectionCd='" & Session("selectedsection") & "' "
        End If
        If Session("selectedunit") <> "All" Then
            vSQL += " and UnitCd='" & Session("selectedunit") & "' "
        End If
        If Session("selectedrank") <> "All" Then
            vSQL += " and EmploymentType='" & Session("selectedrank") & "' "
        End If

        'vSQL += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
        '            "' and Property='rc' and Property_Value=Rc_Cd) "
        ''set agency rights
        'vSQL += "  and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
        '            "' and Property='agency' and Property_Value=Agency_Cd) "
        ''set division rights
        'vSQL += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
        '            "' and Property='division' and Property_Value=DivCd) "
        ''set department rights
        'vSQL += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
        '        "' and Property='department' and Property_Value=DeptCd) "
        ''set section rights
        'vSQL += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
        '           "' and Property='section' and Property_Value=SectionCd) "
        ''set units rights
        'vSQL += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
        '            "' and Property='unit' and Property_Value=UnitCd) "
        ''set rank rights
        'vSQL += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
        '            "' and Property='employmenttype' and Property_Value=EmploymentType) "
        'set sorting optin
        vSQL += "  order by Emp_Lname,Emp_Fname"

        da = New sqlclient.sqlDataAdapter(vSQL, c)
        da.Fill(ds, "emp")
        tblEmp.DataSource = ds.Tables("emp")
        tblEmp.DataBind()

        c.Close()
        c.Dispose()
        da.Dispose()
        ds.Dispose()
    End Sub
End Class
