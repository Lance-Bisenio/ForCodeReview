﻿Imports denaro.fis
Partial Class payrollsumm
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Public vBankAcct As String = ""
    Public vNoBankAcct As String = ""
    Public vHoldEmp As String = ""
    Public vResignedEmp As String = ""
    Public vOthers As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            vScript = "alert('Your login session has expired. Please re-login again.'); window.close();"
            Exit Sub
        End If

        If Not IsPostBack Then
            Dim c As New SqlClient.SqlConnection(connStr)
            Dim cm As New SqlClient.SqlCommand("", c)
            Dim cmRef As New SqlClient.SqlCommand("", c)
            Dim rs As SqlClient.SqlDataReader
            Dim rsRef As SqlClient.SqlDataReader

            Dim vSql As String = Session("sqlstr")
            Dim vCond As String = Mid(vSql, InStr(vSql, "where"))
            Dim vAgencyName As String = "Unknown Agency"
            Dim vFrom As String = "Unknown Start Date"
            Dim vTo As String = "Unknown End Date"
            Dim vPayDate As String = "Unknown Payout"
            Dim vTotal As Decimal = 0
            Dim vGrandTotal As Decimal = 0
            Dim vTmp As String = ""
            Dim vOppositeRank As String = ""

            Try
                c.Open()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                    ex.Message.Replace("'", "").Replace(vbCrLf, "") & "'); window.close();"
                c.Dispose()
                cm.Dispose()
                Exit Sub
            End Try


            'get header information
            cm.CommandText = "select top 1 Agency_Cd,FromDate,ToDate,PayDate from py_report " & vCond
            Try
                rs = cm.ExecuteReader
                If rs.Read Then
                    vAgencyName = rs("Agency_Cd")
                    vFrom = Format(CDate(rs("FromDate")), "MM/dd/yyyy")
                    vTo = Format(CDate(rs("ToDate")), "MM/dd/yyyy")
                    vPayDate = Format(CDate(rs("PayDate")), "MM/dd/yyyy")
                End If
                rs.Close()
                cm.CommandText = "select AgencyName from agency where AgencyCd='" & vAgencyName & "'"
                rs = cm.ExecuteReader
                If rs.Read Then
                    vAgencyName = rs("AgencyName")
                End If
                rs.Close()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to retrieve header records. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                c.Close()
                cm.Dispose()
                c.Dispose()
                Exit Sub
            End Try

            lblPeriod.Text = vFrom & " - " & vTo
            lblPayDate.Text = vPayDate
            lblRank.Text = Mid(vCond, InStr(vCond, "EmploymentType in (") + 20)
            lblRank.Text = lblRank.Text.Replace("'", "").Replace(")", "")
            vTmp = Mid(vCond, InStr(vCond, "and EmploymentType in ("))
            
            Try
                'get total Payroll amount
                cm.CommandText = "select sum(Amount_Per) as TotalPayroll " & _
                   "from py_report " & vCond

                vTotal = 0
                rs = cm.ExecuteReader
                If rs.Read Then
                    If Not IsDBNull(rs("TotalPayroll")) Then
                        vTotal = rs("TotalPayroll")
                    End If
                End If
                rs.Close()
                lblTotalNetPay.Text = Format(vTotal, "##,###,##0.00")

                'get total Payroll amount per bank
                cm.CommandText = "select distinct BankCd from py_report " & _
                    vCond & " and Amount_Per > 0 and Report_No is not null and Report_No<>'' and " & _
                    "Emp_Cd in (select Emp_Cd from py_emp_master where DateHold is null and Date_Resign is null) " & _
                    "order by BankCd"
                rs = cm.ExecuteReader
                vBankAcct = ""
                Do While rs.Read
                    cmRef.CommandText = "select sum(Amount_Per) as TotalPayroll from py_report " & _
                        vCond.Replace(vTmp, "") & " and Amount_Per > 0 and Report_No is not null and Report_No<>'' and " & _
                        "Emp_Cd in (select Emp_Cd from py_emp_master where DateHold is null and Date_Resign is null) " & _
                        "and BankCd='" & rs("BankCd") & "'"
                    rsRef = cmRef.ExecuteReader
                    If rsRef.Read Then
                        vTotal = 0
                        If Not IsDBNull(rsRef("TotalPayroll")) Then
                            vTotal = rsRef("TotalPayroll")
                        End If
                        vBankAcct += "<tr>" & _
                            "<td class='labelR'><a href=""javascript:showdetail('" & rs("BankCd") & "');"">" & _
                            rs("BankCd") & "</a>:&nbsp;</td>" & _
                            "<td class='labelR'>" & Format(rsRef("TotalPayroll"), "##,###,##0.00") & "</td></tr>"
                    End If
                    rsRef.Close()

                    cmRef.CommandText = "select distinct GroupName from hr_employment_type where EmploymentType not in ('" & _
                        lblRank.Text.Replace(",", "','") & "') order by GroupName"
                    rsRef = cmRef.ExecuteReader
                    vOppositeRank = ""
                    Do While rsRef.Read
                        vOppositeRank = rsRef(0) & ","
                    Loop
                    rsRef.Close()
                    If vOppositeRank <> "" Then
                        vOppositeRank = Mid(vOppositeRank, 1, Len(vOppositeRank) - 1)
                    End If

                    'less bank total from other ranks
                    cmRef.CommandText = "select sum(Amount_Per) as TotalPayroll from py_report " & _
                        vCond.Replace(vTmp, "") & " and Amount_Per > 0 and Report_No is not null and Report_No<>'' and " & _
                        "Emp_Cd in (select Emp_Cd from py_emp_master where DateHold is null and Date_Resign is null) " & _
                        "and BankCd='" & rs("BankCd") & "' and EmploymentType not in ('" & lblRank.Text.Replace(",", "','") & "')"
                    rsRef = cmRef.ExecuteReader
                    If rsRef.Read Then
                        If Not IsDBNull(rsRef("TotalPayroll")) Then
                            vBankAcct += "<tr>" & _
                                "<td class='labelR'>Less: (" & vOppositeRank & ")&nbsp;</td>" & _
                                "<td class='labelR' style='color:red;'>(" & Format(rsRef("TotalPayroll"), "##,###,##0.00") & ")</td></tr>"
                            vGrandTotal -= rsRef("TotalPayroll")
                        End If
                    End If
                    rsRef.Close()
                    vGrandTotal += vTotal
                Loop
                rs.Close()

                'get total payroll amount without account
                cm.CommandText = "select sum(Amount_Per) as TotalPayroll,Name from py_report " & _
                    vCond & " and Amount_Per > 0 and (Report_No is null or Report_No='') and " & _
                    "Emp_Cd in (select Emp_Cd from py_emp_master where DateHold is null and Date_Resign is null) " & _
                    "Group by Name Order by Name"
                rs = cm.ExecuteReader
                vNoBankAcct = ""
                Do While rs.Read
                    vTotal = 0
                    If Not IsDBNull(rs("TotalPayroll")) Then
                        vTotal = rs("TotalPayroll")
                    End If
                    vNoBankAcct += "<tr>" & _
                        "<td class='labelR'>" & rs("Name") & ":&nbsp;</td>" & _
                        "<td class='labelR'>" & Format(rs("TotalPayroll"), "##,###,##0.00") & "</td></tr>"
                    vGrandTotal += vTotal
                Loop
                rs.Close()

                'get hold employees
                cm.CommandText = "select sum(Amount_Per) as TotalPayroll,Name from py_report " & _
                   vCond & " and Amount_Per > 0 and " & _
                   "Emp_Cd in (select Emp_Cd from py_emp_master where DateHold is not null) " & _
                   "Group By Name Order by Name"
                rs = cm.ExecuteReader
                vHoldEmp = ""
                Do While rs.Read
                    vTotal = 0
                    If Not IsDBNull(rs("TotalPayroll")) Then
                        vTotal = rs("TotalPayroll")
                    End If
                    vHoldEmp += "<tr>" & _
                        "<td class='labelR'>" & rs("Name") & ":&nbsp;</td>" & _
                        "<td class='labelR'>" & Format(rs("TotalPayroll"), "##,###,##0.00") & "</td></tr>"
                    vGrandTotal += vTotal
                Loop
                rs.Close()

                'get resigned employees
                cm.CommandText = "select sum(Amount_Per) as TotalPayroll,Name from py_report " & _
                   vCond & " and Amount_Per > 0 and " & _
                   "Emp_Cd in (select Emp_Cd from py_emp_master where Date_Resign is not null) " & _
                   "Group By Name Order by Name"
                rs = cm.ExecuteReader
                vResignedEmp = ""
                Do While rs.Read
                    vTotal = 0
                    If Not IsDBNull(rs("TotalPayroll")) Then
                        vTotal = rs("TotalPayroll")
                    End If
                    vResignedEmp += "<tr>" & _
                        "<td class='labelR'>" & rs("Name") & ":&nbsp;</td>" & _
                        "<td class='labelR'>" & Format(rs("TotalPayroll"), "##,###,##0.00") & "</td></tr>"
                    vGrandTotal += vTotal
                Loop
                rs.Close()

                'get others
                cm.CommandText = "select sum(Amount_Per) as TotalPayroll,Name from py_report " & _
                   vCond & " and Amount_Per < 0 Group By Name Order by Name"
                rs = cm.ExecuteReader
                vOthers = ""
                Do While rs.Read
                    vTotal = 0
                    If Not IsDBNull(rs("TotalPayroll")) Then
                        vTotal = rs("TotalPayroll")
                    End If
                    vOthers += "<tr>" & _
                        "<td class='labelR'>" & rs("Name") & ":&nbsp;</td>" & _
                        "<td class='labelR'>" & Format(rs("TotalPayroll"), "##,###,##0.00") & "</td></tr>"
                    vGrandTotal += vTotal
                Loop
                rs.Close()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while retrieving records.  Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            End Try
            c.Close()
            cm.Dispose()
            c.Dispose()
            lblGrandTotal.Text = Format(vGrandTotal, "##,###,##0.00")
            lblVariance.Text = Format(Val(lblTotalNetPay.Text.Replace(",", "")) - vGrandTotal, "##,###,##0.00")
        End If
    End Sub
End Class
