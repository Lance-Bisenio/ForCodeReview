﻿Imports denaro.fis
Partial Class forex
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Public vData As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If
        If Not IsPostBack Then
            lblcaption.text = "Set Forex Rate for " & Format(Now, "Long Date")
            Dim c As New SqlClient.SqlConnection(connStr)
            Dim cm As New SqlClient.SqlCommand
            Dim rs As SqlClient.SqlDataReader
            Dim vClass As String = "odd"
            Dim i As Integer = 1

            lblUser.Text = Session("uid")
            Try
                c.Open()
            Catch ex As SqlClient.SqlException
                vScript = "alert('An error occurred while trying to connect to database. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                c.Dispose()
                cm.Dispose()
                Exit Sub
            End Try
            cm.Connection = c
            cm.CommandText = "select Primary_CurrCd from glsyscntrl"
            Try
                rs = cm.ExecuteReader
                If rs.Read Then
                    If Not IsDBNull(rs("Primary_CurrCd")) Then
                        lblDefCurr.Text = rs("Primary_CurrCd")
                    Else
                        lblDefCurr.Text = "You have not yet defined your default currency."
                    End If
                End If
                rs.Close()

                'retrieve currency reference
                cm.CommandText = "select * from currency_ref"
                rs = cm.ExecuteReader
                vData = ""
                Do While rs.Read
                    vData += "<tr class='" & vClass & "'>" & _
                        "<td class='labelC'>" & rs("CurrCd") & "</td>" & _
                        "<td class='labelL'>" & rs("CurrName") & "</td>" & _
                        "<td class='labelL'><input type='text' id='txtCurr" & i & _
                        "' name='txt" & rs("CurrName") & "' class='labelL' value='" & _
                        IIf(rs("CurrCd") = lblDefCurr.Text, 1, 0) & _
                        "' style='text-align:right' /></td></tr>"
                    vClass = IIf(vClass = "odd", "even", "odd")
                Loop
                rs.Close()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to retrieve currency information. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            Finally
                c.Close()
                cm.Dispose()
                c.Dispose()
            End Try
        End If
    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cmRef As New SqlClient.SqlCommand
        Dim rsRef As SqlClient.SqlDataReader

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('An error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try
        cm.Connection = c
        cmRef.Connection = c

        Try
            cmRef.CommandText = "select * from currency_ref"
            rsRef = cmRef.ExecuteReader
            Do While rsRef.Read
                'save to historical first
                cm.CommandText = "insert into currency_ref_hist (CurrCd,TranDate,Forex,UpdatedBy) values ('" & _
                    rsRef("CurrCd") & "','" & rsRef("LastUpdate") & "'," & rsRef("Forex") & ",'" & _
                    rsRef("UpdatedBy") & "')"
                cm.ExecuteNonQuery()
                'now update the changes
                cm.CommandText = "update currency_ref set Forex=" & Val(Request.Form("txt" & rsRef("CurrName"))) & _
                    ",UpdatedBy='" & Session("uid") & "',LastUpdate='" & Format(Now, "yyyy/MM/dd HH:mm:ss") & _
                    "' where CurrCd='" & rsRef("CurrCd") & "'"
                cm.ExecuteNonQuery()
                vScript = "alert('Changes were successfully saved.');"
            Loop
            rsRef.Close()
            vScript = "window.close();"
        Catch ex As SqlClient.SqlException
            vScript = "alert('An error occurred while trying to save changes. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            c.Dispose()
            cm.Dispose()
            cmRef.Dispose()
        End Try
    End Sub
End Class
