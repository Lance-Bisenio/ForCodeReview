Imports denaro.fis
Partial Class recalc
    Inherits System.Web.UI.Page
    Public vReturn As String = ""

    Dim vRank As String = ""
    Dim vGrace As Single = 0
    Dim vBreak As Single = 0
    Dim vRateHr As Single = 0
    Dim vRateDay As Single = 0
    Dim vReqHrs As Single = 8
    Dim vOtHrs As Single = 0
    Dim vOtAfter As Single = 0      'min. # of hours before ot is recognized
    Dim vHours As Single = 0
    Dim vEmpStat As String = ""
    Dim vGrade As String = ""
    Dim vName As String = ""
    Dim vHoly As Boolean = False
    Dim vLegal As Boolean = False
    Dim vRest As Boolean = False
    Dim vFullFlexi As Boolean = False
    Dim vFlexi As Boolean = False
    Dim vIn As Date = Nothing
    Dim vOut As Date = Nothing
    Dim vOutD As Date = Nothing
    Dim vRegIn As Date = Nothing
    Dim vRegOut As Date = Nothing
    Dim vType As String = "99"
    Dim vCasualCd As String = ""
    Dim vCanOT As Boolean = False
    Dim vOTonLeave As Boolean = False
    Dim vWithLeave As Boolean = False
    Dim vDaysLeave As Decimal = 0
    Dim vScheds(,) As String
    Dim vLateFiledDTR As Boolean = False
    Dim vLateFiledOT As Boolean = False
    Dim vTrans As New Collection
    Dim vEffectivityDate As Date = Nothing

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            vReturn = "expired"
            Exit Sub
        End If

        Dim vStartDate As Date = CDate(Request.Form("s"))
        Dim vEndDate As Date = CDate(Request.Form("e"))
        Dim vSQL As String = ""
        Dim vRc As Boolean = False
        Dim vOfc As Boolean = False
        Dim iDate As Date
        Dim rc As String = ""
        Dim vAgency As String = ""
        Dim c As New sqlclient.sqlconnection(connStr)
        Dim cm As New sqlclient.sqlcommand
        Dim cmRef As New sqlclient.sqlcommand
        Dim dr As sqlclient.sqldatareader
        Dim drRef As sqlclient.sqldatareader
        Dim iCtr As Integer = 0
        Dim vInRaw As String = ""
        Dim vOutRaw As String = ""
        Dim vDateOutRaw As String = ""

        vLateFiledDTR = Val(Request.Form("ldtr")) = 1
        vLateFiledOT = Val(Request.Form("lot")) = 1

        vSQL = "select Emp_Cd,Emp_Lname,Emp_Fname,Req_Hrs_Day,Emp_Status,Rate_Day,OtAllowanceType,EmploymentType," & _
            "Allow_Reg_TimeIn,Allow_Req_Hrs,Grade_Cd,EmploymentType,GracePeriod,MinOtHours,Agency_Cd,Rc_Cd " & _
            "from py_emp_master where Emp_Cd='" & Request.Form("id") & "'"

        Try
            c.Open()
        Catch ex As sqlclient.sqlexception
            vReturn = "Error occurred while trying to connect to SQL server. Error is: " & ex.Message.Replace(vbCrLf, "\n")
            cm.Dispose()
            cmRef.Dispose()
            Exit Sub
        End Try

        cm.Connection = c
        cmRef.Connection = c

        'get defaults grace period,Break Hours and other global parameters
        cm.CommandText = "select Grace_Period, Break_Hrs, Casual_Cd,Start_Ot_Time from py_syscntrl"
        Try
            dr = cm.ExecuteReader
        Catch ex As sqlclient.sqlexception
            vReturn = "Error occurred while trying to read the system control table. Error in line 85: " & _
                ex.Message.Replace(vbCrLf, "\n")
            c.Close()
            c.Dispose()
            cm.Dispose()
            cmRef.Dispose()
            Exit Sub
        End Try

        vGrace = 0
        vBreak = 0
        vOtAfter = 0
        vRank = ""
        Try
            If dr.Read Then
                If Not IsDBNull(dr("Grace_Period")) Then vGrace = dr("Grace_Period")
                If Not IsDBNull(dr("Break_Hrs")) Then vBreak = dr("Break_Hrs")
                If Not IsDBNull(dr("Casual_Cd")) Then vCasualCd = dr("Casual_Cd")
                If Not IsDBNull(dr("Start_Ot_Time")) Then vOtAfter = dr("Start_Ot_Time")
            End If
            dr.Close()
        Catch ex As sqlclient.sqlexception
            vReturn = "Error occurred while trying to retrieve data from system control table. Error in line 100-105: " & _
                ex.Message.Replace(vbCrLf, "\n")
            c.Close()
            c.Dispose()
            cm.Dispose()
            cmRef.Dispose()
            Exit Sub
        End Try

        cm.CommandText = vSQL

        Try
            dr = cm.ExecuteReader
        Catch ex As sqlclient.sqlexception
            vReturn = "Error occurred while trying to execute SQL Query. Error in line 118: " & ex.Message.Replace(vbCrLf, "\n")
            c.Close()
            c.Dispose()
            cm.Dispose()
            cmRef.Dispose()
            Exit Sub
        End Try

        Try
            If dr.Read Then
                'set personalized parameter
                If Not IsDBNull(dr("EmploymentType")) Then vRank = dr("EmploymentType")
                If Not IsDBNull(dr("GracePeriod")) Then vGrace = dr("GracePeriod")
                If Not IsDBNull(dr("MinOtHours")) Then vOtAfter = dr("MinOtHours")

                vName = dr("Emp_Lname") & ", " & dr("Emp_Fname") & " "
                If Not IsDBNull(dr("Allow_Reg_TimeIn")) Then vFlexi = dr("Allow_Reg_TimeIn") = 0 'semi-flexi, no tardy, may or may have undertime
                If Not IsDBNull(dr("Allow_Req_Hrs")) Then vFullFlexi = dr("Allow_Req_Hrs") = 0 'full flexi, no undertime, no tardiness
                If Not IsDBNull(dr("Grade_Cd")) Then vGrade = dr("Grade_Cd")
                If Not IsDBNull(dr("Rc_Cd")) Then rc = dr("Rc_Cd")
                If Not IsDBNull(dr("Agency_Cd")) Then vAgency = dr("Agency_Cd")
                If Not IsDBNull(dr("OtAllowanceType")) Then
                    If dr("OtAllowanceType") = "2" Then     'employee can have Overtime plus OT Allowance
                        vCanOT = True
                    End If
                End If
                If Not IsDBNull(dr("Emp_Status")) Then vEmpStat = dr("Emp_Status")

                'get hourly rate and required hours per day
                If Not IsDBNull(dr("Req_Hrs_Day")) Then vReqHrs = dr("Req_Hrs_Day")
                If Not IsDBNull(dr("Rate_Day")) Then
                    vRateDay = dr("Rate_Day")
                    vRateHr = vRateDay / vReqHrs
                End If

                iDate = vStartDate
                Do While iDate <= vEndDate
                    vTrans.Clear()

                    'clean up any duplicate time-in null transactions
                    cmRef.CommandText = "delete from py_time_log where Time_In is null and Tran_Date='" & _
                        Format(iDate, "yyyy/MM/dd") & "' and Emp_Cd='" & dr("Emp_Cd") & _
                        "' and EffectivityDate is null and CorrectionTimeIn is null and Reason is null"
                    Try
                        cmRef.ExecuteNonQuery()
                    Catch ex As sqlclient.sqlexception
                        vReturn = "Error occurred while trying to clean-up the time log table of employee " & _
                            dr("Emp_Cd") & " for trans date " & iDate & ". Error in line 164: " & _
                            ex.Message.Replace(vbCrLf, "\n")
                        c.Close()
                        c.Dispose()
                        dr.Close()
                        cm.Dispose()
                        cmRef.Dispose()
                        Exit Sub
                    End Try


                    're-align  logs with logs raw
                    cmRef.CommandText = "select Time_InDate,Time_In,Time_Out,Time_OutDate " & _
                        "from py_time_log_raw where Emp_cd='" & dr("Emp_Cd") & _
                        "' and Time_InDate='" & Format(iDate, "yyyy/MM/dd") & _
                        "' and Time_In is not null  " & _
                        "order by Time_InDate,Time_In,Time_Out"
                    Try
                        drRef = cmRef.ExecuteReader
                        vInRaw = ""
                        vOutRaw = ""
                        vDateOutRaw = ""
                        Do While drRef.Read
                            'get first in
                            If Not IsDBNull(drRef("Time_In")) Then
                                If vInRaw = "" Then
                                    vInRaw = drRef("Time_In")
                                Else
                                    vInRaw = IIf(CDate(drRef("Time_In")) < CDate(vInRaw), drRef("Time_In"), vInRaw)
                                End If
                            End If
                            If Not IsDBNull(drRef("Time_Out")) Then
                                If vInRaw = "" Then
                                    vInRaw = drRef("Time_Out")
                                Else
                                    vInRaw = IIf(CDate(drRef("Time_Out")) < CDate(vInRaw), drRef("Time_Out"), vInRaw)
                                End If
                            End If

                            'get last out
                            If Not IsDBNull(drRef("Time_In")) Then
                                If vOutRaw = "" Then
                                    vOutRaw = drRef("Time_In")
                                    vDateOutRaw = Format(drRef("Time_InDate"), "yyyy/MM/dd")
                                Else
                                    vOutRaw = IIf(CDate(drRef("Time_In")) > CDate(vOutRaw), drRef("Time_In"), vOutRaw)
                                    vDateOutRaw = IIf(CDate(drRef("Time_In")) > CDate(vOutRaw), Format(drRef("Time_InDate"), "yyyy/MM/dd"), vDateOutRaw)
                                End If
                            End If
                            If Not IsDBNull(drRef("Time_Out")) Then
                                If vOutRaw = "" Then
                                    vOutRaw = drRef("Time_Out")
                                    vDateOutRaw = drRef("Time_OutDate")
                                Else
                                    vOutRaw = IIf(CDate(drRef("Time_Out")) > CDate(vOutRaw), drRef("Time_Out"), vOutRaw)
                                    vDateOutRaw = IIf(CDate(drRef("Time_Out")) > CDate(vOutRaw), drRef("Time_OutDate"), vDateOutRaw)
                                End If
                            End If
                        Loop
                        If vInRaw = vOutRaw Then
                            vOutRaw = ""
                            vDateOutRaw = ""
                        End If
                        drRef.Close()
                    Catch ex As system.exception
                        vReturn = "Error occurred while trying to retrieve the raw logs table of employee " & _
                            dr("Emp_Cd") & " for trans date " & iDate & ". Error in line 183: " & _
                            ex.Message.Replace(vbCrLf, "\n")
                        c.Close()
                        c.Dispose()
                        dr.Close()
                        cm.Dispose()
                        cmRef.Dispose()
                        Exit Sub
                    End Try
                    ''''''''''''''' end re-align ''''''''''''''''''''''''''''

                    'get number of schedules in a day
                    cmRef.CommandText = "select count(*) from py_emp_time_sched where Emp_Cd='" & _
                        dr("Emp_Cd") & "' and Date_Sched='" & Format(iDate, "yyyy/MM/dd") & "'"
                    Try
                        drRef = cmRef.ExecuteReader
                        iCtr = 0
                        If drRef.Read Then
                            If Not IsDBNull(drRef(0)) Then
                                iCtr = drRef(0)
                            End If
                        End If
                        drRef.Close()
                    Catch ex As sqlclient.sqlexception
                        vReturn = "Error occurred while trying to count employee schedule of " & _
                            dr("Emp_Cd") & " for date " & iDate & ". Error is: " & ex.Message.Replace(vbCrLf, "\n")
                        c.Close()
                        c.Dispose()
                        dr.Close()
                        cm.Dispose()
                        cmRef.Dispose()
                        Exit Sub
                    End Try

                    ReDim vScheds(iCtr - 1, 3)

                    cmRef.CommandText = "select Start_Time,End_Time from py_emp_time_sched where Emp_Cd='" & _
                        dr("Emp_Cd") & "' and Date_Sched='" & Format(iDate, "yyyy/MM/dd") & "'"
                    Try
                        drRef = cmRef.ExecuteReader
                        iCtr = 0
                        Do While drRef.Read
                            vScheds(iCtr, 0) = CDate(iDate & " " & Format(CDate(drRef("Start_Time")), "HH:mm:00"))
                            If CDate(Format(CDate(drRef("End_Time")), "HH:mm:00")) < CDate(Format(CDate(drRef("Start_Time")), "HH:mm:00")) Then
                                vScheds(iCtr, 1) = CDate(iDate.AddDays(1) & " " & Format(CDate(drRef("End_Time")), "HH:mm:00"))
                            Else
                                vScheds(iCtr, 1) = CDate(iDate & " " & Format(CDate(drRef("End_Time")), "HH:mm:00"))
                            End If
                            vScheds(iCtr, 2) = 0
                            iCtr += 1
                        Loop
                        drRef.Close()
                    Catch ex As system.exception
                        vReturn = "Error occurred while trying to retrieve employee schedule of " & _
                            dr("Emp_Cd") & " for date " & iDate
                        c.Close()
                        c.Dispose()
                        dr.Close()
                        cm.Dispose()
                        cmRef.Dispose()
                        Exit Sub
                    End Try

                    '''''''''''''''''''''  GET STATUS OF DAY if it falls on a holiday '''''''''''''''''''''''''''''''
                    cmRef.CommandText = "select Official,Office_Cd,Rc_Cd from py_holiday where month(Holy_Date)=" & _
                        Month(iDate) & " and day(Holy_Date)=" & Day(iDate) & " and " & _
                        "(Office_Cd like '%" & vAgency & "%' or Office_Cd='*') and " & _
                        "(Rc_Cd like  '%" & rc & "%' or Rc_Cd='*') order by Holy_Date desc"
                    Try
                        drRef = cmRef.ExecuteReader
                        vHoly = False
                        vLegal = False
                        If drRef.Read Then   'DAY IS HOLIDAY
                            If Not IsDBNull(drRef("Official")) Then
                                vLegal = drRef("Official")       '1=LEGAL HOLIDAY;0=SPECIAL HOLIDAY
                            End If
                            vHoly = True
                        End If
                        drRef.Close()
                        If Analyze(dr("Emp_Cd"), iDate, vInRaw, vOutRaw, vDateOutRaw, c) <> "" Then
                            c.Close()
                            c.Dispose()
                            dr.Close()
                            cm.Dispose()
                            cmRef.Dispose()
                            Exit Sub
                        End If
                    Catch ex As system.exception
                        vReturn = "Error occurred while trying to retrieve employee schedule of " & _
                                dr("Emp_Cd") & " for date " & iDate
                        c.Close()
                        c.Dispose()
                        dr.Close()
                        cm.Dispose()
                        cmRef.Dispose()
                        Exit Sub
                    End Try
                    iDate = iDate.AddDays(1)
                Loop
            End If
            dr.Close()
            vReturn = "ok"
        Catch ex As system.exception
            vReturn = "Error occurred while trying to read the dataQuery. Error in line 118-284: " & _
                ex.Message.Replace(vbCrLf, "\n")
        Finally
            c.Close()
            c.Dispose()
            cm.Dispose()
            cmRef.Dispose()
        End Try
    End Sub

    Private Function Analyze(ByVal pID As String, ByVal pDate As Date, _
        ByVal pInRaw As String, ByVal pOutRaw As String, ByVal pDateOutRaw As String, _
        ByRef c As sqlclient.sqlconnection) As String

        Dim cm As New sqlclient.sqlcommand
        Dim dr As sqlclient.sqldatareader
        Dim iCtr As Integer = 0
        Dim _2ndPass As Boolean = False
        Dim vNoRecord As Boolean = True
        Dim vSyncLog As Boolean = False
        Dim vResult As String = ""


        vRest = False
        vIn = Nothing
        vOut = Nothing
        vOutD = Nothing
        vRegIn = Nothing
        vRegOut = Nothing
        vType = "99"
        vEffectivityDate = Nothing

        'get actual logs
        cm.Connection = c
        If Not vLateFiledDTR Then       'get logs from current
again:
            cm.CommandText = "select Type,Time_In,Time_Out,Time_OutDate,Etp,Tran_Date as EffectivityDate,Reason from py_time_log " & _
                "where Tran_Date='" & Format(pDate, "yyyy/MM/dd") & "' and Emp_Cd='" & pID & _
                "' "
        Else                            'get logs from corrections
            cm.CommandText = "select Type,CorrectionTimeIn as Time_In, CorrectionTimeOut as Time_Out," & _
                "CorrectionTimeOutDate as Time_OutDate,Etp,EffectivityDate,Reason from py_time_log " & _
                "where Tran_Date='" & Format(pDate, "yyyy/MM/dd") & "' and Emp_Cd='" & pID & _
                "' and EffectivityDate is not null and Date_Approved is not null and ApprovedBy is not null " & _
                " and DateDisApproved is null"
        End If

        Try
            dr = cm.ExecuteReader
            If Not _2ndPass And Not dr.HasRows And vLateFiledDTR Then
                _2ndPass = True
                dr.Close()
                GoTo again
            End If
            If dr.Read Then 'date is either restday overtime or regular day checked later in the code
                vNoRecord = False
                If Not IsDBNull(dr("Reason")) Then
                    vSyncLog = Not dr("Reason").ToString.Contains("Edited")
                Else
                    vSyncLog = True
                End If
                If Not IsDBNull(dr("Time_In")) Then vIn = CDate(pDate & " " & Format(CDate(dr("Time_In")), "HH:mm:00"))
                If Not IsDBNull(dr("Time_OutDate")) Then
                    vOutD = dr("Time_OutDate")
                    If Not IsDBNull(dr("Time_Out")) Then
                        vOut = CDate(vOutD & " " & Format(CDate(dr("Time_Out")), "HH:mm:00"))
                    Else
                        vOut = vIn  'set out = in if there's no out
                    End If
                End If
                If Not IsDBNull(dr("Type")) Then vType = dr("Type")
                If Not IsDBNull(dr("EffectivityDate")) Then vEffectivityDate = dr("EffectivityDate")
            Else    'no record at all, create a blank record on time log header instead
                vNoRecord = True
            End If
            dr.Close()
        Catch ex As system.exception
            vResult = "Error occurred while trying to get the logs of employee " & pID & _
                " for date " & pDate & ". Error is: " & ex.Message.Replace(vbCrLf, "\n")
            cm.Dispose()
            Return vResult
            Exit Function
        End Try

        If vNoRecord Then
            cm.CommandText = "insert into py_time_log (Tran_Date,Time_In,Time_Out,Time_OutDate,Etp,Type,Hrs_Worked,Emp_Cd) " & _
                "values ('" & Format(pDate, "yyyy/MM/dd") & "'," & IIf(pInRaw = "", "null", "'" & pInRaw & "'") & _
                "," & IIf(pOutRaw = "", "null", "'" & pOutRaw & "'") & "," & IIf(pDateOutRaw = "", "null", "'" & pDateOutRaw & "'") & _
                ",0,'99',0,'" & pID & "')"
            Try
                cm.ExecuteNonQuery()
            Catch ex As sqlclient.sqlexception
                vResult = "Error occurred while trying to insert blank record in time log table for employee " & _
                    pID & " for date " & pDate & ". Error is: " & ex.Message.Replace(vbCrLf, "\n")
                cm.Dispose()
                Return vResult
                Exit Function
            End Try
        Else
            If vSyncLog Then
                'overwrite existing logs
                Dim vHrs_Worked As Decimal = 0
                If pOutRaw <> "" And pInRaw <> "" Then
                    vHrs_Worked = Math.Round(DateDiff(DateInterval.Minute, _
                        CDate(Format(pDate, "yyyy/MM/dd") & " " & pInRaw), _
                        CDate(pDateOutRaw & " " & pOutRaw)) / 60, 2)
                End If
                cm.CommandText = "update py_time_log set Time_In=" & IIf(pInRaw = "", "null", "'" & pInRaw & "'") & _
                    ",Time_Out=" & IIf(pOutRaw = "", "null", "'" & pOutRaw & "'") & _
                    ",Time_OutDate=" & IIf(pDateOutRaw = "", "null", "'" & pDateOutRaw & "'") & _
                    ",Hrs_Worked=" & vHrs_Worked & " where Emp_Cd='" & pID & "' and Tran_Date='" & Format(pDate, "yyyy/MM/dd") & "'"
                Try
                    cm.ExecuteNonQuery()

                    If pInRaw <> "" Then vIn = CDate(pDate & " " & Format(CDate(pInRaw), "HH:mm:00"))
                    If pDateOutRaw <> "" Then
                        vOutD = CDate(pDateOutRaw)
                        If pOutRaw <> "" Then
                            vOut = CDate(vOutD & " " & Format(CDate(pOutRaw), "HH:mm:00"))
                        Else
                            vOut = vIn  'set out=in if there's no out
                        End If
                    End If
                Catch ex As system.exception
                    vReturn = "Error occurred while trying to update the log table of employee " & _
                        pID & " for date " & pDate & ". Error is: " & ex.Message.Replace(vbCrLf, "\n")
                    cm.Dispose()
                    Return vReturn
                    Exit Function
                End Try
            End If
        End If

        If vOut = Nothing And vIn <> Nothing Then
            vOut = vIn
        ElseIf vIn = Nothing And vOut <> Nothing Then
            vIn = vOut
        End If

        '''''''''''update schedules in py_time_log '''''''''''''''
        vReturn = DetermineSked(pDate, pID, c)
        If vReturn <> "" Then
            cm.Dispose()
            Return vReturn
            Exit Function
        End If

        vOtHrs = 0                     'Turn off Overtime approval

        vRest = vRegIn = Nothing

        If vFlexi Then             'check if the employee falls on flexi-time (regtimein =0)
            If vRegIn <> Nothing And vIn <> Nothing Then
                vIn = vRegIn
            End If
        End If

        If vFullFlexi Then
            If vOut <> Nothing And vRegOut <> Nothing Then
                vOut = vRegOut
            End If
        End If

        ''''''  get approved overtime, if there's any ''''''''''''
        If Not vLateFiledOT Then        'current ot application mode
            cm.CommandText = "select sum(DaysLeave) as DaysLeave from hr_leave_application where " & _
                " Void=0 and ApprovedBy is not null and DateApproved is not null and EffectivityDate is null " & _
                " and LeaveCd='OT' and Emp_Cd='" & pID & "' and year(StartDate)=" & pDate.Year & _
                " and month(StartDate)=" & pDate.Month & " and day(StartDate)=" & pDate.Day
        Else
            cm.CommandText = "select DaysLeave, EffectivityDate from hr_leave_application where " & _
                " Void=0 and ApprovedBy is not null and DateApproved is not null " & _
                " and LeaveCd='OT' and Emp_Cd='" & pID & "' and year(StartDate)=" & pDate.Year & _
                " and month(StartDate)=" & pDate.Month & " and day(StartDate)=" & pDate.Day & _
                " and EffectivityDate is not null"
        End If
        Try
            dr = cm.ExecuteReader
            vOtHrs = 0
            If dr.Read Then
                If Not IsDBNull(dr("DaysLeave")) Then vOtHrs = dr("DaysLeave")
                If vLateFiledOT Then
                    If Not IsDBNull(dr("EffectivityDate")) Then vEffectivityDate = dr("EffectivityDate")
                End If
            End If
            dr.Close()
            cm.Dispose()
            vReturn = DigestTime(pDate, pID, c)
            If vReturn <> "" Then
                cm.Dispose()
                Return vReturn
                Exit Function
            End If
        Catch ex As system.exception
            vReturn = "Error occurred while trying to retrieve leave application for employee " & _
                pID & " for date " & pDate & ". Error is: " & ex.Message.Replace(vbCrLf, "\n")
            cm.Dispose()
            Return vReturn
            Exit Function
        End Try

        Return ""
    End Function
    Private Function DetermineSked(ByVal pDate As Date, ByVal pID As String, ByRef c As sqlclient.sqlconnection) As String
        Dim cm As New sqlclient.sqlcommand
        Dim a As Integer = vScheds.GetUpperBound(0)
        cm.Connection = c
        Dim iCtr As Integer
        Dim vReturn As String = ""

        Select Case vScheds.GetUpperBound(0)
            Case 0  'one schedule, temporary only, should be =0 only
                cm.CommandText = "update py_time_log set Sched_In = '" & vScheds(0, 0) & _
                "',Sched_Out='" & vScheds(0, 1) & "' where Emp_Cd='" & pID & _
                "' and Tran_Date='" & Format(pDate, "yyyy/MM/dd") & "'"
                Try
                    cm.ExecuteNonQuery()
                Catch ex As sqlclient.sqlexception
                    vReturn = "Error occurred while trying to update log table schedule of employee " & _
                        pID & " for date " & pDate
                    cm.Dispose()
                    Return vReturn
                    Exit Function
                End Try

                vRegIn = CDate(vScheds(0, 0))
                vRegOut = CDate(vScheds(0, 1))
                vScheds(0, 2) = 1
            Case -1 'no schedule, rest day
                cm.CommandText = "update py_time_log set Sched_In = null" & _
                    ",Sched_Out=null where Emp_Cd='" & pID & _
                    "' and Tran_Date='" & Format(pDate, "yyyy/MM/dd") & "'"
                Try
                    cm.ExecuteNonQuery()
                Catch ex As sqlclient.sqlexception
                    vReturn = "Error occurred while trying to update log table schedule of employee " & _
                        pID & " for date " & pDate
                    cm.Dispose()
                    Return vReturn
                    Exit Function
                End Try
                vRegIn = Nothing
                vRegOut = Nothing
            Case Else   'more than one schedule in a day
                Dim vIdx As Integer = -1
                For iCtr = 0 To UBound(vScheds)

                Next
        End Select
        vReturn = ""
        Return vReturn
    End Function
    Private Function DigestTime(ByVal pDate As Date, ByVal pID As String, ByRef c As sqlclient.sqlconnection) As String
        Dim vReturn As String = ""
        Dim cm As New sqlclient.sqlcommand
        Dim dr As sqlclient.sqldatareader

        cm.Connection = c
        'CLEAN EXISTING DATA
        If vLateFiledDTR Or vLateFiledOT Then
            'get data from current calculation
            cm.CommandText = "select TranCd,Hrs_Rendered from py_time_log_dtl where TranDate='" & _
                Format(pDate, "yyyy/MM/dd") & "' and Emp_Cd='" & pID & _
                "' and LateFiled=0"
            Try
                dr = cm.ExecuteReader
                vTrans.Clear()
                Do While dr.Read
                    vTrans.Add(dr("Hrs_Rendered"), dr("TranCd"))
                Loop
                dr.Close()
            Catch ex As system.exception
                vReturn = "Error occurred while trying to retrieve Log Detail of employee " & _
                    pID & " for date " & pDate & ". Error in line 599: " & ex.Message.Replace(vbCrLf, "\n")
                cm.Dispose()
                Return vReturn
                Exit Function
            End Try
            cm.CommandText = "delete from py_time_log_dtl where cast(Reason as varchar)='Auto-generated' " & _
                "and Emp_Cd='" & pID & "' and TranDate='" & Format(pDate, "yyyy/MM/dd") & "' and LateFiled=1"
        Else

            cm.CommandText = "delete from py_time_log_dtl where cast(Reason as varchar)='Auto-generated' " & _
                "and Emp_Cd='" & pID & "' and TranDate='" & Format(pDate, "yyyy/MM/dd") & "' and LateFiled=0"
        End If

        Try
            cm.ExecuteNonQuery()
        Catch ex As sqlclient.sqlexception
            vReturn = "Error occurred while trying to clean up Log Detail of employee " & _
                pID & " for date " & pDate & ". Error is line 625: " & ex.Message.Replace(vbCrLf, "\n")
            cm.Dispose()
            Return vReturn
            Exit Function
        End Try

        'now check if there are leaves for the day
        cm.CommandText = "select Hrs_Rendered from py_time_log_dtl where cast(Reason as varchar)='Posted-LeaveApp' " & _
            "and Emp_Cd='" & pID & "' and TranDate='" & Format(pDate, "yyyy/MM/dd") & "'"
        If vLateFiledDTR Or vLateFiledOT Then
            cm.CommandText += " and LateFiled=1"
        Else
            cm.CommandText += " and LateFiled=0"
        End If

        Try
            dr = cm.ExecuteReader
            vWithLeave = dr.HasRows
            vOTonLeave = False
            vDaysLeave = 0
            If dr.Read Then
                vDaysLeave = dr("Hrs_Rendered")
                If vOtHrs > 0 Then
                    vOTonLeave = True
                    'set it as restday
                    If Not vHoly Then
                        If vDaysLeave > 4 Then  'more than half day
                            vRegIn = Nothing
                            vRegOut = Nothing
                        Else    'half day leave only

                        End If
                    End If
                End If
            End If
            dr.Close()
        Catch ex As system.exception
            vReturn = "Error occurred while trying to retrieve Leave from Log detail of employee " & _
                pID & " for date " & pDate & ". Error is: " & ex.Message.Replace(vbCrLf, "\n")
            cm.Dispose()
            Return vReturn
            Exit Function
        End Try

        'CHECK FOR RESTDAY
        If vRegIn = Nothing And vIn = Nothing Then cm.Dispose() : vReturn = "" : Return vReturn : Exit Function

        If vIn = Nothing And vRegIn <> Nothing Then 'with schedule, but with no logs
            'check if it falls on holiday and employee is regular, exit procedure and do nothing
            If vHoly And vEmpStat <> vCasualCd Then cm.Dispose() : vReturn = "" : Return vReturn : Exit Function

            If Not vHoly Then  'ABSENT
                Try
                    cm.CommandText = "select 1 from py_time_log where Tran_Date='" & _
                        Format(pDate, "yyyy/MM/dd") & "' and Emp_Cd='" & pID & "'"
                    dr = cm.ExecuteReader
                    If Not dr.HasRows Then
                        dr.Close()
                        cm.CommandText = "insert into py_time_log (Tran_Date,Emp_Cd,Emp_Name," & _
                            "Time_In,Time_Out,Time_OutDate,IsLeavePay,Hrs_Worked) values ('" & _
                            Format(pDate, "yyyy/MM/dd") & "','" & _
                            pID & "','" & vName & "',null,null,null,0,0)"
                        cm.ExecuteNonQuery()
                        'GoTo skip
                        vReturn = DetermineSked(pDate, pID, c)
                        If vReturn <> "" Then
                            cm.Dispose()
                            Return vReturn
                            Exit Function
                        End If
                    End If
                    dr.Close()
                Catch ex As sqlclient.sqlexception
                    'if error occur, it means that there is already a record, disregard the execution
                    vReturn = "Error occurred while trying to insert record in Time Log of employee " & _
                        pID & " for date " & pDate & ". Error is: " & ex.Message.Replace(vbCrLf, "\n")
                    cm.Dispose()
                    Return vReturn
                    Exit Function
                End Try

                If Not vWithLeave And Not vLateFiledOT And Not vLateFiledDTR Then
                    dr.Close()
                    cm.CommandText = "delete from py_time_log_dtl where TranDate='" & _
                        Format(pDate, "yyyy/M/dd") & "' and Emp_Cd='" & pID & _
                        "' and TranCd='ABSENT' and LateFiled=0"
                    Try
                        cm.ExecuteNonQuery()
                    Catch ex As sqlclient.sqlException
                        vReturn = "Error occurred while trying to clean up Log Detail of employee " & _
                            pID & " for date " & pDate & ". Error in line 717: " & ex.Message.Replace(vbCrLf, "\n")
                        cm.Dispose()
                        Return vReturn
                        Exit Function
                    End Try

                    cm.CommandText = "insert into py_time_log_dtl (Emp_Cd,TranDate,TranCd,Reason," & _
                        "Hrs_Rendered,AmtConv,LateFiled,EffectivityDate) " & _
                        "values ('" & pID & "','" & Format(pDate, "yyyy/MM/dd") & "','ABSENT','Auto-generated'," & _
                        vReqHrs & "," & vRateDay * -1 & ",0,'" & Format(pDate, "yyyy/MM/dd") & "')"
                    Try
                        cm.ExecuteNonQuery()
                    Catch ex As sqlclient.sqlException
                        vReturn = "Error occurred while trying to insert Log Detail record for employee " & _
                            pID & " for date " & pDate & ". Error in line 730: " & ex.Message.Replace(vbCrLf, "\n")
                        cm.Dispose()
                        Return vReturn
                        Exit Function
                    End Try

                    cm.Dispose()
                    vReturn = ""
                    Return vReturn
                    Exit Function
                End If
            End If
            cm.Dispose()
            vReturn = ""
            Return vReturn
            Exit Function
        End If


        cm.Dispose()


        'CHECK FOR OVERTIME IN RESTDAY
        If vIn <> Nothing And vRegIn = Nothing And vCanOT Then
            If Not vHoly Then 'REST DAY DOES NOT FALL ON A HOLIDAY (CODE IS E1 TO E4)
                vReturn = ExtractTime("E1", "E2", "E3", "E4", pDate, pID, c)
                If vReturn <> "" Then
                    Return vReturn
                    Exit Function
                End If
            Else  'REST DAY FALLS ON A HOLIDAY
                If vLegal Then 'HOLIDAY IS A LEGAL HOLIDAY  (CODE IS D1 TO D4)
                    vReturn = ExtractTime("D1", "D2", "D3", "D4", pDate, pID, c)
                    If vReturn <> "" Then
                        Return vReturn
                        Exit Function
                    End If
                Else  'HOLIDAY IS A SPECIAL HOLIDAY (CODE IS B1 TO B4)
                    vReturn = ExtractTime("B1", "B2", "B3", "B4", pDate, pID, c)
                    If vReturn <> "" Then
                        Return vReturn
                        Exit Function
                    End If
                End If
            End If
            vReturn = ""
            Return vReturn
            Exit Function
        End If

        If vIn <> Nothing And vRegIn <> Nothing Then        'WITH LOGS, WITH SCHEDULE
            If Not vHoly Then 'REGULAR DAY
                vReturn = CheckRegular(pDate, pID, c)
                If vReturn <> "" Then
                    Return vReturn
                    Exit Function
                End If
            Else  'FALLS ON A HOLIDAY
                If vCanOT Then
                    If vLegal Then       'HOLIDAY IS A LEGAL HOLIDAY
                        vReturn = ExtractTime("C1", "C2", "C3", "C4", pDate, pID, c)
                        If vReturn <> "" Then
                            Return vReturn
                            Exit Function
                        End If
                    Else                 'HOLIDAY IS A SPECIAL HOLIDAY
                        vReturn = ExtractTime("F1", "F2", "F3", "F4", pDate, pID, c)
                        If vReturn <> "" Then
                            Return vReturn
                            Exit Function
                        End If
                    End If
                End If
            End If
        End If
        vReturn = ""
        Return vReturn
    End Function

    Private Function RoundOff(ByVal pRemainder As Single) As Single
        If pRemainder >= 0.5 Then
            RoundOff = 0.5
        Else
            RoundOff = 0
        End If
    End Function

    Private Function ExtractTime(ByVal p1 As String, ByVal p2 As String, _
        ByVal p3 As String, ByVal p4 As String, ByVal pDate As Date, ByVal pID As String, _
        ByRef c As sqlclient.sqlconnection) As String

        Dim vReturn As String = ""
        Dim vTmpOut As Date = vOut

        Try
            vOut = vIn.AddHours(vOtHrs) 'adjust to approved out based on approved ot hours
            vOut = IIf(vOut > vTmpOut, vTmpOut, vOut)

            vHours = Math.Round(DateDiff(DateInterval.Minute, vIn, vOut) / 60, 2)
            vHours = Int(vHours) + RoundOff(vHours - Int(vHours))   'round off the minutes side
            'If vHours >= vOtHrs Then vHours = vOtHrs 'set approved OT hours

            If vHours >= vOtAfter Then
                WriteLog(p1, IIf(vHours > 8, 8, vHours), pID, pDate, IIf(vHours > 8, 8, vHours), c) 'OT FIRST 8HRS
                If vHours > 8 Then WriteLog(p3, vHours - 8, pID, pDate, vHours - 8, c) 'OT IN EXCESS OF 8HRS 

                If vOut >= CDate(pDate & " 22:00:00") Then  'OUT IS ON OR AFTER 10PM
                    vTmpOut = vOut
                    Dim vTmpIn As Date = vIn    'set default to actual in

                    If vIn < CDate(pDate & " 22:00:00") Then 'IN is before 10PM, adjust tmp in to 10pm
                        vTmpIn = CDate(pDate & " 22:00:00")
                    End If

                    vHours = Math.Round(DateDiff(DateInterval.Minute, vTmpIn, vTmpOut) / 60, 2)
                    vHours = Int(vHours) + RoundOff(vHours - Int(vHours))   'round off the minutes side

                    WriteLog(p2, IIf(vHours > 2, 2, vHours), pID, pDate, IIf(vHours > 2, 2, vHours), c)    'ND OT
                    If vHours > 2 Then WriteLog(p4, vHours - 2, pID, pDate, vHours - 2, c) 'ND OT excess of 2 hours
                End If
            End If
        Catch ex As system.exception
            vReturn = "Error occurred in Extracting Time Analysis procedure. Error is: " & ex.Message.Replace(vbCrLf, "\n")
            Return vReturn
            Exit Function
        End Try
        vReturn = ""
        Return vReturn
    End Function
    Private Sub WriteLog(ByVal pCode As String, ByVal pHrs As Single, ByVal pID As String, _
        ByVal pDate As Date, ByVal pOrgHrs As Single, ByRef c As sqlclient.sqlconnection)

        Dim cm As New sqlclient.sqlcommand
        Dim dr As sqlclient.sqldatareader
        Dim vFactor As Single = 0
        Dim vUOM As Integer = 0     '0=percent: 1= amount
        Dim _2ndPass As Boolean = False
        Dim vAmtConv As Decimal = 0

        cm.Connection = c

        If vOTonLeave Then
            pCode = "G1"
        End If
        'If Not vOTonLeave Then
        If vRank = "" Then  'no rank, use default
def:
            cm.CommandText = "select OtPer, 0 as UOM from py_ot_ref where OtCd='" & pCode & "'"
        Else    'with rank, check the 
            cm.CommandText = "select UOM,Factor as OtPer from py_ot_ref_dtl where OtCd='" & pCode & _
                "' and EmploymentType='" & vRank & "'"
        End If
        dr = cm.ExecuteReader

        If dr.Read Then
            If Not IsDBNull(dr("OtPer")) Then vFactor = dr("OtPer")
            If Not IsDBNull(dr("UOM")) Then vUOM = dr("UOM")
            If vUOM = 1 Then    'unit of measure is by amount, reset rate/hr to 1 peso only
                vRateHr = 1
            End If
        ElseIf Not dr.HasRows And Not _2ndPass Then    'no record found, use default settings 
            _2ndPass = True
            dr.Close()
            GoTo def
        End If
        dr.Close()
        'Else
        '    vFactor = 1     'factor rate is 100% only
        '    pCode = "G1"    'convert Regular Overtime to Regular Overtime with Leave code
        'End If

        'ADD NEW DATA
        If vLateFiledOT Or vLateFiledDTR Then
            Dim vOldHrs As Decimal = 0
            Dim vAdjHrs As Decimal = 0
            Try
                vOldHrs = vTrans(pCode)
            Catch ex As system.exception   'index does not exist
                vOldHrs = 0
            End Try
            vAdjHrs = pHrs - vOldHrs
            vAmtConv = Math.Round(vFactor * vAdjHrs * vRateHr, 2)
            If vAmtConv <> 0 Then
                cm.CommandText = "insert into py_time_log_dtl (Emp_Cd,TranDate,TranCd,Hrs_Rendered,AmtConv,Reason," & _
                    "LateFiled,EffectivityDate) values ('" & pID & "','" & Format(pDate, "yyyy/MM/dd") & "','" & pCode & "'," & _
                    vAdjHrs & "," & vAmtConv & ",'Auto-generated',1,'" & _
                    Format(vEffectivityDate, "yyyy/MM/dd") & "')"
            End If
        Else
            vAmtConv = Math.Round(vFactor * pHrs * vRateHr, 2)
            If vAmtConv <> 0 Then
                cm.CommandText = "insert into py_time_log_dtl (Emp_Cd,TranDate,TranCd,Hrs_Rendered,AmtConv,Reason," & _
                    "LateFiled,EffectivityDate) values ('" & pID & "','" & Format(pDate, "yyyy/MM/dd") & "','" & pCode & "'," & _
                    pOrgHrs & "," & vAmtConv & ",'Auto-generated',0,'" & _
                    Format(pDate, "yyyy/MM/dd") & "')"
            End If
        End If
        cm.ExecuteNonQuery()
        cm.Dispose()
    End Sub

    Private Function AdjustGrace(ByVal pValue As Object, ByVal pGrace As Single) As String
        Dim vHr As Single
        Dim vMin As Single

        vHr = 0 : vMin = 0
        If pGrace > 59 Then
            vHr = pGrace / 60
            vMin = pGrace Mod 60
        Else
            vMin = pGrace
        End If
        vHr = vHr + Hour(pValue)
        vMin = vMin + Minute(pValue)
        AdjustGrace = Format(vHr, "00") & ":" & Format(vMin, "00") & ":00"
    End Function
    Private Function CheckRegular(ByVal pDate As Date, ByVal pID As String, ByRef c As sqlclient.sqlconnection) As String
        Dim vTardy As Single = 0
        Dim vUndertime As Single = 0
        Dim vHr As Single = 0
        Dim vMin As Single = 0
        Dim vFactor As Single = 0
        Dim vNDTime As Date = CDate(pDate & " 22:00:00")
        Dim cm As New sqlclient.sqlcommand
        Dim dr As sqlclient.sqldatareader
        Dim vLeaveDays As Integer = 0
        Dim vDistance As Integer = 0
        Dim vBalance As Decimal = vDaysLeave
        Dim vReturn As String = ""

        Try
            cm.Connection = c

            If vIn <= vRegIn Then vIn = vRegIn 'adjust vin to regular in

            'disable grace period
            'vRegIn = CDate(Format(vRegIn, "yyyy/MM/dd") & " " & AdjustGrace(vRegIn, vGrace))

            If vIn > vRegIn Then   'TARDY 
                'check if vin falls on 2nd half or 1st half of the day
                Dim v2ndHalf As Date = vRegIn.AddHours(vReqHrs / 2)

                vTardy = Math.Round(Math.Abs(DateDiff(DateInterval.Minute, vIn, vRegIn)), 2)
                If vIn >= v2ndHalf Then 'actual in falls on 2nd half of the day, deduct the break hours from tardy
                    vTardy -= (vBreak * 60)
                End If
                'now check in tardiness table
                cm.CommandText = "select * from py_tardiness_table where " & _
                    vTardy & " between FromMinutes and ToMinutes"
                dr = cm.ExecuteReader

                vFactor = 1    'DEFAULT TO 100%
                If dr.Read Then
                    vFactor = dr("Factor")
                    If dr("RoundTo") Then
                        If Not IsDBNull(dr("RoundedTo")) Then vTardy = dr("RoundedTo")
                    End If
                End If
                dr.Close()

                vTardy = (vTardy * vFactor) / 60
                If vTardy > 0 Then
                    If vBalance >= vTardy Then  'hours leave is still greater than tardiness, remove the tardiness and updat the balance
                        vBalance -= vTardy
                        vTardy = 0
                    ElseIf vBalance > 0 And vBalance < vTardy Then    'days leave is less than tardiness,reduce tardiness by hours leave and zero out the hour leave afterwards
                        '''''''''''' code inserted by vic on 6/25/2009 ''''''''''''
                        vTardy -= vBalance
                        vBalance = 0
                    End If
                End If
            End If

            If vOut < vRegOut Then      'check for undertime 
                vUndertime = Math.Round(DateDiff(DateInterval.Minute, vOut, vRegOut) / 60, 2)
                If vUndertime > 0 Then
                    If vBalance >= vUndertime Then 'hours leave is still greater than tardiness, remove the tardiness and updat the balance
                        vBalance -= vUndertime
                        vUndertime = 0
                    ElseIf vBalance > 0 And vBalance < vUndertime Then    'days leave is less than tardiness,reduce tardiness by hours leave and zero out the hour leave afterwards
                        '''''''''''' code inserted by vic on 6/25/2009 ''''''''''''
                        vUndertime -= vBalance
                        vBalance = 0
                    End If
                End If
            ElseIf vOut > vRegOut And vCanOT Then    'with overtime
                Dim vNDHrs As Decimal = 0
                Dim vNDEndTime As Date = CDate(pDate.AddDays(1) & " 6:00:00")
                Dim vUBound As Date = vRegOut.AddHours(vOtHrs)
                Dim vNDActualStart As Date = Nothing
                Dim vNDActualEnd As Date = Nothing

                If vOut < vUBound Then  'adjust upper bound if actual out is less than approved ot
                    vUBound = vOut
                End If
                vHours = Math.Round(DateDiff(DateInterval.Minute, vRegOut, vUBound) / 60, 2)
                vHours = Int(vHours) + RoundOff(vHours - Int(vHours))   'round off the minutes side


                'check night differential
                If vRegIn >= vNDTime Or vRegOut >= vNDTime Then   'regular schedule has night differential
                    vNDActualStart = IIf(vRegIn > vNDTime, vRegIn, vNDTime)
                    vNDActualStart = IIf(vIn > vNDActualStart, vIn, vNDActualStart)
                    vNDActualEnd = IIf(vRegOut > vNDEndTime, vNDEndTime, vRegOut)
                    vNDActualEnd = IIf(vOut > vNDActualEnd, vNDActualEnd, vOut)

                    vNDHrs = Math.Round(DateDiff(DateInterval.Minute, vNDActualStart, vNDActualEnd) / 60, 2)
                    vNDHrs = Int(vNDHrs) + RoundOff(vNDHrs - Int(vNDHrs))     'round off the minutes side
                    WriteLog("A4", vNDHrs, pID, pDate, vNDHrs, c)    'ND OT
                End If

                If vHours >= vOtAfter Then  'overtime is eligible
                    WriteLog("A1", vHours, pID, pDate, vHours, c)   'OT Regular
                    'check if overtime falls on night differential
                    If vUBound > vNDTime Then  'out falls on night diff ot
                        vNDActualStart = IIf(vRegOut > vNDTime, vRegOut, vNDTime)
                        vNDHrs = Math.Round(DateDiff(DateInterval.Minute, vNDActualStart, _
                            IIf(vUBound > vNDEndTime, vNDEndTime, vUBound)) / 60, 2)
                        vNDHrs = Int(vNDHrs) + RoundOff(vNDHrs - Int(vNDHrs))     'round off the minutes side
                        WriteLog("A2", IIf(vNDHrs > 2, 2, vNDHrs), pID, pDate, IIf(vNDHrs > 2, 2, vNDHrs), c)    'ND OT
                        If vNDHrs > 2 Then WriteLog("A3", vNDHrs - 2, pID, pDate, vNDHrs - 2, c) 'ND OT excess of 2 hours
                    End If
                End If
            End If

            'check if there's a filed leave without pay
            Dim vDaysLeaveNoPay As Decimal = 0

            cm.CommandText = "select DaysLeave from hr_leave_application where Emp_Cd='" & _
                pID & "' and StartDate='" & Format(pDate, "yyyy/MM/dd") & _
                "' and Void=0 and Paid=0 and DateApproved is not null and EffectivityDate is null"
            dr = cm.ExecuteReader
            If dr.Read Then
                If Not IsDBNull(dr("DaysLeave")) Then
                    vDaysLeaveNoPay = dr("DaysLeave") * 8
                End If
            End If
            dr.Close()
            cm.Dispose()

            'write undertime and tardiness        
            If vTardy > 0 Then
                If vDaysLeaveNoPay > 0 Then
                    If vDaysLeaveNoPay > vTardy Then    'applied leave is more than incurred tardiness, reset the leave to tardiness value
                        vDaysLeaveNoPay = vTardy
                    End If
                    WriteLog("ABSENT", vDaysLeaveNoPay, pID, pDate, vDaysLeaveNoPay, c)
                    vTardy -= vDaysLeaveNoPay
                    vDaysLeaveNoPay = 0     'reset back to zero since it was already written to the database
                    If vTardy > 0 Then  'double check if there is still tardiness despite the absent without leave application
                        WriteLog("TARD", vTardy, pID, pDate, vTardy, c)
                    End If
                Else
                    WriteLog("TARD", vTardy, pID, pDate, vTardy, c)
                End If
            End If
            If vUndertime > 0 Then
                'double check if there is still values in vdaysleavenopay variable
                If vDaysLeaveNoPay > 0 Then
                    If vDaysLeaveNoPay > vUndertime Then
                        vDaysLeaveNoPay = vUndertime
                    End If
                    WriteLog("ABSENT", vDaysLeaveNoPay, pID, pDate, vDaysLeaveNoPay, c)
                    vUndertime -= vDaysLeaveNoPay
                    vDaysLeaveNoPay = 0     'reset back to zero since it was already written to the database
                    If vUndertime > 0 Then  'double check if there is still undertime despite the absent without leave application
                        WriteLog("UT", vUndertime, pID, pDate, vUndertime, c)
                    End If
                Else
                    WriteLog("UT", vUndertime, pID, pDate, vUndertime, c)
                End If
            End If
        Catch ex As system.exception
            vReturn = "Error code while processing Overtime, Absences and Tardiness in Check Regular module.  " & _
                "Error is: " & ex.Message.Replace(vbCrLf, "\n")
            Return vReturn
            Exit Function
        End Try
        vReturn = ""
        Return vReturn
        Exit Function
    End Function
End Class
