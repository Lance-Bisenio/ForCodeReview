Imports denaro
Partial Class modifyref
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Dim c As New SqlClient.SqlConnection
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If
        If Not IsPostBack Then
            Dim cm As New sqlclient.sqlcommand
            Dim dr As sqlclient.sqldatareader
            txtEmpCd.Text = Session("empid")
            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c
            cm.CommandText = "select Emp_Lname,Emp_Fname from py_emp_master where Emp_Cd='" & txtEmpCd.Text & "'"
            dr = cm.ExecuteReader
            lblcaption.text = "Add/Modify Character Reference for "
            If dr.Read Then
                lblcaption.Text += dr("Emp_Lname") & ", " & dr("Emp_Fname")
            End If
            dr.Close()

            If Session("mode") = "e" Then
                cm.CommandText = "select * from hr_emp_reference where Emp_Cd='" & txtEmpCd.Text & _
                    "' and SeqId=" & Session("seqid")
                dr = cm.ExecuteReader
                If dr.Read Then
                    txtSeq.Text = dr("SeqId")
                    txtName.Text = dr("FullName")
                    txtPosition.Text = dr("Position")
                    txtTel.Text = dr("Contact_No")
                    txtAddress.Text = dr("Address")
                End If
                dr.Close()
            End If
            cm.Dispose()
            c.Close()
        End If
    End Sub

    Protected Sub cmdCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        Session.Remove("empid")
        Session.Remove("mode")
        Session.Remove("seqid")
        'Server.Transfer("emp.aspx")
        vScript = "window.close();"
    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        Dim cm As New sqlclient.sqlcommand
        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c
        If Session("mode") = "e" Then 'edit mode
            cm.CommandText = "update hr_emp_reference set FullName='" & txtName.Text & _
                "',Position='" & txtPosition.Text & _
                "',Contact_No='" & txtTel.Text & _
               "',Address='" & txtAddress.Text & _
                "' where Emp_Cd='" & txtEmpCd.Text & "' and SeqId=" & txtSeq.Text
        Else                          'add mode
            cm.CommandText = "insert into hr_emp_reference (Emp_Cd,SeqId,FullName,Position," & _
                "Contact_No,Address) values ('" & txtEmpCd.Text & "'," & txtSeq.Text & _
                ",'" & txtName.Text & "','" & txtPosition.Text & "','" & txtTel.Text & _
                "','" & txtAddress.Text & "')"
        End If
        cm.ExecuteNonQuery()
        vScript = "alert('Changes where successfully saved.');"
    End Sub

End Class
