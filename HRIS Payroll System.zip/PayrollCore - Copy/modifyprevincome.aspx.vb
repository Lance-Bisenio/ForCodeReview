﻿Imports denaro.fis
Partial Class modifyprevincome
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            vScript = "alert('Your login session has expired. Please re-login again.'); window.close();"
            Exit Sub
        End If
        If Not IsPostBack Then
            Dim c As New SqlClient.SqlConnection(connStr)
            Dim cm As New SqlClient.SqlCommand
            Dim rs As SqlClient.SqlDataReader
            lblCaption.Text = "Add/Edit Previous Employer Income"

            Try
                c.Open()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to connect to database. Error is: " & ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                c.Dispose()
                cm.Dispose()
                Exit Sub
            End Try

            cm.Connection = c
            BuildCombo("select Emp_Cd,Emp_Lname+', '+Emp_Fname as Name from py_emp_master order by Emp_Lname,Emp_Fname", cmbEmpID, c)

            cmbYear.Items.Clear()
            cmbYear.Items.Add(Now.Year - 1)
            cmbYear.Items.Add(Now.Year)
            cmbYear.SelectedValue = Now.Year - 1

            If Request.Item("m") = "e" Then 'edit mode
                If Session("empid") = "" Or Session("year") = "" Then
                    vScript = "alert('You must first select a record to edit.'); window.close();"
                Else
                    cmbEmpID.Enabled = False
                    cmbYear.Enabled = False
                    cm.CommandText = "select * from py_prev_employer_income where Emp_Cd='" & Session("empid") & _
                        "' and YearCd=" & Session("year")
                    Try
                        rs = cm.ExecuteReader
                        If rs.Read Then
                            cmbEmpID.SelectedValue = rs("Emp_Cd")
                            cmbYear.SelectedValue = rs("YearCd")
                            txtGrossTax.Text = rs("GrossTaxable")
                            txtGrossNonTax.Text = rs("GrossNonTax")
                            txt13Tax.Text = rs("Tax13th")
                            txt13NonTax.Text = rs("NonTax13th")
                            txtContri.Text = rs("NonTaxSSS")
                            txtTax.Text = rs("TaxWithheld")
                        End If
                        rs.Close()
                    Catch ex As SqlClient.SqlException
                        vScript = "alert('Error occurred while trying to retrieve record. Error is: " & _
                            ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                    End Try
                End If                
            End If
            c.Close()
            c.Dispose()
            cm.Dispose()
        End If
    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        If Not IsNumeric(txtGrossTax.Text) Then
            vScript = "alert('You must enter a valid number format for Gross Taxable amount field. Please try again.');"
            Exit Sub
        End If
        If Not IsNumeric(txtGrossNonTax.Text) Then
            vScript = "alert('You must enter a valid number format for Gross Non-Taxable amount field. Please try again.');"
            Exit Sub
        End If
        If Not IsNumeric(txt13Tax.Text) Then
            vScript = "alert('You must enter a valid numer format for 13th month and other Income Taxable field. Please try again.');"
            Exit Sub
        End If
        If Not IsNumeric(txt13NonTax.Text) Then
            vScript = "alert('You must enter a valid numer format for 13th month and other Income Non-Taxable field. Please try again.');"
            Exit Sub
        End If
        If Not IsNumeric(txtContri.Text) Then
            vScript = "alert('You must enter a valid number format for SSS,Pagibig,PHIC contribution amount field. Please try again.');"
            Exit Sub
        End If
        If Not IsNumeric(txtTax.Text) Then
            vScript = "alert('You must enter a valid number format for Withholding tax amount field. Please try again.');"
            Exit Sub
        End If

        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand

        txtGrossTax.Text = txtGrossTax.Text.Replace(",", "")
        txtGrossNonTax.Text = txtGrossNonTax.Text.Replace(",", "")
        txt13NonTax.Text = txt13NonTax.Text.Replace(",", "")
        txt13Tax.Text = txt13Tax.Text.Replace(",", "")
        txtContri.Text = txtContri.Text.Replace(",", "")
        txtTax.Text = txtTax.Text.Replace(",", "")

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        cm.Connection = c

        If Request.Item("m") = "a" Then 'add mode
            cm.CommandText = "insert into py_prev_employer_income (Emp_Cd,YearCd,GrossTaxable,GrossNonTax,Tax13th," & _
                "NonTax13th,NonTaxSss,TaxWithheld) values ('" & cmbEmpID.SelectedValue & "'," & cmbYear.SelectedValue & _
                "," & Val(txtGrossTax.Text) & "," & Val(txtGrossNonTax.Text) & "," & Val(txt13Tax.Text) & _
                "," & Val(txt13NonTax.Text) & "," & Val(txtContri.Text) & "," & Val(txtTax.Text) & ")"
        Else                            'edit mode
            cm.CommandText = "update py_prev_employer_income set GrossTaxable=" & Val(txtGrossTax.Text) & _
                ",GrossNonTax=" & Val(txtGrossNonTax.Text) & _
                ",Tax13th=" & Val(txt13Tax.Text) & _
                ",NonTax13th=" & Val(txt13NonTax.Text) & _
                ",NonTaxSss=" & Val(txtContri.Text) & _
                ",TaxWithheld=" & Val(txtTax.Text) & _
                " where Emp_Cd='" & cmbEmpID.SelectedValue & _
                "' and YearCd=" & cmbYear.SelectedValue
        End If
        Try
            cm.ExecuteNonQuery()
            vScript = "alert('Changes were successfully saved. Click the Refresh button to refresh the list.'); window.close();"
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to save changes. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            c.Dispose()
            cm.Dispose()
        End Try
    End Sub
End Class
