Imports denaro
Partial Class postsumm
    Inherits System.Web.UI.Page
    Public vScript As String = "window.focus();"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            vScript = "alert('Your login session has expired. Please re-login again.'); window.close();"
            Exit Sub
        End If

        If Not IsPostBack Then
            Dim c As New SqlClient.SqlConnection(connStr)
            Dim cm As New SqlClient.SqlCommand
            Dim dr As SqlClient.SqlDataReader
            Dim iCtr As Integer = 0
            lblCaption.Text = "Summarize Daily Logsheet"

            Try
                c.Open()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                c.Dispose()
                cm.Dispose()
                Exit Sub
            End Try

            cm.Connection = c
            cm.CommandText = "select OtCd,Descr from py_ot_ref"
            Try
                dr = cm.ExecuteReader
                Do While dr.Read
                    chkOT.Items.Add(dr("OtCd") & "=>" & dr("Descr"))
                    chkOT.Items(iCtr).Selected = True
                    iCtr += 1
                Loop
                dr.Close()
                txtPostDate.Text = Session("postdate")
                lblFrom.Text = Session("startdate")
                lblTo.Text = Session("enddate")
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to retrieve OT reference. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            Finally
                cm.Dispose()
                c.Close()
                c.Dispose()
            End Try
        End If
    End Sub

    Protected Sub cmdCancel_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCancel.Init
        cmdCancel.Attributes.Add("onclick", "javascript:window.close();")
    End Sub

    Protected Sub cmdDeselect_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDeselect.Click
        SetState(False)
    End Sub

    Protected Sub cmdSelect_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSelect.Click
        SetState(True)
    End Sub
    Private Sub SetState(ByVal pState As Boolean)
        Dim iCtr As Integer = 0

        For iCtr = 0 To chkOT.Items.Count - 1
            chkOT.Items(iCtr).Selected = pState
        Next iCtr
    End Sub

    Protected Sub cmdPost_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdPost.Click
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim dr As SqlClient.SqlDataReader
        Dim vList As String = ""
        Dim iCtr As Integer
        Dim vOTList As String = ""

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        cm.Connection = c
        cm.CommandText = Session("sql")

        Try
            dr = cm.ExecuteReader
            Do While dr.Read
                vList += dr("Emp_Cd") & ","
            Loop
            If vList <> "" Then
                vList = vList.Substring(0, vList.Length - 1)
            End If
            dr.Close()
            'process the data
            'get list of checked ot
            For iCtr = 0 To chkOT.Items.Count - 1
                If chkOT.Items(iCtr).Selected Then
                    vOTList += ExtractData(chkOT.Items(iCtr).Text) & ","
                End If
            Next iCtr
            If vOTList <> "" Then
                vOTList = "'" & vOTList.Substring(0, vOTList.Length - 1) & "'"
                vOTList = vOTList.Replace(",", "','")
                Summarize(vList, vOTList, c)
            End If
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to retrieve records. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            c.Dispose()
            cm.Dispose()
        End Try
    End Sub
    Private Sub Summarize(ByVal pEmpList As String, ByVal pOTList As String, ByRef c As SqlClient.SqlConnection)
        Dim cm As New SqlClient.SqlCommand
        Dim cmInsert As New SqlClient.SqlCommand
        Dim dr As SqlClient.SqlDataReader
        Dim vEmp() As String = pEmpList.Split(",")
        Dim iCtr As Integer
        Dim vDaysWorked As Integer = 0
        Dim vHourlyRate As Decimal = 0

        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                                      ''
        '' DATE MODIFIED: 4/2/2013                                           ''
        '' PURPOSE: VARIABLE TO DETERMINE IF THE EMPLOYEE HAS CUMULATIVE     ''
        ''          GRACE PERIOD OR NOT.                                     ''
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        Dim vCumulativeGrace As Boolean = False
        Dim vGracePeriod As Decimal = 0
        '''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''''''

        cm.Connection = c
        cmInsert.Connection = c

        'delete existing transaction based on post date
        cm.CommandText = "delete from py_emp_time_log where TranDate='" & Format(CDate(txtPostDate.Text), "yyyy/MM/dd") & _
            "' and Emp_Cd in ('" & pEmpList.Replace(",", "','") & "') and TranCd in (" & pOTList & ")"
        Try
            cm.ExecuteNonQuery()
            For iCtr = 0 To vEmp.Length - 1
                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY:  VIC GATCHALIAN                             ''
                '' DATE MODIFIED: 4/2/2013                                  ''
                '' PURPOSE: TO GET THE STATUS OF EMPLOYEE IF HE HAS         ''
                ''          CUMULATIVE GRACE OR NOT.                        ''
                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                vCumulativeGrace = False
                vGracePeriod = 0
                cm.CommandText = "select CumulativeGrace,GracePeriod from py_emp_master where Emp_Cd='" & vEmp(iCtr) & "'"
                dr = cm.ExecuteReader
                If dr.Read Then
                    vCumulativeGrace = dr("CumulativeGrace") = 1
                    vGracePeriod = dr("GracePeriod")
                End If
                dr.Close()
                ''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''

                'insert # of days to be paid for daily paid employees only
                cm.CommandText = "select count(*) from py_emp_time_sched where Emp_Cd='" & vEmp(iCtr) & _
                    "' and Date_Sched between '" & Format(CDate(lblFrom.Text), "yyyy/MM/dd") & "' and '" & _
                    Format(CDate(lblTo.Text), "yyyy/MM/dd") & "' and Start_Time is not null" 'and exists " & _
                '"(select Emp_Cd from py_time_log where Tran_Date=Date_Sched and Emp_Cd='" & _
                'rs("Emp_Cd") & "' and Time_In is not null)"

                dr = cm.ExecuteReader
                vDaysWorked = 0
                If dr.Read Then
                    If Not IsDBNull(dr(0)) Then vDaysWorked = dr(0)
                End If
                dr.Close()
                cmInsert.CommandText = "insert into py_emp_time_log (Emp_Cd,Agency_Cd,TranDate,TranCd," & _
                    "Hrs_Rendered,AmtConv,Reason,FromDate,ToDate,PostedBy,DatePosted) values ('" & vEmp(iCtr) & "','','" & _
                    Format(CDate(txtPostDate.Text), "yyyy/MM/dd") & "','BASIC'," & _
                    vDaysWorked & ",0,'Auto-posted','" & Format(CDate(lblFrom.Text), "yyyy/MM/dd") & _
                    "','" & Format(CDate(lblTo.Text), "yyyy/MM/dd") & "','" & Session("uid") & _
                    "','" & Format(Now, "yyyy/MM/dd HH:mm:ss") & "')"
                cmInsert.ExecuteNonQuery()

                cm.CommandText = "select Rate_Day from py_emp_master where Emp_Cd='" & vEmp(iCtr) & "'"
                dr = cm.ExecuteReader
                If dr.Read Then
                    vHourlyRate = dr("Rate_Day") / 8
                End If
                dr.Close()

                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY:  VIC GATCHALIAN                                           ''
                '' DATE MODIFIED: 4/2/2013                                                ''
                '' PURPOSE: TO REMOVE THE TARDINESS AND UNDERTIME IF THE EMPLOYEE IS      ''
                ''          TAGGED FOR CUMULATIVE GRACE PERIOD.                           ''
                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                If vCumulativeGrace Then
                    pOTList = pOTList.Replace(",'TARD'", "")    'REMOVE THE TARDINESS FROM THE LIST 
                    pOTList = pOTList.Replace(",'UT'", "")      'REMOVE THE UNDERTIME FROM THE LIST
                End If
                '''''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''''''''

                cm.CommandText = "select TranCd,sum(Hrs_Rendered) as TotHrs,sum(AmtConv) as TotAmt " & _
                    "from py_time_log_dtl where Trandate between '" & Format(CDate(lblFrom.Text), "yyyy/MM/dd") & _
                    "' and '" & Format(CDate(lblTo.Text), "yyyy/MM/dd") & "' and Emp_Cd='" & vEmp(iCtr) & _
                    "' and TranCd in (" & pOTList & ") group by TranCd"
                dr = cm.ExecuteReader
                Do While dr.Read
                    cmInsert.CommandText = "insert into py_emp_time_log (Emp_Cd,Agency_Cd,TranDate,TranCd," & _
                        "Hrs_Rendered,AmtConv,Rate_Hour,Reason,FromDate,ToDate,PostedBy,DatePosted) values ('" & vEmp(iCtr) & "','','" & _
                        Format(CDate(txtPostDate.Text), "yyyy/MM/dd") & "','" & dr("TranCd") & "'," & _
                        Math.Round(dr("TotHrs"), 2) & "," & Math.Round(dr("TotAmt"), 2) & "," & vHourlyRate & ",'Auto-posted','" & _
                        Format(CDate(lblFrom.Text), "yyyy/MM/dd") & "','" & Format(CDate(lblTo.Text), "yyyy/MM/dd") & _
                        "','" & Session("uid") & "','" & Format(Now, "yyyy/MM/dd HH:mm:ss") & "')"
                    cmInsert.ExecuteNonQuery()
                Loop
                dr.Close()

                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY: VIC GATCHALIAN                                            ''
                '' DATE MODIFIED: 4/2/2013                                                ''
                '' PURPOSE: TO CHECK THE CUMULATIVE GRACE PERIOD FOR TARDINESS AND UT     ''
                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                If vCumulativeGrace Then
                    cm.CommandText = "select sum(Hrs_Rendered) as TotHrs,sum(AmtConv) as TotAmt " & _
                        "from py_time_log_dtl where Trandate between '" & Format(CDate(lblFrom.Text), "yyyy/MM/dd") & _
                        "' and '" & Format(CDate(lblTo.Text), "yyyy/MM/dd") & "' and Emp_Cd='" & vEmp(iCtr) & _
                        "' and TranCd in ('TARD','UT')"
                    dr = cm.ExecuteReader
                    If dr.Read Then
                        If Not IsDBNull(dr("TotHrs")) Then
                            If dr("TotHrs") > vGracePeriod / 60 Then
                                cmInsert.CommandText = "insert into py_emp_time_log (Emp_Cd,Agency_Cd,TranDate,TranCd," & _
                                    "Hrs_Rendered,AmtConv,Rate_Hour,Reason,FromDate,ToDate,PostedBy,DatePosted) values ('" & vEmp(iCtr) & "','','" & _
                                    Format(CDate(txtPostDate.Text), "yyyy/MM/dd") & "','TARD'," & _
                                    Math.Round(dr("TotHrs"), 2) & "," & Math.Round(dr("TotAmt"), 2) & "," & _
                                    vHourlyRate & ",'Auto-posted','" & Format(CDate(lblFrom.Text), "yyyy/MM/dd") & "','" & _
                                    Format(CDate(lblTo.Text), "yyyy/MM/dd") & _
                                    "','" & Session("uid") & "','" & Format(Now, "yyyy/MM/dd HH:mm:ss") & "')"
                                cmInsert.ExecuteNonQuery()
                            End If
                        End If
                    End If
                    dr.Close()
                End If
                ''''''''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''''''
            Next iCtr

            vScript = "alert('Posting complete!'); " & _
                "document.getElementById('divWait').style.visibility='hidden';" & _
                "window.close();"
        Catch ex As SqlClient.SqlException
            Response.Write("Error in SQL statement.<br>" & ex.Message)
        End Try
        cm.Dispose()
        cmInsert.Dispose()
    End Sub
    Protected Sub cmdPost_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdPost.Init
        cmdPost.Attributes.Add("onclick", "javascript:document.getElementById('divWait').style.visibility='visible';")
    End Sub
End Class
