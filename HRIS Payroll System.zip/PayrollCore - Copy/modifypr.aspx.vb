Imports denaro
Partial Class modifypr
    Inherits System.Web.UI.Page
    Dim c As New sqlclient.sqlconnection
    Public vScript As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If

        If Not IsPostBack Then
            lblcaption.text = "Add/Modify Personnel Requisition"
            Dim cm As New sqlclient.sqlcommand
            Dim dr As sqlclient.sqldatareader
            Dim vRc As String = ""
            Dim vOfc As String = ""
            Dim vDiv As String = ""
            Dim vDept As String = ""
            Dim vSection As String = ""
            Dim vUnit As String = ""
            Dim vPos As String = ""
            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c

            cm.CommandText = "select * from hr_hiring_request where Request_No=" & _
                Session("reqno")
            dr = cm.ExecuteReader
            If dr.Read Then
                txtRequestNo.Text = dr("Request_No")
                txtRequestedBy.Text = dr("Requested_By")
                txtRequestDate.Text = dr("Date_Requested")
                txtDateRequired.Text = IIf(IsDBNull(dr("Date_Required")), "", dr("Date_Required"))
                vRc = dr("Rc_Cd")
                vOfc = dr("Office_Cd")
                vDiv = dr("Div_Cd")
                vDept = dr("Dept_Cd")
                vSection = dr("Section_Cd")
                vUnit = dr("Unit_Cd")
                vPos = dr("Position_Cd")
                txtNoStaff.Text = dr("Number_Needed")
                txtsalary.Text = IIf(IsDBNull(dr("Rate")), 0, dr("Rate"))
                txtRemarks.Text = IIf(IsDBNull(dr("Remarks")), "", dr("Remarks"))
                txtPeriod.Text = IIf(IsDBNull(dr("Emp_Period")), "", dr("Emp_Period"))
                Select Case dr("Sex")
                    Case 0 : txtSex.Text = "Female"
                    Case 1 : txtSex.Text = "Male"
                    Case 2 : txtSex.Text = "Any"
                End Select
            End If
            dr.Close()
            cm.CommandText = "select Emp_Cd,Emp_Lname,Emp_Fname from py_emp_master where Emp_Cd='" & _
                txtRequestedBy.Text & "'"
            dr = cm.ExecuteReader
            If dr.Read Then
                txtRequestedBy.Text = dr("Emp_Cd") & "=>" & dr("Emp_Lname") & ", " & _
                    dr("Emp_Fname")
            End If

            dr.Close()
            cm.Dispose()
            c.Close()
            BuildCombo("select Pos_Cd,Position from py_position_ref order by Position", cmbPos, vPos)
            BuildCombo("select Rc_Cd,Descr from rc order by Descr", cmbRc, vRc)
            BuildCombo("select AgencyCd,AgencyName from agency order by AgencyName", cmbOfc, vOfc)
            BuildCombo("select Div_Cd,Descr from hr_div_ref order by Descr", cmbDiv, vDiv)
            BuildCombo("select Dept_Cd,Descr from hr_dept_ref order by Descr", cmbDept, vDept)
            BuildCombo("select Section_Cd,Descr from hr_section_ref order by Descr", cmbSection, vSection)
            BuildCombo("select Unit_Cd,Descr from hr_unit_ref order by Descr", cmbUnit, vUnit)
        End If
    End Sub
    Private Sub BuildCombo(ByVal pSql As String, ByVal pCombo As Web.UI.WebControls.DropDownList, _
        Optional ByVal pValue As String = "")
        Dim cm As New sqlclient.sqlcommand
        Dim dr As sqlclient.sqldatareader
        Dim vSelected As String = ""
        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c
        cm.CommandText = pSql
        dr = cm.ExecuteReader
        pCombo.Items.Clear()
        Do While dr.Read
            pCombo.Items.Add(dr(0) & "=>" & dr(1))
            If dr(0) = pValue Then
                vSelected = dr(0) & "=>" & dr(1)
            End If
        Loop
        dr.Close()
        cm.Dispose()
        c.Close()
        If vSelected <> "" Then
            pCombo.SelectedValue = vSelected
        End If
    End Sub
End Class
