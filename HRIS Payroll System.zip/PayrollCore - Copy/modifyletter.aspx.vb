Imports denaro
Partial Class modifyletter
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Dim c As New sqlclient.sqlconnection
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            lblCaption.Text = "Add/Modify Letter template"
            txtDate.Text = Now
            If Session("mode") = "e" Then
                Dim cm As New sqlclient.sqlcommand
                Dim dr As sqlclient.sqldatareader

                c.ConnectionString = connStr
                c.Open()
                cm.Connection = c
                cm.CommandText = "select * from hr_letter_hdr where Letter_Cd='" & _
                    Session("lettercd") & "'"
                dr = cm.ExecuteReader
                If dr.Read Then
                    txtLetterCd.Text = dr("Letter_Cd")
                    txtDescr.Text = dr("Letter_Name")
                    txtContent.Text = dr("Letter_Content")
                End If
                dr.Close()
                cm.Dispose()
                c.Close()
            End If
        End If
    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        Dim cm As New sqlclient.sqlcommand
        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c

        If Session("mode") = "e" Then
            cm.CommandText = "update hr_letter_hdr set Letter_Cd='" & txtLetterCd.Text & _
                "',Letter_Name='" & txtDescr.Text & _
                "',Letter_Content='" & txtContent.Text.Replace("'", "`") & _
                "',Last_Date_Updated='" & Format(CDate(txtDate.Text), "yyyy/MM/dd") & _
                "' where Letter_Cd='" & Session("lettercd") & "'"
        Else
            cm.CommandText = "insert into hr_letter_hdr (Letter_Cd,Letter_Name,Last_Date_Updated,Letter_Content) " & _
                "values ('" & txtLetterCd.Text & "','" & txtDescr.Text & "','" & _
                Format(CDate(txtDate.Text), "yyyy/MM/dd") & "','" & txtContent.Text.Replace("'", "`") & "')"
        End If
        'Response.Write(cm.CommandText)
        cm.ExecuteNonQuery()
        c.Close()
        cm.Dispose()
        Server.Transfer("letterref.aspx")
        vScript = "alert('Changes were successfully saved.');"
    End Sub

    Protected Sub cmdCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        Server.Transfer("letterref.aspx")
    End Sub
End Class
