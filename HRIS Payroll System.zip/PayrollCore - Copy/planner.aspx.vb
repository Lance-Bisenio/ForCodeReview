﻿Imports denaro.fis
Partial Class planner
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            cmbYear.Items.Clear()
            For i As Integer = Now.Year - 10 To Now.Year + 5
                cmbYear.Items.Add(i)
            Next

            cmbYear.SelectedValue = Now.Year
            cmbMonth.SelectedValue = Now.Month

        End If
    End Sub

    Protected Sub cmbMonth_Init(sender As Object, e As EventArgs) Handles cmbMonth.Init
        cmbMonth.Attributes.Add("onchange", "PopulateDays();")
    End Sub

    Protected Sub cmbYear_Init(sender As Object, e As EventArgs) Handles cmbYear.Init
        cmbYear.Attributes.Add("onchange", "PopulateDays();")
    End Sub

End Class
