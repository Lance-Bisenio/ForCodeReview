Imports denaro
Partial Class payroll
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    
   

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If

        If Not CanRun(Session("caption"), Request.Item("id")) Then
            Session("denied") = "1"
            Server.Transfer("main.aspx")
            Exit Sub
        End If

        If Not IsPostBack Then
            lblCaption.Text = "Generate Payroll"
            
            cmbMonth.SelectedValue = Now.Month

            Dim c As New SqlClient.SqlConnection(connStr)
            Dim cm As New SqlClient.SqlCommand
            Dim dr As SqlClient.SqlDataReader

            Try
                c.Open()
            Catch ex As sqlclient.sqlException
                vScript = "alert('Error occurred while trying to connect to SQL Server. Error is: " & _
                    ex.Message.Replace(vbCrLf, "\n").Replace("'", "\'") & "');"
                c.Dispose()
                cm.Dispose()
                Exit Sub
            End Try

            BuildCombo("select Status_Code,Descr from py_employee_stat order by Descr", cmbEmpStatus, c)
            BuildCombo("select Pay_Cd,Payment from py_pay_mode order by Payment", cmbPayMode, c)
            BuildCombo("select Rc_Cd,Descr from rc where exists (select User_Id from rights_list where User_Id='" & _
                    Session("uid") & "' and property='rc' and Property_Value=Rc_Cd) order by Descr", cmbRC, c)
            BuildCombo("select AgencyCd,AgencyName from agency where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='agency' and Property_Value=AgencyCd) order by AgencyName", cmbOfc, c)
            BuildCombo("select Div_Cd,Descr from hr_div_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='division' and Property_Value=Div_Cd) order by Descr", cmbDiv, c)
            BuildCombo("select Dept_Cd,Descr from hr_dept_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='department' and Property_Value=Dept_Cd) order by Descr", cmbDept, c)
            BuildCombo("select Section_Cd,Descr from hr_section_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='section' and Property_Value=Section_Cd) order by Descr", cmbSection, c)
            BuildCombo("select Unit_Cd,Descr from hr_unit_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='unit' and Property_Value=Unit_Cd) order by Descr", cmbUnit, c)
            BuildCombo("select EmploymentType,Descr from hr_employment_type where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='employmenttype' and Property_Value=EmploymentType) order by Descr", cmbEmpType, c)

            cmbRC.Items.Add("All")
            cmbRC.SelectedValue = "All"
            cmbOfc.Items.Add("All")
            cmbOfc.SelectedValue = "All"
            cmbDiv.Items.Add("All")
            cmbDiv.SelectedValue = "All"
            cmbDept.Items.Add("All")
            cmbDept.SelectedValue = "All"
            cmbSection.Items.Add("All")
            cmbSection.SelectedValue = "All"
            cmbUnit.Items.Add("All")
            cmbUnit.SelectedValue = "All"
            cmbEmpType.Items.Add("All")
            cmbEmpType.SelectedValue = "All"
            cmbEmpStatus.Items.Add("All")
            cmbEmpStatus.SelectedValue = "All"

            cm.Connection = c
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:  VIC GATCHALIAN                                    ''
            '' DATE MODIFIED: 3/7/2012                                         ''
            '' PURPOSE: TO EXPOSE FILTERS FOR INCENTIVES LIST UNDER SPECIAL    ''
            ''          PAYROLL                                                ''
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            cm.CommandText = "select Incentive_Cd,Descr from py_other_incentvs where SpecialPayroll<>0 order by Descr"
            Try
                dr = cm.ExecuteReader
                chkIncentives.Items.Clear()
                Do While dr.Read
                    chkIncentives.Items.Add(New ListItem(dr("Incentive_Cd") & "=>" & dr("Descr"), dr("Incentive_Cd")))
                Loop
                dr.Close()
                For i = 0 To chkIncentives.Items.Count - 1
                    chkIncentives.Items(i).Selected = True
                Next
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to read Other Compensation Reference. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                c.Close()
                c.Dispose()
                cm.Dispose()
                Exit Sub
            End Try
            '''''''''''''''' END OF MODIFICATION  '''''''''''''''''''''''''''''''

            cm.CommandText = "select NetPayFloor from py_syscntrl"
            Dim NetPayFloor As Decimal
            NetPayFloor = 0

            Try
                dr = cm.ExecuteReader
                If dr.Read Then
                    NetPayFloor = IIf(IsDBNull(dr("NetPayFloor")), 0, (dr("NetPayFloor") * 100))
                    txtMinPay.Text = NetPayFloor
                End If
                dr.Close()
            Catch ex As sqlclient.sqlException
                vScript = "alert('Error occurred while trying to read Payroll System Control. Error is: " & _
                    ex.Message.Replace(vbCrLf, "\n").Replace("'", "\'") & "');"
                c.Close()
                c.Dispose()
                cm.Dispose()
                Exit Sub
            End Try

            txtMode.Value = Request.Item("mode")

            If Request.Item("mode") = "reg" Then    'REGULAR PAYROLL
                SetStartCutOff()
                txtStartDate.Visible = False
                txtEndDate.Visible = False
                cmbFrom.Visible = True
                cmbTo.Visible = True
                txtPayDate.ReadOnly = False
                lblIncentList.Visible = False
                pnlIncentive.Visible = False
            Else                                    'SPECIAL PAYROLL
                txtStartDate.Visible = True
                txtEndDate.Visible = True
                cmbFrom.Visible = False
                cmbTo.Visible = False
                txtPayDate.ReadOnly = False
                lblIncentList.Visible = True
                pnlIncentive.Visible = True
            End If
            c.Close()
            c.Dispose()
            cm.Dispose()
            RefreshIncentives()
            RefreshCurrency()
        End If
    End Sub
    Private Sub RefreshCurrency()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim da As New SqlClient.SqlDataAdapter
        Dim ds As New DataSet

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            da.Dispose()
            ds.Dispose()
            Exit Sub
        End Try

        da = New SqlClient.SqlDataAdapter("select * from currency_ref order by CurrName", c)
        da.Fill(ds, "currency")
        tblForex.DataSource = ds.Tables("currency")
        tblForex.DataBind()
        c.Close()
        c.Dispose()
        da.Dispose()
        ds.Dispose()
    End Sub
    Private Sub RefreshIncentives()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim da As New SqlClient.SqlDataAdapter
        Dim ds As New DataSet

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            da.Dispose()
            ds.Dispose()
            Exit Sub
        End Try

        da = New SqlClient.SqlDataAdapter("select Incentive_Cd,Descr,AssumeIncome " & _
            "from py_other_incentvs where Taxable=1 order by AssumeIncome desc, Descr", c)
        da.Fill(ds, "incentives")
        tblAccruals.DataSource = ds.Tables("incentives")
        tblAccruals.DataBind()
        c.Close()
        c.Dispose()
        da.Dispose()
        ds.Dispose()
    End Sub
    Protected Sub cmdReturn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.Click
        Session.Remove("divisor")
        Session.Remove("ActualDays")
        Session.Remove("WeekEnds")
        Session.Remove("index")
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub cmbPayMode_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbPayMode.SelectedIndexChanged, _
        cmbMonth.SelectedIndexChanged
        SetStartCutOff()
    End Sub
    Private Sub SetStartCutOff()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim dr As SqlClient.SqlDataReader
        Dim vCutOff As String = ""
        Dim vDays() As String
        Dim iCtr As Integer

        Try
            c.Open()
        Catch ex As sqlclient.sqlexception
            vScript = "alert('Error occurred while trying to connect to SQL Server. Error in line 223: " & _
                ex.Message.Replace(vbCrLf, "\n").Replace("'", "\'") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        cm.Connection = c
        cm.CommandText = "select * from py_pay_mode where Pay_Cd='" & cmbPayMode.SelectedValue & "'"

        Try
            dr = cm.ExecuteReader
            If dr.Read Then
                Session("divisor") = IIf(IsDBNull(dr("Divisor")), 1, dr("Divisor"))
                Session("index") = "1"
                vCutOff = IIf(IsDBNull(dr("Days")), "", dr("Days"))
                cmbFrom.Items.Clear()
                cmbTo.Items.Clear()
                vDays = vCutOff.Split(",")
                For iCtr = 0 To vDays.Length - 1
                    cmbFrom.Items.Add(cmbMonth.SelectedValue & "/" & vDays(iCtr) & "/" & Now.Year)
                    'If cmbMonth.SelectedValue = 12 Then
                    cmbFrom.Items.Add(cmbMonth.SelectedValue & "/" & vDays(iCtr) & "/" & Now.Year - 1)
                    'End If
                Next iCtr
            End If
            dr.Close()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to analyze cut-off periods. Error is: " & _
                ex.Message.Replace(vbCrLf, "\n").Replace("'", "\'") & "');"
        Finally
            cm.Dispose()
            c.Close()
            c.Dispose()
            SetEndCutOff()
        End Try
    End Sub

    Protected Sub cmbFrom_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbFrom.SelectedIndexChanged
        Select Case cmbFrom.SelectedIndex + 1
            Case 1, 2
                Session("index") = 1
            Case Else
                Session("index") = 2
        End Select
        SetEndCutOff()
    End Sub
    Private Sub SetEndCutOff()
        Dim vDate As Date
        Dim vTo As Date
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim dr As SqlClient.SqlDataReader
        Dim vWorkingDays As Boolean = True
        Dim iDate As Date
        Dim iWeekEnds As Integer = 0

        cmbTo.Items.Clear()
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                                         ''
        '' DATE MODIFIED:  1/21/2012                                            ''
        '' PURPOSE:  TO SUPPORT MULTIPLE PAYMENT MODES                          ''
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        If cmbFrom.Items.Count > 2 Then
            vDate = CDate(cmbFrom.SelectedValue)
            If cmbFrom.SelectedIndex + 2 > cmbFrom.Items.Count - 1 Then
                vTo = CDate(cmbFrom.Items((cmbFrom.SelectedIndex + 2) - cmbFrom.Items.Count).Text)
            Else
                vTo = CDate(cmbFrom.Items(cmbFrom.SelectedIndex + 2).Text)
            End If
            If vTo.Day < vDate.Day Then
                vTo = vTo.AddMonths(1)
            End If
        Else
            vTo = CDate(cmbFrom.SelectedValue).AddMonths(1)
        End If
        ''''''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''''''''

        cmbTo.Items.Add(vTo.AddDays(-1))


        cmdStart.Enabled = True

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to SQL Server. Error in line 307: " & _
                ex.Message.Replace(vbCrLf, "\n").Replace("'", "\'") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        cm.Connection = c
        cm.CommandText = "select WorkingDays_Only from glsyscntrl"
        dr = cm.ExecuteReader
        If dr.Read Then
            vWorkingDays = IIf(IsDBNull(dr("WorkingDays_Only")), True, dr("WorkingDays_Only"))
        End If
        dr.Close()
        cm.CommandText = "select Days,CreditDay from py_pay_mode where Pay_Cd='" & cmbPayMode.SelectedValue & "'"
        Try
            dr = cm.ExecuteReader
            If dr.Read() Then
                Dim vCutOff = dr("Days").ToString.Split(",")
                Dim vCredit = dr("CreditDay").ToString.Split(",")
                Dim vDay = CDate(cmbFrom.SelectedValue).Day
                Dim iCtr As Integer
                Dim vMonth As Integer = 0
                Dim vYear As Integer = 0

                For iCtr = 0 To UBound(vCutOff)
                    If vCutOff(iCtr) = vDay Then
                        If CDate(cmbTo.SelectedValue).Month = 12 And CDate(cmbTo.SelectedValue).Day >= 30 Then
                            vMonth = 0
                            vYear = CDate(cmbTo.SelectedValue).Year + 1
                        Else
                            vMonth = CDate(cmbTo.SelectedValue).Month
                            vYear = CDate(cmbTo.SelectedValue).Year
                        End If
                        txtPayDate.Text = Format(vMonth + _
                            IIf(CDate(cmbTo.SelectedValue).Day < vCredit(iCtr), 0, 1), "00") & "/" & Format(Val(vCredit(iCtr)), "00") & "/" & _
                            Format(vYear, "0000")
                        If vCredit(iCtr) = 30 Then
                            txtPayDate.Text = MonthEND(CDate(Mid(txtPayDate.Text, 1, 2) & "/1/" & Mid(txtPayDate.Text, 7)))
                        End If
                        Exit For
                    End If
                Next iCtr
            End If
            dr.Close()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to analyze the ending cut-off periods. Error is: " & _
                ex.Message.Replace(vbCrLf, "\n").Replace("'", "\'") & "');"
        Finally
            cm.Dispose()
            c.Close()
            c.Dispose()
            iDate = CDate(cmbFrom.SelectedValue)
            Do While iDate <= CDate(cmbTo.SelectedValue)
                If iDate.DayOfWeek = DayOfWeek.Sunday Or (iDate.DayOfWeek = DayOfWeek.Saturday And Not vWorkingDays) Then
                    iWeekEnds += 1
                End If
                iDate = DateAdd(DateInterval.Day, 1, iDate)
            Loop
            Session("ActualDays") = Math.Abs(DateDiff(DateInterval.Day, CDate(cmbFrom.SelectedValue), CDate(cmbTo.SelectedValue)) + 1 - iWeekEnds)
            Session("WeekEnds") = iWeekEnds
            'vActualDays = ((iEnd - iStart) + 1) - (iWeekEnds + iHoliday)
            'sldDays.Max = 31
            'sldDays.Min = 1
            'sldDays.Value = DateDiff("D", CVDate(cmbFrom), CVDate(cmbTo))
            'SetPayoutDate()
        End Try
    End Sub

    Protected Sub cmdStart_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdStart.Click
        Dim i As Integer
        Dim vList As String = ""
        Dim vDist As Integer = 0
        Dim vInclude As String = ""
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim vFrom As Date
        Dim vTo As Date
        Dim vPayDate As Date = CDate(txtPayDate.Text)

        If cmbFrom.Visible Then
            vFrom = CDate(cmbFrom.SelectedValue)
        Else
            vFrom = CDate(txtStartDate.Text)
        End If

        If cmbTo.Visible Then
            vTo = CDate(cmbTo.SelectedValue)
        Else
            vTo = CDate(txtEndDate.Text)
        End If


        'set filters
        'If cmbRC.SelectedValue <> "All" Then   'filter by cost center
        '    vInclude = " and Rc_Cd='" & cmbRC.SelectedValue & "' "
        'Else
        '    vInclude = " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
        '        "' and Property='rc' and Property_Value=py_report.Rc_Cd) "
        'End If

        'If cmbOfc.SelectedValue <> "All" Then        'filter by office/agency
        '    vInclude += " and Agency_Cd='" & cmbOfc.SelectedValue & "' "
        'Else
        '    vInclude += "  and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
        '        "' and Property='agency' and Property_Value=py_report.Agency_Cd) "
        'End If
        'If cmbDiv.SelectedValue <> "All" Then      'filter by division
        '    vInclude += " and Divcd='" & cmbDiv.SelectedValue & "' "
        'Else
        '    vInclude += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
        '        "' and Property='division' and Property_Value=py_report.DivCd) "
        'End If
        'If cmbDept.SelectedValue <> "All" Then  'filter by departments
        '    vInclude += " and DeptCd='" & cmbDept.SelectedValue & "' "
        'Else
        '    vInclude += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
        '        "' and Property='department' and Property_Value=py_report.DeptCd) "
        'End If
        'If cmbSection.SelectedValue <> "All" Then 'filter by section
        '    vInclude += " and SectionCd='" & cmbSection.SelectedValue & "' "
        'Else
        '    vInclude += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
        '        "' and Property='section' and Property_Value=py_report.SectionCd) "
        'End If
        'If cmbUnit.SelectedValue <> "All" Then  'filter by units
        '    vInclude += " and UnitCd='" & cmbUnit.SelectedValue & "' "
        'Else
        '    vInclude += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
        '        "' and Property='unit' and Property_Value=py_report.UnitCd) "
        'End If
        'If cmbEmpType.SelectedValue <> "All" Then 'filter by employment types
        '    vInclude += " and EmploymentType='" & cmbEmpType.SelectedValue & "' "
        'Else
        '    vInclude += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
        '        "' and Property='employmenttype' and Property_Value=py_report.EmploymentType) "
        'End If

        'If cmbEmpStatus.SelectedValue <> "All" Then
        '    vInclude += " and Emp_Status='" & cmbEmpStatus.SelectedValue & "' "
        'End If
        'Select Case cmbAccount.SelectedValue
        '    Case "With Account No."
        '        vInclude += " and Report_No is not null"
        '    Case "Without Account No."
        '        vInclude += " and (Report_No is null or Report_No = '')"
        'End Select

        For i = 0 To chkEmp.Items.Count - 1
            If chkEmp.Items(i).Selected Then
                vList += chkEmp.Items(i).Value & ","
            End If
        Next
        If vList <> "" Then
            vList = Mid(vList, 1, Len(vList) - 1)
        End If
        txtEmplist.Value = vList

        'double check if the current selected cutoff period is frozen or not
        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error connecting to database. Error is: " & _
                ex.Message.Replace("'", "").Replace(vbCrLf, "") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        Try
            cm.Connection = c
            cm.CommandText = "select count(*) from py_report where FromDate='" & Format(vFrom, "yyyy/MM/dd") & _
                "' and ToDate='" & Format(vTo, "yyyy/MM/dd") & "' and PayDate='" & Format(vPayDate, "yyyy/MM/dd") & _
                "' and Posted=1 and Emp_Cd in ('" & vList.Replace(",", "','") & "') "

            rs = cm.ExecuteReader
            If rs.Read Then
                If Not IsDBNull(rs(0)) Then
                    If rs(0) > 0 Then
                        vScript = "alert('Cannot re-process this payroll cut off because it was already frozen.'); " & _
                            "document.getElementById('divWait').style.visibility='hidden';"
                        rs.Close()
                        c.Close()
                        c.Dispose()
                        cm.Dispose()
                        Exit Sub
                    End If
                End If
            End If
            rs.Close()

            'cut off is still open for generation or re-generation of payroll
            If chkClear.Checked Then
                cm.CommandText = "delete from py_report where FromDate='" & Format(vFrom, "yyyy/MM/dd") & _
                    "' and ToDate='" & Format(vTo, "yyyy/MM/dd") & "' and PayDate='" & Format(vPayDate, "yyyy/MM/dd") & _
                    "' and Pay_Cd='" & cmbPayMode.SelectedValue & "' and Posted=0 "
                If cmbEmpType.SelectedValue <> "All" Then
                    cm.CommandText += "and EmploymentType='" & cmbEmpType.SelectedValue & "' "
                End If
            Else
                cm.CommandText = "delete from py_report where FromDate='" & Format(vFrom, "yyyy/MM/dd") & _
                    "' and ToDate='" & Format(vTo, "yyyy/MM/dd") & "' and PayDate='" & Format(vPayDate, "yyyy/MM/dd") & _
                    "' and Emp_Cd in ('" & vList.Replace(",", "','") & "') and Posted=0 "
            End If

            cm.ExecuteNonQuery()
            c.Close()
            c.Dispose()
            cm.Dispose()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error reading database. Error is: " & _
                ex.Message.Replace("'", "").Replace(vbCrLf, "") & "');"
            c.Close()
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        vDist = rdoDist.SelectedValue
        vScript = "process(" & vDist & ");"
    End Sub

    Private Sub Get_Emp_With_MTP(ByRef c As sqlclient.sqlConnection)
        'Dim vPdf As New VSPDF8Lib.VSPDF8
        'Dim vCompanyName As String = ""
        'Dim vAddress As String = ""
        'Dim vData As String = ""
        'Dim vFormat As String = ""
        'Dim vDed As String = ""
        'Dim vIncent As String = ""
        'Dim vAgency As String = ""
        'Dim vDept As String = ""
        'Dim iLoop As Integer = 0
        'Dim iCtr As Integer = 0
        'Dim vNetPay As Double = 0
        'Dim vGross As Double = 0
        'Dim vSubTotal(12) As Double
        'Dim vDeptSubTotal(12) As Double
        'Dim vGrandTotal(12) As Double
        'Dim vSw As Integer = 0
        'Dim vDeptSW As Integer = 0
        ''Dim c As New sqlclient.sqlConnection(connStr)
        ''Dim cRef As New sqlclient.sqlConnection(connStr)
        ''Dim cGrp As New sqlclient.sqlConnection(connStr)

        'Dim cm As New sqlclient.sqlCommand
        'Dim cmRef As New sqlclient.sqlCommand
        'Dim cmGrp As New sqlclient.sqlCommand

        'Dim drRef As sqlclient.sqlDataReader
        'Dim dr As sqlclient.sqlDataReader
        'Dim drGrp As sqlclient.sqlDataReader
        'Dim PayrollMode As Boolean = Request.Item("mode") = "reg"

        ''cRef.Open()
        ''c.Open()
        ''cGrp.Open()
        'cm.Connection = c
        'cmRef.Connection = c
        'cmGrp.Connection = c

        'cm.CommandText = "select Company_Name,Address from glsyscntrl WHERE CompanyCd='" & cmbOfc.SelectedValue & "'"
        'dr = cm.ExecuteReader
        'If dr.Read Then
        '    vCompanyName = IIf(IsDBNull(dr("Company_Name")), "Unknown Company", dr("Company_Name"))
        '    vAddress = IIf(IsDBNull(dr("Address")), "Unknown Address", dr("Address"))
        'End If
        'dr.Close()

        'vData = ""
        'cmRef.CommandText = "select * from py_syscntrl"
        'drRef = cmRef.ExecuteReader
        'drRef.Read()
        'For iLoop = 1 To 30
        '    If iLoop <> 4 And iLoop <> 5 Then        'exclude coop
        '        vDed += "Other_Deduct" & iLoop & "+"
        '    End If

        '    cm.CommandText = "select Taxable from py_other_incentvs where Incentive_Cd='" & _
        '        IIf(IsDBNull(drRef("OthIncent" & iLoop & "Cd")), "", drRef("OthIncent" & iLoop & "Cd")) & "'"
        '    dr = cm.ExecuteReader
        '    If dr.Read Then
        '        If dr("Taxable") <> 0 Then      'taxable
        '            vIncent += "Other_Incent" & iLoop & "+"
        '        End If
        '    End If
        '    dr.Close()
        'Next iLoop
        'If vDed <> "" Then
        '    vDed = vDed.Substring(0, vDed.Length - 1)
        'Else
        '    vDed = "0"
        'End If

        'If vIncent <> "" Then
        '    vIncent = vIncent.Substring(0, vIncent.Length - 1)
        'Else
        '    vIncent = "0"
        'End If

        'Dim cmp_gross_pay As Decimal
        'Dim vComp_Gross As Decimal

        'cmp_gross_pay = 0
        'If (txtMinPay.Text <> 0) Then
        '    cmp_gross_pay = (txtMinPay.Text / 100)
        'End If

        'cmGrp.CommandText = "select Agency_Cd,DeptCd,Emp_Cd from " & _
        '    "py_report where " & IIf(PayrollMode = True, " NormalPayroll<>0", " NormalPayroll=0") & _
        '    " and PayDate='" & Format(CDate(txtPayDate.Text), "yyyy/MM/dd") & _
        '    "' and Pay_Cd='" & cmbPayMode.SelectedValue & "' " & Session("Emp_WMTHP") & _
        '    "group by Agency_Cd,DeptCd,Emp_Cd"

        'drGrp = cmGrp.ExecuteReader

        'vData += "<table border='0' width='100%' align='center'  style='border-collapse: collapse'>"
        'vData += "<tr class='txtNormal_H'>"
        'vData += "<td>List of Employees with Minimum Take Home Pay</td>"
        'vData += "</tr></table><br>"

        'vData += "<table border='1' width='100%'  style='border-collapse: collapse'>"
        'vData += "<tr class='txtNormal_C'>"
        'vData += "<td>Emp Cd</td>"
        'vData += "<td>Employee Name</td>"
        'vData += "<td>Basic Pay</td>"
        'vData += "<td>Overtime</td>"
        'vData += "<td>Night Diff.</td>"
        'vData += "<td>Absences and Tardiness</td>"
        'vData += "<td>Other Pay</td>"
        'vData += "<td>Gross Pay</td>"
        'vData += "<td>W/Tax</td>"
        'vData += "<td>SSS</td>"
        'vData += "<td>Philhealth</td>"
        'vData += "<td>Pag Ibig</td>"
        'vData += "<td>Other Deductions</td>"
        'vData += "<td>Net Pay</td>"
        'vData += "</tr>"

        'For iLoop = 0 To 11
        '    vGrandTotal(iLoop) = 0
        '    vSubTotal(iLoop) = 0
        '    vDeptSubTotal(iLoop) = 0
        'Next iLoop
        'vDeptSW = 0
        'Do While drGrp.Read
        '    cm.CommandText = "select Agency_Cd,DeptCd,Emp_Cd,Name,Month_Rate,Pera," & _
        '       "Absent + Tardiness as Absent_Tardy,With_Tax,Sss_Per," & _
        '       "C2+C4+D2+D4+A2+NdReg+E2+E4+F2+B2+F4+B4 AS Nd," & _
        '       "C1+C3+D1+D3+A1+E3+E1+F1+F3+B1+B3 AS Ot," & _
        '       vIncent & " as OtherInc,Other_Deduct4,Other_Deduct5," & _
        '       "PagIbig_Per,Medicare_Per," & vDed & " as Other_Ded from " & _
        '       "py_report where " & IIf(PayrollMode = True, " NormalPayroll<>0", " NormalPayroll=0") & _
        '       " and PayDate='" & Format(CDate(txtPayDate.Text), "yyyy/MM/dd") & _
        '       "' and Pay_Cd='" & cmbPayMode.SelectedValue & "' and Emp_Cd='" & drGrp("Emp_Cd") & _
        '       "' and Agency_Cd='" & drGrp("Agency_Cd") & "' and DeptCd='" & _
        '       drGrp("DeptCd") & "'"

        '    dr = cm.ExecuteReader
        '    dr.Read()
        '    iCtr += 1
        '    vGross = dr("Month_Rate") + dr("Ot") + dr("Nd") + dr("OtherInc") + dr("Absent_Tardy") + dr("Pera")
        '    vComp_Gross = vGross * cmp_gross_pay

        '    vNetPay = vGross - dr("With_Tax") - dr("Sss_Per") - dr("Medicare_Per") - _
        '        dr("PagIbig_Per") - dr("Other_Ded")

        '    If vNetPay < vComp_Gross Then
        '        If vAgency <> dr("Agency_Cd") Then
        '            If vSw <> 0 Then
        '                vData += "<tr><td class='txtNormal_L'>Office Sub-Total >>></td><td class='txtNormal_R'>" & Format(vSubTotal(0), "###,##0.00") & "</td><td class='txtNormal_R'>" & _
        '                    Format(vSubTotal(1), "###,##0.00") & "</td><td class='txtNormal_R'>" & _
        '                    Format(vSubTotal(2), "###,##0.00") & "</td><td class='txtNormal_R'>" & _
        '                    Format(vSubTotal(3), "###,##0.00") & "</td><td class='txtNormal_R'>" & _
        '                    Format(vSubTotal(4), "###,##0.00") & "</td><td class='txtNormal_R'>" & _
        '                    Format(vSubTotal(5), "###,##0.00") & "</td><td class='txtNormal_R'>" & _
        '                    Format(vSubTotal(6), "###,##0.00") & "</td><td class='txtNormal_R'>" & _
        '                    Format(vSubTotal(7), "###,##0.00") & "</td><td class='txtNormal_R'>" & _
        '                    Format(vSubTotal(8), "###,##0.00") & "</td><td class='txtNormal_R'>" & _
        '                    Format(vSubTotal(9), "###,##0.00") & "</td><td class='txtNormal_R'>" & _
        '                    Format(vSubTotal(10), "###,##0.00") & "</td><td class='txtNormal_R'>" & _
        '                    Format(vSubTotal(11), "###,##0.00") & "</td></tr>"
        '                For iLoop = 0 To 11
        '                    vSubTotal(iLoop) = 0
        '                Next iLoop
        '            End If
        '            vData += "<tr class='txtNormal_L'><td>Office:</td><td>" & dr("Agency_Cd") & "</td></td>"
        '            vAgency = dr("Agency_Cd")
        '            vSw = 1
        '        End If
        '        If vDept <> dr("DeptCd") Then
        '            If vDeptSW <> 0 Then
        '                vData += "<tr><td colspan='2' class='txtNormal_L'>Dept Sub-Total >>></td><td class='txtNormal_R'>" & Format(vDeptSubTotal(0), "###,##0.00") & "</td><td class='txtNormal_R'>" & _
        '                    Format(vDeptSubTotal(1), "###,##0.00") & "</td><td class='txtNormal_R'>" & _
        '                    Format(vDeptSubTotal(2), "###,##0.00") & "</td><td class='txtNormal_R'>" & _
        '                    Format(vDeptSubTotal(3), "###,##0.00") & "</td><td class='txtNormal_R'>" & _
        '                    Format(vDeptSubTotal(4), "###,##0.00") & "</td><td class='txtNormal_R'>" & _
        '                    Format(vDeptSubTotal(5), "###,##0.00") & "</td><td class='txtNormal_R'>" & _
        '                    Format(vDeptSubTotal(6), "###,##0.00") & "</td><td class='txtNormal_R'>" & _
        '                    Format(vDeptSubTotal(7), "###,##0.00") & "</td><td class='txtNormal_R'>" & _
        '                    Format(vDeptSubTotal(8), "###,##0.00") & "</td><td class='txtNormal_R'>" & _
        '                    Format(vDeptSubTotal(9), "###,##0.00") & "</td><td class='txtNormal_R'>" & _
        '                    Format(vDeptSubTotal(10), "###,##0.00") & "</td><td class='txtNormal_R'>" & _
        '                    Format(vDeptSubTotal(11), "###,##0.00") & "</td></tr>"
        '                For iLoop = 0 To 11
        '                    vDeptSubTotal(iLoop) = 0
        '                Next iLoop
        '            End If
        '            vData += "<tr class='txtNormal_L'><td>Department:</td><td>" & dr("DeptCd") & "</td></tr>"
        '            vDept = dr("DeptCd")
        '            vDeptSW = 1
        '        End If
        '        vData += "<tr class='txtNormal_N'><td>" & dr("Emp_Cd") & "</td><td>" & dr("Name") & "</td><td align='right'>" & Format(dr("Month_Rate"), "###,##0.00") & _
        '                       "</td><td align='right'>" & Format(dr("Ot"), "##,##0.00") & "</td><td align='right'>" & Format(dr("Nd"), "##,##0.00") & "</td><td align='right'>" & _
        '                       Format(Math.Abs(dr("Absent_Tardy")), "##,##0.00") & "</td><td align='right'>" & _
        '                       Format(dr("OtherInc") + dr("Pera"), "###,##0.00") & "</td><td align='right'>" & Format(vGross, "###,##0.00") & "</td><td align='right'>" & _
        '                       Format(dr("With_Tax"), "##,##0.00") & "</td><td align='right'>" & Format(dr("Sss_Per"), "##,##0.00") & "</td><td align='right'>" & _
        '                       Format(dr("Medicare_Per"), "##,##0.00") & "</td><td align='right'>" & Format(dr("PagIbig_Per"), "##,##0.00") & "</td><td align='right'>" & _
        '                       Format(dr("Other_Ded"), "###,##0.00") & "</td><td align='right'>" & Format(vNetPay, "###,##0.00") & "</td></tr>"

        '        vGrandTotal(0) += dr("Month_Rate")
        '        vGrandTotal(1) += dr("Ot")
        '        vGrandTotal(2) += dr("Nd")
        '        vGrandTotal(3) += Math.Abs(dr("Absent_Tardy"))
        '        vGrandTotal(4) += dr("OtherInc") + dr("Pera")
        '        vGrandTotal(5) += vGross
        '        vGrandTotal(6) += dr("With_Tax")
        '        vGrandTotal(7) += dr("Sss_Per")
        '        vGrandTotal(8) += dr("Medicare_Per")
        '        vGrandTotal(9) += dr("PagIbig_Per")
        '        vGrandTotal(10) += dr("Other_Ded")
        '        vGrandTotal(11) += vNetPay

        '        vSubTotal(0) += dr("Month_Rate")
        '        vSubTotal(1) += dr("Ot")
        '        vSubTotal(2) += dr("Nd")
        '        vSubTotal(3) += Math.Abs(dr("Absent_Tardy"))
        '        vSubTotal(4) += dr("OtherInc") + dr("Pera")
        '        vSubTotal(5) += vGross
        '        vSubTotal(6) += dr("With_Tax")
        '        vSubTotal(7) += dr("Sss_Per")
        '        vSubTotal(8) += dr("Medicare_Per")
        '        vSubTotal(9) += dr("PagIbig_Per")
        '        vSubTotal(10) += dr("Other_Ded")
        '        vSubTotal(11) += vNetPay

        '        vDeptSubTotal(0) += dr("Month_Rate")
        '        vDeptSubTotal(1) += dr("Ot")
        '        vDeptSubTotal(2) += dr("Nd")
        '        vDeptSubTotal(3) += Math.Abs(dr("Absent_Tardy"))
        '        vDeptSubTotal(4) += dr("OtherInc") + dr("Pera")
        '        vDeptSubTotal(5) += vGross
        '        vDeptSubTotal(6) += dr("With_Tax")
        '        vDeptSubTotal(7) += dr("Sss_Per")
        '        vDeptSubTotal(8) += dr("Medicare_Per")
        '        vDeptSubTotal(9) += dr("PagIbig_Per")
        '        vDeptSubTotal(10) += dr("Other_Ded")
        '        vDeptSubTotal(11) += vNetPay
        '        dr.Close()
        '    End If 'vNetPay > vComp_Gross
        '    dr.Close()
        'Loop
        'dr.Close()

        'vData += "<tr><td class='txtNormal_L' colspan='2'>Dept. Sub-Total >>></td><td class='txtNormal_R'>" & Format(vDeptSubTotal(0), "###,##0.00") & "</td><td class='txtNormal_R'>" & _
        '    Format(vDeptSubTotal(1), "###,##0.00") & "</td><td class='txtNormal_R'>" & _
        '    Format(vDeptSubTotal(2), "###,##0.00") & "</td><td class='txtNormal_R'>" & _
        '    Format(vDeptSubTotal(3), "###,##0.00") & "</td><td class='txtNormal_R'>" & _
        '    Format(vDeptSubTotal(4), "###,##0.00") & "</td><td class='txtNormal_R'>" & _
        '    Format(vDeptSubTotal(5), "###,##0.00") & "</td><td class='txtNormal_R'>" & _
        '    Format(vDeptSubTotal(6), "###,##0.00") & "</td><td class='txtNormal_R'>" & _
        '    Format(vDeptSubTotal(7), "###,##0.00") & "</td><td class='txtNormal_R'>" & _
        '    Format(vDeptSubTotal(8), "###,##0.00") & "</td><td class='txtNormal_R'>" & _
        '    Format(vDeptSubTotal(9), "###,##0.00") & "</td><td class='txtNormal_R'>" & _
        '    Format(vDeptSubTotal(10), "###,##0.00") & "</td><td class='txtNormal_R'>" & _
        '    Format(vDeptSubTotal(11), "###,##0.00") & "</td></tr>"
        'vData += "<tr><td class='txtNormal_L' colspan='2'>Office Sub-Total >>></td><td class='txtNormal_R'>" & Format(vSubTotal(0), "###,##0.00") & "</td><td class='txtNormal_R'>" & _
        '   Format(vSubTotal(1), "###,##0.00") & "</td><td class='txtNormal_R'>" & _
        '   Format(vSubTotal(2), "###,##0.00") & "</td><td class='txtNormal_R'>" & _
        '   Format(vSubTotal(3), "###,##0.00") & "</td><td class='txtNormal_R'>" & _
        '   Format(vSubTotal(4), "###,##0.00") & "</td><td class='txtNormal_R'>" & _
        '   Format(vSubTotal(5), "###,##0.00") & "</td><td class='txtNormal_R'>" & _
        '   Format(vSubTotal(6), "###,##0.00") & "</td><td class='txtNormal_R'>" & _
        '   Format(vSubTotal(7), "###,##0.00") & "</td><td class='txtNormal_R'>" & _
        '   Format(vSubTotal(8), "###,##0.00") & "</td><td class='txtNormal_R'>" & _
        '   Format(vSubTotal(9), "###,##0.00") & "</td><td class='txtNormal_R'>" & _
        '   Format(vSubTotal(10), "###,##0.00") & "</td><td class='txtNormal_R'>" & _
        '   Format(vSubTotal(11), "###,##0.00") & "</td></tr>"
        'vData += "<tr><td class='txtNormal_L' colspan='2'>Grand Total >>></td><td class='txtNormal_R'>" & Format(vGrandTotal(0), "###,##0.00") & "</td><td class='txtNormal_R'>" & _
        '    Format(vGrandTotal(1), "###,##0.00") & "</td><td class='txtNormal_R'>" & _
        '    Format(vGrandTotal(2), "###,##0.00") & "</td><td class='txtNormal_R'>" & _
        '    Format(vGrandTotal(3), "###,##0.00") & "</td><td class='txtNormal_R'>" & _
        '    Format(vGrandTotal(4), "###,##0.00") & "</td><td class='txtNormal_R'>" & _
        '    Format(vGrandTotal(5), "###,##0.00") & "</td><td class='txtNormal_R'>" & _
        '    Format(vGrandTotal(6), "###,##0.00") & "</td><td class='txtNormal_R'>" & _
        '    Format(vGrandTotal(7), "###,##0.00") & "</td><td class='txtNormal_R'>" & _
        '    Format(vGrandTotal(8), "###,##0.00") & "</td><td class='txtNormal_R'>" & _
        '    Format(vGrandTotal(9), "###,##0.00") & "</td><td class='txtNormal_R'>" & _
        '    Format(vGrandTotal(10), "###,##0.00") & "</td><td class='txtNormal_R'>" & _
        '    Format(vGrandTotal(11), "###,##0.00") & "</td></tr>"
        'vData += "</table>"
        'Session("data_emthp") = vData
        'vScript = "alert('Processing of payroll complete. " & _
        '       "You can check the result in the View Payroll Menu.');" & _
        '       "prevwin=window.open('preview_mthp.aspx','incentwin','location=no,toolber=no,width=1000,height=500,scrollbars=yes');"
        'dr.Close()
        'drGrp.Close()
        'cm.Dispose()
        'cmRef.Dispose()
        'cmGrp.Dispose()
    End Sub

    Protected Sub chkAnnualize_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkAnnualize.CheckedChanged
        If chkAnnualize.Checked = True Then
            pnlAnnual.Visible = True
            rdoDist.Enabled = True
        Else
            pnlAnnual.Visible = False
            rdoDist.Enabled = False
        End If
    End Sub

    Protected Sub cmdRefresh_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdRefresh.Click
        Dim vFrom As Date
        Dim vTo As Date
        Dim vInclude As String = ""

        If cmbFrom.Visible Then
            vFrom = CDate(cmbFrom.SelectedValue)
            vTo = CDate(cmbTo.SelectedValue)
        Else
            If Not IsDate(txtStartDate.Text) Then
                vScript = "alert('Please enter a valid Starting cut off date.');"
                Exit Sub
            End If
            If Not IsDate(txtEndDate.Text) Then
                vScript = "alert('Please enter a valid Ending cut off date.');"
                Exit Sub
            End If
            If Not IsDate(txtPayDate.Text) Then
                vScript = "alert('Please enter a valid Payout date.');"
                Exit Sub
            End If
            vFrom = CDate(txtStartDate.Text)
            vTo = CDate(txtEndDate.Text)
        End If

        Select Case cmbStatus.SelectedValue
            Case 1   'retrieve active employees only
                vInclude = " where Date_Resign is null and DateHold is null and Date_Retired is null " & _
                    "and DateSuspended is null "
            Case 0   'retrieve inactive employees only
                'vInclude = " where (Date_Resign is not null and Date_Resign between '" & _
                'Format(vFrom, "yyyy/MM/dd") & "' and '" & Format(vTo, "yyyy/MM/dd") & "') "
                vInclude = " where (Date_Resign is not null and Cleared=0) "
            Case 2  'retrieve hold employees only
                vInclude = " where Date_Resign is null and DateHold is not null "
        End Select

        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                                 ''
        '' DATE MODIFIED:  2/11/2012                                    ''
        '' PURPOSE:  TO ADD THE MODE OF PAYMENT AS PART OF THE FILER    ''
        ''           IN ORDER TO SHOW ONLY THE EMPLOYEES WITH THE SAME  ''
        ''           MODE OF PAYMENT AS THE SELECTED PAYMENT MODE       ''
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        vInclude += " and Pay_Cd='" & cmbPayMode.SelectedValue & "' "
        ''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''''''


        If cmbRC.SelectedValue <> "All" Then   'filter by cost center
            vInclude += " and py_emp_master.Rc_Cd='" & cmbRC.SelectedValue & "' "
        Else
            vInclude += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='rc' and Property_Value=py_emp_master.Rc_Cd) "
        End If

        If cmbOfc.SelectedValue <> "All" Then        'filter by office/agency
            vInclude += " and py_emp_master.Agency_Cd='" & cmbOfc.SelectedValue & "' "
        Else
            vInclude += "  and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='agency' and Property_Value=py_emp_master.Agency_Cd) "
        End If
        If cmbDiv.SelectedValue <> "All" Then      'filter by division
            vInclude += " and py_emp_master.Divcd='" & cmbDiv.SelectedValue & "' "
        Else
            vInclude += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='division' and Property_Value=py_emp_master.DivCd) "
        End If
        If cmbDept.SelectedValue <> "All" Then  'filter by departments
            vInclude += " and py_emp_master.DeptCd='" & cmbDept.SelectedValue & "' "
        Else
            vInclude += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='department' and Property_Value=py_emp_master.DeptCd) "
        End If
        If cmbSection.SelectedValue <> "All" Then 'filter by section
            vInclude += " and py_emp_master.SectionCd='" & cmbSection.SelectedValue & "' "
        Else
            vInclude += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='section' and Property_Value=py_emp_master.SectionCd) "
        End If
        If cmbUnit.SelectedValue <> "All" Then  'filter by units
            vInclude += " and py_emp_master.UnitCd='" & cmbUnit.SelectedValue & "' "
        Else
            vInclude += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='unit' and Property_Value=py_emp_master.UnitCd) "
        End If
        If cmbEmpType.SelectedValue <> "All" Then 'filter by employment types
            vInclude += " and py_emp_master.EmploymentType='" & cmbEmpType.SelectedValue & "' "
        Else
            vInclude += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='employmenttype' and Property_Value=py_emp_master.EmploymentType) "
        End If

        If cmbEmpStatus.SelectedValue <> "All" Then
            vInclude += " and py_emp_master.Emp_Status='" & cmbEmpStatus.SelectedValue & "' "
        End If
        Select Case cmbAccount.SelectedValue
            Case "With Account No."
                vInclude += " and Acct_No is not null"
            Case "Without Account No."
                vInclude += " and (Acct_No is null or Acct_No = '')"
        End Select

        If Request.Item("mode") = "reg" Then  'normal payroll if payrollmode=true
            Session("sql") = "select Emp_Cd,(Emp_Lname+', '+Emp_Fname) as name,Confidential from py_emp_master " & _
                vInclude & " order by Emp_Lname,Emp_Fname"
        Else     'SPECIAL PAYROLL
            'Session("sql") = "select Emp_Cd,Emp_LName,Emp_Fname from py_emp_master " & vInclude & _
            '   " and exists (select py_incentives_dtl.Emp_Cd from py_incentives_dtl where '" & _
            '   Format(vFrom, "yyyy/MM/dd") & "' >= FromDate and ToDate <= '" & Format(vTo, "yyyy/MM/dd") & _
            '   "' and py_incentives_dtl.Emp_Cd=py_emp_master.Emp_Cd " & _
            '   "and exists (select py_other_incentvs.Incentive_Cd from py_other_incentvs where SpecialPayroll<>0)) " & _
            '   " order by Emp_Lname,Emp_Fname"
            
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:  VIC GATCHALIAN                                  ''
            '' DATE MODIFIED: 9/25/2011                                      ''
            '' PURPOSE :  TO PRODUCE SPECIAL REPORT WITH RECURRING           ''
            ''            TRANSACTIONS                                       ''
            '' EXCEPTIONS:  FOR GWI USE ONLY                                 ''
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '''''''''''''''''' ORIGINAL CODE ''''''''''''''''''''''''''''''''''
            'Session("sql") = "select distinct emp_cd, (select (Emp_Lname+', '+Emp_Fname) from py_emp_master " & _
            '    "where py_emp_master.Emp_Cd=py_incentives_dtl.Emp_Cd) as name  from py_incentives_dtl where ToDate = '" & _
            '    Format(vFrom, "yyyy/MM/dd") & _
            '    "' and exists (select py_other_incentvs.Incentive_Cd from py_other_incentvs where SpecialPayroll<>0)"
            ''''''''''''''''''' END ORIGINAL CODE ''''''''''''''''''''''''''''''
            ''''''''''''''''''' OLD CODE VER 2 ''''''''''''''''''''''''''''
            'Session("sql") = "select distinct emp_cd, (select (Emp_Lname+', '+Emp_Fname) from py_emp_master " & _
            '    "where py_emp_master.Emp_Cd=py_incentives_dtl.Emp_Cd) as name  from py_incentives_dtl where (ToDate = '" & _
            '    Format(vFrom, "yyyy/MM/dd") & _
            '    "' or ToDate is null) and exists " & _
            '    "(select py_other_incentvs.Incentive_Cd from py_other_incentvs where SpecialPayroll<>0) "
            '''''''''''''''''' END OLD CODE VER 2 '''''''''''''''''''''''''''''''
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:  VIC GATCHALIAN                                    ''
            '' DATE MODIFIED: 3/7/2012                                         ''
            '' PURPOSE:  TO SUPPORT SELECTIVE INCENTIVES FOR SPECIAL PAYROLL   ''
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '''''''''''''''''''''' OLD CODE VER 3 '''''''''''''''''''''''''''''''
            'Session("sql") = "select distinct emp_cd, (select (Emp_Lname+', '+Emp_Fname) from py_emp_master " & _
            '    "where py_emp_master.Emp_Cd=py_incentives_dtl.Emp_Cd) as name  from py_incentives_dtl where (ToDate = '" & _
            '    Format(vFrom, "yyyy/MM/dd") & _
            '    "' or ToDate is null) and exists " & _
            '    "(select py_other_incentvs.Incentive_Cd from py_other_incentvs where SpecialPayroll<>0 " & _
            '    "and py_other_incentvs.Incentive_Cd = py_incentives_dtl.Incentive_Cd)"
            ''''''''''''''''''''' END OLD CODE VER 3 ''''''''''''''''''''''''''''
            ' GET LIST OF INCENTIVES CHECKED 
            Dim vIncentList As String = ""

            For iloop As Integer = 0 To chkIncentives.Items.Count - 1
                If chkIncentives.Items(iloop).Selected Then
                    vIncentList += chkIncentives.Items(iloop).Value & ","
                End If
            Next
            If vIncentList = "" Then
                vScript = "alert('You must select at least one Incentive from the list.');"
                Exit Sub
            Else
                vIncentList = Mid(vIncentList, 1, Len(vIncentList) - 1)
            End If

            Session("sql") = "select distinct emp_cd, (select (Emp_Lname+', '+Emp_Fname) from py_emp_master " & _
                "where py_emp_master.Emp_Cd=py_incentives_dtl.Emp_Cd) as name,(select Confidential from py_emp_master " & _
                "where py_emp_master.Emp_Cd=py_incentives_dtl.Emp_Cd) as Confidential from py_incentives_dtl where (ToDate = '" & _
                Format(vFrom, "yyyy/MM/dd") & _
                "' or ToDate is null) and Incentive_Cd in ('" & vIncentList.Replace(",", "','") & "')"
            txtIncentList.Value = vIncentList
            ''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''''
        End If

        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "\n").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        cm.Connection = c
        cm.CommandText = Session("sql")
        Try
            rs = cm.ExecuteReader
            chkEmp.Items.Clear()
            Do While rs.Read
                If (rs("Confidential") = 1 And Val(Session("userlevel")) = 1) Or rs("Confidential") = 0 Then
                    chkEmp.Items.Add(New ListItem(rs("Emp_Cd") & "=>" & rs("name"), rs("Emp_Cd")))
                End If
            Loop
            rs.Close()
            TickEmp(True)
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to read to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "\n").Replace("'", "") & "');"
        Finally
            c.Close()
            cm.Dispose()
            c.Dispose()
        End Try
    End Sub
    Private Sub TickEmp(ByVal pState As Boolean)
        Dim i As Integer
        Dim vList As String = ""
        For i = 0 To chkEmp.Items.Count - 1
            chkEmp.Items(i).Selected = pState
            If pState Then vList += chkEmp.Items(i).Value & ","
        Next
        If vList <> "" Then vList = vList.Substring(0, vList.Length - 1)
        txtEmplist.Value = vList
    End Sub
    Protected Sub cmdAll_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdAll.Click
        TickEmp(True)
    End Sub

    Protected Sub cmdUnAll_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdUnAll.Click
        TickEmp(False)
    End Sub

    Protected Sub tblAccruals_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles tblAccruals.PageIndexChanging
        tblAccruals.PageIndex = e.NewPageIndex
        RefreshIncentives()
    End Sub

    Protected Sub tblAccruals_RowCancelingEdit(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCancelEditEventArgs) Handles tblAccruals.RowCancelingEdit
        tblAccruals.EditIndex = -1
        RefreshIncentives()
    End Sub

    Protected Sub tblAccruals_RowEditing(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewEditEventArgs) Handles tblAccruals.RowEditing
        tblAccruals.EditIndex = e.NewEditIndex
        tblAccruals.SelectedIndex = e.NewEditIndex
        RefreshIncentives()
    End Sub

    Protected Sub tblAccruals_RowUpdating(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewUpdateEventArgs) Handles tblAccruals.RowUpdating
        Dim ctlText As TextBox
        ctlText = CType(tblAccruals.Rows(e.RowIndex).Cells(2).Controls(0), TextBox)
        ctlText.Text = ctlText.Text.Replace(",", "")

        If Not IsNumeric(ctlText.Text) Then
            vScript = "alert('You must enter a valid numeric value in the field.');"
            Exit Sub
        End If

        Dim vCode As String = tblAccruals.SelectedRow.Cells(0).Text
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to databse. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        cm.Connection = c
        
        cm.CommandText = "update py_other_incentvs set AssumeIncome=" & Val(ctlText.Text) & _
            " where Incentive_Cd='" & vCode & "'"

        Try
            cm.ExecuteNonQuery()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to save changes. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            c.Dispose()
            cm.Dispose()
            tblAccruals.EditIndex = -1
            tblAccruals.PageIndex = 0
            RefreshIncentives()
        End Try
    End Sub

    Protected Sub tblForex_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles tblForex.PageIndexChanging
        tblForex.PageIndex = e.NewPageIndex
        RefreshCurrency()
    End Sub

    Protected Sub tblForex_RowCancelingEdit(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCancelEditEventArgs) Handles tblForex.RowCancelingEdit
        tblForex.EditIndex = -1
        RefreshCurrency()
    End Sub

    Protected Sub tblForex_RowEditing(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewEditEventArgs) Handles tblForex.RowEditing
        tblForex.EditIndex = e.NewEditIndex
        tblForex.SelectedIndex = e.NewEditIndex
        RefreshCurrency()
    End Sub

    Protected Sub tblForex_RowUpdating(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewUpdateEventArgs) Handles tblForex.RowUpdating
        Dim ctlText As TextBox
        ctlText = CType(tblForex.Rows(e.RowIndex).Cells(2).Controls(0), TextBox)
        ctlText.Text = ctlText.Text.Replace(",", "")

        If Not IsNumeric(ctlText.Text) Then
            vScript = "alert('You must enter a valid numeric value in the field.');"
            Exit Sub
        End If

        Dim vCode As String = tblForex.SelectedRow.Cells(0).Text
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to databse. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        cm.Connection = c

        cm.CommandText = "update currency_ref set Forex=" & Val(ctlText.Text) & _
            " where CurrCd='" & vCode & "'"

        Try
            cm.ExecuteNonQuery()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to save changes. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            c.Dispose()
            cm.Dispose()
            tblForex.EditIndex = -1
            tblForex.PageIndex = 0
            RefreshCurrency()
        End Try
    End Sub
End Class
