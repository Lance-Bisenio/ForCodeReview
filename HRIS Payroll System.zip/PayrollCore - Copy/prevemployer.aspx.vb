﻿Imports denaro.fis
Partial Class prevemployer
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If

        If Not IsPostBack Then
            If Not CanRun(Session("caption"), Request.Item("id")) Then
                Session("denied") = "1"
                Server.Transfer("main.aspx")
                Exit Sub
            End If
            lblcaption.text = "Record Employee's Previous Employer Income"
            
            DataRefresh()
        End If
    End Sub
    Private Sub DataRefresh()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim da As New SqlClient.SqlDataAdapter("select Emp_Cd,GrossTaxable,TaxWithheld," & _
            "YearCd,GrossNonTax,NonTax13th,NonTaxSSS,Tax13th," & _
            "(select Emp_Lname+', '+Emp_Fname from py_emp_master where py_emp_master.Emp_Cd=py_prev_employer_income.Emp_Cd) as Name " & _
            "from py_prev_employer_income order by YearCd desc,Name", c)
        Dim ds As New DataSet

        da.Fill(ds, "prev")
        tblPrev.DataSource = ds.Tables("prev")
        tblPrev.DataBind()
        da.Dispose()
        ds.Dispose()
        Session.Remove("empid")
        Session.Remove("year")
        tblPrev.SelectedIndex = -1
    End Sub
    Protected Sub cmdClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdClose.Click
        Session.Remove("empid")
        Session.Remove("year")
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub tblPrev_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles tblPrev.PageIndexChanging
        tblPrev.PageIndex = e.NewPageIndex
        DataRefresh()
    End Sub

    Protected Sub tblPrev_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tblPrev.SelectedIndexChanged
        Session("empid") = tblPrev.SelectedRow.Cells(0).Text
        Session("year") = tblPrev.SelectedRow.Cells(2).Text
    End Sub

    Protected Sub cmdDelete_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDelete.Click
        If tblPrev.SelectedIndex > -1 Then
            Dim c As New SqlClient.SqlConnection(connStr)
            Dim cm As New SqlClient.SqlCommand

            Try
                c.Open()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                c.Dispose()
                cm.Dispose()
                Exit Sub
            End Try

            cm.Connection = c

            cm.CommandText = "delete from py_prev_employer_income where Emp_Cd='" & _
                tblPrev.SelectedRow.Cells(0).Text & "' and YearCd=" & _
                tblPrev.SelectedRow.Cells(2).Text
            Try
                cm.ExecuteNonQuery()
                DataRefresh()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to delete record. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            Finally
                c.Close()
                c.Dispose()
                cm.Dispose()
            End Try
        End If
    End Sub
End Class
