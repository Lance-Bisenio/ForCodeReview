Imports denaro
Partial Class empmaster
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Public vSrc As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If
        If Not CanRun(Session("caption"), Request.Item("id")) Then 
            Session("denied") = "1" 
            Server.Transfer("main.aspx")
            Exit Sub
        End If 

        If Not IsPostBack Then
            lblCaption.Text = "Employee Master Query"

            Dim c As New SqlClient.SqlConnection(connStr)

            Try
                c.Open()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                    ex.Message.Replace("'", "").Replace(vbCrLf, "") & "');"
                c.Dispose()
                Exit Sub
            End Try

            BuildCombo("select Rc_Cd,Descr from rc where exists (select User_Id from rights_list where User_Id='" & _
                   Session("uid") & "' and property='rc' and Property_Value=Rc_Cd) order by Descr", cmbRc, c)
            BuildCombo("select AgencyCd,AgencyName from agency where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='agency' and Property_Value=AgencyCd) order by AgencyName", cmbOfc, c)
            BuildCombo("select Div_Cd,Descr from hr_div_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='division' and Property_Value=Div_Cd) order by Descr", cmbDiv, c)
            BuildCombo("select Dept_Cd,Descr from hr_dept_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='department' and Property_Value=Dept_Cd) order by Descr", cmbDept, c)
            BuildCombo("select Section_Cd,Descr from hr_section_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='section' and Property_Value=Section_Cd) order by Descr", cmbSection, c)
            BuildCombo("select Unit_Cd,Descr from hr_unit_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='unit' and Property_Value=Unit_Cd) order by Descr", cmbUnit, c)
            BuildCombo("select EmploymentType,Descr from hr_employment_type where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='employmenttype' and Property_Value=EmploymentType) order by Descr", cmbType, c)
            BuildCombo("select Status_Code,Descr from py_employee_stat order by Descr", cmbStatus, c)
            BuildCombo("select Pos_Cd,Position from py_position_ref order by Position", cmbPos, c)
            BuildCombo("select Pay_Cd,Payment from py_pay_mode order by Payment", cmbPayCd, c)
            BuildCombo("select Tax_Cd,Descr from py_tax_ref order by Descr", cmbTax, c)
            BuildCombo("select Civil_Cd,Descr from py_civil_ref order by Descr", cmbCivil, c)
            BuildCombo("select Emp_Cd,Emp_Lname+', '+Emp_Fname as Name from py_emp_master where " & _
                "EmploymentType not in ('R&F','99') order by Emp_Lname,Emp_Fname", cmbSupervisor, c)
            BuildCombo("select Emp_Cd,Emp_Lname+', '+Emp_Fname as Name from py_emp_master where " & _
               "EmploymentType not in ('R&F','99') order by Emp_Lname,Emp_Fname", cmb2ndApprover, c)
            BuildCombo("select Emp_Cd,Emp_Lname+', '+Emp_Fname as Name from py_emp_master where " & _
                "EmploymentType not in ('R&F','99') order by Emp_Lname,Emp_Fname", cmb3rdApprover, c)

            c.Close()
            c.Dispose()

            cmbRc.Items.Add("All")
            cmbOfc.Items.Add("All")
            cmbDiv.Items.Add("All")
            cmbDept.Items.Add("All")
            cmbSection.Items.Add("All")
            cmbUnit.Items.Add("All")
            cmbType.Items.Add("All")
            cmbStatus.Items.Add("All")
            cmbPos.Items.Add("All")
            cmbPayCd.Items.Add("All")
            cmbTax.Items.Add("All")
            cmbCivil.Items.Add("All")
            cmbSupervisor.Items.Add("All")
            cmb2ndApprover.Items.Add("All")
            cmb3rdApprover.Items.Add("All")
            cmbResigned.Items.Add("All")

            cmbRc.SelectedValue = "All"
            cmbOfc.SelectedValue = "All"
            cmbDiv.SelectedValue = "All"
            cmbDept.SelectedValue = "All"
            cmbSection.SelectedValue = "All"
            cmbUnit.SelectedValue = "All"
            cmbType.SelectedValue = "All"
            cmbStatus.SelectedValue = "All"
            cmbPos.SelectedValue = "All"
            cmbPayCd.SelectedValue = "All"
            cmbTax.SelectedValue = "All"
            cmbCivil.SelectedValue = "All"
            cmbSupervisor.SelectedValue = "All"
            cmb2ndApprover.SelectedValue = "All"
            cmb3rdApprover.SelectedValue = "All"
            cmbResigned.SelectedValue = "All"

            cmbYear.Items.Clear()
            For iLoop = Now.Year - 3 To Now.Year
                cmbYear.Items.Add(iLoop)
            Next iLoop
            cmbYear.SelectedValue = Now.Year

            For iCtr = 1 To 31      'add days
                cmbDayFr.Items.Add(iCtr)
                cmbDayTo.Items.Add(iCtr)
            Next iCtr
            For iCtr = 1980 To 2030 'add year
                cmbYrFr.Items.Add(iCtr)
                cmbYrTo.Items.Add(iCtr)
            Next iCtr

            'now set the default values
            cmbMonthFr.SelectedValue = Now.Month
            cmbMonthTo.SelectedValue = Now.Month
            cmbDayFr.SelectedValue = 1
            cmbDayTo.SelectedValue = Now.Day
            cmbYrFr.SelectedValue = Now.Year
            cmbYrTo.SelectedValue = Now.Year


            cmbDayFr.Enabled = False
            cmbDayTo.Enabled = False
            cmbYrFr.Enabled = False
            cmbYrTo.Enabled = False
            cmbMonthFr.Enabled = False
            cmbMonthTo.Enabled = False

            cmbResigned.Enabled = False
            cmbMonth.Enabled = False
            cmbYear.Enabled = False

        End If
    End Sub

    Protected Sub cmdReturn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.Click, _
        cmdReturn1.Click
        Session.Remove("Emp_Cd")
        Session.Remove("BarcodeId")
        Session.Remove("Emp_Lname")
        Session.Remove("Emp_Fname")
        Session.Remove("Emp_Mname")
        Session.Remove("Pos_Cd")
        Session.Remove("Rc_Cd")
        Session.Remove("Agency_Cd")
        Session.Remove("DivCd")
        Session.Remove("DeptCd")
        Session.Remove("SectionCd")
        Session.Remove("UnitCd")
        Session.Remove("EmploymentType")
        Session.Remove("Emp_Status")
        Session.Remove("Pay_Cd")
        Session.Remove("Civil_Cd")
        Session.Remove("Tax_Cd")
        Session.Remove("SupervisorCd")
        Session.Remove("Approving")
        Session.Remove("Noting")
        Session.Remove("Male")
        Session.Remove("Bday")
        Session.Remove("Start_Date")
        Session.Remove("Date_Resigned")
        Session.Remove("Years_of_Service")
        Session.Remove("Rate_Year")
        Session.Remove("Month_Rate")
        Session.Remove("Rate_Day")
        Session.Remove("Emp_Address")
        Session.Remove("Emp_Tel")
        Session.Remove("Emp_Email")
        Session.Remove("Sss_No")
        Session.Remove("Pagibig_No")
        Session.Remove("Tin")
        Session.Remove("PhicNo")
        Session.Remove("Acct_No")
        Server.Transfer("main.aspx")
    End Sub
    Private Sub AppendCol(ByVal pCol As String, ByVal pTitle As String, ByRef pData As StringBuilder, ByRef pOK As Boolean)
        If Session(pCol) = "1" Then
            pOK = True
            pData.AppendLine("<th>" & pTitle & "</th>")
        End If
    End Sub
    Private Sub GetData(ByVal pCol As String, ByVal pData As String, ByRef pDump As StringBuilder, _
                        ByRef c As SqlClient.SqlConnection, Optional ByVal pSQL As String = "")

        If Session(pCol) = "1" Then
            Dim vData As String = pData

            If pSQL <> "" Then 'cross reference the code to get the description
                Dim cm As New SqlClient.SqlCommand(pSQL, c)
                Dim rs As SqlClient.SqlDataReader
                rs = cm.ExecuteReader
                If rs.Read Then
                    If Not IsDBNull(rs(0)) Then
                        vData = rs(0)
                    End If
                End If
                rs.Close()
                cm.Dispose()
            End If
            pDump.AppendLine("<td class='labelL'>" & vData & "</td>")
        End If
    End Sub
    Protected Sub cmdRefresh1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdRefresh1.Click, cmdRefresh.Click
        Dim vData As New StringBuilder
        Dim vCond As String = ""
        Dim vOk As Boolean = False
        Dim vClass As String = "odd"
        Dim c As New SqlClient.SqlConnection
        Dim cm As New SqlClient.SqlCommand
        Dim dr As SqlClient.SqlDataReader
        Dim iCtr As Integer = 0
        Dim vFrom As Date
        Dim vTo As Date


        If Dir(Server.MapPath("") & "\downloads\" & Session.SessionID & "-empmaster.html") <> "" Then
            Kill(Server.MapPath("") & "\downloads\" & Session.SessionID & "-empmaster.html")
        End If

        If txtSalStart.Text <> "" And Not IsNumeric(txtSalStart.Text) Then
            vScript = "alert('Invalid numeric format in Starting salary field.');"
            Exit Sub
        End If
        If txtSalEnd.Text <> "" And Not IsNumeric(txtSalEnd.Text) Then
            vScript = "alert('Invalid numeric format in Ending salary field.');"
            Exit Sub
        End If
        If txtSalEnd.Text = "" And txtSalStart.Text <> "" Then
            txtSalEnd.Text = txtSalStart.Text
        End If
        If txtSalStart.Text = "" And txtSalEnd.Text <> "" Then
            txtSalStart.Text = txtSalEnd.Text
        End If
        If txtSalStart.Text = "" And txtSalEnd.Text = "" Then
            txtSalStart.Text = 0
            txtSalEnd.Text = 9999999.99
        End If
        If txtSalEnd.Text < txtSalStart.Text Then
            vScript = "alert('Ending Salary field must be greater than Starting salary field.');"
            Exit Sub
        End If

        If txtYearsFrom.Text <> "" And Not IsNumeric(txtYearsFrom.Text) Then
            vScript = "alert('Invalid numeric format in Starting Years of service field.');"
            Exit Sub
        End If
        If txtYearsTo.Text <> "" And Not IsNumeric(txtYearsTo.Text) Then
            vScript = "alert('Invalid numeric format in Ending Years of service field.');"
            Exit Sub
        End If
        If txtYearsTo.Text = "" And txtYearsFrom.Text <> "" Then
            txtYearsTo.Text = txtYearsFrom.Text
        End If
        If txtYearsFrom.Text = "" And txtYearsTo.Text <> "" Then
            txtYearsFrom.Text = txtYearsTo.Text
        End If
        If txtYearsFrom.Text = "" And txtYearsTo.Text <> "" Then
            txtYearsFrom.Text = txtYearsTo.Text
        End If
        If txtYearsTo.Text < txtYearsFrom.Text Then
            vScript = "alert('Ending Years of service field must be greater than Starting Years of service field.');"
            Exit Sub
        End If

        vCond += " where Rate_Month between " & txtSalStart.Text & " and " & txtSalEnd.Text

        If chkResign.Checked = True Then
            Select Case cmbResigned.SelectedValue
                Case 0
                    vCond += " and Date_Resign is null "
                Case 1
                    vCond += " and Month(Date_Resign)=" & cmbMonth.SelectedValue & " and Year(Date_Resign)=" & cmbYear.SelectedValue & " "
                Case 2
                    vCond += " and Month(Date_Retired)=" & cmbMonth.SelectedValue & " and Year(Date_Retired)=" & cmbYear.SelectedValue & " "
                Case 3
                    vCond += " and Month(DateSuspended)=" & cmbMonth.SelectedValue & " and Year(DateSuspended)=" & cmbYear.SelectedValue & " "
                Case "All"
                    'vCond += " and Date_Resign is null "
                    vCond += " and Month(Date_Resign)=" & cmbMonth.SelectedValue & " and Year(Date_Resign)=" & cmbYear.SelectedValue & " "
                    vCond += " and Month(Date_Retired)=" & cmbMonth.SelectedValue & " and Year(Date_Retired)=" & cmbYear.SelectedValue & " "
                    vCond += " and Month(DateSuspended)=" & cmbMonth.SelectedValue & " and Year(DateSuspended)=" & cmbYear.SelectedValue & " "
            End Select
        End If

        If chkDateHired.Checked = True Then
            vFrom = cmbYrFr.SelectedValue & "/" & cmbMonthFr.SelectedValue & "/" & cmbDayFr.SelectedValue
            vTo = cmbYrTo.SelectedValue & "/" & cmbMonthTo.SelectedValue & "/" & cmbDayTo.SelectedValue
            vCond += " and Start_Date between '" & vFrom & "' and '" & vTo & "' "
        End If


        'If cmbResigned.SelectedValue <> "All" Then
        '    If cmbResigned.SelectedValue = 0 Then           'active  Date_Retired DateSuspended
        '        vCond += " and Date_Resign is null "
        '    Else                                            'resigned
        '        vCond += " and Date_Resign is not null "
        '    End If
        'End If

        If cmbRc.SelectedValue <> "All" Then
            vCond += " and Rc_Cd='" & cmbRc.SelectedValue & "' "
        Else
            vCond += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='rc' and Property_Value=Rc_Cd)"
        End If
        If cmbOfc.SelectedValue <> "All" Then
            vCond += " and Agency_Cd='" & cmbOfc.SelectedValue & "' "
        Else
            vCond += "  and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='agency' and Property_Value=Agency_Cd) "
        End If
        If cmbDiv.SelectedValue <> "All" Then
            vCond += " and DivCd='" & cmbDiv.SelectedValue & "' "
        Else
            vCond += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='division' and Property_Value=DivCd) "
        End If
        If cmbDept.SelectedValue <> "All" Then
            vCond += " and DeptCd='" & cmbDept.SelectedValue & "' "
        Else
            vCond += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='department' and Property_Value=DeptCd) "
        End If
        If cmbSection.SelectedValue <> "All" Then
            vCond += " and SectionCd='" & cmbSection.SelectedValue & "' "
        Else
            vCond += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='section' and Property_Value=SectionCd) "
        End If
        If cmbUnit.SelectedValue <> "All" Then
            vCond += " and UnitCd='" & cmbUnit.SelectedValue & "' "
        Else
            vCond += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='unit' and Property_Value=UnitCd) "
        End If
        If cmbType.SelectedValue <> "All" Then
            vCond += " and EmploymentType='" & cmbType.SelectedValue & "' "
        Else
            vCond += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='employmenttype' and Property_Value=EmploymentType) "
        End If
        If cmbStatus.SelectedValue <> "All" Then
            vCond += " and Emp_Status='" & cmbStatus.SelectedValue & "' "
        End If
        If cmbPos.SelectedValue <> "All" Then
            vCond += " and Pos_Cd='" & cmbPos.SelectedValue & "' "
        End If
        If cmbPayCd.SelectedValue <> "All" Then
            vCond += " and Pay_Cd='" & cmbPayCd.SelectedValue & "' "
        End If
        If cmbTax.SelectedValue <> "All" Then
            vCond += " and Tax_Cd='" & cmbTax.SelectedValue & "' "
        End If
        If cmbCivil.SelectedValue <> "All" Then
            vCond += " and Civil_Cd='" & cmbCivil.SelectedValue & "' "
        End If
        If cmbSupervisor.SelectedValue <> "All" Then
            vCond += " and SupervisorCd like '%" & cmbSupervisor.SelectedValue & "%' "
        End If
        If cmb2ndApprover.SelectedValue <> "All" Then
            vCond += " and Approving like '%" & cmb2ndApprover.SelectedValue & "%' "
        End If
        If cmb3rdApprover.SelectedValue <> "All" Then
            vCond += " and Noting like '%" & cmb3rdApprover.SelectedValue & "%' "
        End If

        If cmbBirthMonth.SelectedValue <> "0" Then
            vCond += " and month(Bday)=" & cmbBirthMonth.SelectedValue
        End If
        If cmbsex.SelectedValue <> "2" Then
            vCond += " and Male=" & cmbsex.SelectedValue
        End If
        If cmbConfi.SelectedValue <> "2" Then
            vCond += " and Confidential=" & cmbConfi.SelectedValue
        End If
        If cmbSC.SelectedValue <> "2" Then
            vCond += " and SCMember=" & cmbSC.SelectedValue
        End If
        If txtYearsFrom.Text <> "" Then
            vCond += " and ((TO_DAYS(NOW()) - TO_DAYS(Start_Date)) / 365) between " & txtYearsFrom.Text & " and " & txtYearsTo.Text
        End If

        With vData
            .AppendLine("<html>")
            .AppendLine("<head>")
            .AppendLine("<title>Employee Master Query</title>")
            .AppendLine("<link href='../redtheme/red.css' rel='stylesheet' type='text/css' />")
            .AppendLine("</head>")
            .AppendLine("<body>")
            .AppendLine("<center>")
            .AppendLine("<h1>Employee Master Report</h1>")
            .AppendLine("<hr/>")
            .AppendLine("<table border='1' style='border-collapse:collapse; width:100%;' class='mainGridView' >")
            'generate column headers
            .AppendLine("<tr class='titleBar' style='font-size: 11px;'>")
            .AppendLine("<th>Line #</th>")
            AppendCol("Emp_Cd", "Emp Id", vData, vOk)
            AppendCol("BarcodeId", "Barcode Id", vData, vOk)
            AppendCol("Emp_Lname", "Last Name", vData, vOk)
            AppendCol("Emp_Fname", "First Name", vData, vOk)
            AppendCol("Emp_Mname", "Middle Name", vData, vOk)
            AppendCol("Confidential", "Confidential?", vData, vOk)
            AppendCol("SCMember", "Service Charge Eligible?", vData, vOk)
            AppendCol("Pos_Cd", "Position", vData, vOk)
            AppendCol("Rc_Cd", "Cost Center", vData, vOk)
            AppendCol("Agency_Cd", "Office", vData, vOk)
            AppendCol("DivCd", "Division", vData, vOk)
            AppendCol("DeptCd", "Department", vData, vOk)
            AppendCol("SectionCd", "Section", vData, vOk)
            AppendCol("UnitCd", "Unit", vData, vOk)
            AppendCol("EmploymentType", "Rank", vData, vOk)
            AppendCol("Grade_Cd", "Salary Grade", vData, vOk)
            AppendCol("Emp_Status", "Emp. Status", vData, vOk)
            AppendCol("Pay_Cd", "Pay Code", vData, vOk)
            AppendCol("Civil_Cd", "Civil Status", vData, vOk)
            AppendCol("Tax_Cd", "Tax Code", vData, vOk)
            AppendCol("SupervisorCd", "Immediate Superior", vData, vOk)
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:  VIC GATCHALIAN                                                 ''
            '' DATE MODIFIED: 3/19/2013                                                     ''
            '' PURPOSE: TO EXPOSE 2ND AND 3RD LEVEL APPROVING OFFICER                       ''
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            AppendCol("Approving", "Second Level Approver (Recommending)", vData, vOk)
            AppendCol("Noting", "Third Level Approver (Noting)", vData, vOk)
            ''''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''''''''''''''''

            AppendCol("Male", "Gender", vData, vOk)
            AppendCol("Bday", "Birth Date", vData, vOk)
            AppendCol("Age", "Age", vData, vOk)
            AppendCol("Start_Date", "Date Hired", vData, vOk)
            AppendCol("Date_Resigned", "Date Resigned", vData, vOk)
            AppendCol("Years_of_Service", "Yrs of Svc", vData, vOk)
            AppendCol("Rate_Year", "Annual Salary", vData, vOk)
            AppendCol("Month_Rate", "Monthly Salary", vData, vOk)
            AppendCol("Rate_Day", "Daily Rate", vData, vOk)
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:  VIC GATCHALIAN                           ''
            '' DATE MODIFIED: 7/17/2013                               ''
            '' PURPOSE: TO EXPOSE THE GRACE PERIOD,DAILYPAID          ''
            ''          and  MOBILE NO. FIELDS                        ''
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            AppendCol("DailyPaid", "Daily Paid?", vData, vOk)
            AppendCol("GracePeriod", "Grace Period", vData, vOk)
            ''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''

            AppendCol("Emp_Address", "Address", vData, vOk)
            AppendCol("Emp_Tel", "Tel. #", vData, vOk)
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:  VIC GATCHALIAN                           ''
            '' DATE MODIFIED: 7/17/2013                               ''
            '' PURPOSE: TO EXPOSE THE GRACE PERIOD AND MOBILE NO.     ''
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            AppendCol("MobileNo", "Mobile No.", vData, vOk)
            ''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''

            AppendCol("Emp_Email", "Email Address", vData, vOk)
            AppendCol("Sss_No", "SSS #", vData, vOk)
            AppendCol("Pagibig_No", "PagIBIG #", vData, vOk)
            AppendCol("Tin", "TIN", vData, vOk)
            AppendCol("PhicNo", "PHIC #", vData, vOk)
            AppendCol("Acct_No", "Account #", vData, vOk)
            .AppendLine("</tr>")
            If Not vOk Then
                vScript = "alert('You must first select at least one column to view the query. Click the Set Cols button to select the columns you want to show.');"
                Exit Sub
            End If
            'end of column header generation

            'now dump the data
            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c
            cm.CommandText = "select * from py_emp_master " & vCond & " order by Emp_Lname,Emp_Fname"
            'Response.Write(cm.CommandText)

            dr = cm.ExecuteReader
            Do While dr.Read
                iCtr += 1
                .AppendLine("<tr class='" & vClass & "'>")
                .AppendLine("<td class='labelR'>" & iCtr & ".&nbsp;</td>")
                GetData("Emp_Cd", dr("Emp_Cd"), vData, c, "")
                GetData("BarcodeId", dr("BarcodeId"), vData, c, "")
                GetData("Emp_Lname", dr("Emp_Lname"), vData, c, "")
                GetData("Emp_Fname", dr("Emp_Fname"), vData, c, "")
                GetData("Emp_Mname", dr("Emp_Mname"), vData, c, "")
                GetData("Confidential", IIf(dr("Confidential") = 1, "Yes", "No"), vData, c, "")
                GetData("SCMember", IIf(dr("SCMember") = 1, "Yes", "No"), vData, c, "")
                GetData("Pos_Cd", IIf(IsDBNull(dr("Pos_Cd")), "&nbsp;", dr("Pos_Cd")), vData, c, _
                        "select Position from py_position_ref where Pos_Cd='" & IIf(IsDBNull(dr("Pos_Cd")), "", dr("Pos_Cd")) & "'")
                GetData("Rc_Cd", IIf(IsDBNull(dr("Rc_Cd")), "&nbsp;", dr("Rc_Cd")), vData, c, _
                        "select Descr from rc where Rc_Cd='" & IIf(IsDBNull(dr("Rc_Cd")), "", dr("Rc_Cd")) & "'")
                GetData("Agency_Cd", IIf(IsDBNull(dr("Agency_Cd")), "&nbsp;", dr("Agency_Cd")), vData, c, _
                        "select AgencyName from agency where AgencyCd='" & IIf(IsDBNull(dr("Agency_Cd")), "", dr("Agency_Cd")) & "'")
                GetData("DivCd", IIf(IsDBNull(dr("DivCd")), "&nbsp;", dr("DivCd")), vData, c, _
                        "select Descr from hr_div_ref where Div_Cd='" & IIf(IsDBNull(dr("DivCd")), "", dr("DivCd")) & "'")
                GetData("DeptCd", IIf(IsDBNull(dr("DeptCd")), "&nbsp;", dr("DeptCd")), vData, c, _
                        "select Descr from hr_dept_ref where Dept_Cd='" & IIf(IsDBNull(dr("DeptCd")), "", dr("DeptCd")) & "'")
                GetData("SectionCd", IIf(IsDBNull(dr("SectionCd")), "&nbsp;", dr("SectionCd")), vData, c, _
                        "select Descr from hr_section_ref where Section_Cd='" & IIf(IsDBNull(dr("SectionCd")), "", dr("SectionCd")) & "'")
                GetData("UnitCd", IIf(IsDBNull(dr("UnitCd")), "&nbsp;", dr("UnitCd")), vData, c, _
                        "select Descr from hr_unit_ref where Unit_Cd='" & IIf(IsDBNull(dr("UnitCd")), "", dr("UnitCd")) & "'")
                GetData("EmploymentType", IIf(IsDBNull(dr("EmploymentType")), "&nbsp;", dr("EmploymentType")), vData, c, _
                        "select Descr from hr_employment_type where EmploymentType='" & _
                        IIf(IsDBNull(dr("EmploymentType")), "", dr("EmploymentType")) & "'")
                GetData("Grade_Cd", dr("Grade_Cd"), vData, c, "")
                GetData("Emp_Status", IIf(IsDBNull(dr("Emp_Status")), "&nbsp;", dr("Emp_Status")), vData, c, _
                        "select Descr from py_employee_stat where Status_Code='" & _
                        IIf(IsDBNull(dr("Emp_Status")), "", dr("Emp_Status")) & "'")
                GetData("Pay_Cd", IIf(IsDBNull(dr("Pay_Cd")), "&nbsp;", dr("Pay_Cd")), vData, c, "")
                GetData("Civil_Cd", IIf(IsDBNull(dr("Civil_Cd")), "&nbsp;", dr("Civil_Cd")), vData, c, _
                        "select Descr from py_civil_ref where Civil_Cd='" & IIf(IsDBNull(dr("Civil_Cd")), "", dr("Civil_Cd")) & "'")
                GetData("Tax_Cd", IIf(IsDBNull(dr("Tax_Cd")), "&nbsp;", dr("Tax_Cd")), vData, c, "")

                If Session("SupervisorCd") = "1" Then
                    If Not IsDBNull(dr("SupervisorCd")) Then
                        GetOfficer(dr("SupervisorCd"), vData, c)
                    Else
                        GetData("SupervisorCd", "", vData, c, "select Emp_Lname+', '+Emp_Fname from py_emp_master " & _
                            "where Emp_Cd='" & IIf(IsDBNull(dr("SupervisorCd")), "", dr("SupervisorCd")) & "'")
                    End If
                End If

                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY:  VIC GATCHALIAN                                                     ''
                '' DATE MODIFIED: 3/19/2013                                                         ''
                '' PURPOSE: TO DISPLAY THE 2ND AND 3RD LEVEL APPROVING OFFICER.                     ''
                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                If Session("Approving") = "1" Then
                    If Not IsDBNull(dr("Approving")) Then
                        GetOfficer(dr("Approving"), vData, c)
                    Else
                        GetData("Recommending", "", vData, c, "select Emp_Lname+', '+Emp_Fname from py_emp_master " & _
                            "where Emp_Cd='" & IIf(IsDBNull(dr("Approving")), "", dr("Approving")) & "'")
                    End If
                End If

                If Session("Noting") = "1" Then
                    If Not IsDBNull(dr("Noting")) Then
                        GetOfficer(dr("Noting"), vData, c)
                    Else
                        GetData("Noting", "", vData, c, "select Emp_Lname+', '+Emp_Fname from py_emp_master " & _
                            "where Emp_Cd='" & IIf(IsDBNull(dr("Noting")), "", dr("Noting")) & "'")
                    End If
                End If
                ''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''''''''''''''''''''''

                GetData("Male", IIf(dr("Male") = 1, "Male", "Female"), vData, c, "")

                If Session("Bday") = "1" Then
                    If IsDBNull(dr("Bday")) Then
                        vData.AppendLine("<td class='labelR'>&nbsp;</td>")
                    Else
                        vData.AppendLine("<td class='labelR'>" & Format(dr("Bday"), "MM/dd/yyyy") & "</td>")
                    End If
                End If
                If Session("Age") = "1" Then
                    If Not IsDBNull(dr("Bday")) Then
                        vData.AppendLine("<td class='labelR'>" & _
                            Format(Math.Round(DateDiff(DateInterval.Day, CDate(dr("Bday")), Now) / 365, 2), "#0.00") & "</td>")
                    Else
                        vData.AppendLine("<td class='labelR'>0.00</td>")
                    End If
                End If
                If Session("Start_Date") = "1" Then
                    If IsDBNull(dr("Start_Date")) Then
                        vData.AppendLine("<td class='labelR'>&nbsp;</td>")
                    Else
                        vData.AppendLine("<td class='labelR'>" & Format(dr("Start_Date"), "MM/dd/yyyy") & "</td>")
                    End If
                End If
                If Session("Date_Resigned") = "1" Then
                    If IsDBNull(dr("Date_Resign")) Then
                        vData.AppendLine("<td class='labelR'>&nbsp;</td>")
                    Else
                        vData.AppendLine("<td class='labelR'>" & Format(dr("Date_Resign"), "MM/dd/yyyy") & "</td>")
                    End If
                End If
                If Session("Years_of_Service") = "1" Then
                    If Not IsDBNull(dr("Start_Date")) Then
                        vData.AppendLine("<td class='labelR'>" & _
                            Format(Math.Round(DateDiff(DateInterval.Day, CDate(dr("Start_Date")), Now) / 365, 2), "#0.00") & "</td>")
                    Else
                        vData.AppendLine("<td class='labelR'>0.00</td>")
                    End If
                End If

                If dr("Confidential") = 1 And Session("userlevel") = 0 Then
                    vData.AppendLine("<td class='labelL'>RESTRICTED</td>")
                    vData.AppendLine("<td class='labelL'>RESTRICTED</td>")
                    vData.AppendLine("<td class='labelL'>RESTRICTED</td>")
                Else
                    GetData("Rate_Year", Format(dr("Rate_Year"), "##,###,##0.00"), vData, c, "")
                    GetData("Month_Rate", Format(dr("Rate_Month"), "##,###,##0.00"), vData, c, "")
                    GetData("Rate_Day", Format(dr("Rate_Day"), "##,###,##0.00"), vData, c, "")
                End If
                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY:  VIC GATCHALIAN                           ''
                '' DATE MODIFIED: 7/17/2013                               ''
                '' PURPOSE: TO EXPOSE THE GRACE PERIOD AND MOBILE NO.     ''
                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                GetData("DailyPaid", IIf(dr("DailyPaid") = 1, "Yes", "No"), vData, c, "")
                GetData("GracePeriod", Format(dr("GracePeriod"), "#0.00"), vData, c, "")
                ''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''

                GetData("Emp_Address", IIf(IsDBNull(dr("Emp_Address")), "&nbsp;", dr("Emp_Address")), vData, c, "")
                GetData("Emp_Tel", IIf(IsDBNull(dr("Emp_Tel")), "&nbsp;", dr("Emp_Tel")), vData, c, "")
                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY:  VIC GATCHALIAN                           ''
                '' DATE MODIFIED: 7/17/2013                               ''
                '' PURPOSE: TO EXPOSE THE GRACE PERIOD AND MOBILE NO.     ''
                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                GetData("MobileNo", IIf(IsDBNull(dr("MobileNo")), "&nbsp;", dr("MobileNo")), vData, c, "")
                ''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''

                GetData("Emp_Email", IIf(IsDBNull(dr("Emp_Email")), "&nbsp;", dr("Emp_Email")), vData, c, "")
                GetData("Sss_No", IIf(IsDBNull(dr("Sss_No")), "&nbsp;", dr("Sss_No")), vData, c, "")
                GetData("Pagibig_No", IIf(IsDBNull(dr("Pagibig_No")), "&nbsp;", dr("Pagibig_No")), vData, c, "")
                GetData("Tin", IIf(IsDBNull(dr("Tin")), "&nbsp;", dr("Tin")), vData, c, "")
                GetData("PhicNo", IIf(IsDBNull(dr("PhicNo")), "&nbsp;", dr("PhicNo")), vData, c, "")
                GetData("Acct_No", IIf(IsDBNull(dr("Acct_No")), "&nbsp;", dr("Acct_No")), vData, c, "")
                .AppendLine("</tr>")
                vClass = IIf(vClass = "odd", "even", "odd")
            Loop
            dr.Close()
            cm.Dispose()
            c.Close()
            .AppendLine("</table>")
            .AppendLine("</center>")
            .AppendLine("</body>")
            .AppendLine("</html>")
            IO.File.WriteAllText(Server.MapPath(".") & "\downloads\" & Session.SessionID & "-empmaster.html", .ToString)
            vSrc = "downloads/" & Session.SessionID & "-empmaster.html"
        End With
    End Sub
    Private Sub GetOfficer(ByVal pSupervisor As String, ByRef pData As StringBuilder, ByRef c As SqlClient.SqlConnection)
        Dim cm As New SqlClient.SqlCommand("", c)
        Dim rs As SqlClient.SqlDataReader
        Dim vSup() As String
        Dim i As Integer
        Dim vDump As String = "<td class='labelL'>"

        vSup = pSupervisor.Split(",")
        For i = 0 To UBound(vSup)
            cm.CommandText = "select Emp_Lname,Emp_Fname from py_emp_master where Emp_Cd='" & vSup(i) & "'"
            Try
                rs = cm.ExecuteReader
                If rs.Read Then
                    vDump += rs("Emp_Lname") & ", " & rs("Emp_Fname") & "<br/>"
                End If
                rs.Close()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to retrieve Approving Officer info. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                Exit Sub
            End Try
        Next
        If vDump.Contains("<br/>") Then
            vDump = Mid(vDump, 1, Len(vDump) - 5)
        End If
        vDump += "</td>"
        pData.AppendLine(vDump)
    End Sub

    Protected Sub chkDateHired_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkDateHired.CheckedChanged
        If chkDateHired.Checked = True Then
            cmbDayFr.Enabled = True
            cmbDayTo.Enabled = True
            cmbYrFr.Enabled = True
            cmbYrTo.Enabled = True
            cmbMonthFr.Enabled = True
            cmbMonthTo.Enabled = True
        Else
            cmbDayFr.Enabled = False
            cmbDayTo.Enabled = False
            cmbYrFr.Enabled = False
            cmbYrTo.Enabled = False
            cmbMonthFr.Enabled = False
            cmbMonthTo.Enabled = False
        End If
    End Sub
    Protected Sub chkResign_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkResign.CheckedChanged
        If chkResign.Checked = True Then
            cmbResigned.Enabled = True
            cmbMonth.Enabled = True
            cmbYear.Enabled = True
        Else
            cmbResigned.Enabled = False
            cmbMonth.Enabled = False
            cmbYear.Enabled = False
        End If
    End Sub
End Class
