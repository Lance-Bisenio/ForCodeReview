
Partial Class printotreport
    Inherits System.Web.UI.Page

End Class
