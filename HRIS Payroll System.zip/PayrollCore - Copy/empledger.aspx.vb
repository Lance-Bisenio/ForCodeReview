Imports denaro
Partial Class empledger
    Inherits System.Web.UI.Page

    Public vScript As String = ""
    Public vLedger As String = ""
    Public vsumm As String = ""

    Dim vPeriods() As String
    Dim vTaxGroup() As String
    Dim vIncentives() As String
    Dim vStatement() As String
    Dim vNonTax() As String
    Dim vB4Tax() As String
    Dim vSQLB4Tax As String
    Dim vSQLStr As String
    Dim vSQLNonTax As String
    Dim vRows As New Collection
    Dim vAccrueGross As Decimal
    Dim vAccrueContr As Decimal
    Dim vLastPayDate As Date
    Dim vItems() As String
    Dim cmSysCntrl As New SqlClient.SqlCommand
    Dim rsSysCntrl As SqlClient.SqlDataReader

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Session("returnaddr") = "emp.aspx"
            Server.Transfer("index.aspx")
        End If

        If Not CanRun(Session("caption"), Request.Item("id")) Then
            Session("denied") = "1"
            Server.Transfer("main.aspx")
            Exit Sub
        End If


        Dim c As New SqlClient.SqlConnection(connStr)
        
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim iLoop As Integer
        Dim vStr As String = ""
        Dim vDump As String = ""

        If Not IsPostBack Then
            cmbYear.Items.Clear()
            For iLoop = Now.Year - 3 To Now.Year
                cmbYear.Items.Add(iLoop)
            Next iLoop
            cmbYear.SelectedValue = Now.Year
        End If

        PopulateCols()
        c.Open()
        cm.Connection = c
        cmSysCntrl.Connection = c
        cmSysCntrl.CommandText = "select * from py_syscntrl"
        rsSysCntrl = cmSysCntrl.ExecuteReader
        rsSysCntrl.Read()

        If Not IsPostBack Then
            lblCaption.CssClass = "labelL"
            lblCaption.Text = "Employee Ledger"
            BuildCombo("select Rc_Cd,Descr from rc where exists (select User_Id from rights_list where User_Id='" & _
                    Session("uid") & "' and property='rc' and Property_Value=Rc_Cd) order by Descr", cmbRC)

            BuildCombo("select AgencyCd,AgencyName from agency where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='agency' and Property_Value=AgencyCd) order by AgencyName", cmbOfc)

            BuildCombo("select Div_Cd,Descr from hr_div_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='division' and Property_Value=Div_Cd) order by Descr", cmbDiv)

            BuildCombo("select Dept_Cd,Descr from hr_dept_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='department' and Property_Value=Dept_Cd) order by Descr", cmbDept)

            BuildCombo("select Section_Cd,Descr from hr_section_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='section' and Property_Value=Section_Cd) order by Descr", cmbSection)

            BuildCombo("select Unit_Cd,Descr from hr_unit_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='unit' and Property_Value=Unit_Cd) order by Descr", cmbUnit)

            BuildCombo("select EmploymentType,Descr from hr_employment_type where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='employmenttype' and Property_Value=EmploymentType) order by Descr", cmbEmpType)


            cmbRC.Items.Add("All")
            cmbRC.SelectedValue = "All"
            cmbOfc.Items.Add("All")
            cmbOfc.SelectedValue = "All"
            cmbDiv.Items.Add("All")
            cmbDiv.SelectedValue = "All"
            cmbDept.Items.Add("All")
            cmbDept.SelectedValue = "All"
            cmbSection.Items.Add("All")
            cmbSection.SelectedValue = "All"
            cmbUnit.Items.Add("All")
            cmbUnit.SelectedValue = "All"
            cmbEmpType.Items.Add("All")
            cmbEmpType.SelectedValue = "All"

            'get non-taxable incentives
            cm.CommandText = "select Incentive_Cd from py_other_incentvs where Taxable=0 order by Incentive_Cd"
            rs = cm.ExecuteReader
            vStr = ""
            Do While rs.Read
                vStr += rs("Incentive_Cd") & ","
            Loop
            rs.Close()
            If vStr <> "" Then
                vStr = Mid(vStr, 1, Len(vStr) - 1)
                Session("nontax") = vStr
            End If

            'GET TAXABLE GROUP
            cm.CommandText = "select distinct MaxTaxExempt from py_other_incentvs where Taxable <> 0 and " & _
               "MaxTaxExempt is not null and Grouped <> 0"
            rs = cm.ExecuteReader

            vStr = ""
            Do While rs.Read
                vStr += rs("MaxTaxExempt").ToString & ","
            Loop
            rs.Close()
            If vStr <> "" Then
                vStr = Mid(vStr, 1, Len(vStr) - 1)
                Session("taxgroup") = vStr
            End If

        End If
        If Session("nontax") <> Nothing Then
            vNonTax = Session("nontax").ToString.Split(",")
        End If
        If Session("taxgroup") <> Nothing Then
            vTaxGroup = Session("taxgroup").ToString.Split(",")
            ReDim vIncentives(vTaxGroup.Length - 1)
            ReDim vStatement(vTaxGroup.Length - 1)
            ReDim vB4Tax(vTaxGroup.Length - 1)
        Else
            ReDim vIncentives(0)
            ReDim vStatement(0)
            ReDim vB4Tax(0)
        End If
        If Session("periods") <> Nothing Then
            vPeriods = Session("periods").ToString.Split(",")
        End If

        
        'asSIGN LIST OF INCENTIVES FOR EACH GROUP
        For iLoop = 0 To UBound(vTaxGroup)
            cm.CommandText = "select Incentive_Cd from py_other_incentvs where Taxable <> 0 and " & _
               "Grouped <> 0 and MaxTaxExempt=" & vTaxGroup(iLoop) & " order by Incentive_Cd"
            vIncentives(iLoop) = ""
            rs = cm.ExecuteReader
            Do While rs.Read
                vIncentives(iLoop) += rs("Incentive_Cd") & ","
            Loop
            rs.Close()
            If vIncentives(iLoop) <> "" Then
                vIncentives(iLoop) = Mid(vIncentives(iLoop), 1, Len(vIncentives(iLoop)) - 1)
            End If
        Next iLoop

        'CREATE THE STATEMENTS  for taxable
        Dim iStart As Integer
        Dim vIncent() As String
        For iLoop = 0 To UBound(vStatement)
            vStatement(iLoop) = "(sum("
            vB4Tax(iLoop) = "(sum("
            vIncent = vIncentives(iLoop).Split(",")
            For iStart = 0 To UBound(vIncent)
                vStatement(iLoop) += GetCode(vIncent(iStart))
                vB4Tax(iLoop) += GetCode(vIncent(iStart))
            Next iStart
            If Len(vStatement(iLoop)) > 5 Then
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY:  VIC GATCHALIAN                                  ''
                '' DATE MODIFIED: 12/13/2012                                     ''
                '' PURPOSE: TO ADD THE SENIOR ALLOWANCE FOR 0 EXEMPTION          ''
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                ''''''''''''''''''' OLD CODE ''''''''''''''''''''''''''''''''''''''
                'vStatement(iLoop) = Mid(vStatement(iLoop), 1, Len(vStatement(iLoop)) - 1) & ") - " & _
                '   vTaxGroup(iLoop) & ") as TotIncent" & iLoop
                'vB4Tax(iLoop) = Mid(vB4Tax(iLoop), 1, Len(vB4Tax(iLoop)) - 1) & ")) as TotIncent" & iLoop
                ''''''''''''''''''' END OLD CODE ''''''''''''''''''''''''''''''''''
                If Val(vTaxGroup(iLoop)) = 0 Then '0 exemption 
                    vStatement(iLoop) = Mid(vStatement(iLoop), 1, Len(vStatement(iLoop)) - 1) & _
                        "+SeniorAllowance) - " & vTaxGroup(iLoop) & ") as TotIncent" & iLoop
                    vB4Tax(iLoop) = Mid(vB4Tax(iLoop), 1, Len(vB4Tax(iLoop)) - 1) & "+SeniorAllowance)) as TotIncent" & iLoop
                Else
                    vStatement(iLoop) = Mid(vStatement(iLoop), 1, Len(vStatement(iLoop)) - 1) & ") - " & _
                        vTaxGroup(iLoop) & ") as TotIncent" & iLoop
                    vB4Tax(iLoop) = Mid(vB4Tax(iLoop), 1, Len(vB4Tax(iLoop)) - 1) & ")) as TotIncent" & iLoop
                End If
                ''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''
            Else
                vStatement(iLoop) = ""
                vB4Tax(iLoop) = ""
            End If
        Next iLoop
        'create the statements for non-tax
        'vSQLNonTax = ""
        'For iLoop = 0 To UBound(vNonTax)
        '    vSQLNonTax = vSQLNonTax & ",sum(" & Replace(GetCode(vNonTax(iLoop)), "+", ")") & _
        '       " as NonTax" & iLoop
        'Next iLoop

        vSQLNonTax = ",sum("

        For iLoop = 0 To UBound(vNonTax)
            If GetCode(vNonTax(iLoop)) <> "" Then
                vSQLNonTax += GetCode(vNonTax(iLoop))
            End If
        Next
        If vSQLNonTax <> "" Then
            vSQLNonTax = Mid(vSQLNonTax, 1, Len(vSQLNonTax) - 1) & ") as NonTax"
        End If

        vSQLStr = ","
        vSQLB4Tax = ","
        For iLoop = 0 To UBound(vTaxGroup)
            If vStatement(iLoop) <> "" Then
                vSQLStr += vStatement(iLoop) & ","
                vSQLB4Tax += vB4Tax(iLoop) & ","
            End If
        Next iLoop

        'build rows collection
        Do While vRows.Count > 0
            vRows.Remove(1)
        Loop
        With vRows
            .Add("Basic Pay:")
            .Add("Transpo:")
            .Add("ACA/PERA:")
            .Add("Absences/Tardy:")
            .Add("Overtime:")
            .Add("Sub-Total (Basic):")
            .Add("Other Income (Non-Tax)")
            For iLoop = 0 To UBound(vNonTax)
                .Add(Space(5) & vNonTax(iLoop) & ":")
            Next iLoop
            .Add(Space(5) & "Meal Allowance:")        ' mealallow
            .Add("Sub-Total (NonTax):")
            vDump = "Emr.TIN,Emp.Id,Employee Name,Tax Code,Monthly Rate,Emp. TIN,Date Hired,Date Resigned,Address,Total Basic,"

            vsumm = "<tr class='titleBar'><th>Total Basic</th>"
            For iLoop = 0 To UBound(vTaxGroup)
                .Add("Other Income (" & vTaxGroup(iLoop) & " exemption):")
                vIncent = vIncentives(iLoop).Split(",")
                For iStart = 0 To UBound(vIncent)
                    .Add(Space(5) & vIncent(iStart) & ":")
                Next iStart
                '''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY:  VIC GATCHALIAN                  ''
                '' DATE MODIFIED: 12/13/2012                     ''
                '' PURPOSE: TO ADD SENIORITY ALLOWANCE IF TAX    ''
                ''          GROUP=0 EXEMPTION                    ''
                '''''''''''''''''''''''''''''''''''''''''''''''''''
                If Val(vTaxGroup(iLoop)) = 0 Then
                    .Add("Seniority Allowance:")
                End If
                ''''''''''''''' END OF MODIFICATION '''''''''''''''

                .Add("Sub-Total (" & vTaxGroup(iLoop) & " exemption):")
                vsumm += "<th>Income (" & _
                    vTaxGroup(iLoop) & " exemption)</th>"
                vDump += "Income (" & vTaxGroup(iLoop) & " exemption),"
            Next iLoop
            .Add("Total Income:")
            .Add("Tax Withheld:")
            .Add("SSS Cont.:")
            .Add("HDMF Cont.:")
            .Add("PhilHealth Cont.:")
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:  VIC GATCHALIAN                               ''
            '' DATE MODIFIED: 10/22/2012                                  ''
            '' PURPOSE: TO DEDUCTION UNION DUES                           ''
            '' EXCEPTIONS: FOR MANILA PEN USE ONLY                        ''
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            .Add("Union Dues:")
            '''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''
            .Add("Total Deduction:")
        End With
        ReDim vItems(vRows.Count - 1)
        For iLoop = 1 To vRows.Count
            vItems(iLoop - 1) = vRows(iLoop)
        Next iLoop

        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                                        ''
        '' DATE MODIFIED: 10/22/2012                                           ''
        '' PURPOSE: TO CHANGE THE "LESS H. PREMIUS" COLUMN TO "UNION DUES" COL ''
        '' EXCEPTIONS: FOR MANILA PEN USE ONLY                                 ''
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        'vsumm += "<th>Accrued Income</th>" & _
        '   "<th>Less Accrued Contr.</th>" & _
        '   "<th>Gross Inc (Prev Employer)</th>" & vbTab & _
        '   "<th>Less Exemption</th>" & _
        '   "<th>Less Contr</th>" & _
        '   "<th>Less H. Premiums</th>" & _
        '   "<th>Total Taxable</th>" & _
        '   "<th>Tax Withheld (Curr)</th>" & _
        '   "<th>Tax Withheld (Prev)</th>" & _
        '   "<th>Tax Withheld (Total)</th>" & _
        '   "<th>Tax Due</th>" & _
        '   "<th>(Over)/ Under</th></tr>"
        'vDump += "Accrued Income,Less Accrued Contr.,Gross In (Prev Employer),Less Exemption,Less Contr," & _
        '    "Less H. Premiums,Total Taxable,Tax Withheld (Curr),Tax Withheld (Prev),Tax Withheld (Total)," & _
        '    "Tax Due,(Over)/Under" & vbCrLf
        '''''''''''''''''''''''' END ORIGINAL CODE ''''''''''''''''''''''''''''''''
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                                          ''
        '' DATE MODIFIED: 1/3/2013                                               ''
        '' PURPOSE: TO ADD THE CONTRIBUTION FROM PREVIOUS EMPLOYER               ''
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        ''''''''''''''''''''''' OLD CODE ''''''''''''''''''''''''''''''''''''''''''
        'vsumm += "<th>Accrued Income</th>" & _
        '   "<th>Less Accrued Contr.</th>" & _
        '   "<th>Gross Inc (Prev Employer)</th>" & vbTab & _
        '   "<th>Less Exemption</th>" & _
        '   "<th>Less Contr</th>" & _
        '   "<th>Less Union Dues</th>" & _
        '   "<th>Total Taxable</th>" & _
        '   "<th>Tax Withheld (Curr)</th>" & _
        '   "<th>Tax Withheld (Prev)</th>" & _
        '   "<th>Tax Withheld (Total)</th>" & _
        '   "<th>Tax Due</th>" & _
        '   "<th>(Over)/ Under</th></tr>"
        'vDump += "Accrued Income,Less Accrued Contr.,Gross In (Prev Employer),Less Exemption,Less Contr," & _
        '    "Less Union Dues,Total Taxable,Tax Withheld (Curr),Tax Withheld (Prev),Tax Withheld (Total)," & _
        '    "Tax Due,(Over)/Under" & vbCrLf
        ''''''''''''''''''''''' END OF OLD CODE '''''''''''''''''''''''''''''''''''
        vsumm += "<th>Accrued Income</th>" & _
           "<th>Less Accrued Contr.</th>" & _
           "<th>Gross Inc (Prev Employer)</th>" & vbTab & _
           "<th>Less Exemption</th>" & _
           "<th>Less Contr (Curr)</th>" & _
           "<th>Less Contr (Prev)</th>" & _
           "<th>Less Union Dues</th>" & _
           "<th>Total Taxable</th>" & _
           "<th>Tax Withheld (Curr)</th>" & _
           "<th>Tax Withheld (Prev)</th>" & _
           "<th>Tax Withheld (Total)</th>" & _
           "<th>Tax Due</th>" & _
           "<th>(Over)/ Under</th></tr>"

        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                                          ''
        '' DATE MODIFIED: 1/8/2013                                               ''
        '' PURPOSE: TO ADD THE OTHER COMPANY INFORMATION FOR BIR RELEAF PURPOSE  ''
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        ''''''''''''''''''''' OLD CODE ''''''''''''''''''''''''''''''''''''''''''''
        'vDump += "Accrued Income,Less: Accrued Contr.,Gross Income (Prev. Employer),Less: Exemption,Less: Contr. (Curr),Less: Contr. (Prev)," & _
        '    "Less: Union Dues,Total Taxable,Tax Withheld (Curr),Tax Withheld (Prev),Tax Withheld (Total)," & _
        '    "Tax Due,(Over)/Under" & vbCrLf
        ''''''''''''''''''''' END OLD CODE ''''''''''''''''''''''''''''''''''''''''
        vDump += "Accrued Income,Less: Accrued Contr.,Gross Income (Prev. Employer),Less: Exemption," & _
            "Less: Contr. (Curr),Less: Contr. (Prev),Less: Union Dues,Total Taxable,Tax Withheld (Curr)," & _
            "Tax Withheld (Prev),Tax Withheld (Total),Tax Due,(Over)/Under,Total Non-Taxable," & _
            "Tax Withheld (Dec),Company Name,Attention,Company Address" & vbCrLf
        ''''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''''''''

        
        ''''''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''''''
        '''''''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''''''
        Session.Remove("header")
        Session.Remove("ledger")
        Session.Remove("summary")
        Session("header") = vDump
        Session("ledger") = vLedger
        Session("summary") = vsumm

        rsSysCntrl.Close()
        cmSysCntrl.Dispose()
        cm.Dispose()
        c.Close()
        c.Dispose()
        vLedger += "</table>"
    End Sub
    Private Function GetCode(ByVal pIncentive As String) As String
        Dim iCd As Integer

        GetCode = ""
        For iCd = 1 To 60
            If rsSysCntrl("OthIncent" & iCd & "Cd") = pIncentive Then
                GetCode = "Other_Incent" & iCd & "+"
                Exit For
            End If
        Next iCd
    End Function

    Private Sub SetLetters(ByVal pLetter As String)
        Select Case LCase(pLetter)
            Case "a"
                cmdA.Visible = True
            Case "b"
                cmdB.Visible = True
            Case "c"
                cmdC.Visible = True
            Case "d"
                cmdD.Visible = True
            Case "e"
                cmdE.Visible = True
            Case "f"
                cmdF.Visible = True
            Case "g"
                cmdG.Visible = True
            Case "h"
                cmdH.Visible = True
            Case "i"
                cmdI.Visible = True
            Case "j"
                cmdJ.Visible = True
            Case "k"
                cmdK.Visible = True
            Case "l"
                cmdL.Visible = True
            Case "m"
                cmdM.Visible = True
            Case "n"
                cmdN.Visible = True
            Case "o"
                cmdO.Visible = True
            Case "p"
                cmdP.Visible = True
            Case "q"
                cmdQ.Visible = True
            Case "r"
                cmdR.Visible = True
            Case "s"
                cmdS.Visible = True
            Case "t"
                cmdT.Visible = True
            Case "u"
                cmdU.Visible = True
            Case "v"
                cmdV.Visible = True
            Case "w"
                cmdW.Visible = True
            Case "x"
                cmdX.Visible = True
            Case "y"
                cmdY.Visible = True
            Case "z"
                cmdZ.Visible = True
        End Select
    End Sub
    Private Sub DataRefresh(ByVal pLetter As String)

        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim dr As SqlClient.SqlDataReader
        Dim da As SqlClient.SqlDataAdapter
        Dim ds As New DataSet
        Dim vSQL As String = ""
        Dim vFilter As String = ""
        Dim vLtrFilter As String = ""


        vFilter = " and " & cmbType.SelectedValue & " like '" & pLetter & "%' "
        vFilter += cmbStatus.SelectedValue

        If cmbStatus.SelectedIndex = 1 Then 'resigned option was chosen, retrieve only resigned for the selected year
            vFilter += " and year(Date_Resign)=" & cmbYear.SelectedValue
        End If
        vLtrFilter += cmbStatus.SelectedValue

        If cmbRC.SelectedValue <> "All" Then   'filter by cost center
            vFilter += " and Rc_Cd='" & cmbRC.SelectedValue & "' "

            vLtrFilter += " and Rc_Cd='" & cmbRC.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='rc' and Property_Value=Rc_Cd) "
            vLtrFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='rc' and Property_Value=Rc_Cd) "
        End If

        If cmbOfc.SelectedValue <> "All" Then        'filter by office/agency
            vFilter += " and Agency_Cd='" & cmbOfc.SelectedValue & "' "
            vLtrFilter += " and Agency_Cd='" & cmbOfc.SelectedValue & "' "
        Else
            vFilter += "  and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='agency' and Property_Value=Agency_Cd) "
            vLtrFilter += "  and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='agency' and Property_Value=Agency_Cd) "
        End If
        If cmbDiv.SelectedValue <> "All" Then      'filter by division
            vFilter += " and Divcd='" & cmbDiv.SelectedValue & "' "
            vLtrFilter += " and Divcd='" & cmbDiv.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='division' and Property_Value=DivCd) "
            vLtrFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='division' and Property_Value=DivCd) "
        End If
        If cmbDept.SelectedValue <> "All" Then  'filter by departments
            vFilter += " and DeptCd='" & cmbDept.SelectedValue & "' "
            vLtrFilter += " and DeptCd='" & cmbDept.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='department' and Property_Value=DeptCd) "
            vLtrFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='department' and Property_Value=DeptCd) "
        End If
        If cmbSection.SelectedValue <> "All" Then 'filter by section
            vFilter += " and SectionCd='" & cmbSection.SelectedValue & "' "
            vLtrFilter += " and SectionCd='" & cmbSection.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='section' and Property_Value=SectionCd) "
            vLtrFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='section' and Property_Value=SectionCd) "
        End If
        If cmbUnit.SelectedValue <> "All" Then  'filter by units
            vFilter += " and UnitCd='" & cmbUnit.SelectedValue & "' "
            vLtrFilter += " and UnitCd='" & cmbUnit.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='unit' and Property_Value=UnitCd) "
            vLtrFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='unit' and Property_Value=UnitCd) "
        End If
        If cmbEmpType.SelectedValue <> "All" Then 'filter by employment types
            vFilter += " and EmploymentType='" & cmbEmpType.SelectedValue & "' "
            vLtrFilter += " and EmploymentType='" & cmbEmpType.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='employmenttype' and Property_Value=EmploymentType) "
            vLtrFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='employmenttype' and Property_Value=EmploymentType) "
        End If

        Session("filter") = vFilter
        vSQL = "select Emp_Cd,Emp_Lname,Emp_Fname,py_emp_master.Tax_Cd,(select Exemption from py_tax_ref where " & _
            "py_tax_ref.Tax_Cd=py_emp_master.Tax_Cd) as Exemption,Rate_Month from " & _
            "py_emp_master where Emp_Cd is not null " & vFilter & _
            " order by Emp_Lname,Emp_Fname"
        da = New SqlClient.SqlDataAdapter(vSQL, c)
        da.Fill(ds, "EMP")

        tblEmp.DataSource = ds.Tables("EMP")
        tblEmp.DataBind()
        da.Dispose()
        ds.Dispose()

        c.Open()
        cm.Connection = c
        cm.CommandText = "select distinct substring(Emp_Lname,1,1) as Letters from " & _
            "py_emp_master where Emp_Cd is not null  " & vLtrFilter
        dr = cm.ExecuteReader
        EnableAll(False)
        Do While dr.Read
            SetLetters(dr("Letters"))
        Loop
        dr.Close()
        cm.Dispose()
        c.Close()
        c.Dispose()
    End Sub

    Private Sub cmdA_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdA.Click, _
        cmdB.Click, cmdC.Click, cmdD.Click, cmdE.Click, cmdF.Click, cmdG.Click, cmdH.Click, cmdI.Click, _
        cmdJ.Click, cmdK.Click, cmdL.Click, cmdM.Click, cmdN.Click, cmdO.Click, cmdP.Click, cmdQ.Click, _
        cmdR.Click, cmdS.Click, cmdT.Click, cmdU.Click, cmdV.Click, cmdW.Click, cmdX.Click, cmdY.Click, cmdZ.Click
        Session("letter") = CType(sender, LinkButton).Text
        tblEmp.SelectedIndex = -1
        tblEmp.PageIndex = 0
        DataRefresh(Session("letter"))
    End Sub
    Private Sub EnableAll(Optional ByVal pState As Boolean = False)
        cmdA.Visible = pState : cmdB.Visible = pState : cmdC.Visible = pState : cmdD.Visible = pState
        cmdE.Visible = pState : cmdF.Visible = pState : cmdG.Visible = pState : cmdH.Visible = pState
        cmdI.Visible = pState : cmdJ.Visible = pState : cmdK.Visible = pState : cmdL.Visible = pState
        cmdM.Visible = pState : cmdN.Visible = pState : cmdO.Visible = pState : cmdP.Visible = pState
        cmdQ.Visible = pState : cmdR.Visible = pState : cmdS.Visible = pState : cmdT.Visible = pState
        cmdU.Visible = pState : cmdV.Visible = pState : cmdW.Visible = pState : cmdX.Visible = pState
        cmdY.Visible = pState : cmdZ.Visible = pState
    End Sub

    Protected Sub cmdSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSearch.Click
        'Session("letter") = txtSearch.Text
        'Response.Write("lance.test")
        DataRefresh(txtSearch.Text)
    End Sub

    Protected Sub cmdReturn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.Click
        Session.Remove("header")
        Session.Remove("letter")
        Session.Remove("filter")
        Session.Remove("nontax")
        Session.Remove("taxgroup")
        Session.Remove("periods")
        Session.Remove("2316dump")
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub tblEmp_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles tblEmp.PageIndexChanging
        tblEmp.PageIndex = e.NewPageIndex
        DataRefresh(txtSearch.Text)
    End Sub

    Protected Sub tblEmp_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tblEmp.SelectedIndexChanged
        If Session("periods") <> "" Then
            GetLedger(tblEmp.SelectedRow.Cells(0).Text, False, False, tblEmp.SelectedRow.Cells(4).Text, _
                Val(tblEmp.SelectedRow.Cells(5).Text))
        Else
            vScript = "alert('No Payroll transactions for the selected year. Please select another year.');"
        End If
    End Sub

    Protected Sub cmbYear_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbYear.SelectedIndexChanged
        PopulateCols()
    End Sub
    Private Sub PopulateCols()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim vStr As String = ""

        c.Open()
        cm.Connection = c
        cm.CommandText = "select distinct PayDate from py_report where year(PayDate)=" & cmbYear.SelectedValue & _
            " order by PayDate"
        rs = cm.ExecuteReader
        vLedger = "<table border='1' cellpadding='1' cellspacing='1' style='border-collapse:collapse; width: 100%;'>" & _
            "<tr class='titleBar'><th style='width: 150px;'>Particulars</th>"
        Do While rs.Read
            vLedger += "<th>" & Format(CDate(rs("PayDate")), "MM/dd") & "</th>"
            vStr += Format(CDate(rs("PayDate")), "yyyy/MM/dd") & ","
            vLastPayDate = CDate(rs("PayDate"))
        Loop
        vLedger += "<th>TOTAL</th></tr>"
        If vStr <> "" Then
            vStr = Mid(vStr, 1, Len(vStr) - 1)
        End If
        rs.Close()
        cm.Dispose()
        c.Close()
        c.Dispose()
        Session("periods") = vStr
    End Sub
    Private Function GetNumber(ByVal pIncentive As String) As Integer
        Dim iCtr As Integer
        For iCtr = 1 To 60
            If rsSysCntrl("OthIncent" & iCtr & "Cd") = pIncentive Then
                GetNumber = iCtr
                Exit For
            End If
        Next iCtr
    End Function

    Private Sub GetLedger(ByVal pIndex As String, ByVal pSave As Boolean, ByVal pOnce As Boolean, _
        ByVal pExemption As Decimal, ByVal pMonthRate As Decimal, _
        Optional ByVal pDump As String = "", Optional ByVal pFileName As String = "")

        Dim c As New SqlClient.SqlConnection(connStr)
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                                            ''
        '' DATE MODIFIED:  1/9/2012                                                ''
        '' PURPOSE: TO DETERMINE WHETHER THE EMPLOYEE HAS A GROSS UP FEATURE OR NOT''
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        Dim vIsNet As Boolean = False
        Dim vTmpSSS As Decimal = 0
        Dim vTmpPagIBIG As Decimal = 0
        Dim vTmpPHIC As Decimal = 0
        Dim cmRef As New SqlClient.SqlCommand("", c)
        Dim rsRef As SqlClient.SqlDataReader
        ''''''''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''''''
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                          ''
        '' DATE MODIFIED: 10/22/2012                             ''
        '' PURPOSE: TO SUPPORT THE DEDUCTION OF UNION DUES       ''
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        Dim vTmpUnionDues As Decimal = 0
        '''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''

        Dim vOnce As Boolean = pOnce
        'Dim cSysCntrl As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim vDump As String = pDump
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY: VIC GATCHALIAN                                 ''
        '' DATE MODIFIED: 1/12/2013                                    ''
        '' PURPOSE: TO CREATE A VARIABLE THAT WILL CATER FOR 2316 PRINT''
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        Dim v2316Dump As String = ""
        '''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''''

        Dim vStr As String
        Dim iCol As Integer
        Dim iRow As Integer
        Dim iGrp As Integer
        Dim iCtr As Integer
        Dim vTot As Double
        Dim vPremium As Double
        Dim vPrevGross As Double
        Dim vPrevTax As Double
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                             ''
        '' DATE MODIFIED: 1/3/2013                                  ''
        '' PURPOSE: TO ADD THE CONTR AND 13TH MONTH FROM            ''
        ''          PREVIOUS(EMPLOYER)                              ''
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        Dim vPrevContr As Decimal = 0
        Dim vPrev13Tax As Decimal = 0
        '''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''

        Dim vSubIncent As Double
        'Dim vTotBasic As Double
        'Dim vTotOT As Double
        'Dim vTotRATA As Double
        'Dim vTotIncent As Double
        'Dim vTotAbsent As Double
        'Dim vTotSSS As Double
        'Dim vTotPagIBIG As Double
        'Dim vTotMedicare As Double
        Dim vTotTaxable As Double
        Dim vTaxDue As Double
        Dim vTotTaxWithheld As Double
        Dim vStrDump As String
        Dim vZeroCols As String
        Dim vIndex As Integer
        'Dim vShow As Boolean
        Dim vEmpty As Boolean
        Dim vAddStr As String
        'Dim vTIN As String
        Dim vPeriod() As String = Session("periods").ToString.Split(",")
        Dim vTotals() As Decimal
        Dim vClass As String = "odd"

        vLedger = Session("ledger")
        vsumm = Session("summary")

        c.Open()
        'cSysCntrl.Open()
        cm.Connection = c
        cmSysCntrl.Connection = c
        cmSysCntrl.CommandText = "select * from py_syscntrl"
        rsSysCntrl = cmSysCntrl.ExecuteReader
        rsSysCntrl.Read()

        vZeroCols = ""
        ReDim vTotals(vRows.Count - 1)
        For iCtr = 0 To UBound(vTotals)
            vTotals(iCtr) = 0
        Next iCtr

        For iCtr = 1 To vRows.Count
            If vRows(iCtr).ToString.Contains("Total Income:") Or vRows(iCtr).ToString.Contains("Total Deduction:") Then
                vClass = "ttl"
            End If
            If vRows(iCtr).ToString.Contains("Sub-Total") Then
                vClass = "subttl"
            End If

            vItems(iCtr - 1) = "<tr class='" & vClass & "'><td>" & vRows(iCtr) & "</td>"

            If vClass = "even" Or vClass = "ttl" Or vClass = "subttl" Then vClass = "odd" Else vClass = "even"
        Next iCtr

        For iCol = 0 To UBound(vPeriod)
            'MEALALLOW Was REMOVED (FOR GXS TRANSACTION ONLY)
            'ORIGINAL CODE sum(ACA+PERA+MEALALLOW) as ALLOWANCE
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:  VIC GATCHALIAN                                  ''
            '' DATE MODIFIED: 1/9/2012                                       ''
            '' PURPOSE: TO GET THE STATUS OF EMPLOYEE IF GROSS UP OR NOT     ''
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            cm.CommandText = "select IsNetAmt from py_emp_master where Emp_Cd='" & _
                pIndex & "'"
            vIsNet = False
            rs = cm.ExecuteReader
            If rs.Read Then
                If Not IsDBNull(rs("IsNetAmt")) Then
                    vIsNet = rs("IsNetAmt") = 1
                End If
            End If
            rs.Close()
            '''''''''''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''

            vStr = "select sum(Month_Rate) as Gross, sum(Absent+Tardiness) as Absents," & _
               "sum(G1+G2+G3+G4) as OfcOt,sum(SeniorAllowance) as Senior," & _
               "sum(Ot) as OtTotal, sum(Aca+Pera) as Allowance, 0 as Meal, 0 as Transpo," & _
               "sum(Other_Incent1) as Incent1, sum(Other_Incent2) as Incent2," & _
               "sum(Other_Incent3) as Incent3, sum(Other_Incent4) as Incent4," & _
               "sum(Other_Incent5) as Incent5, sum(Other_Incent6) as Incent6," & _
               "sum(Other_Incent7) as Incent7, sum(Other_Incent8) as Incent8," & _
               "sum(Other_Incent9) as Incent9, sum(Other_Incent10) as Incent10," & _
               "sum(Other_Incent11) as Incent11, sum(Other_Incent12) as Incent12," & _
               "sum(Other_Incent13) as Incent13, sum(Other_Incent14) as Incent14," & _
               "sum(Other_Incent15) as Incent15, sum(Other_Incent16) as Incent16," & _
               "sum(Other_Incent17) as Incent17, sum(Other_Incent18) as Incent18," & _
               "sum(Other_Incent19) as Incent19, sum(Other_Incent20) as Incent20," & _
               "sum(Other_Incent21) as Incent21, sum(Other_Incent22) as Incent22," & _
               "sum(Other_Incent23) as Incent23, sum(Other_Incent24) as Incent24," & _
               "sum(Other_Incent25) as Incent25, sum(Other_Incent26) as Incent26," & _
               "sum(Other_Incent27) as Incent27, sum(Other_Incent28) as Incent28," & _
               "sum(Other_Incent29) as Incent29, sum(Other_Incent30) as Incent30," & _
               "sum(Other_Incent31) as Incent31, sum(Other_Incent32) as Incent32," & _
               "sum(Other_Incent33) as Incent33, sum(Other_Incent34) as Incent34," & _
               "sum(Other_Incent35) as Incent35, sum(Other_Incent36) as Incent36," & _
               "sum(Other_Incent37) as Incent37, sum(Other_Incent38) as Incent38," & _
               "sum(Other_Incent39) as Incent39, sum(Other_Incent40) as Incent40," & _
               "sum(Other_Incent41) as Incent41, sum(Other_Incent42) as Incent42," & _
               "sum(Other_Incent43) as Incent43, sum(Other_Incent44) as Incent44," & _
               "sum(Other_Incent45) as Incent45, sum(Other_Incent46) as Incent46," & _
               "sum(Other_Incent47) as Incent47, sum(Other_Incent48) as Incent48," & _
               "sum(Other_Incent49) as Incent49, sum(Other_Incent50) as Incent50," & _
               "sum(Other_Incent51) as Incent51, sum(Other_Incent52) as Incent52," & _
               "sum(Other_Incent53) as Incent53, sum(Other_Incent54) as Incent54," & _
               "sum(Other_Incent55) as Incent55, sum(Other_Incent56) as Incent56," & _
               "sum(Other_Incent57) as Incent57, sum(Other_Incent58) as Incent58," & _
               "sum(Other_Incent59) as Incent59, sum(Other_Incent60) as Incent60," & _
               "sum(Month_Rate+Absent+Tardiness+Ot+Aca+MealAllow+Rata+Pera+SeniorAllowance+Other_Incent1+" & _
               "Other_Incent2+Other_Incent3+Other_Incent4+Other_Incent5+Other_Incent6+" & _
               "Other_Incent7+Other_Incent8+Other_Incent9+Other_Incent10+Other_Incent11+" & _
               "Other_Incent12+Other_Incent13+Other_Incent14+Other_Incent15 +" & _
               "Other_Incent16+Other_Incent17+Other_Incent18+Other_Incent19+" & _
               "Other_Incent20+Other_Incent21+Other_Incent22+Other_Incent23+" & _
               "Other_Incent24+Other_Incent25+Other_Incent26+Other_Incent27+" & _
               "Other_Incent28+Other_Incent29+Other_Incent30+Other_Incent31+" & _
               "Other_Incent32+Other_Incent33+Other_Incent34+Other_Incent35+" & _
               "Other_Incent36+Other_Incent37+Other_Incent38+Other_Incent39+" & _
               "Other_Incent40+Other_Incent41+Other_Incent42+Other_Incent43+" & _
               "Other_Incent44+Other_Incent45+Other_Incent46+Other_Incent47+" & _
               "Other_Incent48+Other_Incent49+Other_Incent50+Other_Incent51+" & _
               "Other_Incent52+Other_Incent53+Other_Incent54+Other_Incent55+" & _
               "Other_Incent56+Other_Incent57+Other_Incent58+Other_Incent59+Other_Incent60) as TotalIncome,"
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY: VIC GATCHALIAN                                                  ''
            '' DATE MODIFIED:  1/9/2012                                                     ''
            '' PURPOSE: TO RETRIEVE ONLY RECORD THAT ARE TAX DECLARED                       ''
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            ''''''''''''''''''''  ORIGINAL CODE ''''''''''''''''''''''''''''''''''''''''''''''
            'vStr = vStr & "sum(With_Tax) as WithTax, sum(Sss_Per) as SssEmp,  " & _
            '   "sum(PagIbig_Per) as PagIbigEmp,sum(Medicare_Per) as MedEmp, " & _
            '   "sum(Gsis_Per) as GsisEmp,  sum(With_Tax + Sss_Per + PagIbig_Per + " & _
            '   "Medicare_Per + Gsis_PER) as TotalDeduct  from py_report " & _
            '   "where PayDate='" & vPeriod(iCol) & _
            '   "' and Emp_Cd='" & pIndex & "'"
            '''''''''''''''''''' END ORIGINAL CODE '''''''''''''''''''''''''''''''''''''''''''
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:  VIC GATCHALIAN                                                 ''
            '' DATE MODIFIED: 10/22/2012                                                    ''
            '' PURPOSE:  TO INCLUDE UNION DUES AS PART OF THE DEDUCTION                     ''
            '' EXCEPTIONS: FOR MANILA PENINSULA USE ONLY                                    ''
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '''''''''''''''''''''' ORIGINAL CODE '''''''''''''''''''''''''''''''''''''''''''''
            'vStr = vStr & "sum(With_Tax) as WithTax, sum(Sss_Per) as SssEmp,  " & _
            '   "sum(PagIbig_Per) as PagIbigEmp,sum(Medicare_Per) as MedEmp, " & _
            '   "sum(Gsis_Per) as GsisEmp,  sum(With_Tax + Sss_Per + PagIbig_Per + " & _
            '   "Medicare_Per + Gsis_PER) as TotalDeduct  from py_report " & _
            '   "where PayDate='" & vPeriod(iCol) & _
            '   "' and TaxDeclared=1 and Emp_Cd='" & pIndex & "'"
            '''''''''''''''''''''' END ORIGINAL CODE '''''''''''''''''''''''''''''''''''''''''
            vStr = vStr & "sum(With_Tax) as WithTax, sum(Sss_Per) as SssEmp,  " & _
               "sum(PagIbig_Per) as PagIbigEmp,sum(Medicare_Per) as MedEmp, " & _
               "sum(Gsis_Per) as GsisEmp, sum(UnionDues) as UnionDues, sum(With_Tax + Sss_Per + PagIbig_Per + " & _
               "Medicare_Per + Gsis_PER + UnionDues) as TotalDeduct  from py_report " & _
               "where PayDate='" & vPeriod(iCol) & _
               "' and TaxDeclared=1 and Emp_Cd='" & pIndex & "'"
            '''''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''''''''''''''
            ''''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''''''''''''''''

            cm.CommandText = vStr
            rs = cm.ExecuteReader
            If rs.Read Then
                Dim vOtNet As Decimal = 0
                If Not IsDBNull(rs("OtTotal")) Then
                    vOtNet = rs("OtTotal")
                End If
                If Not IsDBNull(rs("OfcOt")) Then
                    vOtNet -= rs("OfcOt")
                End If
               
                'place in collection
                vItems(0) += "<td align='right'>" & Format(IIf(IsDBNull(rs("Gross")), 0, rs("Gross")), "###,##0.00") & "</td>"
                vItems(1) += "<td align='right'>" & Format(IIf(IsDBNull(rs("Transpo")), 0, rs("Transpo")), "###,##0.00") & "</td>"
                vItems(2) += "<td align='right'>" & Format(IIf(IsDBNull(rs("Allowance")), 0, rs("Allowance")), "###,##0.00") & "</td>"
                vItems(3) += "<td align='right'>" & Format(IIf(IsDBNull(rs("Absents")), 0, rs("Absents")), "###,##0.00") & "</td>"
                vItems(4) += "<td align='right'>" & Format(vOtNet, "###,##0.00") & "</td>"
                vItems(5) += "<td align='right'>" & Format(IIf(IsDBNull(rs("Gross")), 0, rs("Gross")) + _
                   IIf(IsDBNull(rs("Transpo")), 0, rs("Transpo")) + _
                   IIf(IsDBNull(rs("Allowance")), 0, rs("Allowance")) + _
                   IIf(IsDBNull(rs("Absents")), 0, rs("Absents")) + vOtNet, "###,##0.00") & "</td>"
                vTotals(0) += IIf(IsDBNull(rs("Gross")), 0, rs("Gross"))
                vTotals(1) += IIf(IsDBNull(rs("Transpo")), 0, rs("Transpo"))
                vTotals(2) += IIf(IsDBNull(rs("Allowance")), 0, rs("Allowance"))
                vTotals(3) += IIf(IsDBNull(rs("Absents")), 0, rs("Absents"))
                vTotals(4) += vOtNet
                vTotals(5) += (IIf(IsDBNull(rs("Gross")), 0, rs("Gross")) + _
                    IIf(IsDBNull(rs("Transpo")), 0, rs("Transpo")) + _
                    IIf(IsDBNull(rs("Allowance")), 0, rs("Allowance")) + _
                    IIf(IsDBNull(rs("Absents")), 0, rs("Absents")) + vOtNet)

                vItems(6) += "<td>&nbsp;</td>"  'label Other Income (Non-Tax)

                'get other income nontaxable
                iCtr = 7
                vTot = 0
                vSubIncent = 0
                'Do While Not vItems(iCtr).Contains("Meal Allowance:")
                'Do While InStr(vItems(iCtr), "Meal Allowance:") = 0
                Do While Not vItems(iCtr).Contains("Sub-Total (NonTax):")
                    vIndex = GetNumber(Trim(Mid(vRows(iCtr + 1), 1, Len(vRows(iCtr + 1)) - 1)))
                    If vIndex <> 0 Then
                        vTot = IIf(IsDBNull(rs("Incent" & vIndex)), 0, rs("Incent" & vIndex))
                    Else
                        vTot = 0
                    End If
                    vTotals(iCtr) += vTot
                    vItems(iCtr) += "<td align='right'>" & Format(vTot, "###,##0.00") & "</td>"
                    vSubIncent = vSubIncent + vTot
                    iCtr = iCtr + 1
                Loop

                'GET OTHER NON-TAX (MEAL ALLOWANCE)
                iCtr -= 1
                vTot = IIf(IsDBNull(rs("Meal")), 0, rs("Meal"))  'mealallow
                vTotals(iCtr) += vTot
                vItems(iCtr) += "<td align='right'>" & Format(vTot, "###,##0.00") & "</td>"
                vSubIncent = vSubIncent + vTot

                'GET TOTAL INC NONTAX
                iCtr = iCtr + 1
                vTotals(iCtr) += vSubIncent
                vItems(iCtr) += "<td align='right'>" & Format(vSubIncent, "###,##0.00") & "</td>"

                'GET TAXABLE INCOME BY GROUP
                'iCtr = iCtr + 2
                For iGrp = 0 To UBound(vTaxGroup)
                    vTot = 0
                    vSubIncent = 0
                    iCtr += 1
                    vItems(iCtr) += "<td>&nbsp;</td>"
                    iCtr += 1
                    Do While Not vItems(iCtr).Contains("Sub-Total (" & vTaxGroup(iGrp) & " exemption):") And _
                        Not vItems(iCtr).Contains("Seniority Allowance:")
                        'Do While InStr(vItems(iCtr), "Sub-Total (" & vTaxGroup(iGrp) & " exemption):") = 0

                        vIndex = GetNumber(Trim(Mid(vRows(iCtr + 1), 1, Len(vRows(iCtr + 1)) - 1)))
                        If vIndex <> 0 Then
                            vTot = IIf(IsDBNull(rs("Incent" & vIndex)), 0, rs("Incent" & vIndex))
                        Else
                            vTot = 0
                        End If
                        vTotals(iCtr) += vTot
                        vItems(iCtr) += "<td align='right'>" & Format(vTot, "###,##0.00") & "</td>"
                        vSubIncent = vSubIncent + vTot
                        iCtr += 1
                    Loop

                    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                    '' MODIFIED BY:  VIC GATCHALIAN                               ''
                    '' DATE MODIFIED: 12/13/2012                                  ''
                    '' PURPOSE: TO EXPOSE THE SENIORITY ALLOWANCE                 ''
                    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

                    If Val(vTaxGroup(iGrp)) = 0 Then
                        vTot = IIf(IsDBNull(rs("Senior")), 0, rs("Senior"))
                        vTotals(iCtr) += vTot
                        vItems(iCtr) += "<td align='right'>" & Format(vTot, "###,##0.00") & "</td>"
                        vSubIncent += vTot
                        iCtr += 1
                    End If
                    ''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''''

                    'sub-total (exemption)
                    vTotals(iCtr) += vSubIncent
                    vItems(iCtr) += "<td align='right'>" & Format(vSubIncent, "###,##0.00") & "</td>"

                    'iCtr = iCtr + 2
                Next iGrp

                'Total Income
                iCtr = iCtr + 1
                vTotals(iCtr) += IIf(IsDBNull(rs("TotalIncome")), 0, rs("TotalIncome"))
                vItems(iCtr) += "<td align='right'>" & Format(IIf(IsDBNull(rs("TotalIncome")), 0, rs("TotalIncome")), "###,##0.00") & "</td>"

                'GET TAX WITHHELD
                iCtr = iCtr + 1
                vTotals(iCtr) += IIf(IsDBNull(rs("WithTax")), 0, rs("WithTax"))
                vItems(iCtr) += "<td align='right'>" & Format(IIf(IsDBNull(rs("WithTax")), 0, rs("WithTax")), "###,##0.00") & "</td>"

                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY:  VIC GATCHALIAN                                           ''
                '' DATE MODIFIED: 1/9/2012                                                ''
                '' PURPOSE: TO RE-DIRECT THE RETRIEVAL OF TOTAL IF EMPLOYEE IS GROSS UP   ''
                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '''''''''''''''''''''' ORIGINAL CODE '''''''''''''''''''''''''''''''''''''''
                ''GET SSS CONT
                'iCtr = iCtr + 1
                'vTotals(iCtr) += IIf(IsDBNull(rs("SssEmp")), 0, rs("SssEmp"))
                'vItems(iCtr) += "<td align='right'>" & Format(IIf(IsDBNull(rs("SssEmp")), 0, rs("SssEmp")), "###,##0.00") & "</td>"
                ''GET PAGIBIG
                'iCtr = iCtr + 1
                'vTotals(iCtr) += IIf(IsDBNull(rs("PagIbigEmp")), 0, rs("PagIbigEmp"))
                'vItems(iCtr) += "<td align='right'>" & Format(IIf(IsDBNull(rs("PagIbigEmp")), 0, rs("PagIbigEmp")), "###,##0.00") & "</td>"
                ''GET MEDICARE
                'iCtr = iCtr + 1
                'vTotals(iCtr) += IIf(IsDBNull(rs("MedEmp")), 0, rs("MedEmp"))
                'vItems(iCtr) += "<td align='right'>" & Format(IIf(IsDBNull(rs("MedEmp")), 0, rs("MedEmp")), "###,##0.00") & "</td>"
                '''''''''''''''''''''' END ORIGINAL CODE '''''''''''''''''''''''''''''''''''
                vTmpPagIBIG = 0
                vTmpSSS = 0
                vTmpPHIC = 0
                vTmpUnionDues = 0
                If vIsNet Then
                    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                    '' MODIFIED BY:  VIC GATCHALIAN                        ''
                    '' DATE MODIFIED: 10/22/2012                           ''
                    '' PURPOSE: TO ADD UNION DUES AS PART OF DEDUCTION     ''
                    '' EXCEPTIONS: FOR MANILA PEN USE ONLY                 ''
                    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                    ''''''''''''''''' ORIGINAL CODE '''''''''''''''''''''''''
                    'cmRef.CommandText = "select sum(With_Tax) as WithTax, sum(Sss_Per) as SssEmp,  " & _
                    '   "sum(PagIbig_Per) as PagIbigEmp,sum(Medicare_Per) as MedEmp, " & _
                    '   "sum(Gsis_Per) as GsisEmp,  sum(With_Tax + Sss_Per + PagIbig_Per + " & _
                    '   "Medicare_Per + Gsis_PER) as TotalDeduct  from py_report " & _
                    '   "where PayDate='" & vPeriod(iCol) & _
                    '   "' and TaxDeclared=0 and Emp_Cd='" & pIndex & "'"
                    '''''''''''''''' END ORIGINAL CODE ''''''''''''''''''''''
                    cmRef.CommandText = "select sum(With_Tax) as WithTax, sum(Sss_Per) as SssEmp,  " & _
                       "sum(PagIbig_Per) as PagIbigEmp,sum(Medicare_Per) as MedEmp, " & _
                       "sum(Gsis_Per) as GsisEmp,  sum(UnionDues) as UnionDues, " & _
                       "sum(With_Tax + Sss_Per + PagIbig_Per + " & _
                       "Medicare_Per + Gsis_PER + UnionDues) as TotalDeduct  from py_report " & _
                       "where PayDate='" & vPeriod(iCol) & _
                       "' and TaxDeclared=0 and Emp_Cd='" & pIndex & "'"
                    '''''''''''''''' END OF MODIFICATION ''''''''''''''''''''
                    rsRef = cmRef.ExecuteReader
                    If rsRef.Read Then
                        vTmpSSS = IIf(IsDBNull(rsRef("SssEmp")), 0, rsRef("SssEmp"))
                        vTmpPagIBIG = IIf(IsDBNull(rsRef("PagIbigEmp")), 0, rsRef("PagIbigEmp"))
                        vTmpPHIC = IIf(IsDBNull(rsRef("MedEmp")), 0, rsRef("MedEmp"))
                        ''''''''''''''''''''''''''''''''''''''''''''
                        '' MODIFIED BY:  VIC GATCHALIAN           ''
                        '' DATE MODIFIED: 10/22/2012              ''
                        '' PURPOSE: TO SUPPORT DED OF UNION DUES  ''
                        ''''''''''''''''''''''''''''''''''''''''''''
                        vTmpUnionDues = IIf(IsDBNull(rsRef("UnionDues")), 0, rsRef("UnionDues"))
                        '''''''''''''' END OF MODIFICATION '''''''''
                    End If
                    rsRef.Close()
                Else
                    vTmpSSS = IIf(IsDBNull(rs("SssEmp")), 0, rs("SssEmp"))
                    vTmpPagIBIG = IIf(IsDBNull(rs("PagIbigEmp")), 0, rs("PagIbigEmp"))
                    vTmpPHIC = IIf(IsDBNull(rs("MedEmp")), 0, rs("MedEmp"))
                    ''''''''''''''''''''''''''''''''''''''''''''
                    '' MODIFIED BY:  VIC GATCHALIAN           ''
                    '' DATE MODIFIED: 10/22/2012              ''
                    '' PURPOSE: TO SUPPORT DED OF UNION DUES  ''
                    ''''''''''''''''''''''''''''''''''''''''''''
                    vTmpUnionDues = IIf(IsDBNull(rs("UnionDues")), 0, rs("UnionDues"))
                    '''''''''''''' END OF MODIFICATION '''''''''
                End If
                'GET SSS CONT
                iCtr = iCtr + 1
                vTotals(iCtr) += vTmpSSS
                vItems(iCtr) += "<td align='right'>" & Format(vTmpSSS, "###,##0.00") & "</td>"
                'GET PAGIBIG
                iCtr = iCtr + 1
                vTotals(iCtr) += vTmpPagIBIG
                vItems(iCtr) += "<td align='right'>" & Format(vTmpPagIBIG, "###,##0.00") & "</td>"
                'GET MEDICARE
                iCtr = iCtr + 1
                vTotals(iCtr) += vTmpPHIC
                vItems(iCtr) += "<td align='right'>" & Format(vTmpPHIC, "###,##0.00") & "</td>"
                ''''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''''''''''''

                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY:  VIC GATCHALIAN                         ''
                '' DATE MODIFIED: 10/22/2012                            ''
                '' PURPOSE: TO ADD UNION DUES DEDUCTION                 ''
                '' EXCEPTION: FOR MANILA PEN USE ONLY                   ''
                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                iCtr += 1
                vTotals(iCtr) += vTmpUnionDues
                vItems(iCtr) += "<td align='right'>" & Format(vTmpUnionDues, "###,##0.00") & "</td>"
                '''''''''''''' END OF MODIFICATION '''''''''''''''''''''''
                'GET TOTAL DED
                iCtr = iCtr + 1
                vTotals(iCtr) += IIf(IsDBNull(rs("TotalDeduct")), 0, rs("TotalDeduct"))
                vItems(iCtr) += "<td align='right'>" & Format(IIf(IsDBNull(rs("TotalDeduct")), 0, rs("TotalDeduct")), "###,##0.00") & "</td>"
            End If
            rs.Close()
        Next iCol

        'DUMP TO TABLE
        For iCtr = 0 To UBound(vItems)
            '''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:  VIC GATCHALIAN               '
            '' DATE MODIFIED: 11/22/2011                  '
            '' PURPOSE: TO EXPOSE THE TAX WITHHELD COLUMN '
            ''          WHETHER THE VALUE IS ZERO OR NOT  '
            '''''''''''''''''''''''''''''''''''''''''''''''
            ''''''''' ORIGINAL CODE '''''''''''''''''''''''
            'If vTotals(iCtr) <> 0 Then
            '''''''''' END ORIGINAL CODE ''''''''''''''''''

            If vTotals(iCtr) <> 0 Or (vTotals(iCtr) = 0 And vItems(iCtr).Contains("Tax Withheld:")) Then
                '''''''''' END OF MODIFICATION ''''''''''''''''
                vLedger += vItems(iCtr) & "<td align='right'>" & Format(vTotals(iCtr), "#,###,##0.00") & "</td></tr>"
            End If
        Next iCtr
        vLedger = vLedger.Replace("</table>", "")
        vLedger += "</table>"


        '''''''''''''''''' RECAPITULATION ''''''''''''''''''''''''''''''''

        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                                              ''
        '' DATE MODIFIED: 1/12/2013                                                  ''
        '' PURPOSE: TO POPULATE THE STRING FOR 2316 PRINTING                         ''
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        Dim vAgencyCd As String = ""
        Dim vEmpLName As String = ""
        Dim vEmpFName As String = ""
        Dim vEmpMName As String = ""
        Dim vEmpTIN As String = ""
        Dim vEmpAddr As String = ""
        Dim vEmpZip As String = ""
        Dim vEmpTel As String = ""
        Dim vBDay As String = ""
        Dim vCivilCd As String = "S"
        Dim vDependentName() As String = {"", "", "", ""}
        Dim vDependentBDay() As String = {"", "", "", ""}
        Dim iCount As Integer = 0

        Dim vEmrTIN As String = ""
        Dim vEmrName As String = ""
        Dim vEmrAddr As String = ""
        Dim vEmrZIP As String = ""
        Dim vAuthorizedPerson As String = ""

        Dim vPrevEmrTIN As String = ""
        Dim vPrevEmrName As String = ""
        Dim vPrevEmrAddr As String = ""
        Dim vPrevEmrZip As String = ""

        Dim v13NonTaxInc As Decimal = 0
        Dim v13TaxInc As Decimal = 0
        Dim vTotContr As Decimal = 0
        Dim vOthTaxInc As Decimal = 0


        v2316Dump = cmbYear.SelectedValue & "~12/31~"    'for the year and period


        cm.CommandText = "select * from py_emp_master where Emp_Cd='" & pIndex & "'"
        rs = cm.ExecuteReader
        If rs.Read Then
            vEmpLName = rs("Emp_Lname")
            vEmpFName = rs("Emp_Fname")
            vEmpMName = rs("Emp_Mname")
            vEmpTIN = IIf(IsDBNull(rs("Tin")), "", rs("Tin"))
            vEmpAddr = IIf(IsDBNull(rs("Emp_Address")), "", rs("Emp_Address"))
            vEmpTel = IIf(IsDBNull(rs("Emp_Tel")), "", rs("Emp_Tel"))
            vEmpZip = IIf(IsDBNull(rs("Zip")), "", rs("Zip"))
            vCivilCd = IIf(rs("Civil_Cd") <> "M", "S", "M")
            vAgencyCd = rs("Agency_Cd")
            If Not IsDBNull(rs("Bday")) Then
                If IsDate(rs("Bday")) Then
                    vBDay = Format(CDate(rs("Bday")), "MM/dd/yyyy")
                End If
            End If
        End If
        rs.Close()
        cm.CommandText = "select TOP 4 * from hr_dependents where Emp_Cd='" & pIndex & "' order by Bday desc"
        rs = cm.ExecuteReader
        Do While rs.Read
            If Not IsDBNull(rs("Bday")) Then
                If IsDate(rs("Bday")) Then
                    If DateDiff(DateInterval.Month, Now, rs("BDay")) / 12 < 21 Then
                        vDependentName(iCount) = rs("DependentName")
                        vDependentBDay(iCount) = Format(CDate(rs("Bday")), "MM/dd/yyyy")
                        iCount += 1
                    End If
                End If
            End If
        Loop
        rs.Close()

        cm.CommandText = "select * from glsyscntrl where AgencyCd='" & vAgencyCd & "'"
        rs = cm.ExecuteReader
        If rs.Read Then
            vEmrName = IIf(IsDBNull(rs("Company_Name")), "", rs("Company_Name"))
            vEmrAddr = IIf(IsDBNull(rs("Address")), "", rs("Address").ToString.Replace(vbCrLf, " "))
            vEmrTIN = IIf(IsDBNull(rs("Tin")), "", rs("Tin"))
            vEmrZIP = IIf(IsDBNull(rs("Zip")), "", rs("Zip"))
            vAuthorizedPerson = IIf(IsDBNull(rs("Attention")), "", rs("Attention"))
        End If
        rs.Close()

        v2316Dump += vEmpTIN & "~" & vEmpLName & "~" & vEmpFName & "~" & vEmpMName & "~" & vEmpAddr.Replace(vbCrLf, " ") & "~" & vEmpZip & _
            "~" & vBDay & "~" & vEmpTel & "~" & vCivilCd & "~"
        v2316Dump += vDependentName(0) & "^" & vDependentBDay(0) & "|" & _
            vDependentName(1) & "^" & vDependentBDay(1) & "|" & _
            vDependentName(2) & "^" & vDependentBDay(2) & "|" & _
            vDependentName(3) & "^" & vDependentBDay(3) & "~"
        v2316Dump += vEmrTIN & "~" & vEmrName & "~" & vEmrAddr & "~" & vEmrZIP & "~" & _
            vPrevEmrTIN & "~" & vPrevEmrName & "~" & vPrevEmrAddr & "~" & vPrevEmrZip & "~"
        ''''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''''''''''''


        vsumm += "<tr><td align='right'>" & Format(vTotals(5), "#,###,##0.00") & "</td>"

        vTotTaxable = vTotals(5)        'Total Basic
        vDump += vTotTaxable & ","

        iRow = 0

        v13NonTaxInc = 0
        v13TaxInc = 0
        vOthTaxInc = 0
        For iCol = 0 To UBound(vTaxGroup)
            vEmpty = True
            For iCtr = 0 To UBound(vItems)
                If vItems(iCtr).IndexOf("Sub-Total (" & vTaxGroup(iCol) & " exemption):") >= 0 Then
                    vEmpty = False
                    vTot = Math.Round(vTotals(iCtr) - Val(vTaxGroup(iCol)), 2)
                    If vTot < 0 And Val(vTaxGroup(iCol)) <> 0 Then vTot = 0

                    If Val(vTaxGroup(iCol)) > 0 Then
                        If vTotals(iCtr) > Val(vTaxGroup(iCol)) Then
                            v13NonTaxInc = Val(vTaxGroup(iCol))
                        Else
                            v13NonTaxInc = vTotals(iCtr)
                        End If
                        v13TaxInc += vTot
                    End If

                    vOthTaxInc += vTot
                    vTotTaxable = vTotTaxable + vTot

                    vsumm += "<td>" & Format(vTot, "##,##0.00") & "</td>"
                    vDump += vTot & ","
                ElseIf vItems(iCtr).IndexOf("Tax Withheld:") >= 0 Then
                    iRow = iCtr
                End If
            Next iCtr
            If vEmpty Then vsumm += "<td>0.00</td>" : vDump += "0,"
        Next iCol

        'GET PREVIOUS EMPLOYER'S GROSS AND TAX
        cm.CommandText = "select * from py_prev_employer_income where Emp_Cd='" & _
           pIndex & "' and YearCd=" & cmbYear.SelectedValue
        rs = cm.ExecuteReader
        vPrevGross = 0
        vPrevTax = 0
        vPrev13Tax = 0
        vPrevContr = 0
        If rs.Read Then
            vPrevGross = Math.Round(rs("GrossTaxable"), 2)
            vPrevTax = Math.Round(rs("TaxWithheld"), 2)
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:  VIC GATCHALIAN                                     ''
            '' DATE MODIFIED: 1/3/2013                                          ''
            '' PURPOSE: TO GET THE TAXABLE 13TH MONTH AND CONTRIBUTIONS FROM    ''
            ''          PREVIOUS EMPLOYER.                                      ''
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            vPrev13Tax = Math.Round(rs("Tax13th"), 2)
            vPrevContr = Math.Round(rs("NonTaxSss"), 2)
            '''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''''''
        End If
        rs.Close()


        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                              ''
        '' DATE MODIFIED:  10/22/2012                                ''
        '' PURPOSE: TO REPLACE HEALTH PREMIUMS WITH UNION DUES       ''
        '' EXCEPTIONS: FOR MANILA PEN USE ONLY                       ''
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '''''''''''''''' OLD CODE '''''''''''''''''''''''''''''''''''''
        'get health premiums
        'get health premiums exemptions
        'cm.CommandText = "select sum(Amount) as Amt from py_other_premiums where Emp_Id='" & _
        '    pIndex & "'"
        'rs = cm.ExecuteReader
        'vPremium = 0
        'If rs.Read Then
        '    vPremium = IIf(IsDBNull(rs("Amt")), 0, rs("Amt"))
        'End If
        'rs.Close()
        '''''''''''''''''' END OLD CODE ''''''''''''''''''''''''''''''
        vPremium = vTotals(iRow + 4)
        '''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''

        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                             ''
        '' DATE MODIFIED: 1/3/2013                                  ''
        '' PURPOSE: TO ADD THE TAXABLE 13TH MONTH AND CONTRIBUTION  ''
        ''          FROM PREVIOUS EMPLOYER.                         ''
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '''''''''''''''''''' OLD CODE ''''''''''''''''''''''''''''''''
        'vTotTaxable += vPrevGross - pExemption - vPremium
        '''''''''''''''''''' END OLD CODE ''''''''''''''''''''''''''''
        vTotTaxable += vPrevGross + vPrev13Tax - pExemption - vPremium - vPrevContr
        '''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''

        'get total sss+pagibig+philhealth
        vTotContr = vPremium 'union dues
        If iRow + 3 < UBound(vTotals) Then
            vTotTaxable -= (vTotals(iRow + 1) + vTotals(iRow + 2) + vTotals(iRow + 3))
            vAddStr = Format(vTotals(iRow + 1) + vTotals(iRow + 2) + vTotals(iRow + 3), "#,###,##0.00")
            vTotContr = vTotals(iRow + 1) + vTotals(iRow + 2) + vTotals(iRow + 3)
        Else
            vAddStr = "0.00"
        End If



        'get gross from prev employer
        vTotTaxWithheld = vTotals(iRow) + vPrevTax

        'get tax due
        vTaxDue = Math.Round(AccrueTax(vTotTaxable, iRow, CDate(vPeriod(UBound(vPeriod))), pIndex, pMonthRate, c), 2)

        If cmbYear.SelectedValue < Now.Year Then
            vAccrueContr = 0
        End If

        v2316Dump += vPrevGross & "~" & pExemption & "~" & vTotTaxable & "~" & vTaxDue & "~" & vTotals(iRow) & "~" & vPrevTax & "~" & _
            vTotTaxWithheld & "~" & v13NonTaxInc & "~" & vTotContr & "~"
        v2316Dump += "0~" '#40 Salaries and other forms of compensation

        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                                                      ''
        '' DATE MODIFIED: 1/18/2013                                                          ''
        '' PURPOSE: TO COMBINE OTHER ZERO EXEMPT INCOME TO BASIC GROSS                       ''
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        ''''''''''''''''''''''''' OLD CODE  '''''''''''''''''''''''''''''''''''''''''''''''''''
        'v2316Dump += vTotals(5) & "~" & vOthTaxInc & "~" & vAuthorizedPerson
        ''''''''''''''''''''''''' END OLD CODE ''''''''''''''''''''''''''''''''''''''''''''''''
        v2316Dump += vTotals(5) + vOthTaxInc - v13TaxInc & "~" & v13TaxInc & "~" & vAuthorizedPerson
        ' Response.Write(v2316Dump)
        ''''''''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''''''''''''''''

        vTotTaxable += vAccrueGross - vAccrueContr  '''''questionable''''

        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                                                      ''
        '' DATE MODIFIED: 1/3/2013                                                           ''
        '' PURPOSE: TO EXPOSE THE TAXABLE 13TH MONTH AND CONTRIBUTION FROM PREV EMPLOYER     ''
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '''''''''''''''''''''''''' OLD CODE    ''''''''''''''''''''''''''''''''''''''''''''''''
        'vStrDump = "<td align='right'>" & Format(vAccrueGross, "#,###,##0.00") & "</td>" & _
        '   "<td align='right'>" & Format(vAccrueContr, "#,###,##0.00") & "</td>" & _
        '   "<td align='right'>" & Format(vPrevGross, "#,###,##0.00") & "</td>" & _
        '   "<td align='right'>" & Format(pExemption, "###,##0.00") & "</td>" & _
        '   "<td align='right'>" & vAddStr & "</td>" & _
        '   "<td align='right'>" & Format(vPremium, "#,###,##0.00") & "</td>" & _
        '   "<td align='right'>" & Format(vTotTaxable, "#,###,##0.00") & "</td>" & _
        '   "<td align='right'>" & Format(vTotals(iRow), "#,###,##0.00") & "</td>" & _
        '   "<td align='right'>" & Format(vPrevTax, "#,###,##0.00") & "</td>" & _
        '   "<td align='right'>" & Format(vTotTaxWithheld, "#,###,##0.00") & "</td>" & _
        '   "<td align='right'>" & Format(vTaxDue, "#,###,##0.00") & "</td>" & _
        '   "<td align='right'>" & Format(vTaxDue - vTotTaxWithheld, "#,###,##0.00") & "</td>"

        'vDump += vAccrueGross & "," & vAccrueContr & "," & vPrevGross & "," & pExemption & "," & _
        '    Val(vAddStr) & "," & vPremium & "," & vTotTaxable & "," & vTotals(iRow) & "," & _
        '    vPrevTax & "," & vTotTaxWithheld & "," & vTaxDue & "," & vTaxDue - vTotTaxWithheld & vbCrLf
        '''''''''''''''''''''''''' END OLD CODE '''''''''''''''''''''''''''''''''''''''''''''''
        vStrDump = "<td align='right'>" & Format(vAccrueGross, "#,###,##0.00") & "</td>" & _
           "<td align='right'>" & Format(vAccrueContr, "#,###,##0.00") & "</td>" & _
           "<td align='right'>" & Format(vPrevGross + vPrev13Tax, "#,###,##0.00") & "</td>" & _
           "<td align='right'>" & Format(pExemption, "###,##0.00") & "</td>" & _
           "<td align='right'>" & vAddStr & "</td>" & _
           "<td align='right'>" & Format(vPrevContr, "###,##0.00") & "</td>" & _
           "<td align='right'>" & Format(vPremium, "#,###,##0.00") & "</td>" & _
           "<td align='right'>" & Format(vTotTaxable, "#,###,##0.00") & "</td>" & _
           "<td align='right'>" & Format(vTotals(iRow), "#,###,##0.00") & "</td>" & _
           "<td align='right'>" & Format(vPrevTax, "#,###,##0.00") & "</td>" & _
           "<td align='right'>" & Format(vTotTaxWithheld, "#,###,##0.00") & "</td>" & _
           "<td align='right'>" & Format(vTaxDue, "#,###,##0.00") & "</td>" & _
           "<td align='right'>" & Format(vTaxDue - vTotTaxWithheld, "#,###,##0.00") & "</td>"

        vDump += vAccrueGross & "," & vAccrueContr & "," & vPrevGross + vPrev13Tax & "," & pExemption & "," & _
            Val(vAddStr) & "," & vPrevContr & "," & vPremium & "," & vTotTaxable & "," & vTotals(iRow) & "," & _
            vPrevTax & "," & vTotTaxWithheld & "," & vTaxDue & "," & vTaxDue - vTotTaxWithheld & vbCrLf
        '''''''''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''''''''''''''''

        vsumm += vStrDump & "</tr>"
        Session("2316dump") = v2316Dump

        If pFileName <> "" Then IO.File.AppendAllText(pFileName, vDump)

        rsSysCntrl.Close()
        c.Close()
        'cSysCntrl.Close()
        c.Dispose()
        'cSysCntrl.Dispose()
        cm.Dispose()
        cmRef.Dispose()
    End Sub

    Private Function AccrueTax(ByVal pTaxableAmt As Double, ByVal pRow As Integer, _
        ByVal pDate As Date, ByVal pIndex As String, ByVal pMonthRate As Decimal, ByRef c As SqlClient.SqlConnection) As Double

        Dim vTaxableAmt As Double
        'Dim c As New SqlClient.SqlConnection(connStr)
        'Dim cRef As New SqlClient.SqlConnection(connStr)

        Dim cm As New SqlClient.SqlCommand
        Dim cmRef As New SqlClient.SqlCommand

        Dim rs As SqlClient.SqlDataReader
        Dim rsRef As SqlClient.SqlDataReader

        Dim vMultiplier As Single
        Dim vAccrueAmt As Double
        Dim vFixedSSS As Double
        Dim vFixedPagIBIG As Double
        Dim vFixedMedicare As Double
        Dim vRATA As Double
        Dim vACA As Double
        Dim vPERA As Double
        Dim vAllowSSS As Boolean
        Dim vAllowPagibig As Boolean
        Dim vAllowMedicare As Boolean
        Dim vRateMonth As Double
        Dim vTemp2 As Double
        Dim vTemp As Double
        Dim vSSS As Double
        Dim vPagIBIG As Double
        Dim vMedicare As Double
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY: VIC GATCHALIAN                            ''
        '' DATE MODIFIED: 12/21/2012                              ''
        '' PURPOSE: TO INCLUDE THE UNION DUES AS PART OF THE      ''
        ''          ACCRUALS.                                     ''
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        Dim vUnionDues As Double
        ''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''

        Dim vLastBalance As Double
        Dim vLastTranspo As Double
        Dim vLastACA As Double
        Dim vLastPERA As Double
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                           ''
        '' DATE MODIFIED: 2/23/2012                               ''
        '' PURPOSE: ADDED A VARIABLE TO DETERMINE IF THE SELECTED ''
        ''          EMPLOYEE IS ALREADY RESIGNED OR STILL ACTIVE. ''
        ''          DEFAULT VARIABLE IS SET TO ACTIVE.            ''
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        Dim vIsResigned As Boolean = False
        '''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''
        
        cm.Connection = c
        cmRef.Connection = c

        AccrueTax = 0
        'get last balance of basic last period payroll generated
        cm.CommandText = "select sum(BasicRate),0 as Transpo,sum(Aca),sum(Pera) from py_report where Emp_Cd='" & _
           pIndex & "' and month(PayDate)=" & Month(vLastPayDate) & _
           " and year(PayDate)=" & Year(vLastPayDate)
        rs = cm.ExecuteReader

        vLastBalance = 0
        vLastTranspo = 0
        vLastACA = 0
        vLastPERA = 0
        If rs.Read Then
            If Not IsDBNull(rs(0)) Then vLastBalance = rs(0)
            If Not IsDBNull(rs(1)) Then vLastTranspo = rs(1)
            If Not IsDBNull(rs(2)) Then vLastACA = rs(2)
            If Not IsDBNull(rs(3)) Then vLastPERA = rs(3)
        End If
        rs.Close()

        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                              ''
        '' DATE MODIFIED: 2/23/2012                                  ''
        '' PURPOSE: TO ADD THE DATE_RESIGN FIELD TO GET THE STATUS   ''
        ''          OF THE SELECTED EMPLOYEE                         ''
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '''''''''''''''''''' OLD CODE '''''''''''''''''''''''''''''''''
        'cm.CommandText = "select Aca,Rata,Pera,FixedSss_Emp,FixedPagIbig_Emp,FixedHealth_Emp,Allow_Sss,Allow_PagIbig," & _
        '"Allow_Medicare from py_emp_master where Emp_Cd='" & pIndex & "'"
        '''''''''''''''''''' END OLD CODE '''''''''''''''''''''''''''''
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY: VIC GATCHALIAN                               ''
        '' DATE MODIFIED: 12/27/2012                                 ''
        '' PURPOSE: TO ADD UNION DUES FIELD RETRIEVAL FOR UNION DUES ''
        ''          CALCULATION.                                     ''
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        ''''''''''''''''' OLD CODE ''''''''''''''''''''''''''''''''''''
        'cm.CommandText = "select Aca,Rata,Pera,FixedSss_Emp,FixedPagIbig_Emp,FixedHealth_Emp,Allow_Sss,Allow_PagIbig," & _
        '   "Allow_Medicare,Date_Resign from py_emp_master where Emp_Cd='" & pIndex & "'"
        ''''''''''''''''' END OLD CODE ''''''''''''''''''''''''''''''''
        cm.CommandText = "select Aca,Rata,Pera,FixedSss_Emp,FixedPagIbig_Emp,FixedHealth_Emp,Allow_Sss,Allow_PagIbig," & _
           "Allow_Medicare,Date_Resign,Allow_UnionDues,UnionValue,UnionCd,Rate_Month from py_emp_master where Emp_Cd='" & pIndex & "'"
        ''''''''''''''''' END OF MODIFICAITON '''''''''''''''''''''''''
        '''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''
        vFixedSSS = 0
        vFixedPagIBIG = 0
        vFixedMedicare = 0
        vACA = 0
        vRATA = 0
        vPERA = 0
        vAllowSSS = False
        vAllowPagibig = False
        vAllowMedicare = False
        rs = cm.ExecuteReader
        If rs.Read Then
            vFixedSSS = rs("FixedSss_Emp")
            vFixedPagIBIG = rs("FixedPagIbig_Emp")
            vFixedMedicare = rs("FixedHealth_Emp")
            vAllowSSS = rs("Allow_Sss")
            vAllowPagibig = rs("Allow_PagIbig")
            vAllowMedicare = rs("Allow_Medicare")
            vRATA = IIf(IsDBNull(rs("Rata")), 0, rs("Rata"))
            vPERA = IIf(IsDBNull(rs("Pera")), 0, rs("Pera"))
            vACA = IIf(IsDBNull(rs("Aca")), 0, rs("Aca"))
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:  VIC GATCHALIAN                                   ''
            '' DATE MODIFIED: 2/23/2012                                       ''
            '' PURPOSE: TO GET THE STATUS OF THE EMPLOYEE IF ACTIVE OR NOT.   ''
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            vIsResigned = Not IsDBNull(rs("Date_Resign"))
            '''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''

            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:  VIC GATCHALIAN                                   ''
            '' DATE MODIFIED: 12/27/2012                                      ''
            '' PURPOSE: TO GET UNION DUES VALUES                              ''
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            If rs("Allow_UnionDues") = 1 Or rs("UnionValue") <> 0 Then   'employee is  a member of union
                'get info from union ref
                cmRef.CommandText = "select * from py_union_ref where UnionCd='" & rs("UnionCd") & "'"
                rsRef = cmRef.ExecuteReader
                If rsRef.Read Then
                    If rsRef("Mode") = 0 Then   'percentage mode
                        vUnionDues = (rsRef("Value") / 100) * rs("Rate_Month")
                    Else                        'amount mode
                        vUnionDues = rsRef("Value")
                    End If
                    If rsRef("FreqCd") = 0 Then     'if every payroll or specific date=current cut off date
                        vUnionDues = vUnionDues * 2 'assumes semi-monthly
                    Else
                    End If
                End If
                rsRef.Close()
            End If
            ''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''''
        End If
        rs.Close()

        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                                        ''
        '' DATE MODIFIED: 10/23/2012                                           ''
        '' PURPOSE: TO DETERMINE THE PROPER LAST PAYDATE OF THE SELECTED EMP.  ''
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        Dim vTotalMonthly As Decimal = 0

        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                                        ''
        '' DATE MODIFIED: 1/20/2013                                            ''
        '' PURPOSE: TO ADD THE SELECTED YEAR AS PART OF THE QUERY.             ''
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '''''''''''''''''''''' OLD CODE '''''''''''''''''''''''''''''''''''''''''
        'cm.CommandText = "select top 1 PayDate from py_report where Emp_Cd='" & _
        '    pIndex & "' and NormalPayroll=1 order by PayDate desc"
        '''''''''''''''''''''' END OLD CODE '''''''''''''''''''''''''''''''''''''
        cm.CommandText = "select top 1 PayDate from py_report where Emp_Cd='" & _
            pIndex & "' and NormalPayroll=1 and year(PayDate)=" & cmbYear.SelectedValue & " order by PayDate desc"
        '''''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''''''

        
        rs = cm.ExecuteReader
        If rs.Read Then
            vLastPayDate = rs("PayDate")
        End If
        rs.Close()

        'now get the sum of basicrate
        cm.CommandText = "select sum(BasicRate) from py_report where Emp_Cd='" & _
            pIndex & "' and NormalPayroll=1 and Month(PayDate)=" & vLastPayDate.Month & _
            " and Year(PayDate)=" & vLastPayDate.Year
        rs = cm.ExecuteReader
        If rs.Read Then
            If Not IsDBNull(rs(0)) Then
                vTotalMonthly = rs(0)
            End If
        End If
        rs.Close()
        If vTotalMonthly < pMonthRate Then
            vMultiplier = 0.5   'add 1/2 accrued month for monthly rate
        End If
        ''''''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''''

        vMultiplier += (12 - Month(vLastPayDate))

        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY: VIC GATCHALIAN                                         ''
        '' DATE MODIFIED: 1/20/2013                                            ''
        '' PURPOSE: TO ENSURE THAT THE ACCRUALS ARE EFFECTED ONLY IN THE       ''
        ''          CURRENT YEAR.                                              ''
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        If cmbYear.SelectedValue < Now.Year Then vMultiplier = 0
        ''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''''''''

        vRateMonth = pMonthRate
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY: VIC GATCHALIAN                                          ''
        '' DATE MODIFIED: 2/23/2012                                             ''
        '' PURPOSE: TO ENHANCE CHECKING IF THE EMPLOYEE IS ACTIVE OR NOT.       ''
        ''          IF THE EMPLOYEE IS ACTIVE, GET THE ACCRUED SALARY. OTHERWISE,'
        ''          SET THE ACCRUED AMOUNT TO ZERO.                             ''
        ''''''''''''''''''''''' OLD CODE '''''''''''''''''''''''''''''''''''''''''
        'vAccrueAmt = vRateMonth * vMultiplier
        ''''''''''''''''''''''' END OLD CODE '''''''''''''''''''''''''''''''''''''
        If vIsResigned Or cmbYear.SelectedValue < Now.Year Then
            vAccrueAmt = 0
        Else    'employee is active, get the accrued salary
            vAccrueAmt = vRateMonth * vMultiplier
        End If
        ''''''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''''''

        ''CHECK OPTION ACCRUALS OF OTHER INCENTIVES
        ''check rata first
        'If lstIncent.ListItems(1).Checked Then 'accrue rata
        '    vAccrueAmt = vAccrueAmt + ((vRATA * 2 * (vMultiplier + 1)) - vLastTranspo)
        'End If

        ''check ACA first
        'If lstIncent.ListItems(1).Checked Then
        '    vAccrueAmt = vAccrueAmt + ((vACA * 2 * (vMultiplier + 1)) - vLastACA)
        'End If

        ''check PERA first
        'If lstIncent.ListItems(1).Checked Then
        '    vAccrueAmt = vAccrueAmt + ((vPERA * 2 * (vMultiplier + 1)) - vLastPERA)
        'End If

        ''CHECK FOR OTHER INCENTIVES
        'For iCtr = 2 To lstIncent.ListItems.Count
        '    If lstIncent.ListItems(iCtr).Checked Then
        '        'rs.Open "SELECT SUM(INCENTIVE_AMT) FROM PY_INCENTIVES_DTL WHERE INCENTIVE_CD='" & _
        '    lstIncent.ListItems(iCtr) & "' AND EMP_CD='" & lstEmp.SelectedItem & _
        '    "' AND YEAR([TO])=" & Year(vLastPayDate), CN, adOpenStatic, adLockReadOnly
        '        rs.Open("SELECT SUM(INCENTIVE_AMT) FROM PY_INCENTIVES_DTL WHERE INCENTIVE_CD='" & _
        '           lstIncent.ListItems(iCtr) & "' AND EMP_CD='" & lstEmp.SelectedItem & _
        '           "' AND YEAR([TO])=" & Year(vLastPayDate) & " AND [TO] > " & _
        '           DTQUOTE & vLastPayDate & DTQUOTE, CN, adOpenStatic, adLockReadOnly)
        '        If Not IsNull(rs(0)) Then
        '            If Val(lstIncent.ListItems(iCtr).ListSubItems(3)) > 0 Then
        '                vTemp2 = rs(0) - Val(lstIncent.ListItems(iCtr).ListSubItems(3))
        '                If vTemp2 < 0 Then vTemp2 = 0
        '            Else
        '                vTemp2 = rs(0)
        '            End If
        '            vAccrueAmt = vAccrueAmt + vTemp2
        '        End If
        '        rs.Close()
        '    End If
        'Next iCtr

        'accrue basic for the month
        'If vLastPayDate <> MonthEND(vLastPayDate) Then     'check whether lastpaydate is not end of the month
        'If vLastBalance < vRateMonth Then
        '    vAccrueAmt = vAccrueAmt + (vRateMonth - vLastBalance)
        'End If
        'vAccrueAmt = vAccrueAmt + (vRateMonth / 2)
        'End If


        vAccrueGross = vAccrueAmt

        vTaxableAmt = pTaxableAmt + vAccrueAmt

        vAccrueContr = 0
        cmRef.CommandText = "select sum(Sss_Per) as SssEmp,  " & _
            "sum(PagIbig_Per) as PagIbigEmp,sum(Medicare_Per) as MedEmp " & _
            " from py_report where month(PayDate)=" & pDate.Month & _
            " and year(PayDate)=" & cmbYear.SelectedValue & " and Emp_Cd='" & _
            pIndex & "'"

        rsRef = cmRef.ExecuteReader
        rsRef.Read()

        vSSS = 0
        vPagIBIG = 0
        vMedicare = 0

        ''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                     ''
        '' DATE MODIFIED: 10/23/2012                        ''
        '' PURPOSE: TO GET THE REMAINING MONTHS BASED ON THE''
        ''          PARAMETER DATE                          ''
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''
        vMultiplier = 12 - pDate.Month
        ''''''''''''''' END OF MODIFICATION ''''''''''''''''''

        'SSS SHARE
        vTemp = 0
        'If vAllowSSS And vLastPayDate <> MonthEND(vLastPayDate) Then
        If vFixedSSS = 0 Then
            cm.CommandText = "select * from py_sss_table where " & vRateMonth & _
               " between Min_Amt and Max_Amt"
            rs = cm.ExecuteReader
            If rs.Read Then
                vSSS = rs("Emp_Ss")
            End If
            rs.Close() 'PY_SSS_TABLE
        Else
            If vFixedSSS > 0 And vFixedSSS < 1 Then   'USE PERCENTAGE
                vSSS = vRateMonth * vFixedSSS
            Else  'USE SPECIFIC AMOUNT
                vSSS = vFixedSSS
            End If
        End If
        'End If

        If IsDBNull(rsRef("SssEmp")) Then
            vSSS = vSSS * (vMultiplier + 1)
        ElseIf rsRef("SssEmp") = 0 Then
            vSSS = vSSS * (vMultiplier + 1)
        Else
            vTemp = vSSS - rsRef("SssEmp")
            vSSS = (vSSS * vMultiplier) + IIf(vTemp < 0, 0, vTemp)
        End If

        'PAGIBIG SHARE FOR GOVT AND PERSONAL
        vTemp = 0
        'If vAllowPagibig And vLastPayDate <> MonthEND(vLastPayDate) Then
        If vFixedPagIBIG = 0 Then
            cm.CommandText = "select * from py_deduct"
            rs = cm.ExecuteReader
            rs.Read()
            vTemp = IIf(IsDBNull(rs("Pag_Per_Per")), 0, rs("Pag_Per_Per")) * vRateMonth
            vTemp2 = IIf(IsDBNull(rs("Pag_Per_Up")), 0, rs("Pag_Per_Up"))
            vPagIBIG = (IIf(vTemp > vTemp2, vTemp2, vTemp))
            rs.Close() 'PY_DEDUCT
        Else
            If vFixedPagIBIG > 0 And vFixedPagIBIG < 1 Then   'USE PERCENTAGE
                vPagIBIG = vRateMonth * vFixedPagIBIG
            Else  'USE SPECIFIC AMOUNT
                vPagIBIG = vFixedPagIBIG
            End If
        End If
        'End If

        If IsDBNull(rsRef("PagIbigEmp")) Then
            vPagIBIG = vPagIBIG * (vMultiplier + 1)
        ElseIf rsRef("PagIbigEmp") = 0 Then
            vPagIBIG = vPagIBIG * (vMultiplier + 1)
        Else
            vTemp = vPagIBIG - rsRef("PagIbigEmp")
            vPagIBIG = (vPagIBIG * vMultiplier) + IIf(vTemp < 0, 0, vTemp)
        End If

        'MEDICARE SHARE FOR GOVT AND PERSONAL
        'If vAllowMedicare And vLastPayDate <> MonthEND(vLastPayDate) Then
        If vFixedMedicare = 0 Then
            cm.CommandText = "select * from py_philhealth_table where " & vRateMonth & _
               " between FromAmt and ToAmt"
            rs = cm.ExecuteReader
            If rs.Read Then
                vMedicare = rs("Per_Share")
            End If
            rs.Close() 'PY_PHILHEALTH_TABLE
        Else
            If vFixedMedicare > 0 And vFixedMedicare < 1 Then   'USE PERCENTAGE
                vMedicare = vRateMonth * vFixedMedicare
            Else  'USE SPECIFIC AMOUNT
                vMedicare = vFixedMedicare
            End If
        End If
        'End If

        If IsDBNull(rsRef("MedEmp")) Then
            vMedicare = vMedicare * (vMultiplier + 1)
        ElseIf rsRef("MedEmp") = 0 Then
            vMedicare = vMedicare * (vMultiplier + 1)
        Else
            vTemp = vMedicare - rsRef("MedEmp")
            vMedicare = (vMedicare * vMultiplier) + IIf(vTemp < 0, 0, vTemp)
        End If

        rsRef.Close()

        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                                          ''
        '' DATE MODIFIED: 12/27/2012                                             ''
        '' PURPOSE: TO ACCRUE THE COMPUTED UNION DUES                            ''
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        vUnionDues = vUnionDues * (vMultiplier)
        ''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''''''''''''

        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                                          ''
        '' DATE MODIFIED: 2/23/2012                                              ''
        '' PURPOSE: TO DOUBLE CHECK IF THE EMPLOYEE IS ACTIVE OR NOT. IF ACTIVE, ''
        ''          THE SYSTEM WILL GET THE ACCRUED CONTRIBUTION. OTHERWISE, IT  ''
        ''          WILL BE SET TO ZERO.                                         ''
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '''''''''''''''''''''''' OLD CODE '''''''''''''''''''''''''''''''''''''''''
        'vAccrueContr = vSSS + vPagIBIG + vMedicare
        '''''''''''''''''''''''' END OLD CODE '''''''''''''''''''''''''''''''''''''
        If vIsResigned Or cmbYear.SelectedValue < Now.Year Then
            vAccrueContr = 0
        Else    'employee is active, get accrued contribution
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:  VIC GATCHALIAN                                     ''
            '' DATE MODIFIED: 12/27/2012                                        ''
            '' PURPOSE:  TO INCLUDE THE UNION DUES AS PART OF THE ACCRUED CONTR ''
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '''''''''''''''''''''' OLD CODE ''''''''''''''''''''''''''''''''''''''
            'vAccrueContr = vSSS + vPagIBIG + vMedicare
            '''''''''''''''''''''' END OLD CODE ''''''''''''''''''''''''''''''''''
            vAccrueContr = vSSS + vPagIBIG + vMedicare + vUnionDues
            '''''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''
        End If
        'Response.Write(vAccrueContr)
        '''''''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''''''

        vTaxableAmt = vTaxableAmt - vAccrueContr
        cm.CommandText = "select * from py_tax_table where Freq_Cd='ANNUAL' and Tax_Cd='ANNUAL' and " & _
           vTaxableAmt & " >= Check_Amt order by Check_Amt desc"
        rs = cm.ExecuteReader
        AccrueTax = 0
        If rs.Read Then
            AccrueTax = rs("Add_Amt") + (rs("Factor") * (vTaxableAmt - rs("Check_Amt")))
        End If
        rs.Close()
        'c.Close()
        'cRef.Close()
        'c.Dispose()
        'cRef.Dispose()
    End Function

    Protected Sub cmdDump_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDump.Click
        Dim vFilename = Server.MapPath(".") & "/downloads/summary-" & Session.SessionID & ".csv"
        Dim vDump As New StringBuilder
        Dim vString As String = ""
        Dim vExempt As Decimal = 0
        Dim vEmrTIN As String = "000-000-000-000"
        Dim vCompName As String = ""
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim vDateResigned As String = ""


        If IO.File.Exists(vFilename) Then
            Try
                IO.File.Delete(vFilename)
            Catch ex As IO.IOException
                vScript = "alert('Cannot delete temp file. Error is: " & ex.Message.Replace(vbCrLf, "\n ").Replace("'", "") & "');"
                Exit Sub
            End Try
        End If

        vDump.AppendLine(Session("header"))
        c.Open()

        cm.Connection = c
        cm.CommandText = "select Tin from glsyscntrl where AgencyCd='" & cmbOfc.SelectedValue & "'"
        rs = cm.ExecuteReader
        If rs.Read Then
            vEmrTIN = rs("Tin")
            'vCompName = rs("Company_Name")
        End If
        rs.Close()


        If txtPrint.Value = "1" Then    'print the currently selected employee
            If tblEmp.SelectedIndex > -1 Then
                cm.CommandText = "select Emp_Cd,Emp_Lname,Emp_Fname,Emp_Mname,Agency_Cd, " & _
                    "(select Tin from glsyscntrl where glsyscntrl.AgencyCd=py_emp_master.Agency_Cd) as EmrTIN, " & _
                    "(select Company_Name from glsyscntrl where glsyscntrl.AgencyCd=py_emp_master.Agency_Cd) as CompName, " & _
                    "(select Attention from glsyscntrl where glsyscntrl.AgencyCd=py_emp_master.Agency_Cd) as Attention, " & _
                    "(select Address from glsyscntrl where glsyscntrl.AgencyCd=py_emp_master.Agency_Cd) as vAddress, " & _
                    "Tax_Cd,Rate_Month,Tin,Start_Date,Date_Resign, " & _
                    "Emp_Address from py_emp_master " & _
                    "where Emp_Cd='" & tblEmp.SelectedRow.Cells(0).Text & "'"
                rs = cm.ExecuteReader
                If rs.Read Then
                    If Not IsDBNull(rs("EmrTIN")) Then
                        vEmrTIN = rs("EmrTIN")
                    End If

                    vString = vEmrTIN & "," & tblEmp.SelectedRow.Cells(0).Text & ",""" & _
                        tblEmp.SelectedRow.Cells(1).Text.Replace(",", " ") & ", " & tblEmp.SelectedRow.Cells(2).Text.Replace(",", " ") & """," & _
                        tblEmp.SelectedRow.Cells(3).Text & "," & _
                        tblEmp.SelectedRow.Cells(5).Text & "," & _
                        rs("Tin") & "," & _
                        IIf(IsDBNull(rs("Start_Date")), "", rs("Start_Date")) & "," & _
                        IIf(IsDBNull(rs("Date_Resign")), "", rs("Date_Resign")) & ",""" & _
                        rs("Emp_Address").ToString.Replace(",", " ").Replace(vbCrLf, " ") & """," & _
                        DumpLedger2File(tblEmp.SelectedRow.Cells(0).Text, tblEmp.SelectedRow.Cells(4).Text, _
                            Val(tblEmp.SelectedRow.Cells(5).Text), _
                            rs("CompName").ToString.Replace(",", " ").Replace(vbCrLf, " "), _
                            rs("Attention").ToString.Replace(",", " ").Replace(vbCrLf, " "), _
                            rs("vAddress").ToString.Replace(",", " ").Replace(vbCrLf, " "), c).ToString
                    vDump.AppendLine(vString)
                    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                    '' MODIFIED BY: VIC GATCHALIAN                           ''
                    '' DATE MODIFIED: 1/9/2013                               ''
                    '' PURPOSE: TO DISABLE THE GENERATION OF 1604 RECORDS    ''
                    ''          DURING SINGLE EMPLOYEE DOWNLOAD.             ''
                    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                    Insert1604(vString, 1, rs, c)
                    ''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''
                End If

                IO.File.WriteAllText(vFilename, vDump.ToString)
            Else
                vScript = "alert('Please Select employee')"
            End If
        Else    'print all filered employees
            Dim cmExempt As New SqlClient.SqlCommand
            Dim rsExempt As SqlClient.SqlDataReader
            Dim i As Integer = 1

            cmExempt.Connection = c
            cm.CommandText = "select Emp_Cd, Emp_Lname, Emp_Fname, Emp_Mname, Tax_Cd,Rate_Month,Tin,Start_Date,Date_Resign, " & _
                "(select Tin from glsyscntrl where glsyscntrl.AgencyCd=py_emp_master.Agency_Cd) as EmrTIN, " & _
                "(select Company_Name from glsyscntrl where glsyscntrl.AgencyCd=py_emp_master.Agency_Cd) as CompName, " & _
                "(select Attention from glsyscntrl where glsyscntrl.AgencyCd=py_emp_master.Agency_Cd) as Attention, " & _
                "(select Address from glsyscntrl where glsyscntrl.AgencyCd=py_emp_master.Agency_Cd) as vAddress, " & _
                "Emp_Address, Agency_Cd from py_emp_master " & _
                "where Emp_Cd is not null " & Session("filter") & " order by Emp_Lname,Emp_Fname"
            rs = cm.ExecuteReader
            Do While rs.Read
                cmExempt.CommandText = "select Exemption from py_tax_ref where Tax_Cd='" & rs("Tax_Cd") & "'"
                rsExempt = cmExempt.ExecuteReader
                If rsExempt.Read Then
                    vExempt = rsExempt("Exemption")
                End If
                rsExempt.Close()
                If Not IsDBNull(rs("EmrTIN")) Then
                    vEmrTIN = rs("EmrTIN")
                End If

                vString = vEmrTIN & "," & rs("Emp_Cd") & ",""" & rs("Emp_Lname").ToString.Replace(",", " ") & ", " & rs("Emp_Fname").ToString.Replace(",", " ") & """," & _
                    rs("Tax_Cd") & "," & rs("Rate_Month") & "," & rs("Tin") & "," & _
                    IIf(IsDBNull(rs("Start_Date")), "", rs("Start_Date")) & "," & _
                    IIf(IsDBNull(rs("Date_Resign")), "", rs("Date_Resign")) & ",""" & _
                    rs("Emp_Address").ToString.Replace(",", " ").Replace(vbCrLf, " ") & """," & _
                    DumpLedger2File(rs("Emp_Cd"), vExempt, rs("Rate_Month"), _
                    rs("CompName").ToString.Replace(",", " ").Replace(vbCrLf, " "), _
                    rs("Attention").ToString.Replace(",", " ").Replace(vbCrLf, " "), _
                    rs("vAddress").ToString.Replace(",", " ").Replace(vbCrLf, " "), c).ToString

                vDump.AppendLine(vString)

                Insert1604(vString, i, rs, c)
                i += 1
            Loop
            rs.Close()

            cmExempt.Dispose()
            IO.File.WriteAllText(vFilename, vDump.ToString)

            If tblEmp.SelectedIndex > -1 Then
                GetLedger(tblEmp.SelectedRow.Cells(0).Text, False, False, tblEmp.SelectedRow.Cells(4).Text, _
                    Val(tblEmp.SelectedRow.Cells(5).Text))
            Else
                vScript = "alert('Please Select employee')"
            End If

        End If
        c.Close()
        c.Dispose()
        cm.Dispose()
        vScript = "document.getElementById(""divWait"").style.visibility = ""hidden""; alert('Dump complete.');"
        lnkDownload.NavigateUrl = "~/downloads/summary-" & Session.SessionID & ".csv"
    End Sub
    Private Sub Insert1604(ByVal vString As String, ByVal i As Integer, ByRef rs As SqlClient.SqlDataReader, ByRef c As SqlClient.SqlConnection)
        Dim vData() As String

        vData = vString.Split(",")
        If UBound(vData) < 29 Then
            Exit Sub
        End If

        Dim cm_a As New SqlClient.SqlCommand("", c)
        Dim vSchedNum As String = ""
        Dim vDateResigned As String = "null"

        Dim vSalariesNonTax As Decimal = 0
        Dim vNonTax_13th As Decimal = 0
        Dim vTax_13th As Decimal = 0
        Dim vBasicSalary As Decimal = 0
        Dim vTTCI As Decimal = 0

        If Not IsDBNull(rs("Date_Resign")) Then     'D7.1 = Employee is Resigned
            vSchedNum = "D7.1"
        Else
            If Val(vData(24)) = 0 Then              'No tax due
                vSchedNum = "D7.2"
            Else
                If Val(vData(15)) <> 0 Then          'With previous employer
                    vSchedNum = "D7.4"
                Else
                    vSchedNum = "D7.3"              'Without previous employer
                End If
            End If
        End If

        If lblCompTin.Text = "" Then
            lblCompTin.Text = vData(0)
        End If

        'cm_a.CommandText = "delete from [1604f] where emp_cd = '" & rs("Emp_Cd") & "' and Sched_Num = '" & vSchedNum & "' and " & _
        '    "year(returnpd) = '" & cmbYear.SelectedValue & "' "
        cm_a.CommandText = "delete from [1604f] where emp_cd = '" & rs("Emp_Cd") & _
            "' and year(returnpd) = " & cmbYear.SelectedValue
        cm_a.ExecuteNonQuery()

        If vData(8) = "" Then
            vDateResigned = "null"
        Else
            vDateResigned = "'" & Format(CDate(vData(8)), "yyyy/MM/dd") & "'"
        End If

        'Response.Write("insert into 1604F (Emp_Cd, FType_CD, BranchCd_Emr, ReturnPd, Sched_Num, " & _
        '"SeqID, Fname, Lname, Mname, Tin_Emp, " & _
        '"BranchCd_Emp, DateHired, DateResigned, Actual_Withheld, Salaries_Tax, Prev_Taxable_Salaries, " & _
        '"OtherIncent_Tax, Taxwithheld, Salaries_Nontax, OtherIncent_NonTax, Prev_Taxable_13th_Month, Prev_Tax_Withheld, " & _
        '"Prev_NonTax_Salaries, Prev_NonTax_13th_Month, Mandatory, Prev_NonTax_SSS, Variance," & _
        '"Taxwithheld_Dec, Exemption, Taxdue, Premiums, AgencyCd, Region_Num, Subs_Filing, Tax_Cd, Factor_Used, " & _
        '"Income_Payment, Tax_Rate, Fringe_Benefit, NonTax_13th, Tax_13th) " & _
        '"values " & _
        '"('" & vData(1) & "', '1604f', '" & txtBranCd.Text & "', '" & cmbYear.SelectedValue & "-12-31" & "', '" & vSchedNum & "', " & _
        '"" & i & ", '" & rs("Emp_Fname") & "', '" & rs("Emp_Lname") & "', '" & rs("Emp_Mname") & "', '" & vData(6) & "', " & _
        '"'" & txtBranCd.Text & "', '" & Format(CDate(vData(7)), "yyyy/MM/dd") & "', " & vDateResigned & ", " & vData(22) & ", " & (Val(vData(10)) - Val(vData(17)) - Val(vData(18)) - Val(vData(16))) & "test.john" & ", " & _
        '"" & "<-- " & vData(12) & "lance -->" & ", " & vData(22) & ", 0, " & vData(25) & ", " & vData(15) & ", 0, " & vData(21) & ", " & _
        '"0, 0, " & vData(17) & ", 0, " & vData(24) & ", " & _
        '"0, " & vData(16) & ", " & vData(23) & ", " & vData(18) & ", '" & rs("Agency_Cd") & "-" & vData(1) & "', '','N', '" & vData(4) & "', 0," & _
        '"0, 0, 0, 0, 0) ")

        'For i = 0 To UBound(vData)
        '    Response.Write("Value of vData(" & i & ") = " & vData(i) & "<br/>")
        'Next

        Select Case vData(12)
            Case 0
                vNonTax_13th = 0
                vTax_13th = 0
            Case Is < 0
                vNonTax_13th = 30000 + vData(11)
                vTax_13th = 0
            Case Is > 0
                vNonTax_13th = 30000
                vTax_13th = vData(11)
        End Select

        'vSalariesNonTax = (Val(vData(10)) + Val((vData(11)) + Val(30000)) + Val(vData(12)) + Val(vData(25)))
        vSalariesNonTax = Val(vData(26))

        vBasicSalary = Val(vData(10))
        vTTCI = (Val(vData(10)) + Val(vData(11)) + Val(vData(12)) - Val(vData(17)))

        Dim vStartDate As String = "null"

        If IsDate(vData(7)) Then
            vStartDate = "'" & Format(CDate(vData(7)), "yyyy/MM/dd") & "'"
        End If
        Try
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:  VIC GATCHALIAN                                                                  ''
            '' DATE MODIFIED: 1/23/2013                                                                      ''
            '' PURPOSE: TO ADJUST THE SAVING OF 1604CF                                                       ''
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '''''''''''''''''''''''''''''''' OLD CODE '''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            'cm_a.CommandText = "insert into [1604F] (Tin_Emr, Emp_Cd, FType_CD, BranchCd_Emr, ReturnPd, Sched_Num, " & _
            '"SeqID, Fname, Lname, Mname, Tin_Emp, " & _
            '"BranchCd_Emp, DateHired, DateResigned, Actual_Withheld, Salaries_Tax, " & _
            '"OtherIncent_Tax, Taxwithheld, Salaries_Nontax, OtherIncent_NonTax, Prev_Taxable_Salaries, Prev_Taxable_13th_Month, Prev_Tax_Withheld, " & _
            '"Prev_NonTax_Salaries, Prev_NonTax_13th_Month, Mandatory, Prev_NonTax_SSS, Variance," & _
            '"Taxwithheld_Dec, Exemption, Taxdue, Premiums, AgencyCd, Region_Num, Subs_Filing, Tax_Cd, Factor_Used, " & _
            '"Income_Payment, Tax_Rate, Fringe_Benefit, NonTax_13th, Tax_13th, Total_Taxable_Comp_Income, Tax_Basic_Sal) " & _
            '"values " & _
            '"('" & vData(0) & "', '" & vData(1) & "', '1604CF', '" & txtBranCd.Text & "', '" & cmbYear.SelectedValue & "-12-31" & "', '" & vSchedNum & "', " & _
            '"" & i & ", '" & rs("Emp_Fname") & "', '" & rs("Emp_Lname") & "', '" & rs("Emp_Mname") & "', '" & vData(6) & "', " & _
            '"'" & txtBranCd.Text & "', '" & vStartDate & "', " & vDateResigned & ", " & vData(21) & ", " & vData(10) & ", " & _
            '"" & vData(11) & ", " & vData(22) & ", " & vSalariesNonTax & ", " & vData(25) & ", " & vData(15) & ", 0, " & vData(21) & ", " & _
            '"0, 0, " & vData(17) & ", 0, " & vData(24) & ", " & _
            '"" & vData(26) & ", " & vData(16) & ", " & vData(23) & ", " & vData(18) & ", '" & rs("Agency_Cd") & "', '', 'N', '" & vData(4) & "', 0," & _
            '"0, 0, 0, " & vNonTax_13th & ", " & vTax_13th & ", " & vTTCI & ", " & vData(10) & ") "
            ''''''''''''''''''''''''''''' END OLD CODE '''''''''''''''''''''''''''''''''''''''''''''''''''''''
            cm_a.CommandText = "insert into [1604f] (Tin_Emr,Emp_Cd,FType_Cd,BranchCd_Emr,ReturnPd,Sched_Num," & _
                "SeqId,Fname,LName,Mname,Tin_Emp,BranchCd_Emp,DateHired,DateResigned,AgencyCd,Tax_Cd," & _
                "Exemption,Gross_Comp_Income,Mandatory,Net_Taxable_Comp_Income,NonTax_13th,OtherIncent_NonTax," & _
                "Premiums,Pres_NonTax_De_Minimis,Prev_NonTax_13th_Month,Prev_NonTax_De_Minimis," & _
                "Prev_NonTax_Salaries,Prev_NonTax_SSS,Prev_Pres_Total_Taxable,Prev_Tax_Withheld," & _
                "Prev_Taxable_13th_Month,Prev_Taxable_Basic_Salary,Prev_Taxable_Salaries," & _
                "Prev_Total_NonTax_Comp_Income,Prev_Total_Taxable,Salaries_Tax,Tax_13th," & _
                "Tax_Basic_Sal,TaxDue,TaxWithheld,TaxWithheld_Dec,Total_NonTax_Comp_Income," & _
                "Total_Taxable_Comp_Income,Variance) "
            cm_a.CommandText += " values ('" & vData(0) & "','" & vData(1) & "','1604CF','" & txtBranCd.Text & "','" & _
                cmbYear.SelectedValue & "-12-31','" & vSchedNum & "'," & i & ",'" & rs("Emp_Fname") & "','" & rs("Emp_Lname") & _
                "','" & rs("Emp_Mname") & "','" & vData(6) & "','" & txtBranCd.Text & "'," & vStartDate & "," & vDateResigned & _
                ",'" & rs("Agency_Cd") & "','" & rs("Tax_Cd") & "'," & _
                vData(16) & "," & Val(vData(10)) + Val(vData(11)) + Val(vData(12)) & "," & Val(vData(17)) + Val(vData(19)) & _
                "," & vData(20) & "," & vData(34) & ",0,0,0," & vData(32) & ",0,0," & vData(18) & "," & vData(20) & "," & _
                vData(22) & "," & vData(31) & "," & Val(vData(15)) - Val(vData(31)) & ",0," & vData(32) & "," & _
                vData(15) & ",0," & vData(12) & "," & Val(vData(10)) + Val(vData(11)) & "," & vData(24) & "," & _
                vData(23) & "," & vData(27) & "," & vData(26) & "," & vData(20) & "," & vData(25) & ")"
            ''''''''''''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''''''''''''''''''''''''

            cm_a.ExecuteNonQuery()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to save data.');"

        Finally
            cm_a.Dispose()
        End Try
        


    End Sub
    Private Function DumpLedger2File(ByVal pIndex As String, ByVal pExemption As Decimal, _
        ByVal pMonthRate As Decimal, ByVal pCompanyName As String, ByVal pAttention As String, _
        ByVal pAddress As String, ByRef c As SqlClient.SqlConnection) As StringBuilder

        Dim vDump As New StringBuilder
        Dim cm As New SqlClient.SqlCommand
        Dim cmRef As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim rsRef As SqlClient.SqlDataReader

        Dim vStr As String
        Dim iCol As Integer
        Dim iRow As Integer
        Dim iCtr As Integer
        Dim vPremium As Double
        Dim vPrevGross As Double
        Dim vPrevTax As Double
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                                ''
        '' DATE MODIFIED: 1/8/2013                                     ''
        '' PURPOSE: TO ADD THE EMPLOYEE'S CONTRIBUTION FROM PREVIOUS   ''
        ''          EMPLOYER.                                          ''
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        Dim vPrevContr As Double
        '''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''

        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                                ''
        '' DATE MODIFIED: 1/24/2013                                    ''
        '' PURPOSE: TO ADD VARIABLE TO GET THE 13TH MONTH NON-TAXABLE  ''
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        Dim v13thNT As Decimal = 0
        Dim vPrev13th As Decimal = 0
        Dim vPrev13thNT As Decimal = 0
        Dim vPrevGrossNT As Decimal = 0
        '''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''''

        Dim vGross As Decimal
        Dim vTotTaxable As Double
        Dim vTaxDue As Double
        Dim vTotalNT As Decimal = 0
        Dim vTaxDec As Decimal = 0
        Dim vNTList() As String
        Dim vPeriod() As String = Session("periods").ToString.Split(",")

        cm.Connection = c
        'cmSysCntrl.Connection = c
        cmRef.Connection = c

        'cmSysCntrl.CommandText = "select * from py_syscntrl"
        'rsSysCntrl = cmSysCntrl.ExecuteReader
        'rsSysCntrl.Read()

        vStr = "select sum(With_Tax) from py_report where year(PayDate)=" & cmbYear.SelectedValue & _
            " and Emp_Cd='" & pIndex & "' and month(PayDate)=12"

        cm.CommandText = vStr
        rs = cm.ExecuteReader
        If rs.Read Then
            If Not IsDBNull(rs(0)) Then
                vTaxDec = rs(0)
            End If
        End If
        rs.Close()

        vStr = "select sum(Month_Rate) as Gross, sum(Absent+Tardiness) as Absents," & _
           "sum(G1+G2+G3+G4) as OfcOt,sum(SeniorAllowance) as Senior,sum(UnionDues) as UnionDues," & _
           "sum(Ot) as OtTotal, sum(Aca+Pera) as Allowance, 0 as Meal, 0 as Transpo," & _
           "sum(Month_Rate+Absent+Tardiness+Ot+Aca+MealAllow+Rata+Pera+SeniorAllowance+Other_Incent1+" & _
           "Other_Incent2+Other_Incent3+Other_Incent4+Other_Incent5+Other_Incent6+" & _
           "Other_Incent7+Other_Incent8+Other_Incent9+Other_Incent10+Other_Incent11+" & _
           "Other_Incent12+Other_Incent13+Other_Incent14+Other_Incent15+" & _
           "Other_Incent16+Other_Incent17+Other_Incent18+Other_Incent19+" & _
           "Other_Incent20+Other_Incent21+Other_Incent22+Other_Incent23+" & _
           "Other_Incent24+Other_Incent25+Other_Incent26+Other_Incent27+" & _
           "Other_Incent28+Other_Incent29+Other_Incent30+Other_Incent31+" & _
           "Other_Incent32+Other_Incent33+Other_Incent34+Other_Incent35+" & _
           "Other_Incent36+Other_Incent37+Other_Incent38+Other_Incent39+" & _
           "Other_Incent40+Other_Incent41+Other_Incent42+Other_Incent43+" & _
           "Other_Incent44+Other_Incent45+Other_Incent46+Other_Incent47+" & _
           "Other_Incent48+Other_Incent49+Other_Incent50+Other_Incent51+" & _
           "Other_Incent52+Other_Incent53+Other_Incent54+Other_Incent55+" & _
           "Other_Incent56+Other_Incent57+Other_Incent58+Other_Incent59+" & _
           "Other_Incent60) as TotalIncome,"
        For iCtr = 0 To UBound(vTaxGroup)
            vStr += vStatement(iCtr) & ","
        Next

        vStr = vStr & "sum(With_Tax) as WithTax, sum(Sss_Per) as SssEmp,  " & _
           "sum(PagIbig_Per) as PagIbigEmp,sum(Medicare_Per) as MedEmp, " & _
           "sum(Gsis_Per) as GsisEmp,  sum(With_Tax + Sss_Per + PagIbig_Per + " & _
           "Medicare_Per + Gsis_PER + UnionDues) as TotalDeduct  "
        'nontaxable statement
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                                       ''
        '' DATE MODIFIED:  1/16/2012                                          ''
        '' PURPOSE:  TO DUMP TAX DECLARED RECORDS ONLY                        ''
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        ''''''''''''''''''' ORIGINAL CODE ''''''''''''''''''''''''''''''''''''''
        'vStr += vSQLNonTax & " from py_report " & _
        '   "where year(PayDate)=" & cmbYear.SelectedValue & " and Emp_Cd='" & pIndex & "'"
        '''''''''''''''''''''' END ORIGINAL CODE '''''''''''''''''''''''''''''''

        vStr += vSQLNonTax & " from py_report " & _
           "where year(PayDate)=" & cmbYear.SelectedValue & _
           " and TaxDeclared=1 and Emp_Cd='" & pIndex & "'"
        '''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''''''

        cm.CommandText = vStr
        Try
            rs = cm.ExecuteReader
        Catch ex As System.Exception
            Response.Write(vStr)
            Return vDump
            Exit Function
        End Try

        vGross = 0
        rs.Read()
        If Not IsDBNull(rs("Gross")) Then   'with records
            'vNTList = Session("nontax").ToString.Split(",")
            vTotalNT = 0
            If Not IsDBNull(rs("NonTax")) Then
                vTotalNT = rs("NonTax")
            End If

            'For i As Integer = 0 To UBound(vNTList)
            '    If Not IsDBNull(rs("NonTax" & i)) Then
            '        vTotalNT += rs("NonTax" & i)
            '    End If
            'Next

            vGross = rs("Gross") + (rs("OtTotal") - rs("OfcOt")) + rs("Allowance") + rs("Absents")
            ''''''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''

            'GET PREVIOUS EMPLOYER'S GROSS AND TAX
            cmRef.CommandText = "select * from py_prev_employer_income where Emp_Cd='" & _
               pIndex & "' and YearCd=" & cmbYear.SelectedValue
            rsRef = cmRef.ExecuteReader
            vPrevGross = 0
            vPrevTax = 0
            If rsRef.Read Then
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY:  VIC GATCHALIAN                                ''
                '' DATE MODIFIED: 1/8/2012                                     ''
                '' PURPOSE: TO ADD THE 13TH MONTH TAXABLE AND THE CONTRIBUTION ''
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                ''''''''''''''''''' OLD CODE ''''''''''''''''''''''''''''''''''''
                'vPrevGross = Math.Round(rsRef("GrossTaxable"), 2)
                ''''''''''''''''''' END OLD CODE ''''''''''''''''''''''''''''''''
                vPrevGross = Math.Round(rsRef("GrossTaxable") + rsRef("Tax13th"), 2)
                vPrev13th = rsRef("Tax13th")
                vPrev13thNT = rsRef("NonTax13th")
                vPrevGrossNT = rsRef("GrossNonTax")
                vPrevContr = Math.Round(rsRef("NonTaxSss"), 2)
                ''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''

                vPrevTax = Math.Round(rsRef("TaxWithheld"), 2)
            End If
            rsRef.Close()

            'get health premiums exemptions
            cmRef.CommandText = "select sum(Amount) as Amt from py_other_premiums where Emp_Id='" & _
                pIndex & "'"
            rsRef = cmRef.ExecuteReader
            vPremium = 0
            rsRef.Read()
            If Not IsDBNull(rsRef("Amt")) Then
                vPremium = rsRef("Amt")
            End If
            rsRef.Close()

            vTotTaxable = vGross + vPrevGross

            For iCol = 0 To UBound(vTaxGroup) 'add the other taxable incentives
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY:  VIC GATCHALIAN                                        ''
                '' DATE MODIFIED: 1/24/2013                                            ''
                '' PURPOSE: TO GET THE 13TH MONTH NON-TAXABLE                          ''
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '''''''''''''''''''''' OLD CODE '''''''''''''''''''''''''''''''''''''''''
                'vTotTaxable += IIf(rs("TotIncent" & iCol) < 0 And Val(vTaxGroup(iCol)) > 0, 0, rs("TotIncent" & iCol))
                '''''''''''''''''''''' END OLD CODE '''''''''''''''''''''''''''''''''''''
                If rs("TotIncent" & iCol) < 0 And Val(vTaxGroup(iCol)) > 0 Then
                    v13thNT = rs("TotIncent" & iCol) + Val(vTaxGroup(iCol))
                Else
                    If rs("TotIncent" & iCol) > 0 And Val(vTaxGroup(iCol)) > 0 Then
                        v13thNT = Val(vTaxGroup(iCol))
                    End If
                    vTotTaxable += rs("TotIncent" & iCol)
                End If
                '''''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''''''
            Next iCol

            vAccrueContr = 0
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:  VIC GATCHALIAN                                           ''
            '' DATE MODIFIED: 1/8/2013                                                ''
            '' PURPOSE: TO INCLUDE THE THE EMPLOYEE'S CONTRIBUTION FROM PREVIOUS      ''
            ''          EMPLOYER and UNION DUES.                                      ''
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            ''''''''''''''''''''' OLD CODE '''''''''''''''''''''''''''''''''''''''''''''
            'vTotTaxable -= (pExemption + rs("SssEmp") + rs("PagibigEmp") + _
            '    rs("MedEmp") + rs("GsisEmp") + vPremium)
            ''''''''''''''''''''' END OLD CODE '''''''''''''''''''''''''''''''''''''''''
            vTotTaxable -= (pExemption + rs("SssEmp") + rs("PagibigEmp") + _
                rs("MedEmp") + rs("GsisEmp") + vPremium + vPrevContr + rs("UnionDues"))
            ''''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''''''''''

            'get tax due
            vTaxDue = Math.Round(AccrueTax(vTotTaxable, iRow, CDate(vPeriod(UBound(vPeriod))), pIndex, pMonthRate, c), 2)

            If cmbYear.SelectedValue < Now.Year Then
                vAccrueContr = 0
            End If
            vTotTaxable += vAccrueGross
            vTotTaxable -= vAccrueContr

            vStr = Math.Round(vGross, 2) & ","
            For iCol = 0 To UBound(vTaxGroup)
                'vStr += IIf(rs("TotIncent" & iCol) < 0 And Val(vTaxGroup(iCol)) > 0, 0, Math.Round(rs("TotIncent" & iCol), 2)) & ","
                vStr += Math.Round(rs("TotIncent" & iCol), 2) & ","
            Next
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:  VIC GATCHALIAN                                          ''
            '' DATE MODIFIED: 1/8/2013                                               ''
            '' PURPOSE: TO INCLUDE THE EMPLOYEE'S CONTRIBUTION FROM PREVIOUS         ''
            ''          EMPLOYER.                                                    ''
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '''''''''''''''''' OLD CODE '''''''''''''''''''''''''''''''''''''''''''''''
            'vDump.Append(vStr & Math.Round(vAccrueGross, 2) & "," & Math.Round(vAccrueContr, 2) & "," & _
            '    vPrevGross & "," & Math.Round(pExemption, 2) & "," & _
            '    Math.Round(rs("TotalDeduct") - rs("WithTax"), 2) & "," & Math.Round(vPremium, 2) & "," & _
            '    Math.Round(vTotTaxable, 2) & "," & Math.Round(rs("WithTax"), 2) & "," & _
            '    vPrevTax & "," & vPrevTax + Math.Round(rs("WithTax"), 2) & "," & _
            '    vTaxDue & "," & Math.Round(vTaxDue - (vPrevTax + rs("WithTax")), 2) & "," & Math.Round(vTotalNT, 2) & _
            '    "," & vTaxDec & "," & pCompanyName & "," & pAttention & "," & pAddress)
            ''''''''''''''''''''' END OLD CODE ''''''''''''''''''''''''''''''''''''''''
            vDump.Append(vStr & Math.Round(vAccrueGross, 2) & "," & Math.Round(vAccrueContr, 2) & "," & _
                vPrevGross & "," & Math.Round(pExemption, 2) & "," & _
                Math.Round(rs("SssEmp") + rs("PagibigEmp") + rs("MedEmp") + rs("GsisEmp"), 2) & "," & _
                Math.Round(vPrevContr, 2) & "," & _
                Math.Round(rs("UnionDues"), 2) & "," & _
                Math.Round(vTotTaxable, 2) & "," & _
                Math.Round(rs("WithTax"), 2) & "," & _
                vPrevTax & "," & vPrevTax + Math.Round(rs("WithTax"), 2) & "," & _
                vTaxDue & "," & Math.Round(vTaxDue - (vPrevTax + rs("WithTax")), 2) & "," & Math.Round(vTotalNT, 2) & _
                "," & vTaxDec & "," & pCompanyName & "," & pAttention & "," & pAddress & "," & _
                vPrev13th & "," & vPrev13thNT & "," & vPrevGrossNT & "," & v13thNT)
            ''''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''''''''
        End If
        rs.Close()
        rsSysCntrl.Close()
        cm.Dispose()
        cmRef.Dispose()
        Return vDump
    End Function


    Protected Sub vPrint1604f_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles vPrint1604f.Click

        If txtBranCd.Text = "" Then
            vScript = "selectOption('Print')"
        Else
            vScript = "print1604F(" & cmbYear.SelectedItem.Value & ", '" & rdoSchedule.SelectedItem.Value & "', '" & _
            cmbOfc.SelectedItem.Value & "', '" & cmbOfc.SelectedItem.Text & "', '" & txtBranCd.Text & "' );"
            
        End If
    End Sub
    Private Sub Generate7_1()

    End Sub
    Private Sub Generate7_3()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim vData As New StringBuilder
        Dim vTINEMR As String = "000000000"
        Dim iCtr As Integer = 1
        Dim vTotals(18) As Decimal
        Dim vFilename As String

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        cm.Connection = c

        Try

            cm.CommandText = "select Tin from glsyscntrl where AgencyCd='" & cmbOfc.SelectedValue & "'"

            rs = cm.ExecuteReader
            If rs.Read Then
                If Not IsDBNull(rs("Tin")) Then
                    If rs("Tin").ToString.Trim = "" Then
                        GoTo notin
                    End If
                    vTINEMR = Mid(rs("Tin").ToString.Replace("-", ""), 1, 9)
                Else
notin:
                    vScript = "alert('No Employer TIN defined.');"
                    rs.Close()
                    c.Close()
                    c.Dispose()
                    cm.Dispose()
                    Exit Sub
                End If

            End If
            rs.Close()

            For iCtr = 0 To 17
                vTotals(iCtr) = 0
            Next
            iCtr = 0

            vData.AppendLine("H1604CF," & vTINEMR & ",0000,12/31/" & cmbYear.SelectedValue)

            cm.CommandText = "select * from [1604f] where Sched_Num='" & rdoSchedule.SelectedValue & _
                "' and year(ReturnPd)=" & cmbYear.SelectedValue

            rs = cm.ExecuteReader
            Do While rs.Read
                iCtr += 1
                vData.AppendLine("D7.3,1604CF," & vTINEMR & ",0000," & Format(CDate(rs("ReturnPd")), "MM/dd/yyyy") & "," & _
                    Format(iCtr, "000000") & "," & Mid(rs("Tin_Emp").ToString.Replace("-", ""), 1, 9) & ",0000," & _
                    Mid(rs("Lname"), 1, 30) & "," & Mid(rs("Fname"), 1, 30) & "," & Mid(rs("Mname"), 1, 30) & "," & rs("Gross_Comp_Income") & "," & _
                    rs("NonTax_13th") & "," & rs("Pres_NonTax_De_Minimis") & "," & rs("Mandatory") & "," & _
                    rs("OtherIncent_NonTax") & "," & _
                    rs("NonTax_13th") + rs("Pres_NonTax_De_Minimis") + rs("Mandatory") + rs("OtherIncent_NonTax") & "," & _
                    rs("Tax_Basic_Sal") & "," & rs("Tax_13th") & "," & rs("Salaries_Tax") & "," & _
                    rs("Tax_Basic_Sal") + rs("Tax_13th") + rs("Salaries_Tax") & "," & _
                    rs("Tax_Cd") & "," & rs("Exemption") & "," & rs("Premiums") & "," & rs("Net_Taxable_Comp_Income") & _
                    "," & rs("TaxDue") & "," & rs("TaxWithHeld") - rs("TaxWithHeld_Dec") & "," & _
                    rs("TaxWithHeld_Dec") & "," & rs("Variance") & "," & rs("TaxWithHeld") & ",Y")
                vTotals(0) += rs("Gross_Comp_Income")
                vTotals(1) += rs("NonTax_13th")
                vTotals(2) += rs("Pres_NonTax_De_Minimis")
                vTotals(3) += rs("Mandatory")
                vTotals(4) += rs("OtherIncent_NonTax")
                vTotals(5) += rs("NonTax_13th") + rs("Pres_NonTax_De_Minimis") + rs("Mandatory") + rs("OtherIncent_NonTax")
                vTotals(6) += rs("Tax_Basic_Sal")
                vTotals(7) += rs("Tax_13th")
                vTotals(8) += rs("Salaries_Tax")
                vTotals(9) += rs("Tax_Basic_Sal") + rs("Tax_13th") + rs("Salaries_Tax")
                vTotals(10) += rs("ExemptioN")
                vTotals(11) += rs("Premiums")
                vTotals(12) += rs("Net_Taxable_Comp_Income")
                vTotals(13) += rs("TaxDue")
                vTotals(14) += rs("TaxWithHeld") - rs("TaxWithHeld_Dec")
                vTotals(15) += rs("TaxWithHeld_Dec")
                vTotals(16) += rs("Variance")
                vTotals(17) += rs("TaxWithHeld")
            Loop
            rs.Close()
            vData.AppendLine("C7.3,1604CF," & vTINEMR & ",0000,12/31/" & cmbYear.SelectedValue & "," & _
                vTotals(0) & "," & vTotals(1) & "," & vTotals(2) & "," & vTotals(3) & "," & vTotals(4) & "," & _
                vTotals(5) & "," & vTotals(6) & "," & vTotals(7) & "," & vTotals(8) & "," & vTotals(9) & "," & _
                vTotals(10) & "," & vTotals(11) & "," & vTotals(12) & "," & vTotals(13) & "," & vTotals(14) & "," & _
                vTotals(15) & "," & vTotals(16) & "," & vTotals(17))

            vFilename = vTINEMR & "1231" & cmbYear.SelectedValue & "7.3.csv"

            If IO.File.Exists(Server.MapPath(".") & "\downloads\" & vFilename) Then
                Try
                    IO.File.Delete(Server.MapPath(".") & "\downloads\" & vFilename)
                Catch ex As Exception
                    vScript = "alert('Error deleting temporary file. Error is: " & _
                        ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                    c.Close()
                    c.Dispose()
                    cm.Dispose()
                    Exit Sub
                End Try
            End If

            IO.File.WriteAllText(Server.MapPath(".") & "\downloads\" & vFilename, vData.ToString)
            vScript = "alert('Download complete.'); winpop=window.open('downloads/" & vFilename & _
                "','winpop','top=10,left=10,height=768,width=1024,resizable=yes,scrollbars=yes');winpop.focus();"
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to retrieve record. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            c.Dispose()
            cm.Dispose()
        End Try
    End Sub
    Private Sub Generate7_4()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim vData As New StringBuilder
        Dim vTINEMR As String = "000000000"
        Dim iCtr As Integer = 1
        Dim vTotals(29) As Decimal
        Dim vFilename As String

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        cm.Connection = c

        Try

            cm.CommandText = "select Tin from glsyscntrl where AgencyCd='" & cmbOfc.SelectedValue & "'"

            rs = cm.ExecuteReader
            If rs.Read Then
                If Not IsDBNull(rs("Tin")) Then
                    If rs("Tin").ToString.Trim = "" Then
                        GoTo notin
                    End If
                    vTINEMR = Mid(rs("Tin").ToString.Replace("-", ""), 1, 9)
                Else
notin:
                    vScript = "alert('No Employer TIN defined.');"
                    rs.Close()
                    c.Close()
                    c.Dispose()
                    cm.Dispose()
                    Exit Sub
                End If

            End If
            rs.Close()

            For iCtr = 0 To 28
                vTotals(iCtr) = 0
            Next
            iCtr = 0

            vData.AppendLine("H1604CF," & vTINEMR & ",0000,12/31/" & cmbYear.SelectedValue)

            cm.CommandText = "select * from [1604f] where Sched_Num='" & rdoSchedule.SelectedValue & _
                "' and year(ReturnPd)=" & cmbYear.SelectedValue

            rs = cm.ExecuteReader
            Do While rs.Read
                iCtr += 1
                vData.AppendLine("D7.4,1604CF," & vTINEMR & ",0000," & Format(CDate(rs("ReturnPd")), "MM/dd/yyyy") & "," & _
                    Format(iCtr, "000000") & "," & Mid(rs("Tin_Emp").ToString.Replace("-", ""), 1, 9) & ",0000," & _
                    rs("Lname") & "," & rs("Fname") & "," & rs("Mname") & "," & rs("Gross_Comp_Income") & "," & _
                    rs("Prev_Nontax_13th_Month") & "," & rs("Prev_NonTax_De_Minimis") & "," & _
                    rs("Prev_NonTax_Sss") & "," & rs("Prev_NonTax_Salaries") & "," & _
                    rs("Prev_Total_NonTax_Comp_Income") & "," & rs("Prev_Taxable_Basic_Salary") & _
                    rs("Prev_Taxable_13th_Month") & "," & rs("Prev_Taxable_Salaries") & "," & _
                    rs("Prev_Total_Taxable") & "," & _
                    rs("NonTax_13th") & "," & rs("Pres_NonTax_De_Minimis") & "," & rs("Mandatory") & "," & _
                    rs("OtherIncent_NonTax") & "," & _
                    rs("NonTax_13th") + rs("Pres_NonTax_De_Minimis") & +rs("Mandatory") + rs("OtherIncent_NonTax") & "," & _
                    rs("Tax_Basic_Sal") & "," & rs("Tax_13th") & "," & rs("Salaries_Tax") & "," & _
                    rs("Tax_Basic_Sal") + rs("Tax_13th") + rs("Salaries_Tax") & "," & _
                    rs("Prev_Pres_Total_Taxable") & "," & _
                    rs("Tax_Cd") & "," & rs("Exemption") & "," & rs("Premiums") & "," & rs("Net_Taxable_Comp_Income") & _
                    "," & rs("TaxDue") & "," & rs("Prev_Tax_WithHeld") & "," & rs("TaxWithHeld") - rs("TaxWithHeld_Dec") & "," & _
                    rs("TaxWithHeld_Dec") & "," & rs("Variance") & "," & rs("TaxWithHeld") + rs("Prev_Tax_WithHeld"))
                vTotals(0) += rs("Gross_Comp_Income")
                vTotals(1) += rs("Prev_Nontax_13th_Month")
                vTotals(2) += rs("Prev_NonTax_De_Minimis")
                vTotals(3) += rs("Prev_NonTax_Sss")
                vTotals(4) += rs("Prev_NonTax_Salaries")
                vTotals(5) += rs("Prev_Total_NonTax_Comp_Income")
                vTotals(6) += rs("Prev_Taxable_Basic_Salary")
                vTotals(7) += rs("Prev_Taxable_13th_Month")
                vTotals(8) += rs("Prev_Taxable_Salaries")
                vTotals(9) += rs("Prev_Total_Taxable")
                vTotals(10) += rs("NonTax_13th")
                vTotals(11) += rs("Pres_NonTax_De_Minimis")
                vTotals(12) += rs("Mandatory")
                vTotals(13) += rs("OtherIncent_NonTax")
                vTotals(14) += rs("NonTax_13th") + rs("Pres_NonTax_De_Minimis") + rs("Mandatory") + rs("OtherIncent_NonTax")
                vTotals(15) += rs("Tax_Basic_Sal")
                vTotals(16) += rs("Tax_13th")
                vTotals(17) += rs("Salaries_Tax")
                vTotals(18) += rs("Tax_Basic_Sal") + rs("Tax_13th") + rs("Salaries_Tax")
                vTotals(19) += rs("Prev_Pres_Total_Taxable")
                vTotals(20) += rs("ExemptioN")
                vTotals(21) += rs("Premiums")
                vTotals(22) += rs("Net_Taxable_Comp_Income")
                vTotals(23) += rs("TaxDue")
                vTotals(24) += rs("Prev_Tax_WithHeld")
                vTotals(25) += rs("TaxWithHeld") - rs("TaxWithHeld_Dec")
                vTotals(26) += rs("TaxWithHeld_Dec")
                vTotals(27) += rs("Variance")
                vTotals(28) += rs("TaxWithHeld") + rs("Prev_Tax_WithHeld")
            Loop
            rs.Close()
            vData.AppendLine("C7.3,1604CF," & vTINEMR & ",0000,12/31/" & cmbYear.SelectedValue & "," & _
                vTotals(0) & "," & vTotals(1) & "," & vTotals(2) & "," & vTotals(3) & "," & vTotals(4) & "," & _
                vTotals(5) & "," & vTotals(6) & "," & vTotals(7) & "," & vTotals(8) & "," & vTotals(9) & "," & _
                vTotals(10) & "," & vTotals(11) & "," & vTotals(12) & "," & vTotals(13) & "," & vTotals(14) & "," & _
                vTotals(15) & "," & vTotals(16) & "," & vTotals(17) & "," & vTotals(18) & "," & vTotals(19) & "," & _
                vTotals(20) & "," & vTotals(21) & "," & vTotals(22) & "," & vTotals(23) & "," & vTotals(24) & "," & _
                vTotals(25) & "," & vTotals(26) & "," & vTotals(27) & "," & vTotals(28))

            vFilename = vTINEMR & "1231" & cmbYear.SelectedValue & "7.4.csv"

            If IO.File.Exists(Server.MapPath(".") & "\downloads\" & vFilename) Then
                Try
                    IO.File.Delete(Server.MapPath(".") & "\downloads\" & vFilename)
                Catch ex As Exception
                    vScript = "alert('Error deleting temporary file. Error is: " & _
                        ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                    c.Close()
                    c.Dispose()
                    cm.Dispose()
                    Exit Sub
                End Try
            End If

            IO.File.WriteAllText(Server.MapPath(".") & "\downloads\" & vFilename, vData.ToString)
            vScript = "alert('Download complete.'); winpop=window.open('downloads/" & vFilename & _
                "','winpop','top=10,left=10,height=768,width=1024,resizable=yes,scrollbars=yes');winpop.focus();"
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to retrieve record. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            c.Dispose()
            cm.Dispose()
        End Try
    End Sub
    Protected Sub cmdDownload_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDownload.Click
        If cmbOfc.SelectedValue = "All" Then
            vScript = "alert('You must first select a Company/Office.');"
            Exit Sub
        End If

        Select Case rdoSchedule.SelectedValue
            Case "D7.1"
                'Generate7_1()
            Case "D7.2"
            Case "D7.3"
                Generate7_3()
            Case "D7.4"
                Generate7_4()
        End Select
    End Sub
End Class
