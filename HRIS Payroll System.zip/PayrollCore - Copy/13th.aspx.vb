Imports denaro
Partial Class _13th
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Public vDump As String = ""
    Public vMonth(12) As String
    Public vTotAmount As Double = 0
    Dim c As New SqlClient.SqlConnection
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'If Session("uid") = "" Then
        '    Session("returnaddr") = "massupdateincent.aspx"
        '    Server.Transfer("index.aspx")
        'End If
        If Not IsPostBack Then 'now build the reference code
            'If Not CanRun(Session("caption"), Request.Item("id")) Then
            '    Session("denied") = "1"
            '    Server.Transfer("main.aspx")
            '    Exit Sub
            'End If
            Dim ictr As Integer
            lblCaption.Text = "13th Month,Bonus and Other Incentives Computation"
            'BuildCombo("select Rc_Cd, Descr from rc where Rc_Cd in ('" & _
            '    Session("rclist").ToString.Replace(",", "','") & "') order by Descr", cmbRC)
            'BuildCombo("select AgencyCd,AgencyName from agency where AgencyCd in ('" & _
            '    Session("agencylist").ToString.Replace(",", "','") & "') order by AgencyName", cmbOfc)
            'BuildCombo("select Div_Cd,Descr from hr_div_ref where Div_Cd in ('" & _
            '    Session("divlist").ToString.Replace(",", "','") & "') order by Descr", cmbDiv)
            'BuildCombo("select Dept_Cd,Descr from hr_dept_ref where Dept_Cd in ('" & _
            '    Session("deptlist").ToString.Replace(",", "','") & "') order by Descr", cmbDept)
            'BuildCombo("select Section_Cd,Descr from hr_section_ref where Section_Cd in ('" & _
            '    Session("sectionlist").ToString.Replace(",", "','") & "') order by Descr", cmbSection)
            'BuildCombo("select Unit_Cd,Descr from hr_unit_ref where Unit_Cd in ('" & _
            '    Session("unitlist").ToString.Replace(",", "','") & "') order by Descr", cmbUnit)
            'BuildCombo("select Incentive_Cd,Descr from py_other_incentvs order by Descr", cmbIncent)
            'BuildCombo("select EmploymentType,Descr from hr_employment_type where EmploymentType in ('" & _
            '    Session("typelist").ToString.Replace(",", "','") & "') order by Descr", cmbSecurity)
            BuildCombo("select Rc_Cd, Descr from rc order by Descr", cmbRC)
            BuildCombo("select AgencyCd,AgencyName from agency order by AgencyName", cmbOfc)
            BuildCombo("select Div_Cd,Descr from hr_div_ref order by Descr", cmbDiv)
            BuildCombo("select Dept_Cd,Descr from hr_dept_ref order by Descr", cmbDept)
            BuildCombo("select Section_Cd,Descr from hr_section_ref order by Descr", cmbSection)
            BuildCombo("select Unit_Cd,Descr from hr_unit_ref order by Descr", cmbUnit)
            BuildCombo("select Incentive_Cd,Descr from py_other_incentvs order by Descr", cmbIncent)
            BuildCombo("select EmploymentType,Descr from hr_employment_type order by Descr", cmbSecurity)
            cmbRC.Items.Add("All")
            cmbRC.SelectedValue = "All"
            cmbOfc.Items.Add("All")
            cmbOfc.SelectedValue = "All"
            cmbDiv.Items.Add("All")
            cmbDiv.SelectedValue = "All"
            cmbDept.Items.Add("All")
            cmbDept.SelectedValue = "All"
            cmbSection.Items.Add("All")
            cmbSection.SelectedValue = "All"
            cmbUnit.Items.Add("All")
            cmbUnit.SelectedValue = "All"
            cmbSecurity.Items.Add("All")
            cmbSecurity.SelectedValue = "All"
            cmbYearFr.Items.Clear()
            cmbYearTo.Items.Clear()
            For ictr = 1990 To 2030
                cmbYearFr.Items.Add(ictr)
                cmbYearTo.Items.Add(ictr)
            Next
            cmbYearFr.SelectedValue = Now.Year
            cmbYearTo.SelectedValue = Now.Year
        Else
            If Request.Form("txtEmpList") <> "" Then
                txtEmpList.Text = Request.Form("txtEmpList")
            End If
        End If
    End Sub
    Protected Sub cmdReturn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.Click
        Session.Remove("basis")
        Session.Remove("1stMonthCredit")
        Session.Remove("cond1")
        Session.Remove("cond2")
        Session.Remove("cond3")
        Session.Remove("start1")
        Session.Remove("start2")
        Session.Remove("start3")
        Session.Remove("end1")
        Session.Remove("end2")
        Session.Remove("end3")
        Session.Remove("absences")
        Session.Remove("divisor")
        Session.Remove("incentives")
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub cmdGenerate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdGenerate.Click
        Dim vEmpCount As Integer = 0
        'Dim vTotAmount As Double = 0

        Dim vEmpList As String = txtEmpList.Text
        If vEmpList = "" Then
            vScript = "alert('You must first select a list of employees to generate.');"
            Exit Sub
        End If

        If Session("basis") = Nothing Or _
            Session("divisor") = Nothing Or _
            Session("1stMonthCredit") = Nothing Then
            vScript = "alert('You must first click the settings button to set the necessary parameters.');"
            Exit Sub
        End If

        Dim vString As String = ""
        Dim vCompute As String = ""
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim vMonths(12) As String
        Dim iCtr As Integer
        Dim iLoop As Integer
        Dim vStartDate As Date
        Dim vStyle As String = "odd"

        'set the month labels
        vMonths(0) = "Jan" : vMonths(1) = "Feb" : vMonths(2) = "Mar" : vMonths(3) = "Apr"
        vMonths(4) = "May" : vMonths(5) = "Jun" : vMonths(6) = "Jul" : vMonths(7) = "Aug"
        vMonths(8) = "Sep" : vMonths(9) = "Oct" : vMonths(10) = "Nov" : vMonths(11) = "Dec"
        iCtr = 0
        cmbMonthFrom.Value = Request.Form("cmbMonthFrom")
        For iLoop = Val(Request.Form("cmbMonthFrom")) To 12
            vMonth(iCtr) = vMonths(iLoop - 1)
            iCtr += 1
        Next iLoop
        If cmbMonthFrom.Value <> 1 Then
            For iLoop = 1 To cmbMonthTo.SelectedValue
                vMonth(iCtr) = vMonths(iLoop - 1)
                iCtr += 1
            Next iLoop
        End If

        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c
        cm.CommandText = "select Emp_Cd,Emp_Lname,Emp_Fname,Rate_Month,Rate_Day,Start_Date,Date_Resign,DateRegularized from " & _
            "py_emp_master where Emp_Cd in (" & vEmpList & ") and Start_Date is not null order by Emp_Lname,Emp_Fname"

        rs = cm.ExecuteReader
        vDump = ""
        vString = ""
        'vString = "Emp Code,Employee Name,Date Hired,Monthly Rate,Jan,Feb,Mar,Apr,May,Jun,Jul,Aug,Sep,Oct,Nov,Dec,Total,"
        Do While rs.Read
            vEmpCount += 1
            vString += rs("Emp_Cd") & "," & rs("Emp_Lname") & "," & rs("Emp_Fname") & "," & _
                            Format(rs("Start_Date"), "MM/dd/yyyy") & "," & _
                            Format(rs("Rate_Month"), "#####0.00") & ","

            If Not IsDBNull(rs("DateRegularized")) Then
                vStartDate = rs("DateRegularized")
            Else
                vStartDate = rs("Start_Date")
            End If

            vCompute = Compute(rs("Emp_Cd"), rs("Rate_Month"), rs("Rate_Day"), vStartDate, _
                IIf(IsDBNull(rs("Date_Resign")), "", rs("Date_Resign")), vString)

            vString += vbCrLf
            vDump += "<tr class=' " & vStyle & " '><td class='labelBC'>" & rs("Emp_Cd") & "</td>" & _
                "<td class='labelBL'>&nbsp;" & rs("Emp_Lname") & ", " & rs("Emp_Fname") & "</td>" & _
                "<td class='labelBC'>" & Format(rs("Start_Date"), "MM/dd/yyyy") & "</td>" & _
                "<td class='labelBC'>" & Format(rs("Rate_Month"), "###,##0.00") & "</td>" & _
                vCompute & "</tr>"

            If vStyle = "odd" Then
                vStyle = "even"
            Else
                vStyle = "odd"
            End If
        Loop
        rs.Close()
        cm.Dispose()
        c.Close()
        cmdPost.Enabled = True
        txtEmpCount.Text = vEmpCount
        txtTotAmount.Text = Format(vTotAmount, "###,###,##0.00")

        If Dir(Server.MapPath(".") & "\downloads\" & Session.SessionID & "-13th.csv") <> "" Then
            Try
                IO.File.Delete(Server.MapPath(".") & "\downloads\" & Session.SessionID & "-13th.csv")
            Catch ex As IO.IOException
                vScript = "alert('Error writing deleteing csv file. " & ex.Message.Replace("'", "\'").Replace(vbCrLf, "\n") & "');"
            End Try
        End If
        Try
            IO.File.WriteAllText(Server.MapPath(".") & "\downloads\" & Session.SessionID & "-13th.csv", vString)
            lnkDownload.NavigateUrl = "downloads/" & Session.SessionID & "-13th.csv"

        Catch ex As IO.IOException
            vScript = "alert('Error writing writing to csv file. " & ex.Message.Replace("'", "\'").Replace(vbCrLf, "\n") & "');"
        End Try

    End Sub
    Private Function Compute(ByVal pEmpCd As String, ByVal pRateMonth As Double, _
        ByVal pRateDay As Double, ByVal pStartDate As Date, ByVal pEndDate As String, _
        ByRef pDump As String) As String

        Dim rsPayroll As SqlClient.SqlDataReader
        Dim cmPayroll As New SqlClient.SqlCommand
        Dim iCtr As Integer = 1
        Dim iMonth As Integer
        Dim vStart As Integer
        Dim vEnd As Integer
        Dim vYear As Integer
        Dim vSw As Boolean = False
        Dim vEndDate As Date
        Dim vAbsents As Double
        Dim vBasic As Double
        Dim v13th As Double
        Dim vTotal As Double = 0
        Dim vIncent As Double
        Dim vSum As String = Session("incentives")
        Dim vStr As String = ""
        Dim vPayPeriodCount As Integer = 0

        If pEndDate = "" Then
            vEndDate = Nothing
        Else
            vEndDate = CDate(pEndDate)
        End If

        vStart = cmbMonthFrom.Value
        vEnd = 12
        vYear = Val(cmbYearFr.SelectedValue)
        cmPayroll.Connection = c

again:
        For iMonth = vStart To vEnd
            vAbsents = 0
            vIncent = 0

            If Session("basis") = "1" Or Session("absences") = "1" Then   'USE GROSS BASIC WITH OR W/O ABSENT & TARDINESS OPTION
                cmPayroll.CommandText = "select sum(Month_Rate) as Basic, sum(Ot) as TotalOt,count(*) as PayPdCount, " & _
                   "sum(Absent+Tardiness) as Ut " & vSum & " from py_report where year(PayDate)=" & _
                   vYear & " and month(PayDate)=" & iMonth & " and Emp_Cd='" & pEmpCd & "' and Agency_Cd not in ('100','101')"

                rsPayroll = cmPayroll.ExecuteReader
                vPayPeriodCount = 0
                If rsPayroll.Read Then
                    vAbsents = IIf(IsDBNull(rsPayroll("Ut")), 0, rsPayroll("Ut"))
                    'vBasic = IIf(IsDBNull(rsPayroll("Basic")), 0, rsPayroll("Basic")) + _
                    '   IIf(IsDBNull(rsPayroll("TotalOt")), 0, rsPayroll("TotalOt")) + _
                    '   IIf(IsDBNull(rsPayroll("Acas")), 0, rsPayroll("Acas")) + _
                    '   IIf(IsDBNull(rsPayroll("Ratas")), 0, rsPayroll("Ratas")) + _
                    '   IIf(IsDBNull(rsPayroll("Peras")), 0, rsPayroll("Peras")) + _
                    '   IIf(IsDBNull(rsPayroll("Meals")), 0, rsPayroll("Meals"))
                    vBasic = IIf(IsDBNull(rsPayroll("Basic")), 0, rsPayroll("Basic"))
                    vIncent = IIf(IsDBNull(rsPayroll("Incent")), 0, rsPayroll("Incent"))
                    vPayPeriodCount = IIf(IsDBNull(rsPayroll("PayPdCount")), 0, rsPayroll("PayPdCount"))
                End If
                rsPayroll.Close()

                '-------------------------------------------------------------------------------------------------------------------------

                If vBasic = 0 Then 'Or vPayPeriodCount < 2 Then      

                    'if current gross is zero, get basicrate of current month 
                    'plus ot and absences and tardiness of previous year of same month
                    'get last date of payment in payroll;

                    Dim vLastPayMonth As Integer = 0
                    cmPayroll.CommandText = "select PayDate from py_report where " & _
                        "Posted<>0 order by PayDate desc limit 1"
                    rsPayroll = cmPayroll.ExecuteReader
                    If rsPayroll.Read Then
                        vLastPayMonth = CDate(rsPayroll("PayDate")).Month
                    Else
                        vLastPayMonth = Now.Month
                    End If
                    rsPayroll.Close()

                    If (Year(pStartDate) < Year(Now) And iMonth > vLastPayMonth) Or _
                        (Year(pStartDate) = Year(Now) And iMonth >= Month(pStartDate) And _
                        iMonth > vLastPayMonth) Then
                        cmPayroll.CommandText = "select Aca,Rata,Pera,MealAllow,Rate_Month from " & _
                            "py_emp_master where Emp_Cd='" & pEmpCd & "'"

                        rsPayroll = cmPayroll.ExecuteReader
                        vBasic = 0
                        If rsPayroll.Read Then
                            'vBasic = IIf(vBasic = 0, rsPayroll("Rate_Month"), 0) + rsPayroll("Aca") + _
                            '    rsPayroll("Rata") + rsPayroll("Pera") + rsPayroll("MealAllow")
                            vBasic = IIf(vBasic = 0, rsPayroll("Rate_Month"), 0)
                        End If
                        rsPayroll.Close()

                        'get summation of  overtime,absences and tardiness of previous year of the selected month
                        'cmPayroll.CommandText = "select sum(Ot) as TotalOt, " & _
                        '   "sum(Absent+Tardiness) as Ut " & vSum & " from py_report where year(PayDate)=" & _
                        '   vYear - 1 & " and month(PayDate)=" & iMonth & " and Emp_Cd='" & pEmpCd & "'"
                        'rsPayroll = cmPayroll.ExecuteReader
                        'If rsPayroll.Read Then
                        '    vAbsents = IIf(IsDBNull(rsPayroll("Ut")), 0, rsPayroll("Ut"))
                        '    vBasic += IIf(IsDBNull(rsPayroll("TotalOt")), 0, rsPayroll("TotalOt"))
                        'End If
                        'rsPayroll.Close()
                    ElseIf vPayPeriodCount = 1 Then 'payroll period is only 1st half, get then 2nd half from basic pay
                        'vBasic += (pRateMonth / 2)
                    End If  'check start date
                End If
            End If

            '-------------------------------------------------------------------------------------------------------------------------

            If Session("basis") = "0" Then  'USE BASIC RATE
                vBasic = 0
                If Year(pStartDate) < Year(Now) Then      'DATE HIRED IS MORE THAN A YEAR
                    If vEndDate <> Nothing Then           'employee is already resigned
                        If iMonth < Month(vEndDate) And Year(vEndDate) = vYear Then
                            vBasic = pRateMonth + vIncent
                        ElseIf iMonth > Month(vEndDate) And Year(vEndDate) = vYear Then
                            vBasic = 0
                        ElseIf iMonth = Month(vEndDate) And Year(vEndDate) = vYear Then
                            'enddate is current month, so get absolute remaining days
                            vBasic = (pRateMonth / Day(MonthEND(vEndDate))) * Day(vEndDate)
                        End If
                    Else
                        vBasic = Val(pRateMonth) + vIncent
                    End If
                Else 'DATE HIRED IS WITHIN THE YEAR
                    If Month(pStartDate) > iMonth And Year(pStartDate) = vYear Then
                        vBasic = 0
                    ElseIf Month(pStartDate) = iMonth And Year(pStartDate) = vYear Then 'GET ACTUAL DAYS
                        If Session("1stMonthCredit") = "0" Then   'USE PRO-RATED CALCULATION
                            vBasic = (pRateMonth / Day(MonthEND(pStartDate))) * _
                               (DateDiff("d", pStartDate, MonthEND(pStartDate)) + 1)
                        Else  'USE RANGE DATE CALCULATION
                            'CHECK 3RD FIELD CONDITION
                            vBasic = GetBasic(3, pRateMonth, pStartDate)
                            If vBasic = 0 Then vBasic = GetBasic(2, pRateMonth, pStartDate) 'CHECK 2ND FIELD COND
                            If vBasic = 0 Then vBasic = GetBasic(1, pRateMonth, pStartDate) 'CHECK 1ST FIELD COND
                        End If
                    ElseIf Month(pStartDate) < iMonth And Year(pStartDate) = vYear Then  'PAST HIRED DATE
                        If pEndDate <> Nothing Then    'resigned
                            If iMonth < Month(vEndDate) And Year(vEndDate) = vYear Then
                                vBasic = pRateMonth + vIncent
                            ElseIf iMonth > Month(vEndDate) And Year(vEndDate) = vYear Then
                                vBasic = 0
                            ElseIf iMonth = Month(vEndDate) And Year(vEndDate) = vYear Then  'month is equal to imonth
                                vBasic = (pRateDay / Day(MonthEND(vEndDate))) * Day(vEndDate)
                            End If
                        Else
                            vBasic = pRateMonth + vIncent
                        End If
                    End If
                End If
            End If

            v13th = (vBasic + vIncent + vAbsents) / Val(Session("divisor"))
            vTotal += v13th
            'dump to string
            pDump += Format(v13th) & ","
            vStr += "<td class='labelBC'>" & _
                "<input id='txt" & Format(iCtr, "00") & pEmpCd & _
                "' name='txt" & Format(iCtr, "00") & pEmpCd & _
                "' class='labelR' style='width: 56px; direction: rtl; " & _
                "background-color: transparent; border:0px ' type='text' " & _
                "value='" & Format(v13th, "###,##0.00") & "' /></td>"
            iCtr += 1
        Next iMonth
        If Not vSw Then
            If cmbMonthFrom.Value > 1 Then  'selected month is not january
                vStart = 1
                vEnd = cmbMonthTo.SelectedValue
                vYear = cmbYearTo.SelectedValue
                vSw = True
                GoTo again
            End If
        End If

        If cmbPostmuch.SelectedValue = "QAmt" Then
            vTotal = vTotal / 4
        ElseIf cmbPostmuch.SelectedValue = "HAmt" Then
            vTotal = vTotal / 2
        End If

        vStr += "<td class='labelBC'>" & _
            "<input id='txtTot" & pEmpCd & _
            "' name='txtTot" & pEmpCd & _
            "' class='labelR' style='width: 56px; direction: rtl; border:0px; " & _
            "background-color: transparent; ' type='text' " & _
            "value='" & Format(vTotal, "###,##0.00") & "' /></td>"
        pDump += Format(vTotal)
        Compute = vStr
        vTotAmount += Format(vTotal)
    End Function

    Private Function GetBasic(ByVal pIndex As Integer, ByVal pRateMonth As Double, ByVal pStartDate As Date) As Double

        Response.Write(pRateMonth & " - " & pStartDate)
        If Day(pStartDate) >= Val(Session("start" & pIndex)) And _
           Day(pStartDate) <= Val(Session("end" & pIndex)) Then
            GetBasic = (Val(Session("cond" & pIndex)) / 100) * pRateMonth
        Else
            GetBasic = 0
        End If
    End Function

    Protected Sub cmdPost_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdPost.Click
        If Not IsDate(txtEffectivity.Text) Then
            vScript = "alert('You must enter a valid effectivity date format.');"
            Exit Sub
        End If
        If cmbIncent.SelectedIndex < 0 Then
            vScript = "alert('You must select where to post the calculated figures.');"
            Exit Sub
        End If

        If txtEmpList.Text = "" Then
            vScript = "alert('You must select an employee list first, then click the Generate button before posting it to " & _
                "incentives module.');"
            Exit Sub
        End If

        Dim vAmount As Double = 0
        Dim cm As New SqlClient.SqlCommand
        Dim cmExec As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim vEmpList = txtEmpList.Text

        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c
        cmExec.Connection = c
        cm.CommandText = "select Emp_Cd from " & _
            "py_emp_master where Emp_Cd in (" & vEmpList & ") and Start_Date is not null order by Emp_Lname,Emp_Fname"
        rs = cm.ExecuteReader
        vDump = ""
        Do While rs.Read

            Select Case cmbPostmuch.SelectedValue
                Case "0"    'whole amount
                    vAmount = Val(Request.Form("txtTot" & rs("Emp_Cd")).ToString.Replace(",", ""))
                Case "1"    '1st quarter
                    vAmount = Val(Request.Form("txt01" & rs("Emp_Cd")).ToString.Replace(",", "")) + _
                        Val(Request.Form("txt02" & rs("Emp_Cd")).ToString.Replace(",", "")) + _
                        Val(Request.Form("txt03" & rs("Emp_Cd")).ToString.Replace(",", ""))
                Case "2"    '2nd quarter
                    vAmount = Val(Request.Form("txt04" & rs("Emp_Cd")).ToString.Replace(",", "")) + _
                        Val(Request.Form("txt05" & rs("Emp_Cd")).ToString.Replace(",", "")) + _
                        Val(Request.Form("txt06" & rs("Emp_Cd")).ToString.Replace(",", ""))
                Case "3"    '3rd quarter
                    vAmount = Val(Request.Form("txt07" & rs("Emp_Cd")).ToString.Replace(",", "")) + _
                        Val(Request.Form("txt08" & rs("Emp_Cd")).ToString.Replace(",", "")) + _
                        Val(Request.Form("txt09" & rs("Emp_Cd")).ToString.Replace(",", ""))
                Case "4"    '4th quarter
                    vAmount = Val(Request.Form("txt10" & rs("Emp_Cd")).ToString.Replace(",", "")) + _
                        Val(Request.Form("txt11" & rs("Emp_Cd")).ToString.Replace(",", "")) + _
                        Val(Request.Form("txt12" & rs("Emp_Cd")).ToString.Replace(",", ""))
                Case "1/2"  '1st half
                    vAmount = Val(Request.Form("txt01" & rs("Emp_Cd")).ToString.Replace(",", "")) + _
                        Val(Request.Form("txt02" & rs("Emp_Cd")).ToString.Replace(",", "")) + _
                        Val(Request.Form("txt03" & rs("Emp_Cd")).ToString.Replace(",", "")) + _
                        Val(Request.Form("txt04" & rs("Emp_Cd")).ToString.Replace(",", "")) + _
                        Val(Request.Form("txt05" & rs("Emp_Cd")).ToString.Replace(",", "")) + _
                        Val(Request.Form("txt06" & rs("Emp_Cd")).ToString.Replace(",", ""))
                Case "2/2"  '2nd half
                    vAmount = Val(Request.Form("txt07" & rs("Emp_Cd")).ToString.Replace(",", "")) + _
                        Val(Request.Form("txt08" & rs("Emp_Cd")).ToString.Replace(",", "")) + _
                        Val(Request.Form("txt09" & rs("Emp_Cd")).ToString.Replace(",", "")) + _
                        Val(Request.Form("txt10" & rs("Emp_Cd")).ToString.Replace(",", "")) + _
                        Val(Request.Form("txt11" & rs("Emp_Cd")).ToString.Replace(",", "")) + _
                        Val(Request.Form("txt12" & rs("Emp_Cd")).ToString.Replace(",", ""))
                Case "QAmt" 'Quarter of the Amount
                    vAmount = Val(Request.Form("txt10" & rs("Emp_Cd")).ToString.Replace(",", "")) + _
                        Val(Request.Form("txt11" & rs("Emp_Cd")).ToString.Replace(",", "")) + _
                        Val(Request.Form("txt12" & rs("Emp_Cd")).ToString.Replace(",", ""))
                Case "HAmt" 'Half of the Amount
                    vAmount = Val(Request.Form("txtTot" & rs("Emp_Cd")).ToString.Replace(",", ""))
            End Select

            cmExec.CommandText = "delete from py_incentives_dtl where Emp_Cd='" & _
                rs("Emp_Cd") & "' and Incentive_Cd='" & cmbIncent.SelectedValue & _
                "' and FromDate='" & Format(CDate(txtEffectivity.Text), "yyyy/MM/dd") & "'"
            cmExec.ExecuteNonQuery()
            cmExec.CommandText = "insert into py_incentives_dtl (Incentive_Cd,Incentive_Amt," & _
                "FromDate,ToDate,Emp_Cd,Recurring) values ('" & cmbIncent.SelectedValue & _
                "'," & vAmount & ",'" & Format(CDate(txtEffectivity.Text), "yyyy/MM/dd") & _
                "','" & Format(CDate(txtEffectivity.Text), "yyyy/MM/dd") & "','" & _
                rs("Emp_Cd") & "',0)"
            cmExec.ExecuteNonQuery()
        Loop

        rs.Close()
        cm.Dispose()
        c.Close()
        vScript = "alert('Posting complete!');"
    End Sub

End Class
