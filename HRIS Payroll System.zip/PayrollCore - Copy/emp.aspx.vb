Namespace denaro
    Partial Class emp
        Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub


        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        Public vScript As String = ""
        Public vSalaryOtherInfo As String = ""
        Dim vClass As String = "odd"
        Dim vSQL As String = ""

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load, Me.Load
            If Session("uid") = "" Then
                Server.Transfer("index.aspx")
                Exit Sub
            End If
            If Not IsPostBack Then

                If Not CanRun(Session("caption"), Request.Item("id")) Then
                    Session("denied") = "1"
                    Server.Transfer("main.aspx")
                    Exit Sub
                End If
                lblCaption.Text = "Employee 201 Profile"
                BuildCombo("select Rc_Cd,Descr from rc where exists (select User_Id from rights_list where User_Id='" & _
                    Session("uid") & "' and property='rc' and Property_Value=Rc_Cd) order by Descr", cmbRC)
                BuildCombo("select AgencyCd,AgencyName from agency where exists (select User_Id from rights_list where User_Id='" & _
                    Session("uid") & "' and property='agency' and Property_Value=AgencyCd) order by AgencyName", cmbOfc)
                BuildCombo("select Div_Cd,Descr from hr_div_ref where exists (select User_Id from rights_list where User_Id='" & _
                    Session("uid") & "' and property='division' and Property_Value=Div_Cd) order by Descr", cmbDiv)
                BuildCombo("select Dept_Cd,Descr from hr_dept_ref where exists (select User_Id from rights_list where User_Id='" & _
                    Session("uid") & "' and property='department' and Property_Value=Dept_Cd) order by Descr", cmbDept)
                BuildCombo("select Section_Cd,Descr from hr_section_ref where exists (select User_Id from rights_list where User_Id='" & _
                    Session("uid") & "' and property='section' and Property_Value=Section_Cd) order by Descr", cmbSection)
                BuildCombo("select Unit_Cd,Descr from hr_unit_ref where exists (select User_Id from rights_list where User_Id='" & _
                    Session("uid") & "' and property='unit' and Property_Value=Unit_Cd) order by Descr", cmbUnit)
                BuildCombo("select EmploymentType,Descr from hr_employment_type where exists (select User_Id from rights_list where User_Id='" & _
                    Session("uid") & "' and property='employmenttype' and Property_Value=EmploymentType) order by Descr", cmbEmpType)
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY:     Rudner D. Diaz, Jr.                                        ''
                '' DATE:            4/4/2013                                                   ''
                '' PURPOSE:         To include the paymode in searching the employee           ''
                '' Exception:       Cygnus                                                     ''
                '' ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                BuildCombo("select Pay_Cd, Payment from py_pay_mode order by Payment", cmbPayMode)
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

                cmbRC.Items.Add("All")
                cmbRC.SelectedValue = "All"
                cmbOfc.Items.Add("All")
                cmbOfc.SelectedValue = "All"
                cmbDiv.Items.Add("All")
                cmbDiv.SelectedValue = "All"
                cmbDept.Items.Add("All")
                cmbDept.SelectedValue = "All"
                cmbSection.Items.Add("All")
                cmbSection.SelectedValue = "All"
                cmbUnit.Items.Add("All")
                cmbUnit.SelectedValue = "All"
                cmbEmpType.Items.Add("All")
                cmbEmpType.SelectedValue = "All"
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY:     Rudner D. Diaz, Jr.                                        ''
                '' DATE:            4/4/2013                                                   ''
                '' PURPOSE:         To include the paymode in searching the employee           ''
                '' ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                cmbPayMode.Items.Add("All")
                cmbPayMode.SelectedValue = "All"
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                Session("letter") = "A"
                DataRefresh(Session("letter"))
                cmdAdd.Enabled = CanRun(Session("caption"), "41.100")
                cmdEdit.Enabled = CanRun(Session("caption"), "41.101")
                cmdDelete.Enabled = CanRun(Session("caption"), "41.102")
                cmdPrintEMR.Enabled = CanRun(Session("caption"), "41.103")

                pnlGeneral.Visible = False
                pnlAccountability.Visible = False
            End If
        End Sub
        Private Sub SetLetters(ByVal pLetter As String)
            Select Case pLetter.ToLower
                Case "a"
                    cmdA.Visible = True
                Case "b"
                    cmdB.Visible = True
                Case "c"
                    cmdC.Visible = True
                Case "d"
                    cmdD.Visible = True
                Case "e"
                    cmdE.Visible = True
                Case "f"
                    cmdF.Visible = True
                Case "g"
                    cmdG.Visible = True
                Case "h"
                    cmdH.Visible = True
                Case "i"
                    cmdI.Visible = True
                Case "j"
                    cmdJ.Visible = True
                Case "k"
                    cmdK.Visible = True
                Case "l"
                    cmdL.Visible = True
                Case "m"
                    cmdM.Visible = True
                Case "n"
                    cmdN.Visible = True
                Case "o"
                    cmdO.Visible = True
                Case "p"
                    cmdP.Visible = True
                Case "q"
                    cmdQ.Visible = True
                Case "r"
                    cmdR.Visible = True
                Case "s"
                    cmdS.Visible = True
                Case "t"
                    cmdT.Visible = True
                Case "u"
                    cmdU.Visible = True
                Case "v"
                    cmdV.Visible = True
                Case "w"
                    cmdW.Visible = True
                Case "x"
                    cmdX.Visible = True
                Case "y"
                    cmdY.Visible = True
                Case "z"
                    cmdZ.Visible = True
            End Select
        End Sub
        Private Sub DataRefresh(ByVal pLetter As String)
            Dim c As New SqlClient.SqlConnection
            Dim cm As New SqlClient.SqlCommand
            Dim dr As SqlClient.SqlDataReader
            Dim da As SqlClient.SqlDataAdapter
            Dim ds As New DataSet
            Dim vSQL As String = ""
            Dim vFilter As String = ""
            Dim vLtrFilter As String = ""
            c.ConnectionString = connStr

            vFilter = " where " & cmbType.SelectedValue & " like '" & pLetter & "%' "

            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:  VIC GATCHALIAN                                                  ''
            '' DATE MODIFIED: 3/1/2012                                                       ''
            '' PURPOSE:  TO SUPPORT ADDITIONAL EMPLOYEE CLASSIFICATION IF IT IS ADMIN OR     ''
            ''           OPERATIONS. DEFAULT IS BOTH.                                        ''
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            If rdoGroup.SelectedValue <> "BOTH" Then
                vFilter += " and GroupCd='" & rdoGroup.SelectedValue & "' "
            End If
            '''''''''''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''''''''''

            Select Case Val(cmbStatus.SelectedValue)
                Case 1  'active employees only
                    vFilter += " and Date_Resign is null AND Date_Retired IS NULL AND DateHold IS NULL AND DateDismissed IS NULL"
                    vLtrFilter += " where Date_Resign is null AND Date_Retired IS NULL AND DateHold IS NULL AND DateDismissed IS NULL"
                Case 0  'inactive employees only
                    vFilter += " and (Date_Resign is not null OR Date_Retired IS NOT NULL OR DateHold IS NOT NULL Or DateDismissed IS NOT NULL)"
                    vLtrFilter += " where (Date_Resign is not null OR Date_Retired IS NOT NULL OR DateHold IS NOT NULL OR DateDismissed IS NOT NULL)"
            End Select

            If cmbRC.SelectedValue <> "All" Then   'filter by cost center
                vFilter += " and Rc_Cd='" & cmbRC.SelectedValue & "' "
                If cmbStatus.SelectedValue = 3 Then
                    vLtrFilter += " Where Rc_Cd='" & cmbRC.SelectedValue & "' "
                Else
                    vLtrFilter += " and Rc_Cd='" & cmbRC.SelectedValue & "' "
                End If
            Else
                vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='rc' and Property_Value=Rc_Cd) "

                If cmbStatus.SelectedValue = 3 Then
                    vLtrFilter += " where exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                        "' and Property='rc' and Property_Value=Rc_Cd) "
                Else
                    vLtrFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                        "' and Property='rc' and Property_Value=Rc_Cd) "
                End If
            End If

            If cmbOfc.SelectedValue <> "All" Then        'filter by office/agency
                vFilter += " and Agency_Cd='" & cmbOfc.SelectedValue & "' "
                vLtrFilter += " and Agency_Cd='" & cmbOfc.SelectedValue & "' "
            Else
                vFilter += "  and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='agency' and Property_Value=Agency_Cd) "
                vLtrFilter += "  and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='agency' and Property_Value=Agency_Cd) "
            End If
            If cmbDiv.SelectedValue <> "All" Then      'filter by division
                vFilter += " and Divcd='" & cmbDiv.SelectedValue & "' "
                vLtrFilter += " and Divcd='" & cmbDiv.SelectedValue & "' "
            Else
                vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='division' and Property_Value=DivCd) "
                vLtrFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='division' and Property_Value=DivCd) "
            End If
            If cmbDept.SelectedValue <> "All" Then  'filter by departments
                vFilter += " and DeptCd='" & cmbDept.SelectedValue & "' "
                vLtrFilter += " and DeptCd='" & cmbDept.SelectedValue & "' "
            Else
                vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='department' and Property_Value=DeptCd) "
                vLtrFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='department' and Property_Value=DeptCd) "
            End If
            If cmbSection.SelectedValue <> "All" Then 'filter by section
                vFilter += " and SectionCd='" & cmbSection.SelectedValue & "' "
                vLtrFilter += " and SectionCd='" & cmbSection.SelectedValue & "' "
            Else
                vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='section' and Property_Value=SectionCd) "
                vLtrFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='section' and Property_Value=SectionCd) "
            End If
            If cmbUnit.SelectedValue <> "All" Then  'filter by units
                vFilter += " and UnitCd='" & cmbUnit.SelectedValue & "' "
                vLtrFilter += " and UnitCd='" & cmbUnit.SelectedValue & "' "
            Else
                vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='unit' and Property_Value=UnitCd) "
                vLtrFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='unit' and Property_Value=UnitCd) "
            End If
            If cmbEmpType.SelectedValue <> "All" Then 'filter by employment types
                vFilter += " and EmploymentType='" & cmbEmpType.SelectedValue & "' "
                vLtrFilter += " and EmploymentType='" & cmbEmpType.SelectedValue & "' "
            Else
                vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='employmenttype' and Property_Value=EmploymentType) "
                vLtrFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='employmenttype' and Property_Value=EmploymentType) "
            End If
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:     Rudner D. Diaz, Jr.                                        ''
            '' DATE:            4/4/2013                                                   ''
            '' PURPOSE:         To include the paymode in searching the employee           ''
            '' ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            If cmbPayMode.SelectedValue <> "All" Then
                vFilter += " and Pay_Cd='" & cmbPayMode.SelectedValue & "' "
                vLtrFilter += " and Pay_Cd='" & cmbPayMode.SelectedValue & "' "
            End If
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            vSQL = "select * from py_emp_master " & vFilter & _
                " order by Emp_Lname,Emp_Fname,Emp_Mname"
            da = New SqlClient.SqlDataAdapter(vSQL, c)
            da.Fill(ds, "EMP")

            tblEmp.DataSource = ds.Tables("EMP")
            tblEmp.DataBind()
            da.Dispose()
            ds.Dispose()

            c.Open()
            cm.Connection = c
            cm.CommandText = "select distinct substring(Emp_Lname,1,1) as Letters from py_emp_master " & vLtrFilter
            dr = cm.ExecuteReader
            EnableAll(False)
            Do While dr.Read
                SetLetters(dr("Letters"))
            Loop
            dr.Close()
            cm.Dispose()
            c.Close()
            c.Dispose()
            lnkGeneral.Enabled = CanRun(Session("caption"), "41.1")
            lnkPersonal.Enabled = CanRun(Session("caption"), "41.2")
            lnkSalary.Enabled = CanRun(Session("caption"), "41.3")
            lnkIdentificaiton.Enabled = CanRun(Session("caption"), "41.4")
            lnkOptions.Enabled = CanRun(Session("caption"), "41.5")
            lnkDependents.Enabled = CanRun(Session("caption"), "41.6")
            lnkSiblings.Enabled = CanRun(Session("caption"), "41.16")
            lnkrel.Enabled = CanRun(Session("caption"), "41.17")
            lnkRef.Enabled = CanRun(Session("caption"), "41.7")
            lnkLicense.Enabled = CanRun(Session("caption"), "41.8")
            lnkEmpHist.Enabled = CanRun(Session("caption"), "41.9")
            'lnkCareer.Enabled = CanRun(Session("caption"), "41.10")
            lnkSchool.Enabled = CanRun(Session("caption"), "41.11")
            lnktraining.Enabled = CanRun(Session("caption"), "41.12")
            lnkLeave.Enabled = CanRun(Session("caption"), "41.13")
            lnkCommend.Enabled = CanRun(Session("caption"), "41.14")
            lnkViolate.Enabled = CanRun(Session("caption"), "41.15")

            pnlGeneral.Visible = lnkGeneral.Enabled

            If tblEmp.SelectedIndex > -1 And tblEmp.SelectedIndex < tblEmp.Rows.Count Then
                If pnlGeneral.Visible Then
                    RefreshGeneral(tblEmp.SelectedRow.Cells(0).Text)
                End If
                If pnlSalary.Visible Then
                    RefreshSalary(tblEmp.SelectedRow.Cells(0).Text)
                End If
                If pnlIdentification.Visible Then
                    RefreshIdentification(tblEmp.SelectedRow.Cells(0).Text)
                End If
                If pnlOption.Visible Then
                    RefreshOption(tblEmp.SelectedRow.Cells(0).Text)
                End If
                If pnlPersonal.Visible Then
                    RefreshPersonal(tblEmp.SelectedRow.Cells(0).Text)
                End If
                If pnlDep.Visible Then
                    RefreshDep(tblEmp.SelectedRow.Cells(0).Text)
                End If
                If pnlEmpSib.Visible Then
                    RefreshSib(tblEmp.SelectedRow.Cells(0).Text)
                End If
                If pnlLicense.Visible Then
                    RefreshLic(tblEmp.SelectedRow.Cells(0).Text)
                End If
                If pnlEmployment.Visible Then
                    RefreshHist(tblEmp.SelectedRow.Cells(0).Text)
                End If
                If pnlCareer.Visible Then
                    RefreshCareer(tblEmp.SelectedRow.Cells(0).Text)
                End If
                If pnlSchool.Visible Then
                    RefreshSchool(tblEmp.SelectedRow.Cells(0).Text)
                End If
            Else
                If pnlGeneral.Visible Then
                    ClearGeneral()
                End If
                If pnlSalary.Visible Then
                    ClearSalary()
                End If
                If pnlIdentification.Visible Then
                    ClearIdentification()
                End If
                If pnlOption.Visible Then
                    ClearOption()
                End If
            End If
        End Sub

        Private Sub cmdA_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdA.Click, _
            cmdB.Click, cmdC.Click, cmdD.Click, cmdE.Click, cmdF.Click, cmdG.Click, cmdH.Click, cmdI.Click, _
            cmdJ.Click, cmdK.Click, cmdL.Click, cmdM.Click, cmdN.Click, cmdO.Click, cmdP.Click, cmdQ.Click, _
            cmdR.Click, cmdS.Click, cmdT.Click, cmdU.Click, cmdV.Click, cmdW.Click, cmdX.Click, cmdY.Click, cmdZ.Click
            Session("letter") = CType(sender, LinkButton).Text
            tblEmp.SelectedIndex = -1
            tblEmp.PageIndex = 0
            DataRefresh(Session("letter"))
        End Sub
        Private Sub EnableAll(Optional ByVal pState As Boolean = False)
            cmdA.Visible = pState : cmdB.Visible = pState : cmdC.Visible = pState : cmdD.Visible = pState
            cmdE.Visible = pState : cmdF.Visible = pState : cmdG.Visible = pState : cmdH.Visible = pState
            cmdI.Visible = pState : cmdJ.Visible = pState : cmdK.Visible = pState : cmdL.Visible = pState
            cmdM.Visible = pState : cmdN.Visible = pState : cmdO.Visible = pState : cmdP.Visible = pState
            cmdQ.Visible = pState : cmdR.Visible = pState : cmdS.Visible = pState : cmdT.Visible = pState
            cmdU.Visible = pState : cmdV.Visible = pState : cmdW.Visible = pState : cmdX.Visible = pState
            cmdY.Visible = pState : cmdZ.Visible = pState
        End Sub

        Private Sub ClearPersonal()
            Me.txtSkills.Text = ""
            Me.txttraining.Text = ""
            Me.txtHeight.Text = ""
            Me.txtWeight.Text = ""
            Me.txtFatherFName.Text = ""
            Me.txtFatherLName.Text = ""
            Me.txtFatherMName.Text = ""
            Me.txtMotherFName.Text = ""
            Me.txtMotherLName.Text = ""
            Me.txtMotherMName.Text = ""
            Me.txtSpouseLocalAddr.Text = ""
            Me.txtSpouseEmployer.Text = ""
            Me.txtSpouseLName.Text = ""
            Me.txtSpouseFName.Text = ""
            Me.txtSpouseMName.Text = ""
            Me.txtSpouseOccupation.Text = ""
            Me.txtSpouseTel.Text = ""
            Me.txtOtherInfo.Text = ""
            Me.txtFatherBday.Text = ""
            Me.txtMotherBday.Text = ""
            Me.txtFatherContacts.Text = ""
            Me.txtMotherContacts.Text = ""
            Me.txtFatherOccupation.Text = ""
            Me.txtMotherOccupation.Text = ""
            Me.txtFatherRemarks.Text = ""
            Me.txtMotherRemarks.Text = ""
            Me.txtFatherDeathCause.Text = ""
            Me.txtMotherDeathCause.Text = ""
            Me.txtMotherAddress.Text = ""
            Me.txtFatherAddress.Text = ""
            Me.txtRegion.Text = ""
            Me.txtCity.Text = ""
            Me.txtProvince.Text = ""
            Me.txtZip.Text = ""
            Me.txtMacOprtd.Text = ""
        End Sub

        Private Sub RefreshPersonal(ByVal pID As String)
            ClearPersonal()
            Dim c As New SqlClient.SqlConnection
            Dim cmd As New SqlClient.SqlCommand
            Dim dr As SqlClient.SqlDataReader
            Dim vDialect As String = ""
            Dim vLang As String = ""
            Dim vSkills As String = ""
            Dim DialectArr() As String
            Dim LangArr() As String
            Dim SkillsArr() As String
            Dim i As Integer = 0

            c.ConnectionString = connStr
            c.Open()
            cmd.Connection = c

            cmd.CommandText = "SELECT * FROM py_emp_master WHERE Emp_Cd = '" & pID & "'"
            dr = cmd.ExecuteReader
            If dr.Read Then
                If (Session("userlevel") = "1" And dr("EmploymentType") = "CON") Or _
                                    dr("EmploymentType") <> "CON" Then
                    'Me.txtSkills.Text = IIf(IsDBNull(dr("Skills")), "", dr("Skills"))

                    If Not IsDBNull(dr("Skills")) Then
                        vSkills = dr("Skills")
                        SkillsArr = vSkills.Split(",")

                        For i = 0 To UBound(SkillsArr)
                            Me.txtSkills.Text += GetRef("SELECT Descr FROM hr_skills_ref WHERE SkillCd = '" & SkillsArr(i).ToString & "'", SkillsArr(i).ToString) & vbNewLine
                        Next i
                        Me.txtSkills.Text = Me.txtSkills.Text.TrimEnd
                    End If

                    Me.txtMacOprtd.Text = ""
                    Dim aMachines As String()
                    If Not IsDBNull(dr("MacOprtd")) Then
                        aMachines = dr("MacOprtd").ToString.Split(";")
                        For i = 0 To UBound(aMachines)
                            Me.txtMacOprtd.Text += "*" & aMachines(i) & vbNewLine
                        Next
                    End If

                    Me.txttraining.Text = IIf(IsDBNull(dr("Self_Trainings")), "", dr("Self_Trainings"))

                    Me.txtHeight.Text = IIf(IsDBNull(dr("Height")), "0", dr("Height"))
                    Me.txtWeight.Text = IIf(IsDBNull(dr("Weight")), "0", dr("Weight"))
                    lblWeight.Text = Math.Round(Val(txtWeight.Text) * 2.2046226, 2)
                    Dim vFoot As Decimal = Val(txtHeight.Text) * 0.0328   'convert to foot
                    Dim vInch As Decimal = Math.Ceiling((vFoot - Int(vFoot)) * 12)
                    If vInch >= 12 Then
                        vFoot = Int(vFoot) + 1
                        vInch -= 12
                    End If
                    lblFt.Text = Math.Round(Int(vFoot), 0) & "'" & vInch & """"
                    Me.txtFatherFName.Text = IIf(IsDBNull(dr("Father_Fname")), "", dr("Father_Fname"))
                    Me.txtFatherLName.Text = IIf(IsDBNull(dr("Father_Lname")), "", dr("Father_Lname"))
                    Me.txtFatherMName.Text = IIf(IsDBNull(dr("Father_Mname")), "", dr("Father_Mname"))
                    Me.txtMotherFName.Text = IIf(IsDBNull(dr("Mother_Fname")), "", dr("Mother_Fname"))
                    Me.txtMotherLName.Text = IIf(IsDBNull(dr("Mother_Lname")), "", dr("Mother_Lname"))
                    Me.txtMotherMName.Text = IIf(IsDBNull(dr("Mother_Mname")), "", dr("Mother_Mname"))
                    Me.txtSpouseBusAddress.Text = IIf(IsDBNull(dr("Spouse_Bus_Addr")), "", dr("Spouse_Bus_Addr"))
                    Me.txtSpouseLocalAddr.Text = IIf(IsDBNull(dr("SpouseAddress")), "", dr("SpouseAddress"))
                    Me.txtSpouseProvAddress.Text = IIf(IsDBNull(dr("SpouseProvAddress")), "", dr("SpouseProvAddress"))
                    Me.txtSpouseEmployer.Text = IIf(IsDBNull(dr("Spouse_Emr")), "", dr("Spouse_Emr"))
                    Me.txtSpouseLName.Text = IIf(IsDBNull(dr("Spouse_Lname")), "", dr("Spouse_Lname"))
                    Me.txtSpouseFName.Text = IIf(IsDBNull(dr("Spouse_Fname")), "", dr("Spouse_Fname"))
                    Me.txtSpouseMName.Text = IIf(IsDBNull(dr("Spouse_Mname")), "", dr("Spouse_Mname"))
                    Me.txtSpouseOccupation.Text = IIf(IsDBNull(dr("Spouse_Occupation")), "", dr("Spouse_Occupation"))
                    Me.txtSpouseTel.Text = IIf(IsDBNull(dr("Spouse_Tel")), "", dr("Spouse_Tel"))
                    Me.txtOtherInfo.Text = IIf(IsDBNull(dr("OtherInfo")), "", dr("OtherInfo"))

                    txtFatherBday.Text = ""
                    If Not IsDBNull(dr("FatherBday")) Then
                        txtFatherBday.Text = Format(dr("FatherBday"), "MM/dd/yyyy")
                    End If
                    Me.txtMotherBday.Text = ""
                    If Not IsDBNull(dr("MotherBday")) Then
                        Me.txtMotherBday.Text = Format(dr("MotherBday"), "MM/dd/yyyy")
                    End If
                    Me.txtFatherContacts.Text = IIf(IsDBNull(dr("FatherContact")), "", dr("FatherContact"))
                    Me.txtMotherContacts.Text = IIf(IsDBNull(dr("MotherContact")), "", dr("MotherContact"))
                    Me.txtFatherOccupation.Text = IIf(IsDBNull(dr("FatherOcc")), "", dr("FatherOcc"))
                    Me.txtMotherOccupation.Text = IIf(IsDBNull(dr("MotherOcc")), "", dr("MotherOcc"))
                    Me.txtFatherRemarks.Text = ""
                    Me.txtMotherRemarks.Text = ""
                    Me.txtFatherDeathCause.Text = ""
                    Me.txtMotherDeathCause.Text = ""
                    Me.txtFatherRemarks.Text = ""
                    If Not IsDBNull(dr("FatherAlive")) Then
                        If dr("FatherAlive") = 1 Then
                            Me.txtFatherRemarks.Text = "Deceased"
                            Me.txtFatherDeathCause.Text = IIf(IsDBNull(dr("FatherDeathCause")), "", dr("FatherDeathCause"))
                        Else
                            Me.txtFatherRemarks.Text = "Alive"
                        End If
                    End If
                    Me.txtMotherRemarks.Text = ""
                    If Not IsDBNull(dr("MotherAlive")) Then
                        If dr("MotherAlive") = 1 Then
                            Me.txtMotherRemarks.Text = "Deceased"
                            Me.txtMotherDeathCause.Text = IIf(IsDBNull(dr("MotherDeathCause")), "", dr("MotherDeathCause"))
                        Else
                            Me.txtMotherRemarks.Text = "Alive"
                        End If
                    End If
                    Me.txtMotherAddress.Text = IIf(IsDBNull(dr("MotherAddress")), "", dr("MotherAddress"))
                    Me.txtFatherAddress.Text = IIf(IsDBNull(dr("FatherAddress")), "", dr("FatherAddress"))

                    Me.txtEmrgncyName.Text = IIf(IsDBNull(dr("EmergencyContactPerson")), "", dr("EmergencyContactPerson"))
                    Me.txtEmrgncyContact.Text = IIf(IsDBNull(dr("EmergencyContactNo")), "", dr("EmergencyContactNo"))
                    Me.txtEmgrncyRelation.Text = IIf(IsDBNull(dr("EmergencyRelation")), "", dr("EmergencyRelation"))
                    Me.txtEmrgncyEmail.Text = IIf(IsDBNull(dr("EmergencyEmail")), "", dr("EmergencyEmail"))
                    Me.txtEmrgncyAddress.Text = IIf(IsDBNull(dr("EmergencyAddress")), "", dr("EmergencyAddress"))

                    Me.txtEyeColor.Text = IIf(IsDBNull(dr("EyeColor")), "", dr("EyeColor"))
                    Me.txtHairColor.Text = IIf(IsDBNull(dr("HairColor")), "", dr("HairColor"))
                    Me.txtDistingMark.Text = IIf(IsDBNull(dr("DistingMark")), "", dr("DistingMark"))
                    Me.txtNoofChild.Text = IIf(IsDBNull(dr("ChildrenNo")), 0, dr("ChildrenNo"))

                    Me.txtRegion.Text = GetRef("region_ref", "Descr", "RegionCd", IIf(IsDBNull(dr("RegionCd")), "", dr("RegionCd")))
                    Me.txtCity.Text = GetRef("City_ref", "Descr", "CityCd", IIf(IsDBNull(dr("City")), "", dr("City")))
                    Me.txtProvince.Text = GetRef("province_ref", "Descr", "ProvCd", IIf(IsDBNull(dr("ProvCd")), "", dr("ProvCd")))
                    Me.txtZip.Text = GetRef("Zip_ref", "AreaNM", "ZipCd", IIf(IsDBNull(dr("Zip")), "", dr("Zip")))

                    'lblAppCountry.Text = GetRef("hr_country_ref", "Descr", "CountryCd", IIf(IsDBNull(rs("CountryCd")), "", rs("CountryCd")))
                    'lblTaxCode.Text = GetRef("py_tax_ref", "Descr", "Tax_Cd", IIf(IsDBNull(rs("TaxCd")), "", rs("TaxCd")))
                    'lblDialectSpoken.Text = ""


                    BuildCombo("SELECT CountryCd, Descr FROM hr_country_ref WHERE CountryCd = '" & dr("CountryCd") & "'", cmbCountry)
                    BuildCombo("SELECT REligionCd, Descr FROM hr_religion_ref WHERE ReligionCd = '" & dr("ReligionCd") & "'", cmbReligion)
                    BuildCombo("SELECT BloodType, Descr FROM hr_bloodtype_ref WHERE BloodType = '" & dr("BloodType") & "'", cmbBloodType)
                    BuildCombo("SELECT Citizen_Cd, Descr FROM hr_citizenship_ref WHERE Citizen_Cd = '" & dr("CitizenCd") & "'", cmbCitizenship)

                    Me.txtDialect.Text = ""
                    Me.txtLang.Text = ""

                    If Not IsDBNull(dr("DialectCd")) Then
                        vDialect = dr("DialectCd")
                        DialectArr = vDialect.Split(",")

                        For i = 0 To UBound(DialectArr)
                            Me.txtDialect.Text += GetRef("SELECT Descr FROM hr_dialect_ref WHERE DialectCd = '" & DialectArr(i).ToString & "'", DialectArr(i).ToString) & vbNewLine
                        Next i

                        Me.txtDialect.Text = Me.txtDialect.Text.TrimEnd
                    End If

                    If Not IsDBNull(dr("LanguageCd")) Then
                        vLang = dr("LanguageCd")
                        LangArr = vLang.Split(",")

                        For i = 0 To UBound(LangArr)
                            Me.txtLang.Text += GetRef("SELECT Descr FROM hr_language_ref WHERE LanguageCd = '" & LangArr(i).ToString & "'", LangArr(i).ToString) & vbNewLine
                        Next i
                        Me.txtLang.Text = Me.txtLang.Text.TrimEnd
                    End If
                Else
                    Me.txtDialect.Text = "RESTRICTED"
                    Me.txtLang.Text = "RESTRICTED"
                    Me.txtSkills.Text = "RESTRICTED"
                    Me.txttraining.Text = "RESTRICTED"
                    Me.txtHeight.Text = "RESTRICTED"
                    Me.txtWeight.Text = "RESTRICTED"
                    Me.txtFatherFName.Text = "RESTRICTED"
                    Me.txtFatherLName.Text = "RESTRICTED"
                    Me.txtFatherMName.Text = "RESTRICTED"
                    Me.txtMotherFName.Text = "RESTRICTED"
                    Me.txtMotherLName.Text = "RESTRICTED"
                    Me.txtMotherMName.Text = "RESTRICTED"
                    Me.txtSpouseLocalAddr.Text = "RESTRICTED"
                    Me.txtSpouseBusAddress.Text = "RESTRICTED"
                    Me.txtSpouseLocalAddr.Text = "RESTRICTED"
                    Me.txtSpouseProvAddress.Text = "RESTRICTED"
                    Me.txtSpouseEmployer.Text = "RESTRICTED"
                    Me.txtSpouseLName.Text = "RESTRICTED"
                    Me.txtSpouseFName.Text = "RESTRICTED"
                    Me.txtSpouseMName.Text = "RESTRICTED"
                    Me.txtSpouseOccupation.Text = "RESTRICTED"
                    Me.txtSpouseTel.Text = "RESTRICTED"
                    Me.txtOtherInfo.Text = "RESTRICTED"
                    Me.txtFatherBday.Text = "RESTRICTED"
                    Me.txtMotherBday.Text = "RESTRICTED"
                    Me.txtFatherContacts.Text = "RESTRICTED"
                    Me.txtMotherContacts.Text = "RESTRICTED"
                    Me.txtFatherOccupation.Text = "RESTRICTED"
                    Me.txtMotherOccupation.Text = "RESTRICTED"
                    Me.txtFatherRemarks.Text = "RESTRICTED"
                    Me.txtMotherRemarks.Text = "RESTRICTED"
                    Me.txtFatherDeathCause.Text = "RESTRICTED"
                    Me.txtMotherDeathCause.Text = "RESTRICTED"
                    Me.txtMotherAddress.Text = "RESTRICTED"
                    Me.txtFatherAddress.Text = "RESTRICTED"
                    Me.txtEmrgncyName.Text = "RESTRICTED"
                    Me.txtEmrgncyContact.Text = "RESTRICTED"
                    Me.txtEmgrncyRelation.Text = "RESTRICTED"
                    Me.txtEmrgncyEmail.Text = "RESTRICTED"
                    Me.txtEmrgncyAddress.Text = "RESTRICTED"
                    Me.txtHairColor.Text = "RESTRICTED"
                    Me.txtDistingMark.Text = "RESTRICTED"
                    Me.txtEyeColor.Text = "RESTRICTED"
                    Me.txtNoofChild.Text = "RESTRICTED"
                    Me.txtRegion.Text = "RESTRICTED"
                    Me.txtCity.Text = "RESTRICTED"
                    Me.txtProvince.Text = "RESTRICTED"
                    Me.txtZip.Text = "RESTRICTED"
                    Me.txtMacOprtd.Text = "RESTRICTED"
                End If
            End If

            dr.Close()
            c.Close()
            c.Dispose()
            cmd.Dispose()
        End Sub
        Private Sub RefreshDep(ByVal pID As String)
            Dim c As New SqlClient.SqlConnection
            Dim da As SqlClient.SqlDataAdapter
            Dim ds As New DataSet

            c.ConnectionString = connStr
            da = New SqlClient.SqlDataAdapter("select SeqId,DependentName,Sex as Gender,Relationship," & _
                                              "CAST(Bday AS DATETIME) AS Bday,Bplace,Emp_Cd, HMO_Mem, HMO_Age from hr_dependents where Emp_Cd='" & _
                                              pID & "' and rel_type='dependents'", c)
            'cm.CommandText = "Select Application_No,SeqId,Dependent_Name,Relation,Sex,Birth_Date,PlaceofBirth," & _
            '                     "Address from hr_emp_tmp_dependents where Application_No='" & Session("id") & _
            '                     "' and rel_type='dependents' order by SeqId asc"
            'rs = cm.ExecuteReader
            'Dim age As Integer = 0
            'Do While rs.Read
            '    age = 0
            '    If Not IsDBNull(rs("Birth_Date")) Then
            '        age = Math.Floor(DateDiff(DateInterval.Month, rs("Birth_Date"), Now) / 12)
            '        vDepInfo += "<tr>" & _
            '                    "<td style='font-size: 12px; padding: 2px;' align='center'>" & rs("Dependent_Name") & "</td>" & _
            '                    "<td style='font-size: 12px; padding: 2px;' align='center'>" & rs("Sex") & "</td>" & _
            '                    "<td style='font-size: 12px; padding: 2px;' align='center'>" & rs("Relation") & "</td>" & _
            '                    "<td style='font-size: 12px; padding: 2px;' align='center'>" & rs("Birth_Date") & "</td>" & _
            '                    "<td style='font-size: 12px; padding: 2px;' align='center'>" & rs("PlaceofBirth") & "</td>" & _
            '                    "<td style='font-size: 12px; padding: 2px;' align='center'>" & age & "</td>" & _
            '                "</tr>"
            '    End If
            'Loop

            da.Fill(ds, "dep")
            tblDep.DataSource = ds.Tables("dep")
            tblDep.DataBind()
            ds.Dispose()
            da.Dispose()
            c.Dispose()

            If tblDep.Rows.Count > 0 Then
                cmdEditdep.Enabled = True
                cmdDelDep.Enabled = True
                cmdPrintdep.Enabled = True
            Else
                cmdEditdep.Enabled = False
                cmdDelDep.Enabled = False
                cmdPrintdep.Enabled = False
            End If
        End Sub
        Private Sub RefreshSib(ByVal pID As String)
            Dim c As New SqlClient.SqlConnection
            Dim da As SqlClient.SqlDataAdapter
            Dim ds As New DataSet

            c.ConnectionString = connStr
            da = New SqlClient.SqlDataAdapter("select SeqId,DependentName,Sex as Gender,Relationship," & _
                                              "CAST(Bday AS DATETIME) AS Bday,Bplace,Emp_Cd, " & _
                                              "Position,School,Tel " & _
                                              "from hr_dependents where Emp_Cd='" & pID & "' and rel_type='sibling'", c)


            da.Fill(ds, "sib")
            tblEmpSib.DataSource = ds.Tables("sib")
            tblEmpSib.DataBind()
            ds.Dispose()
            da.Dispose()
            c.Dispose()
            If tblEmpSib.Rows.Count > 0 Then
                'cmdEditdep.Enabled = True
                'cmdDelDep.Enabled = True
                'cmdPrintdep.Enabled = True
                cmdEditSibling.Enabled = True
                cmdDelSibling.Enabled = True
            Else
                'cmdEditdep.Enabled = False
                'cmdDelDep.Enabled = False
                'cmdPrintdep.Enabled = False
                cmdEditSibling.Enabled = False
                cmdDelSibling.Enabled = False
            End If
        End Sub
        Private Sub RefreshRel(ByVal pID As String)
            Dim c As New SqlClient.SqlConnection
            Dim da As SqlClient.SqlDataAdapter
            Dim ds As New DataSet

            c.ConnectionString = connStr
            da = New SqlClient.SqlDataAdapter("select SeqId,DependentName,Sex as Gender,Relationship," & _
                                              "CAST(Bday AS DATETIME) AS Bday,Bplace,Emp_Cd," & _
                                              "Position,Tel from hr_dependents where Emp_Cd='" & pID & "' and rel_type='relatives'", c)


            da.Fill(ds, "rel")
            tblrel.DataSource = ds.Tables("rel")
            tblrel.DataBind()
            ds.Dispose()
            da.Dispose()
            c.Dispose()
            If tblrel.Rows.Count > 0 Then
                'cmdEditdep.Enabled = True
                'cmdDelDep.Enabled = True
                'cmdPrintdep.Enabled = True
                cmdEditRel.Enabled = True
                cmdDelRel.Enabled = True
            Else
                'cmdEditdep.Enabled = False
                'cmdDelDep.Enabled = False
                'cmdPrintdep.Enabled = False
                cmdEditRel.Enabled = False
                cmdDelRel.Enabled = False
            End If
        End Sub
        Private Sub RefreshLic(ByVal pID As String)
            Dim c As New SqlClient.SqlConnection
            Dim da As SqlClient.SqlDataAdapter
            Dim ds As New DataSet

            c.ConnectionString = connStr
            da = New SqlClient.SqlDataAdapter("select Date_Issued as DateIssued," & _
                "License_No,LicenseName,CAST(Exp_Date AS DATETIME) as ExpDate, " & _
                "Score,Place_Exam,CAST(Date_Exam AS DATETIME) as Date_Exam,Remarks from " & _
                "hr_emp_license_ref where Emp_Cd='" & pID & "'", c)

            da.Fill(ds, "ref")
            tblLicense.DataSource = ds.Tables("ref")
            tblLicense.DataBind()
            ds.Dispose()
            da.Dispose()
            c.Dispose()

            If tblLicense.Rows.Count > 0 Then
                cmdEditLic.Enabled = True
                cmdDelLic.Enabled = True
                cmdPrintLic.Enabled = True
                cmdViewLic.Enabled = True
            Else
                cmdEditLic.Enabled = False
                cmdDelLic.Enabled = False
                cmdPrintLic.Enabled = False
                cmdViewLic.Enabled = False
            End If
        End Sub
        Private Sub RefreshHist(ByVal pID As String)
            Dim c As New SqlClient.SqlConnection
            Dim da As SqlClient.SqlDataAdapter
            Dim ds As New DataSet

            c.ConnectionString = connStr
            da = New SqlClient.SqlDataAdapter("select From_Date as FromDate," & _
                "To_Date as ToDate,Employer,Position,Nature,Annual_Salary," & _
                "[Function],Accomplishments,Address,EmployerNo,Supervisor,Reasonforleaving from " & _
                "hr_emp_employment_hist where Emp_Id='" & pID & "'", c)
            da.Fill(ds, "ref")
            tblEmpHist.DataSource = ds.Tables("ref")
            tblEmpHist.DataBind()
            ds.Dispose()
            da.Dispose()
            c.Dispose()

            If tblEmpHist.Rows.Count > 0 Then
                cmdEditHist.Enabled = True
                cmdDelHist.Enabled = True
                cmdPrintHist.Enabled = True
                cmdViewHist.Enabled = True
            Else
                cmdEditHist.Enabled = False
                cmdDelHist.Enabled = False
                cmdPrintHist.Enabled = False
                cmdViewHist.Enabled = False
            End If
        End Sub
        Private Sub RefreshSchool(ByVal pID As String)
            Dim c As New SqlClient.SqlConnection
            Dim da As SqlClient.SqlDataAdapter
            Dim ds As New DataSet

            c.ConnectionString = connStr
            da = New sqlclient.sqldataadapter("select From_Date as FromDate," & _
                "To_Date as ToDate,Type,School,Course,Final_Grade,School_Address " & _
                "from hr_emp_scholastic where Emp_Cd='" & pID & "'", c)
            da.Fill(ds, "ref")
            tblSchool.DataSource = ds.Tables("ref")
            tblSchool.DataBind()
            ds.Dispose()
            da.Dispose()
            c.Dispose()

            If tblSchool.Rows.Count > 0 Then
                cmdEditSchool.Enabled = True
                cmdDelSchool.Enabled = True
                cmdPrintSchool.Enabled = True
                cmdViewSchool.Enabled = True
            Else
                cmdEditSchool.Enabled = False
                cmdDelSchool.Enabled = False
                cmdPrintSchool.Enabled = False
                cmdViewSchool.Enabled = False
            End If
        End Sub

        Private Sub RefreshAccountability(ByVal pID As String)
            Dim c As New SqlClient.SqlConnection
            Dim da As SqlClient.SqlDataAdapter
            Dim ds As New DataSet

            c.ConnectionString = connStr
            da = New SqlClient.SqlDataAdapter("select StockCd,DateReleased,Reason,DateAssigned,ExpiryDate,DateReturned " & _
                    " from fa_accountability_hist where Emp_Cd='" & pID & "'", c)


            'da = New SqlClient.SqlDataAdapter("select StockCd,DateReleased,Reason,DateAssigned,ExpiryDate,DateReturned," & _
            '        "(select ItemName from item where ItemCd=StockCd) as ItemName from fa_accountability_hist where Emp_Cd='" & pID & "'", c)

            da.Fill(ds, "accountability")
            tblAccountability.DataSource = ds.Tables("accountability")
            tblAccountability.DataBind()
            ds.Dispose()
            da.Dispose()
            c.Dispose()

            If tblAccountability.Rows.Count > 0 Then
                cmdEditAsset.Enabled = True
                cmdDeleteAsset.Enabled = True
                cmdPrintAsset.Enabled = True
            Else
                cmdEditAsset.Enabled = False
                cmdDeleteAsset.Enabled = False
                cmdPrintAsset.Enabled = False
            End If
        End Sub
        Private Sub RefreshLeave(ByVal pID As String)
            Dim c As New SqlClient.SqlConnection
            Dim da As SqlClient.SqlDataAdapter
            Dim ds As New DataSet

            c.ConnectionString = connStr
            da = New SqlClient.SqlDataAdapter("select * from py_emp_leave where Emp_Cd='" & pID & "'", c)
            da.Fill(ds, "ref")
            tblLeave.DataSource = ds.Tables("ref")
            tblLeave.DataBind()
            ds.Dispose()
            da.Dispose()
            c.Dispose()

            If tblLeave.Rows.Count > 0 Then
                cmdEditLeave.Enabled = True
                cmdDelLeave.Enabled = True
                cmdPrintLeave.Enabled = True
            Else
                cmdEditLeave.Enabled = False
                cmdDelLeave.Enabled = False
                cmdPrintLeave.Enabled = False
            End If
        End Sub
        Private Sub RefreshViolateCommend(ByVal pID As String, ByVal pType As String)
            Dim c As New SqlClient.SqlConnection
            Dim da As SqlClient.SqlDataAdapter
            Dim ds As New DataSet

            c.ConnectionString = connStr
            da = New sqlclient.sqldataadapter("select Event_Date as EventDate," & _
                "Event,Actions,Remarks from hr_emp_violate_commend where Emp_Id='" & pID & _
                "' and Event_Type='" & pType & "'", c)
            da.Fill(ds, "ref")
            tblViolateCommend.DataSource = ds.Tables("ref")
            tblViolateCommend.DataBind()
            ds.Dispose()
            da.Dispose()
            c.Dispose()

            If tblViolateCommend.Rows.Count > 0 Then
                cmdEditViolateCommend.Enabled = True
                cmdDelViolateCommend.Enabled = True
                cmdPrintViolateCommend.Enabled = True
            Else
                cmdEditViolateCommend.Enabled = False
                cmdDelViolateCommend.Enabled = False
                cmdPrintViolateCommend.Enabled = False
            End If
            If pType = "violate" Then
                cmdAddViolateCommend.Text = "Add Violation"
                cmdEditViolateCommend.Text = "Edit Violation"
                cmdDelViolateCommend.Text = "Del Violation"
            Else
                cmdAddViolateCommend.Text = "Add Commendation"
                cmdEditViolateCommend.Text = "Edit Commendation"
                cmdDelViolateCommend.Text = "Del Commendation"
            End If
        End Sub

        Private Sub RefreshTraining(ByVal pID As String)
            Dim c As New SqlClient.SqlConnection
            Dim da As SqlClient.SqlDataAdapter
            Dim ds As New DataSet

            c.ConnectionString = connStr
            da = New SqlClient.SqlDataAdapter("select SeqId,CAST(From_Date AS DATETIME) AS FromDate," & _
                "CAST(To_Date AS DATETIME) AS ToDate,Training_Name,No_Of_Hours,Held,Remarks" & _
                " from hr_emp_training where Emp_Id='" & pID & "'", c)

            da.Fill(ds, "ref")
            tblTraining.DataSource = ds.Tables("ref")
            tblTraining.DataBind()
            ds.Dispose()
            da.Dispose()
            c.Dispose()

            If tblTraining.Rows.Count > 0 Then
                cmdEditTraining.Enabled = True
                cmdDelTraining.Enabled = True
                cmdPrintTraining.Enabled = True
                cmdViewTraining.Enabled = True
            Else
                cmdEditTraining.Enabled = False
                cmdDelTraining.Enabled = False
                cmdPrintTraining.Enabled = False
                cmdViewTraining.Enabled = False
            End If
        End Sub
        Private Sub RefreshCareer(ByVal pID As String)
            Dim c As New SqlClient.SqlConnection
            Dim da As SqlClient.SqlDataAdapter
            Dim ds As New DataSet

            c.ConnectionString = connStr


            vSQL = "select From_Date as FromDate," & _
                "To_Date as ToDate,(select Descr from rc where rc.Rc_Cd=hr_emp_career_movement.Rc_Cd) as Rc_Cd," & _
                "(select AgencyName from agency where AgencyCd=Office_Cd) as Office_Cd," & _
                "(select Descr from hr_div_ref where hr_div_ref.Div_Cd=hr_emp_career_movement.Div_Cd) as Div_Cd," & _
                "(select Descr from hr_dept_ref where hr_dept_ref.Dept_Cd=hr_emp_career_movement.Dept_Cd) as Dept_Cd," & _
                "(select Descr from hr_section_ref where hr_section_ref.Section_Cd=hr_emp_career_movement.Section_Cd) as Section_Cd," & _
                "(select Descr from hr_unit_ref where hr_unit_ref.Unit_Cd=hr_emp_career_movement.Unit_Cd) as Unit_Cd," & _
                "(select Position from py_position_ref where Pos_Cd=Position_Cd) as Position_Cd,Salary_Amt from " & _
                "hr_emp_career_movement where Emp_Cd='" & pID & "' order by From_Date desc"

            'Response.Write(vSQL)
            da = New SqlClient.SqlDataAdapter(vSQL, c)



            da.Fill(ds, "ref")
            tblCareer.DataSource = ds.Tables("ref")
            tblCareer.DataBind()
            ds.Dispose()
            da.Dispose()
            c.Dispose()

            If tblCareer.Rows.Count > 0 Then
                cmdEditCareer.Enabled = True
                cmdDelCareer.Enabled = True
                cmdPrintCareer.Enabled = True
                cmdViewCareer.Enabled = True
            Else
                cmdEditCareer.Enabled = False
                cmdDelCareer.Enabled = False
                cmdPrintCareer.Enabled = False
                cmdViewCareer.Enabled = False
            End If
        End Sub
        Private Sub RefreshRef(ByVal pID As String)
            Dim c As New SqlClient.SqlConnection
            Dim da As SqlClient.SqlDataAdapter
            Dim ds As New DataSet

            c.ConnectionString = connStr
            da = New sqlclient.sqlDataAdapter("select * from hr_emp_reference where Emp_Cd='" & pID & "'", c)
            da.Fill(ds, "ref")
            tblRef.DataSource = ds.Tables("ref")
            tblRef.DataBind()
            ds.Dispose()
            da.Dispose()
            c.Dispose()

            If tblRef.Rows.Count > 0 Then
                cmdEditRef.Enabled = True
                cmdDelRef.Enabled = True
                cmdPrintRef.Enabled = True
            Else
                cmdEditRef.Enabled = False
                cmdDelRef.Enabled = False
                cmdPrintRef.Enabled = False
            End If
        End Sub
        Private Sub RefreshOption(ByVal pID As String)
            Dim c As New SqlClient.SqlConnection
            Dim cmd As New SqlClient.SqlCommand
            Dim dr As sqlclient.sqldatareader

            c.ConnectionString = connStr
            c.Open()
            cmd.Connection = c
            cmd.CommandText = "select * from py_emp_master where Emp_Cd='" & pID & "'"
            dr = cmd.ExecuteReader
            If dr.Read Then
                chkTax.Checked = IIf(IsDBNull(dr("Allow_WithTax")), False, dr("Allow_WithTax"))
                chkSSS.Checked = IIf(IsDBNull(dr("Allow_Sss")), False, dr("Allow_Sss"))
                chkPAGIBIG.Checked = IIf(IsDBNull(dr("Allow_PagIbig")), False, dr("Allow_PagIbig"))
                chkPHIC.Checked = IIf(IsDBNull(dr("Allow_Medicare")), False, dr("Allow_Medicare"))
                chkGSIS.Checked = IIf(IsDBNull(dr("Allow_Retire")), False, dr("Allow_Retire"))
                chkState.Checked = IIf(IsDBNull(dr("Allow_Life")), False, dr("Allow_Life"))
                chkOptional.Checked = IIf(IsDBNull(dr("Allow_Insurance")), False, dr("Allow_Insurance"))
                chkTimesheet.Checked = IIf(IsDBNull(dr("Allow_Reg_Timein")), False, dr("Allow_Reg_Timein") = 0)
                chkRenderHr.Checked = IIf(IsDBNull(dr("Allow_Req_Hrs")), False, dr("Allow_Req_Hrs"))
                chkEarlyOT.Checked = IIf(IsDBNull(dr("Allow_EarlyOt")), False, dr("Allow_EarlyOT") = 1)
                chkBapEnrolled.Checked = IIf(dr("BapEnrolled") = 0, False, True)
                chkUnion.Checked = IIf(dr("Allow_UnionDues") = 0, False, True)
                chkSC.Checked = IIf(dr("SCMember") = 0, False, True)
                txtMaxFlexHrs.Text = dr("MaxFlexHrs")
                chkTax.Text = "Deduct Withholding tax every " & _
                    IIf(dr("TaxFreq") = -1, "[system default]", IIf(dr("TaxFreq") = 0, "payroll", IIf(dr("TaxFreq") = 1, "1st cut off", "2nd cut off")))
                chkSSS.Text = "Deduct SSS Contribution every " & _
                    IIf(dr("SSSFreq") = -1, "[system default]", IIf(dr("SSSFreq") = 0, "payroll", IIf(dr("SSSFreq") = 1, "1st cut off", "2nd cut off")))
                chkPAGIBIG.Text = "Deduct PagIBIG Contribution every " & _
                    IIf(dr("PagIBIGFreq") = -1, "[system default]", IIf(dr("PagIBIGFreq") = 0, "payroll", IIf(dr("PagIBIGFreq") = 1, "1st cut off", "2nd cut off")))
                chkPHIC.Text = " Deduct Philhealth Contribution every " & _
                    IIf(dr("PHICFreq") = -1, "[system default]", IIf(dr("PHICFreq") = 0, "payroll", IIf(dr("PHICFreq") = 1, "1st cut off", "2nd cut off")))
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY:  VIC GATCHALIAN                              ''
                '' DATE MODIFIED: 3/27/2013                                  ''
                '' PURPOSE: TO EXPOSE THE PRE-APPROVED OT HOURS AND          ''
                ''          MULTIPLE OF MINS IN OT FILING                    ''
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                txtPreApprovedOT.Text = dr("AutoApprovedOT")
                txtMultipleMinsOT.Text = dr("OTMultipleMins")
                ''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''
            End If
            dr.Close()
            cmd.Dispose()
            c.Close()
            c.Dispose()
        End Sub
        Private Sub RefreshIdentification(ByVal pID As String)
            Dim c As New SqlClient.SqlConnection
            Dim cmd As New SqlClient.SqlCommand
            Dim dr As sqlclient.sqldatareader

            c.ConnectionString = connStr
            c.Open()
            cmd.Connection = c
            cmd.CommandText = "select * from py_emp_master where Emp_Cd='" & pID & "'"
            dr = cmd.ExecuteReader
            If dr.Read Then
                txtresCert.Text = IIf(IsDBNull(dr("Res_Cert")), "", dr("Res_Cert"))
                txtPlaceIssued.Text = IIf(IsDBNull(dr("ResCertPlaceIssued")), "", dr("ResCertPlaceIssued"))
                txtDateIssued.Text = IIf(IsDBNull(dr("ResCertDateIssued")), "", dr("ResCertDateIssued"))
                txtSSS.Text = IIf(IsDBNull(dr("Sss_No")), "", dr("Sss_No"))
                txtPAGIBIG.Text = IIf(IsDBNull(dr("PagIbig_No")), "", dr("PagIbig_No"))
                txtPHIC.Text = IIf(IsDBNull(dr("PhicNo")), "", dr("PhicNo"))
                txtTIN.Text = IIf(IsDBNull(dr("Tin")), "", dr("Tin"))
                txtGSIS.Text = IIf(IsDBNull(dr("Gsis_No")), "", dr("Gsis_No"))
                txtDateStart.Text = IIf(IsDBNull(dr("Start_Date")), "", dr("Start_Date"))
                txtdateEnd.Text = IIf(IsDBNull(dr("Date_Resign")), "", dr("Date_Resign"))

                txtDateEOC.Text = IIf(IsDBNull(dr("DateDismissed")), "", dr("DateDismissed"))
                txtDateRetired.Text = IIf(IsDBNull(dr("Date_Retired")), "", dr("Date_Retired"))
                txtDateHold.Text = IIf(IsDBNull(dr("DateHold")), "", dr("DateHold"))
                txtDateSuspended.Text = IIf(IsDBNull(dr("DateSuspended")), "", dr("DateSuspended"))
                txtDateRegularized.Text = IIf(IsDBNull(dr("DateRegularized")), "", dr("DateRegularized"))
                txtFixedSSSEmp.Text = IIf(IsDBNull(dr("FixedSss_Emp")), 0, dr("FixedSss_Emp"))
                txtFixedSSSEmr.Text = IIf(IsDBNull(dr("FixedSss_Emr")), 0, dr("FixedSss_Emr"))
                txtFixedPAGIBIGEmp.Text = IIf(IsDBNull(dr("FixedPagIbig_Emp")), 0, dr("FixedPagIbig_Emp"))
                txtFixedPAGIBIGEmr.Text = IIf(IsDBNull(dr("FixedPagIbig_Emr")), 0, dr("FixedPagIbig_Emr"))
                txtFixedPHICEmp.Text = IIf(IsDBNull(dr("FixedHealth_Emp")), 0, dr("FixedHealth_Emp"))
                txtFixedPHICEmr.Text = IIf(IsDBNull(dr("FixedHealth_Emr")), 0, dr("FixedHealth_Emr"))
                txtFixedTax.Text = IIf(IsDBNull(dr("FixedTax")), 0, dr("FixedTax"))
            End If
            dr.Close()
            cmd.Dispose()
            c.Close()
            c.Dispose()
        End Sub
        Private Sub RefreshSalary(ByVal pID As String)
            Dim c As New SqlClient.SqlConnection
            Dim cmd As New SqlClient.SqlCommand
            Dim dr As SqlClient.SqlDataReader

            c.ConnectionString = connStr
            c.Open()
            cmd.Connection = c
            cmd.CommandText = "select * from py_emp_master where Emp_Cd='" & pID & "'"
            dr = cmd.ExecuteReader
            If dr.Read Then
                If Session("userlevel") = "1" Or _
                    (Session("userlevel") <> "1" And dr("Confidential") = 0) Then
                    txtrateYr.Text = Format(IIf(IsDBNull(dr("Rate_Year")), 0, dr("Rate_Year")), "###,##0.00")
                    txtrateMo.Text = Format(IIf(IsDBNull(dr("Rate_Month")), 0, dr("Rate_Month")), "###,##0.00")
                    txtrateDay.Text = Format(IIf(IsDBNull(dr("Rate_Day")), 0, dr("Rate_Day")), "###,##0.00")
                    txtACA.Text = Format(IIf(IsDBNull(dr("Aca")), 0, dr("Aca")), "###,##0.00")
                    txtrATA.Text = Format(IIf(IsDBNull(dr("Rata")), 0, dr("Rata")), "###,##0.00")
                    txtPERA.Text = Format(IIf(IsDBNull(dr("Pera")), 0, dr("Pera")), "###,##0.00")
                    txtMeal.Text = Format(IIf(IsDBNull(dr("MealAllow")), 0, dr("MealAllow")), "###,##0.00")
                    txtGrade.Text = IIf(IsDBNull(dr("Grade_Cd")), "", GetRef("select Descr from py_grade where Grade_Cd='" & dr("Grade_Cd") & "'", dr("Grade_Cd")))
                    txtAcct.Text = IIf(IsDBNull(dr("Acct_No")), "", dr("Acct_No"))
                    txtType.Text = IIf(IsDBNull(dr("Bank_Type")), "", dr("Bank_Type"))
                    txtBranch.Text = IIf(IsDBNull(dr("Bank_Code")), "", dr("Bank_Code"))
                    
                    vSalaryOtherInfo = "<tr>" & _
                    "<td class='labelR'>Basic Salary :</td><td class='labelC'>" & dr("SalarySrcCurrCd") & "</td><td class='labelC'>" & dr("SalaryTargetCurrCd") & "</td><tr>" & _
                    "<tr><td class='labelR'>COLA :</td><td class='labelC'>" & dr("AcaSrcCurrCd") & "</td><td class='labelC'>" & dr("AcaTargetCurrCd") & "</td><tr>" & _
                    "<tr><td class='labelR'>BTA :</td><td class='labelC'>" & dr("PeraSrcCurrCd") & "</td><td class='labelC'>" & dr("PeraTargetCurrCd") & "</td><tr>" & _
                    "<tr><td class='labelR'>RATA :</td><td class='labelC'>" & dr("RataSrcCurrCd") & "</td><td class='labelC'>" & dr("RataTargetCurrCd") & "</td><tr>" & _
                    "<tr><td class='labelR'>Meal Allowance :</td><td class='labelC'>" & dr("MealSrcCurrCd") & "</td><td class='labelC'>" & dr("MealTargetCurrCd") & "</td><tr>" & _
                    "<tr><td class='labelR'>Senior Allowance :</td><td class='labelC'>" & dr("SeniorAllowSrcCurrCd") & "</td><td class='labelC'>" & dr("SeniorAllowTargetCurrCd") & "</td><tr>" & _
                    "<tr><td class='labelR'>Tax :</td><td class='labelC'></td><td class='labelC'>" & dr("TaxCurrCd") & "</td><tr>" & _
                    "<tr><td class='labelR'>SSS :</td><td class='labelC'></td><td class='labelC'>" & dr("SssCurrCd") & "</td><tr>" & _
                    "<tr><td class='labelR'>PagIBIG :</td><td class='labelC'></td><td class='labelC'>" & dr("PagIbigCurrCd") & "</td><tr>" & _
                    "<tr><td class='labelR'>PHIC :</td><td class='labelC'></td><td class='labelC'>" & dr("PHICCurrCd") & "</td><tr>" & _
                    "<tr><td class='labelR'>Union Dues :</td><td class='labelC'></td><td class='labelC'>" & dr("UnionDuesCurrCd") & "</td></tr>"

                Else
                    txtrateYr.Text = "RESTRICTED"
                    txtrateMo.Text = "RESTRICTED"
                    txtrateDay.Text = "RESTRICTED"
                    txtACA.Text = "RESTRICTED"
                    txtrATA.Text = "RESTRICTED"
                    txtPERA.Text = "RESTRICTED"
                    txtMeal.Text = "RESTRICTED"
                    txtGrade.Text = "RESTRICTED"
                    txtAcct.Text = "RESTRICTED"
                    txtType.Text = "RESTRICTED"
                    txtBranch.Text = "RESTRICTED"
                End If

                txtreqHrs.Text = IIf(IsDBNull(dr("Req_Hrs_Day")), 8, dr("Req_Hrs_Day"))
                txtPosition.Text = GetRef("select Position from py_position_ref where Pos_Cd='" & dr("Pos_Cd") & "'", dr("Pos_Cd"), c)
                txtTax.Text = IIf(IsDBNull(dr("Tax_Cd")), "", GetRef("select Descr from py_tax_ref where Tax_Cd='" & dr("Tax_Cd") & "'", dr("Tax_Cd"), c))
                txtStatus.Text = IIf(IsDBNull(dr("Emp_Status")), "", dr("Emp_Status"))
                txtPayCd.Text = IIf(IsDBNull(dr("Pay_Cd")), "", GetRef("select Payment from py_pay_mode where Pay_Cd='" & dr("Pay_Cd") & "'", dr("Pay_Cd"), c))
                txtempType.Text = IIf(IsDBNull(dr("Emp_Status")), "", GetRef("SELECT Descr FROM py_employee_stat WHERE Status_Code = '" & dr("Emp_Status") & "'", dr("Emp_Status"), c))
                txtDateHired.Text = IIf(IsDBNull(dr("Start_Date")), "", dr("Start_Date"))
                txtRegularized.Text = IIf(IsDBNull(dr("DateRegularized")), "", dr("DateRegularized"))
                txtGrace.Text = dr("GracePeriod")
                chkCumulative.Checked = dr("CumulativeGrace") = 1
            End If
            dr.Close()
            cmd.Dispose()
            c.Close()
            c.Dispose()
        End Sub
        Private Sub RefreshGeneral(ByVal pID As String)
            Dim c As New SqlClient.SqlConnection
            Dim cmd As New SqlClient.SqlCommand
            Dim dr As SqlClient.SqlDataReader
            c.ConnectionString = connStr
            c.Open()
            cmd.Connection = c

            cmd.CommandText = "select * from py_emp_master where Emp_Cd='" & pID & "'"
            dr = cmd.ExecuteReader
            If dr.Read Then
                txtSupervisor.Text = IIf(IsDBNull(dr("SupervisorCd")), "", dr("SupervisorCd"))
                txtNoting.Text = IIf(IsDBNull(dr("Noting")), "", dr("Noting"))
                txtApproving.Text = IIf(IsDBNull(dr("Approving")), "", dr("Approving"))
                txtCivil.Text = IIf(IsDBNull(dr("Civil_Cd")), "", dr("Civil_Cd"))
                txtContact.Text = IIf(IsDBNull(dr("Emp_Tel")), "", dr("Emp_Tel"))
                txtemail.Text = IIf(IsDBNull(dr("Emp_Email")), "", dr("Emp_Email"))
                txtAddr.Text = IIf(IsDBNull(dr("Emp_Address")), "", dr("Emp_Address"))
                txtBarcode.Text = IIf(IsDBNull(dr("BarcodeId")), "", dr("BarcodeId"))
                txtSex.Text = IIf(dr("Male") = 1, "Male", "Female")
                txtMobileNumber.Text = IIf(IsDBNull(dr("MobileNo")), "", dr("MobileNo"))
                txtBDate.Text = ""
                If Not IsDBNull(dr("Bday")) Then
                    txtBDate.Text = dr("Bday")
                    If IsDate(dr("Bday")) Then
                        txtAge.Text = DateDiff(DateInterval.Year, CDate(dr("Bday")), Now())
                        If CDate(dr("Bday")).Month > Now.Month Then
                            txtAge.Text = Val(txtAge.Text) - 1
                        Else
                            If CDate(dr("Bday")).Month >= Now.Month Then
                                If CDate(dr("Bday")).Day > Now.Day Then
                                    txtAge.Text = Val(txtAge.Text) - 1
                                End If
                            End If

                        End If
                    End If
                End If
                txtUID.Text = IIf(IsDBNull(dr("User_Id")), "", dr("User_Id"))
                txtNick.Text = IIf(IsDBNull(dr("NickName")), "", dr("NickName"))
                txtRank.Text = IIf(IsDBNull(dr("EmploymentType")), "", GetRef("select Descr from hr_employment_type where EmploymentType='" & dr("EmploymentType") & "' ", dr("EmploymentType")))
                'txtLocal.Text = IIf(IsDBNull(dr("DeptCd")), "99", dr("DeptCd"))
                txtRegularized.Text = ""
                If Not IsDBNull(dr("DateRegularized")) Then
                    txtRegularized.Text = IIf(IsDate(dr("DateRegularized")), dr("DateRegularized"), "")
                End If

                If Not IsDBNull(dr("Start_Date")) Then
                    txtDateHired.Text = IIf(IsDate(dr("Start_Date")), dr("Start_Date"), "")
                End If

                txtRC.Text = GetRef("select Descr from rc where Rc_Cd='" & dr("Rc_Cd") & "'", dr("Rc_Cd"))
                txtAgency.Text = GetRef("select AgencyName from agency where AgencyCd='" & dr("Agency_Cd") & "'", dr("Agency_Cd"))
                txtDivision.Text = GetRef("select Descr from hr_div_ref where Div_Cd='" & dr("DivCd") & "'", dr("DivCd"))
                txtDept.Text = GetRef("select Descr from hr_dept_ref where Dept_Cd='" & dr("DeptCd") & "'", dr("DeptCd"))
                txtSection.Text = GetRef("select Descr from hr_section_ref where Section_Cd='" & dr("SectionCd") & "'", dr("SectionCd"))
                txtUnit.Text = GetRef("select Descr from hr_unit_ref where Unit_Cd='" & dr("UnitCd") & "'", dr("UnitCd"))
                txtDupPos.Text = GetRef("select Position from py_position_ref where Pos_Cd='" & dr("Pos_Cd") & "'", dr("Pos_Cd"))
                Me.txtProvAddress.Text = IIf(IsDBNull(dr("Prov_Address")), "", dr("Prov_Address"))
                If Not IsDBNull(dr("Date_Resign")) Then
                    txtStat.Text = "Resigned"
                ElseIf Not IsDBNull(dr("DateSuspended")) Then
                    txtStat.Text = "Suspended"
                ElseIf Not IsDBNull(dr("Date_Retired")) Then
                    txtStat.Text = "Retired"
                ElseIf Not IsDBNull(dr("DateDismissed")) Then
                    txtStat.Text = "End Of Contract"
                ElseIf Not IsDBNull(dr("DateHold")) Then
                    txtStat.Text = "Hold/Suspended"
                Else
                    txtStat.Text = "Active"
                End If
                'txtRegularized.Text = IIf(IsDBNull(dr("DateRegularized")), "", dr("DateRegularized"))
                If Not IsDBNull(dr("Emp_Status")) Then
                    txtempType.Text = GetRef("SELECT Descr FROM py_employee_stat WHERE Status_Code = '" & dr("Emp_Status") & "'", dr("Emp_Status"))
                Else
                    txtempType.Text = ""
                End If
            End If
            dr.Close()
            cmd.CommandText = "select ContactNos from hr_dept_ref where Dept_Cd='" & txtLocal.Text & "'"
            dr = cmd.ExecuteReader
            If dr.Read Then
                txtLocal.Text = IIf(IsDBNull(dr("ContactNos")), "Unknown", dr("ContactNos"))
            End If
            dr.Close()
            If txtSupervisor.Text <> "" Then
                cmd.CommandText = "select Emp_Lname,Emp_Fname from py_emp_master where Emp_Cd='" & _
                    txtSupervisor.Text & "'"
                dr = cmd.ExecuteReader
                If dr.Read Then
                    txtSupervisor.Text = dr("Emp_Lname") & ", " & dr("Emp_Fname")
                End If
                dr.Close()
            End If

            If txtNoting.Text <> "" Then
                cmd.CommandText = "select Emp_Lname,Emp_Fname from py_emp_master where Emp_Cd='" & _
                    txtNoting.Text & "'"
                dr = cmd.ExecuteReader
                If dr.Read Then
                    txtNoting.Text = dr("Emp_Lname") & ", " & dr("Emp_Fname")
                End If
                dr.Close()
            End If

            If txtApproving.Text <> "" Then
                cmd.CommandText = "select Emp_Lname,Emp_Fname from py_emp_master where Emp_Cd='" & _
                    txtApproving.Text & "'"
                dr = cmd.ExecuteReader
                If dr.Read Then
                    txtApproving.Text = dr("Emp_Lname") & ", " & dr("Emp_Fname")
                End If
                dr.Close()
            End If

            If txtCivil.Text <> "" Then
                cmd.CommandText = "select Descr from py_civil_ref where Civil_Cd='" & txtCivil.Text & "'"
                dr = cmd.ExecuteReader
                If dr.Read Then
                    txtCivil.Text = IIf(IsDBNull(dr("Descr")), "", dr("Descr"))
                End If
                dr.Close()
            End If
            cmd.Dispose()
            c.Close()
            c.Dispose()
        End Sub
        Private Sub ClearGeneral()
            txtContact.Text = ""
            txtemail.Text = ""
            txtAddr.Text = ""
            txtBarcode.Text = ""
            txtSex.Text = ""
            txtBDate.Text = ""
            txtAcct.Text = ""
            txtType.Text = ""
            txtBranch.Text = ""
            txtUID.Text = ""
            txtNick.Text = ""
            txtRank.Text = ""
            txtCivil.Text = ""
            txtSupervisor.Text = ""
            txtProvAddress.Text = ""
            txtMobileNumber.Text = ""
        End Sub
        Private Sub ClearSalary()
            txtRateYr.Text = ""
            txtRateMo.Text = ""
            txtRateDay.Text = ""
            txtReqHrs.Text = ""

            txtACA.Text = ""
            txtRATA.Text = ""
            txtPERA.Text = ""
            txtMeal.Text = ""
            txtPosition.Text = ""

            txtTax.Text = ""
            txtGrade.Text = ""
            txtStatus.Text = ""
            txtPayCd.Text = ""
            txtempType.Text = ""
            txtRegularized.Text = ""
        End Sub
        Private Sub ClearIdentification()
            txtResCert.Text = ""
            txtSSS.Text = ""
            txtPAGIBIG.Text = ""
            txtPHIC.Text = ""
            txtTIN.Text = ""
            txtGSIS.Text = ""
            txtDateStart.Text = ""
            txtDateEnd.Text = ""
            txtFixedSSSEmp.Text = ""
            txtFixedSSSEmr.Text = ""
            txtFixedPAGIBIGEmp.Text = ""
            txtFixedPAGIBIGEmr.Text = ""
            txtFixedPHICEmp.Text = ""
            txtFixedPHICEmr.Text = ""
            txtFixedTax.Text = ""
        End Sub
        Private Sub ClearOption()
            chkTax.Checked = False
            chkSSS.Checked = chkTax.Checked
            chkPAGIBIG.Checked = chkTax.Checked
            chkPHIC.Checked = chkTax.Checked
            chkGSIS.Checked = chkTax.Checked
            chkState.Checked = chkTax.Checked
            chkOptional.Checked = chkTax.Checked
            chkTimesheet.Checked = chkTax.Checked
            chkRenderHr.Checked = chkTax.Checked
        End Sub

        Private Sub cmdReturn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdReturn.Click
            Session.Remove("empid")
            Server.Transfer("main.aspx")
        End Sub

        Private Sub cmdAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdAdd.Click
            Session.Remove("empid")
            If lnkGeneral.Enabled Then
                vScript = "editwin=window.open('empstep1.aspx','empwin','toolbar=no,location=no,width=600,height=500,top=100,left=100');"
            Else
                vScript = "alert('You cannot add new employee because you do not have rights in the General Information Tab. " & _
                    "You should have access to this tab first before you can add new employees.');"
            End If
        End Sub

        Protected Sub cmdPrint_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdPrintEMR.Click
            If tblEmp.SelectedIndex < 0 Then
                vScript = "alert('You must first select an employee.');"
                Exit Sub
            End If
            'Server.Transfer("preview.aspx")
            'Dim cm As New sqlclient.sqlcommand
            Session("id") = Session("empid")
            vScript = "prevwin=window.open('emp_step12.aspx','incentwin','location=no,toolber=no,width=900,height=600,scrollbars=yes');"
            'cm.Dispose()
            'c.Close()
        End Sub

        Protected Sub cmdDelete_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDelete.Click
            If tblEmp.SelectedIndex >= 0 Then
                Dim vId As String = tblEmp.SelectedRow.Cells(0).Text
                Dim c As New SqlClient.SqlConnection
                Dim cm As New SqlClient.SqlCommand
                c.ConnectionString = connStr
                c.Open()
                cm.Connection = c
                cm.CommandText = "delete from py_emp_master where Emp_Cd='" & vId & "'"
                cm.ExecuteNonQuery()
                cm.Dispose()
                c.Close()
                c.Dispose()
                DataRefresh(Session("letter"))
            Else
                vScript = "alert('You must first select an employee.');"
            End If
        End Sub

        Protected Sub cmdDelete_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDelete.Init
            cmdDelete.Attributes.Add("onclick", "return ask();")
        End Sub

        Protected Sub cmdEdit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdEdit.Click
            If tblEmp.SelectedIndex >= 0 Then
                Session("empid") = tblEmp.SelectedRow.Cells(0).Text
                vScript = "editwin=window.open('empstep1.aspx','empwin','toolbar=no,location=no,width=650,height=580,top=10,left=100,scrollbars=no');"
            Else
                vScript = "alert('You must first select an employee.');"
            End If
        End Sub

        Protected Sub cmdEditDep_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdEditdep.Click, cmdEditref.Click, cmdEditLic.Click, _
            cmdEditHist.Click, cmdEditCareer.Click, cmdEditSchool.Click, cmdEdittraining.Click, cmdEditLeave.Click, cmdEditViolateCommend.Click, _
            cmdEditSibling.Click, cmdEditRel.Click, cmdEditAsset.Click

            Session("empid") = tblEmp.SelectedRow.Cells(0).Text
            Session("mode") = "e"

            Select Case CType(sender, Web.UI.WebControls.Button).ID

                Case "cmdEditdep"
                    If tblDep.SelectedIndex >= 0 Then
                        Session("addtype") = "dependents"
                        Session("seqid") = tblDep.SelectedRow.Cells(0).Text

                        'Server.Transfer("modifydep.aspx")
                        vScript = "editwin=window.open('modifydep.aspx','empwin','toolbar=no,location=no,width=600,height=400,top=100,left=100');"
                    Else
                        vScript = "alert('Please select a dependent first.');"
                    End If
                Case "cmdEditSibling"
                    If tblEmpSib.SelectedIndex >= 0 Then
                        Session("addtype") = "sibling"
                        Session("seqid") = tblEmpSib.SelectedRow.Cells(0).Text
                        'Server.Transfer("modifydep.aspx")
                        vScript = "editwin=window.open('modifydep.aspx','empwin','toolbar=no,location=no,width=600,height=400,top=100,left=100');"
                    Else
                        vScript = "alert('Please select a dependent first.');"
                    End If
                Case "cmdEditAsset"
                    If tblRef.SelectedIndex >= 0 Then
                        Session("seqid") = tblAccountability.SelectedRow.Cells(0).Text
                        'Server.Transfer("modifyref.aspx")
                        vScript = "editwin=window.open('modifyasset.aspx','empwin','toolbar=no,location=no,width=600,height=400,top=100,left=100');"
                    Else
                        vScript = "alert('Please select an Item first.');"
                    End If
                Case "cmdEditRel"
                    If tblrel.SelectedIndex >= 0 Then
                        Session("addtype") = "relatives"
                        Session("seqid") = tblrel.SelectedRow.Cells(0).Text
                        vScript = "editwin=window.open('modifydep.aspx','empwin','toolbar=no,location=no,width=600,height=400,top=100,left=100');"
                    Else
                        vScript = "alert('Please select a dependent first.');"
                    End If
                Case "cmdEditRef"
                    If tblRef.SelectedIndex >= 0 Then
                        Session("seqid") = tblRef.SelectedRow.Cells(0).Text
                        'Server.Transfer("modifyref.aspx")
                        vScript = "editwin=window.open('modifyref.aspx','empwin','toolbar=no,location=no,width=600,height=400,top=100,left=100');"
                    Else
                        vScript = "alert('Please select a reference person first.');"
                    End If
                Case "cmdEditLic"
                    If tblLicense.SelectedIndex >= 0 Then
                        Session("seqid") = tblLicense.SelectedRow.Cells(0).Text
                        'Server.Transfer("modifylic.aspx")
                        vScript = "editwin=window.open('modifylic.aspx','empwin','toolbar=no,location=no,width=600,height=400,top=100,left=100');"
                    Else
                        vScript = "alert('Please select a license record first.');"
                    End If
                Case "cmdEditHist"
                    If tblEmpHist.SelectedIndex >= 0 Then
                        Session("seqid") = tblEmpHist.SelectedRow.Cells(0).Text
                        'Server.Transfer("modifyhist.aspx")
                        vScript = "editwin=window.open('modifyhist.aspx','empwin','toolbar=no,location=no,width=600,height=600,top=100,left=100');"
                    Else
                        vScript = "alert('Please select an Employer record first.');"
                    End If
                Case "cmdEditCareer"
                    If tblCareer.SelectedIndex >= 0 Then
                        Session("seqid") = tblCareer.SelectedRow.Cells(0).Text
                        'Server.Transfer("modifycareer.aspx")
                        vScript = "editwin=window.open('modifycareer.aspx','empwin','toolbar=no,location=no,width=600,height=400,top=100,left=100');"
                    Else
                        vScript = "alert('Please select an Employer record first.');"
                    End If
                Case "cmdEditSchool"
                    If tblSchool.SelectedIndex >= 0 Then
                        Session("seqid") = tblSchool.SelectedRow.Cells(1).Text
                        vScript = "editwin=window.open('modifyschool.aspx','empwin','toolbar=no,location=no,width=600,height=400,top=100,left=100');"
                    Else
                        vScript = "alert('Please select a school record first.');"
                    End If
                Case "cmdEdittraining"
                    If tbltraining.SelectedIndex >= 0 Then
                        Session("seqid") = tbltraining.SelectedRow.Cells(0).Text
                        vScript = "editwin=window.open('modifytraining.aspx','empwin','toolbar=no,location=no,width=600,height=400,top=100,left=100');"
                    Else
                        vScript = "alert('Please select a training record first.');"
                    End If
                Case "cmdEditLeave"
                    If tblLeave.SelectedIndex >= 0 Then
                        Session("seqid") = tblLeave.SelectedRow.Cells(0).Text
                        vScript = "editwin=window.open('modifyleaveref.aspx','empwin','toolbar=no,location=no,width=600,height=400,top=100,left=100');"
                    Else
                        vScript = "alert('Please select a training record first.');"
                    End If
                Case "cmdEditViolateCommend"
                    If cmdAddViolateCommend.Text.IndexOf("Violation") > 0 Then
                        Session("type") = "violate"
                    Else
                        Session("type") = "commend"
                    End If
                    If tblViolateCommend.SelectedIndex >= 0 Then
                        Session("seqid") = tblViolateCommend.SelectedRow.Cells(0).Text
                        vScript = "editwin=window.open('modifyviolatecommend.aspx','empwin','toolbar=no,location=no,width=500,height=500,top=100,left=100');"
                    Else
                        vScript = "alert('Please select a record first.');"
                    End If
            End Select
        End Sub

        Protected Sub cmdAddDep_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdAddDep.Click, cmdAddRef.Click, cmdAddLic.Click, _
            cmdAddHist.Click, cmdAddCareer.Click, cmdAddSchool.Click, cmdAddtraining.Click, cmdAddLeave.Click, _
            cmdAddViolateCommend.Click, cmdAddSibling.Click, cmdAddRel.Click, cmdAddAsset.Click

            If tblEmp.SelectedIndex >= 0 Then
                Session("empid") = tblEmp.SelectedRow.Cells(0).Text
                Session("seqid") = ""
                Session("mode") = "a"
                Select Case CType(sender, Web.UI.WebControls.Button).ID
                    Case "cmdAddDep"
                        Session("addtype") = "dependents"
                        vScript = "editwin=window.open('modifydep.aspx','empwin','toolbar=no,location=no,width=600,height=400,top=100,left=100');"
                    Case "cmdAddSibling"
                        Session("addtype") = "sibling"
                        vScript = "editwin=window.open('modifydep.aspx','empwin','toolbar=no,location=no,width=600,height=400,top=100,left=100');"
                    Case "cmdAddRel"
                        Session("addtype") = "relatives"
                        vScript = "editwin=window.open('modifydep.aspx','empwin','toolbar=no,location=no,width=600,height=400,top=100,left=100');"
                    Case "cmdAddRef"
                        vScript = "editwin=window.open('modifyref.aspx','empwin','toolbar=no,location=no,width=600,height=400,top=100,left=100');"
                    Case "cmdAddAsset"
                        vScript = "editwin=window.open('modifyasset.aspx','empwin','toolbar=no,location=no,width=600,height=400,top=100,left=100');"
                    Case "cmdAddLic"
                        vScript = "editwin=window.open('modifylic.aspx','empwin','toolbar=no,location=no,width=600,height=400,top=100,left=100');"
                    Case "cmdAddHist"
                        vScript = "editwin=window.open('modifyhist.aspx','empwin','toolbar=no,location=no,width=600,height=550,top=10,left=100');"
                    Case "cmdAddCareer"
                        vScript = "editwin=window.open('modifycareer.aspx','empwin','toolbar=no,location=no,width=600,height=500,top=100,left=100');"
                    Case "cmdAddSchool"
                        vScript = "editwin=window.open('modifyschool.aspx','empwin','toolbar=no,location=no,width=600,height=400,top=100,left=100');"
                    Case "cmdAddtraining"
                        vScript = "editwin=window.open('modifytraining.aspx','empwin','toolbar=no,location=no,width=600,height=400,top=100,left=100');"
                    Case "cmdAddSeminar"
                        vScript = "editwin=window.open('modifyseminar.aspx','empwin','toolbar=no,location=no,width=600,height=400,top=100,left=100');"
                    Case "cmdAddLeave"
                        vScript = "editwin=window.open('modifyleaveref.aspx','empwin','toolbar=no,location=no,width=600,height=400,top=100,left=100');"
                    Case "cmdAddViolateCommend"
                        If cmdAddViolateCommend.Text.IndexOf("Violation") > 0 Then
                            Session("type") = "violate"
                        Else
                            Session("type") = "commend"
                        End If
                        vScript = "editwin=window.open('modifyviolatecommend.aspx','empwin','toolbar=no,location=no,width=500,height=500,top=100,left=100');"
                End Select
            End If
        End Sub

        Protected Sub cmdDelDep_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDelDep.Click, cmdDelRef.Click, cmdDelLic.Click, _
            cmdDelHist.Click, cmdDelCareer.Click, cmdDelSchool.Click, cmdDeltraining.Click, cmdDelLeave.Click, _
            cmdDelViolateCommend.Click, cmdDelSibling.Click, cmdDelRel.Click

            Dim c As New SqlClient.SqlConnection
            Dim cm As New SqlClient.SqlCommand
            Dim rs As SqlClient.SqlDataReader

            Dim vType As String = ""

            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c
            Select Case CType(sender, Web.UI.WebControls.Button).ID
                Case "cmdDelDep"
                    If tblDep.SelectedIndex >= 0 Then
                        cm.CommandText = "delete from hr_dependents where Emp_Cd='" & _
                            tblEmp.SelectedRow.Cells(0).Text & "' and SeqId=" & _
                            tblDep.SelectedRow.Cells(0).Text
                    Else
                        vScript = "alert('Please first select a dependent to delete.');"
                        GoTo skip
                    End If
                Case "cmdDelRel"
                    If tblrel.SelectedIndex >= 0 Then
                        cm.CommandText = "delete from hr_dependents where Emp_Cd='" & _
                            tblEmp.SelectedRow.Cells(0).Text & "' and SeqId=" & _
                            tblrel.SelectedRow.Cells(0).Text
                    Else
                        vScript = "alert('Please first select a dependent to delete.');"
                        GoTo skip
                    End If

                Case "cmdDelSibling"
                    If tblEmpSib.SelectedIndex >= 0 Then
                        cm.CommandText = "delete from hr_dependents where Emp_Cd='" & _
                            tblEmp.SelectedRow.Cells(0).Text & "' and SeqId=" & _
                            tblEmpSib.SelectedRow.Cells(0).Text
                    Else
                        vScript = "alert('Please first select a dependent to delete.');"
                        GoTo skip
                    End If
                Case "cmdDelRef"
                    If tblRef.SelectedIndex >= 0 Then
                        cm.CommandText = "delete from hr_emp_reference where Emp_Cd='" & _
                            tblEmp.SelectedRow.Cells(0).Text & "' and SeqId=" & _
                            tblRef.SelectedRow.Cells(0).Text
                    Else
                        vScript = "alert('Please first select a reference person to delete.');"
                        GoTo skip
                    End If
                Case "cmdDelLic"
                    If tblLicense.SelectedIndex >= 0 Then
                        cm.CommandText = "delete from hr_emp_license_ref where Emp_Cd='" & _
                            tblEmp.SelectedRow.Cells(0).Text & "' and License_No='" & _
                            tblLicense.SelectedRow.Cells(0).Text & "'"
                    Else
                        vScript = "alert('Please first select a license no. to delete.');"
                        GoTo skip
                    End If
                Case "cmdDelHist"
                    If tblEmpHist.SelectedIndex >= 0 Then
                        cm.CommandText = "delete from hr_emp_employment_hist where Emp_Id='" & _
                            tblEmp.SelectedRow.Cells(0).Text & "' and From_Date='" & _
                            Format(CDate(tblEmpHist.SelectedRow.Cells(0).Text), "yyyy/MM/dd") & "'"
                    Else
                        vScript = "alert('Please first select an employer to delete.');"
                        GoTo skip
                    End If
                Case "cmdDelCareer"
                    If tblCareer.SelectedIndex >= 0 Then
                        Dim vretro As String = Request.Form("txtretro")
                        If vretro = "1" Then
                            Dim cmRef As New sqlclient.sqlcommand
                            Dim drRef As sqlclient.sqldatareader
                            Dim vMonth As Decimal = 30      'default

                            cmRef.Connection = c
                            cmRef.CommandText = "select Dates_to_Month from py_syscntrl"
                            drRef = cmRef.ExecuteReader
                            If drRef.Read Then
                                vMonth = drRef("Dates_to_Month")
                            End If
                            drRef.Close()
                            cmRef.CommandText = "select *  from hr_emp_career_movement where Emp_Cd='" & _
                                tblEmp.SelectedRow.Cells(0).Text & "' and From_Date='" & _
                                Format(CDate(tblCareer.SelectedRow.Cells(0).Text), "yyyy/MM/dd") & "'"
                            drRef = cmRef.ExecuteReader
                            If drRef.Read Then
                                cm.CommandText = "update py_emp_master set Rate_Month=" & _
                                    drRef("Salary_Amt") & _
                                    ",Rate_Year=" & drRef("Salary_Amt") * 12 & _
                                    ",Rate_Day=" & Math.Round(drRef("Salary_Amt") / vMonth, 2) & _
                                    ",Agency_Cd='" & IIf(IsDBNull(drRef("Office_Cd")), "99", drRef("Office_Cd")) & _
                                    "',DeptCd='" & IIf(IsDBNull(drRef("Dept_Cd")), "99", drRef("Dept_Cd")) & _
                                    "',DivCd='" & IIf(IsDBNull(drRef("Div_Cd")), "99", drRef("Div_Cd")) & _
                                    "',SectionCd='" & IIf(IsDBNull(drRef("Section_Cd")), "99", drRef("Section_Cd")) & _
                                    "',UnitCd='" & IIf(IsDBNull(drRef("Unit_Cd")), "99", drRef("Unit_Cd")) & _
                                    "',Pos_Cd='" & IIf(IsDBNull(drRef("Position_Cd")), "99", drRef("Position_Cd")) & _
                                    "',MealAllow=" & IIf(IsDBNull(drRef("MealAllow")), 0, drRef("MealAllow")) & _
                                    ",Rc_Cd='" & IIf(IsDBNull(drRef("Rc_Cd")), "99", drRef("Rc_Cd")) & _
                                    "',Aca=" & IIf(IsDBNull(drRef("Aca")), 0, drRef("Aca")) & _
                                    ",Rata=" & IIf(IsDBNull(drRef("Rata")), 0, drRef("Rata")) & _
                                    ",Pera=" & IIf(IsDBNull(drRef("Pera")), 0, drRef("Pera")) & _
                                    ",Tax_Cd='" & IIf(IsDBNull(drRef("TaxCd")), "Z", drRef("TaxCd")) & _
                                    "',Emp_Status='" & IIf(IsDBNull(drRef("Emp_Status")), "99", drRef("Emp_Status")) & _
                                    "',EmploymentType='" & IIf(IsDBNull(drRef("EmploymentType")), "R&F", drRef("EmploymentType")) & _
                                    "',Grade_Cd='" & IIf(IsDBNull(drRef("GradeCd")), "99", drRef("GradeCd")) & _
                                    "' where Emp_Cd='" & tblEmp.SelectedRow.Cells(0).Text & "'"
                                cm.ExecuteNonQuery()
                            End If
                            drRef.Close()
                            cmRef.Dispose()
                        End If
                        cm.CommandText = "delete from hr_emp_career_movement where Emp_Cd='" & _
                            tblEmp.SelectedRow.Cells(0).Text & "' and From_Date >='" & _
                            Format(CDate(tblCareer.SelectedRow.Cells(0).Text), "yyyy/MM/dd") & "'"
                    Else
                        vScript = "alert('Please first select an employer to delete.');"
                        GoTo skip
                    End If
                Case "cmdDelSchool"
                    If tblSchool.SelectedIndex >= 0 Then
                        cm.CommandText = "delete from hr_emp_scholastic where Emp_Cd='" & _
                            tblEmp.SelectedRow.Cells(0).Text & "' and From_Date='" & _
                            Format(CDate(tblSchool.SelectedRow.Cells(1).Text), "yyyy/MM/dd") & "'"
                    Else
                        vScript = "alert('Please first select a school to delete.');"
                        GoTo skip
                    End If
                Case "cmdDeltraining"
                    If tbltraining.SelectedIndex >= 0 Then
                        cm.CommandText = "delete from hr_emp_training where Emp_Id='" & _
                            tblEmp.SelectedRow.Cells(0).Text & "' and SeqId='" & _
                            tbltraining.SelectedRow.Cells(0).Text & "'"

                    Else
                        vScript = "alert('Please first select a training record to delete.');"
                        GoTo skip
                    End If
                Case "cmdDelLeave"
                    If tblLeave.SelectedIndex >= 0 Then
                        cm.CommandText = "select * from py_emp_leave where Emp_Cd='" & _
                                        tblEmp.SelectedRow.Cells(0).Text & "' and Leave_Cd='" & _
                                        tblLeave.SelectedRow.Cells(0).Text & "'"
                        rs = cm.ExecuteReader
                        Dim vLastUpdate As String = ""
                        Dim vExpiryDate As String = ""
                        If rs.Read Then

                            If IsDBNull(rs("LastUpdate")) Then
                                vLastUpdate = ""
                            Else
                                vLastUpdate = Format(CDate(rs("LastUpdate")), "yyyy/MM/dd")
                            End If
                            If IsDBNull(rs("ExpiryDate")) Then
                                vExpiryDate = ""
                            Else
                                vExpiryDate = Format(CDate(rs("ExpiryDate")), "yyyy/MM/dd")
                            End If

                            Session("oldval") = "Leave Type=" & rs("Leave_Cd") & _
                                "|Credit=" & rs("Credit") & _
                                "|Used=" & rs("Used") & _
                                "|Balance=" & rs("Balance") & _
                                "|Last Update=" & vLastUpdate & _
                                "|Balance Previous Year=" & Val(rs("BalanceLastYear")) & _
                                "|Expiry Date Previous Year=" & vExpiryDate

                            Session("newval") = "Leave Type=Delete" & _
                                "|Credit=Delete" & _
                                "|Used=Delete" & _
                                "|Balance=" & "Delete" & _
                                "|Last Update=Delete" & _
                                "|Balance Previous Year=Delete" & _
                                "|Expiry Date Previous Year=Delete"

                        End If
                        rs.Close()
                        EventLog(Session("uid"), Request.ServerVariables("REMOTE_ADDR"), "DELETE", Session("oldval"), Session("newval"), _
                        "Employee ID: " & Session("empid") & " was deleted the leave", "Leave", c)

                        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                        cm.CommandText = "delete from py_emp_leave where Emp_Cd='" & _
                            tblEmp.SelectedRow.Cells(0).Text & "' and Leave_Cd='" & _
                            tblLeave.SelectedRow.Cells(0).Text & "'"
                    Else
                        vScript = "alert('Please first select a training record to delete.');"
                        GoTo skip
                    End If
                Case "cmdDelViolateCommend"
                    vType = IIf(cmdDelViolateCommend.Text.IndexOf("violate") > 0, "violate", "commend")

                    If tblViolateCommend.SelectedIndex >= 0 Then
                        cm.CommandText = "delete from hr_emp_violate_commend where Emp_Id='" & _
                            tblEmp.SelectedRow.Cells(0).Text & "' and Event_Date='" & _
                            Format(CDate(tblViolateCommend.SelectedRow.Cells(0).Text), "yyyy/MM/dd") & _
                            "' and Event_Type='" & vType & "'"
                    Else
                        vScript = "alert('Please first select a record to delete.');"
                        GoTo skip
                    End If
            End Select
            cm.ExecuteNonQuery()
            vScript = "alert('Record successfully deleted.');"
skip:
            cm.Dispose()
            c.Close()
            c.Dispose()
            Select Case CType(sender, Web.UI.WebControls.Button).ID
                Case "cmdDelDep"
                    RefreshDep(tblEmp.SelectedRow.Cells(0).Text)
                Case "cmdDelSibling"
                    RefreshSib(tblEmp.SelectedRow.Cells(0).Text)
                Case "cmdDelRel"
                    RefreshRel(tblEmp.SelectedRow.Cells(0).Text)
                Case "cmdDelRef"
                    RefreshRef(tblEmp.SelectedRow.Cells(0).Text)
                Case "cmdDelLic"
                    RefreshLic(tblEmp.SelectedRow.Cells(0).Text)
                Case "cmdDelHist"
                    RefreshHist(tblEmp.SelectedRow.Cells(0).Text)
                Case "cmdDelCareer"
                    RefreshCareer(tblEmp.SelectedRow.Cells(0).Text)
                Case "cmdDelSchool"
                    RefreshSchool(tblEmp.SelectedRow.Cells(0).Text)
                Case "cmdDeltraining"
                    RefreshTraining(tblEmp.SelectedRow.Cells(0).Text)
                Case "cmdDelLeave"
                    RefreshLeave(tblEmp.SelectedRow.Cells(0).Text)
                Case "cmdDelViolateCommend"
                    RefreshViolateCommend(tblEmp.SelectedRow.Cells(0).Text, vType)
            End Select
        End Sub

        Protected Sub cmdDelDep_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDelDep.Init, cmdDelRef.Init, cmdDelLic.Init, _
            cmdDelCareer.Init, cmdDelSchool.Init, cmdDeltraining.Init, cmdDelLeave.Init, cmdDelViolateCommend.Init, _
            cmdDelSibling.Init, cmdDelRel.Init

            cmdDelRel.Attributes.Add("onclick", "return ask();")
            cmdDelSibling.Attributes.Add("onclick", "return ask();")
            cmdDelDep.Attributes.Add("onclick", "return ask();")
            cmdDelRef.Attributes.Add("onclick", "return ask();")
            cmdDelLic.Attributes.Add("onclick", "return ask();")
            cmdDelCareer.Attributes.Add("onclick", "return askcareer();")
            cmdDelSchool.Attributes.Add("onclick", "return ask();")
            cmdDeltraining.Attributes.Add("onclick", "return ask();")
            cmdDelLeave.Attributes.Add("onclick", "return ask();")

            cmdDelViolateCommend.Attributes.Add("onclick", "return ask();")
        End Sub

        Protected Sub cmdViewLic_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdViewLic.Click, _
            cmdViewHist.Click, cmdViewCareer.Click, cmdViewSchool.Click, cmdViewTraining.Click
            Session("mode") = "v"
            Session("empid") = tblEmp.SelectedRow.Cells(0).Text
            Select Case CType(sender, Web.UI.WebControls.Button).ID
                Case "cmdViewLic"
                    If tblLicense.SelectedIndex >= 0 Then
                        Session("seqid") = tblLicense.SelectedRow.Cells(0).Text
                        vScript = "editwin=window.open('modifylic.aspx','empwin','toolbar=no,location=no,width=600,height=400,top=100,left=100');"
                    Else
                        vScript = "alert('Please select a license record first.');"
                    End If
                Case "cmdViewHist"
                    If tblEmpHist.SelectedIndex >= 0 Then
                        Session("seqid") = tblEmpHist.SelectedRow.Cells(0).Text
                        vScript = "editwin=window.open('modifyhist.aspx','empwin','toolbar=no,location=no,width=600,height=400,top=100,left=100');"
                    Else
                        vScript = "alert('Please select an employer record first.');"
                    End If
                Case "cmdViewCareer"
                    If tblCareer.SelectedIndex >= 0 Then
                        Session("seqid") = tblCareer.SelectedRow.Cells(0).Text
                        'vScript = "editwin=window.open('modifycareer.aspx','empwin','toolbar=no,location=no,width=600,height=400,top=100,left=100');"
                        'printEMR()
                        vScript = "alert('Error in VSPrinter8Lib.VSPrinter reference.');"
                    Else
                        vScript = "alert('Please select an employer record first.');"
                    End If
                Case "cmdViewSchool"
                    If tblSchool.SelectedIndex >= 0 Then
                        Session("seqid") = tblSchool.SelectedRow.Cells(1).Text
                        vScript = "editwin=window.open('modifyschool.aspx','empwin','toolbar=no,location=no,width=600,height=400,top=100,left=100');"
                    Else
                        vScript = "alert('Please select a school record first.');"
                    End If
                Case "cmdViewTraining"
                    If tblTraining.SelectedIndex >= 0 Then
                        Session("seqid") = tblTraining.SelectedRow.Cells(0).Text
                        vScript = "editwin=window.open('modifytraining.aspx','empwin','toolbar=no,location=no,width=600,height=400,top=100,left=100');"
                    Else
                        vScript = "alert('Please select a training record first.');"
                    End If
            End Select
        End Sub
        'Private Sub PrintEMR()
        '    Dim c As New SqlClient.SqlConnection(connStr)
        '    Dim cm As New SqlClient.SqlCommand

        '    Dim dr As SqlClient.SqlDataReader
        '    Dim vPrn As New VSPrinter8Lib.VSPrinter
        '    Dim vPDF As New VSPDF8Lib.VSPDF8
        '    Dim vName As String = tblEmp.SelectedRow.Cells(0).Text & "=>" & tblEmp.SelectedRow.Cells(1).Text & ", " & _
        '        tblEmp.SelectedRow.Cells(2).Text & " " & tblEmp.SelectedRow.Cells(3).Text
        '    Dim vDate As String = ""
        '    Dim vPrepared As String = ""
        '    Dim vRecommend As String = ""
        '    Dim vApproved As String = ""
        '    Dim vDatePrepared As String = ""
        '    Dim vDateRecommend As String = ""
        '    Dim vDateApproved As String = ""
        '    Dim vNature As String = "New"
        '    Dim vRemarks As String = ""
        '    Dim vSSS As String = ""
        '    Dim vTIN As String = ""
        '    Dim vStart As String = ""
        '    Dim vBDate As String = ""
        '    Dim vEffectivity As String = ""
        '    Dim vRC(2) As String
        '    Dim vOfc(2) As String
        '    Dim vDiv(2) As String
        '    Dim vDept(2) As String
        '    Dim vSection(2) As String
        '    Dim vUnit(2) As String
        '    Dim vPosition(2) As String
        '    Dim vTax(2) As String
        '    Dim vType(2) As String
        '    Dim vStatus(2) As String
        '    Dim vGrade(2) As String
        '    Dim vSalary(2) As Decimal
        '    Dim vACA(2) As Decimal
        '    Dim vRATA(2) As Decimal
        '    Dim vPERA(2) As Decimal
        '    Dim vMeal(2) As Decimal
        '    Dim vTotal(2) As Decimal
        '    Dim vFormat As String = ""
        '    Dim vData As String = ""
        '    Dim iLoop As Integer

        '    For iLoop = 0 To 1
        '        vRC(iLoop) = ""
        '        vOfc(iLoop) = ""
        '        vDiv(iLoop) = ""
        '        vDept(iLoop) = ""
        '        vSection(iLoop) = ""
        '        vUnit(iLoop) = ""
        '        vPosition(iLoop) = ""
        '        vTax(iLoop) = ""
        '        vType(iLoop) = ""
        '        vStatus(iLoop) = ""
        '        vACA(iLoop) = 0
        '        vRATA(iLoop) = 0
        '        vPERA(iLoop) = 0
        '        vMeal(iLoop) = 0
        '    Next iLoop
        '    c.ConnectionString = connStr

        '    Try
        '        c.Open()
        '    Catch ex As SqlClient.SqlException
        '        vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
        '            ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        '        c.Dispose()
        '        cm.Dispose()
        '        Exit Sub
        '    End Try

        '    cm.Connection = c
        '    cm.CommandText = "select * from py_emp_master where Emp_Cd='" & ExtractData(vName) & "'"
        '    dr = cm.ExecuteReader
        '    If dr.Read Then
        '        vTIN = IIf(IsDBNull(dr("Tin")), "", dr("Tin"))
        '        vSSS = IIf(IsDBNull(dr("Sss_No")), "", dr("Sss_No"))
        '        vStart = Format(CDate(dr("Start_Date")), "MM/dd/yyyy").ToString
        '        vBDate = IIf(IsDBNull(dr("Bday")), "", dr("Bday").ToString)
        '        vRC(0) = GetRef("select descr from rc where Rc_Cd='" & dr("Rc_Cd") & "'", dr("Rc_Cd"), c)
        '        vOfc(0) = GetRef("select AgencyName from agency where AgencyCd='" & dr("Agency_Cd") & "'", dr("Agency_Cd"), c)
        '        vDiv(0) = GetRef("select Descr from hr_div_ref where Div_Cd='" & dr("DivCd") & "'", dr("DivCd"), c)
        '        vDept(0) = GetRef("select Descr from hr_dept_ref where Dept_Cd='" & dr("DeptCd") & "'", dr("DeptCd"), c)
        '        vSection(0) = GetRef("select Descr from hr_section_ref where Section_Cd='" & dr("SectionCd") & "'", dr("SectionCd"), c)
        '        vUnit(0) = GetRef("select Descr from hr_unit_ref where Unit_Cd='" & dr("UnitCd") & "'", dr("UnitCd"), c)
        '        vPosition(0) = GetRef("select Position from py_position_ref where Pos_Cd='" & dr("Pos_Cd") & "'", dr("Pos_Cd"), c)
        '        vTax(0) = GetRef("select Descr from py_tax_ref where Tax_cd='" & dr("Tax_Cd") & "'", dr("Tax_Cd"), c)
        '        vType(0) = GetRef("select Descr from hr_employment_type where EmploymentType='" & dr("EmploymentType") & "'", dr("EmploymentType"), c)
        '        vStatus(0) = GetRef("select Descr from py_employee_stat where Status_Code='" & dr("Emp_Status") & "'", dr("Emp_Status"), c)
        '        vGrade(0) = GetRef("select Descr from py_grade where Grade_Cd='" & dr("Grade_Cd") & "'", dr("Grade_Cd"), c)
        '        vSalary(0) = dr("Rate_Month")
        '        vACA(0) = dr("Aca")
        '        vRATA(0) = dr("Rata")
        '        vPERA(0) = dr("Pera")
        '        vMeal(0) = dr("MealAllow")
        '    End If
        '    dr.Close()

        '    'get current selection
        '    cm.CommandText = "select  * from hr_emp_career_movement where Emp_Cd='" & ExtractData(vName) & _
        '        "' and From_Date='" & Format(CDate(tblCareer.SelectedRow.Cells(0).Text), "yyyy/MM/dd HH:mm:ss") & _
        '        "' order by From_Date desc"
        '    dr = cm.ExecuteReader
        '    If dr.Read Then 'with records
        '        vDate = Format(dr("From_Date"), "MM/dd/yyyy")
        '        If IsDBNull(dr("EffectivityDate")) Then
        '            vEffectivity = ""
        '        Else
        '            vEffectivity = Format(dr("EffectivityDate"), "MM/dd/yyyy")
        '        End If
        '        vRC(1) = GetRef("select descr from rc where Rc_Cd='" & dr("Rc_Cd") & "'", dr("Rc_Cd"), c)
        '        vOfc(1) = GetRef("select AgencyName from agency where AgencyCd='" & dr("Office_Cd") & "'", dr("Office_Cd"), c)
        '        vDiv(1) = GetRef("select Descr from hr_div_ref where Div_Cd='" & dr("Div_Cd") & "'", dr("Div_Cd"), c)
        '        vDept(1) = GetRef("select Descr from hr_dept_ref where Dept_Cd='" & dr("Dept_Cd") & "'", dr("Dept_Cd"), c)
        '        vSection(1) = GetRef("select Descr from hr_section_ref where Section_Cd='" & dr("Section_Cd") & "'", dr("Section_Cd"), c)
        '        vUnit(1) = GetRef("select Descr from hr_unit_ref where Unit_Cd='" & dr("Unit_Cd") & "'", dr("Unit_Cd"), c)
        '        vPosition(1) = GetRef("select Position from py_position_ref where Pos_Cd='" & dr("Position_Cd") & "'", dr("Position_Cd"), c)
        '        vTax(1) = GetRef("select Descr from py_tax_ref where Tax_cd='" & dr("TaxCd") & "'", dr("TaxCd"), c)
        '        vType(1) = GetRef("select Descr from hr_employment_type where EmploymentType='" & dr("EmploymentType") & "'", dr("EmploymentType"), c)
        '        vStatus(1) = GetRef("select Descr from py_employee_stat where Status_Code='" & dr("Emp_Status") & "'", dr("Emp_Status"), c)
        '        vGrade(1) = GetRef("select Grade_Cd,Descr from py_grade where Grade_Cd='" & _
        '            IIf(IsDBNull(dr("GradeCd")), "", dr("GradeCd")) & "'", _
        '            IIf(IsDBNull(dr("GradeCd")), "", dr("GradeCd")), c)
        '        vSalary(1) = dr("Salary_Amt")
        '        vACA(1) = dr("Aca")
        '        vRATA(1) = dr("Rata")
        '        vPERA(1) = dr("Pera")
        '        vMeal(1) = dr("MealAllow")
        '        vNature = GetRef("select Descr from hr_nature where NatureCd='" & IIf(IsDBNull(dr("Nature")), "", dr("Nature")) & "'", dr("Nature"), c)
        '        vRemarks = IIf(IsDBNull(dr("Remarks")), "", dr("Remarks"))
        '        vPrepared = dr("PreparedBy")
        '        vRecommend = dr("RecommendedBy")
        '        vApproved = dr("ApprovedBy")
        '        vDatePrepared = Format(dr("DatePrepared"), "MM/dd/yyyy")
        '        vDateRecommend = Format(dr("DateRecommended"), "MM/dd/yyyy")
        '        vDateApproved = Format(dr("DateApproved"), "MM/dd/yyyy")
        '    End If
        '    dr.Close()

        '    'check if the current selection is the latest record
        '    cm.CommandText = "select top 1 * from hr_emp_career_movement where Emp_Cd='" & ExtractData(vName) & _
        '        "' and From_Date >'" & Format(CDate(tblCareer.SelectedRow.Cells(0).Text), "yyyy/MM/dd HH:mm:ss") & "'"
        '    dr = cm.ExecuteReader
        '    If dr.Read Then 'current selected record is not latest, retrieve the fetched records
        '        vDate = Format(dr("From_Date"), "MM/dd/yyyy")
        '        If IsDBNull(dr("EffectivityDate")) Then
        '            vEffectivity = ""
        '        Else
        '            vEffectivity = Format(dr("EffectivityDate"), "MM/dd/yyyy")
        '        End If
        '        vRC(0) = GetRef("select descr from rc where Rc_Cd='" & dr("Rc_Cd") & "'", dr("Rc_Cd"), c)
        '        vOfc(0) = GetRef("select AgencyName from agency where AgencyCd='" & dr("Office_Cd") & "'", dr("Office_Cd"), c)
        '        vDiv(0) = GetRef("select Descr from hr_div_ref where Div_Cd='" & dr("Div_Cd") & "'", dr("Div_Cd"), c)
        '        vDept(0) = GetRef("select Descr from hr_dept_ref where Dept_Cd='" & dr("Dept_Cd") & "'", dr("Dept_Cd"), c)
        '        vSection(0) = GetRef("select Descr from hr_section_ref where Section_Cd='" & dr("Section_Cd") & "'", dr("Section_Cd"), c)
        '        vUnit(0) = GetRef("select Descr from hr_unit_ref where Unit_Cd='" & dr("Unit_Cd") & "'", dr("Unit_Cd"), c)
        '        vPosition(0) = GetRef("select Position from py_position_ref where Pos_Cd='" & dr("Position_Cd") & "'", dr("Position_Cd"), c)
        '        vTax(0) = GetRef("select Descr from py_tax_ref where Tax_cd='" & dr("TaxCd") & "'", dr("TaxCd"), c)
        '        vType(0) = GetRef("select Descr from hr_employment_type where EmploymentType='" & dr("EmploymentType") & "'", dr("EmploymentType"), c)
        '        vStatus(0) = GetRef("select Descr from py_employee_stat where Status_Code='" & dr("Emp_Status") & "'", dr("Emp_Status"), c)
        '        vGrade(0) = GetRef("select Grade_Cd,Descr from py_grade where Grade_Cd='" & _
        '            IIf(IsDBNull(dr("GradeCd")), "", dr("GradeCd")) & "'", _
        '            IIf(IsDBNull(dr("GradeCd")), "", dr("GradeCd")), c)
        '        vSalary(0) = dr("Salary_Amt")
        '        vACA(0) = dr("Aca")
        '        vRATA(0) = dr("Rata")
        '        vPERA(0) = dr("Pera")
        '        vMeal(0) = dr("MealAllow")
        '        'vNature = GetRef("select Descr from hr_nature where NatureCd='" & IIf(IsDBNull(dr("Nature")), "", dr("Nature")) & "'", dr("Nature"), c)
        '        'vRemarks = IIf(IsDBNull(dr("Remarks")), "", dr("Remarks"))
        '        'vPrepared = dr("PreparedBy")
        '        'vRecommend = dr("RecommendedBy")
        '        'vApproved = dr("ApprovedBy")
        '        'vDatePrepared = Format(dr("DatePrepared"), "MM/dd/yyyy")
        '        'vDateRecommend = Format(dr("DateRecommended"), "MM/dd/yyyy")
        '        'vDateApproved = Format(dr("DateApproved"), "MM/dd/yyyy")
        '    End If
        '    dr.Close()

        '    vTotal(0) = vACA(0) + vRATA(0) + vPERA(0) + vMeal(0) + vSalary(0)
        '    vTotal(1) = vACA(1) + vRATA(1) + vPERA(1) + vMeal(1) + vSalary(1)
        '    cm.CommandText = "select FullName from user_list where User_Id='" & _
        '        vPrepared & "'"
        '    dr = cm.ExecuteReader
        '    If dr.Read Then
        '        vPrepared = dr("FullName")
        '    End If
        '    dr.Close()
        '    cm.CommandText = "select Emp_Lname,Emp_Fname from py_emp_master where Emp_Cd='" & _
        '        vRecommend & "'"
        '    dr = cm.ExecuteReader
        '    If dr.Read Then
        '        vRecommend = dr("Emp_Lname") & ", " & dr("Emp_Fname")
        '    End If
        '    dr.Close()
        '    cm.CommandText = "select Emp_Lname,Emp_Fname from py_emp_master where Emp_Cd='" & _
        '        vApproved & "'"
        '    dr = cm.ExecuteReader
        '    If dr.Read Then
        '        vApproved = dr("Emp_Lname") & ", " & dr("Emp_Fname")
        '    End If
        '    dr.Close()
        '    vPrn.Action = VSPrinter8Lib.ActionSettings.paStartDoc
        '    vPrn.FontBold = True
        '    vPrn.FontName = "Arial"
        '    vPrn.FontSize = 14
        '    vPrn.Header = "||" & vDate
        '    vPrn.HdrFontSize = 8
        '    vPrn.TextAlign = VSPrinter8Lib.TextAlignSettings.taCenterBottom
        '    vPrn.Paragraph = "EMPLOYEE MOVEMENT REPORT"
        '    vPrn.TextAlign = VSPrinter8Lib.TextAlignSettings.taJustBottom
        '    vPrn.FontSize = 10
        '    vPrn.FontBold = False
        '    vPrn.Paragraph = "NAME: " & vName
        '    vPrn.Paragraph = "NATURE OF MOVEMENT: " & vNature
        '    vPrn.Paragraph = "DATE HIRED: " & vStart
        '    vPrn.Paragraph = "EFFECTIVITY DATE: " & vEffectivity
        '    If vBDate <> "" Then
        '        vPrn.Paragraph = "DATE OF BIRTH: " & Format(CDate(vBDate), "MM/dd/yyyy")
        '    Else
        '        vPrn.Paragraph = "DATE OF BIRTH: Unknown"
        '    End If
        '    vPrn.Paragraph = "SSS: " & vSSS
        '    vPrn.Paragraph = "TIN: " & vTIN
        '    vFormat = "<4000|^3000|^3000;"
        '    vData = "|FROM|TO;"
        '    vPrn.FontBold = True
        '    vPrn.TableBorder = VSPrinter8Lib.TableBorderSettings.tbAll
        '    vPrn.Table = vFormat & vData
        '    vData = "COST CENTER|" & vRC(1) & "|" & vRC(0) & ";" & _
        '            "OFFICE|" & vOfc(1) & "|" & vOfc(0) & ";" & _
        '            "DIVISION|" & vDiv(1) & "|" & vDiv(0) & ";" & _
        '            "DEPARTMENT|" & vDept(1) & "|" & vDept(0) & ";" & _
        '            "SECTION|" & vSection(1) & "|" & vSection(0) & ";" & _
        '            "UNIT|" & vUnit(1) & "|" & vUnit(0) & ";" & _
        '            "EMPLOYMENT STATUS|" & vStatus(1) & "|" & vStatus(0) & ";" & _
        '            "POSITION|" & vPosition(1) & "|" & vPosition(0) & ";" & _
        '            "TAX EXEMPTION|" & vTax(1) & "|" & vTax(0) & ";" & _
        '            "JOB LEVEL|" & vGrade(1) & "|" & vGrade(0) & ";" & _
        '            "SECURITY TYPE|" & vType(1) & "|" & vType(0) & ";" & _
        '            "BASIC SALARY|" & Format(vSalary(1), "###,##0.00") & "|" & Format(vSalary(0), "###,##0.00") & ";" & _
        '            "ECOLA|" & Format(vACA(1), "##,##0.00") & "|" & Format(vACA(0), "##,##0.00") & ";" & _
        '            "REP ALLOW/TRANSPO ALLOW|" & Format(vRATA(1), "##,##0.00") & "|" & Format(vRATA(0), "##,##0.00") & ";" & _
        '            "TEMPO ALLOW/OT ALLOW|" & Format(vPERA(1), "##,##0.00") & "|" & Format(vPERA(0), "##,##0.00") & ";" & _
        '            "MEAL ALLOW|" & Format(vMeal(1), "##,##0.00") & "|" & Format(vMeal(0), "##,##0.00") & ";" & _
        '            "TOTAL==>|" & Format(vTotal(1), "###,##0.00") & "|" & Format(vTotal(0), "###,##0.00") & ";"
        '    vPrn.FontBold = False
        '    vPrn.Table = vFormat & vData
        '    vPrn.Paragraph = vbCrLf & "Remarks: " & vRemarks
        '    vFormat = "<4000|<3000|<3000;"
        '    vData = "PREPARED BY:|RECOMMENDED BY:|APPROVED BY:;" & vbCrLf & vbCrLf & vbCrLf & _
        '            vPrepared & "|" & vbCrLf & vbCrLf & vbCrLf & vRecommend & "|" & vbCrLf & vbCrLf & vbCrLf & _
        '            vApproved & ";" & _
        '            vDatePrepared & "|" & vDateRecommend & "|" & vDateApproved & ";"
        '    vPrn.FontBold = True
        '    vPrn.Table = vFormat & vData
        '    vPrn.Action = VSPrinter8Lib.ActionSettings.paEndDoc
        '    vPDF.ConvertDocument(vPrn, Server.MapPath("") & "\downloads\" & Session.SessionID & "-emr.pdf")
        '    vScript = "viewwin=window.open('downloads/" & Session.SessionID & "-emr.pdf','viewwin','toolbar=no,location=no,width=800,height=600,top=50,left=100,scrollbars=yes');"
        '    vPDF = Nothing
        '    vPrn = Nothing
        '    cm.Dispose()
        '    c.Close()
        '    c.Dispose()
        'End Sub
        Protected Sub cmdPrintDep_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdPrintDep.Click, _
            cmdPrintCareer.Click, cmdPrintHist.Click, cmdPrintLic.Click, _
            cmdPrintRef.Click, cmdPrintSchool.Click, cmdPrintTraining.Click, cmdPrintViolateCommend.Click, _
            cmdPrintLeave.Click

            Dim vRptName As String = ""
            Dim vFilter As String = ""
            Select Case CType(sender, Web.UI.WebControls.Button).ID.ToLower
                Case "cmdprintcareer"
                    vRptName = "reports/emp_career_history.rpt"
                    vFilter = "{emp_career_hist.Emp_Cd}='" & tblEmp.SelectedRow.Cells(0).Text & "'"
                Case "cmdprintdep"
                    vRptName = "reports/emp_dependents.rpt"
                    vFilter = "{emp_dependents.Emp_Cd}='" & tblEmp.SelectedRow.Cells(0).Text & "'"
                Case "cmdprinthist"
                    vRptName = "reports/emp_employ_rec.rpt"
                    vFilter = "{emp_employ_hist.Emp_Id}='" & tblEmp.SelectedRow.Cells(0).Text & "'"
                Case "cmdprintlic"
                    vRptName = "reports/emp_licenses.rpt"
                    vFilter = "{emp_license_ref.Emp_Cd}='" & tblEmp.SelectedRow.Cells(0).Text & "'"
                Case "cmdprintref"
                    vRptName = "reports/emp_char_ref.rpt"
                    vFilter = "{emp_char.Emp_Cd}='" & tblEmp.SelectedRow.Cells(0).Text & "'"
                Case "cmdprintschool"
                    vRptName = "reports/emp_scholastic.rpt"
                    vFilter = "{scholastic.Emp_Cd}='" & tblEmp.SelectedRow.Cells(0).Text & "'"
                Case "cmdprinttraining"
                    vRptName = "reports/emp_training.rpt"
                    vFilter = "{emp_training.Emp_Id}='" & tblEmp.SelectedRow.Cells(0).Text & "'"
                Case "cmdprintviolatecommend"
                    vRptName = "reports/empviolatecommend.rpt"
                    vFilter = "{emp_violate_commend.Event_Type}='" & _
                        IIf(cmdAddViolateCommend.Text.IndexOf("Violation") > 0, "violate", "commend") & _
                        "' and {emp_violate_commend.Emp_Id}='" & _
                        tblEmp.SelectedRow.Cells(0).Text & "'"
            End Select

            Session("reportname") = vRptName
            Session("returnaddr") = ""
            Session("filter") = vFilter
            vScript = "editwin=window.open('preview.aspx','empwin','toolbar=no,location=no,width=800,height=600,top=100,left=100,scrollbars=yes');"
        End Sub

        Protected Sub lnkCommend_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles lnkCommend.Click, _
            lnkCareer.Click, lnkDependents.Click, lnkSiblings.Click, lnkrel.Click, lnkEmpHist.Click, lnkGeneral.Click, _
             lnkIdentificaiton.Click, lnkLeave.Click, lnkLicense.Click, lnkOptions.Click, _
            lnkPersonal.Click, lnkRef.Click, lnkSalary.Click, lnkSchool.Click, _
            lnktraining.Click, lnkViolate.Click, lnkAssets.Click

            If tblEmp.SelectedIndex <> -1 Then
                Select Case CType(sender, Web.UI.WebControls.LinkButton).ID.ToLower
                    Case "lnkgeneral"
                        If Not pnlGeneral.Visible Then
                            RefreshGeneral(tblEmp.SelectedRow.Cells(0).Text)
                            pnlGeneral.Visible = True
                        Else
                            pnlGeneral.Visible = False
                        End If
                    Case "lnkpersonal"
                        If Not pnlPersonal.Visible Then
                            pnlPersonal.Visible = True
                            RefreshPersonal(tblEmp.SelectedRow.Cells(0).Text)
                        Else
                            pnlPersonal.Visible = False
                        End If
                    Case "lnkidentificaiton"
                        If Not pnlIdentification.Visible Then
                            RefreshIdentification(tblEmp.SelectedRow.Cells(0).Text)
                            pnlIdentification.Visible = True
                        Else
                            pnlIdentification.Visible = False
                        End If
                    Case "lnkoptions"
                        If Not pnlOption.Visible Then
                            RefreshOption(tblEmp.SelectedRow.Cells(0).Text)
                            pnlOption.Visible = True
                        Else
                            pnlOption.Visible = False
                        End If
                    Case "lnkassets"
                        If Not pnlAccountability.Visible Then
                            RefreshAccountability(tblEmp.SelectedRow.Cells(0).Text)
                            pnlAccountability.Visible = True
                        Else
                            pnlAccountability.Visible = False
                        End If
                    Case "lnksalary"
                        If Not pnlSalary.Visible Then
                            RefreshSalary(tblEmp.SelectedRow.Cells(0).Text)
                            pnlSalary.Visible = True
                        Else
                            pnlSalary.Visible = False
                        End If
                    Case "lnkpersonal"
                        If Not pnlPersonal.Visible Then
                            RefreshPersonal(tblEmp.SelectedRow.Cells(0).Text)
                            pnlPersonal.Visible = True
                        Else
                            pnlPersonal.Visible = False
                        End If
                    Case "lnkdependents"
                        If Not pnlDep.Visible Then
                            RefreshDep(tblEmp.SelectedRow.Cells(0).Text)
                            pnlDep.Visible = True
                        Else
                            pnlDep.Visible = False
                        End If

                    Case "lnksiblings"
                        If Not pnlEmpSib.Visible Then
                            RefreshSib(tblEmp.SelectedRow.Cells(0).Text)
                            pnlEmpSib.Visible = True
                        Else
                            pnlEmpSib.Visible = False
                        End If

                    Case "lnkrel"
                        If Not pnlemprel.Visible Then
                            RefreshRel(tblEmp.SelectedRow.Cells(0).Text)
                            pnlemprel.Visible = True
                        Else
                            pnlemprel.Visible = False
                        End If

                    Case "lnkref"
                        If Not pnlCharRef.Visible Then
                            RefreshRef(tblEmp.SelectedRow.Cells(0).Text)
                            pnlCharRef.Visible = True
                        Else
                            pnlCharRef.Visible = False
                        End If
                    Case "lnklicense"
                        If Not pnlLicense.Visible Then
                            RefreshLic(tblEmp.SelectedRow.Cells(0).Text)
                            pnlLicense.Visible = True
                        Else
                            pnlLicense.Visible = False
                        End If
                    Case "lnkemphist"
                        If Not pnlEmployment.Visible Then
                            RefreshHist(tblEmp.SelectedRow.Cells(0).Text)
                            pnlEmployment.Visible = True
                        Else
                            pnlEmployment.Visible = False
                        End If
                    Case "lnkcareer"
                        If Not pnlCareer.Visible Then
                            RefreshCareer(tblEmp.SelectedRow.Cells(0).Text)
                            pnlCareer.Visible = True
                        Else
                            pnlCareer.Visible = False
                        End If
                    Case "lnkschool"
                        If Not pnlSchool.Visible Then
                            RefreshSchool(tblEmp.SelectedRow.Cells(0).Text)
                            pnlSchool.Visible = True
                        Else
                            pnlSchool.Visible = False
                        End If
                    Case "lnktraining"
                        If Not pnltraining.Visible Then
                            RefreshTraining(tblEmp.SelectedRow.Cells(0).Text)
                            pnltraining.Visible = True
                        Else
                            pnltraining.Visible = False
                        End If
                    Case "lnkleave"
                        If Not pnlLeave.Visible Then
                            RefreshLeave(tblEmp.SelectedRow.Cells(0).Text)
                            pnlLeave.Visible = True
                        Else
                            pnlLeave.Visible = False
                        End If
                    Case "lnkcommend"
                        If Not pnlCommend.Visible Then
                            RefreshViolateCommend(tblEmp.SelectedRow.Cells(0).Text, "commend")
                            pnlCommend.Visible = True
                        Else
                            pnlCommend.Visible = False
                        End If
                    Case "lnkviolate"
                        RefreshViolateCommend(tblEmp.SelectedRow.Cells(0).Text, "violate")
                End Select
            Else
                vScript = "alert('Please select an employee first');"
            End If
        End Sub

        Protected Sub cmdSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSearch.Click
            Session("letter") = txtSearch.Text
            DataRefresh(txtSearch.Text)
        End Sub

        Protected Sub tblEmp_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles tblEmp.PageIndexChanging
            tblEmp.PageIndex = e.NewPageIndex
            DataRefresh(Session("letter"))
        End Sub

      
        Protected Sub tblEmp_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tblEmp.SelectedIndexChanged
            Session("empid") = tblEmp.SelectedRow.Cells(0).Text
            'empcode.Value = tblEmp.SelectedRow.Cells(0).Text
            If pnlGeneral.Visible Then
                RefreshGeneral(tblEmp.SelectedRow.Cells(0).Text)
            End If
            If pnlPersonal.Visible Then
                RefreshPersonal(tblEmp.SelectedRow.Cells(0).Text)
            End If
            If pnlSalary.Visible Then
                RefreshSalary(tblEmp.SelectedRow.Cells(0).Text)
            End If
            If pnlIdentification.Visible Then
                RefreshIdentification(tblEmp.SelectedRow.Cells(0).Text)
            End If
            If pnlOption.Visible Then
                RefreshOption(tblEmp.SelectedRow.Cells(0).Text)
            End If
            If pnlDep.Visible Then
                RefreshDep(tblEmp.SelectedRow.Cells(0).Text)
            End If
            If pnlAccountability.Visible Then
                RefreshAccountability(tblEmp.SelectedRow.Cells(0).Text)
            End If
            If pnlEmpSib.Visible Then
                RefreshSib(tblEmp.SelectedRow.Cells(0).Text)
            End If

            If pnlemprel.Visible Then
                RefreshRel(tblEmp.SelectedRow.Cells(0).Text)
            End If


            If pnlLicense.Visible Then
                RefreshLic(tblEmp.SelectedRow.Cells(0).Text)
            End If
            If pnlEmployment.Visible Then
                RefreshHist(tblEmp.SelectedRow.Cells(0).Text)
            End If
            If pnlCareer.Visible Then
                RefreshCareer(tblEmp.SelectedRow.Cells(0).Text)
            End If
            If pnlSchool.Visible Then
                RefreshSchool(tblEmp.SelectedRow.Cells(0).Text)
            End If
            If pnlTraining.Visible Then
                RefreshTraining(tblEmp.SelectedRow.Cells(0).Text)
            End If
            If pnlLeave.Visible Then
                RefreshLeave(tblEmp.SelectedRow.Cells(0).Text)
            End If
            If pnlCommend.Visible Then
                RefreshViolateCommend(tblEmp.SelectedRow.Cells(0).Text, _
                    IIf(cmdAddViolateCommend.Text.IndexOf("Violation") > 0, "violate", "commend"))
            End If
        End Sub
        Public Function GetURL(ByVal pField As String) As String
            Return "uploadimage.aspx?id=" & IIf(IsDBNull(pField), "", pField)
        End Function
    End Class
End Namespace