Imports denaro
Partial Class confirmtraining
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Public vDump As String = ""
    Dim c As New sqlclient.sqlconnection
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Session("returnaddr") = "trainingresults.aspx"
            Server.Transfer("index.aspx")
        End If
        If Not IsPostBack Then 'now build the reference code
            If Not CanRun(Session("caption"), Request.Item("id")) Then
                Session("denied") = "1"
                Server.Transfer("main.aspx")
                Exit Sub
            End If
            lblCaption.Text = "Confirm Attendance of Participants"
            DataRefresh()
        End If
    End Sub

    Protected Sub DataRefresh()
        c.ConnectionString = connStr
        Dim cm As New sqlclient.sqlcommand
        Dim dr As sqlclient.sqldatareader
        Dim vDate As String

        c.Open()
        cm.Connection = c

        cm.CommandText = "select py_emp_master.Emp_Cd,Emp_Lname,Emp_Fname,StartDateAttended from py_emp_master " & _
            ",hr_seminar_attendees where py_emp_master.Emp_Cd=hr_seminar_attendees.Emp_Cd and Seminar_No='" & _
            Session("semno") & "' order by Emp_Lname,Emp_Fname,Emp_Mname"
        dr = cm.ExecuteReader
        vDump = ""

        Do While dr.Read
            If Not IsDBNull(dr("StartDateAttended")) Then
                vDate = dr("StartDateAttended")
            Else
                vDate = Session("startdate")
            End If

            vDump += "<tr><td valign='top'><input id='chk" & dr("Emp_Cd") & "' name='chk" & dr("Emp_Cd") & _
                "' type='checkbox' /></td>" & _
                "<td valign='top'>" & dr("Emp_Cd") & "</td>" & _
                "<td valign='top'>" & dr("Emp_Lname") & "</td>" & _
                "<td valign='top'>" & dr("Emp_Fname") & "</td>" & _
                "<td valign='top'><input type='text' style='width: 81px' id='txtstar" & dr("Emp_Cd") & "' name='txtstart" & _
                dr("Emp_Cd") & "' value='" & vDate & "' class='label' /></td>" & _
                "<td valign='top'><input type='text' style='width: 81px' id='txtend" & dr("Emp_Cd") & "' name='txtend" & _
                dr("Emp_Cd") & "' value='" & Session("enddate") & "' class='label' /></td>" & _
                "<td valign='top'><input type='text' style='width: 81px' id='txtfee" & dr("Emp_Cd") & "' name='txtfee" & _
                dr("Emp_Cd") & "' value='" & Session("fee") & "' class='label' /></td>" & _
                "<td valign='top'><textarea style='width: 256px; height: 44px' id='txtinfo" & dr("Emp_Cd") & "' name='txtinfo" & _
                dr("Emp_Cd") & "' class='label'></textarea></td></tr>"
        Loop
        dr.Close()
        cm.Dispose()
        c.Close()
    End Sub

    Protected Sub cmdReturn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.Click
        Session.Remove("semno")
        Session.Remove("startdate")
        Server.Transfer("trainingresults.aspx")
    End Sub

    Protected Sub cmdSelectAttendees_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSelectAttendees.Click
        c.ConnectionString = connStr
        Dim cm As New sqlclient.sqlcommand
        Dim dr As sqlclient.sqldatareader
        Dim vDate As String = ""
        c.Open()
        cm.Connection = c

        cm.CommandText = "select py_emp_master.Emp_Cd,Emp_Lname,Emp_Fname,StartDateAttended from py_emp_master " & _
            ",hr_seminar_attendees where py_emp_master.Emp_Cd=hr_seminar_attendees.Emp_Cd and Seminar_No='" & _
            Session("semno") & "' order by Emp_Lname,Emp_Fname,Emp_Mname"
        dr = cm.ExecuteReader
        vDump = ""
        Do While dr.Read
            If Not IsDBNull(dr("StartDateAttended")) Then
                vDate = dr("StartDateAttended")
            Else
                vDate = Session("startdate")
            End If
            vDump += "<tr><td valign='top'><input id='chk" & dr("Emp_Cd") & "' name='chk" & dr("Emp_Cd") & _
                "' type='checkbox' checked='checked' /></td>" & _
                "<td valign='top'>" & dr("Emp_Cd") & "</td>" & _
                "<td valign='top'>" & dr("Emp_Lname") & "</td>" & _
                "<td valign='top'>" & dr("Emp_Fname") & "</td>" & _
                "<td valign='top'><input type='text' style='width: 81px' id='txtstar" & dr("Emp_Cd") & "' name='txtstart" & _
                dr("Emp_Cd") & "' value='" & vDate & "' /></td>" & _
                "<td valign='top'><input type='text' style='width: 81px' id='txtend" & dr("Emp_Cd") & "' name='txtend" & _
                dr("Emp_Cd") & "' value='" & Session("enddate") & "' /></td>" & _
                "<td valign='top'><input type='text' style='width: 81px' id='txtfee" & dr("Emp_Cd") & "' name='txtfee" & _
                dr("Emp_Cd") & "' value='" & Session("fee") & "' /></td>" & _
                "<td valign='top'><textarea style='width: 256px; height: 44px' id='txtinfo" & dr("Emp_Cd") & "' name='txtinfo" & _
                dr("Emp_Cd") & "'></textarea></td></tr>"
        Loop
        dr.Close()
        cm.Dispose()
        c.Close()
    End Sub

    Protected Sub cmdDeselectAttendees_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDeselectAttendees.Click
        c.ConnectionString = connStr
        Dim cm As New sqlclient.sqlcommand
        Dim dr As sqlclient.sqldatareader
        Dim vDate As String = ""
        c.Open()
        cm.Connection = c

        cm.CommandText = "select py_emp_master.Emp_Cd,Emp_Lname,Emp_Fname,StartDateAttended from py_emp_master " & _
            ",hr_seminar_attendees where py_emp_master.Emp_Cd=hr_seminar_attendees.Emp_Cd and Seminar_No='" & _
            Session("semno") & "' order by Emp_Lname,Emp_Fname,Emp_Mname"

        dr = cm.ExecuteReader
        vDump = ""
        Do While dr.Read
            If Not IsDBNull(dr("StartDateAttended")) Then
                vDate = dr("StartDateAttended")
            Else
                vDate = Session("startdate")
            End If
            vDump += "<tr><td valign='top'><input id='chk" & dr("Emp_Cd") & "' name='chk" & dr("Emp_Cd") & _
                "' type='checkbox' /></td>" & _
                "<td valign='top'>" & dr("Emp_Cd") & "</td>" & _
                "<td valign='top'>" & dr("Emp_Lname") & "</td>" & _
                "<td valign='top'>" & dr("Emp_Fname") & "</td>" & _
                "<td valign='top'><input type='text' style='width: 81px' id='txtstar" & dr("Emp_Cd") & "' name='txtstart" & _
                dr("Emp_Cd") & "' value='" & vDate & "' /></td>" & _
                "<td valign='top'><input type='text' style='width: 81px' id='txtend" & dr("Emp_Cd") & "' name='txtend" & _
                dr("Emp_Cd") & "' value='" & Session("enddate") & "' /></td>" & _
                "<td valign='top'><input type='text' style='width: 81px' id='txtfee" & dr("Emp_Cd") & "' name='txtfee" & _
                dr("Emp_Cd") & "' value='" & Session("fee") & "' /></td>" & _
                "<td valign='top'><textarea style='width: 256px; height: 44px' id='txtinfo" & dr("Emp_Cd") & "' name='txtinfo" & _
                dr("Emp_Cd") & "'></textarea></td></tr>"
        Loop
        dr.Close()
        cm.Dispose()
        c.Close()
    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        c.ConnectionString = connStr
        Dim cExec As New sqlclient.sqlconnection(connStr)
        Dim cm As New sqlclient.sqlcommand
        Dim cmExec As New sqlclient.sqlcommand
        Dim dr As sqlclient.sqldatareader
        Dim vDate As String = ""
        Dim vFee As Decimal = 0

        c.Open()
        cExec.Open()
        cm.Connection = c
        cmExec.Connection = cExec

        cm.CommandText = "select py_emp_master.Emp_Cd,Emp_Lname,Emp_Fname,StartDateAttended from py_emp_master " & _
            ",hr_seminar_attendees where py_emp_master.Emp_Cd=hr_seminar_attendees.Emp_Cd and Seminar_No='" & _
            Session("semno") & "' order by Emp_Lname,Emp_Fname,Emp_Mname"

        dr = cm.ExecuteReader
        vDump = ""
        Do While dr.Read
            cmExec.CommandText = "update hr_seminar_attendees set StartDateAttended='" & _
                Format(CDate(Request.Form("txtstart" & dr("Emp_Cd"))), "yyyy/MM/dd") & _
                "', Attended=1,EndDateAttended='" & _
                Format(CDate(Request.Form("txtend" & dr("Emp_Cd"))), "yyyy/MM/dd") & _
                "',Remarks='" & Request.Form("txtinfo" & dr("Emp_Cd")).ToString.Replace("'", "''") & _
                "' where Seminar_No='" & Session("semno") & "' and Emp_Cd='" & dr("Emp_Cd") & "'"
            cmExec.ExecuteNonQuery()
            cmExec.CommandText = "delete from hr_emp_seminar where Emp_Id='" & _
                dr("Emp_Cd") & "' and Sem_No='" & Session("semno") & _
                "' and From_Date='" & Format(CDate(Request.Form("txtstart" & dr("Emp_Cd"))), "yyyy/MM/dd") & "'"
            cmExec.ExecuteNonQuery()

            If Not IsNumeric(Request.Form("txtfee" & dr("Emp_Cd"))) Then
                vFee = 0
            Else
                vFee = Val(Request.Form("txtfee" & dr("Emp_Cd")))
            End If

            cmExec.CommandText = "insert into hr_emp_seminar (Emp_Id,Sem_No,From_Date,To_Date,Other_Info,Fee) " & _
                "values ('" & dr("Emp_Cd") & "','" & Session("semno") & "','" & _
                Format(CDate(Request.Form("txtstart" & dr("Emp_Cd"))), "yyyy/MM/dd") & "','" & _
                Format(CDate(Request.Form("txtend" & dr("Emp_Cd"))), "yyyy/MM/dd") & "','" & _
                Request.Form("txtinfo" & dr("Emp_Cd")) & "'," & _
                Request.Form("txtfee" & dr("Emp_Cd")) & ")"
            cmExec.ExecuteNonQuery()
        Loop
        dr.Close()
        cm.Dispose()
        cmExec.Dispose()
        c.Close()
        cExec.Close()
        cExec.Dispose()
        vScript = "alert('Changes were successfully saved.');"
    End Sub
End Class
