Imports denaro
Partial Class applicantwork
    Inherits System.Web.UI.Page
    Dim c As New sqlclient.sqlconnection
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If
        If Not IsPostBack Then
            lblcaption.text = "Applicant's Work History"
            c.ConnectionString = connStr
            Dim da As New sqlclient.sqlDataAdapter("select From_Date as FromDate, " & _
                "To_Date as ToDate,Employer,Position,Annual_Salary," & _
                "Accomplishments,[Function],Address,Nature,GovServ from hr_applicant_employment_hist " & _
                "where Emp_Id='" & Session("applicantno") & "' order by From_Date Desc", c)
            Dim ds As New DataSet

            da.Fill(ds, "employment")
            tblwork.DataSource = ds.Tables("employment")
            tblwork.DataBind()
            da.Dispose()
            ds.Dispose()
            If tblwork.Rows.Count = 0 Then
                Response.Write("NO WORK HISTORY FOUND!")
            End If
        End If
    End Sub
End Class
