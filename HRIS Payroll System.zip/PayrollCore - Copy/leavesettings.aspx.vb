﻿Imports denaro
Partial Class leavesettings
    Inherits System.Web.UI.Page
    Public vscript As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        

        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
        End If

        If Not CanRun(Session("caption"), Request.Item("id")) Then
            Session("denied") = "1"
            Server.Transfer("main.aspx")
            Exit Sub
        End If


        datarefreshleaveref()
    End Sub

    Private Sub datarefreshleaveref()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim da As SqlClient.SqlDataAdapter
        Dim ds As New DataSet

        Try
            da = New SqlClient.SqlDataAdapter("select * from py_leave_ref", c)

            da.Fill(ds, "py_leave_ref")
            tblLeaveref.DataSource = ds.Tables("py_leave_ref")
            tblLeaveref.DataBind()
            da.Dispose()
            ds.Dispose()
            c.Dispose()
        Catch ex As SqlClient.SqlException
            vscript = "alert(""" & ex.Message.Replace(vbCrLf, "").Replace("'", "") & """);"
        End Try

    End Sub

    Protected Sub tblLeaveref_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles tblLeaveref.PageIndexChanging
        tblLeaveref.PageIndex = e.NewPageIndex
        datarefreshleaveref()
    End Sub

    Protected Sub tblLeaveref_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tblLeaveref.SelectedIndexChanged
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vscript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        cm.Connection = c

        cm.CommandText = "select * from py_leave_ref where Leave_Cd='" & tblLeaveref.SelectedRow.Cells(0).Text & "'"
        Try
            rs = cm.ExecuteReader
            If rs.Read Then
                btnDelete.Enabled = rs("Frozen") = 0

                txtmatrixLeaveCd.Value = tblLeaveref.SelectedRow.Cells(0).Text
                txtvalue.Value = tblLeaveref.SelectedRow.Cells(0).Text
                txtLeaveCd.Text = tblLeaveref.SelectedRow.Cells(0).Text
                txtDescription.Text = tblLeaveref.SelectedRow.Cells(1).Text

                chkAlwaysPaid.Checked = rs("AlwaysPaid") = 1
                chkNeesRequest.Checked = rs("NeedsRequest") = 1

                txtMaxCredit.Text = rs("MaxCredit")
                txtCashLeaveCredit.Text = rs("CashLeaveCredit")
                txtEffectivity.Text = rs("EffectivityMonths")
                txtConversionBasis.Text = IIf(rs("ConversionBasis") = 0, "First of", "Excess of")
                txtLeaveMultiple.Text = rs("FilingMultipleMins")

                Select Case rs("CreditFreq")
                    Case 1
                        txtCreditFreq.Text = "Monthly"
                    Case 3
                        txtCreditFreq.Text = "Quarterly"
                    Case 6
                        txtCreditFreq.Text = "Semi-Annually"
                    Case Else
                        txtCreditFreq.Text = "Annually"
                End Select

                Select Case rs("ResetBasis")
                    Case 0
                        txtResetBasis.Text = "Fiscal Year"
                    Case 2
                        txtResetBasis.Text = "Anniv. on Date Hired"
                    Case 3
                        txtResetBasis.Text = "Anniv. on Date Regularized"
                End Select

                If rs("AvailType") = 2 Then
                    txtAvailmentType.Text = "Date Regularization"
                Else
                    txtAvailmentType.Text = "Date Hired"
                End If

                If rs("EarnedType") = 1 Then
                    txtEarnedType.Text = "Earned every 1st day of the month"
                Else
                    txtEarnedType.Text = "Advance Crediting"
                End If

                If IsDBNull(rs("ExpiryDate")) Then
                    txtExpDate.Text = ""
                Else
                    txtExpDate.Text = Format(rs("ExpiryDate"), "MM/dd/yyyy")
                End If

                Leavematrix(c)
            End If
            rs.Close()
        Catch ex As SqlClient.SqlException
            vscript = "alert('Error occurred while trying to retrieve Leave Reference information. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            c.Dispose()
            cm.Dispose()
        End Try
    End Sub

    Protected Sub btnClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub btnDelete_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        If tblLeaveref.SelectedIndex >= 0 Then
            Dim c As New SqlClient.SqlConnection(connStr)
            Dim cm As New SqlClient.SqlCommand

            cm.Connection = c
            cm.CommandText = "delete from py_leave_ref where Leave_Cd='" & _
                tblLeaveref.SelectedRow.Cells(0).Text & "'"
            Try
                c.Open()
                cm.ExecuteNonQuery()
                c.Close()
                vscript = "alert('Record successfully deleted.');"
                datarefreshleaveref()
            Catch ex As DataException
                vscript = "alert('An error occurred while trying to delete the selected record. ');"
            End Try
            c.Dispose()
            cm.Dispose()
        Else
            vscript = "alert('Please select item first.');"
        End If
    End Sub

    Private Sub Leavematrix(ByRef c As SqlClient.SqlConnection)
        Dim da As New SqlClient.SqlDataAdapter
        Dim ds As New DataSet
        Dim vleaveCd As String = tblLeaveref.SelectedRow.Cells(0).Text

        Try
            da = New SqlClient.SqlDataAdapter("select LeaveCd,EmploymentType,GroupCd,YearFrom,YearTo," & _
                                              "Credits from py_leave_table where LeaveCd='" & _
                                              vleaveCd & "' order by EmploymentType,YearFrom", c)
            da.Fill(ds, "py_leave_matrix")
            grdLeaveMatrix.DataSource = ds.Tables("py_leave_matrix")
            grdLeaveMatrix.DataBind()
        Catch ex As SqlClient.SqlException
            vscript = "alert(""" & ex.Message.Replace(vbCrLf, "").Replace("'", "") & """);"
        Finally
            da.Dispose()
            ds.Dispose()
        End Try
    End Sub

    Protected Sub grdLeaveMatrix_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles grdLeaveMatrix.PageIndexChanging
        grdLeaveMatrix.PageIndex = e.NewPageIndex
        Dim c As New SqlClient.SqlConnection(connStr)
        c.Open()
        Leavematrix(c)
        c.Close()
        c.Dispose()
    End Sub

    Protected Sub grdLeaveMatrix_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdLeaveMatrix.SelectedIndexChanged
        txtmatrixLeaveCd.Value = tblLeaveref.SelectedRow.Cells(0).Text
        txtmatrixType.Value = grdLeaveMatrix.SelectedRow.Cells(1).Text
        txtGroupCd.Value = grdLeaveMatrix.SelectedRow.Cells(2).Text
        txtYearFrom.Value = grdLeaveMatrix.SelectedRow.Cells(3).Text
    End Sub

    Protected Sub btnLeaveDelete_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnLeaveDelete.Click
        If grdLeaveMatrix.SelectedIndex >= 0 Then

            Dim c As New SqlClient.SqlConnection(connStr)
            Dim cm As New SqlClient.SqlCommand

            cm.Connection = c
            cm.CommandText = "delete from py_leave_table where LeaveCd='" & _
                tblLeaveref.SelectedRow.Cells(0).Text & "' and Employmenttype='" & _
                grdLeaveMatrix.SelectedRow.Cells(1).Text & "' and GroupCd='" & _
                grdLeaveMatrix.SelectedRow.Cells(2).Text & "' and YearFrom=" & grdLeaveMatrix.SelectedRow.Cells(3).Text

            Try
                c.Open()
                cm.ExecuteNonQuery()
                c.Close()
                vscript = "alert('Record successfully deleted in leave matrix.');"
            Catch ex As DataException
                vscript = "alert('An error occurred while trying to delete the selected record. ');"
            End Try
            c.Dispose()
            cm.Dispose()
        Else
            vscript = "alert('Please select item first.');"
        End If
    End Sub

    
End Class
