Imports denaro
Partial Class modifyuser
    Inherits System.Web.UI.Page
    Dim c As New sqlclient.sqlconnection
    Public vScript As String = "document.getElementById('txtUserId').focus();"
    Protected Sub cmdCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        Session.Remove("mode")
        Session.Remove("user_id")
        Server.Transfer("upm.aspx")
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("login.aspx")
            Exit Sub
        End If
        If Not IsPostBack Then
            lblcaption.text = "Add/Modify User"
            If Session("mode") = "e" Then 'edit mode
                Dim cm As New sqlclient.sqlcommand
                Dim dr As sqlclient.sqldatareader
                Dim vStr As String = "select * from user_list where User_Id='" & Session("user_id") & "'"

                c.ConnectionString = connStr
                c.Open()
                cm.Connection = c
                cm.CommandText = vStr
                dr = cm.ExecuteReader
                If dr.Read Then
                    txtUserId.Text = dr("User_Id")
                    txtFullName.Text = dr("FullName")
                    txtPosition.Text = dr("Position")
                    txtAltUid.Text = dr("Alt_Userid")
                    cmbLevel.SelectedValue = dr("UserLevel")

                    Session("oldval") = "User_Id=" & txtUserId.Text & _
                        "|FullName=" & txtFullName.Text & _
                        "|Position=" & txtPosition.Text & _
                        "|UserLevel=" & cmbLevel.SelectedValue
                End If
                dr.Close()
                cm.Dispose()
                c.Close()
            End If
        End If
    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        Dim cm As New sqlclient.sqlcommand
        Dim vType As String = "ADD"

        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c
        If Session("mode") = "a" Then        'add mode
            cm.CommandText = "insert into user_list (User_Id,FullName,Position,UserLevel,Alt_Userid) values ('" & _
                txtUserId.Text & "','" & txtFullName.Text & "','" & txtPosition.Text & _
                "'," & cmbLevel.SelectedValue & ", '" & txtAltUid.Text & "')"

            Session("oldval") = ""
            Session("newval") = "User_Id=" & txtUserId.Text & _
                "|FullName=" & txtFullName.Text & _
                "|Position=" & txtPosition.Text & _
                "|AltUid=" & txtAltUid.Text & _
                "|UserLevel=" & cmbLevel.SelectedValue
        Else                                'edit mode
            vType = "EDIT"
            cm.CommandText = "update user_list set User_Id='" & txtUserId.Text & _
                "',FullName='" & txtFullName.Text & _
                "',Position='" & txtPosition.Text & _
                "',Alt_Userid='" & txtAltUid.Text & _
                "',UserLevel=" & cmbLevel.SelectedValue & _
                " where User_Id='" & Session("user_id") & "'"

            Session("newval") = "User_Id=" & txtUserId.Text & _
                "|FullName=" & txtFullName.Text & _
                "|Position=" & txtPosition.Text & _
                "|AltUid=" & txtAltUid.Text & _
                "|UserLevel=" & cmbLevel.SelectedValue
        End If
        cm.ExecuteNonQuery()
        EventLog(Session("uid"), Request.ServerVariables("REMOTE_ADDR"), vType, Session("oldval"), Session("newval"), "User Profile of " & txtUserId.Text, "User Profiles")
        vScript = "alert('Record was successfully saved.');"
        Server.Transfer("upm.aspx")
    End Sub

    Protected Sub cmdSave_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Init
        cmdSave.Attributes.Add("onclick", "return postvalidate();")
    End Sub
End Class
