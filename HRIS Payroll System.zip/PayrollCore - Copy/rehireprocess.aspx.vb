﻿Imports denaro.fis
Partial Class rehireprocess
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Public vDetail As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            vScript = "alert('Your login session has expired. Please re-login again.'); window.close();"
            Exit Sub
        End If

        If Not IsPostBack Then
            If Session("id") = "" Then
                vScript = "alert('You must first select an employee to re-hire.'); window.close();"
                Exit Sub
            End If

            Dim c As New sqlclient.sqlConnection(connStr)
            Dim cm As New sqlclient.sqlCommand
            Dim rs As sqlclient.sqlDataReader
            Dim vSql As String = ""
            Dim i As Integer
            Dim vClass As String = "odd"
            Dim vYear() As Decimal
            Dim vGrossTaxable() As Decimal
            Dim vGrossNonTax() As Decimal
            Dim v13thTaxable() As Decimal
            Dim v13thNonTax() As Decimal
            Dim vContribution() As Decimal
            Dim vTaxWithheld() As Decimal

            ReDim vYear(0)
            ReDim vGrossTaxable(0)
            ReDim vGrossNonTax(0)
            ReDim v13thTaxable(0)
            ReDim v13thNonTax(0)
            ReDim vContribution(0)
            ReDim vTaxWithheld(0)

            Try
                c.Open()
            Catch ex As sqlclient.sqlException
                vScript = "alert('An error has occured while trying to connect to database. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                c.Dispose()
                cm.Dispose()
                Exit Sub
            End Try

            cm.Connection = c
            cm.CommandText = "select Emp_Cd,Emp_Lname,Emp_Fname,Emp_Mname from py_emp_master where Emp_Cd='" & _
                Session("id") & "'"
            Try
                rs = cm.ExecuteReader
                If rs.Read Then
                    txtOldId.Text = rs("Emp_Cd")
                    txtName.Text = rs("Emp_Lname") & ", " & rs("Emp_Fname") & " " & rs("Emp_Mname")
                End If
                rs.Close()
            Catch ex As sqlclient.sqlException
                vScript = "alert('An error has occurred while trying to retrieve Employee master file. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                c.Close()
                c.Dispose()
                cm.Dispose()
                Exit Sub
            End Try

            Try
                'count number of records
                vSql = "select count(distinct year(paydate)) as TotRecords from py_report where emp_cd='" & txtOldId.Text & "'"
                cm.CommandText = vSql
                rs = cm.ExecuteReader
                If rs.Read Then
                    If Not IsDBNull(rs("TotRecords")) Then
                        If rs("TotRecords") > 0 Then
                            ReDim vGrossTaxable(rs("TotRecords"))
                            ReDim vGrossNonTax(rs("TotRecords"))
                            ReDim v13thTaxable(rs("TotRecords"))
                            ReDim v13thNonTax(rs("TotRecords"))
                            ReDim vContribution(rs("TotRecords"))
                            ReDim vTaxWithheld(rs("TotRecords"))
                        End If
                    End If
                End If
                rs.Close()
                If vGrossTaxable.Length > 0 Then    'with records
                    vSql = "select year(PayDate) as Yr,sum(BasicRate) as BasicPay, sum(Absent+Tardiness) as Absences, sum(Ot) as OT," & _
                    "sum(ACA) as ACA, sum(RATA) as RATA, sum(PERA) As PERA, sum(MealAllow) as Meal,sum(With_Tax) as Tax," & _
                    "sum(Sss_Per+Pagibig_Per+Medicare_Per) as Contribution "

                    For i = 1 To 60
                        vSql += ",sum(Other_Incent" & i & ") as Incent" & i
                    Next

                    vSql += " from py_report where Emp_Cd='" & txtOldId.Text & "' group by year(PayDate) "

                    cm.CommandText = vSql
                    rs = cm.ExecuteReader
                    i = 0
                    Response.Write(UBound(vGrossTaxable))

                    'Do While rs.Read
                    '    vYear(i) = rs("Yr")
                    '    vTaxWithheld(i) = IIf(Not IsDBNull(rs("Tax")), rs("Tax"), 0)
                    '    vContribution(i) = IIf(Not IsDBNull(rs("Contribution")), rs("Contribution"), 0)
                    '    i += 1
                    'Loop
                    'rs.Close()
                    vDetail = ""

                    For i = 0 To UBound(vGrossTaxable)
                        vDetail += "<tr class='" & vClass & "'>" & _
                            "<td class='labelR'>" & vYear(i) & "</td>" & _
                            "<td class='labelR'>" & vGrossTaxable(i) & "</td>" & _
                            "<td class='labelR'>" & vGrossNonTax(i) & "</td>" & _
                            "<td class='labelR'>" & v13thNonTax(i) & "</td>" & _
                            "<td class='labelR'>" & v13thTaxable(i) & "</td>" & _
                            "<td class='labelR'>" & vContribution(i) & "</td>" & _
                            "<td class='labelR'>" & vTaxWithheld(i) & "</td></tr>"
                        vClass = IIf(vClass = "odd", "even", "odd")
                    Next
                End If
            Catch ex As sqlclient.sqlException
                vScript = "alert('An error has occurred while trying to retrieve Employee''s transaction history. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            Finally
                c.Close()
                c.Dispose()
                cm.Dispose()
            End Try
        End If
    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        If Page.IsValid Then

        End If
    End Sub

    Protected Sub vldEmp_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles vldEmp.ServerValidate
        Dim c As New sqlclient.sqlConnection(connStr)
        Dim cm As New sqlclient.sqlCommand
        Dim rs As sqlclient.sqlDataReader

        Try
            c.Open()
        Catch ex As sqlclient.sqlException
            vScript = "alert('An error has occurred while trying to connect to server. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        cm.Connection = c
        Try
            cm.CommandText = "select Emp_Cd from py_emp_master where Emp_Cd='" & txtNewId.Text & "'"
            rs = cm.ExecuteReader
            If rs.HasRows Then
                vScript = "alert('The new Id you entered is already existing in the master file. Please enter a different ID.');"
                args.IsValid = False
            Else
                args.IsValid = True
            End If
            rs.Close()
        Catch ex As sqlclient.sqlException
            vScript = "alert('An error has occurred while trying to retrieve Employee master file. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            cm.Dispose()
            c.Dispose()
        End Try
    End Sub
End Class
