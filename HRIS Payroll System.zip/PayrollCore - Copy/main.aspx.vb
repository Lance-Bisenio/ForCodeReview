Imports System.Data
Imports denaro.fis
Partial Class main
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Public vNotice As String = ""
    Public HREMAIL As String = System.Configuration.ConfigurationManager.AppSettings.Get("hremail")
    Public FROMEMAIL As String = System.Configuration.ConfigurationManager.AppSettings.Get("fromemail")

    'Public HOSTSERVER As String = System.Configuration.ConfigurationManager.AppSettings.Get("hostserver")
    'Public HOMEPAGE As String = System.Configuration.ConfigurationManager.AppSettings.Get("homepage")
    'Public HREMAIL As String = System.Configuration.ConfigurationManager.AppSettings.Get("hremail")
    'Public HOSTNAME As String = System.Configuration.ConfigurationManager.AppSettings.Get("hostname")

    'Public FROMNAME As String = System.Configuration.ConfigurationManager.AppSettings.Get("fromname")
    'Public PORT As Integer = Val(System.Configuration.ConfigurationManager.AppSettings.Get("port"))

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If
        If Session("denied") = "1" Then
            'vScript = "alert('Sorry, but you are not allowed to access this menu.');"
            vScript = "alert('Sorry, but you are not licensed to use this module. " & _
                "Please contact Evolve Software Solutions at ***-**** for more information.');"
            Session.Remove("denied")
            Exit Sub
        End If
        If Not IsPostBack Then
            Dim c As New SqlClient.SqlConnection(connStr)
            Dim cm As New SqlClient.SqlCommand
            Dim cmRef As New SqlClient.SqlCommand
            Dim cmRefSub As New SqlClient.SqlCommand
            Dim rs As SqlClient.SqlDataReader
            Dim rsRef As SqlClient.SqlDataReader

            Dim vName As String = ""
            Dim vCategory As String = ""

            cm.Connection = c
            cmRef.Connection = c
            cmRefSub.Connection = c

            Try
                c.Open()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                c.Dispose()
                cm.Dispose()
                cmRef.Dispose()
                cmRefSub.Dispose()
                Exit Sub
            End Try


            'cm.CommandText = "select TOP 1 LastUpdate from currency_ref "
            'rs = cm.ExecuteReader
            'If rs.Read Then
            '    If CDate(Format(rs("LastUpdate"), "yyyy/MM/dd")) < CDate(Format(Now, "yyyy/MM/dd")) Then
            '        'Server.Transfer("forex.aspx")
            '        'vScript = "winforex=window.open('forex.aspx','winforex','top=100,left=100,width=640,height=480'); winforex.focus();"
            '        rs.Close()
            '        c.Close()
            '        cm.Dispose()
            '        c.Dispose()
            '        Exit Sub
            '    End If
            'End If
            'rs.Close()

            vNotice = "<ul>"
            If CanRun(Session("caption"), "999") Then
                'check any new BAP enrollees
                cm.CommandText = "select * from hr_dependents where BapEnrolled=1 and Synchronized=0"
                rs = cm.ExecuteReader
                If rs.Read Then
                    vNotice = "<li><a href='bappost.aspx'><font size=2pt;>There are new BAP enrollees. Click me to set the deduction schedule...</font></a></li>"
                End If
                rs.Close()
            End If

            If CanRun(Session("caption"), "998") Then
                'check for loan applications
                cm.CommandText = "SELECT 1 FROM hr_loan_application WHERE Synchronized=0 AND DateApproved IS NOT NULL AND Void = 0"
                rs = cm.ExecuteReader
                If rs.Read Then
                    vNotice += "<li><a href='loanpost.aspx'><font size=2pt;>There are new approved loans pending for posting to deduction schedule...</font></a></li>"
                End If
                rs.Close()
            End If

            If CanRun(Session("caption"), "997") Then
                'check for donation applications

            End If

            'check messages posted by employees
            cm.CommandText = "select * from hr_feedback where Replied is null and exists (select Emp_Cd from py_emp_master where " & _
               "py_emp_master.Emp_Cd=hr_feedback.Emp_Cd) and exists (select CatgId from hr_feedback_category where " & _
               "hr_feedback_category.CatgId=hr_feedback.CatgId and Target_Emp_Cd like '%" & Session("uid") & _
               "%') order by TranDate, CatgId, Emp_Cd"
            rs = cm.ExecuteReader
            Do While rs.Read
                cmRef.CommandText = "select Emp_Lname,Emp_Fname from py_emp_master where Emp_Cd='" & _
                    rs("Emp_Cd") & "'"
                rsRef = cmRef.ExecuteReader
                vName = "Unknown"
                If rsRef.Read Then
                    vName = rsRef("Emp_Lname") & ", " & rsRef("Emp_Fname")
                End If
                rsRef.Close()
							
                cmRef.CommandText = "select Descr from hr_feedback_category where CatgId='" & rs("CatgId") & "'"
                rsRef = cmRef.ExecuteReader
                vCategory = "Unknown"
                If rsRef.Read Then
                    vCategory = rsRef("Descr")
                End If
                rsRef.Close()
                vNotice += "<li>You have message from <label style='color:#3399FF;'>" & vName & _
                    "</label> posted on <label style='color:green;'>" & rs("TranDate") & _
                    "</label> under Category <label style='color:#00CCCC;'>" & vCategory & _
                    "</label>. Click <a href='javascript:feedback(&quot;" & rs("CatgId") & _
                    "&quot;,&quot;" & rs("Emp_Cd") & "&quot;,&quot;" & rs("TranDate") & _
                    "&quot;);'>here</a> to view.</li>"
            Loop
            rs.Close()
            vNotice += "</ul>"


            '==========================================================================================================================
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:  LANCE BISENIO                                       ''
            '' DATE MODIFIED: 07/30/2012                                         ''
            '' PURPOSE: TO EMAIL ALL END OF CONTRACT 2MONTHS AND 1 MONTHS BEFORE ''
            ''                                                                   ''
            '' ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '==========================================================================================================================
            If CanRun(Session("caption"), "996") Then

                Dim vEOC As Date
                Dim vAppNo As String = ""
                Dim vSubject As String = ""
                Dim vBody As String = ""
                Dim vList As String = ""
                Dim vMode As String = "close"
                Dim vClass As String = "odd"

                vList += "<html><head><title></title><link href='../redtheme/red.css' rel='stylesheet' type='text/css' /></head>"
                vList += "<body><center><br /><table  style='width:95%; border-collapse:collapse;' border='1'  align='center'>"

                vList += "<tr class='titleBar' style='font-size:11px'><th colspan='3'>End of Contract List</th></tr>"
                vList += "<tr class='titleBar' style='font-size:11px'><th>Employee Name</th><th>Date Hired</th><th>EOC Date</th></tr>"

                cm.CommandText = "select Emp_Cd, Emp_LName+', '+Emp_Fname as EmpName, Start_Date, EOCDate from py_emp_master where EOCDate is not null"
                rs = cm.ExecuteReader
                'vList += "Employee List" & Space(27) & "Date Hired" & Space(10) & "EOC Date" & vbCrLf & vbCrLf

                Do While rs.Read
                    vList += "<tr class='" & vClass & "'>"
                    vBody = "Please be inform you that " & rs("EmpName") & " will End of Contract on " & rs("EOCDate") & ""
                    vAppNo = "EOC-" & rs("Emp_Cd") & "-" & Format(Now(), "MMddyyyy")

                    cmRef.CommandText = "select ApplicationNo from email_queue where ApplicationNo = '" & vAppNo & "'"
                    rsRef = cmRef.ExecuteReader

                    If rsRef.Read Then

                    Else
                        vEOC = CDate(rs("EOCDate")).AddMonths(-2)
                        If Format(vEOC, "MM/dd/yyyy") = Format(Now, "MM/dd/yyyy") Then
                            cmRefSub.CommandText = "insert into email_queue (TransDate, ApplicationNo, FromEmail, ToEmail, Subject, Message) values " & _
                                                    "('" & Format(Now(), "MM/dd/yyyy") & "', '" & vAppNo & "', '" & FROMEMAIL & _
                                                    "', '" & HREMAIL & "', '" & vSubject & "','" & vBody & "')"
                            cmRefSub.ExecuteNonQuery()
                            vMode = "OpenPop"
                        End If

                        vEOC = CDate(rs("EOCDate")).AddMonths(-1)
                        If Format(vEOC, "MM/dd/yyyy") = Format(Now, "MM/dd/yyyy") Then
                            cmRefSub.CommandText = "insert into email_queue (TransDate, ApplicationNo, FromEmail, ToEmail, Subject, Message) values " & _
                                                    "('" & Format(Now(), "MM/dd/yyyy") & "', '" & vAppNo & "', '" & FROMEMAIL & _
                                                    "', '" & HREMAIL & "', '" & vSubject & "','" & vBody & "')"
                            cmRefSub.ExecuteNonQuery()
                            vMode = "OpenPop"
                        End If
                        vList += "<td class='labelL'>&nbsp;" & rs("EmpName") & "</td>"
                        vList += "<td class='labelC'>" & Format(rs("Start_Date"), "MM/dd/yyyy") & "</td>"
                        vList += "<td class='labelC'>" & Format(rs("EOCDate"), "MM/dd/yyyy") & "</td>"

                    End If
                    rsRef.Close()

                    vList += "</tr>"
                    vClass = IIf(vClass = "odd", "even", "odd")
                Loop
                rs.Close()
                vList += "</table></center></body></html>"

                If vMode = "OpenPop" Then
                    IO.File.WriteAllText(Server.MapPath(".") & "\downloads\" & Session.SessionID & "-EOD_List.html", vList)
                    vScript += "winlog = window.open('downloads/" & Session.SessionID & _
                            "-EOD_List.html','winlog','toolbar=no,resizable=yes,top=10,left=100,width=640,height=480'); winlog.focus();"
                End If

            End If
            '==========================================================================================================================

            '==========================================================================================================================
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:  LANCE BISENIO                                       ''
            '' DATE MODIFIED: 07/30/2012                                         ''
            '' PURPOSE: TO MONITORING THE LIST OF SERVICE CHARGE ELIGIBLE        ''
            ''                                                                   ''
            '' ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '==========================================================================================================================

            If CanRun(Session("caption"), "995") Then
                cm.CommandText = "select count(Emp_Cd) as vCtr " & _
                    "from py_emp_master where Date_Resign is null and SCMember = 0 " & _
                    "and '" & Format(Now(), "MM/dd/yyyy") & "' >= DATEADD(""MONTH"",1,start_date)"
                rs = cm.ExecuteReader

                rs.Read()
                If rs("vCtr") > 0 Then
                    vScript = "winforex=window.open('sc_eligible.aspx','winforex','top=100,left=100,width=640,height=480'); winforex.focus();"
                End If

                rs.Close()
            End If

            '==========================================================================================================================

            c.Close()
            cm.Dispose()
            cmRef.Dispose()
            cmRefSub.Dispose()
            c.Dispose()

        End If

    End Sub
End Class
