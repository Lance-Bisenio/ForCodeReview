﻿
Partial Class finalpay
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Protected Sub cmdSelectEmp_Click(sender As Object, e As EventArgs) Handles cmdSelectEmp.Click
        If txtEmpList.Value <> "" Then
            txtEmpList.Value = Mid(txtEmpList.Value, 1, Len(txtEmpList.Value) - 1)
            cmdSelectEmp.Text = "Select Employee (Ok)"
            cmdSelectEmp.BackColor = Color.Blue
            cmdSelectPayDate.Enabled = True
        Else
            cmdSelectEmp.BackColor = Nothing
            cmdSelectEmp.Text = "Select Employee"
            cmdSelectPayDate.Enabled = False
        End If
        Session("emplist") = txtEmpList.Value

        frmChild.Attributes("src") = "finalselectemp.aspx"
    End Sub

    Protected Sub cmdSelectPayDate_Click(sender As Object, e As EventArgs) Handles cmdSelectPayDate.Click
        If txtEmpList.Value <> "" Then
            cmdSelectEmp.BackColor = Color.Blue
            cmdSelectEmp.Text = "Select Employee (Ok)"
            Session("emplist") = txtEmpList.Value
            frmChild.Attributes("src") = "finalselectpaydate.aspx"
        Else
            cmdSelectEmp.BackColor = Nothing
            cmdSelectEmp.Text = "Select Employee"
            Session.Remove("emplist")
            vScript = "alert('You must first select an Employee to process.');"
        End If
    End Sub

    Protected Sub cmdOtherInc_Click(sender As Object, e As EventArgs) Handles cmdOtherInc.Click
        
        frmChild.Attributes("src") = "finalothinc.aspx"
    End Sub

    Protected Sub cmdOtherDed_Click(sender As Object, e As EventArgs) Handles cmdOtherDed.Click
        frmChild.Attributes("src") = "finalothded.aspx"
    End Sub

    Protected Sub cmd13th_Click(sender As Object, e As EventArgs) Handles cmd13th.Click
        
        frmChild.Attributes("src") = "final13th.aspx"
    End Sub

    Protected Sub cmdClose_Click(sender As Object, e As EventArgs) Handles cmdClose.Click
        Session.Remove("emplist")
        Session.Remove("paydate")
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub cmdSLVL_Click(sender As Object, e As EventArgs) Handles cmdSLVL.Click
        If Session("paydate") <> Nothing Then
            cmdSelectPayDate.Text = "Select Payout Date (" & Session("paydate") & ")"
            cmdSelectPayDate.BackColor = Color.Blue
            cmdSelectPayDate.Enabled = True
            cmdSLVL.Enabled = True
            frmChild.Attributes("src") = "finalvlsl.aspx"
        Else
            cmdSelectPayDate.Text = "Select Payout Date"
            cmdSelectPayDate.BackColor = Nothing
            cmdSelectPayDate.Enabled = False
            cmdSLVL.Enabled = False
            Session.Remove("paydate")
            vScript = "alsert('You need to select the Payout Date first.');"
        End If
    End Sub
End Class
