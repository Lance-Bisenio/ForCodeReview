﻿Imports denaro.fis
Partial Class finalselectemp
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Public vData As String = ""
    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Session("uid") = Nothing Or Session("uid") = "" Then
            vScript = "alert('Your login session has expired. Please re-login again to continue.'); parent.parent.window.location='login.aspx';"
            Exit Sub
        End If

        If Not IsPostBack Then
            DataRefresh()
        End If
    End Sub

    Protected Sub cmdSearch_Click(sender As Object, e As EventArgs) Handles cmdSearch.Click
        DataRefresh()
    End Sub

    Private Sub DataRefresh()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim vClass As String = "odd"
        Dim vList As String = ""
        Dim vFilter As String = ""

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        cm.Connection = c

        If txtSearch.Text.Trim <> "" Then
            vFilter = " and " & cmbSearchType.SelectedValue & " like '%" & txtSearch.Text & "%' "
        End If
        cm.CommandText = "select Emp_Cd,Emp_Lname,Emp_Fname,Emp_Mname,Date_Resign,Cleared from " & _
            "py_emp_master where Date_Resign is not null " & vFilter & " order by Emp_Lname,Emp_Fname"

        Try
            rs = cm.ExecuteReader
            vData = ""

            txtEmpList.Value = Session("emplist")
            Do While rs.Read
                vData += "<tr class='" & vClass & "'>" & _
                    "<td class='labelC'><input id='chk" & rs("Emp_Cd") & "' class='labelL' " & _
                        "type='checkbox' " & IIf(txtEmpList.Value.Contains(rs("Emp_Cd")), "checked='checked'", "") & " /></td>" & _
                    "<td class='labelL'>" & rs("Emp_Cd") & "</td>" & _
                    "<td class='labelL'>" & rs("Emp_Lname") & ", " & rs("Emp_Fname") & " " & rs("Emp_MName") & "</td>" & _
                    "<td class='labelC'>" & Format(rs("Date_Resign"), "MM/dd/yyyy") & "</td>" & _
                    "<td class='labelC'>" & IIf(rs("Cleared") = 1, "Yes", "No") & "</td></tr>"
                vList += rs("Emp_Cd") & ","
                vClass = IIf(vClass = "odd", "even", "odd")
            Loop
            rs.Close()
            If vList <> "" Then
                vList = Mid(vList, 1, Len(vList) - 1)
            End If
            txtEmpList.Value = vList
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to retrieve Employee record. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            cm.Dispose()
            c.Dispose()
        End Try
    End Sub
End Class
