﻿Imports denaro.fis
Partial Class rata
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Public vDump As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            vScript = "alert('Your login session has expired. Please re-login again.'); window.close();"
            Exit Sub
        End If
        If Not IsPostBack Then
            lblStartDate.Text = Request.Item("mf") & "/" & Request.Item("df") & "/" & Request.Item("yf")
            lblEndDate.Text = Request.Item("mt") & "/" & Request.Item("dt") & "/" & Request.Item("yt")
            lblRC.Text = Request.Item("rc")
            lblAgency.Text = Request.Item("ofc")
            lblDiv.Text = Request.Item("div")
            lblDept.Text = Request.Item("dept")
            lblSection.Text = Request.Item("section")
            lblUnit.Text = Request.Item("unit")
            txtPostDate.Text = lblEndDate.Text

            'generate target incentives
            BuildCombo("select Incentive_Cd,Descr from py_other_incentvs order by Descr", cmbIncentive)
            GenerateReport(False)
        End If
    End Sub
    Private Sub GenerateReport(ByVal pPost As Boolean)
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cmRef As New SqlClient.SqlCommand
        Dim cmXRef As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim rsRef As SqlClient.SqlDataReader
        Dim rsXRef As SqlClient.SqlDataReader
        Dim vFilter As String = ""
        Dim vData As New StringBuilder
        Dim vRow As String = "odd"
        Dim vEligibleDays As Decimal = 0
        Dim vRataProRata As Boolean = False
        Dim vMealProRata As Boolean = False
        Dim vRataDeductTardy As Boolean = False
        Dim vMealDeductTardy As Boolean = False
        Dim vRataDeductUT As Boolean = False
        Dim vMealDeductUT As Boolean = False
        Dim vRataStartTime As String = "00:00:00"
        Dim vRataEndTime As String = "23:59:59"
        Dim vMealStartTime As String = "00:00:00"
        Dim vMealEndTime As String = "23:59:59"
        Dim vMealMinHrs As Decimal = 0
        Dim vRataMinHrs As Decimal = 0
        Dim iTardy As Integer = 0
        Dim iUT As Integer = 0
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''
        ' '' MODIFIED BY:  VIC GATCHALIAN                     ''
        ' '' DATE MODIFIED: 10/25/2011                        ''
        ' '' PURPOSE:  TO COUNT THE NUMBER OF PAID LEAVES     ''
        ' ''           AND ABSENCES INCURRED BY THE EMPLOYEE  ''
        ' ''           AND SUBTRACT IT FROM ELIGIBLE DAYS     ''
        ' ''           TO COMPUTE THE MEAL AND TRANSPO        ''
        ' ''           ALLOWANCE.                             ''
        ' ''''''''''''''''''''''''''''''''''''''''''''''''''''''
        Dim iLeaves As Integer = 0
        Dim iAbsences As Integer = 0
        ''''''''''''''''''''' END OF MODIFICATION ''''''''''''''
        Dim vEligibleRata As Decimal = 0
        Dim vEligibleMeal As Decimal = 0
        Dim vHrsWorked As Decimal = 0

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace("'", "").Replace(vbCrLf, "") & "'); window.close();"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        cm.Connection = c
        cmRef.Connection = c
        cmXRef.Connection = c

        If pPost Then
            If Not chkAppend.Checked Then
                'clear existing record of same code and posted dates
                cm.CommandText = "delete from py_incentives_dtl where Incentive_Cd='" & cmbIncentive.SelectedValue & _
                    "' and FromDate='" & Format(CDate(txtPostDate.Text), "yyyy/MM/dd") & _
                    "' and ToDate='" & Format(CDate(txtPostDate.Text), "yyyy/MM/dd") & "'"
                Try
                    cm.ExecuteNonQuery()
                Catch ex As SqlClient.SqlException
                    vScript = "alert('An error occurred while trying to clean up target Incentive. Error is: " & _
                        ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                    c.Close()
                    c.Dispose()
                    cm.Dispose()
                    cmRef.Dispose()
                    Exit Sub
                End Try
            End If
        End If

        cm.CommandText = "select Rata_ProRata,Meal_ProRata,Rata_DeductTardy,Meal_DeductTardy,Rata_DeductUT,Meal_DeductUt," & _
            "Rata_StartTime,Rata_EndTime,Meal_StartTime,Meal_EndTime,RataMinHrs,MealMinHrs from py_syscntrl"
        Try
            rs = cm.ExecuteReader
            If rs.Read Then
                vRataProRata = rs("Rata_ProRata") = 1
                vMealProRata = rs("Meal_ProRata") = 1
                vRataDeductTardy = rs("Rata_DeductTardy") = 1
                vRataDeductUT = rs("Rata_DeductUT") = 1
                vMealDeductTardy = rs("Meal_DeductTardy") = 1
                vMealDeductUT = rs("Meal_DeductUT") = 1
                vRataStartTime = Format(CDate(rs("Rata_StartTime")), "HH:mm:ss")
                vRataEndTime = Format(CDate(rs("Rata_EndTime")), "HH:mm:ss")
                vMealStartTime = Format(CDate(rs("Meal_StartTime")), "HH:mm:ss")
                vMealEndTime = Format(CDate(rs("Meal_EndTime")), "HH:mm:ss")
                vMealMinHrs = rs("MealMinHrs")
                vRataMinHrs = rs("RataMinHrs")
            End If
            rs.Close()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to retrieve System Control. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Close()
            c.Dispose()
            cm.Dispose()
            cmRef.Dispose()
            Exit Sub
        End Try

        If lblRC.Text <> "All" Then   'filter by cost center
            vFilter += " and Rc_Cd='" & IIf(lblRC.Text.Contains("=>"), ExtractData(lblRC.Text), lblRC.Text) & "' "
            cm.CommandText = "select Descr from rc where Rc_Cd='" & IIf(lblRC.Text.Contains("=>"), ExtractData(lblRC.Text), lblRC.Text) & "'"
            rs = cm.ExecuteReader
            If rs.Read Then
                lblRC.Text = lblRC.Text & "=>" & rs("Descr")
            End If
            rs.Close()
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='rc' and Property_Value=Rc_Cd) "
        End If

        If lblAgency.Text <> "All" Then        'filter by office/agency
            vFilter += " and Agency_Cd='" & IIf(lblAgency.Text.Contains("=>"), ExtractData(lblAgency.Text), lblAgency.Text) & "' "
            cm.CommandText = "select AgencyName from agency where AgencyCd='" & IIf(lblAgency.Text.Contains("=>"), ExtractData(lblAgency.Text), lblAgency.Text) & "'"
            rs = cm.ExecuteReader
            If rs.Read Then
                lblAgency.Text = lblAgency.Text & "=>" & rs("AgencyName")
            End If
            rs.Close()
        Else
            vFilter += "  and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='agency' and Property_Value=Agency_Cd) "
        End If
        If lblDiv.Text <> "All" Then      'filter by division
            vFilter += " and Divcd='" & IIf(lblDiv.Text.Contains("=>"), ExtractData(lblDiv.Text), lblDiv.Text) & "' "
            cm.CommandText = "select Descr from hr_div_ref where Div_Cd='" & IIf(lblDiv.Text.Contains("=>"), ExtractData(lblDiv.Text), lblDiv.Text) & "'"
            rs = cm.ExecuteReader
            If rs.Read Then
                lblDiv.Text = lblDiv.Text & "=>" & rs("Descr")
            End If
            rs.Close()
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='division' and Property_Value=DivCd) "
        End If
        If lblDept.Text <> "All" Then  'filter by departments
            vFilter += " and DeptCd='" & IIf(lblDept.Text.Contains("=>"), ExtractData(lblDept.Text), lblDept.Text) & "' "
            cm.CommandText = "select Descr from hr_dept_ref where Dept_Cd='" & IIf(lblDept.Text.Contains("=>"), ExtractData(lblDept.Text), lblDept.Text) & "'"
            rs = cm.ExecuteReader
            If rs.Read Then
                lblDept.Text = lblDept.Text & "=>" & rs("Descr")
            End If
            rs.Close()
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='department' and Property_Value=DeptCd) "
        End If
        If lblSection.Text <> "All" Then 'filter by section
            vFilter += " and SectionCd='" & IIf(lblSection.Text.Contains("=>"), ExtractData(lblSection.Text), lblSection.Text) & "' "
            cm.CommandText = "select Descr from hr_section_ref where Section_Cd='" & IIf(lblSection.Text.Contains("=>"), ExtractData(lblSection.Text), lblSection.Text) & "'"
            rs = cm.ExecuteReader
            If rs.Read Then
                lblSection.Text = lblSection.Text & "=>" & rs("Descr")
            End If
            rs.Close()
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='section' and Property_Value=SectionCd) "
        End If
        If lblUnit.Text <> "All" Then  'filter by units
            vFilter += " and UnitCd='" & IIf(lblUnit.Text.Contains("=>"), ExtractData(lblUnit.Text), lblUnit.Text) & "' "
            cm.CommandText = "select Descr from hr_unit_ref where Unit_Cd='" & IIf(lblUnit.Text.Contains("=>"), ExtractData(lblUnit.Text), lblUnit.Text) & "'"
            rs = cm.ExecuteReader
            If rs.Read Then
                lblUnit.Text = lblUnit.Text & "=>" & rs("Descr")
            End If
            rs.Close()
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='unit' and Property_Value=UnitCd) "
        End If

        'retrieve list of employees with ACA and RATA value
        cm.CommandText = "select Emp_Cd,Emp_Lname,Emp_Fname,Rata,MealAllow from py_emp_master where (Rata<>0 or MealAllow<>0) " & _
            vFilter & " order by Emp_Lname,Emp_Fname"

        Try
            rs = cm.ExecuteReader
            Do While rs.Read
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY:  VIC GATCHALIAN                                                ''
                '' DATE MODIFIED: 5/14/2012                                                    ''
                '' PURPOSE: TO COMPUTE THE MEAL AND TRANSPORTATION ALLOWANCE                   ''
                '' EXCEPTIONS:  FORMULA IS FOR GWI USE ONLY                                    ''
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                'count total number of work schedule for the period
                cmRef.CommandText = "select * from py_time_log where Tran_Date between '" & _
                    Format(CDate(lblStartDate.Text), "yyy/MM/dd") & "' and '" & Format(CDate(lblEndDate.Text), "yyyy/MM/dd") & _
                    "' and Emp_Cd='" & rs("Emp_Cd") & "'  and Time_In is not null and Time_Out is not null"

                rsRef = cmRef.ExecuteReader

                vEligibleDays = 0
                Do While rsRef.Read
                    vHrsWorked = 0
                    If Not IsDBNull(rsRef("Sched_In")) Then 'regular working schedule
                        If CDate(rsRef("Sched_In")) >= CDate(Format(CDate(rsRef("Sched_In")), "yyyy/MM/dd") & " " & vMealStartTime) Or _
                        CDate(rsRef("Sched_Out")) >= CDate(Format(CDate(rsRef("Sched_In")), "yyyy/MM/dd") & " " & vMealStartTime) Then
                            'subject to eligible days, now check the minimum number of hours rendered
                            vHrsWorked = DateDiff(DateInterval.Minute, CDate(Format(rsRef("Tran_Date"), "yyyy/MM/dd") & " " & rsRef("Time_In")), _
                                CDate(Format(rsRef("Time_OutDate"), "yyyy/MM/dd") & " " & rsRef("Time_Out"))) / 60
                            If vHrsWorked >= 8 Then 'possible eligibility for 1 day allowance
                                'now check if there is undertime 
                                cmXRef.CommandText = "select 1 from py_time_log_dtl where Emp_Cd='" & rs("Emp_Cd") & _
                                    "' and TranDate='" & Format(rsRef("Tran_Date"), "yyyy/MM/dd") & "' and TranCd='UT'"
                                rsXRef = cmXRef.ExecuteReader
                                If Not rsXRef.Read Then
                                    'no records found, possible eligiblity for 1 day allowance 
                                    rsXRef.Close()
                                    'check for tardiness
                                    cmXRef.CommandText = "select Hrs_Rendered from py_time_log_dtl where Emp_Cd='" & rs("Emp_Cd") & _
                                        "' and TranDate='" & Format(rsRef("Tran_Date"), "yyyy/MM/dd") & _
                                        "' and TranCd='TARD'"
                                    rsXRef = cmXRef.ExecuteReader
                                    If rsXRef.Read Then
                                        If rsXRef("Hrs_Rendered") < 2 Then
                                            'eligible for 1 day allowance
                                            vEligibleDays += 1
                                        End If
                                    Else
                                        vEligibleDays += 1
                                    End If
                                End If
                                rsXRef.Close()
                            End If
                        End If
                    Else    'rest day with logs, check for authorized overtime
                        cmXRef.CommandText = "select Hrs_Rendered from py_time_log_dtl where Emp_Cd='" & rs("Emp_Cd") & _
                            "' and TranDate='" & Format(rsRef("Tran_Date"), "yyyy/MM/dd") & _
                            "' and TranCd='E1'"
                        rsXRef = cmXRef.ExecuteReader
                        If rsXRef.Read Then
                            If rsXRef("Hrs_Rendered") >= 8 Then
                                'eligible for 1 day allowance
                                vEligibleDays += 1
                            End If
                        End If
                        rsXRef.Close()
                    End If
                    '''''''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''
                Loop
                rsRef.Close()

                vEligibleRata = vEligibleDays
                vEligibleMeal = vEligibleDays

                vData.AppendLine("<tr class='" & vRow & "'>" & _
                    "<td>" & rs("Emp_Cd") & "</td>" & _
                    "<td>" & rs("Emp_Lname") & ", " & rs("Emp_Fname") & "</td>" & _
                    "<td align='right'>" & Format(rs("MealAllow"), "##,##0.00") & "</td>" & _
                    "<td align='right'>" & Format(rs("RaTa"), "##,##0.00") & "</td>" & _
                    "<td align='right'>" & Format(vEligibleMeal, "##,##0.00") & "</td>" & _
                    "<td align='right'>" & Format(vEligibleRata, "##.00") & "</td>" & _
                    "<td align='right'>" & Format(rs("MealAllow") * IIf(vMealProRata, vEligibleMeal, 1), "##,##0.00") & "</td>" & _
                    "<td align='right'>" & Format(rs("Rata") * IIf(vRataProRata, vEligibleRata, 1), "##,##0.00") & "</td>" & _
                    "</tr>")

                If pPost Then   'post button was clicked
                    'clean up existing data of the same incentive code, post date and employee id
                    cmRef.CommandText = "delete from py_incentives_dtl where Incentive_Cd='" & _
                        cmbIncentive.SelectedValue & "' and FromDate='" & Format(CDate(txtPostDate.Text), "yyyy/MM/dd") & _
                        "' and Emp_Cd='" & rs("Emp_Cd") & "'"
                    cmRef.ExecuteNonQuery()
                    'now insert the new calculated info
                    cmRef.CommandText = "insert into py_incentives_dtl (Incentive_Cd,Emp_Cd,FromDate,ToDate,Incentive_Amt," & _
                        "Recurring,FreqCd) values ('" & cmbIncentive.SelectedValue & "','" & rs("Emp_Cd") & _
                        "','" & Format(CDate(txtPostDate.Text), "yyyy/MM/dd") & "','" & Format(CDate(txtPostDate.Text), "yyyy/MM/dd") & _
                        "'," & (rs("MealAllow") * IIf(vMealProRata, vEligibleMeal, 1)) + _
                        (rs("Rata") * IIf(vRataProRata, vEligibleRata, 1)) & ",0,0)"
                    cmRef.ExecuteNonQuery()
                End If
                vRow = IIf(vRow = "odd", "even", "odd")
            Loop
            rs.Close()
            vDump = vData.ToString
            If vDump = "" Then
                vScript = "alert('No records retrieved.');"
            Else
                If pPost Then
                    vScript = "alert('Posting complete. You may check the info in the Incentives Monitoring module.'); window.close();"
                End If
            End If
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to retrieve records. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            c.Dispose()
            cm.Dispose()
            cmRef.Dispose()
            cmXRef.Dispose()
        End Try
    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        If Not IsDate(txtPostDate.Text) Then
            vScript = "alert('You must enter a valid date format MM/DD/YYYY.'); " & _
                "document.getElementById('divPost').style.visibility='visible'; " & _
                "document.getElementById('txtPostDate').focus();"
            GenerateReport(False)
            Exit Sub
        End If
        GenerateReport(True)
    End Sub
End Class
