Imports denaro
Partial Class geninfo
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Dim c As New SqlClient.SqlConnection
    Protected Sub cmdCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Or Session("uid") = Nothing Then
            Session("returnaddr") = "geninfo.aspx"
            Server.Transfer("index.aspx")
            Exit Sub
        End If

        If Not CanRun(Session("caption"), Request.Item("id")) Then
            Session("denied") = "1"
            Server.Transfer("main.aspx")
            Exit Sub
        End If
        If Not IsPostBack Then
            lblCaption.Text = "General Information"
            Dim cm As New sqlclient.sqlcommand
            Dim dr As sqlclient.sqldatareader
            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c
            cm.CommandText = "select * from py_syscntrl"
            dr = cm.ExecuteReader
            Dim NetPayFloor As Decimal
            If dr.Read Then
                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY:  VIC GATCHALIAN                                 ''
                '' DATE MODIFIED: 3/19/2013                                     ''
                '' PURPOSE: TO ADD A PARAMETRIC NUMBER OF LOGIN TRIES. VALUE    ''
                ''          SHOULD BE AT LEAST 1 TRY.                           ''
                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                txtLoginTries.Text = dr("LoginTries")
                txtLoginExpiry.Text = dr("LoginExpiry")
                ''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''

                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY:  VIC GATCHALIAN                                 ''
                '' DATE MODIFIED: 4/2/2013                                      ''
                '' PURPOSE: TO ADD FACILITY TO SET PARAMETRIC GAP HOURS BETWEEN ''
                ''          SHIFTS.                                             ''
                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                txtShiftGap.Text = dr("ShiftScheduleGap")
                ''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''

                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY:  VIC GATCHALIAN                                 ''
                '' DATE MODIFIED: 4/22/2013                                     ''
                '' PURPOSE: TO EXPOSE ESCALATION OF PENDING APPLICATION FEATURE ''
                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                chkEscalate.Checked = dr("EscalateApproving") = 1
                txtEscalateHr.Text = dr("EscalateHr")
                '''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''

                rdoBLOption.SelectedValue = dr("BLTag")
                txtBLcheckdays.Text = dr("BLCredit")
                txtDaysMonth.Text = IIf(IsDBNull(dr("Dates_To_Month")), DateAdd(DateInterval.Day, -4, MonthEND(Now)), _
                    dr("Dates_To_Month"))
                txtHrsDay.Text = IIf(IsDBNull(dr("Hrs_Day")), 8, dr("Hrs_Day"))
                txtBrkHrs.Text = IIf(IsDBNull(dr("Break_Hrs")), 1, dr("Break_Hrs"))
                txtGracePd.Text = IIf(IsDBNull(dr("Grace_Period")), 0, dr("Grace_Period"))
                NetPayFloor = IIf(IsDBNull(dr("NetPayFloor")), 0, dr("NetPayFloor") * 100)
                txtMinPay.Text = NetPayFloor
                txtELCount.Text = dr("AnnualElCount")
                rdoSSSBasis.SelectedValue = 1
                rdoPAGIBIGBasis.SelectedValue = 1
                rdoPHICBasis.SelectedValue = 1
                rdoACABasis.SelectedValue = 0
                rdoRataBasis.SelectedValue = 0
                rdoPeraBasis.SelectedValue = 0
                rdoMealBasis.SelectedValue = 0

                chkACATaxable.Checked = False
                chkRATATaxable.Checked = False
                chkPERATaxable.Checked = False
                chkMealTaxable.Checked = False
                chkSenior.Checked = False
                chkAcaDeductTardy.Checked = dr("Aca_DeductTardy") = 1
                chkRataDeductTardy.Checked = dr("Rata_DeductTardy") = 1
                chkPeraDeductTardy.Checked = dr("Pera_DeductTardy") = 1
                chkMealDeductTardy.Checked = dr("Meal_DeductTardy") = 1
                chkAcaDeductUT.Checked = dr("Aca_DeductUT") = 1
                chkRataDeductUT.Checked = dr("Rata_DeductUT") = 1
                chkPeraDeductUT.Checked = dr("Pera_DeductUT") = 1
                chkMealDeductUT.Checked = dr("Meal_DeductUT") = 1
                txtAcaStart.Text = "00:00:00"
                txtAcaEnd.Text = "23:59:59"
                txtRataStart.Text = "00:00:00"
                txtRataEnd.Text = "23:59:59"
                txtPeraStart.Text = "00:00:00"
                txtPeraEnd.Text = "23:59:59"
                txtMealStart.Text = "00:00:00"
                txtMealEnd.Text = "23:59:59"
                txtACAMinHrs.Text = dr("AcaMinHrs")
                txtRATAMinHrs.Text = dr("RataMinHrs")
                txtPERAMinHrs.Text = dr("PeraMinHrs")
                txtMealMinHrs.Text = dr("MealMinHrs")
                If Not IsDBNull(dr("Aca_StartTime")) Then
                    txtAcaStart.Text = dr("Aca_StartTime")
                End If
                If Not IsDBNull(dr("Aca_EndTime")) Then
                    txtAcaEnd.Text = dr("Aca_EndTime")
                End If
                If Not IsDBNull(dr("Rata_StartTime")) Then
                    txtRataStart.Text = dr("Rata_StartTime")
                End If
                If Not IsDBNull(dr("Rata_EndTime")) Then
                    txtRataEnd.Text = dr("Rata_EndTime")
                End If
                If Not IsDBNull(dr("Pera_StartTime")) Then
                    txtPeraStart.Text = dr("Pera_StartTime")
                End If
                If Not IsDBNull(dr("Pera_EndTime")) Then
                    txtPeraEnd.Text = dr("Pera_EndTime")
                End If
                If Not IsDBNull(dr("Meal_StartTime")) Then
                    txtMealStart.Text = dr("Meal_StartTime")
                End If
                If Not IsDBNull(dr("Meal_EndTime")) Then
                    txtMealEnd.Text = dr("Meal_EndTime")
                End If
                If Not IsDBNull(dr("Allow_EarlyOT")) Then
                    rdoEarlyOT.SelectedValue = dr("Allow_EarlyOT")
                End If
                If Not IsDBNull(dr("Sss_Gross_Basis")) Then
                    rdoSSSBasis.SelectedValue = dr("Sss_Gross_Basis")
                End If
                If Not IsDBNull(dr("Pagibig_Gross_Basis")) Then
                    rdoPAGIBIGBasis.SelectedValue = dr("Pagibig_Gross_Basis")
                End If
                If Not IsDBNull(dr("Phic_Gross_Basis")) Then
                    rdoPHICBasis.SelectedValue = dr("Phic_Gross_Basis")
                End If
                If Not IsDBNull(dr("Aca_ProRata")) Then
                    rdoACABasis.SelectedValue = dr("Aca_ProRata")
                End If
                If Not IsDBNull(dr("Rata_ProRata")) Then
                    rdoRataBasis.SelectedValue = dr("Rata_ProRata")
                End If
                If Not IsDBNull(dr("Pera_ProRata")) Then
                    rdoPeraBasis.SelectedValue = dr("Pera_ProRata")
                End If
                If Not IsDBNull(dr("Meal_ProRata")) Then
                    rdoMealBasis.SelectedValue = dr("Meal_ProRata")
                End If
                If Not IsDBNull(dr("Aca_Taxable")) Then
                    chkACATaxable.Checked = dr("Aca_Taxable") = 1
                End If
                If Not IsDBNull(dr("Rata_Taxable")) Then
                    chkRATATaxable.Checked = dr("Rata_Taxable") = 1
                End If
                If Not IsDBNull(dr("Pera_Taxable")) Then
                    chkPERATaxable.Checked = dr("Pera_Taxable") = 1
                End If
                If Not IsDBNull(dr("Meal_Taxable")) Then
                    chkMealTaxable.Checked = dr("Meal_Taxable") = 1
                End If
                If Not IsDBNull(dr("SeniorAllowTaxable")) Then
                    chkSenior.Checked = dr("SeniorAllowTaxable") = 1
                End If
                If IsDBNull(dr("MinWageAmount")) Then
                    txtMinWage.Text = 0
                Else
                    txtMinWage.Text = dr("MinWageAmount")
                End If
                If IsDBNull(dr("LogMethod")) Then
                    rdoLogMethod.SelectedValue = 1
                Else
                    rdoLogMethod.SelectedValue = dr("LogMethod")
                End If
                If IsDBNull(dr("UseTerm")) Then
                    chkTerm.Checked = True
                    txtTerm.Visible = True
                Else
                    If dr("UseTerm") = 1 Then
                        chkTerm.Checked = True
                        txtTerm.Visible = True
                    Else
                        chkTerm.Checked = False
                        txtTerm.Visible = False
                    End If
                End If
                If IsDBNull(dr("UseFn")) Then
                    chkFn.Checked = True
                    tblFn.Visible = True
                Else
                    If dr("UseFn") = 1 Then
                        chkFn.Checked = True
                        tblFn.Visible = True
                        rdoFnIn.SelectedValue = dr("FnIn")
                        rdoFnOut.SelectedValue = dr("FnOut")
                        rdoFnSIn.SelectedValue = dr("FnBin")
                        rdoFnSOut.SelectedValue = dr("FnBout")
                    Else
                        chkFn.Checked = False
                        tblFn.Visible = False
                    End If
                End If
                If IsDBNull(dr("UseFILO")) Then
                    chkFILO.Checked = True
                Else
                    chkFILO.Checked = dr("UseFILO") = 1
                End If
                dr.Close()
                cm.CommandText = "select Pag_Per_Per,Pag_Per_Up,Pag_Gov_Per,Pag_Gov_Up," & _
                    "Opt_Per,Opt_Up,State_Per,State_Up from py_deduct"
                dr = cm.ExecuteReader
                If dr.Read Then
                    txtPerPer.Text = IIf(IsDBNull(dr("Pag_Per_Per")), 0, dr("Pag_Per_Per"))
                    txtPerUp.Text = IIf(IsDBNull(dr("Pag_Per_Up")), 0, dr("Pag_Per_Up"))
                    txtGovPer.Text = IIf(IsDBNull(dr("Pag_Gov_Per")), 0, dr("Pag_Gov_Per"))
                    txtGovUp.Text = IIf(IsDBNull(dr("Pag_Gov_Up")), 0, dr("Pag_Gov_Up"))
                    'txtOptPer.Text = IIf(IsDBNull(dr("Opt_Per")), 0, dr("Opt_Per"))
                    'txtOptUp.Text = IIf(IsDBNull(dr("Opt_Up")), 0, dr("Opt_Up"))
                    'txtStatePer.Text = IIf(IsDBNull(dr("State_Per")), 0, dr("State_Per"))
                    'txtStateUp.Text = IIf(IsDBNull(dr("State_Up")), 0, dr("State_Up"))
                End If
                dr.Close()
                cm.Dispose()
                c.Close()
                c.Dispose()
            End If
        End If
    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        If Page.IsValid Then
            Dim Con_Net_Pay As Decimal
            Con_Net_Pay = 0
            If (txtMinPay.Text <> 0) Then
                Con_Net_Pay = (txtMinPay.Text / 100)
            End If

            txtACAMinHrs.Text = txtACAMinHrs.Text.Replace(",", "")
            txtRATAMinHrs.Text = txtRATAMinHrs.Text.Replace(",", "")
            txtPERAMinHrs.Text = txtPERAMinHrs.Text.Replace(",", "")
            txtMealMinHrs.Text = txtMealMinHrs.Text.Replace(",", "")

            If Not IsNumeric(txtBLcheckdays.Text) Then
                vScript = "alert('Birthday leave days to check should be numeric.');"
                Exit Sub
            End If

            If Not IsNumeric(txtACAMinHrs.Text) Then
                vScript = "alert('ACA Min. Hors Required field should be numeric.');"
                Exit Sub
            End If
            If Not IsNumeric(txtRATAMinHrs.Text) Then
                vScript = "alert('RATA Min. Hours Required field should be numeric.');"
                Exit Sub
            End If
            If Not IsNumeric(txtPERAMinHrs.Text) Then
                vScript = "alert('PERA Min. Hours Required field should be numeric.');"
                Exit Sub
            End If
            If Not IsNumeric(txtMealMinHrs.Text) Then
                vScript = "alert('Meal Allowance Min. Hours Required field should be numeric.');"
                Exit Sub
            End If
            If Not IsNumeric(txtShiftGap.Text) Then
                vScript = "alert('Shift Schedule Gap field should be numeric.');"
                Exit Sub
            End If

            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:  VIC GATCHALIAN                                                    ''
            '' DATE MODIFIED: 3/19/2013                                                        ''
            '' PURPOSE: TO CHECK IF THE LOGINTRIES FIELD IS NUMERIC AND AT LEAST 1             ''
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            If Not IsNumeric(txtLoginTries.Text) Then
                vScript = "alert('Login Tries field should be numeric.');"
                Exit Sub
            End If
            If Val(txtLoginTries.Text) < 1 Then
                vScript = "alert('The value of Login Tries field should be at least 1');"
                Exit Sub
            End If

            If Not IsNumeric(txtLoginExpiry.Text) Then
                vScript = "alert('Login Expiry field should be numeric.');"
                Exit Sub
            End If
            If Val(txtLoginExpiry.Text) < 1 Then
                vScript = "alert('Login Expiry field should be at least one (1) month.');"
                Exit Sub
            End If
            ''''''''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''''''''''''''

            Dim cm As New SqlClient.SqlCommand

            c.ConnectionString = connStr
            Try
                c.Open()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred whiled trying to connect to database. Error is: " & _
                    ex.Message.Replace("'", "").Replace(vbCrLf, "") & "');"
                Exit Sub
            End Try

            cm.Connection = c

            cm.CommandText = "update py_syscntrl set Dates_To_Month=" & txtDaysMonth.Text & _
                ",Hrs_Day=" & txtHrsDay.Text & ",Break_Hrs=" & txtBrkHrs.Text & _
                ",Grace_Period=" & txtGracePd.Text & _
                ",LogMethod=" & rdoLogMethod.SelectedValue & _
                ",UseTerm=" & IIf(chkTerm.Checked, 1, 0) & _
                ",UseFn=" & IIf(chkFn.Checked, 1, 0) & _
                ",UseFILO=" & IIf(chkFILO.Checked, 1, 0) & _
                ",TermList='" & txtTerm.Text & _
                "',FnIn=" & rdoFnIn.SelectedValue & _
                ",FnOut=" & rdoFnOut.SelectedValue & _
                ",FnBin=" & rdoFnSIn.SelectedValue & _
                ",FnBout=" & rdoFnSOut.SelectedValue & _
                ",NetPayFloor=" & Con_Net_Pay & ", AnnualElCount=" & txtELCount.Text & _
                ",MinWageAmount=" & Val(txtMinWage.Text) & _
                ",Sss_Gross_Basis=" & rdoSSSBasis.SelectedValue & _
                ",Pagibig_Gross_Basis=" & rdoPAGIBIGBasis.SelectedValue & _
                ",Phic_Gross_Basis=" & rdoPHICBasis.SelectedValue & _
                ",Aca_Taxable=" & IIf(chkACATaxable.Checked, 1, 0) & _
                ",Rata_Taxable=" & IIf(chkRATATaxable.Checked, 1, 0) & _
                ",Pera_Taxable=" & IIf(chkPERATaxable.Checked, 1, 0) & _
                ",Meal_Taxable=" & IIf(chkMealTaxable.Checked, 1, 0) & _
                ",SeniorAllowTaxable=" & IIf(chkSenior.Checked, 1, 0) & _
                ",Aca_ProRata=" & rdoACABasis.SelectedValue & _
                ",Rata_ProRata=" & rdoRataBasis.SelectedValue & _
                ",Pera_ProRata=" & rdoPeraBasis.SelectedValue & _
                ",Meal_ProRata=" & rdoMealBasis.SelectedValue & _
                ",Aca_DeductTardy=" & IIf(chkAcaDeductTardy.Checked, 1, 0) & _
                ",Rata_DeductTardy=" & IIf(chkRataDeductTardy.Checked, 1, 0) & _
                ",Pera_DeductTardy=" & IIf(chkPeraDeductTardy.Checked, 1, 0) & _
                ",Meal_DeductTardy=" & IIf(chkMealDeductTardy.Checked, 1, 0) & _
                ",Aca_DeductUT=" & IIf(chkAcaDeductUT.Checked, 1, 0) & _
                ",Rata_DeductUT=" & IIf(chkRataDeductUT.Checked, 1, 0) & _
                ",Pera_DeductUT=" & IIf(chkPeraDeductUT.Checked, 1, 0) & _
                ",Meal_DeductUT=" & IIf(chkMealDeductUT.Checked, 1, 0) & _
                ",Aca_StartTime='" & Format(CDate(txtAcaStart.Text), "HH:mm:ss") & _
                "',Aca_EndTime='" & Format(CDate(txtAcaEnd.Text), "HH:mm:ss") & _
                "',Rata_StartTime='" & Format(CDate(txtRataStart.Text), "HH:mm:ss") & _
                "',Rata_EndTime='" & Format(CDate(txtRataEnd.Text), "HH:mm:ss") & _
                "',Pera_StartTime='" & Format(CDate(txtPeraStart.Text), "HH:mm:ss") & _
                "',Pera_EndTime='" & Format(CDate(txtPeraEnd.Text), "HH:mm:ss") & _
                "',Meal_StartTime='" & Format(CDate(txtMealStart.Text), "HH:mm:ss") & _
                "',Meal_EndTime='" & Format(CDate(txtMealEnd.Text), "HH:mm:ss") & _
                "',Allow_EarlyOT=" & rdoEarlyOT.SelectedValue & _
                ",AcaMinHrs=" & Val(txtACAMinHrs.Text) & _
                ",RataMinHrs=" & Val(txtRATAMinHrs.Text) & _
                ",PeraMinHrs=" & Val(txtPERAMinHrs.Text) & _
                ",MealMinHrs=" & Val(txtMealMinHrs.Text) & _
                ",BLCredit=" & Val(txtBLcheckdays.Text) & _
                ",BLTag=" & rdoBLOption.SelectedValue

            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:  VIC GATCHALIAN                                         ''
            '' DATE MODIFIED: 3/19/2013                                             ''
            '' PURPOSE: TO SAVE THE LOGIN TRIES FIELD.                              ''
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            cm.CommandText += ",LoginTries=" & txtLoginTries.Text & ",LoginExpiry=" & txtLoginExpiry.Text & _
                ",ShiftScheduleGap=" & Val(txtShiftGap.Text)
            '''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''''''''''

            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:  VIC GATCHALIAN                                         ''
            '' DATE MODIFIED: 4/22/2013                                             ''
            '' PURPOSE: TO SAVE THE ESCALATION OPTION                               ''
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            cm.CommandText += ",EscalateApproving=" & IIf(chkEscalate.Checked, 1, 0) & _
                ",EscalateHr=" & txtEscalateHr.Text
            '''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''''''''''

            Try
                cm.ExecuteNonQuery()
                cm.CommandText = "update py_deduct set Pag_Per_Per=" & txtPerPer.Text & _
                    ",Pag_Per_Up=" & txtPerUp.Text & ",Pag_Gov_Per=" & txtGovPer.Text & _
                    ",Pag_Gov_Up=" & txtGovUp.Text
                cm.ExecuteNonQuery()

                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY:  VIC GATCHALIAN                                    ''
                '' DATE MODIFIED: 4/8/2013                                         ''
                '' PURPOSE: TO RECALCULATE THE SALARIES ON EXIT IF THE CHECKBOX    ''
                ''          OPTION IS TICKED.                                      ''
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                If chkRecalc.Checked Then
                    cm.CommandText = "update py_emp_master set Rate_Day=Rate_Month / " & _
                        Val(txtDaysMonth.Text) & " where Date_Resign is null"
                    cm.ExecuteNonQuery()
                End If
                ''''''''''''''''''' END OLD CODE ''''''''''''''''''''''''''''''''''''

                vScript = "alert('Changes were saved successfully.');"
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to save changes. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            Finally
                cm.Dispose()
                c.Close()
                c.Dispose()
            End Try
        Else
            vScript = "alert('All fields in this page should be in numeric format!');"
        End If
    End Sub

    Protected Sub CustomValidator1_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles CustomValidator1.ServerValidate
        CustomValidator1.ErrorMessage = "Fields should be numeric."
        args.IsValid = IsNumeric(txtDaysMonth.Text) And IsNumeric(txtHrsDay.Text) And _
            IsNumeric(txtBrkHrs.Text) And IsNumeric(txtGracePd.Text) And _
            IsNumeric(txtPerPer.Text) And IsNumeric(txtPerUp.Text) And _
            IsNumeric(txtGovPer.Text) And IsNumeric(txtGovUp.Text) And _
            IsNumeric(txtMinPay.Text)

        If args.IsValid Then
            CustomValidator1.ErrorMessage = "You must check at least one option in the Log Recognition Priority."
            args.IsValid = chkFILO.Checked Or chkTerm.Checked Or chkFn.Checked
        End If
    End Sub

 
    Protected Sub chkTerm_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkTerm.Init
        chkTerm.Attributes.Add("onclick", "setTerm();")
    End Sub

    Protected Sub chkFn_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkFn.Init
        chkFn.Attributes.Add("onclick", "setFn();")
    End Sub
End Class
