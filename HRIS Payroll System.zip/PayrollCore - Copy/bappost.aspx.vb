Imports System.Data
Imports denaro.fis
Partial Class bappost
    Inherits System.Web.UI.Page
    Public vDump As String = ""
    Public vScript As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If
        If Not IsPostBack Then
            lblCaption.Text = "List of BAP Enrollees for posting"
            BuildCombo("select Loan_Cd,Loan_Name from py_loan_ref order by Loan_Name", cmbLoan)
            DataRefresh()
        End If
    End Sub

    Private Sub DataRefresh()
        Dim c As New sqlclient.sqlconnection(connStr)
        Dim cRef As New sqlclient.sqlconnection(connStr)
        Dim cm As New sqlclient.sqlcommand
        Dim cmRef As New sqlclient.sqlcommand
        Dim rs As sqlclient.sqldatareader
        Dim rsRef As sqlclient.sqldatareader
        Dim vCount As Integer = 0
        Dim vAmt As Decimal = 0

        cm.Connection = c
        cmRef.Connection = cRef
        cm.CommandText = "select Emp_Cd,Emp_Lname,Emp_Fname,EmploymentType from py_emp_master where Emp_Cd in (" & _
            "select distinct Emp_Cd from hr_dependents where Synchronized=0 and BapEnrolled=1)"
        c.Open()
        cRef.Open()
        rs = cm.ExecuteReader
        vDump = "<tr>"
        Do While rs.Read
            cmRef.CommandText = "select count(Emp_Cd) from hr_dependents where Emp_Cd='" & _
                rs("Emp_Cd") & "' and Synchronized=0 and BapEnrolled=1"
            rsRef = cmRef.ExecuteReader
            vCount = 0
            If rsRef.Read Then
                vCount = rsRef(0)
            End If
            rsRef.Close()
            cmRef.CommandText = "select Amount from bap_table where Rank='" & rs("EmploymentType") & _
                "' and " & vCount & " between FromQty and ToQty"
            rsRef = cmRef.ExecuteReader
            If rsRef.Read Then
                vAmt = rsRef("Amount")
            End If
            rsRef.Close()
            vDump += "<td><input type='checkbox' id='chk' name='chk" & rs("Emp_Cd") & "' /></td>" & _
                    "<td style='width: 117px' align='left'>" & rs("Emp_Cd") & "</td>" & _
                    "<td style='width: 387px' align='left'>" & rs("Emp_Lname") & ", " & rs("Emp_Fname") & "</td>" & _
                    "<td style='width: 85px'>" & vCount & "</td>" & _
                    "<td>" & Format(vAmt, "#0.00") & "</td>"
        Loop
        rs.Close()
        c.Close()
        cm.Dispose()
        c.Dispose()
        cRef.Dispose()
        cmRef.Dispose()
        vDump += "</tr>"
    End Sub
    Protected Sub cmdReturn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.Click
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub cmdPost_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdPost.Click
        Dim c As New sqlclient.sqlconnection(connStr)
        Dim cExec As New sqlclient.sqlconnection(connStr)
        Dim cm As New sqlclient.sqlcommand
        Dim cmExec As New sqlclient.sqlcommand
        Dim rs As sqlclient.sqldatareader
        Dim rsRef As sqlclient.sqldatareader
        Dim vCount As Integer = 0
        Dim vAmt As Decimal = 0

        Try
            c.Open()
            cExec.Open()
            cm.Connection = c
            cmExec.Connection = cExec
            cm.CommandText = "select Emp_Cd,EmploymentType from py_emp_master where Emp_Cd in (" & _
                "select distinct Emp_Cd from hr_dependents where Synchronized=0 and BapEnrolled=1)"

            rs = cm.ExecuteReader
            Do While rs.Read
                If Request.Form("chk" & rs("Emp_Cd")) = "on" Then
                    cmExec.CommandText = "select count(Emp_Cd) from hr_dependents where Emp_Cd='" & _
                        rs("Emp_Cd") & "' and Synchronized=0 and BapEnrolled=1"
                    rsRef = cmExec.ExecuteReader
                    vCount = 0
                    If rsRef.Read Then
                        vCount = rsRef(0)
                    End If
                    rsRef.Close()
                    cmExec.CommandText = "select Amount from bap_table where Rank='" & rs("EmploymentType") & _
                        "' and " & vCount & " between FromQty and ToQty"
                    rsRef = cmExec.ExecuteReader
                    If rsRef.Read Then
                        vAmt = rsRef("Amount")
                    End If
                    rsRef.Close()
                    cmExec.CommandText = "insert into py_loan_hdr (Emp_Cd,Loan_Cd,Amt_Bal,Amt_Loan,Amt_Paid," & _
                        "Loan_Date,Start_Date,Int_Rate,Month_to_Pay,Active,ProdDescr,Monthly,MonthlyAmort,Recurring," & _
                        "End_Date,PaymentsMade,FreqCd,DocNo) values ('" & rs("Emp_Cd") & "','" & _
                        cmbLoan.SelectedValue & "'," & vAmt & "," & vAmt & ",0,'" & Format(Now, "yyyy/MM/dd") & _
                        "','" & Format(Now, "yyyy/MM/dd") & "',0,1,1,'Bereivement Assistance Program',0," & _
                        vAmt & ",1,'" & Format(Now, "yyyy/MM/dd") & "',0,0,'.')"
                    cmExec.ExecuteNonQuery()
                    cmExec.CommandText = "update hr_dependents set Synchronized=1 where Emp_Cd='" & _
                        rs("Emp_Cd") & "' and Synchronized=0 and BapEnrolled=1"
                    cmExec.ExecuteNonQuery()
                End If
            Loop
            c.Close()
            cExec.Close()
            cm.Dispose()
            cmExec.Dispose()
            c.Dispose()
            cExec.Dispose()
        Catch ex As sqlclient.sqlException
            vScript = "alert('An error ocurred while trying to save your changes. Error is: " & _
                ex.Message.Replace("'", "") & "');"
        End Try
    End Sub
End Class
