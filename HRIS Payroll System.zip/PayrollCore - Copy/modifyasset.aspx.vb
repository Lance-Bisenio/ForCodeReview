﻿Imports denaro.fis
Partial Class modifyasset
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            vScript = "alert('Your login session has expired. Please re-login again.'); window.close();"
            Exit Sub
        End If

        If Not IsPostBack Then
            Dim c As New SqlClient.SqlConnection(connStr)
            Dim cm As New SqlClient.SqlCommand
            Dim dr As SqlClient.SqlDataReader
            txtEmpCd.Text = Session("empid")

            c.Open()
            cm.Connection = c
            cm.CommandText = "select Emp_Lname,Emp_Fname from py_emp_master where Emp_Cd='" & txtEmpCd.Text & "'"
            dr = cm.ExecuteReader
            If dr.Read Then
                lblEmpName.Text += dr("Emp_Lname") & ", " & dr("Emp_Fname")
            End If
            dr.Close()

            BuildCombo("select ItemCd,ItemName from item order by ItemName", cmbItem, c)
            If Session("mode") = "e" Then
                'cm.CommandText = "select * from hr_emp_reference where Emp_Cd='" & txtEmpCd.Text & _
                '    "' and SeqId=" & Session("seqid")
                'dr = cm.ExecuteReader
                'If dr.Read Then
                '    txtEmpCd.Text = dr("SeqId")
                '    txtDateAssigned.Text = dr("FullName")
                '    txtPosition.Text = dr("Position")
                '    txtTel.Text = dr("Contact_No")
                '    txtReason.Text = dr("Address")
                'End If
                'dr.Close()

            End If
            cm.Dispose()
            c.Close()
            c.Dispose()
        End If
    End Sub
End Class
