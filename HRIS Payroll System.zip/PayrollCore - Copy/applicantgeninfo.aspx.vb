Imports denaro
Partial Class applicantgeninfo
    Inherits System.Web.UI.Page
    Dim c As New sqlclient.sqlconnection
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If

        If Not IsPostBack Then
            Dim cRef As New sqlclient.sqlconnection(connStr)
            Dim cm As New sqlclient.sqlcommand
            Dim cmRef As New sqlclient.sqlcommand
            Dim dr As sqlclient.sqldatareader
            Dim drRef As sqlclient.sqldatareader
            lblCaption.Text = "Applicant's General Information (1 of 2)"
            c.ConnectionString = connStr
            c.Open()
            cRef.Open()
            cm.Connection = c
            cmRef.Connection = cRef
            cm.CommandText = "select * from hr_applicant_master where ApplicantNo=" & _
                Session("applicantno")
            dr = cm.ExecuteReader
            If dr.Read Then
                cmRef.CommandText = "select Position from py_position_ref where Pos_Cd='" & _
                    dr("Pos_Cd") & "'"
                drRef = cmRef.ExecuteReader
                txtPosition.Text = ""
                If drRef.Read Then
                    txtPosition.Text = drRef("Position")
                End If
                drRef.Close()
                cmRef.CommandText = "select Descr from hr_country_ref where CountryCd='" & _
                    IIf(IsDBNull(dr("CountryCd")), "", dr("CountryCd")) & "'"
                drRef = cmRef.ExecuteReader
                txtCountry.Text = ""
                If drRef.Read Then
                    txtCountry.Text = drRef("Descr")
                End If
                drRef.Close()
                txtId.Text = dr("ApplicantNo")
                txtName.Text = dr("Lname") & ", " & dr("Fname") & " " & dr("Mname")
                txtNick.Text = IIf(IsDBNull(dr("NickName")), "", dr("NickName"))
                txtSalaryFrom.Text = Format(dr("DesiredSalaryFrom"), "###,##0.00")
                txtSalaryTo.Text = Format(dr("DesiredSalaryTo"), "###,##0.00")
                txtTel.Text = IIf(IsDBNull(dr("Tel")), "", dr("Tel"))
                txtCP.Text = IIf(IsDBNull(dr("MobileNo")), "", dr("MobileNo"))
                txtAddress.Text = IIf(IsDBNull(dr("Address")), "", dr("Address"))
                txtProvAddr.Text = IIf(IsDBNull(dr("Prov_Address")), "", dr("Prov_Address"))
                txtCity.Text = IIf(IsDBNull(dr("City")), "", dr("City"))
                txtZIP.Text = IIf(IsDBNull(dr("Zip")), "", dr("Zip"))
            End If
            dr.Close()
            cm.Dispose()
            cmRef.Dispose()
            cRef.Close()
            cRef.Dispose()
            c.Close()
        End If
    End Sub
End Class
