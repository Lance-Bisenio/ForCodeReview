Namespace denaro
    Partial Class empstep1
        Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub


        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        Public vScript As String = ""
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load, Me.Load
            If Session("uid") = "" Or Session("uid") = Nothing Then
                vScript = "alert('Your login session has expired. Please login again.'); window.close();"
                Exit Sub
            End If

            If Not IsPostBack Then
                If Not CanRun(Session("caption"), "41.1") Then
                    Server.Transfer("empstep2_1.aspx")
                    Exit Sub
                End If
                Session.Remove("oldval")
                Session.Remove("newval")

                Dim c As New SqlClient.SqlConnection(connStr)
                Dim cm As New SqlClient.SqlCommand
                Dim rs As SqlClient.SqlDataReader

                Try
                    c.Open()
                Catch ex As SqlClient.SqlException
                    vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                        ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                    c.Dispose()
                    cm.Dispose()
                    Exit Sub
                End Try

                lblCaption.Text = "Employee Master Information (1 of 6)"

                BuildCombo("select Pos_Cd,Position from py_position_ref order by position", cmbPos, c)
                BuildCombo("select Status_Code,Descr from py_employee_stat", cmbStatus, c)
                BuildCombo("select Rc_Cd,Descr from rc where exists (select User_Id from rights_list where User_Id='" & _
                    Session("uid") & "' and property='rc' and Property_Value=Rc_Cd) order by Descr", cmbRC, c)
                BuildCombo("select AgencyCd,AgencyName from agency where exists (select User_Id from rights_list where User_Id='" & _
                    Session("uid") & "' and property='agency' and Property_Value=AgencyCd) order by AgencyName", cmbAgency, c)
                BuildCombo("select Div_Cd,Descr from hr_div_ref where exists (select User_Id from rights_list where User_Id='" & _
                    Session("uid") & "' and property='division' and Property_Value=Div_Cd) order by Descr", cmbDiv, c)
                BuildCombo("select Dept_Cd,Descr from hr_dept_ref where exists (select User_Id from rights_list where User_Id='" & _
                    Session("uid") & "' and property='department' and Property_Value=Dept_Cd) order by Descr", cmbDept, c)
                BuildCombo("select Section_Cd,Descr from hr_section_ref where exists (select User_Id from rights_list where User_Id='" & _
                    Session("uid") & "' and property='section' and Property_Value=Section_Cd) order by Descr", cmbSection, c)
                BuildCombo("select Unit_Cd,Descr from hr_unit_ref where exists (select User_Id from rights_list where User_Id='" & _
                    Session("uid") & "' and property='unit' and Property_Value=Unit_Cd) order by Descr", cmbUnit, c)
                BuildCombo("select EmploymentType,Descr from hr_employment_type where exists (select User_Id from rights_list where User_Id='" & _
                    Session("uid") & "' and property='employmenttype' and Property_Value=EmploymentType) order by Descr", cmbSecurity, c)

                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY:  VIC GATCHALIAN                               ''
                '' DATE MODIFIED: 7/17/2013                                   ''
                '' PURPOSE: TO SET THE DEFAULT VALUES IF THERE IS ONLY ONE    ''
                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                If cmbPos.Items.Count > 1 Then
                    cmbPos.Items.Add("Please select from the list...")
                    cmbPos.SelectedValue = "Please select from the list..."
                Else
                    cmbPos.SelectedIndex = 0
                End If
                If cmbStatus.Items.Count > 1 Then
                    cmbStatus.Items.Add("Please select from the list...")
                    cmbStatus.SelectedValue = "Please select from the list..."
                Else
                    cmbStatus.SelectedIndex = 0
                End If
                If cmbRC.Items.Count > 1 Then
                    cmbRC.Items.Add("Please select from the list...")
                    cmbRC.SelectedValue = "Please select from the list..."
                Else
                    cmbRC.SelectedIndex = 0
                End If
                If cmbAgency.Items.Count > 1 Then
                    cmbAgency.Items.Add("Please select from the list...")
                    cmbAgency.SelectedValue = "Please select from the list..."
                Else
                    cmbAgency.SelectedIndex = 0
                End If
                If cmbDiv.Items.Count > 1 Then
                    cmbDiv.Items.Add("Please select from the list...")
                    cmbDiv.SelectedValue = "Please select from the list..."
                Else
                    cmbDiv.SelectedIndex = 0
                End If
                If cmbDept.Items.Count > 1 Then
                    cmbDept.Items.Add("Please select from the list...")
                    cmbDept.SelectedValue = "Please select from the list..."
                Else
                    cmbDept.SelectedIndex = 0
                End If
                If cmbSection.Items.Count > 1 Then
                    cmbSection.Items.Add("Please select from the list...")
                    cmbSection.SelectedValue = "Please select from the list..."
                Else
                    cmbSection.SelectedIndex = 0
                End If
                If cmbUnit.Items.Count > 1 Then
                    cmbUnit.Items.Add("Please select from the list...")
                    cmbUnit.SelectedValue = "Please select from the list..."
                Else
                    cmbUnit.SelectedIndex = 0
                End If
                If cmbSecurity.Items.Count > 1 Then
                    cmbSecurity.Items.Add("Please select from the list...")
                    cmbSecurity.SelectedValue = "Please select from the list..."
                Else
                    cmbSecurity.SelectedIndex = 0
                End If
                ''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''

                If Session("empid") = "" Then
                    'c.ConnectionString = connStr
                    'c.Open()
                    'cm.Connection = c
                    'cm.CommandText = "SELECT Emp_Cd + 1 FROM py_emp_master WHERE substring(Emp_Cd,1,2) = '" & Format(Now, "yy") & _
                    '                 "' ORDER BY Emp_Cd DESC SET ROWCOUNT 1"
                    'rs = cm.ExecuteReader
                    'If rs.Read Then
                    '    Me.txtId.Text = Format(rs(0), "000000")
                    'Else
                    '    Me.txtId.Text = Format(Now, "yy0001")
                    'End If
                    Me.txtBarcode.Text = Me.txtId.Text
                    'cm.Dispose()
                    'c.Close()
                End If

                If Session("empid") <> "" Then
                    'c.ConnectionString = connStr
                    'c.Open()
                    cm.Connection = c
                    cm.CommandText = "select Rc_Cd,Agency_Cd,DivCd,DeptCd,SectionCd,UnitCd,Emp_Cd,BarcodeId," & _
                        "Emp_Fname,Emp_Mname,Emp_Lname,NickName,Pos_Cd,EmploymentType,Emp_Status,Confidential," & _
                        "GroupCd, User_Id " & _
                        "from py_emp_master where " & "Emp_Cd='" & Session("empid") & "'"
                    Try
                        rs = cm.ExecuteReader
                        If rs.Read Then
                            txtId.Text = IIf(IsDBNull(rs("Emp_Cd")), "", rs("Emp_Cd"))
                            txtBarcode.Text = IIf(IsDBNull(rs("BarcodeId")), "", rs("BarcodeId"))
                            txtNexusId.Text = IIf(IsDBNull(rs("User_Id")), "", rs("User_Id"))
                            txtFirst.Text = IIf(IsDBNull(rs("Emp_Fname")), "", rs("Emp_Fname"))
                            txtMiddle.Text = IIf(IsDBNull(rs("Emp_Mname")), "", rs("Emp_Mname"))
                            txtLast.Text = IIf(IsDBNull(rs("Emp_Lname")), "", rs("Emp_Lname"))
                            txtNick.Text = IIf(IsDBNull(rs("NickName")), "", rs("NickName"))
                            chkConfi.Checked = rs("Confidential")
                            chkConfi.Enabled = Session("userlevel") = "1"
                            rdoGroup.SelectedValue = rs("GroupCd")

                            cmbRC.SelectedValue = rs("Rc_Cd") 'PointData("select Rc_Cd,Descr from rc where Rc_Cd='" & rs("Rc_Cd") & "'")
                            cmbAgency.SelectedValue = rs("Agency_Cd") 'PointData("select AgencyCd,AgencyName from agency where AgencyCd='" & rs("Agency_Cd") & "'")
                            cmbDiv.SelectedValue = rs("DivCd") 'PointData("select Div_Cd,Descr from hr_div_ref where Div_Cd='" & rs("DivCd") & "'")
                            cmbDept.SelectedValue = rs("DeptCd") 'PointData("select Dept_Cd,Descr from hr_dept_ref where Dept_Cd='" & rs("DeptCd") & "'")
                            cmbSection.SelectedValue = rs("SectionCd") 'PointData("select Section_Cd,Descr from hr_section_ref where Section_Cd='" & rs("SectionCd") & "'")
                            cmbUnit.SelectedValue = rs("UnitCd") 'PointData("select Unit_Cd,Descr from hr_unit_ref where Unit_Cd='" & rs("UnitCd") & "'")
                            cmbPos.SelectedValue = rs("Pos_Cd") 'PointData("select Pos_Cd,Position from py_position_ref where Pos_Cd='" & rs("Pos_Cd") & "'")
                            cmbSecurity.SelectedValue = rs("EmploymentType") 'PointData("select EmploymentType,Descr from hr_employment_type where EmploymentType='" & rs("EmploymentType") & "'")
                            cmbStatus.SelectedValue = rs("Emp_Status") 'PointData("Select Status_Code,Descr from py_employee_stat where Status_Code='" & rs("Emp_Status") & "'")
                            Session("oldval") = "Emp Id=" & txtId.Text & _
                                "|Biometrics Id=" & txtBarcode.Text & _
                                "|Nexus/Kiosk Id=" & txtNexusId.Text & _
                                "|First Name=" & txtFirst.Text & _
                                "|Middle Name=" & txtMiddle.Text & _
                                "|Last Name=" & txtLast.Text & _
                                "|Nickname=" & txtNick.Text & _
                                "|Cost Center=" & IIf(IsDBNull(rs("Rc_Cd")), "", rs("Rc_Cd")) & _
                                "|Agency=" & IIf(IsDBNull(rs("Agency_Cd")), "", rs("Agency_Cd")) & _
                                "|Division=" & IIf(IsDBNull(rs("DivCd")), "", rs("DivCd")) & _
                                "|Department=" & IIf(IsDBNull(rs("DeptCd")), "", rs("DeptCd")) & _
                                "|Section=" & IIf(IsDBNull(rs("SectionCd")), "", rs("SectionCd")) & _
                                "|Unit=" & IIf(IsDBNull(rs("UnitCd")), "", rs("UnitCd")) & _
                                "|Position=" & IIf(IsDBNull(rs("Pos_Cd")), "", rs("Pos_Cd")) & _
                                "|Rank=" & IIf(IsDBNull(rs("EmploymentType")), "", rs("EmploymentType")) & _
                                "|Confidential Employee?=" & IIf(rs("Confidential") = 1, "Yes", "No") & _
                                "|Group=" & rs("GroupCd") & _
                                "|Emp Status=" & IIf(IsDBNull(rs("Emp_Status")), "", rs("Emp_Status"))
                        End If
                        rs.Close()
                    Catch ex As sqlclient.sqlexception
                        Response.Write("Error in retrieving data. " & ex.Message)
                    End Try
                    c.Close()
                ElseIf Session("fromapplicant") = "1" Then
                    Dim vRC As String = ""
                    Dim vAgency As String = ""
                    Dim vDiv As String = ""
                    Dim vDept As String = ""
                    Dim vSection As String = ""
                    Dim vUnit As String = ""
                    Dim vPos As String = ""
                    Dim iCtr As Integer = 1
                    Dim vStatus As String = ""

                    'c.ConnectionString = connStr
                    'c.Open()
                    cm.Connection = c
                    cm.CommandText = "select * from hr_applicant_master where ApplicantNo=" & Session("applicantno")
                    rs = cm.ExecuteReader
                    If rs.Read Then
                        txtFirst.Text = rs("Fname")
                        txtMiddle.Text = rs("Mname")
                        txtLast.Text = rs("Lname")
                        txtNick.Text = rs("NickName")
                    End If
                    rs.Close()
                    cm.CommandText = "select * from hr_hiring_request where Request_No=" & _
                        Session("reqno")
                    rs = cm.ExecuteReader
                    If rs.Read Then
                        vRC = rs("Rc_Cd")
                        vAgency = rs("Office_Cd")
                        vDiv = rs("Div_Cd")
                        vDept = rs("Dept_Cd")
                        vSection = rs("Section_Cd")
                        vUnit = rs("Unit_Cd")
                        vPos = rs("Position_Cd")
                        vStatus = IIf(IsDBNull(rs("Emp_Status")), "", rs("Emp_Status"))
                    End If
                    rs.Close()
                    cm.CommandText = "select count(*) from py_emp_master where year(Start_Date)=" & _
                        Now.Year
                    rs = cm.ExecuteReader
                    If rs.Read Then
                        iCtr = IIf(IsDBNull(rs(0)), 0, rs(0)) + 1
                    End If
                    rs.Close()
                    txtId.Text = txtLast.Text.Substring(0, 1) & Format(Now.Year - 2000, "00") & _
                        Format(Now.Month, "00") & Format(iCtr, "000")
                    txtBarcode.Text = txtId.Text
                    cm.Dispose()
                    c.Close()
                    cmbRC.SelectedValue = vRC 'PointData("select Rc_Cd,Descr from rc where Rc_Cd='" & vRC & "'")
                    cmbAgency.SelectedValue = vAgency 'PointData("select AgencyCd,AgencyName from agency where AgencyCd='" & vAgency & "'")
                    cmbDiv.SelectedValue = vDiv 'PointData("select Div_Cd,Descr from hr_div_ref where Div_Cd='" & vDiv & "'")
                    cmbDept.SelectedValue = vDept 'PointData("select Dept_Cd,Descr from hr_dept_ref where Dept_Cd='" & vDept & "'")
                    cmbSection.SelectedValue = vSection 'PointData("select Section_Cd,Descr from hr_section_ref where Section_Cd='" & vSection & "'")
                    cmbUnit.SelectedValue = vUnit 'PointData("select Unit_Cd,Descr from hr_unit_ref where Unit_Cd='" & vUnit & "'")
                    cmbPos.SelectedValue = vPos 'PointData("select Pos_Cd,Position from py_position_ref where Pos_Cd='" & vPos & "'")
                    cmbStatus.SelectedValue = vStatus 'PointData("Select Status_Code,Descr from py_employee_stat where Status_Code='" & vStatus & "'")
                End If
                c.Dispose()
                cm.Dispose()
            End If
        End Sub

        Private Sub cmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
            Session.Remove("oldval")
            Session.Remove("newval")
            Session.Remove("empid")
            vScript = "window.close();"
        End Sub

        Private Sub txtFirst_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtFirst.Init
            Dim txt As System.Web.UI.WebControls.TextBox
            txt = CType(sender, System.Web.UI.WebControls.TextBox)
            txt.Attributes.Add("onblur", "copyval();")
        End Sub

        Private Sub cmdSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSave.Click
            If Page.IsValid Then
                Dim vSQL As String = ""
                Dim c As New SqlClient.SqlConnection(connStr)
                Dim cm As New SqlClient.SqlCommand

                If cmbRC.SelectedValue = "Please select from the list..." Then
                    vScript = "alert('Please select the type of Cost Center first before saving.');"
                    Exit Sub
                End If
                If cmbAgency.SelectedValue = "Please select from the list..." Then
                    vScript = "alert('Please select the type of Office first before saving.');"
                    Exit Sub
                End If
                If cmbDiv.SelectedValue = "Please select from the list..." Then
                    vScript = "alert('Please select the type of Division first before saving.');"
                    Exit Sub
                End If
                If cmbDept.SelectedValue = "Please select from the list..." Then
                    vScript = "alert('Please select the type of Department first before saving.');"
                    Exit Sub
                End If
                If cmbSection.SelectedValue = "Please select from the list..." Then
                    vScript = "alert('Please select the type of Section first before saving.');"
                    Exit Sub
                End If
                If cmbUnit.SelectedValue = "Please select from the list..." Then
                    vScript = "alert('Please select the type of Unit first before saving.');"
                    Exit Sub
                End If
                If cmbPos.SelectedValue = "Please select from the list..." Then
                    vScript = "alert('Please select the type of Position first before saving.');"
                    Exit Sub
                End If
                If cmbSecurity.SelectedValue = "Please select from the list..." Then
                    vScript = "alert('Please select the type of Rank first before saving.');"
                    Exit Sub
                End If

                'c.ConnectionString = connStr
                Try
                    c.Open()
                Catch ex As SqlClient.SqlException
                    vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                        ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                    c.Dispose()
                    cm.Dispose()
                    Exit Sub
                End Try

                cm.Connection = c
                If Session("empid") = "" Then 'add mode
Again:
                    vSQL = "insert into py_emp_master (Rc_Cd,Agency_Cd,DivCd,DeptCd,SectionCd,UnitCd," & _
                        "Emp_Cd,BarcodeId,User_Id,Emp_Fname,Emp_Mname,Emp_Lname,NickName,Pos_Cd," & _
                        "EmploymentType,Emp_Status,Confidential,GroupCd,ImgPath,PinExpiry,CumulativeGrace) values ('" & _
                        cmbRC.SelectedValue & "','" & _
                        cmbAgency.SelectedValue & "','" & _
                        cmbDiv.SelectedValue & "','" & _
                        cmbDept.SelectedValue & "','" & _
                        cmbSection.SelectedValue & "','" & _
                        cmbUnit.SelectedValue & "','" & _
                        RTrim(txtId.Text.Trim) & "','" & _
                        RTrim(txtBarcode.Text.Trim) & "','" & _
                        RTrim(txtNexusId.Text.Trim) & "','" & _
                        txtFirst.Text & "','" & _
                        txtMiddle.Text & "','" & _
                        txtLast.Text & "','" & _
                        txtNick.Text & "','" & _
                        cmbPos.SelectedValue & "','" & _
                        cmbSecurity.SelectedValue & "','" & _
                        cmbStatus.SelectedValue & "'," & _
                        If(chkConfi.Checked, 1, 0) & ",'" & rdoGroup.SelectedValue & _
                        "','../pics/" & txtId.Text & "', '" & Now() & "',1)"

                    Session("empid") = RTrim(txtId.Text.Trim)
                    cm.CommandText = vSQL
                    Try
                        cm.ExecuteNonQuery()
                        Session("newval") = "Emp Id=" & txtId.Text & _
                            "|Biometrics Id=" & txtBarcode.Text & _
                            "|Nexus/Kiosk Id=" & txtNexusId.Text & _
                            "|First Name=" & txtFirst.Text & _
                            "|Middle Name=" & txtMiddle.Text & _
                            "|Last Name=" & txtLast.Text & _
                            "|Nickname=" & txtNick.Text & _
                            "|Cost Center=" & cmbRC.SelectedValue & _
                            "|Agency=" & cmbAgency.SelectedValue & _
                            "|Division=" & cmbDiv.SelectedValue & _
                            "|Department=" & cmbDept.SelectedValue & _
                            "|Section=" & cmbSection.SelectedValue & _
                            "|Unit=" & cmbUnit.SelectedValue & _
                            "|Position=" & cmbPos.SelectedValue & _
                            "|Rank=" & cmbSecurity.SelectedValue & _
                            "|Confidential Employee?=" & IIf(chkConfi.Checked, "Yes", "No") & _
                            "|Group=" & rdoGroup.SelectedValue & _
                            "|Emp Status=" & cmbStatus.SelectedValue
                        EventLog(Session("uid"), Request.ServerVariables("REMOTE_ADDR"), "ADD", _
                            Session("oldval"), Session("newval"), "Employee ID: " & txtId.Text & _
                            " was added", "201 Profile", c)
                        Session.Remove("oldval")
                        Session.Remove("newval")
                        vScript = "alert('Adding of employee successfully saved.\nPlease update the leave parameters for newly added employee." & _
                            "\n\n System->Table Matrix->Leave Table');winleave.focus();window.location='empstep2.aspx'"
                    Catch ex As SqlClient.SqlException
                        txtId.Text = Format(Val(txtId.Text) + 1, "000000")
                        txtBarcode.Text = txtId.Text
                        vScript = "alert('Error occurred while trying to save your changes.  Error is: " & _
                            ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                        c.Close()
                        c.Dispose()
                        cm.Dispose()
                        Exit Sub
                        'GoTo Again
                    End Try
                Else        'edit mode
                    If Session("empid") <> RTrim(txtId.Text.Trim) Then  'employee id has been changed. update necessary dependencies
                        UpdateSubTables(c)
                    End If
                    vSQL = "update py_emp_master set Rc_Cd='" & cmbRC.SelectedValue & _
                        "',Agency_Cd='" & cmbAgency.SelectedValue & _
                        "',DivCd='" & cmbDiv.SelectedValue & _
                        "',DeptCd='" & cmbDept.SelectedValue & _
                        "',SectionCd='" & cmbSection.SelectedValue & _
                        "',UnitCd='" & cmbUnit.SelectedValue & _
                        "',Emp_Cd='" & RTrim(txtId.Text.Trim) & _
                        "',BarCodeId='" & RTrim(txtBarcode.Text.Trim) & _
                        "',User_Id='" & RTrim(txtNexusId.Text.Trim) & _
                        "',Emp_Fname='" & txtFirst.Text & _
                        "',Emp_Mname='" & txtMiddle.Text & _
                        "',Emp_Lname='" & txtLast.Text & _
                        "',NickName='" & txtNick.Text & _
                        "',Pos_Cd='" & cmbPos.SelectedValue & _
                        "',EmploymentType='" & cmbSecurity.SelectedValue & _
                        "',Confidential=" & IIf(chkConfi.Checked, 1, 0) & _
                        ",GroupCd='" & rdoGroup.SelectedValue & _
                        "',Emp_Status='" & cmbStatus.SelectedValue & _
                        "',Modified_Date='" & Format(Now, "yyy/MM/dd HH:mm:ss") & _
                        "',Modified_By='" & Session("uid") & _
                        "' where Emp_Cd='" & Session("empid") & "'"
                    cm.CommandText = vSQL
                    Try
                        cm.ExecuteNonQuery()
                        Session("empid") = RTrim(txtId.Text.Trim)
                        Session("newval") = "Emp Id=" & txtId.Text & _
                            "|Biometrics Id=" & txtBarcode.Text & _
                            "|First Name=" & txtFirst.Text & _
                            "|Middle Name=" & txtMiddle.Text & _
                            "|Last Name=" & txtLast.Text & _
                            "|Nickname=" & txtNick.Text & _
                            "|Cost Center=" & cmbRC.SelectedValue & _
                            "|Agency=" & cmbAgency.SelectedValue & _
                            "|Division=" & cmbDiv.SelectedValue & _
                            "|Department=" & cmbDept.SelectedValue & _
                            "|Section=" & cmbSection.SelectedValue & _
                            "|Unit=" & cmbUnit.SelectedValue & _
                            "|Position=" & cmbPos.SelectedValue & _
                            "|Rank=" & cmbSecurity.SelectedValue & _
                            "|Confidential Employee?=" & IIf(chkConfi.Checked, "Yes", "No") & _
                            "|Group=" & rdoGroup.SelectedValue & _
                            "|Emp Status=" & cmbStatus.SelectedValue
                        EventLog(Session("uid"), Request.ServerVariables("REMOTE_ADDR"), "EDIT", _
                            Session("oldval"), Session("newval"), "Employee ID: " & txtId.Text & _
                            " was added/edited", "201 Profile", c)
                        Session.Remove("oldval")
                        Session.Remove("newval")
                    Catch ex As SqlClient.SqlException
                        vScript = "alert('Error occurred while trying to save your changes.  Error is: " & _
                            ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                        c.Close()
                        c.Dispose()
                        cm.Dispose()
                        Exit Sub
                    End Try
                End If

                If Session("fromapplicant") = "1" Then
                    Try
                        Dim dr As SqlClient.SqlDataReader
                        cm.CommandText = "select * from hr_applicant_master where ApplicantNo=" & _
                            Session("applicantno")
                        dr = cm.ExecuteReader
                        If dr.Read Then
                            vSQL = "update py_emp_master set Emp_Address='" & _
                                IIf(IsDBNull(dr("Address")), "", dr("Address")) & _
                                "',Start_Date='" & Format(Now, "yyyy/MM/dd") & _
                                "',Emp_Tel='" & IIf(IsDBNull(dr("Tel")), "", dr("Tel")) & _
                                "',Emp_Email='" & IIf(IsDBNull(dr("Email")), "", dr("Email")) & _
                                "',Res_Cert='" & IIf(IsDBNull(dr("Res_Cert")), "", dr("Res_Cert")) & _
                                "',Sss_No='" & IIf(IsDBNull(dr("Sss_No")), "", dr("Sss_No")) & _
                                "',Gsis_No='" & IIf(IsDBNull(dr("Gsis_No")), "", dr("Gsis_No")) & _
                                "',Pagibig_No='" & IIf(IsDBNull(dr("Pagibig_No")), "", dr("Pagibig_No")) & _
                                "',Tin='" & IIf(IsDBNull(dr("Tin")), "", dr("Tin")) & _
                                "',Pay_Cd='SM',Tax_Cd='Z',Start_Date='" & Format(Now, "yyyy/MM/dd") & _
                                "',Allow_Aca=1,Allow_Pera=1,Allow_Rata=1,Allow_Pagibig=1,Allow_Withtax=1," & _
                                "Allow_Medicare=1,Emp_Status='99',Allow_Req_Hrs=1,Allow_Reg_Timein=1," & _
                                "Bday='" & Format(CDate(dr("Bday")), "yyyy/MM/dd") & _
                                "',Male=" & dr("Male") & ",Civil_Cd='" & IIf(IsDBNull(dr("Civil_Cd")), "", dr("Civil_Cd")) & _
                                "',Prov_Address='" & IIf(IsDBNull(dr("Prov_Address")), "", dr("Prov_Address")) & _
                                "',Skills='" & IIf(IsDBNull(dr("Skills")), "", dr("Skills")) & _
                                "',Self_Trainings='" & IIf(IsDBNull(dr("Self_Trainings")), "", dr("Self_Trainings")) & _
                                "',BirthPlace='" & IIf(IsDBNull(dr("BirthPlace")), "", dr("BirthPlace")) & _
                                "',Height=" & IIf(IsDBNull(dr("Height")), 0, dr("Height")) & _
                                ",Weight=" & IIf(IsDBNull(dr("Weight")), 0, dr("Weight")) & _
                                ",SpouseName='" & IIf(IsDBNull(dr("Spouse_Lname")), "", dr("Spouse_Lname")) & _
                                ", " & IIf(IsDBNull(dr("Spouse_Fname")), "", dr("Spouse_Fname")) & " " & _
                                IIf(IsDBNull(dr("Spouse_Mname")), "", dr("Spouse_Mname")) & _
                                "',ChildrenNo=" & IIf(IsDBNull(dr("ChildrenNo")), 0, dr("ChildrenNo")) & _
                                ",ReligionCd='" & IIf(IsDBNull(dr("ReligionCd")), "", dr("ReligionCd")) & _
                                "',DialectCd='" & IIf(IsDBNull(dr("DialectCd")), "", dr("DialectCd")) & _
                                "',LanguageCd='" & IIf(IsDBNull(dr("LanguageCd")), "", dr("LanguageCd")) & _
                                "',BloodType='" & IIf(IsDBNull(dr("BloodType")), "", dr("BloodType")) & _
                                "',CountryCd='" & IIf(IsDBNull(dr("CountryCd")), "", dr("CountryCd")) & _
                                "',EmergencyContactPerson='" & IIf(IsDBNull(dr("EmergencyContactPerson")), "", _
                                dr("EmergencyContactPerson")) & "',CitizenCd='" & _
                                IIf(IsDBNull(dr("CitizenCd")), "", dr("CitizenCd")) & _
                                "',EmergencyContactNo='" & IIf(IsDBNull(dr("EmergencyContactNo")), "", _
                                dr("EmergencyContactNo")) & "',Req_Hrs_Day=8,OtherInfo='" & _
                                IIf(IsDBNull(dr("OtherInfo")), "", dr("OtherInfo")) & _
                                "',Spouse_Fname='" & IIf(IsDBNull(dr("Spouse_Fname")), "", dr("Spouse_Fname")) & _
                                "',Spouse_Lname='" & IIf(IsDBNull(dr("Spouse_Lname")), "", dr("Spouse_Lname")) & _
                                "',Spouse_Mname='" & IIf(IsDBNull(dr("Spouse_Mname")), "", dr("Spouse_Mname")) & _
                                "',Spouse_Occupation='" & IIf(IsDBNull(dr("Spouse_Occupation")), "", dr("Spouse_Occupation")) & _
                                "',Spouse_Emr='" & IIf(IsDBNull(dr("Spouse_Emr")), "", dr("Spouse_Emr")) & _
                                "',Spouse_Bus_Addr='" & IIf(IsDBNull(dr("Spouse_Bus_Addr")), "", dr("Spouse_Bus_Addr")) & _
                                "',Spouse_Tel='" & IIf(IsDBNull(dr("Spouse_Tel")), "", dr("Spouse_Tel")) & _
                                "',Father_Fname='" & IIf(IsDBNull(dr("Father_Fname")), "", dr("Father_Fname")) & _
                                "',Father_Lname='" & IIf(IsDBNull(dr("Father_Lname")), "", dr("Father_Lname")) & _
                                "',Father_Mname='" & IIf(IsDBNull(dr("Father_Mname")), "", dr("Father_Mname")) & _
                                "',Mother_Fname='" & IIf(IsDBNull(dr("Mother_Fname")), "", dr("Mother_Fname")) & _
                                "',Mother_Lname='" & IIf(IsDBNull(dr("Mother_Lname")), "", dr("Mother_Lname")) & _
                                "',Mother_Mname='" & IIf(IsDBNull(dr("Mother_Mname")), "", dr("Mother_Mname")) & _
                                "',PhicNo='" & IIf(IsDBNull(dr("PhicNo")), "", dr("PhicNo")) & _
                                "',ApplicantNo=" & dr("ApplicantNo") & _
                                " where Emp_Cd='" & txtId.Text & "'"
                        End If
                        dr.Close()
                        cm.CommandText = vSQL
                        cm.ExecuteNonQuery()
                        cm.CommandText = "update hr_applicant_master set Hired=1 where ApplicantNo=" & _
                            Session("applicantno")
                        cm.ExecuteNonQuery()
                    Catch ex As SqlClient.SqlException
                        vScript = "alert('An error occurred while trying to execute the command. " & _
                            "Error is: " & ex.Message.Replace("'", "").Replace(vbCrLf, "") & "');"
                        c.Close()
                        c.Dispose()
                        cm.Dispose()
                        Exit Sub
                    End Try
                End If
                c.Close()
                c.Dispose()
                cm.Dispose()
                If vScript = "" Then
                    Server.Transfer("empstep2.aspx")
                End If
            End If
        End Sub
        Private Sub UpdateSubTables(ByRef c As SqlClient.SqlConnection)
            Dim iCtr As Integer
            Dim vStr As String = ""
            Dim vParsed(2) As String
            Dim cm As New SqlClient.SqlCommand
            Dim vSync(36) As String
            cm.Connection = c

            vSync(1) = "py_emp_leave.Emp_Cd"
            vSync(2) = "py_emp_time_log.Emp_Cd"
            vSync(3) = "py_emp_time_sched.Emp_Cd"
            vSync(4) = "py_final_pay.Emp_Cd"
            vSync(5) = "py_gsis_remittance.Emp_Cd"
            vSync(6) = "py_incentives_dtl.Emp_Cd"
            vSync(7) = "py_loan_dtl.Emp_Cd"
            vSync(8) = "py_loan_hdr.Emp_Cd"
            vSync(9) = "py_loan_remittance.Emp_Cd"
            vSync(10) = "py_logsheet.EmpCd"
            vSync(11) = "py_medicare.Emp_Cd"
            vSync(12) = "py_other_premiums.Emp_Id"
            vSync(13) = "py_pagibig.Emp_Cd"
            vSync(14) = "py_prev_employer_income.Emp_Cd"
            vSync(15) = "py_report.Emp_Cd"
            vSync(16) = "py_sss_remit.Emp_Cd"
            vSync(17) = "py_tax_remittance.Emp_Cd"
            vSync(18) = "py_time_log.Emp_Cd"
            vSync(19) = "py_time_log_dtl.Emp_Cd"
            vSync(20) = "py_time_log_raw.Emp_Cd"
            'hr tables
            vSync(21) = "hr_dependents.Emp_Cd"
            vSync(22) = "hr_dependents_equity.Emp_Cd"
            vSync(23) = "hr_emp_assets.Emp_Cd"
            vSync(24) = "hr_emp_career_movement.Emp_Cd"
            vSync(24) = "hr_emp_certificates.Emp_Cd"
            vSync(25) = "hr_emp_employment_hist.Emp_Id"

            vSync(26) = "hr_emp_training.Emp_Id"
            vSync(27) = "hr_emp_violate_commend.Emp_Id"
            vSync(28) = "hr_emp_exit_hdr.Emp_Cd"
            vSync(29) = "hr_emp_exit_dtl.Emp_Cd"
            vSync(30) = "hr_leave_application.Emp_Cd"
            vSync(31) = "hr_emp_license_ref.Emp_Cd"
            vSync(32) = "hr_emp_org.Emp_Id"
            vSync(33) = "hr_emp_projects.Emp_Cd"
            vSync(34) = "hr_emp_reference.Emp_Cd"
            vSync(35) = "hr_emp_scholastic.Emp_Cd"
            vSync(36) = "hr_emp_seminar.Emp_Id"
            'vSync(37) = "hr_emp_evaluation_hdr.Emp_Cd"
            'vSync(38) = "hr_emp_evaluation_dtl.Emp_Cd"

            For iCtr = 1 To 36
                vParsed = vSync(iCtr).Split(".")

                cm.CommandText = "update " & vParsed(0) & " set " & vParsed(1) & "='" & RTrim(txtId.Text.Trim) & _
                    "' where " & vParsed(1) & "='" & Session("empid") & "'"
                Try
                    cm.ExecuteNonQuery()
                Catch ex As SqlClient.SqlException
                    vScript = "alert('An error occurred while trying to execute the command. " & _
                            "Error is: " & ex.Message.Replace("'", "").Replace(vbCrLf, "") & "');"
                    Exit For
                End Try
            Next iCtr
            cm.Dispose()
        End Sub
        Private Sub vldEmpId_ServerValidate(ByVal source As System.Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles vldEmpId.ServerValidate
            If Session("empid") <> txtId.Text Then
                Dim c As New SqlClient.SqlConnection(connStr)
                Dim cm As New SqlClient.SqlCommand
                Dim rs As SqlClient.SqlDataReader

                Try
                    c.Open()
                Catch ex As SqlClient.SqlException
                    vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                        ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                    c.Dispose()
                    cm.Dispose()
                    args.IsValid = False
                    Exit Sub
                End Try

                args.IsValid = False
                cm.Connection = c
                cm.CommandText = "select Emp_Cd from py_emp_master where Emp_Cd='" & txtId.Text & "'"
                Try
                    rs = cm.ExecuteReader
                    rs.Read()
                    args.IsValid = Not rs.HasRows
                Catch ex As SqlClient.SqlException
                    vScript = "alert('Error executing command during employee id validation. Error is: " & _
                        ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                Finally
                    cm.Dispose()
                    c.Close()
                    c.Dispose()
                End Try
            Else
                args.IsValid = True
            End If
        End Sub

        Protected Sub cmbQuickNavi_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbQuickNavi.SelectedIndexChanged
            Session.Remove("oldval")
            Session.Remove("newval")
            Server.Transfer(cmbQuickNavi.SelectedValue)
        End Sub

    End Class
End Namespace
