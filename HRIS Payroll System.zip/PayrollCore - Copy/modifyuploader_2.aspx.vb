﻿Imports denaro.fis
Partial Class modifyuploader_2
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Public vDump As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            vScript = "alert('Your login session has expired. Please re-login again.'); window.close();"
            Exit Sub
        End If
        If Not IsPostBack Then
            txtProfileCd.Text = Request.Item("id")
        End If
    End Sub

    Protected Sub cmdUpload_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdUpload.Click
        Dim c As New sqlclient.sqlConnection(connStr)
        Dim cm As New sqlclient.sqlCommand
        Dim rs As sqlclient.sqlDataReader
        Dim vFile As String = Server.MapPath(".") & "\uploaded\" & Session.SessionID & "-" & txtProfileCd.Text & ".csv"
        Dim vData() As String
        Dim vTable As String = ""
        Dim vHeaders As String = ""
        Dim vClass As String = "odd"
        Dim vContent As String = ""

        If IO.File.Exists(vFile) Then
            Try
                IO.File.Delete(vFile)
            Catch ex As IO.IOException
                vScript = "alert('Failed to delete the temp file due to: " & _
                    ex.Message.Replace("'", "").Replace(vbCrLf, "") & "');"
                Exit Sub
            End Try
        End If

        Try
            txtUpload.SaveAs(vFile)
        Catch ex As system.exception
            vScript = "alert('Error occurred while trying to upload the file. Error is: " & _
                ex.Message.Replace("'", "").Replace(vbCrLf, "") & "');"
            Exit Sub
        End Try

        'build the contents of the combo box
        Try
            c.Open()
        Catch ex As sqlclient.sqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace("'", "").Replace(vbCrLf, "") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        cm.Connection = c
        cm.CommandText = "select TableName from _db where ProfileCd='" & txtProfileCd.Text & "'"
        Try
            rs = cm.ExecuteReader
            If rs.Read Then
                vTable = rs("TableName")
            End If
            rs.Close()
            cm.CommandText = "select * from INFORMATION_SCHEMA.Columns where Table_Schema='phc' and " & _
                "Table_Name='" & vTable & "'"
            rs = cm.ExecuteReader
            vContent = "<option value=''></option>"
            Do While rs.Read
                vContent += "<option value='" & rs("Column_Name") & "'>" & _
                    IIf(rs("Column_Comment") = "", rs("Column_Name"), rs("Column_Comment")) & "</option>"
            Loop
            rs.Close()
        Catch ex As sqlclient.sqlException
            vScript = "alert('Error occurred while trying to read the database. Error is: " & _
                ex.Message.Replace("'", "").Replace(vbCrLf, "") & "');"
        Finally
            c.Close()
            c.Dispose()
            cm.Dispose()
        End Try

        Try
            vData = IO.File.ReadAllLines(vFile)
            vHeaders = vData(0)
            vData = vHeaders.Split(txtDelimiter.Text)
            vDump = "<table class='mainGridView'><tr class='titleBar'>" & _
                "<th>Col #</th><th>Source Fieldname</th><th>Target Fieldname</th></tr>"
            For i As Integer = 0 To UBound(vData)
                vDump += "<tr class='" & vClass & "'><td>" & i + 1 & "</td><td>" & _
                    vData(i) & "</td><td><select class='labelL' width='100px' id='cmb" & vData(i) & "'>" & _
                    vContent & "</select></td></tr>"
                vClass = IIf(vClass = "odd", "even", "odd")
            Next
            vDump += "</table>"
        Catch ex As IO.IOException
            vScript = "alert('Error occurred while trying to read the file. Error is: " & _
                ex.Message.Replace("'", "").Replace(vbCrLf, "") & "');"
            Exit Sub
        End Try
    End Sub
End Class
