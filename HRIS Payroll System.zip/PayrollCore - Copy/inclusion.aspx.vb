﻿Imports denaro
Partial Class inclusion
    Inherits System.Web.UI.Page
    Public vData As New StringBuilder
    Public vScript As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If

        If Not IsPostBack Then
            If Not CanRun(Session("caption"), Request.Item("id")) Then
                Session("denied") = "1"
                Server.Transfer("main.aspx")
                Exit Sub
            End If

            Dim i As Integer

            BuildCombo("select Rc_Cd,Descr from rc where exists (select User_Id from rights_list where User_Id='" & _
                    Session("uid") & "' and property='rc' and Property_Value=Rc_Cd) order by Descr", cmbRC)
            BuildCombo("select AgencyCd,AgencyName from agency where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='agency' and Property_Value=AgencyCd) order by AgencyName", cmbOfc)
            BuildCombo("select Div_Cd,Descr from hr_div_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='division' and Property_Value=Div_Cd) order by Descr", cmbDiv)
            BuildCombo("select Dept_Cd,Descr from hr_dept_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='department' and Property_Value=Dept_Cd) order by Descr", cmbDept)
            BuildCombo("select Section_Cd,Descr from hr_section_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='section' and Property_Value=Section_Cd) order by Descr", cmbSection)
            BuildCombo("select Unit_Cd,Descr from hr_unit_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='unit' and Property_Value=Unit_Cd) order by Descr", cmbUnit)

            BuildCombo("select EmploymentType,Descr from hr_employment_type where exists (select User_Id from rights_list where User_Id='" & _
                    Session("uid") & "' and property='employmenttype' and Property_Value=EmploymentType) order by Descr", cmbEmpType)

            BuildCombo("select Pay_Cd, Payment from py_pay_mode  order by Payment", cmbPaymode)

            cmbRC.Items.Add("All")
            cmbRC.SelectedValue = "All"
            cmbDiv.Items.Add("All")
            cmbDiv.SelectedValue = "All"
            cmbDept.Items.Add("All")
            cmbDept.SelectedValue = "All"
            cmbSection.Items.Add("All")
            cmbSection.SelectedValue = "All"
            cmbUnit.Items.Add("All")
            cmbUnit.SelectedValue = "All"

            cmbEmpType.Items.Add("All")
            cmbEmpType.SelectedValue = "All"

            cmbYear.Items.Clear()

            For i = Now.Year - 3 To Now.Year
                cmbYear.Items.Add(i)
            Next
            cmbYear.SelectedValue = Now.Year

            Dim c As New sqlclient.sqlConnection(connStr)
            Dim cm As New SqlClient.SqlCommand("select distinct PayDate from py_report group  by PayDate order by PayDate desc", c)
            Dim rs As sqlclient.sqlDataReader

            c.Open()
            rs = cm.ExecuteReader
            cmbDiff.Items.Clear()
            Do While rs.Read
                cmbDiff.Items.Add(rs("PayDate"))
            Loop
            rs.Close()
            cm.Dispose()
            c.Close()
            c.Dispose()

            PayDateRef()

        End If
    End Sub

    Private Sub DataRefresh()

    End Sub
    Private Sub PayDateRef()
        Dim c As New sqlclient.sqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand("select distinct PayDate from py_report where Year(PayDate) = " & _
            cmbYear.SelectedValue & " group by PayDate order by PayDate desc", c)
        Dim rs As sqlclient.sqlDataReader

        c.Open()
        rs = cm.ExecuteReader
        cmbPaydate.Items.Clear()
        Do While rs.Read
            cmbPaydate.Items.Add(rs("PayDate"))
        Loop
        rs.Close()
        cm.Dispose()
        c.Close()
        c.Dispose()
        btnRelaod.Enabled = cmbPaydate.Items.Count > 0
    End Sub

    Private Sub GetInclusion(ByVal vFnlFilters As String)
        Dim c As New sqlclient.sqlConnection
        Dim cm As New sqlclient.sqlCommand
        Dim rs As sqlclient.sqlDataReader

        Dim sub_cm As New sqlclient.sqlCommand
        Dim sub_rs As sqlclient.sqlDataReader

        Dim s1_cm As New sqlclient.sqlCommand
        Dim s1_rs As sqlclient.sqlDataReader

        Dim vDeptname As String = ""
        Dim vSectName As String = ""
        Dim vSupName As String = ""
        Dim vUnitName As String = ""
        Dim vAllowance As Integer = 0
        Dim i As Integer = 1
        Dim vClass As String = "odd"

        c.ConnectionString = connStr
        c.Open()

        cm.Connection = c
        sub_cm.Connection = c
        s1_cm.Connection = c

        vData.AppendLine("<table id='tblSheet' style='width: 2000px; border-collapse: collapse; border-color: #000000; border: solid 0px #a8a8a9;' border='0'>")
        vData.AppendLine("<tr><td>")

        vData.AppendLine("<table style='width: 100%;'>")
        'vData.AppendLine("<tr><td>&nbsp;</td></tr>")
        vData.AppendLine("<tr><td class='labelC'><h3>" & cmbOfc.SelectedItem.Text & "</h3></td></tr>")
        vData.AppendLine("<tr><td class='labelC'>Inclusion for pay period " & cmbPaydate.SelectedValue & _
                            " vs. pay period " & cmbDiff.SelectedValue & "</td></tr>")
        vData.AppendLine("<tr><td style='height:5px'></td></tr>")
        vData.AppendLine("</table>")

        vData.AppendLine("</td></tr>")
        vData.AppendLine("<tr><td class='labelC'>")

        vData.AppendLine("<table style='width: 100%; border-collapse: collapse; border-color: #000000; border: solid 1px #a8a8a9;' border='1'>")
        vData.AppendLine("<tr class='titleBar'>")
        vData.AppendLine("<th style='width: 25px;'>#</th>")
        vData.AppendLine("<th>Full Name</th>")
        vData.AppendLine("<th style='width: 210px;'>Position</th>")
        vData.AppendLine("<th style='width: 90px;'>Date Hired</th>")
        vData.AppendLine("<th style='width: 90px;'>Company ID No.</th>")
        vData.AppendLine("<th style='width: 90px;'>SSS</th>")
        vData.AppendLine("<th style='width: 90px;'>Tin</th>")
        vData.AppendLine("<th style='width: 90px;'>Philhealth No.</th>")
        vData.AppendLine("<th style='width: 90px;'>Pagibig No.</th>")
        vData.AppendLine("<th style='width: 200px;'>Department</th>")
        vData.AppendLine("<th style='width: 90px;'>Mo. Basic Rate</th>")
        vData.AppendLine("<th style='width: 90px;'>Allowances</th>")
        vData.AppendLine("<th style='width: 70px;'>Tax Status</th>")
        vData.AppendLine("<th style='width: 170px;'>Immediate Supervisor</th>")
        vData.AppendLine("<th style='width: 190px;'>Section</th>")
        vData.AppendLine("<th style='width: 170px;'>Unit</th>")
        vData.AppendLine("</tr>")

        cm.CommandText = "select Emp_Cd, Name, Position, Deptcd " & _
            "from py_report a " & _
            "where Pay_Cd='" & cmbPaymode.SelectedValue & "' and paydate='" & Format(CDate(cmbPaydate.SelectedValue), "yyyy/MM/dd") & "' " & _
            "and not exists (select py_report.emp_cd from py_report where paydate='" & Format(CDate(cmbDiff.SelectedValue), "yyyy/MM/dd") & _
            "' and py_report.emp_cd=a.emp_cd) " & vFnlFilters & " order by name "

        Try
            rs = cm.ExecuteReader
            Do While rs.Read

                sub_cm.CommandText = "select Sss_no, Tin, Phicno, Start_Date, Pagibig_No, Deptcd, Rate_Month, DivCd, Tax_Cd, " & _
                "SectionCd, SupervisorCd, UnitCd from py_emp_master where Emp_Cd = '" & rs("Emp_Cd") & "' "
                sub_rs = sub_cm.ExecuteReader
                sub_rs.Read()

                s1_cm.CommandText = "select descr from hr_dept_ref where dept_Cd = '" & rs("Deptcd") & "'"
                s1_rs = s1_cm.ExecuteReader
                vDeptname = rs("Deptcd") & "=>Unkwon"
                If s1_rs.Read() Then
                    vDeptname = s1_rs("Descr")
                End If
                s1_rs.Close()

                s1_cm.CommandText = "select Emp_Lname, Emp_Fname from py_emp_master where Emp_Cd = '" & _
                    sub_rs("SupervisorCd") & "'"
                s1_rs = s1_cm.ExecuteReader
                vSupName = "Unkwon"
                If s1_rs.Read() Then
                    vSupName = s1_rs("Emp_Fname") & ", " & s1_rs("Emp_Lname")
                End If
                s1_rs.Close()


                s1_cm.CommandText = "select Descr from hr_section_ref where Section_Cd = '" & sub_rs("SectionCd") & "'"
                s1_rs = s1_cm.ExecuteReader
                vSectName = "Unkwon"
                If s1_rs.Read() Then
                    vSectName = s1_rs("Descr")
                End If
                s1_rs.Close()

                s1_cm.CommandText = "select Descr from hr_unit_ref where Unit_Cd = '" & sub_rs("UnitCd") & "'"
                s1_rs = s1_cm.ExecuteReader
                vUnitName = "Unkwon"
                If s1_rs.Read() Then
                    vUnitName = s1_rs("Descr")
                End If
                s1_rs.Close()

                s1_cm.CommandText = "select sum(incentive_Amt) as allowance from py_incentives_dtl " & _
                                    "where incentive_cd in ('Cloth', 'Rice') and Recurring <> 0 and Emp_Cd = '" & rs("Emp_Cd") & "' "
                s1_rs = s1_cm.ExecuteReader
                vAllowance = 0

                If s1_rs.Read() Then
                    If Not IsDBNull(s1_rs("Allowance")) Then
                        vAllowance = s1_rs("Allowance")
                    End If
                End If
                s1_rs.Close()

                vData.AppendLine("<tr class='" & vClass & "'>")
                vData.AppendLine("<td class='labelC'>&nbsp;" & i & "</td>")
                vData.AppendLine("<td class='labelL'>&nbsp;" & rs("Name") & "</td>")
                vData.AppendLine("<td class='labelL'>&nbsp;" & rs("Position") & "</td>")
                vData.AppendLine("<td class='labelC'>" & sub_rs("Start_Date") & "</td>")
                vData.AppendLine("<td class='labelC'>" & rs("Emp_Cd") & "</td>")

                vData.AppendLine("<td class='labelC'>" & sub_rs("Sss_No") & "</td>")
                vData.AppendLine("<td class='labelC'>" & sub_rs("Tin") & "</td>")
                vData.AppendLine("<td class='labelC'>" & sub_rs("Phicno") & "</td>")
                vData.AppendLine("<td class='labelC'>" & sub_rs("Pagibig_No") & "</td>")

                vData.AppendLine("<td class='labelL'>&nbsp;" & vDeptname & "</td>")
                vData.AppendLine("<td class='labelR'>" & Format(sub_rs("Rate_Month"), "###,##0.00") & "&nbsp;</td>")
                vData.AppendLine("<td class='labelR'>" & Format(vAllowance, "###,##0.00") & "</td>")
                vData.AppendLine("<td class='labelC'>" & sub_rs("Tax_Cd") & "</td>")
                vData.AppendLine("<td class='labelL'>&nbsp;" & vSupName & "</td>")

                vData.AppendLine("<td class='labelL'>&nbsp;" & vSectName & "</td>")
                vData.AppendLine("<td class='labelL'>&nbsp;" & vUnitName & "</td>")
                vData.AppendLine("</tr>")
                vClass = IIf(vClass = "odd", "even", "odd")
                sub_rs.Close()
                i += 1
            Loop
            vData.AppendLine("</table>")

            vData.AppendLine("</td></tr>")
            vData.AppendLine("</table>")
            rs.Close()
        Catch ex As system.exception
            vData.AppendLine(ex.Message)
        Finally
            c.Close()
            c.Dispose()
            cm.Dispose()
        End Try

    End Sub

    Private Sub GetExclusion(ByVal vFnlFilters As String)
        Dim c As New sqlclient.sqlConnection
        Dim cm As New sqlclient.sqlCommand
        Dim rs As sqlclient.sqlDataReader

        'Dim sub_cm As New sqlclient.sqlCommand
        'Dim sub_rs As sqlclient.sqlDataReader

        Dim vDeptname As String = ""
        Dim vEmpType As String = ""
        Dim vDateResign As String = ""
        Dim i As Integer = 1
        Dim vClass As String = "odd"

        vData.AppendLine("<table id='tblSheet' style='width: 950px; border-collapse: collapse; border-color: #000000; border: solid 0px #a8a8a9;' border='0'>")
        vData.AppendLine("<tr><td>")

        vData.AppendLine("<table style='width: 950px;'>")
        vData.AppendLine("<tr><td>&nbsp;</td></tr>")
        vData.AppendLine("<tr><td class='labelC'><h3>" & cmbOfc.SelectedItem.Text & "</h3></td></tr>")
        vData.AppendLine("<tr><td class='labelC'>Exclusion for pay period " & cmbDiff.SelectedValue & " vs pay period " & cmbPaydate.SelectedValue & "</td></tr>")
        vData.AppendLine("<tr><td>&nbsp;</td></tr>")
        vData.AppendLine("</table>")

        vData.AppendLine("</td></tr>")
        vData.AppendLine("<tr><td class='labelC'>")

        vData.AppendLine("<table style='width: 950px; border-collapse: collapse; border-color: #000000; border: solid 1px #a8a8a9;' border='1'>")
        vData.AppendLine("<tr class='titleBar'>")
        vData.AppendLine("<th style='width: 25px;'>#</th>")
        vData.AppendLine("<th>Full Name</th>")
        vData.AppendLine("<th style='width: 90px; '>Company ID No.</th>")
        vData.AppendLine("<th style='width: 90px; '>Date Separated</th>")
        vData.AppendLine("<th style='width: 180px; '>Department</th>")
        vData.AppendLine("<th style='width: 110px; '>Rank</th>")
        vData.AppendLine("<th style='width: 90px; '>Payroll Period</th>")
        vData.AppendLine("<th style='width: 110px; '>Emploment Status</th>")
        vData.AppendLine("</tr>")

        c.ConnectionString = connStr
        c.Open()

        cm.Connection = c
        'cm.CommandText = "select Emp_Cd, Name, Position, Deptcd " & _
        '    "from py_report a " & _
        '    "where Pay_Cd='" & cmbPaymode.SelectedValue & "' and paydate='" & Format(CDate(cmbDiff.SelectedValue), "yyyy/MM/dd") & "' " & _
        '    "and not exists (select py_report.emp_cd from py_report where paydate='" & Format(CDate(cmbPaydate.SelectedValue), "yyyy/MM/dd") & _
        '    "' and py_report.emp_cd=a.emp_cd) " & vFnlFilters & " order by name "

        cm.CommandText = "select Emp_Cd, Name, Position, DeptCd, PayDate, Emp_Status, " & _
              "(select Descr from hr_dept_ref where DeptCd=Dept_Cd ) as DeptName, " & _
              "(select Date_Resign from py_emp_master where py_emp_master.Emp_Cd=A.Emp_Cd ) as Date_Resign,  " & _
              "(select Descr from hr_employment_type where EmploymentType=a.EmploymentType) as Rank " & _
              "from py_report A where A.paydate='" & Format(CDate(cmbDiff.SelectedValue), "yyyy/MM/dd") & _
              "' and A.Pay_Cd ='" & cmbPaymode.SelectedValue & "' and " & _
              "not EXISTS (select Emp_Cd from py_report where py_report.paydate='" & _
              Format(CDate(cmbPaydate.SelectedValue), "yyyy/MM/dd") & "' and A.Emp_Cd=py_report.Emp_Cd and " & _
              "py_report.Pay_Cd='" & cmbPaymode.SelectedValue & "') order by A.Name"

        Try

            rs = cm.ExecuteReader
            Do While rs.Read

                vData.AppendLine("<tr class='" & vClass & "'>")
                vData.AppendLine("<td>&nbsp;" & i & "</td>")
                vData.AppendLine("<td>&nbsp;" & rs("Name") & "</td>")
                vData.AppendLine("<td>" & rs("Emp_Cd") & "</td>")
                If Not IsDBNull(rs("Date_Resign")) Then
                    vData.AppendLine("<td>" & rs("Date_Resign") & "</td>")
                Else
                    vData.AppendLine("<td>Unknown</td>")
                End If

                vData.AppendLine("<td>&nbsp;" & rs("DeptName") & "</td>")
                vData.AppendLine("<td>" & rs("Rank") & "</td>")
                vData.AppendLine("<td>" & rs("PayDate") & "</td>")
                vData.AppendLine("<td>" & rs("Emp_Status") & "</td>")

                vData.AppendLine("</tr>")
                'sub_rs.Close()
                vClass = IIf(vClass = "odd", "even", "odd")
                i += 1
            Loop

            rs.Close()
            cm.Dispose()
            c.Close()
            c.Dispose()
            vData.AppendLine("</table>")

            vData.AppendLine("</td></tr>")
            vData.AppendLine("</table>")
        Catch ex As system.exception
            vScript = "alert('Error occurred while trying to retrieve records. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            c.Dispose()
            cm.Dispose()
        End Try
    End Sub

    Private Sub GetRateAddjusment(ByVal vFnlFilters As String)
        vData.AppendLine("<table id='tblSheet' style='width: 950px; border-collapse: collapse; border-color: #000000; border: solid 0px #a8a8a9;' border='0'>")
        vData.AppendLine("<tr><td>")

        vData.AppendLine("<table style='width: 950px;'>")
        vData.AppendLine("<tr><td>&nbsp;</td></tr>")
        vData.AppendLine("<tr><td class='labelC'><h3>" & cmbOfc.SelectedItem.Text & "</h3></td></tr>")
        vData.AppendLine("<tr><td class='labelC'>Rate Adjustment for pay period " & cmbPaydate.SelectedValue & " vs pay period " & cmbDiff.SelectedValue & "</td></tr>")
        vData.AppendLine("<tr><td>&nbsp;</td></tr>")
        vData.AppendLine("</table>")

        vData.AppendLine("</td></tr>")
        vData.AppendLine("<tr><td class='labelC'>")

        vData.AppendLine("<table style='width: 950px; border-collapse: collapse; border-color: #000000; border: solid 1px #a8a8a9;' border='1'>")
        vData.AppendLine("<tr class='titleBar'>")
        vData.AppendLine("<th style='width: 25px;'>#</th>")
        vData.AppendLine("<th style='width: 100px;'>Employee ID</th>")
        vData.AppendLine("<th>Full Name</th>")
        vData.AppendLine("<th style='width: 150px;'>Current Rate</th>")
        vData.AppendLine("<th style='width: 150px;'>Previous Rate</th>")
        vData.AppendLine("<th style='width: 150px;'>Variance</th>")
        vData.AppendLine("</tr>")

        Dim i As Integer = 1
        Dim c As New sqlclient.sqlConnection
        Dim cm As New sqlclient.sqlCommand
        Dim rs As sqlclient.sqlDataReader
        Dim vClass As String = "odd"

        Dim vGrdtt() As Decimal = {0, 0, 0}


        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c

        cm.CommandText = "select Name, emp_cd, a.basicrate," & _
            "(select b.basicrate from py_report b where b.paydate='" & Format(CDate(cmbDiff.SelectedValue), "yyyy/MM/dd") & _
            "' and b.emp_cd=a.emp_cd) as oldrate from py_report a where paydate='" & _
            Format(CDate(cmbPaydate.SelectedValue), "yyyy/MM/dd") & "' " & vFnlFilters & _
            "and basicrate<> (select basicrate from py_report c where c.paydate='" & _
            Format(CDate(cmbDiff.SelectedValue), "yyyy/MM/dd") & "' and c.emp_cd=a.emp_cd)"

        rs = cm.ExecuteReader
        Do While rs.Read
            vData.AppendLine("<tr class='" & vClass & "'>")
            vData.AppendLine("<td class='labelC'>" & i & "</td>")
            vData.AppendLine("<td class='labelC'>" & rs("Emp_Cd") & "</td>")
            vData.AppendLine("<td class='labelL'>&nbsp;" & rs("Name") & "</td>")
            vData.AppendLine("<td class='labelR'>" & Format(rs("basicrate"), "###,##0.00") & "</td>")
            vData.AppendLine("<td class='labelR'>" & Format(rs("oldrate"), "###,##0.00") & "</td>")
            vData.AppendLine("<td class='labelR'>" & Format(rs("basicrate") - rs("oldrate"), "###,##0.00") & "</td>")
            vData.AppendLine("</tr>")

            vGrdtt(0) += rs("basicrate")
            vGrdtt(1) += rs("oldrate")
            vGrdtt(2) += (rs("basicrate") - rs("oldrate"))
            i += 1
            vClass = IIf(vClass = "odd", "even", "odd")
        Loop
        rs.Close()
        cm.Dispose()
        c.Close()
        c.Dispose()

        vData.AppendLine("<tr>")

        vData.AppendLine("<td class='labelC' colspan='3'><b>Grand Total :</b></td>")
        vData.AppendLine("<td class='labelR'><b>" & Format(vGrdtt(0), "###,##0.00") & "</b></td>")
        vData.AppendLine("<td class='labelR'><b>" & Format(vGrdtt(1), "###,##0.00") & "</b></td>")
        vData.AppendLine("<td class='labelR'><b>" & Format(vGrdtt(2), "###,##0.00") & "</b></td>")
        vData.AppendLine("</tr>")


        vData.AppendLine("</table>")
        vData.AppendLine("</td></tr>")
        vData.AppendLine("</table>")

    End Sub

    Private Sub GetConsolidated(ByVal vFnlFilters As String)
        vData.AppendLine("<table id='tblSheet' style='width: 950px; border-collapse: collapse; border-color: #000000; border: solid 0px #a8a8a9;' border='0'>")
        vData.AppendLine("<tr><td>")

        vData.AppendLine("<table style='width: 950px;'>")

        vData.AppendLine("<tr><td class='labelC'><h3>" & cmbOfc.SelectedItem.Text & "</h3></td></tr>")
        vData.AppendLine("<tr><td class='labelC'>Rate Adjustment for pay period " & cmbPaydate.SelectedValue & " vs pay period " & cmbDiff.SelectedValue & "</td></tr>")
        vData.AppendLine("<tr><td>&nbsp;</td></tr>")
        vData.AppendLine("</table>")

        vData.AppendLine("</td></tr>")
        vData.AppendLine("<tr><td class='labelC'>")

        vData.AppendLine("<table style='width: 1024px; border-collapse: collapse; border-color: #000000; border: solid 1px #a8a8a9;' border='1'>")
        vData.AppendLine("<tr class='titleBar'><th colspan='6'>Newly Hired Employees</th>")
        vData.AppendLine("</tr>")
        vData.AppendLine("<tr class='titleBar'><th style='width: 30px;'>#</th>")
        vData.AppendLine("<th>Employee</th>")
        vData.AppendLine("<th style='width: 150px;'>Department</th>")
        vData.AppendLine("<th style='width: 300px;'>Remarks</th>")
        vData.AppendLine("<th style='width: 100px;'>Basic Rate</th>")
        vData.AppendLine("<th style='width: 100px;'>No of Staff</th>")
        vData.AppendLine("</tr>")

        Dim i As Integer = 1
        Dim c As New SqlClient.SqlConnection
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim vClass As String = "odd"

        Dim vStaff As Integer = 1
        Dim vTtlStaff As Integer = 0
        Dim vTtlRate As Integer = 0

        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c

        cm.CommandText = "select Emp_Cd, Name, BasicRate, DeptCd, " & _
                "(select Descr from hr_dept_ref where DeptCd=Dept_Cd ) as DeptName, " & _
                "(select Start_Date from py_emp_master where py_emp_master.Emp_Cd=A.Emp_Cd ) as StartDate  " & _
                "from py_report A where A.paydate='" & Format(CDate(cmbPaydate.SelectedValue), "yyyy/MM/dd") & _
                "' and A.Pay_Cd ='" & cmbPaymode.SelectedValue & "' and " & _
                "not EXISTS (select Emp_Cd, Name, BasicRate, DeptCd from py_report where py_report.paydate='" & _
                Format(CDate(cmbDiff.SelectedValue), "yyyy/MM/dd") & "' and A.Emp_Cd=py_report.Emp_Cd and " & _
                "py_report.Pay_Cd='" & cmbPaymode.SelectedValue & "') order by A.Name"

        rs = cm.ExecuteReader
        Do While rs.Read
            vData.AppendLine("<tr class='" & vClass & "'>")
            vData.AppendLine("<td class='labelC'>" & i & "</td>")
            vData.AppendLine("<td class='labelL'>&nbsp;" & rs("Emp_Cd") & " = " & rs("Name") & "</td>")
            vData.AppendLine("<td class='labelL'>&nbsp;" & rs("DeptName") & "</td>")
            vData.AppendLine("<td class='labelL'>&nbsp;Date Hired : " & rs("StartDate") & "</td>") '
            vData.AppendLine("<td class='labelR'>" & Format(rs("BasicRate"), "###,##0.00") & "</td>")
            vData.AppendLine("<td class='labelR'>" & vStaff & "</td>")
            vData.AppendLine("</tr>")

            vTtlRate += rs("BasicRate")
            vTtlStaff += vStaff
            i += 1
            vClass = IIf(vClass = "odd", "even", "odd")
        Loop
        rs.Close()
        cm.Dispose()
        c.Close()
        c.Dispose()

        vData.AppendLine("<tr>")

        vData.AppendLine("<td class='labelR' colspan='4'><b>Grand Total :</b></td>")
        vData.AppendLine("<td class='labelR'><b>" & Format(vTtlRate, "###,##0.00") & "</b></td>") '" & Format(vGrdtt(1), "###,##0.00") & "
        vData.AppendLine("<td class='labelR'><b>" & vTtlStaff & "</b></td>")
        vData.AppendLine("</tr>")

        vData.AppendLine("</table>")
        vData.AppendLine("</td></tr>")
        vData.AppendLine("</table><br />")

    End Sub

    Private Sub GetConsolidatedTrans_RnF_to_Sup(ByVal vFnlFilters As String)
       
        vData.AppendLine("<table style='width: 1024px; border-collapse: collapse; border-color: #000000; border: solid 1px #a8a8a9;' border='1'>")
        vData.AppendLine("<tr class='titleBar'><th colspan='6'>Transferred from R&F to Supervisor</th>")
        vData.AppendLine("</tr>")
        vData.AppendLine("<tr class='titleBar'><th style='width: 30px;'>#</th>")
        vData.AppendLine("<th>Employee</th>")
        vData.AppendLine("<th style='width: 150px;'>Department</th>")
        vData.AppendLine("<th style='width: 300px;'>Remarks</th>")
        vData.AppendLine("<th style='width: 100px;'>Basic Rate</th>")
        vData.AppendLine("<th style='width: 100px;'>No of Staff</th>")
        vData.AppendLine("</tr>")

        Dim i As Integer = 1
        Dim c As New SqlClient.SqlConnection
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim vClass As String = "odd"

        Dim vStaff As Integer = 1
        Dim vTtlStaff As Integer = 0
        Dim vTtlRate As Integer = 0

        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c

        cm.CommandText = "select Emp_Cd, Name, EmploymentType, BasicRate, " & _
            "(select Descr from hr_dept_ref where DeptCd=Dept_Cd ) as DeptName, " & _
            "(select EmploymentType from py_report B where B.Emp_Cd=A.Emp_Cd and B.EmploymentType='RF' " & _
            "and B.PayDate='" & Format(CDate(cmbDiff.SelectedValue), "yyyy/MM/dd") & "' ) as Sup " & _
            "from py_report A where A.EmploymentType='SUP' and A.paydate='" & Format(CDate(cmbPaydate.SelectedValue), "yyyy/MM/dd") & "' " & _
            "and A.Pay_Cd='" & cmbPaymode.SelectedValue & "' order by A.Name"

        rs = cm.ExecuteReader
        Do While rs.Read
            If Not IsDBNull(rs("Sup")) Then
                vData.AppendLine("<tr class='" & vClass & "'>")
                vData.AppendLine("<td class='labelC'>" & i & "</td>")
                vData.AppendLine("<td class='labelL'>&nbsp;" & rs("Emp_Cd") & " = " & rs("Name") & "</td>")
                vData.AppendLine("<td class='labelL'>&nbsp;" & rs("DeptName") & "</td>")
                vData.AppendLine("<td class='labelL'></td>") '
                vData.AppendLine("<td class='labelR'>" & Format(rs("BasicRate"), "###,##0.00") & "</td>")
                vData.AppendLine("<td class='labelR'>" & vStaff & "</td>")
                vData.AppendLine("</tr>")

                vTtlRate += rs("BasicRate")
                vTtlStaff += vStaff
                i += 1
                vClass = IIf(vClass = "odd", "even", "odd")
            End If
        Loop
        rs.Close()
        cm.Dispose()
        c.Close()
        c.Dispose()

        vData.AppendLine("<tr>")

        vData.AppendLine("<td class='labelR' colspan='4'><b>Grand Total :</b></td>")
        vData.AppendLine("<td class='labelR'><b>" & Format(vTtlRate, "###,##0.00") & "</b></td>") '" & Format(vGrdtt(1), "###,##0.00") & "
        vData.AppendLine("<td class='labelR'><b>" & vTtlStaff & "</b></td>")
        vData.AppendLine("</tr>")
        vData.AppendLine("</table><br />")

    End Sub

    Private Sub GetConsolidatedChange_in_mid_month_pay(ByVal vFnlFilters As String)

        vData.AppendLine("<table style='width: 1024px; border-collapse: collapse; border-color: #000000; border: solid 1px #a8a8a9;' border='1'>")
        vData.AppendLine("<tr class='titleBar'><th colspan='6'>Change in Mid month pay</th>")
        vData.AppendLine("</tr>")
        vData.AppendLine("<tr class='titleBar'><th style='width: 30px;'>#</th>")
        vData.AppendLine("<th>Employee</th>")
        vData.AppendLine("<th style='width: 150px;'>Department</th>")
        vData.AppendLine("<th style='width: 300px;'>Remarks</th>")
        vData.AppendLine("<th style='width: 100px;'>Basic Rate</th>")
        vData.AppendLine("<th style='width: 100px;'>No of Staff</th>")
        vData.AppendLine("</tr>")

        Dim i As Integer = 1
        Dim c As New SqlClient.SqlConnection
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim vClass As String = "odd"

        Dim vStaff As Integer = 1
        Dim vTtlStaff As Integer = 0
        Dim vTtlRate As Integer = 0

        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c

        cm.CommandText = "select Emp_Cd, Name, Other_Incent20, BasicRate, " & _
            "(select Descr from hr_dept_ref where DeptCd=Dept_Cd ) as DeptName, " & _
            "(select Other_Incent20 from py_report B where B.Emp_Cd=A.Emp_Cd and B.PayDate='" & _
                Format(CDate(cmbDiff.SelectedValue), "yyyy/MM/dd") & "' ) as PrevMinPay, " & _
            "Other_Incent20 - (select Other_Incent20 from py_report B where B.Emp_Cd=A.Emp_Cd and B.PayDate='" & _
                Format(CDate(cmbDiff.SelectedValue), "yyyy/MM/dd") & "' ) as Diff " & _
            "from py_report A where A.paydate='" & Format(CDate(cmbPaydate.SelectedValue), "yyyy/MM/dd") & _
            "' and A.Pay_Cd='" & cmbPaymode.SelectedValue & "' order by A.Name  "

        rs = cm.ExecuteReader
        Do While rs.Read
            If Not IsDBNull(rs("Diff")) Then
                If rs("Diff") <> 0 Then
                    vData.AppendLine("<tr class='" & vClass & "'>")
                    vData.AppendLine("<td class='labelC'>" & i & "</td>")
                    vData.AppendLine("<td class='labelL'>&nbsp;" & rs("Emp_Cd") & " = " & rs("Name") & "</td>")
                    vData.AppendLine("<td class='labelL'>&nbsp;" & rs("DeptName") & "</td>")
                    vData.AppendLine("<td class='labelL'>&nbsp;previous Mid month pay : " & Format(rs("PrevMinPay"), "###,##0.00") & "</td>")
                    vData.AppendLine("<td class='labelR'>" & Format(rs("Other_Incent20"), "###,##0.00") & "</td>")
                    vData.AppendLine("<td class='labelR'>" & vStaff & "</td>")
                    vData.AppendLine("</tr>")

                    vTtlRate += rs("Other_Incent20")
                    vTtlStaff += vStaff
                    i += 1
                    vClass = IIf(vClass = "odd", "even", "odd")
                End If

            End If
        Loop
        rs.Close()
        cm.Dispose()
        c.Close()
        c.Dispose()

        vData.AppendLine("<tr>")

        vData.AppendLine("<td class='labelR' colspan='4'><b>Grand Total :</b></td>")
        vData.AppendLine("<td class='labelR'><b>" & Format(vTtlRate, "###,##0.00") & "</b></td>") '" & Format(vGrdtt(1), "###,##0.00") & "
        vData.AppendLine("<td class='labelR'><b>" & vTtlStaff & "</b></td>")
        vData.AppendLine("</tr>")

        vData.AppendLine("</table><br />")

    End Sub

    Private Sub GetConsolidatedAdjustment_on_Midmonth_pay(ByVal vFnlFilters As String)

        vData.AppendLine("<table style='width: 1024px; border-collapse: collapse; border-color: #000000; border: solid 1px #a8a8a9;' border='1'>")
        vData.AppendLine("<tr class='titleBar'><th colspan='6'>Adjustment on Midmonth pay</th>")
        vData.AppendLine("</tr>")
        vData.AppendLine("<tr class='titleBar'><th style='width: 30px;'>#</th>")
        vData.AppendLine("<th>Employee</th>")
        vData.AppendLine("<th style='width: 150px;'>Department</th>")
        vData.AppendLine("<th style='width: 300px;'>Remarks</th>")
        vData.AppendLine("<th style='width: 100px;'>Basic Rate</th>")
        vData.AppendLine("<th style='width: 100px;'>No of Staff</th>")
        vData.AppendLine("</tr>")

        Dim i As Integer = 1
        Dim c As New SqlClient.SqlConnection
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim vClass As String = "odd"

        Dim vStaff As Integer = 1
        Dim vTtlStaff As Integer = 0
        Dim vTtlRate As Integer = 0

        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c

        cm.CommandText = "select Emp_Cd, Name, Other_Incent20, BasicRate, " & _
            "(select Descr from hr_dept_ref where DeptCd=Dept_Cd ) as DeptName, " & _
            "(select Other_Incent20 from py_report B where B.Emp_Cd=A.Emp_Cd and B.PayDate='" & _
                Format(CDate(cmbDiff.SelectedValue), "yyyy/MM/dd") & "' ) as PrevMinPay, " & _
            "Other_Incent20 - (select Other_Incent20 from py_report B where B.Emp_Cd=A.Emp_Cd and B.PayDate='" & _
                Format(CDate(cmbDiff.SelectedValue), "yyyy/MM/dd") & "' ) as Diff " & _
            "from py_report A where A.paydate='" & Format(CDate(cmbPaydate.SelectedValue), "yyyy/MM/dd") & _
            "' and A.Pay_Cd='" & cmbPaymode.SelectedValue & "' order by A.Name  "

        rs = cm.ExecuteReader
        Do While rs.Read
            If Not IsDBNull(rs("Diff")) Then
                If rs("Diff") <> 0 Then
                    vData.AppendLine("<tr class='" & vClass & "'>")
                    vData.AppendLine("<td class='labelC'>" & i & "</td>")
                    vData.AppendLine("<td class='labelL'>&nbsp;" & rs("Emp_Cd") & " = " & rs("Name") & "</td>")
                    vData.AppendLine("<td class='labelL'>&nbsp;" & rs("DeptName") & "</td>")
                    vData.AppendLine("<td class='labelL'>&nbsp;(Previous : " & Format(rs("PrevMinPay"), "###,##0.00") & _
                                     ") - (Current :" & Format(rs("Other_Incent20"), "###,##0.00") & ")</td>")
                    vData.AppendLine("<td class='labelR'>" & Format(rs("Diff"), "###,##0.00") & "</td>")
                    vData.AppendLine("<td class='labelR'>" & vStaff & "</td>")
                    vData.AppendLine("</tr>")

                    vTtlRate += rs("Diff")
                    vTtlStaff += vStaff
                    i += 1
                    vClass = IIf(vClass = "odd", "even", "odd")
                End If

            End If
        Loop
        rs.Close()
        cm.Dispose()
        c.Close()
        c.Dispose()

        vData.AppendLine("<tr>")

        vData.AppendLine("<td class='labelR' colspan='4'><b>Grand Total :</b></td>")
        vData.AppendLine("<td class='labelR'><b>" & Format(vTtlRate, "###,##0.00") & "</b></td>") '" & Format(vGrdtt(1), "###,##0.00") & "
        vData.AppendLine("<td class='labelR'><b>" & vTtlStaff & "</b></td>")
        vData.AppendLine("</tr>")

        vData.AppendLine("</table><br />")

    End Sub

    Private Sub GetConsolidatedTrans_Sup_to_Confi(ByVal vFnlFilters As String)

        vData.AppendLine("<table style='width: 1024px; border-collapse: collapse; border-color: #000000; border: solid 1px #a8a8a9;' border='1'>")
        vData.AppendLine("<tr class='titleBar'><th colspan='6'>Transferred from Supervisor to Confidential</th>")
        vData.AppendLine("</tr>")
        vData.AppendLine("<tr class='titleBar'><th style='width: 30px;'>#</th>")
        vData.AppendLine("<th>Employee</th>")
        vData.AppendLine("<th style='width: 150px;'>Department</th>")
        vData.AppendLine("<th style='width: 300px;'>Remarks</th>")
        vData.AppendLine("<th style='width: 100px;'>Basic Rate</th>")
        vData.AppendLine("<th style='width: 100px;'>No of Staff</th>")
        vData.AppendLine("</tr>")

        Dim i As Integer = 1
        Dim c As New SqlClient.SqlConnection
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader

        Dim cmSub As New SqlClient.SqlCommand
        Dim rsSub As SqlClient.SqlDataReader
        Dim vClass As String = "odd"

        Dim vStaff As Integer = 1
        Dim vTtlStaff As Integer = 0
        Dim vTtlRate As Integer = 0

        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c
        cmSub.Connection = c

        cm.CommandText = "select Emp_Cd, Name, EmploymentType, BasicRate, " & _
            "(select Descr from hr_dept_ref where DeptCd=Dept_Cd ) as DeptName, " & _
            "(select EmploymentType from py_report B where B.Emp_Cd=A.Emp_Cd and B.EmploymentType='SUP' " & _
            "and B.PayDate='" & Format(CDate(cmbDiff.SelectedValue), "yyyy/MM/dd") & "' ) as vSup " & _
            "from py_report A where A.EmploymentType='CON' and A.paydate='" & Format(CDate(cmbPaydate.SelectedValue), "yyyy/MM/dd") & "' " & _
            "and A.Pay_Cd='" & cmbPaymode.SelectedValue & "' order by A.Name"

        rs = cm.ExecuteReader
        Do While rs.Read
            If Not IsDBNull(rs("vSup")) Then

                vData.AppendLine("<tr class='" & vClass & "'>")
                vData.AppendLine("<td class='labelC'>" & i & "</td>")
                vData.AppendLine("<td class='labelL'>&nbsp;" & rs("Emp_Cd") & " = " & rs("Name") & "</td>")
                vData.AppendLine("<td class='labelL'>&nbsp;" & rs("DeptName") & "</td>")
                vData.AppendLine("<td class='labelL'></td>") '

                cmSub.CommandText = "select EffectivityDate from hr_emp_career_movement where Emp_Cd='" & rs("Emp_Cd") & _
                    "' and Emp_Status='SUP' and EmploymentType='CON'"

                rsSub = cmSub.ExecuteReader
                If rsSub.Read Then
                    If Not IsDBNull(rs("EffectivityDate")) Then
                        vData.AppendLine("<td class='labelR'>" & Format(rs("EffectivityDate"), "###,##0.00") & "</td>")
                    End If
                Else
                    vData.AppendLine("<td class='labelR'>0.00</td>")
                End If
                rsSub.Close()

                vData.AppendLine("<td class='labelR'>" & vStaff & "</td>")
                vData.AppendLine("</tr>")

                vTtlRate += rs("BasicRate")
                vTtlStaff += vStaff
                i += 1
                vClass = IIf(vClass = "odd", "even", "odd")
            End If
        Loop
        rs.Close()
        cm.Dispose()
        cmSub.Dispose()
        c.Close()
        c.Dispose()

        vData.AppendLine("<tr>")

        vData.AppendLine("<td class='labelR' colspan='4'><b>Grand Total :</b></td>")
        vData.AppendLine("<td class='labelR'><b>" & Format(vTtlRate, "###,##0.00") & "</b></td>") '" & Format(vGrdtt(1), "###,##0.00") & "
        vData.AppendLine("<td class='labelR'><b>" & vTtlStaff & "</b></td>")
        vData.AppendLine("</tr>")
        vData.AppendLine("</table><br />")

    End Sub

    Private Sub GetConsolidatedResigned_Employee(ByVal vFnlFilters As String)

        vData.AppendLine("<table style='width: 1024px; border-collapse: collapse; border-color: #000000; border: solid 1px #a8a8a9;' border='1'>")
        vData.AppendLine("<tr class='titleBar'><th colspan='6'>Resigned Employee</th>")
        vData.AppendLine("</tr>")
        vData.AppendLine("<tr class='titleBar'><th style='width: 30px;'>#</th>")
        vData.AppendLine("<th>Employee</th>")
        vData.AppendLine("<th style='width: 150px;'>Department</th>")
        vData.AppendLine("<th style='width: 300px;'>Remarks</th>")
        vData.AppendLine("<th style='width: 100px;'>Basic Rate</th>")
        vData.AppendLine("<th style='width: 100px;'>No of Staff</th>")
        vData.AppendLine("</tr>")

        Dim i As Integer = 1
        Dim c As New SqlClient.SqlConnection
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim vClass As String = "odd"

        Dim vStaff As Integer = 1
        Dim vTtlStaff As Integer = 0
        Dim vTtlRate As Integer = 0

        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c

        cm.CommandText = "select Emp_Cd, Name, Month_Rate, DeptCd, " & _
                "(select Descr from hr_dept_ref where DeptCd=Dept_Cd ) as DeptName, " & _
                "(select Date_Resign from py_emp_master where py_emp_master.Emp_Cd=A.Emp_Cd ) as Date_Resign  " & _
                "from py_report A where A.paydate='" & Format(CDate(cmbDiff.SelectedValue), "yyyy/MM/dd") & _
                "' and A.Pay_Cd ='" & cmbPaymode.SelectedValue & "' and " & _
                "not EXISTS (select Emp_Cd, Name, BasicRate, DeptCd from py_report where py_report.paydate='" & _
                Format(CDate(cmbPaydate.SelectedValue), "yyyy/MM/dd") & "' and A.Emp_Cd=py_report.Emp_Cd and " & _
                "py_report.Pay_Cd='" & cmbPaymode.SelectedValue & "') order by A.Name"

        rs = cm.ExecuteReader
        Do While rs.Read
            vData.AppendLine("<tr class='" & vClass & "'>")
            vData.AppendLine("<td class='labelC'>" & i & "</td>")
            vData.AppendLine("<td class='labelL'>&nbsp;" & rs("Emp_Cd") & " = " & rs("Name") & "</td>")
            vData.AppendLine("<td class='labelL'>&nbsp;" & rs("DeptName") & "</td>")
            If Not IsDBNull(rs("Date_Resign")) Then
                vData.AppendLine("<td class='labelL'>&nbsp;Date Resigned : " & Format(rs("Date_Resign"), "MM/dd/yyyy") & " </td>")
            Else
                vData.AppendLine("<td class='labelL'>&nbsp;Date Resigned : Unknown </td>")
            End If

            vData.AppendLine("<td class='labelR'>" & Format(rs("Month_Rate"), "###,##0.00") & "</td>")
            vData.AppendLine("<td class='labelR'>" & vStaff & "</td>")
            vData.AppendLine("</tr>")

            vTtlRate += rs("Month_Rate")
            vTtlStaff += vStaff
            i += 1
            vClass = IIf(vClass = "odd", "even", "odd")

        Loop
        rs.Close()
        cm.Dispose()
        c.Close()
        c.Dispose()

        vData.AppendLine("<tr>")
        vData.AppendLine("<td class='labelR' colspan='4'><b>Grand Total :</b></td>")
        vData.AppendLine("<td class='labelR'><b>" & Format(vTtlRate, "###,##0.00") & "</b></td>") '" & Format(vGrdtt(1), "###,##0.00") & "
        vData.AppendLine("<td class='labelR'><b>" & vTtlStaff & "</b></td>")
        vData.AppendLine("</tr>")

        vData.AppendLine("</table><br />")

    End Sub

    Protected Sub btnRelaod_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnRelaod.Click

        Dim vFilter As String = ""
        Dim vRptName As String = ""

        If cmbRC.SelectedValue <> "All" Then   'filter by cost center
            vFilter += " and Rc_Cd='" & cmbRC.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='rc' and Property_Value=Rc_Cd) "
        End If

        If cmbOfc.SelectedValue <> "All" Then   'filter by office/agency
            vFilter += " and Agency_Cd='" & cmbOfc.SelectedValue & "' "
        Else
            vFilter += "  and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='agency' and Property_Value=Agency_Cd) "
        End If

        If cmbDiv.SelectedValue <> "All" Then   'filter by division
            vFilter += " and Divcd='" & cmbDiv.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='division' and Property_Value=DivCd) "
        End If

        If cmbDept.SelectedValue <> "All" Then  'filter by departments
            vFilter += " and DeptCd='" & cmbDept.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='department' and Property_Value=DeptCd) "
        End If

        If cmbSection.SelectedValue <> "All" Then   'filter by section
            vFilter += " and SectionCd='" & cmbSection.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='section' and Property_Value=SectionCd) "
        End If

        If cmbUnit.SelectedValue <> "All" Then  'filter by units
            vFilter += " and UnitCd='" & cmbUnit.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='unit' and Property_Value=UnitCd) "
        End If

        If cmbEmpType.SelectedValue <> "All" Then  'filter by Employment Type
            vFilter += " and EmploymentType='" & cmbEmpType.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='EmploymentType' and Property_Value=EmploymentType) "
        End If

        'select EmploymentType,Descr from hr_employment_type
        'vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
        '    "' and Property='employmenttype' and Property_Value=EmploymentType) "

        If rdoOption.SelectedValue = 0 Then
            GetExclusion(vFilter)
        ElseIf rdoOption.SelectedValue = 1 Then
            GetInclusion(vFilter)
        ElseIf rdoOption.SelectedValue = 2 Then
            GetRateAddjusment(vFilter)
        Else
            GetConsolidated(vFilter)
            GetConsolidatedTrans_RnF_to_Sup(vFilter)
            GetConsolidatedChange_in_mid_month_pay(vFilter)
            GetConsolidatedAdjustment_on_Midmonth_pay(vFilter)
            GetConsolidatedTrans_Sup_to_Confi(vFilter)
            GetConsolidatedResigned_Employee(vFilter)
        End If

    End Sub

    Protected Sub cmbYear_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbYear.SelectedIndexChanged
        PayDateRef()
    End Sub

    Protected Sub cmdReturn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.Click
        Server.Transfer("main.aspx")
    End Sub
End Class
