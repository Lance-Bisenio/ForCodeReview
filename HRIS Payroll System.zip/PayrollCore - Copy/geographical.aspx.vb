Imports denaro.fis
Partial Class geographical
    Inherits System.Web.UI.Page
    Dim c As New sqlclient.sqlconnection(connStr)
    Public vScript As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If

        If Not CanRun(Session("caption"), Request.Item("id")) Then
            Session("denied") = "1"
            Server.Transfer("main.aspx")
            Exit Sub
        End If

        If Not IsPostBack Then
            lblCaption.Text = "Geographical Reference"
            RefreshTree()
            'RefreshZip()
            tblInput.Visible = False

            cmbIsland.Items.Add(New ListItem("-", ""))

            buildRegion()
            buildProvince()
            buildCity()

            cmbRegion.SelectedValue = ""
            cmbProvince.SelectedValue = ""
            cmbCity.SelectedValue = ""
            cmbIsland.SelectedValue = ""
        End If
    End Sub

    Private Sub buildRegion()
        cmbRegion.Items.Clear()
        BuildCombo("SELECT RegionCd,Descr FROM region_ref ORDER BY Descr ASC", cmbRegion)
        cmbRegion.Items.Add(New ListItem("-", ""))
    End Sub

    Private Sub buildProvince()
        cmbProvince.Items.Clear()
        BuildCombo("SELECT ProvCd,Descr FROM province_ref ORDER BY Descr ASC", cmbProvince)
        cmbProvince.Items.Add(New ListItem("-", ""))
    End Sub
    Private Sub buildCity()
        cmbCity.Items.Clear()
        BuildCombo("SELECT CityCd,Descr FROM city_ref ORDER BY Descr ASC", cmbCity)
        cmbCity.Items.Add(New ListItem("-", ""))
    End Sub

    Private Sub RefreshTree()
        Try

            triMain.Nodes.Clear()

            c.Open()
            Dim cm As New sqlclient.sqlcommand
            Dim rs As sqlclient.sqldatareader
            Dim t As TreeNode

            'get Regions
            cm.Connection = c
            cm.CommandText = "SELECT RegionCd,Descr FROM region_ref ORDER BY RegionCd ASC"
            rs = cm.ExecuteReader
            Do While rs.Read
                t = New TreeNode
                t.Text = " <strong style='color:red'>" & rs("RegionCd") & "</strong> - " & rs("Descr")
                t.ToolTip = rs("RegionCd") & " (" & rs("Descr") & ")"
                t.Value = "reg-" & rs("RegionCd")

                getProvince(rs("RegionCd"), t)
                triMain.Nodes.Add(t)
            Loop
            rs.Close()

            c.Close()
            cm.Dispose()
        Catch ex As system.exception
            ErrMsg(ex)
        End Try
    End Sub

    Private Sub getProvince(ByVal RegionCd As String, ByRef pT As TreeNode)
        Try
            Dim cm As New sqlclient.sqlcommand
            Dim rs As sqlclient.sqldatareader
            Dim t As TreeNode

            'get Province
            cm.Connection = c
            cm.CommandText = "SELECT ProvCd,Descr FROM province_ref WHERE RegionCd='" & RegionCd & _
                "' ORDER BY ProvCd ASC"
            rs = cm.ExecuteReader
            Do While rs.Read
                t = New TreeNode
                t.Text = " <strong style='color:green'>" & rs("ProvCd") & "</strong> - " & rs("Descr")
                t.ToolTip = rs("ProvCd") & " (" & rs("Descr") & ")"
                t.Value = "prov-" & rs("ProvCd")

                getCity(RegionCd, rs("ProvCd"), t)
                pT.ChildNodes.Add(t)
            Loop
            rs.Close()
            cm.Dispose()
        Catch ex As system.exception
            ErrMsg(ex)
        End Try
    End Sub

    Private Sub getCity(ByVal RegionCd As String, ByVal ProvCd As String, ByRef pT As TreeNode)
        Try
            Dim cm As New sqlclient.sqlcommand
            Dim rs As sqlclient.sqldatareader
            Dim t As TreeNode

            'get Province
            cm.Connection = c
            cm.CommandText = "SELECT CityCd,Descr FROM city_ref WHERE RegionCd='" & RegionCd & _
                "' AND ProvCd='" & ProvCd & "' ORDER BY CityCd ASC"
            rs = cm.ExecuteReader
            Do While rs.Read
                t = New TreeNode
                t.Text = rs("CityCd") & " - " & rs("Descr")
                t.ToolTip = rs("CityCd") & " (" & rs("Descr") & ")"
                t.Value = "city-" & rs("CityCd")
                pT.ChildNodes.Add(t)
            Loop
            rs.Close()
            cm.Dispose()
        Catch ex As system.exception
            ErrMsg(ex)
        End Try
    End Sub

    Private Sub RefreshZip(ByVal vWhere As String)
        Try
            Dim da As New sqlclient.sqlDataAdapter
            Dim ds As New DataSet
            Dim vSQL As String = "select * from zip_ref " & vWhere & " ORDER BY AreaNm ASC"

            da = New sqlclient.sqlDataAdapter(vSQL, c)
            da.Fill(ds, "Zip")
            tblZip.DataSource = ds.Tables("Zip")
            tblZip.DataBind()
            da.Dispose()
            ds.Dispose()
        Catch ex As system.exception
            ErrMsg(ex)
        End Try

    End Sub

    Protected Sub tblZip_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles tblZip.PageIndexChanging
        tblZip.PageIndex = e.NewPageIndex
        RefreshZip(Session("where"))
    End Sub

    Protected Sub tblZip_RowCancelingEdit(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCancelEditEventArgs) Handles tblZip.RowCancelingEdit

        Try
            cmdAddZip.Visible = True
            tblZip.EditIndex = -1
            e.Cancel = True

            Dim vPath As String = triMain.SelectedNode.ValuePath
            Dim vGeo() As String = vPath.Split("/")
            Dim cm As New sqlclient.sqlcommand

            c.Open()
            cm.Connection = c

            cm.CommandText = "DELETE FROM zip_ref WHERE ZipCd='new record'"
            cm.ExecuteNonQuery()

            cm.Dispose()
            c.Close()

            CType(tblZip.Rows(e.RowIndex).FindControl("cmdDelZip"), Button).Visible = True

            Session("where") = " WHERE RegionCd='" & vGeo(0).Substring(4) & _
                "' AND ProvCd='" & vGeo(1).Substring(5) & "' AND CityCd='" & vGeo(2).Substring(5) & "'"
            RefreshZip(Session("where"))

            tblZip.SelectedIndex = -1
            Session.Remove("zip")

            cmdClose.Visible = True
            cmdCollapsed.Visible = True
            cmdAdd.Visible = True
            cmdEdit.Visible = True
            cmdDel.Visible = True
            cmdAddSub.Visible = True
            cmdAddZip.Visible = True

        Catch ex As system.exception
            ErrMsg(ex)
        End Try

    End Sub

    Protected Sub tblZip_RowDeleting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewDeleteEventArgs) Handles tblZip.RowDeleting
        If triMain.SelectedValue = "" Then
            vScript = "alert('Please select data first.');"
            Exit Sub
        End If

        Try
            Dim vZipCd As String = CType(tblZip.Rows(e.RowIndex).FindControl("lblZip"), Label).Text.Replace("'", "")
            Dim vCanDel As Boolean = True
            Dim cm As New sqlclient.sqlcommand

            c.Open()
            cm.Connection = c

            vCanDel = CanDel("Zip", vZipCd)
            If vCanDel Then
                cm.CommandText = "DELETE FROM zip_ref WHERE ZipCd='" & vZipCd & "'"
                cm.ExecuteNonQuery()

                cm.Dispose()
                c.Close()
                RefreshZip(Session("where"))
                vScript = "alert('Record successfully deleted.');"
                cmdAddZip.Visible = False
            Else
                vScript = "alert('Cannot delete : It is being used by employee.');"
            End If
        Catch ex As system.exception
            ErrMsg(ex)
        End Try
    End Sub

    Protected Sub tblZip_RowEditing(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewEditEventArgs) Handles tblZip.RowEditing
        If triMain.SelectedValue = "" Then
            vScript = "alert('Please select data first.');"
            Exit Sub
        End If

        Try

            Dim vZipCd As String = CType(tblZip.Rows(e.NewEditIndex).FindControl("lblZip"), Label).Text.Replace("'", "")
            Session("zip") = vZipCd
            RefreshZip(" WHERE ZipCd='" & vZipCd & "'")
            tblZip.EditIndex = tblZip.Rows.Count - 1
            RefreshZip(" WHERE ZipCd='" & vZipCd & "'")

            CType(tblZip.Rows(tblZip.EditIndex).FindControl("cmdDelZip"), Button).Visible = False
            CType(tblZip.Rows(tblZip.EditIndex).FindControl("txtZip"), TextBox).Attributes.Add("onclick", "this.select();")
            CType(tblZip.Rows(tblZip.EditIndex).FindControl("txtArea"), TextBox).Attributes.Add("onclick", "this.select();")
            CType(tblZip.Rows(tblZip.EditIndex).FindControl("txtPhone"), TextBox).Attributes.Add("onclick", "this.select();")

            cmdClose.Visible = False
            cmdCollapsed.Visible = False
            cmdAdd.Visible = False
            cmdEdit.Visible = False
            cmdDel.Visible = False
            cmdAddSub.Visible = False
            cmdAddZip.Visible = False


        Catch ex As system.exception
            ErrMsg(ex)
        End Try
    End Sub

    Protected Sub tblZip_RowUpdating(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewUpdateEventArgs) Handles tblZip.RowUpdating
        Try
            Dim vPath As String = triMain.SelectedNode.ValuePath
            Dim vGeo() As String = vPath.Split("/")
            Dim cm As New sqlclient.sqlcommand
            Dim vZip As String = CType(tblZip.Rows(tblZip.EditIndex).FindControl("txtZip"), TextBox).Text.Replace("'", "")
            Dim vArea As String = CType(tblZip.Rows(tblZip.EditIndex).FindControl("txtArea"), TextBox).Text.Replace("'", "")
            Dim vPhone As String = CType(tblZip.Rows(tblZip.EditIndex).FindControl("txtPhone"), TextBox).Text.Replace("'", "")

            If vZip.Trim = "" Then
                vScript = "alert('Zip code is required.');"
                Exit Sub
            End If

            vArea = IIf(vArea.Trim = "", "NULL", vArea)
            vPhone = IIf(vPhone.Trim = "", "NULL", vPhone)

            c.Open()
            cm.Connection = c

            If Session("zip") <> "" Then
                'Update Zip Reference
                cm.CommandText = "UPDATE zip_ref SET ZipCd='" & vZip & "',AreaNm='" & vArea & _
                    "',PhoneAreaCd='" & vPhone & "',RegionCd='" & vGeo(0).Substring(4) & _
                    "',ProvCd='" & vGeo(1).Substring(5) & "',CityCd='" & vGeo(2).Substring(5) & _
                    "' WHERE ZipCd='" & Session("zip") & "'"
                cm.ExecuteNonQuery()

                'Update Emp Master
                cm.CommandText = "UPDATE py_emp_master SET Zip='" & vZip & "' WHERE Zip='" & Session("zip") & "'"
                cm.ExecuteNonQuery()

                'Update Tmp Emp Master
                cm.CommandText = "UPDATE hr_emp_tmp_master SET Zip='" & vZip & "' WHERE Zip='" & Session("zip") & "'"
                cm.ExecuteNonQuery()
            Else
                cm.CommandText = "UPDATE zip_ref SET ZipCd='" & vZip & "',AreaNm='" & vArea & _
                                "',PhoneAreaCd='" & vPhone & "',RegionCd='" & vGeo(0).Substring(4) & _
                                "',ProvCd='" & vGeo(1).Substring(5) & "',CityCd='" & vGeo(2).Substring(5) & _
                                "' WHERE ZipCd='new record'"
                cm.ExecuteNonQuery()
            End If

            cm.Dispose()
            c.Close()
            tblZip.EditIndex = -1
            RefreshZip(Session("where"))
            Session.Remove("zip")

            cmdClose.Visible = True
            cmdCollapsed.Visible = True
            cmdAdd.Visible = True
            cmdEdit.Visible = True
            cmdDel.Visible = True
            cmdAddSub.Visible = True
            cmdAddZip.Visible = True

        Catch ex As system.exception
            ErrMsg(ex)
        End Try
    End Sub

    Protected Sub triMain_SelectedNodeChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles triMain.SelectedNodeChanged
        getSelectedTree()
    End Sub
    Private Sub getSelectedTree()
        Try
            Dim cm As New sqlclient.sqlcommand
            Dim rs As sqlclient.sqldatareader
            Dim vValue As String = triMain.SelectedValue
            Dim vPath As String = triMain.SelectedNode.ValuePath
            Dim vGeo() As String = vPath.Split("/")

            c.Open()
            cm.Connection = c

            trCity.Visible = False
            trIsland.Visible = False
            trMax.Visible = False
            trMid.Visible = False
            trMin.Visible = False
            trCola.Visible = False
            trProvince.Visible = False
            trRegion.Visible = False
            trCity.Visible = False
            cmdAddZip.Visible = False
            lblDesc.Text = "Description : "
            Session.Remove("where")
            tblZip.DataSource = Nothing

            If tblZip.EditIndex <> -1 Then
                tblZip.EditIndex = -1
                cmdClose.Visible = True
                cmdCollapsed.Visible = True
                cmdAdd.Visible = True
                cmdEdit.Visible = True
                cmdDel.Visible = True
                cmdAddSub.Visible = True
                cmdAddZip.Visible = True
            End If

            If vValue.Contains("reg-") Then 'Region
                trCity.Visible = True
                trIsland.Visible = True
                trMax.Visible = True
                trMid.Visible = True
                trMin.Visible = True
                trCola.Visible = True
                trCity.Visible = False

                lblCode.Text = "Region Code : "
                cmdAdd.Text = "Add Region"

                cm.CommandText = "SELECT 1 FROM province_ref WHERE RegionCd='" & vGeo(0).Substring(4) & "'"
                rs = cm.ExecuteReader
                cmdAddSub.Text = "Add Province"
                cmdAddSub.Visible = Not rs.HasRows
                rs.Close()

                cm.CommandText = "SELECT * FROM region_ref WHERE RegionCd='" & vGeo(0).Substring(4) & "'"
                rs = cm.ExecuteReader
                If rs.Read Then
                    If Not IsDBNull(rs("RegionCd")) Then txtCode.Text = rs("RegionCd") Else txtCode.Text = ""
                    If Not IsDBNull(rs("Descr")) Then txtDesc.Text = rs("Descr") Else txtDesc.Text = ""
                    If Not IsDBNull(rs("luzviminda")) Then cmbIsland.SelectedValue = rs("luzviminda") Else cmbIsland.SelectedValue = ""
                    If Not IsDBNull(rs("Minimum")) Then txtMin.Text = rs("Minimum") Else txtMin.Text = ""
                    If Not IsDBNull(rs("MidPoint")) Then txtMid.Text = rs("MidPoint") Else txtMid.Text = ""
                    If Not IsDBNull(rs("Maximum")) Then txtMax.Text = rs("Maximum") Else txtMax.Text = ""
                    If Not IsDBNull(rs("Ecola")) Then txtCola.Text = rs("Ecola") Else txtCola.Text = ""
                End If
                rs.Close()

                tblZip.Visible = False
                txtRegCode.Value = "r"
            ElseIf vValue.Contains("prov-") Then 'Province
                lblCode.Text = "Province Code : "
                cmdAdd.Text = "Add Province"
                trRegion.Visible = True


                cm.CommandText = "SELECT 1 FROM city_ref WHERE ProvCd='" & vGeo(1).Substring(5) & "'"
                rs = cm.ExecuteReader
                cmdAddSub.Text = "Add City"
                cmdAddSub.Visible = Not rs.HasRows
                rs.Close()

                cm.CommandText = "SELECT * FROM province_ref WHERE ProvCd='" & vGeo(1).Substring(5) & "' AND RegionCd='" & vGeo(0).Substring(4) & "'"
                rs = cm.ExecuteReader
                If rs.Read Then
                    If Not IsDBNull(rs("ProvCd")) Then txtCode.Text = rs("ProvCd") Else txtCode.Text = ""
                    If Not IsDBNull(rs("Descr")) Then txtDesc.Text = rs("Descr") Else txtDesc.Text = ""
                    If Not IsDBNull(rs("RegionCd")) Then cmbRegion.SelectedValue = rs("RegionCd") Else cmbRegion.SelectedValue = ""
                End If
                rs.Close()

                tblZip.Visible = False
                txtRegCode.Value = "p"
            ElseIf vValue.Contains("city-") Then 'City
                lblCode.Text = "City Code : "
                cmdAdd.Text = "Add City"
                trProvince.Visible = True
                trRegion.Visible = True

                cm.CommandText = "SELECT * FROM city_ref WHERE CityCd='" & vGeo(2).Substring(5) & _
                    "' AND ProvCd='" & vGeo(1).Substring(5) & "' AND RegionCd='" & vGeo(0).Substring(4) & "'"
                rs = cm.ExecuteReader
                If rs.Read Then
                    If Not IsDBNull(rs("CityCd")) Then txtCode.Text = rs("CityCd") Else txtCode.Text = ""
                    If Not IsDBNull(rs("Descr")) Then txtDesc.Text = rs("Descr") Else txtDesc.Text = ""
                    If Not IsDBNull(rs("RegionCd")) Then cmbRegion.SelectedValue = rs("RegionCd") Else cmbRegion.SelectedValue = ""
                    If Not IsDBNull(rs("ProvCd")) Then cmbProvince.SelectedValue = rs("ProvCd") Else cmbProvince.SelectedValue = ""
                End If
                rs.Close()

                txtRegCode.Value = "c"
                tblZip.Visible = True
                Session("where") = " WHERE RegionCd='" & vGeo(0).Substring(4) & _
                "' AND ProvCd='" & vGeo(1).Substring(5) & "' AND CityCd='" & vGeo(2).Substring(5) & "'"
                RefreshZip(Session("where"))
                cmdAddZip.Visible = True
            End If

            c.Close()
            cm.Dispose()
            tblInput.Visible = True
        Catch ex As system.exception
            ErrMsg(ex)
        End Try
    End Sub
    Protected Sub cmdEdit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdEdit.Click
        Try
            cmdAdd.Visible = False
            cmdAddSub.Visible = False
            cmdEdit.Visible = False
            cmdDel.Visible = False

            cmdSave.Visible = True
            cmdCancel.Visible = True

            Enabled(True)
            txtmode.Value = "e"
        Catch ex As system.exception
            ErrMsg(ex)
        End Try
    End Sub

    Private Sub Enabled(ByVal p As Boolean)
        txtCode.Enabled = p
        txtDesc.Enabled = p
        txtMin.Enabled = p
        txtMid.Enabled = p
        txtMax.Enabled = p
        txtCola.Enabled = p
        cmbIsland.Enabled = p
        cmbRegion.Enabled = p
        cmbProvince.Enabled = p
        cmbCity.Enabled = p
    End Sub

    Protected Sub cmdCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        Enabled(False)
        cmdAdd.Visible = True
        cmdAddSub.Visible = True
        cmdEdit.Visible = True
        cmdDel.Visible = True

        cmdSave.Visible = False
        cmdCancel.Visible = False
        txtCode.Enabled = False
        getSelectedTree()
        txtmode.Value = ""
    End Sub

    Protected Sub cmdAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdAdd.Click
        If triMain.SelectedValue = "" Then
            vScript = "alert('Please select data first.');"
            Exit Sub
        End If
        Try
            Dim vValue As String = cmdAdd.Text
            trCity.Visible = False
            trIsland.Visible = False
            trMax.Visible = False
            trMid.Visible = False
            trMin.Visible = False
            trCola.Visible = False
            trProvince.Visible = False
            trRegion.Visible = False
            trCity.Visible = False
            cmdAddSub.Visible = False

            If vValue.Contains("Region") Then 'Region
                trCity.Visible = True
                trIsland.Visible = True
                trMax.Visible = True
                trMid.Visible = True
                trMin.Visible = True
                trCola.Visible = True
                trCity.Visible = False

                tblZip.Visible = False
                txtRegCode.Value = "r"

            ElseIf vValue.Contains("Province") Then 'Province
                tblZip.Visible = False
                txtRegCode.Value = "p"

            ElseIf vValue.Contains("City") Then 'City
                txtRegCode.Value = "c"
                tblZip.Visible = True
            End If

            Enabled(True)
            cmdAdd.Visible = False
            cmdEdit.Visible = False
            cmdDel.Visible = False

            cmdSave.Visible = True
            cmdCancel.Visible = True

            txtCode.Text = ""
            txtDesc.Text = ""
            cmbRegion.SelectedValue = ""
            cmbProvince.SelectedValue = ""
            cmbCity.SelectedValue = ""
            txtMin.Text = ""
            txtMid.Text = ""
            txtMax.Text = ""
            txtCola.Text = ""
            cmbIsland.SelectedValue = ""

            txtmode.Value = "a"
            txtCode.Enabled = True

            tblInput.Visible = True
        Catch ex As system.exception
            ErrMsg(ex)
        End Try
    End Sub

    Private Sub ErrMsg(ByRef ex As system.exception)
        vScript = "alert('""" & ex.Message.Replace(vbCrLf, "").Replace("'", "") & """');"
    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        Try
            c.Open()
            Dim vGeo() As String = triMain.SelectedNode.ValuePath.Split("/")
            Dim cm As New sqlclient.sqlcommand
            Dim vDesc As String = txtDesc.Text.Replace("'", "")
            Dim vCode As String = txtCode.Text.Replace("'", "")
            Dim vReg As String = cmbRegion.SelectedValue
            Dim vProv As String = cmbProvince.SelectedValue
            Dim vCity As String = cmbCity.SelectedValue
            Dim vMode As String = txtmode.Value

            cm.Connection = c

            'Validation
            If txtCode.Text.Trim = "" Then
                vScript = "alert('Region Code is required.');"
                c.Close()
                Exit Sub
            End If

            If txtDesc.Text.Trim = "" Then
                vScript = "alert('Description is required.');"
                c.Close()
                Exit Sub
            End If

            Select Case txtRegCode.Value
                Case "r" 'Region

                    'Validation 
                    If cmbIsland.SelectedValue = "" Then
                        vScript = "alert('Please select Island Group.');"
                        c.Close()
                        Exit Sub
                    End If

                    If txtMin.Text <> "" Then
                        If Not IsNumeric(txtMin.Text) Then
                            vScript = "alert('Minimum field must be numeric.');"
                            c.Close()
                            Exit Sub
                        End If
                    Else
                        vScript = "alert('Minimum field is required.');"
                        c.Close()
                        Exit Sub
                    End If

                    If txtMax.Text <> "" Then
                        If Not IsNumeric(txtMax.Text) Then
                            vScript = "alert('Maximum field must be numeric.');"
                            c.Close()
                            Exit Sub
                        End If
                    Else
                        vScript = "alert('Maximum field is required.');"
                        c.Close()
                        Exit Sub
                    End If

                    If txtMid.Text <> "" Then
                        If Not IsNumeric(txtMid.Text) Then
                            vScript = "alert('Midpoint field must be numeric.');"
                            c.Close()
                            Exit Sub
                        End If
                    Else
                        vScript = "alert('Midpoint field is required.');"
                        c.Close()
                        Exit Sub
                    End If

                    If txtCola.Text <> "" Then
                        If Not IsNumeric(txtCola.Text) Then
                            vScript = "alert('ECola field must be numeric.');"
                            c.Close()
                            Exit Sub
                        End If
                    Else
                        vScript = "alert('ECola field is required.');"
                        c.Close()
                        Exit Sub
                    End If
                    'End of Validation


                    If vMode = "a" Then 'Add

                        cm.CommandText = "INSERT INTO region_ref (RegionCd,Descr,luzviminda,Minimum,MidPoint,Maximum,Ecola) VALUES " & _
                            "('" & vCode & "','" & vDesc & "','" & cmbIsland.SelectedValue & "'," & txtMin.Text & "," & txtMid.Text & _
                            "," & txtMax.Text & "," & txtCola.Text & ")"
                        cm.ExecuteNonQuery()

                    Else 'Edit

                        'Update Region
                        cm.CommandText = "UPDATE region_ref SET RegionCd='" & vCode & "',Descr='" & vDesc & "',luzviminda='" & cmbIsland.SelectedValue & _
                            "',Minimum=" & IIf(txtMin.Text <> "", txtMin.Text, "NULL") & ",MidPoint=" & _
                            IIf(txtMid.Text <> "", txtMid.Text, "NULL") & ",Maximum=" & IIf(txtMax.Text <> "", txtMax.Text, "NULL") & _
                            ",Ecola=" & IIf(txtCola.Text <> "", txtCola.Text, "NULL") & " WHERE RegionCd='" & vGeo(0).Substring(4) & "'"
                        cm.ExecuteNonQuery()

                        'Update Province
                        cm.CommandText = "UPDATE province_ref SET RegionCd='" & vCode & "' WHERE RegionCd='" & vGeo(0).Substring(4) & "'"
                        cm.ExecuteNonQuery()

                        'Update City

                        cm.CommandText = "UPDATE city_ref SET RegionCd='" & vCode & "' WHERE RegionCd='" & vGeo(0).Substring(4) & "'"
                        cm.ExecuteNonQuery()

                        'Update Zip
                        cm.CommandText = "UPDATE zip_ref SET RegionCd='" & vCode & "' WHERE RegionCd='" & vGeo(0).Substring(4) & "'"
                        cm.ExecuteNonQuery()

                        'Update Emp Master
                        cm.CommandText = "UPDATE py_emp_master SET RegionCd='" & vCode & "' WHERE RegionCd='" & vGeo(0).Substring(4) & "'"
                        cm.ExecuteNonQuery()

                        'Update Tmp Emp Master
                        cm.CommandText = "UPDATE hr_emp_tmp_master SET RegionCd='" & vCode & "' WHERE RegionCd='" & vGeo(0).Substring(4) & "'"
                        cm.ExecuteNonQuery()

                    End If
                    buildRegion()

                Case "p" 'Province

                    If vMode = "a" Then 'Add
                        cm.CommandText = "INSERT INTO province_ref (ProvCd,Descr,RegionCd) VALUES ('" & vCode & _
                            "','" & vDesc & "','" & vGeo(0).Substring(4) & "')"
                        cm.ExecuteNonQuery()

                    Else 'Edit

                        'Validation 
                        If cmbRegion.SelectedValue = "" Then
                            vScript = "alert('Please select Region.');"
                            c.Close()
                            Exit Sub
                        End If
                        'End of Validation

                        'Update Province
                        cm.CommandText = "UPDATE province_ref SET ProvCd='" & vCode & "',Descr='" & vDesc & _
                            "',RegionCd='" & vReg & "' WHERE ProvCd='" & vGeo(1).Substring(5) & "'"
                        cm.ExecuteNonQuery()

                        'Update City

                        cm.CommandText = "UPDATE city_ref SET ProvCd='" & vCode & "' WHERE ProvCd='" & _
                            vGeo(1).Substring(5) & "' AND RegionCd='" & vGeo(0).Substring(4) & "'"
                        cm.ExecuteNonQuery()

                        'Update Zip
                        cm.CommandText = "UPDATE zip_ref SET ProvCd='" & vCode & "' WHERE ProvCd='" & _
                            vGeo(1).Substring(5) & "' AND RegionCd='" & vGeo(0).Substring(4) & "'"
                        cm.ExecuteNonQuery()

                        'Update Emp Master
                        cm.CommandText = "UPDATE py_emp_master SET ProvCd='" & vCode & "' WHERE ProvCd='" & vGeo(1).Substring(5) & "'"
                        cm.ExecuteNonQuery()

                        'Update Tmp Emp Master
                        cm.CommandText = "UPDATE hr_emp_tmp_master SET ProvCd='" & vCode & "' WHERE ProvCd='" & vGeo(1).Substring(5) & "'"
                        cm.ExecuteNonQuery()

                        buildProvince()
                    End If


                Case "c" 'City

                    If vMode = "a" Then 'Add
                        cm.CommandText = "INSERT INTO city_ref (CityCd,Descr,RegionCd,ProvCd) VALUES ('" & vCode & _
                            "','" & vDesc & "','" & vGeo(0).Substring(4) & "','" & vGeo(1).Substring(5) & "')"
                        cm.ExecuteNonQuery()

                    Else 'Edit
                        'Validation 
                        If cmbRegion.SelectedValue = "" Then
                            vScript = "alert('Please select Region.');"
                            c.Close()
                            Exit Sub
                        End If

                        If cmbProvince.SelectedValue = "" Then
                            vScript = "alert('Please select Province.');"
                            c.Close()
                            Exit Sub
                        End If
                        'End of Validation

                        'Update City
                        cm.CommandText = "UPDATE city_ref SET CityCd='" & vCode & "',Descr='" & vDesc & "',RegionCd='" & _
                            vReg & "',ProvCd='" & vProv & "' WHERE CityCd='" & vGeo(2).Substring(5) & "' AND ProvCd='" & _
                            vGeo(1).Substring(5) & "' AND RegionCd='" & vGeo(0).Substring(4) & "'"
                        cm.ExecuteNonQuery()

                        'Update Zip
                        cm.CommandText = "UPDATE zip_ref SET CityCd='" & vCode & "' WHERE CityCd='" & vGeo(2).Substring(5) & "' AND ProvCd='" & _
                            vGeo(1).Substring(5) & "' AND RegionCd='" & vGeo(0).Substring(4) & "'"
                        cm.ExecuteNonQuery()

                        'Update Emp Master
                        cm.CommandText = "UPDATE py_emp_master SET City='" & vCode & "' WHERE City='" & vGeo(2).Substring(5) & "'"
                        cm.ExecuteNonQuery()

                        'Update Tmp Emp Master
                        cm.CommandText = "UPDATE hr_emp_tmp_master SET City='" & vCode & "' WHERE City='" & vGeo(2).Substring(5) & "'"
                        cm.ExecuteNonQuery()
                    End If

                    buildCity()
            End Select

            c.Close()
            cm.Dispose()
            Enabled(False)

            cmdAdd.Visible = True
            cmdEdit.Visible = True
            cmdDel.Visible = True

            cmdSave.Visible = False
            cmdCancel.Visible = False
            txtmode.Value = ""
            txtCode.Enabled = False
            triMain.Nodes.Item(0).Select()
            'tblInput.Visible = False

            RefreshTree()
            vScript = "alert('Record successfully saved.');"

        Catch ex As system.exception
            ErrMsg(ex)
        End Try
    End Sub

    Protected Sub cmdDel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDel.Click
        If triMain.SelectedValue = "" Then
            vScript = "alert('Please select first the data you want to delete.');"
            Exit Sub
        End If

        Try
            Dim cm As New sqlclient.sqlcommand
            Dim vSql As String = ""
            Dim vGeo() As String = triMain.SelectedNode.ValuePath.Split("/")
            Dim vCan As Boolean = True
            vScript = "alert('Record successfully deleted.');"

            c.Open()
            cm.Connection = c

            Select Case txtRegCode.Value
                Case "r" ' Region
                    vCan = CanDel("RegionCd", txtCode.Text)
                    If vCan Then
                        cm.CommandText = "DELETE FROM region_ref WHERE RegionCd='" & txtCode.Text & "'"
                        cm.ExecuteNonQuery()

                        cm.CommandText = "DELETE FROM province_ref WHERE RegionCd='" & txtCode.Text & "'"
                        cm.ExecuteNonQuery()

                        cm.CommandText = "DELETE FROM city_ref WHERE RegionCd='" & txtCode.Text & "'"
                        cm.ExecuteNonQuery()

                        cm.CommandText = "DELETE FROM zip_ref WHERE RegionCd='" & txtCode.Text & "'"
                        cm.ExecuteNonQuery()
                    Else
                        vScript = "alert('Cannot delete : It is being used by employee.');"
                    End If

                    buildRegion()
                Case "p" ' Province
                    vCan = CanDel("ProvCd", txtCode.Text)
                    If vCan Then
                        cm.CommandText = "DELETE FROM province_ref WHERE RegionCd='" & vGeo(0).Substring(4) & _
                            "' AND ProvCd='" & txtCode.Text & "'"
                        cm.ExecuteNonQuery()

                        cm.CommandText = "DELETE FROM city_ref WHERE RegionCd='" & vGeo(0).Substring(4) & _
                            "' AND ProvCd='" & txtCode.Text & "'"
                        cm.ExecuteNonQuery()

                        cm.CommandText = "DELETE FROM zip_ref WHERE RegionCd='" & vGeo(0).Substring(4) & _
                            "' AND ProvCd='" & txtCode.Text & "'"
                        cm.ExecuteNonQuery()
                    Else
                        vScript = "alert('Cannot delete : It is being used by employee.');"
                    End If

                    buildProvince()
                Case "c" ' City
                    vCan = CanDel("City", txtCode.Text)
                    If vCan Then
                        cm.CommandText = "DELETE FROM city_ref WHERE RegionCd='" & vGeo(0).Substring(4) & _
                            "' AND ProvCd='" & vGeo(1).Substring(5) & "' AND CityCd='" & txtCode.Text & "'"
                        cm.ExecuteNonQuery()

                        cm.CommandText = "DELETE FROM zip_ref WHERE RegionCd='" & vGeo(0).Substring(4) & _
                            "' AND ProvCd='" & vGeo(1).Substring(5) & "' AND CityCd='" & txtCode.Text & "'"
                        cm.ExecuteNonQuery()
                    Else
                        vScript = "alert('Cannot delete : It is being used by employee.');"
                    End If

                    buildCity()
            End Select

            c.Close()
            cm.Dispose()

            txtCode.Text = ""
            txtDesc.Text = ""
            cmbRegion.SelectedValue = ""
            cmbProvince.SelectedValue = ""
            cmbCity.SelectedValue = ""
            txtMin.Text = ""
            txtMid.Text = ""
            txtMax.Text = ""
            txtCola.Text = ""
            cmbIsland.SelectedValue = ""
            tblInput.Visible = False

            RefreshTree()
        Catch ex As system.exception
            ErrMsg(ex)
        End Try
    End Sub

    Private Function CanDel(ByVal vField As String, ByVal vCd As String) As Boolean
        Try

            Dim cm As New sqlclient.sqlcommand
            Dim rs As sqlclient.sqldatareader
            Dim vCan As Boolean = False

            cm.Connection = c

            cm.CommandText = "SELECT 1 FROM py_emp_master WHERE " & vField & "='" & vCd & "'"
            rs = cm.ExecuteReader()
            vCan = Not rs.Read
            rs.Close()
            If vCan Then
                cm.CommandText = "SELECT 1 FROM hr_emp_tmp_master WHERE " & vField & "='" & vCd & "'"
                rs = cm.ExecuteReader()
                vCan = Not rs.Read
                rs.Close()
            End If

            Return vCan
        Catch ex As system.exception
            ErrMsg(ex)
            Return False
            Exit Function
        End Try
    End Function
    Protected Sub cmdClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdClose.Click
        Server.Transfer("main.aspx")
        Session.Remove("where")
        Session.Remove("zip")
    End Sub

    Protected Sub cmdCollapsed_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCollapsed.Click
        If cmdCollapsed.Text = " - " Then
            cmdCollapsed.Text = " + "
            cmdCollapsed.ToolTip = "Expand All"
            triMain.CollapseAll()
        Else
            cmdCollapsed.Text = " - "
            cmdCollapsed.ToolTip = "Collapse All"
            triMain.ExpandAll()
        End If
    End Sub

    Protected Sub cmdAddSub_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdAddSub.Click
        If triMain.SelectedValue = "" Then
            vScript = "alert('Please select data first.');"
            Exit Sub
        End If
        Try
            Dim vValue As String = cmdAddSub.Text
            trCity.Visible = False
            trIsland.Visible = False
            trMax.Visible = False
            trMid.Visible = False
            trMin.Visible = False
            trCola.Visible = False
            trProvince.Visible = False
            trRegion.Visible = False
            trCity.Visible = False
            cmdAddSub.Visible = False

            If vValue.Contains("Region") Then 'Region
                trCity.Visible = True
                trIsland.Visible = True
                trMax.Visible = True
                trMid.Visible = True
                trMin.Visible = True
                trCola.Visible = True
                trCity.Visible = False

                tblZip.Visible = False
                txtRegCode.Value = "r"

            ElseIf vValue.Contains("Province") Then 'Province
                lblCode.Text = "Province Code:"
                tblZip.Visible = False
                txtRegCode.Value = "p"

            ElseIf vValue.Contains("City") Then 'City
                lblCode.Text = "City Code:"
                txtRegCode.Value = "c"
                'tblZip.Visible = True
            End If

            Enabled(True)
            cmdAdd.Visible = False
            cmdEdit.Visible = False
            cmdDel.Visible = False

            cmdSave.Visible = True
            cmdCancel.Visible = True

            txtCode.Text = ""
            txtDesc.Text = ""
            cmbRegion.SelectedValue = ""
            cmbProvince.SelectedValue = ""
            cmbCity.SelectedValue = ""
            txtMin.Text = ""
            txtMid.Text = ""
            txtMax.Text = ""
            txtCola.Text = ""
            cmbIsland.SelectedValue = ""

            txtmode.Value = "a"
            txtCode.Enabled = True

            tblInput.Visible = True
        Catch ex As system.exception
            ErrMsg(ex)
        End Try

    End Sub

    Protected Sub cmdAddZip_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdAddZip.Click

        If triMain.SelectedValue = "" Then
            vScript = "alert('Please select data first');"
            Exit Sub
        End If

        Try
            Dim cm As New sqlclient.sqlcommand
            Dim vValue() As String

            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c

            cm.CommandText = "DELETE FROM zip_ref WHERE ZipCd='new record'"
            cm.ExecuteNonQuery()


            vValue = triMain.SelectedNode.ValuePath.Split("/")
            cm.CommandText = "INSERT INTO zip_ref (ZipCd) " & _
                "VALUES('new record')"
            cm.ExecuteNonQuery()

            Dim vWhere As String = " WHERE ZipCd='new record'"

            c.Close()
            cm.Dispose()
            RefreshZip(vWhere)
            tblZip.EditIndex = tblZip.Rows.Count - 1
            RefreshZip(vWhere)
            cmdAddZip.Visible = False
            CType(tblZip.Rows(tblZip.EditIndex).FindControl("cmdDelZip"), Button).Visible = False
            CType(tblZip.Rows(tblZip.EditIndex).FindControl("txtZip"), TextBox).Attributes.Add("onclick", "this.select();")
            CType(tblZip.Rows(tblZip.EditIndex).FindControl("txtArea"), TextBox).Attributes.Add("onclick", "this.select();")
            CType(tblZip.Rows(tblZip.EditIndex).FindControl("txtPhone"), TextBox).Attributes.Add("onclick", "this.select();")
            Session.Remove("zip")


            cmdClose.Visible = False
            cmdCollapsed.Visible = False
            cmdAdd.Visible = False
            cmdEdit.Visible = False
            cmdDel.Visible = False
            cmdAddSub.Visible = False
            cmdAddZip.Visible = False

        Catch ex As system.exception
            ErrMsg(ex)
        End Try
    End Sub

    Protected Sub tblZip_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tblZip.SelectedIndexChanged

    End Sub
End Class
