﻿Imports denaro.fis
Partial Class logvariance
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Public vDump As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Or Session("uid") = Nothing Then
            vScript = "alert('Your login session has expired. Please re-login again.'); window.close();"
            Exit Sub
        End If

        If Not IsPostBack Then
            'build years
            Dim iCtr As Integer

            cmbYearS.Items.Clear()
            cmbYearE.Items.Clear()
            For iCtr = Now.Year To Now.Year - 5 Step -1
                cmbYearS.Items.Add(iCtr)
                cmbYearE.Items.Add(iCtr)
            Next
            cmbYearS.SelectedValue = Now.Year
            cmbYearE.SelectedValue = Now.Year
            cmbMonthS.SelectedValue = Now.Month
            cmbMonthE.SelectedValue = Now.Month
            cmbMonthE_SelectedIndexChanged(sender, e)
            cmbMonthS_SelectedIndexChanged(sender, e)
            BuildCombo("select EmploymentType,Descr from hr_employment_type order by Descr", cmbRank)
        End If
    End Sub
    Protected Sub cmbMonthS_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles _
        cmbMonthS.SelectedIndexChanged, cmbYearS.SelectedIndexChanged

        Dim iCtr As Integer

        cmbDayS.Items.Clear()
        For iCtr = 1 To MonthEND(CDate(cmbMonthS.SelectedValue & "/1/" & cmbYearS.SelectedValue)).Day
            cmbDayS.Items.Add(iCtr)
        Next

        If cmbDayS.Items.Count > 0 Then
            cmbDayS.SelectedValue = 1
        End If
    End Sub

    Protected Sub cmbMonthE_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles _
        cmbMonthE.SelectedIndexChanged, cmbYearE.SelectedIndexChanged

        Dim iCtr As Integer

        cmbDayE.Items.Clear()
        For iCtr = 1 To MonthEND(CDate(cmbMonthE.SelectedValue & "/1/" & cmbYearE.SelectedValue)).Day
            cmbDayE.Items.Add(iCtr)
        Next

        If cmbDayE.Items.Count > 0 Then
            cmbDayE.SelectedValue = 1
        End If
    End Sub

    Protected Sub cmdRefresh_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdRefresh.Click
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cmLog As New SqlClient.SqlCommand

        Dim rs As SqlClient.SqlDataReader
        Dim rsLog As SqlClient.SqlDataReader

        Dim vData As New StringBuilder
        Dim vClass As String

        Dim vLogPeriod As Decimal
        Dim vLogDaily As Decimal
        Dim iCount As Integer

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            cmLog.Dispose()
            Exit Sub
        End Try

        cm.Connection = c
        cmLog.Connection = c

        cm.CommandText = "select distinct Emp_Cd, (select Emp_Lname+', '+Emp_Fname from py_emp_master where py_emp_master.Emp_Cd=" & _
            "py_emp_time_log.Emp_Cd) as Name from py_emp_time_log where TranDate between '" & _
            cmbYearS.SelectedValue & "/" & cmbMonthS.SelectedValue & "/" & cmbDayS.SelectedValue & _
            "' and '" & cmbYearE.SelectedValue & "/" & cmbMonthE.SelectedValue & "/" & cmbDayE.SelectedValue & _
            "' and exists (select Emp_Cd from py_emp_master where py_emp_master.Emp_Cd=py_emp_time_log.Emp_Cd and EmploymentType='" & _
            cmbRank.SelectedValue & "') order by Name"

        Try
            rs = cm.ExecuteReader
            vClass = "odd"

            iCount = 0
            Do While rs.Read
                Select Case rdoTranCd.SelectedValue
                    Case "OT"
                        cmLog.CommandText = "select sum(Hrs_Rendered) as HrsRendered from py_emp_time_log where TranDate between '" & _
                            cmbYearS.SelectedValue & "/" & cmbMonthS.SelectedValue & "/" & cmbDayS.SelectedValue & _
                            "' and '" & cmbYearE.SelectedValue & "/" & cmbMonthE.SelectedValue & "/" & cmbDayE.SelectedValue & _
                            "' and Emp_Cd='" & rs("Emp_Cd") & "' and TranCd IN ('A1','A3','B1','B3','C1','C3','D1','D3','E1','E3','F1','F3')"
                    Case "ND"
                        cmLog.CommandText = "select sum(Hrs_Rendered) as HrsRendered from py_emp_time_log where TranDate between '" & _
                            cmbYearS.SelectedValue & "/" & cmbMonthS.SelectedValue & "/" & cmbDayS.SelectedValue & _
                            "' and '" & cmbYearE.SelectedValue & "/" & cmbMonthE.SelectedValue & "/" & cmbDayE.SelectedValue & _
                            "' and Emp_Cd='" & rs("Emp_Cd") & "' and TranCd IN ('A2','A4','B2','B4','C2','C4','D2','D4','E2','E4','F2','F4')"
                    Case Else
                        cmLog.CommandText = "select sum(Hrs_Rendered) as HrsRendered from py_emp_time_log where TranDate between '" & _
                            cmbYearS.SelectedValue & "/" & cmbMonthS.SelectedValue & "/" & cmbDayS.SelectedValue & _
                            "' and '" & cmbYearE.SelectedValue & "/" & cmbMonthE.SelectedValue & "/" & cmbDayE.SelectedValue & _
                            "' and Emp_Cd='" & rs("Emp_Cd") & "' and TranCd='" & rdoTranCd.SelectedValue & "' "
                End Select
                
                rsLog = cmLog.ExecuteReader
                vLogPeriod = 0
                vLogDaily = 0
                If rsLog.Read Then
                    vLogPeriod = IIf(IsDBNull(rsLog("HrsRendered")), 0, rsLog("HrsRendered"))
                End If
                rsLog.Close()

                Select Case rdoTranCd.SelectedValue
                    Case "OT"
                        cmLog.CommandText = "select sum(Hrs_Rendered) as HrsRendered from py_time_log_dtl where TranDate between '" & _
                            cmbYearS.SelectedValue & "/" & cmbMonthS.SelectedValue & "/" & cmbDayS.SelectedValue & _
                            "' and '" & cmbYearE.SelectedValue & "/" & cmbMonthE.SelectedValue & "/" & cmbDayE.SelectedValue & _
                            "' and Emp_Cd='" & rs("Emp_Cd") & "' and TranCd IN ('A1','A3','B1','B3','C1','C3','D1','D3','E1','E3','F1','F3')"
                    Case "ND"
                        cmLog.CommandText = "select sum(Hrs_Rendered) as HrsRendered from py_time_log_dtl where TranDate between '" & _
                            cmbYearS.SelectedValue & "/" & cmbMonthS.SelectedValue & "/" & cmbDayS.SelectedValue & _
                            "' and '" & cmbYearE.SelectedValue & "/" & cmbMonthE.SelectedValue & "/" & cmbDayE.SelectedValue & _
                            "' and Emp_Cd='" & rs("Emp_Cd") & "' and TranCd IN ('A2','A4','B2','B4','C2','C4','D2','D4','E2','E4','F2','F4')"
                    Case Else
                        cmLog.CommandText = "select sum(Hrs_Rendered) as HrsRendered from py_time_log_dtl where TranDate between '" & _
                            cmbYearS.SelectedValue & "/" & cmbMonthS.SelectedValue & "/" & cmbDayS.SelectedValue & _
                            "' and '" & cmbYearE.SelectedValue & "/" & cmbMonthE.SelectedValue & "/" & cmbDayE.SelectedValue & _
                            "' and Emp_Cd='" & rs("Emp_Cd") & "' and TranCd='" & rdoTranCd.SelectedValue & "' "
                End Select
                
                rsLog = cmLog.ExecuteReader

                If rsLog.Read Then
                    vLogDaily = IIf(IsDBNull(rsLog("HrsRendered")), 0, rsLog("HrsRendered"))
                End If
                rsLog.Close()

                If vLogPeriod <> 0 Or vLogDaily <> 0 Then
                    If (chkNonZero.Checked And vLogPeriod - vLogDaily <> 0) Or Not chkNonZero.Checked Then
                        With vData
                            .AppendLine("<tr class='" & vClass & "'>")
                            .AppendLine("<td class='labelL'>" & rs("Emp_Cd") & "</td>")
                            .AppendLine("<td class='labelL'>" & rs("Name") & "</td>")
                            .AppendLine("<td class='labelL'>" & rdoTranCd.SelectedItem.Text & "</td>")  'transaction code
                            .AppendLine("<td class='labelR'>" & Format(vLogPeriod, "#,##0.00") & "</td>")  'from periodic log
                            .AppendLine("<td class='labelR'>" & Format(vLogDaily, "#,##0.00") & "</td>")  'from daily log
                            .AppendLine("<td class='labelR'>" & Format(vLogPeriod - vLogDaily, "#,##0.00") & "</td>")    'variance
                            .AppendLine("</tr>")
                        End With

                        vClass = IIf(vClass = "odd", "even", "odd")
                        iCount += 1
                    End If
                End If
            Loop
            rs.Close()
            vDump = vData.ToString
            If vDump = "" Then
                vScript = "alert('No records retrieved.');"
            End If
            lblTotal.Text = iCount
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to retrieve the records. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            c.Dispose()
            cm.Dispose()
            cmLog.Dispose()
        End Try
    End Sub
End Class
