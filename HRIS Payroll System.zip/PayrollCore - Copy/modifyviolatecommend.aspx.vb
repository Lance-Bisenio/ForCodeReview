Imports denaro
Partial Class modifyviolatecommend
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Dim c As New sqlclient.sqlconnection
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If
        If Not IsPostBack Then
            Dim cm As New sqlclient.sqlcommand
            Dim dr As sqlclient.sqldatareader
            txtEmpCd.Text = Session("empid")
            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c
            cm.CommandText = "select Emp_Lname,Emp_Fname from py_emp_master where Emp_Cd='" & txtEmpCd.Text & "'"
            dr = cm.ExecuteReader
            lblcaption.text = "Add/Modify Violation/Commendation for "
            If dr.Read Then
                lblcaption.Text += dr("Emp_Lname") & ", " & dr("Emp_Fname")
            End If
            dr.Close()
            BuildCombo("SELECT * FROM hr_violate_article", droparticle)
            txtType.Text = Session("type")
            If Session("mode") = "e" Then
                cm.CommandText = "select * from hr_emp_violate_commend where Emp_Id='" & txtEmpCd.Text & _
                    "' and Event_Date='" & Format(CDate(Session("seqid")), "yyyy/MM/dd") & _
                    "' and Event_Type='" & txtType.Text & "'"
                dr = cm.ExecuteReader
                If dr.Read Then
                    txtTdate.Text = dr("Event_Date")
                    txtEvent.Text = dr("Event")
                    txtAction.Text = dr("Actions")
                    txtRemarks.Text = dr("Remarks")
                    Dim indx As Integer = 0
                    For Each items As ListItem In droparticle.Items
                        If items.Text = dr("article_cd") Then
                            droparticle.SelectedIndex = indx
                            Exit For
                        End If
                        indx += 1
                    Next
                End If
                dr.Close()
            Else
                droparticle.SelectedIndex = 0
                Dim conn As New sqlclient.sqlconnection
                Dim comm As New sqlclient.sqlcommand
                Dim rdr As sqlclient.sqldatareader
                conn.ConnectionString = connStr
                conn.Open()
                comm.Connection = conn
                comm.CommandText = "SELECT duration FROM hr_violate_article WHERE article_cd='" & droparticle.SelectedValue & "'"
                rdr = comm.ExecuteReader
                If rdr.Read Then
                    txtduration.Text = rdr("duration")
                End If
                conn.Close()
                comm.Dispose()
                rdr.Close()
            End If
            cm.Dispose()
            c.Close()

        End If
    End Sub

    Protected Sub cmdCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        Session.Remove("empid")
        Session.Remove("mode")
        Session.Remove("seqid")
        Session.Remove("type")
        vScript = "window.close();"
    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        If Page.IsValid Then
            Dim cm As New sqlclient.sqlcommand
            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c
            If Session("mode") = "e" Then 'edit mode
                cm.CommandText = "update hr_emp_violate_commend set Event_Date='" & Format(CDate(txtTdate.Text), "yyyy/MM/dd") & _
                    "',Event='" & txtEvent.Text & _
                    "',Actions='" & txtAction.Text & _
                   "',Remarks='" & txtRemarks.Text & _
                    "', Article_Cd='" & droparticle.SelectedValue & "' where Emp_Id='" & txtEmpCd.Text & "' and Event_Date='" & Format(CDate(Session("seqid")), "yyyy/MM/dd") & _
                    "' and Event_Type='" & txtType.Text & "'"
            Else                          'add mode
                cm.CommandText = "insert into hr_emp_violate_commend (Emp_Id,Event_Type,Event_Date,Event," & _
                    "Actions,Remarks, Article_Cd) values ('" & txtEmpCd.Text & "','" & txtType.Text & _
                    "','" & Format(CDate(txtTdate.Text), "yyyy/MM/dd") & "','" & txtEvent.Text & "','" & _
                    txtAction.Text & "','" & txtRemarks.Text & "','" & droparticle.SelectedValue & "')"
            End If
            cm.ExecuteNonQuery()
            Session.Remove("empid")
            Session.Remove("mode")
            Session.Remove("seqid")
            Session.Remove("type")
            cm.Dispose()
            c.Close()
            vScript = "alert('Changes were successfully saved.'); window.close();"
        End If
    End Sub

    Protected Sub vld_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles vld.ServerValidate
        If Not IsDate(txtTdate.Text) Then
            vScript = "alert('Invalid date format in Event Date field.');"
            args.IsValid = False
        Else
            args.IsValid = True
        End If
    End Sub

    Protected Sub droparticle_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles droparticle.SelectedIndexChanged
        Dim conn As New sqlclient.sqlconnection
        Dim comm As New sqlclient.sqlcommand
        Dim rdr As sqlclient.sqldatareader
        conn.ConnectionString = connStr
        conn.Open()
        comm.Connection = conn
        comm.CommandText = "SELECT duration FROM hr_violate_article WHERE article_cd='" & droparticle.SelectedValue & "'"
        rdr = comm.ExecuteReader
        If rdr.Read Then
            txtduration.Text = rdr("duration")
        End If
        conn.Close()
        comm.Dispose()
        rdr.Close()
    End Sub
End Class
