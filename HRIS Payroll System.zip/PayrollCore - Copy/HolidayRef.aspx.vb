Imports denaro
Partial Class HolidayRef
    Inherits System.Web.UI.Page
    Dim LegalStyle As New Style
    Dim SpecialStyle As New Style
    Dim SelectedStyle As New Style
    Public vScript As String = ""


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim c As New sqlclient.sqlconnection(connStr)
        Dim cm As New sqlclient.sqlcommand
        Dim rs As sqlclient.sqldatareader

        If Session("uid") = "" Then
            Session("returnaddr") = "HolidayRef.aspx"
            Server.Transfer("index.aspx")
        End If

        If Not CanRun(Session("caption"), Request.Item("id")) Then
            Session("denied") = "1"
            Server.Transfer("main.aspx")
            Exit Sub
        End If

        c.Open()
        cm.Connection = c

        With LegalStyle
            .BackColor = Color.Red
            .ForeColor = Color.White
            .Font.Bold = True
        End With
        With SelectedStyle
            .BackColor = Color.DarkBlue
            .ForeColor = Color.Yellow
        End With
        With SpecialStyle
            .BackColor = Color.Green
            .ForeColor = Color.White
            .Font.Bold = True
        End With
        If Not IsPostBack Then
            lblCaption.Text = "Holiday Reference"
            Dim i As Integer = 0
            Me.cmdAdd.Enabled = False

            cm.CommandText = "SELECT Rc_Cd,Descr FROM rc ORDER BY Descr"
            rs = cm.ExecuteReader
            chkRC.Items.Clear()
            Do While rs.Read
                chkRC.Items.Add(New ListItem(rs("Rc_Cd") & "=>" & rs("Descr").ToString.ToUpper, rs("Rc_Cd")))
                i += 1
            Loop
            Me.txtCost.Value = i
            rs.Close()

            i = 0
            cm.CommandText = "SELECT AgencyCd,AgencyName FROM agency ORDER BY AgencyName"
            rs = cm.ExecuteReader
            chkOffice.Items.Clear()
            Do While rs.Read
                chkOffice.Items.Add(New ListItem(rs("AgencyCd") & "=>" & rs("AgencyName").ToString.ToUpper, rs("AgencyCd")))
                i += 1
            Loop
            rs.Close()
            Me.txtComp.Value = i
            i = 0
            cm.CommandText = "select EmploymentType,Descr from hr_employment_type order by Descr"
            rs = cm.ExecuteReader
            chkRank.Items.Clear()
            Do While rs.Read
                chkRank.Items.Add(New ListItem(rs("EmploymentTYpe") & "=>" & rs("Descr").ToString.ToUpper, rs("EmploymentType")))
                i = i + 1
            Loop
            rs.Close()
            Me.txtRank.Value = i
            i = 0

            BuildCombo("SELECT Holy_Date,Descr FROM py_holiday", cmbHoliday)
            BuildCombo("select Div_Cd,Descr from hr_div_ref where Div_Cd in ('" & _
                    Session("divlist").ToString.Replace(",", "','") & "') order by Descr", cmbDiv)
            BuildCombo("select Dept_Cd,Descr from hr_dept_ref where Dept_Cd in ('" & _
                Session("deptlist").ToString.Replace(",", "','") & "') order by Descr", cmbDept)
            BuildCombo("select Section_Cd,Descr from hr_section_ref where Section_Cd in ('" & _
                Session("sectionlist").ToString.Replace(",", "','") & "') order by Descr", cmbSection)
            BuildCombo("select Unit_Cd,Descr from hr_unit_ref where Unit_Cd in ('" & _
                Session("unitlist").ToString.Replace(",", "','") & "') order by Descr", cmbUnit)

            cmbDiv.Items.Add("All")
            cmbDept.Items.Add("All")
            cmbSection.Items.Add("All")
            cmbUnit.Items.Add("All")

            cmbDiv.SelectedValue = "All"
            cmbDept.SelectedValue = "All"
            cmbSection.SelectedValue = "All"
            cmbUnit.SelectedValue = "All"

            cmbHoliday.Items.Add(" -- ")
            cmbHoliday.SelectedValue = " -- "

            'DataRefresh()
        End If
        c.Close()
        c.Dispose()
        cm.Dispose()

    End Sub

    Protected Sub calHoliday_DayRender(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DayRenderEventArgs) Handles calHoliday.DayRender
        Dim c As New sqlclient.sqlconnection(connStr)
        Dim cm As New sqlclient.sqlcommand("SELECT Holy_Date, Official FROM py_holiday", c)
        Dim rs As sqlclient.sqldatareader
        c.Open()
        rs = cm.ExecuteReader
        Do While rs.Read
            If rs("Official") = 1 Then
                If e.Day.Date = Format(rs("Holy_Date"), "yyyy/MM/dd") Then
                    e.Cell.ApplyStyle(LegalStyle)
                End If
            Else
                If e.Day.Date = Format(rs("Holy_Date"), "yyyy/MM/dd") Then
                    e.Cell.ApplyStyle(SpecialStyle)
                End If
            End If
        Loop
        c.Close()
        c.Dispose()
        cm.Dispose()

        If e.Day.Date = Me.calHoliday.SelectedDate Then
            e.Cell.ApplyStyle(SelectedStyle)
        End If
    End Sub

    Private Sub DataRefresh()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New sqlclient.sqlcommand
        Dim cmRef As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim rsRef As SqlClient.SqlDataReader
        Dim OfficeCd As String = ""
        Dim RcCd As String = ""
        Dim RankCd As String = ""
        Dim i As Integer = 0


        Try
            c.Open()
        Catch ex As sqlclient.sqlexception
            vScript = "alert(""" & ex.Message.Replace(vbCrLf, "") & """);"
            Exit Sub
        End Try

        cm.Connection = c
        cmRef.Connection = c

        Me.txtDate.Text = ""
        Me.txtDesc.Text = ""
        Me.btnType.SelectedIndex = -1
        Me.txtDate.Text = Format(calHoliday.SelectedDate, "MM/dd/yyyy")

        For i = 0 To chkRC.Items.Count - 1
            chkRC.Items(i).Selected = False
        Next i

        For i = 0 To chkOffice.Items.Count - 1
            chkOffice.Items(i).Selected = False
        Next i

        For i = 0 To chkRank.Items.Count - 1
            chkRank.Items(i).Selected = False
        Next i

        tglCompanies.Checked = False
        tglCostCenter.Checked = False
        chkSelectedRc.Items.Clear()
        chkSelectedOfc.Items.Clear()
        chkSelectedRank.Items.Clear()

        chkUnion.Checked = False

        Try
            cm.CommandText = "SELECT * FROM py_holiday WHERE Holy_Date = '" & Me.txtDate.Text & "'"
            rs = cm.ExecuteReader

            If rs.Read Then
                RcCd = IIf(IsDBNull(rs("Rc_Cd")), "", rs("Rc_Cd"))
                OfficeCd = IIf(IsDBNull(rs("Office_Cd")), "", rs("Office_Cd"))
                RankCd = IIf(IsDBNull(rs("Rank")), "", rs("Rank"))

                If rs("UnionOnly") = 1 Then
                    chkUnion.Checked = True
                End If

                If RcCd.Contains("*") Then
                    RcCd = "*"
                    Me.tglCostCenter.Checked = True
                Else
                    RcCd = RcCd
                    Me.tglCostCenter.Checked = False
                End If

                If OfficeCd.Contains("*") Then
                    OfficeCd = "*"
                    Me.tglCompanies.Checked = True
                Else
                    OfficeCd = OfficeCd
                    Me.tglCompanies.Checked = False
                End If

                If RankCd.Contains("*") Then
                    RankCd = "*"
                    Me.tglCompanies.Checked = True
                Else
                    RankCd = RankCd
                    Me.tglCompanies.Checked = False
                End If

                'put in the list of selected rc and ofc
                cmRef.CommandText = "SELECT Rc_Cd,Descr FROM rc "
                If RcCd <> "*" Then
                    cmRef.CommandText += " where Rc_Cd in ('" & RcCd.Replace(",", "','") & "')"
                End If
                cmRef.CommandText += " ORDER BY Descr"
                rsRef = cmRef.ExecuteReader

                Do While rsRef.Read
                    chkSelectedRc.Items.Add(New ListItem(rsRef("Rc_Cd") & "=>" & rsRef("Descr").ToString.ToUpper, rsRef("Rc_Cd")))
                Loop
                rsRef.Close()

                cmRef.CommandText = "SELECT AgencyCd,AgencyName FROM agency "
                If OfficeCd <> "*" Then
                    cmRef.CommandText += " where AgencyCd in ('" & OfficeCd.Replace(",", "','") & "') "
                End If
                cmRef.CommandText += " ORDER BY AgencyName"

                rsRef = cmRef.ExecuteReader

                Do While rsRef.Read
                    chkSelectedOfc.Items.Add(New ListItem(rsRef("AgencyCd") & "=>" & rsRef("AgencyName").ToString.ToUpper, rsRef("AgencyCd")))
                Loop
                rsRef.Close()

                'Get Employment type
                cmRef.CommandText = "select EmploymentType,Descr from hr_employment_type"
                If RankCd <> "*" Then
                    cmRef.CommandText += " where EmploymentType in ('" & RankCd.Replace(",", "','") & "') "
                End If
                cmRef.CommandText += " ORDER BY Descr"

                rsRef = cmRef.ExecuteReader

                Do While rsRef.Read
                    chkSelectedRank.Items.Add(New ListItem(rsRef("EmploymentType") & "=>" & rsRef("Descr").ToString.ToUpper, rsRef("EmploymentType")))
                Loop
                rsRef.Close()


                'chkRecurr.Checked = rs("Recurring")
                'SetList("SELECT Rc_Cd FROM Rc ORDER BY Descr", RcCd, chkRC)
                'SetList("SELECT AgencyCd,AgencyName FROM agency ORDER BY AgencyName", OfficeCd, chkOffice)

                Me.txtDesc.Text = IIf(IsDBNull(rs("Descr")), "", rs("Descr"))


                Me.btnType.SelectedIndex = rs("Official")

                Me.cmdAdd.Enabled = False
                Me.cmdEdit.Enabled = True
                Me.cmdDelete.Enabled = True
                Me.cmbHoliday.Items.Clear()
                BuildCombo("SELECT Holy_Date,Descr FROM py_holiday", cmbHoliday)
                cmbHoliday.Items.Add(" -- ")
                Me.cmbHoliday.SelectedValue = Me.calHoliday.SelectedDate
            Else
                Me.cmdAdd.Enabled = True
                Me.cmdEdit.Enabled = False
                Me.cmdDelete.Enabled = False
                Me.cmbHoliday.SelectedValue = " -- "
            End If
            rs.Close()
        Catch ex As system.exception
            vScript = "alert(""" & ex.Message.Replace(vbCrLf, "") & """);"
        Finally
            c.Close()
            c.Dispose()
            cm.Dispose()
        End Try
    End Sub

    Protected Sub calHoliday_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles calHoliday.SelectionChanged
        DataRefresh()
    End Sub

    Protected Sub cmdEdit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdEdit.Click
        With Me
            .txtDesc.ReadOnly = False
            .btnType.Enabled = True
            .chkRC.Enabled = True
            .chkOffice.Enabled = True

            chkSelectedRc.Enabled = True
            chkSelectedOfc.Enabled = True
            chkSelectedRank.Enabled = True

            chkSelectRC.Enabled = True
            chkSelectRank.Enabled = True
            chkSelectOfc.Enabled = True

            chkRecurr.Enabled = True
            chkRank.Enabled = True

            chkUnion.Enabled = True

            .cmdCancel.Enabled = True
            .cmdSave.Enabled = True
            .cmdEdit.Enabled = False
            .cmdAdd.Enabled = False
            .cmdDelete.Enabled = False
            .tglCostCenter.Disabled = False
            .tglCompanies.Disabled = False
            .tglRank.Disabled = False
            .calHoliday.Enabled = False
            .txtDesc.Focus()
        End With

    End Sub

    Protected Sub cmdDelete_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDelete.Click
        Dim c As New sqlclient.sqlconnection(connStr)
        Dim cm As New sqlclient.sqlcommand
        Dim Mode As String = ""

        Try
            c.Open()
        Catch ex As sqlclient.sqlexception
            vScript = "alert(""" & ex.Message.Replace(vbCrLf, "") & """);"
            Exit Sub
        End Try


        cm.Connection = c
        Mode = txtMode.Value

        cm.CommandText = "DELETE FROM py_holiday WHERE Holy_Date = '" & Me.txtDate.Text & "'"

        Try
            cm.ExecuteNonQuery()
            vScript = "alert('Event successfully deleted.');"

            Me.cmbHoliday.Items.Clear()
            BuildCombo("SELECT Holy_Date,Descr FROM py_holiday", cmbHoliday)
            cmbHoliday.Items.Add(" -- ")
            Me.cmbHoliday.SelectedValue = " -- "
        Catch ex As system.exception
            vScript = "alert(""" & ex.Message.Replace(vbCrLf, "") & """);"
        Finally
            c.Close()
            c.Dispose()
            cm.Dispose()
            DataRefresh()
        End Try
    End Sub

    Protected Sub cmdAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdAdd.Click
        Me.txtMode.Value = "Add"
        btnType.SelectedValue = 0
        Me.txtDesc.ReadOnly = False
        Me.btnType.Enabled = True
        Me.btnType.Enabled = True
        Me.chkRC.Enabled = True
        Me.chkOffice.Enabled = True
        Me.chkRank.Enabled = True

        chkSelectedOfc.Enabled = True
        chkSelectedRc.Enabled = True
        chkSelectedRank.Enabled = True

        chkSelectOfc.Enabled = True
        chkSelectRC.Enabled = True
        chkSelectRank.Enabled = True
        chkUnion.Enabled = True

        chkRecurr.Enabled = True
        Me.cmdCancel.Enabled = True
        Me.cmdSave.Enabled = True
        Me.cmdAdd.Enabled = False
        Me.cmdEdit.Enabled = False
        Me.cmdDelete.Enabled = False
        Me.txtDate.Text = Format(calHoliday.SelectedDate.Date, "MM/dd/yyyy")
        Me.tglCostCenter.Disabled = False
        Me.tglCompanies.Disabled = False
        tglRank.Disabled = False
        Me.calHoliday.Enabled = False
        Me.txtDesc.Focus()
    End Sub

    Protected Sub cmdCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        Me.btnType.Enabled = False
        Me.txtDesc.ReadOnly = True
        Me.chkRC.Enabled = False
        Me.chkOffice.Enabled = False
        Me.chkRank.Enabled = False
        chkSelectedRc.Enabled = False
        chkSelectedOfc.Enabled = False
        chkSelectedRank.Enabled = False
        chkSelectOfc.Enabled = False
        chkSelectRC.Enabled = False
        chkSelectRank.Enabled = False
        chkRecurr.Enabled = True
        chkRecurr.Enabled = False
        chkUnion.Enabled = False
        Me.cmdCancel.Enabled = False
        Me.cmdSave.Enabled = False
        Me.cmdAdd.Enabled = True
        Me.cmdEdit.Enabled = True
        Me.cmdDelete.Enabled = True
        Me.tglCostCenter.Disabled = True
        Me.tglCompanies.Disabled = True
        Me.calHoliday.Enabled = True
        DataRefresh()
    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        Dim c As New sqlclient.sqlconnection(connStr)
        Dim cm As New sqlclient.sqlcommand
        Dim rs As sqlclient.sqldatareader

        Dim vSQL As String = ""
        Dim HolyDate As Date = Me.txtDate.Text
        Dim isLegal As String = Me.btnType.SelectedIndex
        Dim OfficeCd As String = ""
        Dim RcCd As String = ""
        Dim RankCd As String = ""
        Dim vUnion As Integer = 0
        Dim i As Integer = 0

        Dim Descr As String = Me.txtDesc.Text.Replace(";", "").Replace("'", "").Replace(",", "")

        'If isLegal Then
        '    RcCd = "*"
        '    OfficeCd = "*"
        '    'RankCd = "*"
        'Else
        '    'RC 
        'For i = 0 To chkSelectedRc.Items.Count - 1
        '    RcCd += chkSelectedRc.Items(i).Value & ","
        '    Response.Write(RcCd & "v1 <br>")
        'Next
        RcCd = ""
        For i = 0 To chkRC.Items.Count - 1
            If chkRC.Items(i).Selected Then 'And Not RcCd.Contains(chkRC.Items(i).Value) Then
                RcCd += chkRC.Items(i).Value & ","
            End If
        Next i

        If RcCd <> "" Then
            RcCd = RcCd.Substring(0, RcCd.Length - 1)
        Else
            vScript = "alert('The Cost Centers is empty. Please select from list')"
            Exit Sub
        End If

        'Office
        For i = 0 To chkSelectedOfc.Items.Count - 1
            OfficeCd += chkSelectedOfc.Items(i).Value & ","
        Next
        For i = 0 To chkOffice.Items.Count - 1
            If chkOffice.Items(i).Selected And Not OfficeCd.Contains(chkOffice.Items(i).Value) Then
                OfficeCd += chkOffice.Items(i).Value & ","
            End If
        Next i
        If OfficeCd <> "" Then
            OfficeCd = OfficeCd.Substring(0, OfficeCd.Length - 1)
        End If
        'End If

        'Rank
        For i = 0 To chkSelectedRank.Items.Count - 1
            RankCd += chkSelectedRank.Items(i).Value & ","
        Next
        For i = 0 To chkRank.Items.Count - 1
            If chkRank.Items(i).Selected And Not RankCd.Contains(chkRank.Items(i).Value) Then
                RankCd += chkRank.Items(i).Value & ","
            End If
        Next i
        If RankCd <> "" Then
            RankCd = RankCd.Substring(0, RankCd.Length - 1)
        Else
            vScript = "alert('The Rank is empty. Please select from the list ')"
            Exit Sub
        End If


        If chkUnion.Checked = True Then
            vUnion = 1
        End If

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert(""" & ex.Message.Replace(vbCrLf, "") & """);"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        cm.Connection = c
        cm.CommandText = "SELECT Holy_Date FROM py_holiday WHERE Holy_Date = '" & HolyDate & "'"

        Try
            rs = cm.ExecuteReader
            If rs.Read Then

                vSQL = "UPDATE py_holiday SET Descr='" & Descr & "', Official=" & isLegal & _
                       ", Office_Cd='" & OfficeCd & "', Rc_Cd='" & RcCd & _
                       "', Rank='" & RankCd & "', UnionOnly=" & vUnion & " where Holy_Date = '" & HolyDate & "'"
            Else
                vSQL = "INSERT INTO py_holiday (Holy_Date,Descr,Official,Office_Cd,Rc_Cd,Rank,UnionOnly) VALUES ('" & HolyDate & _
                       "', '" & Descr & "'," & isLegal & ", '" & OfficeCd & "', '" & RcCd & "','" & RankCd & "'," & vUnion & ")"
            End If

            rs.Close()
            cm.CommandText = vSQL
            cm.ExecuteNonQuery()
            vScript = "alert('Record successfully saved!..');"
        Catch ex As SqlClient.SqlException
            vScript = "alert(""" & ex.Message.Replace(vbCrLf, "") & """);"
        Finally
            c.Close()
            c.Dispose()
            cm.Dispose()
        End Try

        Me.btnType.Enabled = False
        Me.txtDesc.ReadOnly = True
        Me.chkRC.Enabled = False
        Me.chkOffice.Enabled = False
        Me.chkRank.Enabled = False
        chkSelectedRc.Enabled = False
        chkSelectedOfc.Enabled = False
        chkSelectedRank.Enabled = False
        chkSelectOfc.Enabled = False
        chkSelectRC.Enabled = False
        chkSelectRank.Enabled = False
        chkRecurr.Enabled = True
        chkRecurr.Enabled = False
        chkUnion.Enabled = False
        Me.cmdCancel.Enabled = False
        Me.cmdSave.Enabled = False
        Me.cmdAdd.Enabled = True
        Me.cmdEdit.Enabled = True
        Me.cmdDelete.Enabled = True
        Me.cmdAdd.Enabled = True
        Me.tglCostCenter.Disabled = True
        Me.tglCompanies.Disabled = True
        Me.tglCostCenter.Checked = False
        Me.tglCompanies.Checked = False
        Me.calHoliday.Enabled = True
        DataRefresh()
    End Sub
    Private Sub SetList(ByVal pSQL As String, ByVal pChkField As String, ByRef chkBox As System.Web.UI.WebControls.CheckBoxList)
        'Dim c As New sqlclient.sqlconnection(connStr)
        'Dim cm As New sqlclient.sqlcommand
        'Dim dr As sqlclient.sqldatareader
        Dim iCtr As Integer
        'c.Open()
        'cm.Connection = c
        'cm.CommandText = pSQL
        'dr = cm.ExecuteReader
        'iCtr = 0

        'Do While dr.Read
        For iCtr = 0 To chkBox.Items.Count - 1
            If pChkField = "*" Then 'All
                chkBox.Items(iCtr).Selected = True
            Else 'Selected
                If pChkField.IndexOf(chkBox.Items(iCtr).Value) >= 0 Then
                    chkBox.Items(iCtr).Selected = True
                    If chkBox.ID = "chkRC" Then
                        chkSelectedRc.Items.Add(New ListItem(chkBox.Items(iCtr).Text, chkBox.Items(iCtr).Value))
                    Else
                        chkSelectedOfc.Items.Add(New ListItem(chkBox.Items(iCtr).Text, chkBox.Items(iCtr).Value))
                    End If

                End If
            End If
        Next
        'iCtr += 1
        'Loop
        'dr.Close()
        'cm.Dispose()
        'c.Close()
        'c.Dispose()
    End Sub

    Protected Sub cmbHoliday_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbHoliday.SelectedIndexChanged
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        c.Open()
        cm.Connection = c
        cm.CommandText = "SELECT Holy_Date FROM py_holiday WHERE Holy_Date = '" & Format(CDate(cmbHoliday.SelectedValue), "yyyy/MM/dd") & "'"
        rs = cm.ExecuteReader
        If rs.Read Then
            calHoliday.SelectedDate = rs("Holy_Date")
            Me.calHoliday.VisibleDate = rs("Holy_Date")
        End If
        rs.Close()
        c.Close()
        c.Dispose()
        cm.Dispose()
        DataRefresh()
    End Sub

    Protected Sub cmdRefresh_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdRefresh.Click
        Dim c As New sqlclient.sqlconnection(connStr)
        Dim cm As New sqlclient.sqlcommand
        Dim rs As sqlclient.sqldatareader

        Try
            c.Open()
        Catch ex As sqlclient.sqlexception
            vScript = "alert(""" & ex.Message.Replace(vbCrLf, " ").Replace("'", "") & """);"
            Exit Sub
        End Try

        Try
            Dim vFilter As String = ""
            Dim i As Integer = 0

            cm.Connection = c
            If cmbDiv.SelectedValue <> "All" Then
                vFilter += " and DivCd='" & cmbDiv.SelectedValue & "' "
            End If
            If cmbDept.SelectedValue <> "All" Then
                vFilter += " and DeptCd='" & cmbDept.SelectedValue & "' "
            End If
            If cmbSection.SelectedValue <> "All" Then
                vFilter += " and SectionCd='" & cmbSection.SelectedValue & "' "
            End If
            If cmbUnit.SelectedValue <> "All" Then
                vFilter += " and UnitCd='" & cmbUnit.SelectedValue & "' "
            End If

            cm.CommandText = "select Rc_Cd,Descr from rc where exists " & _
                "(select distinct Rc_Cd from py_emp_master where py_emp_master.Rc_Cd=rc.Rc_Cd " & _
                vFilter & ") order by Descr"
            rs = cm.ExecuteReader
            chkRC.Items.Clear()
            Do While rs.Read
                chkRC.Items.Add(New ListItem(rs("Rc_Cd") & "=>" & rs("Descr").ToString.ToUpper, rs("Rc_Cd")))
                i += 1
            Loop
            Me.txtCost.Value = i
            rs.Close()

            i = 0
            cm.CommandText = "SELECT AgencyCd,AgencyName FROM agency where exists " & _
                "(select distinct Agency_Cd from py_emp_master where py_emp_master.Agency_Cd=agency.AgencyCd " & _
                vFilter & ") ORDER BY AgencyName"

            rs = cm.ExecuteReader
            chkOffice.Items.Clear()
            Do While rs.Read
                chkOffice.Items.Add(New ListItem(rs("AgencyCd") & "=>" & rs("AgencyName").ToString.ToUpper, rs("AgencyCd")))
                i += 1
            Loop

            rs.Close()
        Catch ex As sqlclient.sqlexception
            vScript = "alert(""" & ex.Message.Replace(vbCrLf, " ").Replace("'", "") & """);"
        Finally
            c.Close()
            c.Dispose()
            cm.Dispose()
        End Try
    End Sub

    Protected Sub cmdClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdClose.Click
        Session.Remove("rcholiday")
        Session.Remove("ofcholiday")
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub cmdRemoveRC_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdRemoveRC.Click
        Dim i As Integer
        Dim vList As New ListItemCollection

        For i = 0 To chkSelectedRc.Items.Count - 1
            If Not chkSelectedRc.Items(i).Selected Then
                vList.Add(New ListItem(chkSelectedRc.Items(i).Text, chkSelectedRc.Items(i).Value))
            End If
        Next
        chkSelectedRc.Items.Clear()

        For i = 0 To vList.Count - 1
            chkSelectedRc.Items.Add(vList(i))
        Next
    End Sub

    Protected Sub cmdRemoveOfc_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdRemoveOfc.Click
        Dim i As Integer
        Dim vList As New ListItemCollection

        For i = 0 To chkSelectedOfc.Items.Count - 1
            If Not chkSelectedOfc.Items(i).Selected Then
                vList.Add(New ListItem(chkSelectedOfc.Items(i).Text, chkSelectedOfc.Items(i).Value))
            End If
        Next
        chkSelectedOfc.Items.Clear()

        For i = 0 To vList.Count - 1
            chkSelectedOfc.Items.Add(vList(i))
        Next
    End Sub

    Protected Sub chkSelectRC_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkSelectRC.CheckedChanged
        Dim i As Integer
        For i = 0 To chkSelectedRc.Items.Count - 1
            chkSelectedRc.Items(i).Selected = chkSelectRC.Checked
        Next
    End Sub

    Protected Sub chkSelectOfc_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkSelectOfc.CheckedChanged
        Dim i As Integer
        For i = 0 To chkSelectedOfc.Items.Count - 1
            chkSelectedOfc.Items(i).Selected = chkSelectOfc.Checked
        Next
    End Sub

    Protected Sub cmdRemoveRank_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdRemoveRank.Click
        Dim i As Integer
        Dim vList As New ListItemCollection

        For i = 0 To chkSelectedRank.Items.Count - 1
            If Not chkSelectedRank.Items(i).Selected Then
                vList.Add(New ListItem(chkSelectedRank.Items(i).Text, chkSelectedRank.Items(i).Value))
            End If
        Next
        chkSelectedRank.Items.Clear()

        For i = 0 To vList.Count - 1
            chkSelectedRank.Items.Add(vList(i))
        Next
    End Sub

    Protected Sub chkSelectRank_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkSelectRank.CheckedChanged
        Dim i As Integer
        For i = 0 To chkSelectedRank.Items.Count - 1
            chkSelectedRank.Items(i).Selected = chkSelectRank.Checked
        Next
    End Sub
End Class
