Imports denaro
Structure OT
    Dim A1 As Decimal
    Dim A2A3 As Decimal
    Dim A4 As Decimal
    Dim B1 As Decimal
    Dim B2 As Decimal
    Dim B3 As Decimal
    Dim B4 As Decimal
    Dim C1 As Decimal
    Dim C2 As Decimal
    Dim C3 As Decimal
    Dim C4 As Decimal
    Dim D1 As Decimal
    Dim D2 As Decimal
    Dim D3 As Decimal
    Dim D4 As Decimal
    Dim E1 As Decimal
    Dim E2 As Decimal
    Dim E3 As Decimal
    Dim E4 As Decimal
    Dim F1 As Decimal
    Dim F2 As Decimal
    Dim F3 As Decimal
    Dim F4 As Decimal
End Structure

Partial Class dailylog
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Public vOtDtl As String = ""
    Dim vAcaMinHrs As Decimal = 0
    Dim vRataMinHrs As Decimal = 0
    Dim vPeraMinHrs As Decimal = 0
    Dim vMealMinHrs As Decimal = 0
    Dim vGrace As Single = 0
    Dim vBreak As Single = 0
    Dim vRateHr As Single = 0
    Dim vRateDay As Single = 0
    Dim vReqHrs As Single = 8
    Dim vOtHrs As Single = 0
    Dim vOtAfter As Single = 0      'min. # of hours before ot is recognized
    Dim vHours As Single = 0
    Dim vEmpStat As String = ""
    Dim vGrade As String = ""
    Dim vName As String = ""
    Dim vHoly As Boolean = False
    Dim vLegal As Boolean = False
    Dim vRest As Boolean = False
    Dim vFlexi As Boolean = False
    Dim vFullFlexi As Boolean = False
    Dim vCanOT As Boolean = False
    Dim vIn As Date = Nothing
    Dim vOut As Date = Nothing
    Dim vOutD As Date = Nothing
    Dim vRegIn As Date = Nothing
    Dim vRegOut As Date = Nothing
    Dim vETP As Single = 0
    Dim vType As String = "99"
    Dim vCasualCd As String = ""
    Dim vClass As String = "odd"
    Dim vFromDate As Date
    Dim vToDate As Date
    Dim iRows As Integer = -1

    Public Function PlaceRow() As Integer
        iRows += 1
        Return iRows
    End Function
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
        End If

        If Not CanRun(Session("caption"), Request.Item("id")) Then
            Session("denied") = "1"
            Server.Transfer("main.aspx")
            Exit Sub
        End If

        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                                  ''
        '' DATE MODIFIED: 2/11/2013                                      ''
        '' PURPOSE: TO ENABLE THE ACCESS RIGHTS FOR MODIFICATION AND     ''
        ''          DELETION OF RECORDS                                  ''
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '        cmdEdit.Enabled = CanRun(Session("caption"), "46.1")
        'cmdDel.Enabled = CanRun(Session("caption"), "46.2")
        ''''''''''''''''' END OF MODIFCATION ''''''''''''''''''''''''''''''

        txtRank.Text = Request.Form("txtRank")
        txtFrom.Text = Request.Form("txtFrom")
        txtTo.Text = Request.Form("txtTo")

        If Not IsPostBack Then
            Dim c As New SqlClient.SqlConnection(connStr)
            Dim cm As New SqlClient.SqlCommand("delete from py_time_log where Emp_Cd is null or Emp_Cd=''", c)

            c.Open()
            cm.ExecuteNonQuery()

            lblCaption.Text = "Daily Logs"

            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:  VIC GATCHALIAN                                        ''
            '' DATE MODIFIED: 2/19/2013                                            ''
            '' PURPOSE: TO CHANGE THE DATE SELECTION TO POP-UP CALENDAR INSTEAD    ''
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '''''''''''''''''''''' OLD CODE '''''''''''''''''''''''''''''''''''''''''
            'Dim iCtr As Integer
            'For iCtr = 1 To 31      'add days
            '    cmbDayFr.Items.Add(iCtr)
            '    cmbDayTo.Items.Add(iCtr)
            'Next iCtr
            'For iCtr = 1980 To 2030 'add year
            '    cmbYrFr.Items.Add(iCtr)
            '    cmbYrTo.Items.Add(iCtr)
            'Next iCtr
            ''now set the default values
            'cmbMonthFr.SelectedValue = Now.Month
            'cmbMonthTo.SelectedValue = Now.Month
            'cmbDayFr.SelectedValue = 1
            'cmbDayTo.SelectedValue = Now.Day
            'cmbYrFr.SelectedValue = Now.Year
            'cmbYrTo.SelectedValue = Now.Year
            '''''''''''''''''''''' END OLD CODE '''''''''''''''''''''''''''''''''''''
            txtFrom.Text = Now.Month & "/1/" & Now.Year
            txtTo.Text = Format(Now, "MM/dd/yyyy")
            '''''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''''''


            'now build the reference code
            BuildCombo("select Rc_Cd,Descr from rc where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='rc' and Property_Value=Rc_Cd) order by Descr", cmbRC, c)
            BuildCombo("select AgencyCd,AgencyName from agency where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='agency' and Property_Value=AgencyCd) order by AgencyName", cmbOfc, c)
            BuildCombo("select Div_Cd,Descr from hr_div_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='division' and Property_Value=Div_Cd) order by Descr", cmbDiv, c)
            BuildCombo("select Dept_Cd,Descr from hr_dept_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='department' and Property_Value=Dept_Cd) order by Descr", cmbDept, c)
            BuildCombo("select Section_Cd,Descr from hr_section_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='section' and Property_Value=Section_Cd) order by Descr", cmbSection, c)
            BuildCombo("select Unit_Cd,Descr from hr_unit_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='unit' and Property_Value=Unit_Cd) order by Descr", cmbUnit, c)
            BuildCombo("select Status_Code, Descr from py_employee_stat order by Descr", cmbEmpStatus, c)

            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:     Rudner Diaz                                                            ''
            '' DATE:            4/5/2013                                                               ''
            '' PURPOSE:         To include the Payment mode in the query                               ''
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            BuildCombo("select Pay_Cd,Payment from py_pay_mode order by Payment", cmbPayMode, c)
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

            'BuildCombo("select EmploymentType,Descr from hr_employment_type where EmploymentType in ('" & _
            '    Session("typelist").ToString.Replace(",", "','") & "') order by Descr", cmbRank)

            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:  VIC GATCHALIAN                                     ''
            '' DATE MODIFIED: 2/19/2013                                         ''
            '' PURPOSE: TO DISPLAY THE DEFAULT RANKS RIGHTS                     ''
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            Dim rs As SqlClient.SqlDataReader
            cm.CommandText = "select EmploymentType from hr_employment_type where EmploymentType in ('" & _
                Session("typelist").ToString.Replace(",", "','") & "') order by EmploymentType"

            rs = cm.ExecuteReader
            txtRank.Text = ""
            Do While rs.Read
                txtRank.Text += rs("EmploymentType") & ","
            Loop
            rs.Close()
            If txtRank.Text <> "" Then
                txtRank.Text = Mid(txtRank.Text, 1, Len(txtRank.Text) - 1)
            End If
            ''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''''''''

            c.Close()
            c.Dispose()
            cm.Dispose()

            cmbRC.Items.Add("All")
            cmbRC.SelectedValue = "All"
            cmbOfc.Items.Add("All")
            cmbOfc.SelectedValue = "All"
            cmbDiv.Items.Add("All")
            cmbDiv.SelectedValue = "All"
            cmbDept.Items.Add("All")
            cmbDept.SelectedValue = "All"
            cmbSection.Items.Add("All")
            cmbSection.SelectedValue = "All"
            cmbUnit.Items.Add("All")
            cmbUnit.SelectedValue = "All"
            cmbEmpStatus.Items.Add("All")
            cmbEmpStatus.SelectedValue = "All"

            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:     Rudner Diaz                                                            ''
            '' DATE:            4/5/2013                                                               ''
            '' PURPOSE:         To include the Payment mode in the query                               ''
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            cmbPayMode.Items.Add("All")
            cmbPayMode.SelectedValue = "All"
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

            'cmbRank.Items.Add("All")
            'cmbRank.SelectedValue = "All"
            Session("letter") = "A"
            iRows = 0
            'DataRefresh(Session("letter"))
        End If
    End Sub
    Protected Sub DataRefresh(ByVal pLetter As String)
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim dr As SqlClient.SqlDataReader
        Dim da As SqlClient.SqlDataAdapter
        Dim ds As New DataSet
        Dim vFilter As String = " where " & cmbType.SelectedValue & " like '" & pLetter & "%' "
        Dim vIdList As String = ""
        Dim vSql As String = ""
        Dim vQuery As String = ""

        'txtRank.Text = Request.Form("txtRank")

        If tblEmp.SelectedIndex >= 0 Then
            Me.tblEmp.SelectedIndex = 0
        End If

        iRows = -1
        Select Case Val(cmbStatus.SelectedValue)
            Case 1  'active employees only
                vFilter += " and Date_Resign is null AND Date_Retired IS NULL AND DateHold IS NULL AND DateDismissed IS NULL "
                vQuery += " where Date_Resign is null AND Date_Retired IS NULL AND DateHold IS NULL AND DateDismissed IS NULL "
            Case 0  'inactive employees only
                vFilter += " and (Date_Resign is not null OR Date_Retired IS NOT NULL OR DateHold IS NOT NULL Or DateDismissed IS NOT NULL) "
                vQuery += " where (Date_Resign is not null OR Date_Retired IS NOT NULL OR DateHold IS NOT NULL Or DateDismissed IS NOT NULL) "
            Case 3 'Both
                vQuery += " where Emp_Cd IS NOT NULL"
        End Select

        If cmbRC.SelectedValue <> "All" Then   'filter by cost center
            vFilter += " and Rc_Cd='" & cmbRC.SelectedValue & "' "
            vQuery += " and Rc_Cd='" & cmbRC.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='rc' and Property_Value=Rc_Cd) "
            vQuery += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='rc' and Property_Value=Rc_Cd) "
        End If

        If cmbOfc.SelectedValue <> "All" Then        'filter by office/agency
            vFilter += " and Agency_Cd='" & cmbOfc.SelectedValue & "' "
            vQuery += " and Agency_Cd='" & cmbOfc.SelectedValue & "' "
        Else
            vFilter += "  and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='agency' and Property_Value=Agency_Cd) "
            vQuery += "  and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='agency' and Property_Value=Agency_Cd) "
        End If
        If cmbDiv.SelectedValue <> "All" Then      'filter by division
            vFilter += " and Divcd='" & cmbDiv.SelectedValue & "' "
            vQuery += " and Divcd='" & cmbDiv.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='division' and Property_Value=DivCd) "
            vQuery += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='division' and Property_Value=DivCd) "
        End If
        If cmbDept.SelectedValue <> "All" Then  'filter by departments
            vFilter += " and DeptCd='" & cmbDept.SelectedValue & "' "
            vQuery += " and DeptCd='" & cmbDept.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='department' and Property_Value=DeptCd) "
            vQuery += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='department' and Property_Value=DeptCd) "
        End If
        If cmbSection.SelectedValue <> "All" Then 'filter by section
            vFilter += " and SectionCd='" & cmbSection.SelectedValue & "' "
            vQuery += " and SectionCd='" & cmbSection.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='section' and Property_Value=SectionCd) "
            vQuery += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='section' and Property_Value=SectionCd) "
        End If
        If cmbUnit.SelectedValue <> "All" Then  'filter by units
            vFilter += " and UnitCd='" & cmbUnit.SelectedValue & "' "
            vQuery += " and UnitCd='" & cmbUnit.SelectedValue & "' "
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='unit' and Property_Value=UnitCd) "
            vQuery += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='unit' and Property_Value=UnitCd) "
        End If
        If cmbEmpStatus.SelectedValue <> "All" Then
            vFilter += " and Emp_Status='" & cmbEmpStatus.SelectedValue & "' "
            vQuery += " and Emp_Status='" & cmbEmpStatus.SelectedValue & "' "
        End If

        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:     Rudner Diaz                                                            ''
        '' DATE:            4/5/2013                                                               ''
        '' PURPOSE:         To include the Payment mode in the query                               ''
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        If cmbPayMode.SelectedValue <> "All" Then
            vFilter += " and Pay_Cd='" & cmbPayMode.SelectedValue & "' "
            vQuery += " and Pay_Cd='" & cmbPayMode.SelectedValue & "' "
        End If
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

        'If cmbRank.SelectedValue <> "All" Then   'filter by ranks
        '    vFilter += " and EmploymentType ='" & cmbRank.SelectedValue & "' "
        '    vQuery += " and EmploymentType = '" & cmbRank.SelectedValue & "' "
        'Else
        '    vFilter += " and EmploymentType in ('" & Session("typelist").ToString.Replace(",", "','") & "') "
        '    vQuery += " and EmploymentType in ('" & Session("typelist").ToString.Replace(",", "','") & "') "
        'End If

        Dim vRanklist As String = txtRank.Text
        
        Session("ranklist") = vRanklist
        vFilter += " and EmploymentType in ('" & vRanklist.Replace(",", "','") & "') "
        vQuery += " and EmploymentType in ('" & vRanklist.Replace(",", "','") & "') "

        vSql = "select Emp_Cd,Emp_Lname,Emp_Fname,Emp_Mname,Req_Hrs_Day from py_emp_master" & vFilter & _
            " order by Emp_Lname,Emp_Fname,Emp_Mname"
        Session("sql") = "select Emp_Cd,Emp_Lname,Emp_Fname,Emp_Mname,Req_Hrs_Day from py_emp_master" & vQuery & _
            " order by Emp_Lname,Emp_Fname,Emp_Mname"
        Session("filter") = vFilter

        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                                                 ''
        '' DATE MODIFIED: 2/19/2013                                                     ''
        '' PURPOSE: TO CHANGE THE DATE SELECTION TO A POP-UP CALENDAR                   ''
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        ''''''''''''''''''''''' OLD CODE '''''''''''''''''''''''''''''''''''''''''''''''''
        'Session("from") = cmbYrFr.SelectedValue & "/" & cmbMonthFr.SelectedValue & "/" & cmbDayFr.SelectedValue
        'Session("to") = cmbYrTo.SelectedValue & "/" & cmbMonthTo.SelectedValue & "/" & cmbDayTo.SelectedValue
        ''''''''''''''''''''''' END OLD CODE '''''''''''''''''''''''''''''''''''''''''''''
        Session("from") = Format(CDate(txtFrom.Text), "yyyy/MM/dd")
        Session("to") = Format(CDate(txtTo.Text), "yyyy/MM/dd")
        ''''''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''''''''''''''

        

        da = New SqlClient.SqlDataAdapter(vSql, c)
        da.Fill(ds, "EmpMaster")
        tblEmp.DataSource = ds.Tables("EmpMaster")
        tblEmp.DataBind()

        ds.Dispose()
        da.Dispose()

        c.Open()
        cm.Connection = c
        cm.CommandText = "select distinct substring(Emp_Lname,1,1) as Letters from py_emp_master " & vQuery
        dr = cm.ExecuteReader
        EnableAll()
        Do While dr.Read
            SetLetters(dr("Letters"))
        Loop
        dr.Close()

        cm.CommandText = "select Emp_Cd from py_emp_master " & vQuery & " order by Emp_Lname,Emp_Fname"
        dr = cm.ExecuteReader
        vIdList = ""
        Session("vEmpCdList") = ""

        Me.txtvId.Value = ""
        Do While dr.Read
            vIdList += dr("Emp_Cd") & "','"
            Me.txtvId.Value += dr("Emp_Cd") & ","
        Loop

        'txtEmpCd_list.Value = "'" & Mid(vIdList, 1, Len(vIdList) - 3) & "'"

        If txtvId.Value <> "" Then
            Me.txtvId.Value = Me.txtvId.Value.Substring(0, Me.txtvId.Value.Length - 1)
            Session("vEmpCdList") = Mid(vIdList, 1, Len(vIdList) - 3)
        End If
        dr.Close()
        cm.Dispose()
        c.Close()
        If vIdList <> "" Then
            vIdList = Mid(vIdList, 1, Len(vIdList) - 3)
            cmdPrint.Enabled = True
        End If
        Session("id") = vIdList
        If vIdList = "" Then
            vScript = "alert('No employee records found based on your selected filter.');"
            cmdEdit.Enabled = False
            cmdDel.Enabled = False
            cmdPrint.Enabled = False
            cmdDownload.Enabled = False
            cmdPrint.Enabled = False
            cmdView.Enabled = False
            cmdPost.Enabled = False
            cmdRecalculate.Disabled = True
            cmdGenSC.Disabled = True
            cmdMealTranspo.Disabled = True
            cmdPrintSumm2.Disabled = True
        Else
            cmdEdit.Enabled = True
            cmdDel.Enabled = True
            cmdPrint.Enabled = True
            cmdDownload.Enabled = True
            cmdPrint.Enabled = True
            cmdView.Enabled = True
            cmdPost.Enabled = True
            cmdRecalculate.Disabled = False
            cmdGenSC.Disabled = False
            cmdMealTranspo.Disabled = False
            cmdPrintSumm2.Disabled = False
        End If
    End Sub
    Private Sub SetLetters(ByVal pLetter As String)
        Select Case LCase(pLetter)
            Case "a"
                cmdA.Visible = True
            Case "b"
                cmdB.Visible = True
            Case "c"
                cmdC.Visible = True
            Case "d"
                cmdD.Visible = True
            Case "e"
                cmdE.Visible = True
            Case "f"
                cmdF.Visible = True
            Case "g"
                cmdG.Visible = True
            Case "h"
                cmdH.Visible = True
            Case "i"
                cmdI.Visible = True
            Case "j"
                cmdJ.Visible = True
            Case "k"
                cmdK.Visible = True
            Case "l"
                cmdL.Visible = True
            Case "m"
                cmdM.Visible = True
            Case "n"
                cmdN.Visible = True
            Case "o"
                cmdO.Visible = True
            Case "p"
                cmdP.Visible = True
            Case "q"
                cmdQ.Visible = True
            Case "r"
                cmdR.Visible = True
            Case "s"
                cmdS.Visible = True
            Case "t"
                cmdT.Visible = True
            Case "u"
                cmdU.Visible = True
            Case "v"
                cmdV.Visible = True
            Case "w"
                cmdW.Visible = True
            Case "x"
                cmdX.Visible = True
            Case "y"
                cmdY.Visible = True
            Case "z"
                cmdZ.Visible = True
        End Select
    End Sub
    Protected Sub cmdReturn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.Click
        Session.Remove("VFILTER")
        Session.Remove("sql")
        Session.Remove("postdate")
        Session.Remove("fromdate")
        Session.Remove("todate")
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub tblEmp_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles tblEmp.PageIndexChanging
        tblEmp.PageIndex = e.NewPageIndex
        DataRefresh(txtSearch.Text)
        RefreshDtl()
    End Sub
    Protected Sub tblEmp_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tblEmp.SelectedIndexChanged
        RefreshDtl()
    End Sub
    Protected Sub RefreshDtl()
        Page.Validate()
        If Page.IsValid Then
            Dim c As New SqlClient.SqlConnection(connStr)
            'Dim cExec As New sqlclient.sqlConnection(connStr)
            Dim cm As New SqlClient.SqlCommand
            Dim cmExec As New SqlClient.SqlCommand
            Dim dr As SqlClient.SqlDataReader
            Dim da As SqlClient.SqlDataAdapter
            Dim ds As New DataSet
            Dim vEmpCd As String = ""
            Dim vSQL As String = ""
            Dim vHrs As Decimal = 0

            If tblEmp.SelectedIndex <> -1 Then
                vEmpCd = tblEmp.SelectedRow.Cells(0).Text
            End If


            'Me.txtvId.Value = vEmpCd
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:  VIC GATCHALIAN                           ''
            '' DATE MODIFIED: 2/19/2013                               ''
            '' PURPOSE: TO CHANGE THE DATE RETRIEVAL FROM COMBO BOX   ''
            ''          TO TEXTBOX WITH POP-UP CALENDAR               ''
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '''''''''''''''''' OLD CODE '''''''''''''''''''''''''''''''
            'vSQL = "select Type,Sched_In,Sched_Out,(cast(month(Tran_Date) as varchar)+'/'+" & _
            '    " cast(day(Tran_Date) as varchar)+'/'+cast(year(Tran_Date) as varchar)) as TranDate," & _
            '    "Time_In,Time_Out,(cast(month(Time_OutDate) as varchar)+'/'+" & _
            '    " cast(day(Time_OutDate) as varchar)+'/'+cast(year(Time_OutDate) as varchar)) as TimeOutDate," & _
            '    "Hrs_Worked,BrkHrs,EffectivityDate,Reason, dbo.fnWEEKDAY(Tran_Date) AS DW  from py_time_log where Emp_Cd='" & _
            '    vEmpCd & "' and Tran_Date between '" & _
            '    cmbYrFr.SelectedValue & "/" & cmbMonthFr.SelectedValue & "/" & cmbDayFr.SelectedValue & "' and '" & _
            '    cmbYrTo.SelectedValue & "/" & cmbMonthTo.SelectedValue & "/" & cmbDayTo.SelectedValue & _
            '    "' order by Tran_Date,Time_In"
            '''''''''''''''''' END OLD CODE ''''''''''''''''''''''''''''
            vSQL = "select Type,Sched_In,Sched_Out,(cast(month(Tran_Date) as varchar)+'/'+" & _
                " cast(day(Tran_Date) as varchar)+'/'+cast(year(Tran_Date) as varchar)) as TranDate," & _
                "Time_In,Time_Out,(cast(month(Time_OutDate) as varchar)+'/'+" & _
                " cast(day(Time_OutDate) as varchar)+'/'+cast(year(Time_OutDate) as varchar)) as TimeOutDate," & _
                "Hrs_Worked,BrkHrs,EffectivityDate,Reason, dbo.fnWEEKDAY(Tran_Date) AS DW  from py_time_log where Emp_Cd='" & _
                vEmpCd & "' and Tran_Date between '" & Format(CDate(txtFrom.Text), "yyyy/MM/dd") & "' and '" & _
                Format(CDate(txtTo.Text), "yyyy/MM/dd") & "' order by Tran_Date,Time_In"
            '''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''
            
            c.Open()
            'cExec.Open()
            cm.Connection = c
            cmExec.Connection = c
            cm.CommandText = vSQL
            dr = cm.ExecuteReader
            Do While dr.Read
                vHrs = 0
                If IsDBNull(dr("Hrs_Worked")) Then
ComputeHrs:

                    If Not IsDBNull(dr("Time_Out")) And Not IsDBNull(dr("Time_In")) And Not IsDBNull(dr("TimeOutDate")) Then
                        vHrs = Math.Round(DateDiff(DateInterval.Minute, CDate(dr("TranDate") & " " & Format(CDate(dr("Time_In")), "HH:mm:00")), _
                            CDate(dr("TimeOutDate") & " " & Format(CDate(dr("Time_Out")), "HH:mm:00"))) / 60, 2)
                        cmExec.CommandText = "update py_time_log set Hrs_Worked=" & vHrs & _
                            " where Emp_Cd='" & vEmpCd & "' and Tran_Date='" & _
                            Format(CDate(dr("TranDate")), "yyyy/MM/dd") & "'"
                        cmExec.ExecuteNonQuery()
                    End If
                ElseIf dr("Hrs_Worked") <= 0 Then
                    GoTo ComputeHrs
                End If
            Loop
            dr.Close()
            cm.Dispose()
            cmExec.Dispose()
            c.Close()
            'cExec.Close()
            da = New SqlClient.SqlDataAdapter(vSQL, c)
            da.Fill(ds, "TimeLog")
            tblTime.DataSource = ds.Tables("TimeLog")
            tblTime.DataBind()
            da.Dispose()
            ds.Dispose()
            c.Dispose()
        End If
    End Sub

    Protected Sub cmdA_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdA.Click, _
        cmdB.Click, cmdC.Click, cmdD.Click, cmdE.Click, cmdF.Click, cmdG.Click, cmdH.Click, cmdI.Click, _
        cmdJ.Click, cmdK.Click, cmdL.Click, cmdM.Click, cmdN.Click, cmdO.Click, cmdP.Click, cmdQ.Click, _
        cmdR.Click, cmdS.Click, cmdT.Click, cmdU.Click, cmdV.Click, cmdW.Click, cmdX.Click, cmdY.Click, cmdZ.Click
        txtSearch.Text = CType(sender, LinkButton).Text
        tblEmp.SelectedIndex = -1
        DataRefresh(txtSearch.Text)
    End Sub
    Private Sub EnableAll(Optional ByVal pState As Boolean = False)
        cmdA.Visible = pState : cmdB.Visible = pState : cmdC.Visible = pState : cmdD.Visible = pState
        cmdE.Visible = pState : cmdF.Visible = pState : cmdG.Visible = pState : cmdH.Visible = pState
        cmdI.Visible = pState : cmdJ.Visible = pState : cmdK.Visible = pState : cmdL.Visible = pState
        cmdM.Visible = pState : cmdN.Visible = pState : cmdO.Visible = pState : cmdP.Visible = pState
        cmdQ.Visible = pState : cmdR.Visible = pState : cmdS.Visible = pState : cmdT.Visible = pState
        cmdU.Visible = pState : cmdV.Visible = pState : cmdW.Visible = pState : cmdX.Visible = pState
        cmdY.Visible = pState : cmdZ.Visible = pState
    End Sub
    Protected Sub vldDate_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles vldDate.ServerValidate
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                       ''
        '' DATE MODIFIED: 2/19/2013                           ''
        '' PURPOSE: TO CHANGE THE RETRIEVAL OF DATE FROM      ''
        ''          COMBO BOX TO TEXT BOX WITH POP-UP CALENDAR''
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '''''''''''''''''' OLD CODE ''''''''''''''''''''''''''''
        'Dim vDate As Date

        'Try
        '    vDate = cmbMonthFr.SelectedValue & "/" & cmbDayFr.SelectedValue & "/" & cmbYrFr.SelectedValue
        '    vFromDate = vDate
        'Catch ex As System.Exception
        '    args.IsValid = False
        '    Exit Sub
        'End Try
        'Try
        '    vDate = cmbMonthTo.SelectedValue & "/" & cmbDayTo.SelectedValue & "/" & cmbYrTo.SelectedValue
        '    vToDate = vDate
        'Catch ex As System.Exception
        '    args.IsValid = False
        '    Exit Sub
        'End Try
        '''''''''''''''''' END OLD CODE ''''''''''''''''''''''''
        vFromDate = txtFrom.Text
        vToDate = txtTo.Text
        '''''''''''''''''' END OF MODIFICATION '''''''''''''''''
        
        args.IsValid = True
    End Sub

    Protected Sub cmdPost_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdPost.Click
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                                 ''
        '' DATE MODIFIED: 2/19/2013                                     ''
        '' PURPOSE: TO CHANGE THE RETRIEVAL OF DATE FROM COMBO BOX TO   ''
        ''          TEXT BOX WITH POP-UP CALENDAR                       ''
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '''''''''''''''' OLD CODE ''''''''''''''''''''''''''''''''''''''''
        'Dim vDateTo As Date = CDate(cmbMonthTo.SelectedValue & "/" & cmbDayTo.SelectedValue & "/" & cmbYrTo.SelectedValue)
        'Session("startdate") = cmbMonthFr.SelectedValue & "/" & cmbDayFr.SelectedValue & "/" & cmbYrFr.SelectedValue
        '''''''''''''''' END OLD CODE ''''''''''''''''''''''''''''''''''''
        Dim vDateTo As Date = CDate(txtTo.Text)
        Session("startdate") = txtFrom.Text
        '''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''''

        Session("enddate") = vDateTo
        Session("postdate") = vDateTo
        vScript = "logwin=window.open('postsumm.aspx','logwin','location=no,toolber=no,width=550,height=500');"
    End Sub

    Protected Sub cmdEdit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdEdit.Click
        If tblEmp.SelectedIndex <> -1 And tblTime.SelectedIndex <> -1 Then    'a selection was made
            Session("empid") = tblEmp.SelectedRow.Cells(0).Text
            Session("tdate") = Format(CDate(tblTime.SelectedRow.Cells(0).Text), "yyyy/MM/dd")
            vScript = "logwin=window.open('modifylog.aspx','logwin','top=100;left=200;location=no,toolber=no,width=492,height=430;resizable=yes');"
        Else
            vScript = "alert('You must first select an employee and a Transaction log.');"
        End If
    End Sub

    Protected Sub cmdView_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdView.Click
        If tblEmp.SelectedIndex <> -1 And tblTime.SelectedIndex <> -1 Then
            Session("tdate") = tblTime.SelectedRow.Cells(0).Text
            Session("byperiod") = ""
            Session("empid") = tblEmp.SelectedRow.Cells(0).Text
            Session("empname") = tblEmp.SelectedRow.Cells(1).Text & ", " & _
                tblEmp.SelectedRow.Cells(2).Text
            vScript = "logwin=window.open('logdtl.aspx','logwin','location=no,toolber=no,width=620,height=655,resizable=yes'); logwin.focus();"
        Else
            vScript = "alert('You must first select an employee and a Transaction log.');"
        End If
    End Sub

    Protected Sub cmdDel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDel.Click
        If tblEmp.SelectedIndex <> -1 And tblTime.SelectedIndex <> -1 Then    'an employee was selected
            Dim vEmpCd As String = tblEmp.SelectedRow.Cells(0).Text
            Dim cm As New SqlClient.SqlCommand
            Dim c As New SqlClient.SqlConnection(connStr)
            Dim vDate As String = Format(CDate(tblTime.SelectedRow.Cells(0).Text), "yyyy/MM/dd")
            Dim vVal(2) As String

            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c

            vVal(0) = "Emp Id=" & vEmpCd & _
                 "|Trans. Date=" & vDate & _
                 "|Start Time=" & tblTime.SelectedRow.Cells(2).Text & _
                 "|End Time=" & tblTime.SelectedRow.Cells(3).Text & _
                 "|Actual In=" & tblTime.SelectedRow.Cells(4).Text & _
                 "|Actual Out=" & tblTime.SelectedRow.Cells(6).Text & " " & tblTime.SelectedRow.Cells(5).Text & _
                 "|Remarks=" & tblTime.SelectedRow.Cells(11).Text

            vVal(1) = "Emp Id=" & vEmpCd & _
                 "|Trans. Date=" & vDate & _
                 "|Start Time=" & tblTime.SelectedRow.Cells(2).Text & _
                 "|End Time=" & tblTime.SelectedRow.Cells(3).Text & _
                 "|Actual In=" & _
                 "|Actual Out=" & _
                 "|Remarks=" & tblTime.SelectedRow.Cells(11).Text

            EventLog(Session("uid"), Request.ServerVariables("REMOTE_ADDR"), "DELETE", _
                vVal(0), vVal(1), "Employee ID: " & vEmpCd & _
                " Time Log was deleted", "Daily Log", c)

            cm.CommandText = "delete from py_time_log where Emp_Cd='" & vEmpCd & _
                "' and Tran_Date='" & vDate & "'"
            cm.ExecuteNonQuery()
            cm.CommandText = "delete from py_time_log_dtl where Emp_Cd='" & vEmpCd & _
                "' and TranDate='" & vDate & "'"
            cm.Dispose()
            c.Close()
            c.Dispose()

            RefreshDtl()
        End If
    End Sub

    Protected Sub cmdSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSearch.Click
        Session.Remove("VFILTER")
        DataRefresh(txtSearch.Text)
    End Sub

    'Protected Sub cmdPrintSumm_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdPrintSumm.Click
    '    Session.Remove("VFILTER")
    '    Dim vStartDate As Date = CDate(cmbMonthFr.SelectedValue & "/" & cmbDayFr.SelectedValue & "/" & _
    '        cmbYrFr.SelectedValue)
    '    Dim vEndDate As Date = CDate(cmbMonthTo.SelectedValue & "/" & cmbDayTo.SelectedValue & "/" & _
    '        cmbYrTo.SelectedValue)
    '    Dim vFilter As String = ""

    '    If cmbRC.SelectedValue <> "All" Then   'filter by cost center
    '        vFilter += " and Rc_Cd='" & cmbRC.SelectedValue & "' "
    '        Session("vFilter") += GetRef("SELECT Descr FROM rc WHERE Rc_Cd = '" & cmbRC.SelectedValue & "'", cmbRC.SelectedValue) & ""
    '    Else
    '        vFilter += " and Rc_Cd in ('" & Session("rclist").ToString.Replace(",", "','") & "') "
    '    End If
    '    If cmbOfc.SelectedValue <> "All" Then        'filter by office/agency
    '        vFilter += " and Agency_Cd='" & cmbOfc.SelectedValue & "' "
    '        Session("VFILTER") += GetRef("SELECT AgencyName FROM agency WHERE AgencyCd = '" & cmbOfc.SelectedValue & "'", cmbOfc.SelectedValue) & ", "
    '    Else
    '        vFilter += " and Agency_Cd in ('" & Session("agencylist").ToString.Replace(",", "','") & "') "
    '    End If
    '    If cmbDiv.SelectedValue <> "All" Then      'filter by division
    '        vFilter += " and Divcd='" & cmbDiv.SelectedValue & "' "
    '        Session("VFILTER") += GetRef("SELECT Descr FROM hr_div_ref WHERE Div_Cd = '" & cmbDiv.SelectedValue & "'", cmbDiv.SelectedValue) & ", "
    '    Else
    '        vFilter += " and DivCd in ('" & Session("divlist").ToString.Replace(",", "','") & "') "
    '    End If
    '    If cmbDept.SelectedValue <> "All" Then  'filter by departments
    '        vFilter += " and DeptCd='" & cmbDept.SelectedValue & "' "
    '        Session("VFILTER") += GetRef("SELECT Descr FROM hr_dept_ref WHERE Dept_Cd = '" & cmbDept.SelectedValue & "'", cmbDept.SelectedValue) & ", "
    '    Else
    '        vFilter += " and DeptCd in ('" & Session("deptlist").ToString.Replace(",", "','") & "') "
    '    End If
    '    If cmbSection.SelectedValue <> "All" Then 'filter by section
    '        vFilter += " and SectionCd='" & cmbSection.SelectedValue & "' "
    '        Session("VFILTER") += GetRef("SELECT Descr FROM hr_section_ref WHERE Section_Cd = '" & cmbSection.SelectedValue & "'", cmbSection.SelectedValue) & ", "
    '    Else
    '        vFilter += " and SectionCd in ('" & Session("sectionlist").ToString.Replace(",", "','") & "') "
    '    End If
    '    If cmbUnit.SelectedValue <> "All" Then  'filter by units
    '        vFilter += " and UnitCd='" & cmbUnit.SelectedValue & "' "
    '        Session("VFILTER") += GetRef("SELECT Descr FROM hr_unit_ref WHERE Unit_Cd = '" & cmbUnit.SelectedValue & "'", cmbUnit.SelectedValue) & ", "
    '    Else
    '        vFilter += " and UnitCd in ('" & Session("unitlist").ToString.Replace(",", "','") & "') "
    '    End If

    '    Dim vRanklist As String = ""
    '    For i As Integer = 0 To chkRank.Items.Count - 1
    '        If chkRank.Items(i).Selected Then
    '            vRanklist += chkRank.Items(i).Text & ","
    '        End If
    '    Next
    '    vFilter += " and EmploymentType in ('" & vRanklist.Replace(",", "','") & "') "

    '    Session("startdate") = Format(vStartDate, "yyyy/MM/dd")
    '    Session("enddate") = Format(vEndDate, "yyyy/MM/dd")
    '    Session("filter") = vFilter
    '    If Session("VFILTER") <> "" Then
    '        Session("VFILTER") = Session("VFILTER").ToString.Substring(0, Session("VFILTER").ToString.Length - 2)
    '    End If

    '    vScript = "win=window.open('printsumm.aspx','win','toolbar=no,scrollbars=yes,width=1020,height=700,top=30,left=0');"
    'End Sub

    Protected Sub cmdPrint_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdPrint.Click
        
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                                 ''
        '' DATE MODIFID: 2/19/2013                                      ''
        '' PURPOSE: TO CHANGE THE RETRIEVAL OF DATE FROM COMBO BOX TO   ''
        ''          TO TEXT BOX WITH POP-UP CALENDAR                    ''
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '''''''''''''''''' OLD CODE ''''''''''''''''''''''''''''''''''''''
        'Dim vStartDate As Date = CDate(cmbMonthFr.SelectedValue & "/" & cmbDayFr.SelectedValue & "/" & _
        '    cmbYrFr.SelectedValue)
        'Dim vEndDate As Date = CDate(cmbMonthTo.SelectedValue & "/" & cmbDayTo.SelectedValue & "/" & _
        '    cmbYrTo.SelectedValue)
        '''''''''''''''''' END OLD CODE ''''''''''''''''''''''''''''''''''
        Dim vStartDate As Date = CDate(txtFrom.Text)
        Dim vEndDate As Date = CDate(txtTo.Text)
        '''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''

        Session("startdate") = Format(vStartDate, "yyyy/MM/dd")
        Session("enddate") = Format(vEndDate, "yyyy/MM/dd")
        If Me.txtStatus.Value = "0" Then 'specific
            If tblEmp.SelectedIndex > -1 Then
                Session("id") = tblEmp.SelectedRow.Cells(0).Text
                vScript = "javascript:win=window.open('dtr.aspx','win','toolbar=no,scrollbars=yes,width=950,height=600,top=100,left=100'); win.focus();"
            Else
                vScript = "alert('You must first select an employee!.');"
            End If
        Else
            vScript = "javascript:alert('To ensure accurate results, we advise you to click the Recalculate button first prior to printing the DTR. Click the OK button to continue the printing of DTR.');win=window.open('dtr.aspx','win','toolbar=no,scrollbars=yes,width=950,height=600,top=100,left=100'); win.focus();"
        End If
    End Sub

    Protected Sub tblTime_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tblTime.SelectedIndexChanged
        If tblEmp.SelectedIndex < 0 Then
            vScript = "alert('You must first select an employee.');"
            Exit Sub
        End If
        vOtDtl = ""

        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cmRef As New SqlClient.SqlCommand
        Dim rsRef As SqlClient.SqlDataReader
        Dim rs As SqlClient.SqlDataReader
        Dim vDescr As String = ""
        Dim vFactor As Decimal = 0
        Dim vRank As String = ""

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            cmRef.Dispose()
            Exit Sub
        End Try

        cm.Connection = c
        cmRef.Connection = c
        cm.CommandText = "select * from py_time_log_dtl where Emp_Cd='" & _
            tblEmp.SelectedRow.Cells(0).Text & "' and TranDate='" & _
            Format(CDate(tblTime.SelectedRow.Cells(0).Text), "yyyy/MM/dd") & "' AND LateFiled=0"

        Try
            rs = cm.ExecuteReader
            Do While rs.Read
                cmRef.CommandText = "select Descr,OtPer from py_ot_ref where OtCd='" & _
                    rs("TranCd") & "'"
                rsRef = cmRef.ExecuteReader
                vDescr = "UNKNOWN!!"
                vFactor = 0
                If rsRef.Read Then
                    vDescr = rsRef("Descr")
                    vFactor = IIf(IsDBNull(rsRef("OtPer")), 0, rsRef("OtPer"))
                End If
                rsRef.Close()

                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY:  VIC GATCHALIAN                                   ''
                '' DATE MODIFIED: 4/26/2012                                       ''
                '' PURPOSE: TO CHECK IF THERE ARE ANY CUSTOM FACTOR RATE FOR EACH ''
                ''          CODE OF THE RANK OF THE EMPLOYEE                      ''
                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                'GET RANK OF THE EMPLOYEE
                cmRef.CommandText = "select EmploymentType from py_emp_master where Emp_Cd='" & _
                    tblEmp.SelectedRow.Cells(0).Text & "'"
                rsRef = cmRef.ExecuteReader
                If rsRef.Read Then
                    vRank = rsRef("EmploymentType")
                End If
                rsRef.Close()

                cmRef.CommandText = "select Factor,Uom from py_ot_ref_dtl where EmploymentType='" & _
                    vRank & "' and OtCd='" & rs("TranCd") & "'"
                rsRef = cmRef.ExecuteReader
                If rsRef.Read Then
                    vFactor = IIf(IsDBNull(rsRef("Factor")), vFactor, rsRef("Factor"))
                End If
                rsRef.Close()
                '''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''

                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY: VIC GATCHALIAN                                      ''
                '' DATE MODIFIED: 2/11/2013                                         ''
                '' PURPOSE: TO HIDE THE DISPLAY OF CONVERTED AMOUNT                 ''
                '' EXCEPTION: FOR RICHMONDE USE ONLY                                ''
                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                ''''''''''''''''''' OLD CODE '''''''''''''''''''''''''''''''''''''''''
                vOtDtl += "<tr class='" & vClass & "'>" & _
                    "<td>" & rs("TranCd") & "</td>" & _
                    "<td>" & vDescr & "</td>" & _
                    "<td>" & vFactor & "</td>" & _
                    "<td>" & Math.Round(rs("Hrs_Rendered"), 2) & "</td>" & _
                    "<td>" & Format(Math.Round(rs("AmtConv"), 2), "###,##0.00") & "</td>" & _
                    "<td>" & rs("LateFiled") & "</td>" & _
                    "<td>" & rs("Reason") & "</tr>"
                ''''''''''''''''''' END OLD CODE '''''''''''''''''''''''''''''''''''''
                'vOtDtl += "<tr class='" & vClass & "'>" & _
                '    "<td>" & rs("TranCd") & "</td>" & _
                '    "<td>" & vDescr & "</td>" & _
                '    "<td>" & vFactor & "</td>" & _
                '    "<td>" & Math.Round(rs("Hrs_Rendered"), 2) & "</td>" & _
                '    "<td>&nbsp;</td>" & _
                '    "<td>" & rs("LateFiled") & "</td>" & _
                '    "<td>" & rs("Reason") & "</tr>"
                ''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''''''

                If vClass = "odd" Then
                    vClass = "even"
                Else
                    vClass = "odd"
                End If
            Loop
            rs.Close()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to retrieve Log Detail. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            cm.Dispose()
            cmRef.Dispose()
            c.Close()
            c.Dispose()
        End Try
    End Sub
    Private Sub Old_DownloadDTR()
        If Page.IsValid Then
            Dim vFilter As String = ""
            Dim c As New SqlClient.SqlConnection(connStr)
            Dim cm As New SqlClient.SqlCommand
            Dim rs As SqlClient.SqlDataReader
            Dim vDump As String = ""

            If Me.txtStatus.Value = "0" Then 'specific
                If tblEmp.SelectedIndex > -1 Then
                    vFilter = " and Emp_Cd='" & tblEmp.SelectedRow.Cells(0).Text & "' "
                Else
                    vScript = "alert('You must first select an employee!.');"
                End If
            Else
                vFilter = " and Emp_Cd in ('" & Session("id") & "') "
            End If

            c.Open()
            cm.Connection = c
            cm.CommandText = "select * from py_time_log where Tran_Date between '" & _
                Format(vFromDate, "yyyy/MM/dd") & "' and '" & Format(vToDate, "yyyy/MM/dd") & _
                "' " & vFilter
            rs = cm.ExecuteReader

            Do While rs.Read
                If Not IsDBNull(rs("Time_In")) Then
                    vDump += rs("Emp_Cd") & " " & Format(CDate(rs("Tran_Date")), "yyyyMMdd") & " " & _
                        rs("Time_In").ToString.Replace(":", "").Substring(0, 4) & " 1" & _
                        "           " & vbCrLf
                End If
                If Not IsDBNull(rs("Time_Out")) Then    'with log out
                    vDump += rs("Emp_Cd") & " " & Format(CDate(rs("Time_OutDate")), "yyyyMMdd") & " " & _
                        rs("Time_Out").ToString.Replace(":", "").Substring(0, 4) & " 2" & _
                        "           " & vbCrLf
                End If
            Loop
            rs.Close()
            cm.Dispose()
            c.Close()
            c.Dispose()

            IO.File.WriteAllText(Server.MapPath(".") & "\downloads\" & Session("sessionid") & "-dtr.txt", vDump)
            vScript = "javascript:dtrwin=window.open('downloads/" & Session("sessionid") & _
                "-dtr.txt','dtrwin','toolbar=no,scrollbar=no,width=850,height=600,top=100,left=100'); dtrwin.focus();"
        Else
            vScript = "alert('An error occurred while tyring to execute your request. Please contact your administrator.');"
        End If
    End Sub
    Protected Sub cmdDownload_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDownload.Click
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim vFilter As String = ""
        Dim vDump As New StringBuilder

        'vFilter = vXFilter
        If IO.File.Exists(Server.MapPath(".") & "/downloads/" & Session.SessionID & "-dtr.csv") Then
            Try
                IO.File.Delete(Server.MapPath(".") & "/downloads/" & Session.SessionID & "-dtr.csv")
            Catch ex As IO.IOException
                vScript = "alert('Error occurred while trying to delete temporary dump file. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                Exit Sub
            End Try
        End If
        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        cm.Connection = c

        'get system values
        cm.CommandText = "select AcaMinHrs,RataMinHrs,PeraMinHrs,MealMinHrs from py_syscntrl"
        Try
            rs = cm.ExecuteReader
            If rs.Read Then
                vAcaMinHrs = rs("AcaMinHrs")
                vRataMinHrs = rs("RataMinHrs")
                vPeraMinHrs = rs("PeraMinHrs")
                vMealMinHrs = rs("MealMinHrs")
            End If
            rs.Close()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to retrieve System settings. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Close()
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        If txtStatus.Value = "0" Then       'specific employee only
            If tblEmp.SelectedIndex > -1 And tblEmp.SelectedIndex <= tblEmp.Rows.Count Then
                vFilter = " and Emp_Cd='" & tblEmp.SelectedRow.Cells(0).Text & "' "
                GetDTR(vFilter, c)
            Else
                vScript = "alert('You must first select an employee.');"
            End If
        Else                                'all employees
            If txtByDept.Value = "1" Then   'sorted by dept, by employees

                If cmbDept.SelectedValue <> "All" Then  'filter by departments
                    vFilter = " where Dept_Cd='" & cmbDept.SelectedValue & "' "
                End If
                cm.CommandText = "select Dept_Cd,Descr from hr_dept_ref " & vFilter
                Try
                    rs = cm.ExecuteReader

                    Do While rs.Read
                        'enter here.. the selected filters
                        vFilter = " and Emp_Cd in ('" & Session("id") & "') "
                        vFilter += " and Emp_Cd in (select Emp_Cd from py_emp_master where DeptCd='" & rs("Dept_Cd") & "') "
                        GetDTR(vFilter, c, rs("Dept_Cd") & "=>" & rs("Descr"))
                    Loop
                    rs.Close()
                Catch ex As SqlClient.SqlException
                    vScript = "alert('Error occurred while trying to retrieve records. Error is: " & _
                        ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                    c.Close()
                    c.Dispose()
                    cm.Dispose()
                    Exit Sub
                End Try
            Else                            'sorted by employees
                vFilter = " and Emp_Cd in ('" & Session("id") & "') "
                GetDTR(vFilter, c)
            End If
        End If

        vScript = "alert('Download complete.'); window.open('downloads/" & _
            Session.SessionID & "-dtr.csv');"
        c.Close()
        c.Dispose()
        cm.Dispose()
    End Sub
    Private Sub GetDTR(ByVal pCond As String, ByRef c As SqlClient.SqlConnection, Optional ByVal pDept As String = "")
        Dim cm As New SqlClient.SqlCommand
        Dim cmRef As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim rsRef As SqlClient.SqlDataReader

        Dim vStr As String = ""
        Dim vOldName As String = ""
        Dim vName As String = ""
        Dim vDump As New StringBuilder
        Dim vSchedIn As String = ""
        Dim vSchedOut As String = ""
        Dim vTimeIn As String = ""
        Dim vTimeOut As String = ""

        Dim vRegHrs As Decimal = 0
        Dim vExcess As Decimal = 0
        Dim vAbsent As Decimal = 0
        Dim vTardy As Decimal = 0
        Dim vUT As Decimal = 0
        Dim vOT As OT
        Dim vApprovedOT As Decimal = 0
        Dim vMeal As Decimal = 0
        Dim vTranspo As Decimal = 0

        Dim vMealStartTime As Date = Nothing
        Dim vMealEndTime As Date = Nothing
        Dim vTranspoStartTime As Date = Nothing
        Dim vTranspoEndTime As Date = Nothing

        Dim vTotOT As OT
        Dim vTotRegHrs As Decimal = 0
        Dim vActualHrs As Decimal = 0
        Dim vTotExcess As Decimal = 0
        Dim vTotAbsent As Decimal = 0
        Dim vTotTardy As Decimal = 0
        Dim vTotUT As Decimal = 0
        Dim vTotMeal As Decimal = 0
        Dim vTotTranspo As Decimal = 0
        Dim vDOW() As String = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"}
        Dim vRemarks As String = ""
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY: VIC GATCHALIAN                                 ''
        '' DATE MODIFIED: 11/10/2011                                   ''
        '' PURPOSE:  TO EXCLUDE THE TRANSPO ALLOWANCE ELIGIBLITY       ''
        ''           WHEN EMPLOYEE IS ON LEAVE (EITHER PAID OR NOT)    ''
        '' EXCEPTION: FOR DSM USE ONLY                                 ''
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        Dim vWithLeave As Boolean = False
        ''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''''''

        cm.Connection = c
        cmRef.Connection = c

        'initialize total variables to zero
        vTotOT.A1 = 0 : vTotOT.A2A3 = 0 : vTotOT.A4 = 0
        vTotOT.B1 = 0 : vTotOT.B2 = 0 : vTotOT.B3 = 0 : vTotOT.B4 = 0
        vTotOT.C1 = 0 : vTotOT.C2 = 0 : vTotOT.C3 = 0 : vTotOT.C4 = 0
        vTotOT.D1 = 0 : vTotOT.D2 = 0 : vTotOT.D3 = 0 : vTotOT.D4 = 0
        vTotOT.E1 = 0 : vTotOT.E2 = 0 : vTotOT.E3 = 0 : vTotOT.E4 = 0
        vTotOT.F1 = 0 : vTotOT.F2 = 0 : vTotOT.F3 = 0 : vTotOT.F4 = 0

        Try
            If pDept <> "" Then
                vStr = "Department: " & pDept
                vDump.AppendLine(vStr)
            End If
            '''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:  VIC GATCHALIAN            ''
            '' DATE MODIFIED: 7/30/2012                ''
            '' PURPOSE: TO CHANGE THE LABEL OF ABSENT  ''
            ''          COLUMN FROM "DAYS" TO "HOURS"  ''
            '''''''''''''''''''''''''''''''''''''''''''''
            ''''''''' OLD CODE ''''''''''''''''''''''''''
            'vStr = "Employee Id,Employee Name,Date,DOW,Sched In,Sched Out,Time In,Time Out,Actual Hrs,Excess," & _
            '    "Absent (in days),Tardy,U/T,Reg OT,Reg ND,Reg OT w/ ND," & "RD,RD (Exs8),RDND,RDND (Exs8)," & _
            '    "SH,SH (Exs8),SHND,SHND (Exs8),LH,LH (Exs8),LHND,LHND (Exs8)," & _
            '    "SHRD,SHRD (Exs8),SHRDND,SHRDND (Exs8),LHRD,LHRD (Exs8),LHRDND,LHRDND (Exs8),Transpo,Meal,Remarks"
            ''''''''' END OLD CODE ''''''''''''''''''''''
            vStr = "Employee Id,Employee Name,Date,DOW,Sched In,Sched Out,Time In,Time Out,Actual Hrs,Excess," & _
                "Absences,Tardy,U/T,Reg OT,Reg ND,Reg OT w/ ND," & "RD,RD (Exs8),RDND,RDND (Exs8)," & _
                "SH,SH (Exs8),SHND,SHND (Exs8),LH,LH (Exs8),LHND,LHND (Exs8)," & _
                "SHRD,SHRD (Exs8),SHRDND,SHRDND (Exs8),LHRD,LHRD (Exs8),LHRDND,LHRDND (Exs8),Transpo,Meal,Remarks"
            ''''''''' END OF MODIFICATION '''''''''''''''
            vDump.AppendLine(vStr)

            cm.CommandText = "select Meal_StartTime,Meal_EndTime,Rata_StartTime,Rata_EndTime from py_syscntrl"
            rs = cm.ExecuteReader
            If rs.Read Then
                If IsDBNull(rs("Meal_StartTime")) Then
                    vMealStartTime = CDate("00:00:00")
                Else
                    vMealStartTime = CDate(rs("Meal_StartTime"))
                End If
                If IsDBNull(rs("Meal_EndTime")) Then
                    vMealEndTime = CDate("23:59:59")
                Else
                    vMealEndTime = CDate(rs("Meal_EndTime"))
                End If
                If IsDBNull(rs("Rata_StartTime")) Then
                    vTranspoStartTime = CDate("00:00:00")
                Else
                    vTranspoStartTime = CDate(rs("Rata_StartTime"))
                End If
                If IsDBNull(rs("Rata_EndTime")) Then
                    vTranspoEndTime = CDate("00:00:00")
                Else
                    vTranspoEndTime = CDate(rs("Rata_EndTime"))
                End If
            End If
            rs.Close()

            cm.CommandText = "select Tran_Date,Sched_In,Sched_Out,Time_In,Time_Out,Time_OutDate,Emp_Cd, " & _
                "(select Emp_Lname+', '+Emp_Fname from py_emp_master where py_emp_master.Emp_Cd=py_time_log.Emp_Cd) as Name " & _
                "from py_time_log where Tran_Date between '" & _
                Format(vFromDate, "yyyy/MM/dd") & "' and '" & Format(vToDate, "yyyy/MM/dd") & _
                "' " & pCond & " order by Name"

            rs = cm.ExecuteReader
            Do While rs.Read
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY: VIC GATCHALIAN                                 ''
                '' DATE MODIFIED: 11/10/2011                                   ''
                '' PURPOSE:  TO EXCLUDE THE TRANSPO ALLOWANCE ELIGIBLITY       ''
                ''           WHEN EMPLOYEE IS ON LEAVE (EITHER PAID OR NOT)    ''
                '' EXCEPTION: FOR DSM USE ONLY                                 ''
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                'check if there's a filed leave application '''''''''''''''''''''
                vWithLeave = False
                ''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''' 

                vName = "Unknown Name"
                If Not IsDBNull(rs("Name")) Then
                    vName = rs("Name")
                End If

                'get approved ot hours
                cmRef.CommandText = "select DaysLeave from hr_leave_application where Emp_Cd='" & _
                    rs("Emp_Cd") & "' and StartDate between '" & Format(CDate(rs("Tran_Date")), "yyyy/MM/dd 00:00:00") & _
                    "' and '" & Format(CDate(rs("Tran_Date")), "yyyy/MM/dd 23:59:59") & "'"
                rsRef = cmRef.ExecuteReader
                vApprovedOT = 0
                If rsRef.Read Then
                    vApprovedOT = rsRef("DaysLeave")
                End If
                rsRef.Close()

                'get emploeyee's meal and transpo allowance
                cmRef.CommandText = "select RATA,MealAllow from py_emp_master where Emp_Cd='" & _
                    rs("Emp_Cd") & "'"
                rsRef = cmRef.ExecuteReader
                vMeal = 0
                vTranspo = 0
                If rsRef.Read Then
                    If Not IsDBNull(rsRef("MealAllow")) Then vMeal = rsRef("MealAllow")
                    If Not IsDBNull(rsRef("Rata")) Then vTranspo = rsRef("Rata")
                End If
                rsRef.Close()

                If vOldName = "" Then vOldName = vName

                If vOldName <> vName Then   'end of employee list, dump total
                    vStr = ",,,,,,,TOTAL=>," & _
                        IIf(vTotRegHrs = 0, "", Math.Round(vTotRegHrs, 2)) & "," & _
                        IIf(vTotExcess = 0, "", Math.Round(vTotExcess, 2)) & "," & _
                        IIf(vTotAbsent = 0, "", Math.Round(vTotAbsent, 2)) & "," & _
                        IIf(vTotTardy = 0, "", Math.Round(vTotTardy, 2)) & "," & _
                        IIf(vTotUT = 0, "", Math.Round(vTotUT, 2)) & "," & _
                        IIf(vTotOT.A1 = 0, "", Math.Round(vTotOT.A1, 2)) & "," & _
                        IIf(vTotOT.A4 = 0, "", Math.Round(vTotOT.A4, 2)) & "," & _
                        IIf(vTotOT.A2A3 = 0, "", Math.Round(vTotOT.A2A3, 2)) & "," & _
                        IIf(vTotOT.E1 = 0, "", Math.Round(vTotOT.E1, 2)) & "," & _
                        IIf(vTotOT.E3 = 0, "", Math.Round(vTotOT.E3, 2)) & "," & _
                        IIf(vTotOT.E2 = 0, "", Math.Round(vTotOT.E2, 2)) & "," & _
                        IIf(vTotOT.E4 = 0, "", Math.Round(vTotOT.E4, 2)) & "," & _
                        IIf(vTotOT.F1 = 0, "", Math.Round(vTotOT.F1, 2)) & "," & _
                        IIf(vTotOT.F3 = 0, "", Math.Round(vTotOT.F3, 2)) & "," & _
                        IIf(vTotOT.F2 = 0, "", Math.Round(vTotOT.F2, 2)) & "," & _
                        IIf(vTotOT.F4 = 0, "", Math.Round(vTotOT.F4, 2)) & "," & _
                        IIf(vTotOT.C1 = 0, "", Math.Round(vTotOT.C1, 2)) & "," & _
                        IIf(vTotOT.C3 = 0, "", Math.Round(vTotOT.C3, 2)) & "," & _
                        IIf(vTotOT.C2 = 0, "", Math.Round(vTotOT.C2, 2)) & "," & _
                        IIf(vTotOT.C4 = 0, "", Math.Round(vTotOT.C4, 2)) & "," & _
                        IIf(vTotOT.B1 = 0, "", Math.Round(vTotOT.B1, 2)) & "," & _
                        IIf(vTotOT.B3 = 0, "", Math.Round(vTotOT.B3, 2)) & "," & _
                        IIf(vTotOT.B2 = 0, "", Math.Round(vTotOT.B2, 2)) & "," & _
                        IIf(vTotOT.B4 = 0, "", Math.Round(vTotOT.B4, 2)) & "," & _
                        IIf(vTotOT.D1 = 0, "", Math.Round(vTotOT.D1, 2)) & "," & _
                        IIf(vTotOT.D3 = 0, "", Math.Round(vTotOT.D3, 2)) & "," & _
                        IIf(vTotOT.D2 = 0, "", Math.Round(vTotOT.D2, 2)) & "," & _
                        IIf(vTotOT.D4 = 0, "", Math.Round(vTotOT.D4, 2)) & "," & _
                        IIf(vTotTranspo = 0, "", Math.Round(vTotTranspo, 2)) & "," & _
                        IIf(vTotMeal = 0, "", Math.Round(vTotMeal, 2)) & ","
                    vDump.AppendLine(vStr)

                    'initialize total variables to zero
                    vTotRegHrs = 0 : vTotExcess = 0 : vTotAbsent = 0
                    vTotTardy = 0 : vTotUT = 0 : vTotMeal = 0 : vTotTranspo = 0
                    vTotOT.A1 = 0 : vTotOT.A2A3 = 0 : vTotOT.A4 = 0
                    vTotOT.B1 = 0 : vTotOT.B2 = 0 : vTotOT.B3 = 0 : vTotOT.B4 = 0
                    vTotOT.C1 = 0 : vTotOT.C2 = 0 : vTotOT.C3 = 0 : vTotOT.C4 = 0
                    vTotOT.D1 = 0 : vTotOT.D2 = 0 : vTotOT.D3 = 0 : vTotOT.D4 = 0
                    vTotOT.E1 = 0 : vTotOT.E2 = 0 : vTotOT.E3 = 0 : vTotOT.E4 = 0
                    vTotOT.F1 = 0 : vTotOT.F2 = 0 : vTotOT.F3 = 0 : vTotOT.F4 = 0
                    vOldName = vName
                End If

                vSchedIn = ""
                vSchedOut = ""
                vTimeIn = ""
                vTimeOut = ""

                If Not IsDBNull(rs("Sched_In")) And IsDate(rs("Sched_In")) Then
                    vSchedIn = Format(CDate(rs("Tran_Date")), "MM/dd/yyyy") & " " & Format(CDate(rs("Sched_In")), "hh:mm tt")
                End If
                If Not IsDBNull(rs("Sched_Out")) And IsDate(rs("Sched_Out")) Then
                    vSchedOut = Format(CDate(rs("Sched_Out")), "MM/dd/yyyy hh:mm tt")
                End If
                If Not IsDBNull(rs("Time_In")) Then
                    vTimeIn = Format(CDate(rs("Time_In")), "hh:mm tt")
                End If
                If Not IsDBNull(rs("Time_OutDate")) And Not IsDBNull(rs("Time_Out")) Then
                    vTimeOut = Format(rs("Time_OutDate"), "MM/dd/yyyy") & " " & Format(CDate(rs("Time_Out")), "hh:mm tt")
                End If

                'initialize to zero
                vAbsent = 0 : vTardy = 0 : vUT = 0
                vOT.A1 = 0 : vOT.A2A3 = 0 : vOT.A4 = 0
                vOT.B1 = 0 : vOT.B2 = 0 : vOT.B3 = 0 : vOT.B4 = 0
                vOT.C1 = 0 : vOT.C2 = 0 : vOT.C3 = 0 : vOT.C4 = 0
                vOT.D1 = 0 : vOT.D2 = 0 : vOT.D3 = 0 : vOT.D4 = 0
                vOT.E1 = 0 : vOT.E2 = 0 : vOT.E3 = 0 : vOT.E4 = 0
                vOT.F1 = 0 : vOT.F2 = 0 : vOT.F3 = 0 : vOT.F4 = 0
                vRemarks = ""

                cmRef.CommandText = "select TranCd,Hrs_Rendered from py_time_log_dtl where Emp_Cd='" & _
                    rs("Emp_Cd") & "' and TranDate='" & Format(rs("Tran_Date"), "yyyy/MM/dd") & "'"
                rsRef = cmRef.ExecuteReader

                Do While rsRef.Read
                    Select Case rsRef("TranCd")
                        Case "ABSENT"
                            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                            '' MODIFIED BY:  VIC GATCHALIAN                              ''
                            '' DATE MODIFIED: 7/30/2012                                  ''
                            '' PURPOSE: TO CONVERT BACK TO HOURS                         ''
                            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                            ''''''''''''''''''''' OLD CODE ''''''''''''''''''''''''''''''''
                            'vAbsent = rsRef("Hrs_Rendered") / 8 'convert it in days
                            ''''''''''''''''''''' END OLD CODE ''''''''''''''''''''''''''''
                            vAbsent = rsRef("Hrs_Rendered")
                            ''''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''
                        Case "TARD"
                            vTardy = rsRef("Hrs_Rendered")
                        Case "UT"
                            vUT = rsRef("Hrs_Rendered")
                        Case "A1"
                            vOT.A1 = rsRef("Hrs_Rendered")
                        Case "A4"
                            vOT.A4 = rsRef("Hrs_Rendered")
                        Case "A2", "A3"
                            vOT.A2A3 = rsRef("Hrs_Rendered")
                        Case "B1"
                            vOT.B1 = rsRef("Hrs_Rendered")
                        Case "B2"
                            vOT.B2 = rsRef("Hrs_Rendered")
                        Case "B3"
                            vOT.B3 = rsRef("Hrs_Rendered")
                        Case "B4"
                            vOT.B4 = rsRef("Hrs_Rendered")
                        Case "C1"
                            vOT.C1 = rsRef("Hrs_Rendered")
                        Case "C2"
                            vOT.C2 = rsRef("Hrs_Rendered")
                        Case "C3"
                            vOT.C3 = rsRef("Hrs_Rendered")
                        Case "C4"
                            vOT.C4 = rsRef("Hrs_Rendered")
                        Case "D1"
                            vOT.D1 = rsRef("Hrs_Rendered")
                        Case "D2"
                            vOT.D2 = rsRef("Hrs_Rendered")
                        Case "D3"
                            vOT.D3 = rsRef("Hrs_Rendered")
                        Case "D4"
                            vOT.D4 = rsRef("Hrs_Rendered")
                        Case "E1"
                            vOT.E1 = rsRef("Hrs_Rendered")
                        Case "E2"
                            vOT.E2 = rsRef("Hrs_Rendered")
                        Case "E3"
                            vOT.E3 = rsRef("Hrs_Rendered")
                        Case "E4"
                            vOT.E4 = rsRef("Hrs_Rendered")
                        Case "F1"
                            vOT.F1 = rsRef("Hrs_Rendered")
                        Case "F2"
                            vOT.F2 = rsRef("Hrs_Rendered")
                        Case "F3"
                            vOT.F3 = rsRef("Hrs_Rendered")
                        Case "F4"
                            vOT.F4 = rsRef("Hrs_Rendered")
                        Case Else
                            If rsRef("TranCd") <> "BASIC" Then
                                vRemarks += rsRef("TranCd") & "=" & rsRef("Hrs_Rendered") & ";"
                                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                                '' MODIFIED BY: VIC GATCHALIAN                                 ''
                                '' DATE MODIFIED: 11/10/2011                                   ''
                                '' PURPOSE:  TO EXCLUDE THE TRANSPO ALLOWANCE ELIGIBLITY       ''
                                ''           WHEN EMPLOYEE IS ON LEAVE (EITHER PAID OR NOT)    ''
                                '' EXCEPTION: FOR DSM USE ONLY                                 ''
                                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                                'check if there's a filed leave application '''''''''''''''''''''
                                vWithLeave = True
                                ''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''' 
                            End If
                    End Select
                Loop
                rsRef.Close()

                vRegHrs = 0
                If vSchedIn <> "" And vSchedOut <> "" Then
                    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                    '' MODIFIED BY:  VIC GATCHALIAN                                ''
                    '' DATE MODIFIED:  10/18/2011                                  ''
                    '' PURPOSE: CONVERTS THE INTERVAL FROM HOURS TO MINUTES TO     ''
                    ''          AND CONVERTS IT BACK TO HOURS TO PRODUCE DECIMAL   ''
                    ''          VALUES.                                            ''
                    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                    ''''''''''''' ORIGINAL CODE '''''''''''''''''''''''''''''''''''''
                    'vRegHrs = DateDiff(DateInterval.Hour, CDate(vSchedIn), CDate(vSchedOut))
                    ''''''''''''' END ORIGINAL CODE '''''''''''''''''''''''''''''''''
                    vRegHrs = DateDiff(DateInterval.Minute, CDate(vSchedIn), CDate(vSchedOut))
                    ''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''''''
                End If
                vActualHrs = 0
                If vTimeIn <> "" And vTimeOut <> "" Then
                    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                    '' MODIFIED BY:  VIC GATCHALIAN                                ''
                    '' DATE MODIFIED:  10/18/2011                                  ''
                    '' PURPOSE: CONVERTS THE INTERVAL FROM HOURS TO MINUTES TO     ''
                    ''          AND CONVERTS IT BACK TO HOURS TO PRODUCE DECIMAL   ''
                    ''          VALUES.                                            ''
                    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                    ''''''''''''' ORIGINAL CODE '''''''''''''''''''''''''''''''''''''
                    'vActualHrs = DateDiff(DateInterval.Hour, CDate(Format(CDate(rs("Tran_Date")), "MM/dd/yyyy") & " " & vTimeIn), _
                    'CDate(vTimeOut))
                    ''''''''''''' END ORIGINAL CODE '''''''''''''''''''''''''''''''''
                    vActualHrs = DateDiff(DateInterval.Minute, CDate(Format(CDate(rs("Tran_Date")), "MM/dd/yyyy") & " " & vTimeIn), _
                        CDate(vTimeOut))
                    ''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''''''
                End If

                vExcess = 0
                If vActualHrs > vRegHrs Then vExcess = vActualHrs - vRegHrs
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY:  VIC GATCHALIAN                                    ''
                '' DATE MODIFIED: 10/18/2011                                       ''
                '' PURPOSE:  CONVERTS THE CALCULATED EXCESS MINUTES TO HOURS       ''
                ''           AND ROUNDS OFF TO THE NEAREST TENTHS                  ''
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                vExcess = Math.Round(vExcess / 60, 2)
                vActualHrs = Math.Round(vActualHrs / 60, 2)
                vRegHrs = Math.Round(vRegHrs / 60, 2)
                ''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''''
                If vSchedIn <> "" Then
                    Dim vSI As Date
                    Dim vSO As Date
                    vSI = CDate(CDate(vSchedIn).Hour & ":" & CDate(vSchedIn).Minute & ":" & CDate(vSchedIn).Second)
                    vSO = CDate(CDate(vSchedOut).Hour & ":" & CDate(vSchedOut).Minute & ":" & CDate(vSchedOut).Second)

                    If (vSI >= vTranspoStartTime And vSO >= vTranspoEndTime) Or _
                       (vSI <= vTranspoStartTime And vSO <= vTranspoEndTime) Or _
                       (vSI >= vTranspoStartTime And vSO <= vTranspoEndTime) Or _
                       (vSI <= vTranspoStartTime And vSO >= vTranspoEndTime) Then
                        If vActualHrs < vRataMinHrs Then vTranspo = 0
                    Else
                        vTranspo = 0
                    End If

                    If (vSI >= vMealStartTime And vSO >= vMealEndTime) Or _
                       (vSI <= vMealStartTime And vSO <= vMealEndTime) Or _
                       (vSI >= vMealStartTime And vSO <= vMealEndTime) Or _
                       (vSI <= vMealStartTime And vSO >= vMealEndTime) Then
                        If vApprovedOT < vMealMinHrs Then vMeal = 0
                    Else
                        vMeal = 0
                    End If
                Else
                    vTranspo = 0
                    vMeal = 0
                End If

                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY: VIC GATCHALIAN                                 ''
                '' DATE MODIFIED: 11/10/2011                                   ''
                '' PURPOSE:  TO EXCLUDE THE TRANSPO ALLOWANCE ELIGIBLITY       ''
                ''           WHEN EMPLOYEE IS ON LEAVE (EITHER PAID OR NOT)    ''
                '' EXCEPTION: FOR DSM USE ONLY                                 ''
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                'check if there's a filed leave application '''''''''''''''''''''
                If vWithLeave Then vTranspo = 0
                ''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''' 


                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY:  VIC GATCHALIAN                                   ''
                '' DATE MODIFIED: 10/18/2011                                      ''
                '' PURPOSE: TO REFLECT THE ACTUAL HOURS RENDERED INSTEAD OF THE   ''
                ''          SCHEDULED REGULAR HOURS                               ''
                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '''''   ORIGINAL CODE ''''''''''''''''''''''''''''''''''''''''''''''
                'vTotRegHrs += vRegHrs
                '''''   END ORIGINAL CODE ''''''''''''''''''''''''''''''''''''''''''
                vTotRegHrs += vActualHrs
                ''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''''
                vTotExcess += vExcess : vTotAbsent += vAbsent
                vTotTardy += vTardy : vTotUT += vUT
                vTotOT.A1 += vOT.A1 : vTotOT.A4 += vOT.A4 : vTotOT.A2A3 += vOT.A2A3
                vTotOT.B1 += vOT.B1 : vTotOT.B2 += vOT.B2 : vTotOT.B3 += vOT.B3 : vTotOT.B4 += vOT.B4
                vTotOT.C1 += vOT.C1 : vTotOT.C2 += vOT.C2 : vTotOT.C3 += vOT.C3 : vTotOT.C4 += vOT.C4
                vTotOT.D1 += vOT.D1 : vTotOT.D2 += vOT.D2 : vTotOT.D3 += vOT.D3 : vTotOT.D4 += vOT.D4
                vTotOT.E1 += vOT.E1 : vTotOT.E2 += vOT.E2 : vTotOT.E3 += vOT.E3 : vTotOT.E4 += vOT.E4
                vTotOT.F1 += vOT.F1 : vTotOT.F2 += vOT.F2 : vTotOT.F3 += vOT.F3 : vTotOT.F4 += vOT.F4
                vTotMeal += vMeal : vTotTranspo += vTranspo

                vStr = """" & rs("Emp_Cd") & """,""" & vName & """," & Format(rs("Tran_Date"), "MM/dd/yyyy") & _
                    "," & vDOW(CDate(rs("Tran_Date")).DayOfWeek) & ","
                If IsDate(vSchedIn) Then
                    vStr += Format(CDate(vSchedIn), "hh:mm tt") & ","
                Else
                    vStr += ","
                End If
                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY:  VIC GATCHALIAN                                    '
                '' DATE MODIFIED: 10/18/2011                                       '
                '' PURPOSE: TO REFLECT THE ACTUAL HOURS RENDERED INSTEAD OF THE   ''
                ''          SCHEDULED REGULAR HOURS                               ''
                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '''''   ORIGINAL CODE ''''''''''''''''''''''''''''''''''''''''''''''
                'vStr += vSchedOut & "," & vTimeIn & "," & vTimeOut & "," & _
                '    IIf(vRegHrs = 0, "", Math.Round(vRegHrs, 2)) & "," & _
                '    IIf(vExcess = 0, "", Math.Round(vExcess, 2)) & "," & _
                '    IIf(vAbsent = 0, "", Math.Round(vAbsent, 2)) & "," & _
                '    IIf(vTardy = 0, "", Math.Round(vTardy, 2)) & "," & _
                '    IIf(vUT = 0, "", Math.Round(vUT, 2)) & "," & _
                '    IIf(vOT.A1 = 0, "", Math.Round(vOT.A1, 2)) & "," & _
                '    IIf(vOT.A4 = 0, "", Math.Round(vOT.A4, 2)) & "," & _
                '    IIf(vOT.A2A3 = 0, "", Math.Round(vOT.A2A3, 2)) & "," & _
                '    IIf(vOT.E1 = 0, "", Math.Round(vOT.E1, 2)) & "," & _
                '    IIf(vOT.E3 = 0, "", Math.Round(vOT.E3, 2)) & "," & _
                '    IIf(vOT.E2 = 0, "", Math.Round(vOT.E2, 2)) & "," & _
                '    IIf(vOT.E4 = 0, "", Math.Round(vOT.E4, 2)) & "," & _
                '    IIf(vOT.F1 = 0, "", Math.Round(vOT.F1, 2)) & "," & _
                '    IIf(vOT.F3 = 0, "", Math.Round(vOT.F3, 2)) & "," & _
                '    IIf(vOT.F2 = 0, "", Math.Round(vOT.F2, 2)) & "," & _
                '    IIf(vOT.F4 = 0, "", Math.Round(vOT.F4, 2)) & "," & _
                '    IIf(vOT.C1 = 0, "", Math.Round(vOT.C1, 2)) & "," & _
                '    IIf(vOT.C3 = 0, "", Math.Round(vOT.C3, 2)) & "," & _
                '    IIf(vOT.C2 = 0, "", Math.Round(vOT.C2, 2)) & "," & _
                '    IIf(vOT.C4 = 0, "", Math.Round(vOT.C4, 2)) & "," & _
                '    IIf(vOT.B1 = 0, "", Math.Round(vOT.B1, 2)) & "," & _
                '    IIf(vOT.B3 = 0, "", Math.Round(vOT.B3, 2)) & "," & _
                '    IIf(vOT.B2 = 0, "", Math.Round(vOT.B2, 2)) & "," & _
                '    IIf(vOT.B4 = 0, "", Math.Round(vOT.B4, 2)) & "," & _
                '    IIf(vOT.D1 = 0, "", Math.Round(vOT.D1, 2)) & "," & _
                '    IIf(vOT.D3 = 0, "", Math.Round(vOT.D3, 2)) & "," & _
                '    IIf(vOT.D2 = 0, "", Math.Round(vOT.D2, 2)) & "," & _
                '    IIf(vOT.D4 = 0, "", Math.Round(vOT.D4, 2)) & "," & _
                '    IIf(vTranspo = 0, "", Math.Round(vTranspo, 2)) & "," & _
                '    IIf(vMeal = 0, "", Math.Round(vMeal, 2)) & "," & _
                '    """" & vRemarks & """"
                '''''''''''''''' END ORIGINAL CODE '''''''''''''''''''''''''''''''''
                vStr += vSchedOut & "," & vTimeIn & "," & vTimeOut & "," & _
                    IIf(vActualHrs = 0, "", Math.Round(vActualHrs, 2)) & "," & _
                    IIf(vExcess = 0, "", Math.Round(vExcess, 2)) & "," & _
                    IIf(vAbsent = 0, "", Math.Round(vAbsent, 2)) & "," & _
                    IIf(vTardy = 0, "", Math.Round(vTardy, 2)) & "," & _
                    IIf(vUT = 0, "", Math.Round(vUT, 2)) & "," & _
                    IIf(vOT.A1 = 0, "", Math.Round(vOT.A1, 2)) & "," & _
                    IIf(vOT.A4 = 0, "", Math.Round(vOT.A4, 2)) & "," & _
                    IIf(vOT.A2A3 = 0, "", Math.Round(vOT.A2A3, 2)) & "," & _
                    IIf(vOT.E1 = 0, "", Math.Round(vOT.E1, 2)) & "," & _
                    IIf(vOT.E3 = 0, "", Math.Round(vOT.E3, 2)) & "," & _
                    IIf(vOT.E2 = 0, "", Math.Round(vOT.E2, 2)) & "," & _
                    IIf(vOT.E4 = 0, "", Math.Round(vOT.E4, 2)) & "," & _
                    IIf(vOT.F1 = 0, "", Math.Round(vOT.F1, 2)) & "," & _
                    IIf(vOT.F3 = 0, "", Math.Round(vOT.F3, 2)) & "," & _
                    IIf(vOT.F2 = 0, "", Math.Round(vOT.F2, 2)) & "," & _
                    IIf(vOT.F4 = 0, "", Math.Round(vOT.F4, 2)) & "," & _
                    IIf(vOT.C1 = 0, "", Math.Round(vOT.C1, 2)) & "," & _
                    IIf(vOT.C3 = 0, "", Math.Round(vOT.C3, 2)) & "," & _
                    IIf(vOT.C2 = 0, "", Math.Round(vOT.C2, 2)) & "," & _
                    IIf(vOT.C4 = 0, "", Math.Round(vOT.C4, 2)) & "," & _
                    IIf(vOT.B1 = 0, "", Math.Round(vOT.B1, 2)) & "," & _
                    IIf(vOT.B3 = 0, "", Math.Round(vOT.B3, 2)) & "," & _
                    IIf(vOT.B2 = 0, "", Math.Round(vOT.B2, 2)) & "," & _
                    IIf(vOT.B4 = 0, "", Math.Round(vOT.B4, 2)) & "," & _
                    IIf(vOT.D1 = 0, "", Math.Round(vOT.D1, 2)) & "," & _
                    IIf(vOT.D3 = 0, "", Math.Round(vOT.D3, 2)) & "," & _
                    IIf(vOT.D2 = 0, "", Math.Round(vOT.D2, 2)) & "," & _
                    IIf(vOT.D4 = 0, "", Math.Round(vOT.D4, 2)) & "," & _
                    IIf(vTranspo = 0, "", Math.Round(vTranspo, 2)) & "," & _
                    IIf(vMeal = 0, "", Math.Round(vMeal, 2)) & "," & _
                    """" & vRemarks & """"
                ''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''''
                vDump.AppendLine(vStr)
            Loop
            rs.Close()
            vStr = ",,,,,,,TOTAL=>," & _
                IIf(vTotRegHrs = 0, "", Math.Round(vTotRegHrs, 2)) & "," & _
                IIf(vTotExcess = 0, "", Math.Round(vTotExcess, 2)) & "," & _
                IIf(vTotAbsent = 0, "", Math.Round(vTotAbsent, 2)) & "," & _
                IIf(vTotTardy = 0, "", Math.Round(vTotTardy, 2)) & "," & _
                IIf(vTotUT = 0, "", Math.Round(vTotUT, 2)) & "," & _
                IIf(vTotOT.A1 = 0, "", Math.Round(vTotOT.A1, 2)) & "," & _
                IIf(vTotOT.A4 = 0, "", Math.Round(vTotOT.A4, 2)) & "," & _
                IIf(vTotOT.A2A3 = 0, "", Math.Round(vTotOT.A2A3, 2)) & "," & _
                IIf(vTotOT.E1 = 0, "", Math.Round(vTotOT.E1, 2)) & "," & _
                IIf(vTotOT.E3 = 0, "", Math.Round(vTotOT.E3, 2)) & "," & _
                IIf(vTotOT.E2 = 0, "", Math.Round(vTotOT.E2, 2)) & "," & _
                IIf(vTotOT.E4 = 0, "", Math.Round(vTotOT.E4, 2)) & "," & _
                IIf(vTotOT.F1 = 0, "", Math.Round(vTotOT.F1, 2)) & "," & _
                IIf(vTotOT.F3 = 0, "", Math.Round(vTotOT.F3, 2)) & "," & _
                IIf(vTotOT.F2 = 0, "", Math.Round(vTotOT.F2, 2)) & "," & _
                IIf(vTotOT.F4 = 0, "", Math.Round(vTotOT.F4, 2)) & "," & _
                IIf(vTotOT.C1 = 0, "", Math.Round(vTotOT.C1, 2)) & "," & _
                IIf(vTotOT.C3 = 0, "", Math.Round(vTotOT.C3, 2)) & "," & _
                IIf(vTotOT.C2 = 0, "", Math.Round(vTotOT.C2, 2)) & "," & _
                IIf(vTotOT.C4 = 0, "", Math.Round(vTotOT.C4, 2)) & "," & _
                IIf(vTotOT.B1 = 0, "", Math.Round(vTotOT.B1, 2)) & "," & _
                IIf(vTotOT.B3 = 0, "", Math.Round(vTotOT.B3, 2)) & "," & _
                IIf(vTotOT.B2 = 0, "", Math.Round(vTotOT.B2, 2)) & "," & _
                IIf(vTotOT.B4 = 0, "", Math.Round(vTotOT.B4, 2)) & "," & _
                IIf(vTotOT.D1 = 0, "", Math.Round(vTotOT.D1, 2)) & "," & _
                IIf(vTotOT.D3 = 0, "", Math.Round(vTotOT.D3, 2)) & "," & _
                IIf(vTotOT.D2 = 0, "", Math.Round(vTotOT.D2, 2)) & "," & _
                IIf(vTotOT.D4 = 0, "", Math.Round(vTotOT.D4, 2)) & "," & _
                IIf(vTotTranspo = 0, "", Math.Round(vTotTranspo, 2)) & "," & _
                IIf(vTotMeal = 0, "", Math.Round(vTotMeal, 2)) & ","
                
            vDump.AppendLine(vStr)

            vDump.AppendLine(" ")
            IO.File.AppendAllText(Server.MapPath(".") & "/downloads/" & Session.SessionID & "-dtr.csv", vDump.ToString)
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to retrieve Logs. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            cm.Dispose()
        End Try
    End Sub
    Protected Sub cmdHours_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdHours.Click, cmdAmount.Click
        Dim vRptType As String = ""

        Select Case CType(sender, System.Web.UI.WebControls.Button).ID
            Case "cmdHours"
                vRptType = "Hours"
            Case Else
                vRptType = "Amount"
        End Select
        printSumm(vRptType, 0)
    End Sub

    Private Sub printSumm(ByVal vRptType As String, ByVal isLate As Integer)
        Session.Remove("VFILTER")
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                           ''
        '' DATE MODIFIED: 2/19/2013                               ''
        '' PURPOSE: TO CHANGE THE DATE RETRIEVAL FROM COMBO BOX   ''
        ''          TO TEXT BOX WITH POP-UP CALENDAR              ''
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '''''''''''''''''' OLD CODE ''''''''''''''''''''''''''''''''
        'Dim vStartDate As Date = CDate(cmbMonthFr.SelectedValue & "/" & cmbDayFr.SelectedValue & "/" & _
        '    cmbYrFr.SelectedValue)
        'Dim vEndDate As Date = CDate(cmbMonthTo.SelectedValue & "/" & cmbDayTo.SelectedValue & "/" & _
        '    cmbYrTo.SelectedValue)
        '''''''''''''''''' END OLD CODE ''''''''''''''''''''''''''''
        Dim vStartDate As Date = CDate(txtFrom.Text)
        Dim vEndDate As Date = CDate(txtTo.Text)
        '''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''

        
        'Dim vFilter As String = ""

        'If cmbRC.SelectedValue <> "All" Then   'filter by cost center
        '    vFilter += " and Rc_Cd='" & cmbRC.SelectedValue & "' "
        '    Session("vFilter") += GetRef("SELECT Descr FROM rc WHERE Rc_Cd = '" & cmbRC.SelectedValue & "'", cmbRC.SelectedValue) & ""
        'Else
        '    vFilter += " and Rc_Cd in ('" & Session("rclist").ToString.Replace(",", "','") & "') "
        'End If
        'If cmbOfc.SelectedValue <> "All" Then        'filter by office/agency
        '    vFilter += " and Agency_Cd='" & cmbOfc.SelectedValue & "' "
        '    Session("VFILTER") += GetRef("SELECT AgencyName FROM agency WHERE AgencyCd = '" & cmbOfc.SelectedValue & "'", cmbOfc.SelectedValue) & ", "
        'Else
        '    vFilter += " and Agency_Cd in ('" & Session("agencylist").ToString.Replace(",", "','") & "') "
        'End If
        'If cmbDiv.SelectedValue <> "All" Then      'filter by division
        '    vFilter += " and Divcd='" & cmbDiv.SelectedValue & "' "
        '    Session("VFILTER") += GetRef("SELECT Descr FROM hr_div_ref WHERE Div_Cd = '" & cmbDiv.SelectedValue & "'", cmbDiv.SelectedValue) & ", "
        'Else
        '    vFilter += " and DivCd in ('" & Session("divlist").ToString.Replace(",", "','") & "') "
        'End If
        'If cmbDept.SelectedValue <> "All" Then  'filter by departments
        '    vFilter += " and DeptCd='" & cmbDept.SelectedValue & "' "
        '    Session("VFILTER") += GetRef("SELECT Descr FROM hr_dept_ref WHERE Dept_Cd = '" & cmbDept.SelectedValue & "'", cmbDept.SelectedValue) & ", "
        'Else
        '    vFilter += " and DeptCd in ('" & Session("deptlist").ToString.Replace(",", "','") & "') "
        'End If
        'If cmbSection.SelectedValue <> "All" Then 'filter by section
        '    vFilter += " and SectionCd='" & cmbSection.SelectedValue & "' "
        '    Session("VFILTER") += GetRef("SELECT Descr FROM hr_section_ref WHERE Section_Cd = '" & cmbSection.SelectedValue & "'", cmbSection.SelectedValue) & ", "
        'Else
        '    vFilter += " and SectionCd in ('" & Session("sectionlist").ToString.Replace(",", "','") & "') "
        'End If
        'If cmbUnit.SelectedValue <> "All" Then  'filter by units
        '    vFilter += " and UnitCd='" & cmbUnit.SelectedValue & "' "
        '    Session("VFILTER") += GetRef("SELECT Descr FROM hr_unit_ref WHERE Unit_Cd = '" & cmbUnit.SelectedValue & "'", cmbUnit.SelectedValue) & ", "
        'Else
        '    vFilter += " and UnitCd in ('" & Session("unitlist").ToString.Replace(",", "','") & "') "
        'End If
        'vFilter += " and EmploymentType in ('" & Session("typelist").ToString.Replace(",", "','") & "') "

        Session("startdate") = Format(vStartDate, "yyyy/MM/dd")
        Session("enddate") = Format(vEndDate, "yyyy/MM/dd")
        'Session("filter") = vFilter
        'If Session("VFILTER") <> "" Then
        'Session("VFILTER") = Session("VFILTER").ToString.Substring(0, Session("VFILTER").ToString.Length - 2)
        'End If


        vScript = "win=window.open('printsumm.aspx?r=" & vRptType & "&l=" & isLate & _
            "&m=0','win','toolbar=no,scrollbars=yes,width=1020,height=700,top=30,left=0');"
    End Sub
    'Protected Sub cmdHoursL_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdHoursL.Click, cmdAmountL.Click
    '    Dim vRptType As String = ""

    '    Select Case CType(sender, System.Web.UI.WebControls.Button).ID
    '        Case "cmdHoursL"
    '            vRptType = "Hours"
    '        Case Else
    '            vRptType = "Amount"
    '    End Select
    '    printSumm(vRptType, 1)
    'End Sub

    Protected Sub txtFrom_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtFrom.Init
        txtFrom.Attributes.Add("onfocus", "showCalendarControl(this)")
    End Sub

    Protected Sub txtTo_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtTo.Init
        txtTo.Attributes.Add("onfocus", "showCalendarControl(this)")
    End Sub
End Class
