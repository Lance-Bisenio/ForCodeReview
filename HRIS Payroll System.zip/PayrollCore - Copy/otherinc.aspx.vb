Imports denaro
Partial Class others
    Inherits System.Web.UI.Page
    Public vScript As String = ""

    Dim i As Integer
    Dim vDedList(60) As String

    Protected Sub cmdCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Session("returnaddr") = "otherinc.aspx"
            Server.Transfer("index.aspx")
        End If
        If Not CanRun(Session("caption"), Request.Item("id")) Then
            Session("denied") = "1"
            Server.Transfer("main.aspx")
            Exit Sub
        End If
        If Not IsPostBack Then
            lblCaption.Text = "Incentives and Other Income settings"
            Dim c As New SqlClient.SqlConnection
            Dim cm As New SqlClient.SqlCommand
            Dim dr As SqlClient.SqlDataReader

            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c
            cm.CommandText = "select OthIncent1Cd,OthIncent2Cd,OthIncent3Cd,OthIncent4Cd,OthIncent5Cd," & _
                "OthIncent6Cd,OthIncent7Cd,OthIncent8Cd,OthIncent9Cd,OthIncent10Cd," & _
                "OthIncent11Cd,OthIncent12Cd,OthIncent13Cd,OthIncent14Cd,OthIncent15Cd," & _
                "OthIncent16Cd,OthIncent17Cd,OthIncent18Cd,OthIncent19Cd,OthIncent20Cd," & _
                "OthIncent21Cd,OthIncent22Cd,OthIncent23Cd,OthIncent24Cd,OthIncent25Cd," & _
                "OthIncent26Cd,OthIncent27Cd,OthIncent28Cd,OthIncent29Cd,OthIncent30Cd," & _
                "OthIncent31Cd,OthIncent32Cd,OthIncent33Cd,OthIncent34Cd,OthIncent35Cd," & _
                "OthIncent36Cd,OthIncent37Cd,OthIncent38Cd,OthIncent39Cd,OthIncent40Cd," & _
                "OthIncent41Cd,OthIncent42Cd,OthIncent43Cd,OthIncent44Cd,OthIncent45Cd," & _
                "OthIncent46Cd,OthIncent47Cd,OthIncent48Cd,OthIncent49Cd,OthIncent50Cd," & _
                "OthIncent51Cd,OthIncent52Cd,OthIncent53Cd,OthIncent54Cd,OthIncent55Cd," & _
                "OthIncent56Cd,OthIncent57Cd,OthIncent58Cd,OthIncent59Cd,OthIncent60Cd " & _
                "from py_syscntrl"
            dr = cm.ExecuteReader

            If dr.Read Then
                For i As Integer = 1 To 60
                    vDedList(i - 1) = IIf(IsDBNull(dr("OthIncent" & i & "Cd")), "", dr("OthIncent" & i & "Cd"))
                Next
            End If
            dr.Close()
            cm.Dispose()
            c.Close()
            c.Dispose()
        End If
    End Sub

    Private Sub ClearList()
        cmbInc1.SelectedValue = "" : cmbInc2.SelectedValue = "" : cmbInc3.SelectedValue = ""
        cmbInc4.SelectedValue = "" : cmbInc5.SelectedValue = "" : cmbInc6.SelectedValue = ""
        cmbInc7.SelectedValue = "" : cmbInc8.SelectedValue = "" : cmbInc9.SelectedValue = ""
        cmbInc10.SelectedValue = "" : cmbInc11.SelectedValue = "" : cmbInc12.SelectedValue = ""
        cmbInc13.SelectedValue = "" : cmbInc14.SelectedValue = "" : cmbInc15.SelectedValue = ""
        cmbInc16.SelectedValue = "" : cmbInc17.SelectedValue = "" : cmbInc18.SelectedValue = ""
        cmbInc19.SelectedValue = "" : cmbInc20.SelectedValue = "" : cmbInc21.SelectedValue = ""
        cmbInc22.SelectedValue = "" : cmbInc23.SelectedValue = "" : cmbInc24.SelectedValue = ""
        cmbInc25.SelectedValue = "" : cmbInc26.SelectedValue = "" : cmbInc27.SelectedValue = ""
        cmbInc28.SelectedValue = "" : cmbInc29.SelectedValue = "" : cmbInc30.SelectedValue = ""
        cmbInc31.SelectedValue = "" : cmbInc32.SelectedValue = "" : cmbInc33.SelectedValue = ""
        cmbInc34.SelectedValue = "" : cmbInc35.SelectedValue = "" : cmbInc36.SelectedValue = ""
        cmbInc37.SelectedValue = "" : cmbInc38.SelectedValue = "" : cmbInc39.SelectedValue = ""
        cmbInc40.SelectedValue = "" : cmbInc41.SelectedValue = "" : cmbInc42.SelectedValue = ""
        cmbInc43.SelectedValue = "" : cmbInc44.SelectedValue = "" : cmbInc45.SelectedValue = ""
        cmbInc46.SelectedValue = "" : cmbInc47.SelectedValue = "" : cmbInc48.SelectedValue = ""
        cmbInc49.SelectedValue = "" : cmbInc50.SelectedValue = "" : cmbInc51.SelectedValue = ""
        cmbInc52.SelectedValue = "" : cmbInc53.SelectedValue = "" : cmbInc54.SelectedValue = ""
        cmbInc55.SelectedValue = "" : cmbInc56.SelectedValue = "" : cmbInc57.SelectedValue = ""
        cmbInc58.SelectedValue = "" : cmbInc59.SelectedValue = "" : cmbInc60.SelectedValue = ""
    End Sub

    Protected Sub cmbReset_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbReset.Click
        ClearList()
    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click

        Try
            Dim c As New SqlClient.SqlConnection
            Dim cm As New SqlClient.SqlCommand
            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c
            cm.CommandText = "update py_syscntrl set OthIncent1Cd='" & cmbInc1.SelectedValue & _
                "',OthIncent2Cd='" & cmbInc2.SelectedValue & _
                "',OthIncent3Cd='" & cmbInc3.SelectedValue & _
                "',OthIncent4Cd='" & cmbInc4.SelectedValue & _
                "',OthIncent5Cd='" & cmbInc5.SelectedValue & _
                "',OthIncent6Cd='" & cmbInc6.SelectedValue & _
                "',OthIncent7Cd='" & cmbInc7.SelectedValue & _
                "',OthIncent8Cd='" & cmbInc8.SelectedValue & _
                "',OthIncent9Cd='" & cmbInc9.SelectedValue & _
                "',OthIncent10Cd='" & cmbInc10.SelectedValue & _
                "',OthIncent11Cd='" & cmbInc11.SelectedValue & _
                "',OthIncent12Cd='" & cmbInc12.SelectedValue & _
                "',OthIncent13Cd='" & cmbInc13.SelectedValue & _
                "',OthIncent14Cd='" & cmbInc14.SelectedValue & _
                "',OthIncent15Cd='" & cmbInc15.SelectedValue & _
                "',OthIncent16Cd='" & cmbInc16.SelectedValue & _
                "',OthIncent17Cd='" & cmbInc17.SelectedValue & _
                "',OthIncent18Cd='" & cmbInc18.SelectedValue & _
                "',OthIncent19Cd='" & cmbInc19.SelectedValue & _
                "',OthIncent20Cd='" & cmbInc20.SelectedValue & _
                "',OthIncent21Cd='" & cmbInc21.SelectedValue & _
                "',OthIncent22Cd='" & cmbInc22.SelectedValue & _
                "',OthIncent23Cd='" & cmbInc23.SelectedValue & _
                "',OthIncent24Cd='" & cmbInc24.SelectedValue & _
                "',OthIncent25Cd='" & cmbInc25.SelectedValue & _
                "',OthIncent26Cd='" & cmbInc26.SelectedValue & _
                "',OthIncent27Cd='" & cmbInc27.SelectedValue & _
                "',OthIncent28Cd='" & cmbInc28.SelectedValue & _
                "',OthIncent29Cd='" & cmbInc29.SelectedValue & _
                "',OthIncent30Cd='" & cmbInc30.SelectedValue & _
                "',OthIncent31Cd='" & cmbInc31.SelectedValue & _
                "',OthIncent32Cd='" & cmbInc32.SelectedValue & _
                "',OthIncent33Cd='" & cmbInc33.SelectedValue & _
                "',OthIncent34Cd='" & cmbInc34.SelectedValue & _
                "',OthIncent35Cd='" & cmbInc35.SelectedValue & _
                "',OthIncent36Cd='" & cmbInc36.SelectedValue & _
                "',OthIncent37Cd='" & cmbInc37.SelectedValue & _
                "',OthIncent38Cd='" & cmbInc38.SelectedValue & _
                "',OthIncent39Cd='" & cmbInc39.SelectedValue & _
                "',OthIncent40Cd='" & cmbInc40.SelectedValue & _
                "',OthIncent41Cd='" & cmbInc41.SelectedValue & _
                "',OthIncent42Cd='" & cmbInc42.SelectedValue & _
                "',OthIncent43Cd='" & cmbInc43.SelectedValue & _
                "',OthIncent44Cd='" & cmbInc44.SelectedValue & _
                "',OthIncent45Cd='" & cmbInc45.SelectedValue & _
                "',OthIncent46Cd='" & cmbInc46.SelectedValue & _
                "',OthIncent47Cd='" & cmbInc47.SelectedValue & _
                "',OthIncent48Cd='" & cmbInc48.SelectedValue & _
                "',OthIncent49Cd='" & cmbInc49.SelectedValue & _
                "',OthIncent50Cd='" & cmbInc50.SelectedValue & _
                "',OthIncent51Cd='" & cmbInc51.SelectedValue & _
                "',OthIncent52Cd='" & cmbInc52.SelectedValue & _
                "',OthIncent53Cd='" & cmbInc53.SelectedValue & _
                "',OthIncent54Cd='" & cmbInc54.SelectedValue & _
                "',OthIncent55Cd='" & cmbInc55.SelectedValue & _
                "',OthIncent56Cd='" & cmbInc56.SelectedValue & _
                "',OthIncent57Cd='" & cmbInc57.SelectedValue & _
                "',OthIncent58Cd='" & cmbInc58.SelectedValue & _
                "',OthIncent59Cd='" & cmbInc59.SelectedValue & _
                "',OthIncent60Cd='" & cmbInc60.SelectedValue & "'"
            cm.ExecuteNonQuery()
            cm.Dispose()
            c.Close()
            c.Dispose()
            vScript = "alert('Changes have been saved successfully.');"
        Catch ex As system.exception
            MsgBox("error")
            vScript = "alert('Error occurred while trying to save changes. Error is: " & _
                ex.Message.Replace("'", "").Replace(vbCrLf, "") & "');"
        End Try
    End Sub

    Protected Sub cmbInc1_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles _
        cmbInc1.PreRender, cmbInc2.PreRender, cmbInc3.PreRender, cmbInc4.PreRender, cmbInc5.PreRender, _
        cmbInc6.PreRender, cmbInc7.PreRender, cmbInc8.PreRender, cmbInc9.PreRender, cmbInc10.PreRender, _
        cmbInc11.PreRender, cmbInc12.PreRender, cmbInc13.PreRender, cmbInc14.PreRender, cmbInc15.PreRender, _
        cmbInc16.PreRender, cmbInc17.PreRender, cmbInc18.PreRender, cmbInc19.PreRender, cmbInc20.PreRender, _
        cmbInc21.PreRender, cmbInc22.PreRender, cmbInc23.PreRender, cmbInc24.PreRender, cmbInc25.PreRender, _
        cmbInc26.PreRender, cmbInc27.PreRender, cmbInc28.PreRender, cmbInc29.PreRender, cmbInc30.PreRender, _
        cmbInc31.PreRender, cmbInc32.PreRender, cmbInc33.PreRender, cmbInc34.PreRender, cmbInc35.PreRender, _
        cmbInc36.PreRender, cmbInc37.PreRender, cmbInc38.PreRender, cmbInc39.PreRender, cmbInc40.PreRender, _
        cmbInc41.PreRender, cmbInc42.PreRender, cmbInc43.PreRender, cmbInc44.PreRender, cmbInc45.PreRender, _
        cmbInc46.PreRender, cmbInc47.PreRender, cmbInc48.PreRender, cmbInc49.PreRender, cmbInc50.PreRender, _
        cmbInc51.PreRender, cmbInc52.PreRender, cmbInc53.PreRender, cmbInc54.PreRender, cmbInc55.PreRender, _
        cmbInc56.PreRender, cmbInc57.PreRender, cmbInc58.PreRender, cmbInc59.PreRender, cmbInc60.PreRender

        If txtState.Value = "" Then
            Dim vIdx As String

            BuildCombo("select Incentive_Cd,Descr from py_other_incentvs order by Descr", CType(sender, DropDownList))

            CType(sender, DropDownList).Items.Add("")
            vIdx = CType(sender, DropDownList).ID.Substring(6)
            CType(sender, DropDownList).SelectedValue = vDedList(vIdx - 1)
            If vIdx = 60 Then txtState.Value = "1"
        End If
    End Sub

End Class
