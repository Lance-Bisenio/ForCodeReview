﻿Imports denaro
Partial Class generateletter_print
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Public vData As String = ""
    Dim c As New SqlClient.SqlConnection

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim cRef As New SqlClient.SqlConnection(connStr)

        Dim cm As New SqlClient.SqlCommand
        Dim cmEmp As New SqlClient.SqlCommand
        Dim drEmp As SqlClient.SqlDataReader
        Dim dr As SqlClient.SqlDataReader
        Dim vContent As String = ""
        Dim vPrn As New VSPrinter8Lib.VSPrinter
        Dim vPDF As New VSPDF8Lib.VSPDF8

        c.ConnectionString = connStr
        c.Open()
        cRef.Open()

        cm.Connection = c
        cmEmp.Connection = cRef

        'cmEmp.CommandText = "select * from py_emp_master where Emp_Cd='" & _
        '    tblEmp.SelectedRow.Cells(0).Text & "'"

        cmEmp.CommandText = "select * from py_emp_master where Emp_Cd='" & Request.Item("vEmpCd") & "'"
        'Response.Write(cmEmp.CommandText)
        drEmp = cmEmp.ExecuteReader
        If drEmp.Read Then
            'cm.CommandText = "select Letter_Content from hr_letter_hdr where Letter_Cd='" & _
            '    cmbLetter.SelectedValue & "'"

            cm.CommandText = "select Letter_Content from hr_letter_hdr where Letter_Cd='" & Request.Item("letterCd") & "'"

            dr = cm.ExecuteReader

            If dr.Read Then
                vContent = IIf(IsDBNull(dr("Letter_Content")), "", dr("Letter_Content"))
            End If
            dr.Close()

            cm.CommandText = "select * from hr_letter_dtl where Letter_Cd='" & Request.Item("letterCd") & "'"
            dr = cm.ExecuteReader
            Do While dr.Read


                Select Case dr("Find_Var") '.ToString.ToLower
                    Case "[Date]"
                        vContent = vContent.Replace(dr("Find_Var"), Format(Now, "MM/dd/yyyy"))
                    Case "[DateTime]"
                        vContent = vContent.Replace(dr("Find_Var"), Format(Now, "MM/dd/yyyy HH:mm:ss"))
                    Case "[Time]"
                        vContent = vContent.Replace(dr("Find_Var"), Format(Now, "HH:mm:ss"))
                    Case Else
                        Try
                            'vContent = vContent.Replace(dr("Find_Var"), drEmp(dr("Replace_With")))
                            vContent = vContent.Replace(IIf(IsDBNull(dr("Find_Var")), "", dr("Find_Var")), drEmp(dr("Replace_With")))
                        Catch
                        End Try
                End Select
            Loop
            dr.Close()
        End If

        vData = vContent

        drEmp.Close()
        cmEmp.Dispose()
        cm.Dispose()

        cRef.Close()
        cRef.Dispose()
        c.Close()


        'vPrn.Orientation = VSPrinter8Lib.OrientationSettings.orPortrait
        'vPrn.PaperSize = VSPrinter8Lib.PaperSizeSettings.ppr10x14
        'vPrn.MarginTop = OneInch
        'vPrn.MarginBottom = OneInch
        'vPrn.MarginLeft = OneInch / 2
        'vPrn.MarginRight = OneInch / 2
        'vPrn.StartDoc()
        'vPrn.Paragraph = vContent
        'vPrn.EndDoc()
        'vPDF.ConvertDocument(vPrn, Server.MapPath(".") & "/downloads/" & Session("sessionid") & ".pdf")

        'vScript = "document.getElementById('IFRAME1').src = 'downloads/" & Session("sessionid") & ".pdf';"
        'vPDF = Nothing
        'vPrn = Nothing
    End Sub
End Class
