Imports denaro.fis
Partial Class PostToIncent
    Inherits System.Web.UI.Page
    Public vScript As String

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Session("returnaddr") = "massupdateincent.aspx"
            Server.Transfer("index.aspx")
        End If
        If Not IsPostBack Then
            BuildCombo("select Pay_Cd,Payment from py_pay_mode order by Payment", cmbPayMode)
            BuildCombo("select Incentive_Cd,Descr from py_other_incentvs order by Descr", cmbIncent)
            cmbMonth.SelectedValue = Now.Month
            setPeriod()
        End If

    End Sub

    Protected Sub cmbMonth_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbMonth.SelectedIndexChanged
        setPeriod()
    End Sub

    Private Sub setPeriod()
        Dim c As New sqlclient.sqlconnection(connStr)
        Dim cm As New sqlclient.sqlcommand
        Dim dr As sqlclient.sqldatareader
        Dim vCutOff As String = ""
        Dim vDays() As String

        c.Open()
        cm.Connection = c
        cm.CommandText = "select * from py_pay_mode where Pay_Cd='" & cmbPayMode.SelectedValue & "'"
        dr = cm.ExecuteReader
        If dr.Read Then
            Session("divisor") = IIf(IsDBNull(dr("Divisor")), 1, dr("Divisor"))
            Session("index") = "1"
            vCutOff = IIf(IsDBNull(dr("Days")), "", dr("Days"))
            cmbPeriod.Items.Clear()
            vDays = vCutOff.Split(",")
            If vDays(1) > vDays(0) Then
                cmbPeriod.Items.Add(cmbMonth.SelectedValue & "/" & vDays(1) - 1 & "/" & Now.Year)
                cmbPeriod.Items.Add(cmbMonth.SelectedValue & "/" & Date.DaysInMonth(Now.Year, cmbMonth.SelectedValue) & "/" & Now.Year)
            End If
        End If
        dr.Close()
        cm.Dispose()
        c.Close()
        c.Dispose()
    End Sub

    Protected Sub cmdPost_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdPost.Click
        Dim c As New sqlclient.sqlconnection(connStr)
        Dim cm As New sqlclient.sqlcommand
        Dim rs As sqlclient.sqldatareader
        Dim vInitEmpAmount() As String
        Dim vRawData As String = ""
        Dim vEmpCdWithAmt() As String
        Dim vCtr As Integer = 0
        Dim vAllowed As Boolean = True
        Dim vInsert As Boolean = True

        c.Open()
        cm.Connection = c

        If Session("EmpToPost") <> "" Then
            vInitEmpAmount = Session("EmpToPost").ToString.Split(",")

            cm.CommandText = "SELECT 1 FROM py_report WHERE '" & cmbPeriod.SelectedItem.Text & "' BETWEEN FromDate AND ToDate AND Posted = 1"
            rs = cm.ExecuteReader
            vAllowed = Not rs.HasRows
            rs.Close()

            If vAllowed Then
                For vCtr = 0 To vInitEmpAmount.Length - 1
                    vInsert = True
                    vRawData = vInitEmpAmount(vCtr).ToString
                    vEmpCdWithAmt = vRawData.Split("-")

                    cm.CommandText = "DELETE FROM py_incentives_dtl WHERE Incentive_Cd = '" & ExtractData(cmbIncent.SelectedItem.Text) & "' AND FromDate = '" & _
                                     cmbPeriod.SelectedItem.Text & "' AND ToDate = '" & cmbPeriod.SelectedItem.Text & "' AND Emp_Cd = '" & vEmpCdWithAmt(0) & "' AND Recurring = 0"
                    cm.ExecuteNonQuery()

                    cm.CommandText = "INSERT INTO py_incentives_dtl (Incentive_Cd, Incentive_Amt, FromDate, ToDate, Emp_Cd, Recurring) VALUES " & _
                               "('" & ExtractData(cmbIncent.SelectedItem.Text) & " ','" & vEmpCdWithAmt(1) & "' ,'" & cmbPeriod.SelectedItem.Text & "','" & cmbPeriod.SelectedItem.Text & "','" & vEmpCdWithAmt(0) & "',0)"
                    Try
                        cm.ExecuteNonQuery()
                    Catch ex As sqlclient.sqlException
                        vScript = "alert('Cannot saved due to " & ex.Message & "');"
                        Exit Sub
                    End Try
                Next
            Else
                vScript = "alert('Sorry this cut-off period has been frozen.');"
                Exit Sub
            End If
        End If
        vScript = "alert('Posting to incetives complete.');window.close();"
        c.Close()
        c.Dispose()
        cm.Dispose()

    End Sub
End Class
