﻿Imports denaro.fis
Partial Class livemonitor
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Label1.Text = "Powered by <a href='http://www.evolvesoftwaresolutions.com' target='_blank'>Evolve Integrated Software Solutions</a> &copy 2009-" & Now.Year
    End Sub
End Class
