﻿Imports denaro
Partial Class _14th
    Inherits System.Web.UI.Page

    Public vScript As String = ""
    Public vDump As String = ""
    Public vMonth(12) As String
    Public vTotAmount As Double = 0
    Dim c As New SqlClient.SqlConnection
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'If Session("uid") = "" Then
        '    Session("returnaddr") = "massupdateincent.aspx"
        '    Server.Transfer("index.aspx")
        'End If
        If Not IsPostBack Then 'now build the reference code
            'If Not CanRun(Session("caption"), Request.Item("id")) Then
            '    Session("denied") = "1"
            '    Server.Transfer("main.aspx")
            '    Exit Sub
            'End If
            Dim ictr As Integer
            lblCaption.Text = "14th Month Incentives Computation"
            'BuildCombo("select Rc_Cd, Descr from rc where Rc_Cd in ('" & _
            '    Session("rclist").ToString.Replace(",", "','") & "') order by Descr", cmbRC)
            'BuildCombo("select AgencyCd,AgencyName from agency where AgencyCd in ('" & _
            '    Session("agencylist").ToString.Replace(",", "','") & "') order by AgencyName", cmbOfc)
            'BuildCombo("select Div_Cd,Descr from hr_div_ref where Div_Cd in ('" & _
            '    Session("divlist").ToString.Replace(",", "','") & "') order by Descr", cmbDiv)
            'BuildCombo("select Dept_Cd,Descr from hr_dept_ref where Dept_Cd in ('" & _
            '    Session("deptlist").ToString.Replace(",", "','") & "') order by Descr", cmbDept)
            'BuildCombo("select Section_Cd,Descr from hr_section_ref where Section_Cd in ('" & _
            '    Session("sectionlist").ToString.Replace(",", "','") & "') order by Descr", cmbSection)
            'BuildCombo("select Unit_Cd,Descr from hr_unit_ref where Unit_Cd in ('" & _
            '    Session("unitlist").ToString.Replace(",", "','") & "') order by Descr", cmbUnit)
            'BuildCombo("select Incentive_Cd,Descr from py_other_incentvs order by Descr", cmbIncent)
            'BuildCombo("select EmploymentType,Descr from hr_employment_type where EmploymentType in ('" & _
            '    Session("typelist").ToString.Replace(",", "','") & "') order by Descr", cmbSecurity)
            BuildCombo("select Rc_Cd, Descr from rc order by Descr", cmbRC)
            BuildCombo("select AgencyCd,AgencyName from agency order by AgencyName", cmbOfc)
            BuildCombo("select Div_Cd,Descr from hr_div_ref order by Descr", cmbDiv)
            BuildCombo("select Dept_Cd,Descr from hr_dept_ref order by Descr", cmbDept)
            BuildCombo("select Section_Cd,Descr from hr_section_ref order by Descr", cmbSection)
            BuildCombo("select Unit_Cd,Descr from hr_unit_ref order by Descr", cmbUnit)
            BuildCombo("select Incentive_Cd,Descr from py_other_incentvs order by Descr", cmbIncent)
            BuildCombo("select EmploymentType,Descr from hr_employment_type order by Descr", cmbSecurity)
            cmbRC.Items.Add("All")
            cmbRC.SelectedValue = "All"
            cmbOfc.Items.Add("All")
            cmbOfc.SelectedValue = "All"
            cmbDiv.Items.Add("All")
            cmbDiv.SelectedValue = "All"
            cmbDept.Items.Add("All")
            cmbDept.SelectedValue = "All"
            cmbSection.Items.Add("All")
            cmbSection.SelectedValue = "All"
            cmbUnit.Items.Add("All")
            cmbUnit.SelectedValue = "All"
            cmbSecurity.Items.Add("All")
            cmbSecurity.SelectedValue = "All"
            'cmbYearFr.Items.Clear()
            'cmbYearTo.Items.Clear()
            'For ictr = 1990 To 2030
            '    cmbYearFr.Items.Add(ictr)
            '    cmbYearTo.Items.Add(ictr)
            'Next
            'cmbYearFr.SelectedValue = Now.Year
            'cmbYearTo.SelectedValue = Now.Year
        Else
            If Request.Form("txtEmpList") <> "" Then
                txtEmpList.Text = Request.Form("txtEmpList")
            End If
        End If
    End Sub
    Protected Sub cmdReturn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.Click
        Session.Remove("basis")
        Session.Remove("1stMonthCredit")
        Session.Remove("cond1")
        Session.Remove("cond2")
        Session.Remove("cond3")
        Session.Remove("start1")
        Session.Remove("start2")
        Session.Remove("start3")
        Session.Remove("end1")
        Session.Remove("end2")
        Session.Remove("end3")
        Session.Remove("absences")
        Session.Remove("divisor")
        Session.Remove("incentives")
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub cmdGenerate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdGenerate.Click
        Dim vEmpCount As Integer = 0
        'Dim vTotAmount As Double = 0

        Dim vEmpList As String = txtEmpList.Text

        'If cmbRC.SelectedValue = "All" Then
        '    vEmpList = " and Rc_Cd in ('" & Session("rclist").ToString.Replace(",", "','") & "') "
        'Else
        '    vEmpList = " and Rc_Cd='" & Request.Item("rc") & "' "
        'End If
        'If cmbOfc.SelectedValue = "All" Then
        '    vEmpList += " and Agency_Cd in ('" & Session("agencylist").ToString.Replace(",", "','") & "') "
        'Else
        '    vEmpList += " and Agency_Cd='" & Request.Item("ofc") & "' "
        'End If
        'If cmbDiv.SelectedValue = "All" Then
        '    vEmpList += " and DivCd in ('" & Session("divlist").ToString.Replace(",", "','") & "') "
        'Else
        '    vEmpList += " and DivCd='" & Request.Item("div") & "' "
        'End If
        'If cmbDept.SelectedValue = "All" Then
        '    vEmpList += " and DeptCd in ('" & Session("deptlist").ToString.Replace(",", "','") & "') "
        'Else
        '    vEmpList += " and DeptCd='" & Request.Item("dept") & "' "
        'End If
        'If cmbSection.SelectedValue = "All" Then
        '    vEmpList += " and SectionCd in ('" & Session("sectionlist").ToString.Replace(",", "','") & "') "
        'Else
        '    vEmpList += " and SectionCd='" & Request.Item("section") & "' "
        'End If
        'If cmbUnit.SelectedValue = "All" Then
        '    vEmpList += " and UnitCd in ('" & Session("unitlist").ToString.Replace(",", "','") & "') "
        'Else
        '    vEmpList += " and UnitCd='" & Request.Item("unit") & "' "
        'End If
        'If cmbSecurity.SelectedValue = "All" Then
        '    vEmpList += " and EmploymentType in ('" & Session("typelist").ToString.Replace(",", "','") & "') "
        'Else
        '    vEmpList += " and EmploymentType='" & Request.Item("type") & "' "
        'End If
        'If cmbStatus.SelectedValue = "All" Then
        '    vEmpList += " and (Date_Resign is not null or Date_Resign is null) "
        'Else
        '    vEmpList += cmbStatus.SelectedValue
        'End If



        If vEmpList = "" Then
            vScript = "alert('You must first select a list of employees to generate.');"
            Exit Sub
        End If

        Dim vString As String = ""
        Dim vCompute As Decimal
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader

        Dim cmref As New SqlClient.SqlCommand
        Dim rsref As SqlClient.SqlDataReader

        Dim vLOS As Decimal = 0
        Dim v14th As Decimal = 0
        Dim vStyle As String = "odd"


        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c
        cm.CommandText = "select Emp_Cd,Emp_Lname,Emp_Fname,Rate_Month,Start_Date from " & _
            "py_emp_master where Emp_Cd in (" & vEmpList & ") and Start_Date is not null order by Emp_Lname,Emp_Fname"

        cmref.Connection = c

        rs = cm.ExecuteReader
        vDump = ""
        vString = ""
        vString = "Emp Code,Last Name,First Name,Date Hired,Monthly Rate,LOS,Factor,Amount,"
        vString += vbCrLf
        Do While rs.Read
            vEmpCount += 1

            vLOS = DateDiff(DateInterval.Year, rs("Start_Date"), Now)

            '''''Get the Factor Rate of LOS
            cmref.CommandText = "select Bonus from py_14thincent where " & vLOS & " between LOSFrom and LOSTo"
            rsref = cmref.ExecuteReader
            If rsref.Read Then
                v14th = rsref("Bonus")
            End If
            rsref.Close()



            vString += rs("Emp_Cd") & "," & rs("Emp_Lname") & "," & rs("Emp_Fname") & "," & _
                            Format(rs("Start_Date"), "MM/dd/yyyy") & "," & _
                        Format(rs("Rate_Month"), "########0.00") & "," & vLOS & "," & Format(v14th, "###,###,##0.00") & ","


            ''''''''''''''''''''''''''''''''''''''
            '' 14th month computation goes here ''
            'vCompute = Compute(rs("Emp_Cd"), rs("Rate_Month"), rs("Start_Date"), vString, vLOS, v14th)
            vCompute = rs("Rate_Month") * v14th
            ''''''''''''''''''''''''''''''''''''''

            'Compute = (pRateMonth * v14th)
            'vTotal = (pRateMonth * v14th)
            vString += Format(vCompute)

            vTotAmount += Format(vCompute)


            vString += vbCrLf
            vDump += "<tr class=' " & vStyle & " '><td class='labelBC'>" & rs("Emp_Cd") & "</td>" & _
                "<td class='labelBL'>&nbsp;" & rs("Emp_Lname") & ", " & rs("Emp_Fname") & "</td>" & _
                "<td class='labelBC'>" & Format(rs("Start_Date"), "MM/dd/yyyy") & "</td>" & _
                "<td class='labelBR'>" & Format(rs("Rate_Month"), "###,##0.00") & "</td>" & _
                "<td class='labelBC'>" & vLOS & "</td>" & _
                "<td class='labelBC'>" & Format(v14th, "##0.00") & "</td>" & _
                "<td class='labelBR'>" & Format(vCompute, "###,##0.00") & "</td>" & _
                "</tr>"

            If vStyle = "odd" Then
                vStyle = "even"
            Else
                vStyle = "odd"
            End If
        Loop
        rs.Close()
        cm.Dispose()
        cmref.Dispose()
        c.Close()
        cmdPost.Enabled = True
        txtEmpCount.Text = vEmpCount
        txtTotAmount.Text = Format(vTotAmount, "###,###,##0.00")

        If Dir(Server.MapPath(".") & "\downloads\" & Session.SessionID & "-14th.csv") <> "" Then
            Try
                IO.File.Delete(Server.MapPath(".") & "\downloads\" & Session.SessionID & "-14th.csv")
            Catch ex As IO.IOException
                vScript = "alert('Error writing deleteing csv file. " & ex.Message.Replace("'", "\'").Replace(vbCrLf, "\n") & "');"
            End Try
        End If
        Try
            IO.File.WriteAllText(Server.MapPath(".") & "\downloads\" & Session.SessionID & "-14th.csv", vString)
            lnkDownload.NavigateUrl = "downloads/" & Session.SessionID & "-14th.csv"

        Catch ex As IO.IOException
            vScript = "alert('Error writing writing to csv file. " & ex.Message.Replace("'", "\'").Replace(vbCrLf, "\n") & "');"
        End Try

    End Sub
    
    Protected Sub cmdPost_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdPost.Click
        If Not IsDate(txtEffectivity.Text) Then
            vScript = "alert('You must enter a valid effectivity date format.');"
            Exit Sub
        End If
        If cmbIncent.SelectedIndex < 0 Then
            vScript = "alert('You must select where to post the calculated figures.');"
            Exit Sub
        End If

        If txtEmpList.Text = "" Then
            vScript = "alert('You must select an employee list first, then click the Generate button before posting it to " & _
                "incentives module.');"
            Exit Sub
        End If

        Dim vAmount As Double = 0
        Dim cm As New SqlClient.SqlCommand
        Dim cmref As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim rsref As SqlClient.SqlDataReader

        Dim cmAudit As New SqlClient.SqlCommand
        Dim rsAudit As SqlClient.SqlDataReader

        Dim vEmpList = txtEmpList.Text
        Dim vLos As Integer
        Dim v14th As Decimal = 0
        Dim vCompute As Decimal = 0

        c.ConnectionString = connStr
        c.Open()
        cm.Connection = c
        cmref.Connection = c
        cm.CommandText = "select Emp_Cd,Emp_Lname,Emp_Fname,Rate_Month,Start_Date from " & _
            "py_emp_master where Emp_Cd in (" & vEmpList & ") and Start_Date is not null order by Emp_Lname,Emp_Fname"

        rs = cm.ExecuteReader
        vDump = ""
        Do While rs.Read
            ''''''Compute the amount
            vLOS = DateDiff(DateInterval.Year, rs("Start_Date"), Now)

            '''''Get the Factor Rate of LOS
            cmref.CommandText = "select Bonus from py_14thincent where " & vLos & " between LOSFrom and LOSTo"
            rsref = cmref.ExecuteReader
            If rsref.Read Then
                v14th = rsref("Bonus")
            End If

            rsref.Close()
            vCompute = rs("Rate_Month") * v14th

            Select Case cmbPostmuch.SelectedValue
                Case "0"    'whole amount
                    vAmount = vCompute
                    'Case "1"    '1st quarter
                    '    vAmount = Val(Request.Form("txt01" & rs("Emp_Cd")).ToString.Replace(",", "")) + _
                    '        Val(Request.Form("txt02" & rs("Emp_Cd")).ToString.Replace(",", "")) + _
                    '        Val(Request.Form("txt03" & rs("Emp_Cd")).ToString.Replace(",", ""))
                    'Case "2"    '2nd quarter
                    '    vAmount = Val(Request.Form("txt04" & rs("Emp_Cd")).ToString.Replace(",", "")) + _
                    '        Val(Request.Form("txt05" & rs("Emp_Cd")).ToString.Replace(",", "")) + _
                    '        Val(Request.Form("txt06" & rs("Emp_Cd")).ToString.Replace(",", ""))
                    'Case "3"    '3rd quarter
                    '    vAmount = Val(Request.Form("txt07" & rs("Emp_Cd")).ToString.Replace(",", "")) + _
                    '        Val(Request.Form("txt08" & rs("Emp_Cd")).ToString.Replace(",", "")) + _
                    '        Val(Request.Form("txt09" & rs("Emp_Cd")).ToString.Replace(",", ""))
                    'Case "4"    '4th quarter
                    '    vAmount = Val(Request.Form("txt10" & rs("Emp_Cd")).ToString.Replace(",", "")) + _
                    '        Val(Request.Form("txt11" & rs("Emp_Cd")).ToString.Replace(",", "")) + _
                    '        Val(Request.Form("txt12" & rs("Emp_Cd")).ToString.Replace(",", ""))
                    'Case "1/2"  '1st half
                    '    vAmount = Val(Request.Form("txt01" & rs("Emp_Cd")).ToString.Replace(",", "")) + _
                    '        Val(Request.Form("txt02" & rs("Emp_Cd")).ToString.Replace(",", "")) + _
                    '        Val(Request.Form("txt03" & rs("Emp_Cd")).ToString.Replace(",", "")) + _
                    '        Val(Request.Form("txt04" & rs("Emp_Cd")).ToString.Replace(",", "")) + _
                    '        Val(Request.Form("txt05" & rs("Emp_Cd")).ToString.Replace(",", "")) + _
                    '        Val(Request.Form("txt06" & rs("Emp_Cd")).ToString.Replace(",", ""))
                    'Case "2/2"  '2nd half
                    '    vAmount = Val(Request.Form("txt07" & rs("Emp_Cd")).ToString.Replace(",", "")) + _
                    '        Val(Request.Form("txt08" & rs("Emp_Cd")).ToString.Replace(",", "")) + _
                    '        Val(Request.Form("txt09" & rs("Emp_Cd")).ToString.Replace(",", "")) + _
                    '        Val(Request.Form("txt10" & rs("Emp_Cd")).ToString.Replace(",", "")) + _
                    '        Val(Request.Form("txt11" & rs("Emp_Cd")).ToString.Replace(",", "")) + _
                    '        Val(Request.Form("txt12" & rs("Emp_Cd")).ToString.Replace(",", ""))
                    'Case "QAmt" 'Quarter of the Amount
                    '    vAmount = Val(Request.Form("txt10" & rs("Emp_Cd")).ToString.Replace(",", "")) + _
                    '        Val(Request.Form("txt11" & rs("Emp_Cd")).ToString.Replace(",", "")) + _
                    '        Val(Request.Form("txt12" & rs("Emp_Cd")).ToString.Replace(",", ""))
                Case "HAmt" 'Half of the Amount
                    vAmount = vCompute / 2
            End Select

            cmAudit.Connection = c
            '''''Audit Log Delete
            cmAudit.CommandText = "select * from py_incentives_dtl where Emp_Cd ='" & rs("Emp_Cd") & "' and Incentive_Cd='" & _
                                cmbIncent.SelectedValue & "' and FromDate='" & _
                                Format(CDate(txtEffectivity.Text), "yyyy/MM/dd") & "'"
            rsAudit = cmAudit.ExecuteReader
            If rsAudit.Read Then
                EventLog(Session("uid"), Request.ServerVariables("REMOTE_ADDR"), "DELETE", "Emp_Cd=" & rsAudit("Emp_Cd") & "|Amount=" & rsAudit("Incentive_Amt") & _
                         "|Incent_Code=" & rsAudit("Incentive_Cd") & "|FromDate=" & rsAudit("FromDate") & _
                         "|ToDate=" & rsAudit("ToDate"), "|EmpCd=|Amount=|Incent_Code=|FromDate=|ToDate=", _
                            "Employee ID: " & Session("uid") & " was deleted the incentives " & rsAudit("Incentive_Cd") & " of " & rsAudit("Emp_Cd"), "Incentives", c)
            End If
            rsAudit.Close()

            cmref.CommandText = "delete from py_incentives_dtl where Emp_Cd='" & _
                rs("Emp_Cd") & "' and Incentive_Cd='" & cmbIncent.SelectedValue & _
                "' and FromDate='" & Format(CDate(txtEffectivity.Text), "yyyy/MM/dd") & "'"
            cmref.ExecuteNonQuery()


            cmref.CommandText = "insert into py_incentives_dtl (Incentive_Cd,Incentive_Amt," & _
                "FromDate,ToDate,Emp_Cd,Recurring) values ('" & cmbIncent.SelectedValue & _
                "'," & vAmount & ",'" & Format(CDate(txtEffectivity.Text), "yyyy/MM/dd") & _
                "','" & Format(CDate(txtEffectivity.Text), "yyyy/MM/dd") & "','" & _
                rs("Emp_Cd") & "',0)"
            cmref.ExecuteNonQuery()

            '''''Audit log insert            
            EventLog(Session("uid"), Request.ServerVariables("REMOTE_ADDR"), "ADD", "Emp_Cd=|Amount=|Incent_Code=|FromDate=|ToDate=", "Emp_Cd=" & _
                     rs("Emp_Cd") & "|Amount=" & vAmount & _
                         "|Incent_Code=" & cmbIncent.SelectedValue & "|FromDate=" & Format(CDate(txtEffectivity.Text), "yyyy/MM/dd") & _
                         "|ToDate=" & Format(CDate(txtEffectivity.Text), "yyyy/MM/dd"), _
                         "Employee ID: " & Session("uid") & " was added the incentives " & cmbIncent.SelectedValue & _
                         " of " & rs("Emp_Cd"), "Incentives", c)
        Loop

        rs.Close()
        cm.Dispose()
        cmref.Dispose()
        cmAudit.Dispose()
        c.Close()
        vScript = "alert('Posting complete!');"
    End Sub

End Class
