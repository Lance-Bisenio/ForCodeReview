Imports denaro
Partial Class emr
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Dim vSQL As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If
        If Not CanRun(Session("caption"), Request.Item("id")) Then
            Session("denied") = "1"
            Server.Transfer("main.aspx")
            Exit Sub
        End If

        If Not IsPostBack Then
            lblCaption.Text = "Record Employee Movement"
            txtPreparedBy.Text = Session("uid")
            Dim c As New SqlClient.SqlConnection(connStr)
            Dim cm As New SqlClient.SqlCommand
            Dim dr As SqlClient.SqlDataReader

            Try
                c.Open()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                c.Dispose()
                cm.Dispose()
                Exit Sub
            End Try

            cm.Connection = c
            cm.CommandText = "select FullName from user_list where User_Id='" & txtPreparedBy.Text & "'"
            Try
                dr = cm.ExecuteReader
                If dr.Read Then
                    txtPreparedBy.Text += "=>" & dr("FullName")
                End If
                dr.Close()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to retrieve User Information. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                c.Close()
                cm.Dispose()
                c.Dispose()
                Exit Sub
            End Try
            
            txtDatePrepared.Text = Format(Now, "MM/dd/yyyy")
            txtEffectivityDate.Text = Format(Now, "MM/dd/yyyy")
            BuildCombo("select Emp_Cd,(Emp_Lname+', '+Emp_Fname) as Name from py_emp_master where " & _
                "Date_Resign is null and DateHold is null and DateSuspended is null and Date_Retired is null " & _
                "and EmploymentType in ('" & Session("typelist").ToString.Replace(",", "','") & _
                "') order by Emp_Lname,Emp_Fname", cmbEmp, c)
            BuildCombo("select Emp_Cd,(Emp_Lname+', '+Emp_Fname) as Name from py_emp_master where " & _
                "EmploymentType<>'R&F' and Date_Resign is null and DateHold is null and DateSuspended is null and Date_Retired is null " & _
                "order by Emp_Lname,Emp_Fname", cmbRecommendedBy, c)
            BuildCombo("select Emp_Cd,(Emp_Lname+', '+Emp_Fname) as Name from py_emp_master where " & _
                "EmploymentTYpe<>'R&F' and Date_Resign is null and DateHold is null and DateSuspended is null and Date_Retired is null " & _
                "order by Emp_Lname,Emp_Fname", cmbApprovedBy, c)

            BuildCombo("select Status_Code,Descr from py_employee_stat order by Descr", cmbStatus, c)
            BuildCombo("select Pos_Cd,Position from py_position_ref order by Position", cmbPos, c)
            BuildCombo("select Tax_Cd,Descr from py_tax_ref order by Descr", cmbTax, c)
            BuildCombo("select Rc_Cd,Descr from rc order by Descr", cmbRC, c)
            BuildCombo("select AgencyCd,AgencyName from agency order by AgencyName", cmbOffice, c)
            BuildCombo("select Div_Cd,Descr from hr_div_ref order by Descr", cmbDiv, c)
            BuildCombo("select Dept_Cd,Descr from hr_dept_ref order by Descr", cmbDept, c)
            BuildCombo("select Section_Cd,Descr from hr_section_ref order by Descr", cmbSection, c)
            BuildCombo("select Unit_Cd,Descr from hr_unit_ref order by Descr", cmbUnit, c)
            BuildCombo("select EmploymentType,Descr from hr_employment_type order by Descr", cmbType, c)
            BuildCombo("select Grade_Cd,Descr from py_grade order by Descr", cmbJobLevel, c)
            BuildCombo("select NatureCd,Descr from hr_nature order by Descr", cmbNature, c)
            cmbRecommendedBy.Items.Add("")
            cmbApprovedBy.Items.Add("")
            cmbRecommendedBy.SelectedValue = ""
            cmbApprovedBy.SelectedValue = ""
            cmbEmp.Items.Add("Please select employee...")
            cmbEmp.SelectedValue = "Please select employee..."
            c.Close()
            c.Dispose()
            cm.Dispose()
            cmdSave.Enabled = False
        End If
    End Sub
    Private Sub GetData()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim dr As SqlClient.SqlDataReader

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            cm.Dispose()
            c.Dispose()
            Exit Sub
        End Try

        cm.Connection = c
        cm.CommandText = "select * from py_emp_master where Emp_Cd='" & cmbEmp.SelectedValue & "'"
        Try
            dr = cm.ExecuteReader

            If dr.Read Then
                txtNewSal.Text = dr("Rate_Month")
                txtNewACA.Text = dr("Aca")
                txtNewRATA.Text = dr("Rata")
                txtNewPERA.Text = dr("Pera")
                txtNewMeal.Text = dr("MealAllow")

                txtCurrSal.Text = txtNewSal.Text
                txtCurrACA.Text = txtNewACA.Text
                txtCurrRATA.Text = txtNewRATA.Text
                txtCurrPERA.Text = txtNewPERA.Text
                txtCurrMeal.Text = txtNewMeal.Text

                cmbStatus.SelectedValue = dr("Emp_Status")
                cmbPos.SelectedValue = dr("Pos_Cd")
                cmbTax.SelectedValue = dr("Tax_Cd")
                cmbRC.SelectedValue = dr("Rc_Cd")
                cmbOffice.SelectedValue = dr("Agency_Cd")
                cmbDiv.SelectedValue = dr("DivCd")
                cmbDept.SelectedValue = dr("DeptCd")
                cmbSection.SelectedValue = dr("SectionCd")
                cmbUnit.SelectedValue = dr("UnitCd")
                cmbType.SelectedValue = dr("EmploymentType")
                cmbJobLevel.SelectedValue = dr("Grade_Cd")

                txtStatus.Text = cmbStatus.SelectedValue & "=>" & cmbStatus.SelectedItem.Text
                txtPos.Text = cmbPos.SelectedValue & "=>" & cmbPos.SelectedItem.Text
                txtTaxcd.Text = cmbTax.SelectedValue & "=>" & cmbTax.SelectedItem.Text
                txtRC.Text = cmbRC.SelectedValue & "=>" & cmbRC.SelectedItem.Text
                txtOffice.Text = cmbOffice.SelectedValue & "=>" & cmbOffice.SelectedItem.Text
                txtDiv.Text = cmbDiv.SelectedValue & "=>" & cmbDiv.SelectedItem.Text
                txtDept.Text = cmbDept.SelectedValue & "=>" & cmbDept.SelectedItem.Text
                txtSection.Text = cmbSection.SelectedValue & "=>" & cmbSection.SelectedItem.Text
                txtUnit.Text = cmbUnit.SelectedValue & "=>" & cmbUnit.SelectedItem.Text
                txtType.Text = cmbType.SelectedValue & "=>" & cmbType.SelectedItem.Text
                txtJobLevel.Text = cmbJobLevel.SelectedValue & "=>" & cmbJobLevel.SelectedItem.Text
            End If
            dr.Close()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to retrieve employee profile. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            c.Dispose()
            cm.Dispose()
        End Try


        'Try
        '    '''''''''Clothing
        '    txtClothing.Text = 0
        '    cm.CommandText = "SELECT TOP 1 Incentive_Cd,Incentive_Amt FROM py_incentives_dtl WHERE Emp_Cd='" & _
        '        cmbEmp.SelectedValue & "' AND Incentive_Cd='CLOTH' ORDER BY recurring DESC,todate"

        '    dr = cm.ExecuteReader
        '    If dr.Read Then
        '        txtClothing.Text = dr("Incentive_Amt")
        '    End If
        '    dr.Close()
        '    txtClothingNew.Text = txtClothing.Text
        'Catch ex As SqlClient.SqlException
        '    vScript = "alert('Error occurred while trying to retrieve Clothing Allowance. Error is: " & _
        '        ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        '    c.Close()
        '    cm.Dispose()
        '    c.Dispose()
        '    Exit Sub
        'End Try

        'Try
        '    '''''''Rice
        '    txtRice.Text = 0
        '    cm.CommandText = "SELECT TOP 1 Incentive_Cd,Incentive_Amt FROM py_incentives_dtl WHERE Emp_Cd='" & _
        '        cmbEmp.SelectedValue & "' AND Incentive_Cd='RICE' ORDER BY recurring DESC,todate DESC"
        '    dr = cm.ExecuteReader
        '    If dr.Read Then
        '        txtRice.Text = dr("Incentive_Amt")
        '    End If
        '    dr.Close()
        '    txtRiceNew.Text = txtRice.Text
        'Catch ex As SqlClient.SqlException
        '    vScript = "alert('Error occurred while trying to retrieve Rice Allowance. Error is: " & _
        '        ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        '    c.Close()
        '    cm.Dispose()
        '    c.Dispose()
        '    Exit Sub
        'End Try

        'Try
        '    '''''''''CA-Incentives
        '    txtCAIncentives.Text = 0
        '    cm.CommandText = "SELECT TOP 1 Incentive_Cd,Incentive_Amt FROM py_incentives_dtl WHERE Emp_Cd='" & _
        '        cmbEmp.SelectedValue & "' AND Incentive_Cd='CA' ORDER BY recurring DESC,todate DESC"
        '    dr = cm.ExecuteReader
        '    If dr.Read Then
        '        txtCAIncentives.Text = dr("Incentive_Amt")
        '    End If
        '    dr.Close()
        '    txtCAIncentivesNew.Text = txtCAIncentives.Text
        'Catch ex As SqlClient.SqlException
        '    vScript = "alert('Error occurred while trying to retrieve CA-Incentives. Error is: " & _
        '        ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        '    c.Close()
        '    cm.Dispose()
        '    c.Dispose()
        '    Exit Sub
        'End Try

        'Try
        '    ''''TEMPO
        '    txtTempo.Text = 0
        '    cm.CommandText = "SELECT TOP 1 Incentive_Cd,Incentive_Amt FROM py_incentives_dtl WHERE Emp_Cd='" & _
        '                     cmbEmp.SelectedValue & "' AND Incentive_Cd='TEMPO' ORDER BY recurring DESC,todate DESC"
        '    dr = cm.ExecuteReader
        '    If dr.Read Then
        '        txtTempo.Text = dr("Incentive_Amt")
        '    End If
        '    dr.Close()
        '    txtTempoNew.Text = txtTempo.Text
        'Catch ex As SqlClient.SqlException
        '    vScript = "alert('Error occurred while trying to retrieve TEMPO Allowance. Error is: " & _
        '        ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        'Finally
        '    c.Close()
        '    cm.Dispose()
        '    c.Dispose()
        'End Try
    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click

        If Page.IsValid Then
            Dim c As New SqlClient.SqlConnection(connStr)
            Dim cm As New SqlClient.SqlCommand
            Dim dr As SqlClient.SqlDataReader
            Dim vDays As Single = 1

            Try
                c.Open()
            Catch ex As System.Exception
                vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                c.Dispose()
                cm.Dispose()
                Exit Sub
            End Try

            cm.Connection = c
            cm.CommandText = "select Dates_to_Month from py_syscntrl"

            Try
                dr = cm.ExecuteReader
                If dr.Read Then
                    vDays = IIf(IsDBNull(dr("Dates_to_Month")), 1, dr("Dates_to_Month"))
                End If
                dr.Close()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to retrieve System Control. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                c.Close()
                cm.Dispose()
                c.Dispose()
                Exit Sub
            End Try

            Try
                vSQL = "insert into hr_emp_career_movement (Emp_Cd,From_Date,Remarks,Nature,Salary_Amt," & _
                    "Emp_Status,Position_Cd,TaxCd,Rc_Cd,Office_Cd,Div_Cd,Dept_Cd,Section_Cd,Unit_Cd,Aca," & _
                    "Rata,Pera,MealAllow,EmploymentType,PreparedBy,RecommendedBy,ApprovedBy,DatePrepared," & _
                    "DateRecommended,DateApproved,GradeCd,EffectivityDate) values ('" & _
                    cmbEmp.SelectedValue & "','" & Format(Now, "yyyy/MM/dd HH:mm:ss") & "','" & txtRemarks.Text & "','" & _
                    cmbNature.SelectedValue & "'," & txtCurrSal.Text & _
                    ",'" & ExtractData(txtStatus.Text) & "','" & ExtractData(txtPos.Text) & _
                    "','" & ExtractData(txtTaxcd.Text) & "','" & ExtractData(txtRC.Text) & _
                    "','" & ExtractData(txtOffice.Text) & "','" & ExtractData(txtDiv.Text) & _
                    "','" & ExtractData(txtDept.Text) & "','" & ExtractData(txtSection.Text) & _
                    "','" & ExtractData(txtUnit.Text) & "'," & Val(txtCurrACA.Text) & "," & Val(txtCurrRATA.Text) & _
                    "," & Val(txtCurrPERA.Text) & "," & Val(txtCurrMeal.Text) & ",'" & ExtractData(txtType.Text) & "','" & _
                    ExtractData(txtPreparedBy.Text) & "','" & cmbRecommendedBy.SelectedValue & _
                    "','" & cmbApprovedBy.SelectedValue & "','" & _
                    Format(CDate(txtDatePrepared.Text), "yyyy/MM/dd") & "','" & _
                    Format(CDate(txtDateRecommended.Text), "yyyy/MM/dd") & "','" & _
                    Format(CDate(txtDateApproved.Text), "yyyy/MM/dd") & "','" & _
                    ExtractData(txtJobLevel.Text) & "','" & _
                    Format(CDate(txtEffectivityDate.Text), "yyyy/MM/dd") & "')"

                'Response.Write("<br><br>" & vSQL)
                cm.CommandText = vSQL

                cm.ExecuteNonQuery()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to save Historical information. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                c.Close()
                cm.Dispose()
                c.Dispose()
                Exit Sub
            End Try


            'cm.CommandText = "INSERT INTO py_incentives_dtl(Incentive_Cd,Incentive_Amt,Emp_Cd,Recurring,FreqCd,FromDate,ToDate)" & _
            '                 "VALUES('CLOTH'," & Val(txtClothingNew.Text) & ",'" & _
            '                 cmbEmp.SelectedValue & "',1,0,'" & Format(Now, "yyyy/MM/dd") & "','" & Format(Now, "yyyy/MM/dd") & "')"
            ''Response.Write(cm.CommandText)
            'cm.ExecuteNonQuery()

            'cm.CommandText = "INSERT INTO py_incentives_dtl(Incentive_Cd,Incentive_Amt,Emp_Cd,Recurring,FreqCd,FromDate,ToDate)" & _
            '                 "VALUES('RICE'," & Val(txtRiceNew.Text) & ",'" & _
            '                 cmbEmp.SelectedValue & "',1,0,'" & Format(Now, "yyyy/MM/dd") & "','" & Format(Now, "yyyy/MM/dd") & "')"
            ''Response.Write(cm.CommandText)
            'cm.ExecuteNonQuery()

            'cm.CommandText = "INSERT INTO py_incentives_dtl(Incentive_Cd,Incentive_Amt,Emp_Cd,Recurring,FreqCd,FromDate,ToDate)" & _
            '                 "VALUES('CA'," & Val(txtCAIncentivesNew.Text) & ",'" & _
            '                 cmbEmp.SelectedValue & "',1,0,'" & Format(Now, "yyyy/MM/dd") & "','" & Format(Now, "yyyy/MM/dd") & "')"
            ''Response.Write(cm.CommandText)
            'cm.ExecuteNonQuery()

            'cm.CommandText = "INSERT INTO py_incentives_dtl(Incentive_Cd,Incentive_Amt,Emp_Cd,Recurring,FreqCd,FromDate,ToDate)" & _
            '                 "VALUES('TEMPO'," & Val(txtTempoNew.Text) & ",'" & _
            '                 cmbEmp.SelectedValue & "',1,0,'" & Format(Now, "yyyy/MM/dd") & "','" & Format(Now, "yyyy/MM/dd") & "')"
            ''Response.Write(cm.CommandText)
            'cm.ExecuteNonQuery()

            vSQL = "update py_emp_master set Rate_Month=" & txtNewSal.Text & _
                ",Rate_Year=" & Val(txtNewSal.Text) * 12 & _
                ",Rate_Day=" & Val(txtNewSal.Text) / vDays & _
                ",Aca=" & txtNewACA.Text & _
                ",Rata=" & txtNewRATA.Text & _
                ",Pera=" & txtNewPERA.Text & _
                ",MealAllow=" & txtNewMeal.Text & _
                ",Emp_Status='" & cmbStatus.SelectedValue & _
                "',Pos_Cd='" & cmbPos.SelectedValue & _
                "',Tax_Cd='" & cmbTax.SelectedValue & _
                "',Rc_Cd='" & cmbRC.SelectedValue & _
                "',Agency_Cd='" & cmbOffice.SelectedValue & _
                "',DivCd='" & cmbDiv.SelectedValue & _
                "',DeptCd='" & cmbDept.SelectedValue & _
                "',SectionCd='" & cmbSection.SelectedValue & _
                "',UnitCd='" & cmbUnit.SelectedValue & _
                "',EmploymentType='" & cmbType.SelectedValue & _
                "',Grade_Cd='" & cmbJobLevel.SelectedValue & _
                "' where Emp_Cd='" & cmbEmp.SelectedValue & "'"

            cm.CommandText = vSQL
            'Response.Write("<br><br>" & vSQL)

            Try
                cm.ExecuteNonQuery()
                vScript = "alert('Successfully saved');"
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to update Employee master file. Error is: " & ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            Finally
                c.Close()
                cm.Dispose()
                c.Dispose()
            End Try
        End If
    End Sub
    'Private Sub PrintEMR(ByRef c As SqlClient.SqlConnection)
    '    Dim cm As New SqlClient.SqlCommand
    '    Dim dr As SqlClient.SqlDataReader

    '    Dim vPrn As New VSPrinter8Lib.VSPrinter
    '    Dim vPDF As New VSPDF8Lib.VSPDF8
    '    Dim vSSS As String = "No SSS"
    '    Dim vTIN As String = "No TIN"
    '    Dim vStart As String = "Unknown Start Date"
    '    Dim vBDate As String = "No Birthdate"
    '    Dim vFormat As String = ""
    '    Dim vData As String = ""

    '    cm.Connection = c
    '    cm.CommandText = "select * from py_emp_master where Emp_Cd='" & cmbEmp.SelectedValue & "'"
    '    Try
    '        dr = cm.ExecuteReader
    '        If dr.Read Then
    '            vTIN = IIf(IsDBNull(dr("Tin")), "NO TIN", dr("Tin"))
    '            vSSS = IIf(IsDBNull(dr("Sss_No")), "NO SSS", dr("Sss_No"))
    '            If Not IsDBNull(dr("Start_Date")) And IsDate(dr("Start_Date")) Then
    '                vStart = Format(CDate(dr("Start_Date")), "MM/dd/yyyy")
    '            End If
    '            If Not IsDBNull(dr("Bday")) And IsDate(dr("Bday")) Then
    '                vBDate = Format(CDate(dr("BDay")), "MM/dd/yyyy")
    '            End If
    '        End If
    '        dr.Close()
    '    Catch ex As SqlClient.SqlException
    '        vScript = "alert('Error occurred while trying to retrieve Employee information. Error is: " & _
    '            ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
    '        cm.Dispose()
    '        Exit Sub
    '    End Try

    '    vPrn.Action = VSPrinter8Lib.ActionSettings.paStartDoc
    '    vPrn.FontBold = True
    '    vPrn.FontName = "Arial"
    '    vPrn.FontSize = 14
    '    vPrn.Header = "||" & Format(Now, "MM/dd/yyyy")
    '    vPrn.HdrFontSize = 8
    '    vPrn.TextAlign = VSPrinter8Lib.TextAlignSettings.taCenterBottom
    '    vPrn.Paragraph = "EMPLOYEE MOVEMENT REPORT"
    '    vPrn.TextAlign = VSPrinter8Lib.TextAlignSettings.taJustBottom
    '    vPrn.FontSize = 10
    '    vPrn.FontBold = False
    '    vPrn.Paragraph = "NAME: " & cmbEmp.SelectedItem.Text
    '    vPrn.Paragraph = "NATURE OF MOVEMENT: " & cmbNature.SelectedItem.Text
    '    vPrn.Paragraph = "DATE HIRED: " & vStart
    '    vPrn.Paragraph = "EFFECTIVITY DATE: " & txtEffectivityDate.Text
    '    vPrn.Paragraph = "DATE OF BIRTH: " & vBDate
    '    vPrn.Paragraph = "SSS: " & vSSS
    '    vPrn.Paragraph = "TIN: " & vTIN
    '    vFormat = "<4000|^3000|^3000;"
    '    vData = "|FROM|TO;"
    '    vPrn.FontBold = True
    '    vPrn.TableBorder = VSPrinter8Lib.TableBorderSettings.tbAll
    '    vPrn.Table = vFormat & vData
    '    vFormat = "<4000|<3000|<3000;"
    '    vPrn.FontBold = False
    '    vData = "COST CENTER|" & txtRC.Text & "|" & cmbRC.SelectedItem.Text & ";" & _
    '          "OFFICE|" & txtOffice.Text & "|" & cmbOffice.SelectedItem.Text & ";" & _
    '          "DIVISION|" & txtDiv.Text & "|" & cmbDiv.SelectedItem.Text & ";" & _
    '          "DEPARTMENT|" & txtDept.Text & "|" & cmbDept.SelectedItem.Text & ";" & _
    '          "SECTION|" & txtSection.Text & "|" & cmbSection.SelectedItem.Text & ";" & _
    '          "UNIT|" & txtUnit.Text & "|" & cmbUnit.SelectedItem.Text & ";" & _
    '          "EMPLOYMENT STATUS|" & txtStatus.Text & "|" & cmbStatus.SelectedItem.Text & ";" & _
    '          "POSITION|" & txtPos.Text & "|" & cmbPos.SelectedItem.Text & ";" & _
    '          "TAX EXEMPTION|" & txtTaxcd.Text & "|" & cmbTax.SelectedItem.Text & ";" & _
    '          "JOB LEVEL|" & txtJobLevel.Text & "|" & cmbJobLevel.SelectedItem.Text & ";" & _
    '          "RANK|" & txtType.Text & "|" & cmbType.SelectedItem.Text & ";" & _
    '          "BASIC SALARY|" & Format(Val(txtCurrSal.Text), "###,##0.00") & "|" & Format(Val(txtNewSal.Text), "###,##0.00") & ";" & _
    '          "ECOLA|" & Format(Val(txtCurrACA.Text), "##,##0.00") & "|" & Format(Val(txtNewACA.Text), "##,##0.00") & ";" & _
    '          "REP ALLOW/TRANSPO ALLOW|" & Format(Val(txtCurrRATA.Text), "##,##0.00") & "|" & Format(Val(txtNewRATA.Text), "##,##0.00") & ";" & _
    '          "TEMPO ALLOW/OT ALLOW|" & Format(Val(txtCurrPERA.Text), "##,##0.00") & "|" & Format(Val(txtNewPERA.Text), "##,##0.00") & ";" & _
    '          "MEAL ALLOW|" & Format(Val(txtCurrMeal.Text), "##,##0.00") & "|" & Format(Val(txtNewMeal.Text), "##,##0.00") & ";"
    '    vPrn.Table = vFormat & vData
    '    vPrn.FontBold = True
    '    vData = "TOTAL==>|" & Format(Val(txtCurrSal.Text) + Val(txtCurrACA.Text) + Val(txtCurrRATA.Text) + _
    '          Val(txtCurrPERA.Text) + Val(txtCurrMeal.Text), "###,##0.00") & "|" & _
    '          Format(Val(txtNewSal.Text) + Val(txtNewACA.Text) + Val(txtNewRATA.Text) + _
    '          Val(txtNewPERA.Text) + Val(txtNewMeal.Text), "###,##0.00") & ";"
    '    vPrn.FontBold = False
    '    vPrn.Table = vFormat & vData
    '    vPrn.Paragraph = vbCrLf & "Remarks: " & txtRemarks.Text
    '    vFormat = "<4000|<3000|<3000;"
    '    vData = "PREPARED BY:|RECOMMENDED BY:|APPROVED BY:;" & vbCrLf & vbCrLf & vbCrLf & _
    '             txtPreparedBy.Text & "|" & vbCrLf & vbCrLf & vbCrLf & cmbRecommendedBy.SelectedItem.Text & _
    '             "|" & vbCrLf & vbCrLf & vbCrLf & _
    '             cmbApprovedBy.SelectedItem.Text & ";" & _
    '             txtDatePrepared.Text & "|" & txtDateRecommended.Text & "|" & txtDateApproved.Text & ";"

    '    vPrn.FontBold = True
    '    vPrn.Table = vFormat & vData
    '    vPrn.Action = VSPrinter8Lib.ActionSettings.paEndDoc
    '    vPDF.ConvertDocument(vPrn, Server.MapPath("") & "\downloads\" & Session.SessionID & "-emr.pdf")
    '    vScript = "alert('Changes were successfully saved in the career movement archives. Click OK to " & _
    '        "print the EMR Slilp...'); " & _
    '        "viewwin=window.open('downloads/" & Session.SessionID & _
    '        "-emr.pdf','viewwin','toolbar=no,location=no,width=800,height=600,top=50,left=100,scrollbars=yes');"
    '    vPDF = Nothing
    '    vPrn = Nothing
    '    cm.Dispose()
    'End Sub
    Protected Sub cmdSave_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Init
        cmdSave.Attributes.Add("onclick", "return ask();")
    End Sub

    Protected Sub vldPage_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles vldPage.ServerValidate
       
        'cm.CommandText = "select TOP 1 * from hr_emp_career_movement where Emp_Cd='" & _
        '    cmbEmp.SelectedValue & "' and From_Date='" & _
        '    Format(Now, "yyyy/MM/dd") & "'"
        'dr = cm.ExecuteReader
        'If dr.Read Then
        '    vOk = False
        'End If
        'dr.Close()
        'cm.Dispose()
        'c.Close()
        'If Not vOk Then
        '    vScript = "alert('A career movement has already been set for employee " & _
        '        cmbEmp.SelectedValue & " for transaction date " & _
        '        Format(Now, "yyyy/MM/dd") & ". You must first undo the existing transaction " & _
        '        "before you can re-update the new values.');"
        '    args.IsValid = False
        '    Exit Sub
        'End If

        If Not IsNumeric(txtNewSal.Text) Then
            vScript = "alert('New monthly salary field should be numeric!');"
            args.IsValid = False
            Exit Sub
        End If
        If Not IsNumeric(txtNewACA.Text) Then
            vScript = "alert('New ACA/ECOLA field should be numeric!');"
            args.IsValid = False
            Exit Sub
        End If
        If Not IsNumeric(txtNewRATA.Text) Then
            vScript = "alert('New Rep. Allow/Transpo. Allow. field should not be empty!');"
            args.IsValid = False
            Exit Sub
        End If
        If Not IsNumeric(txtNewPERA.Text) Then
            vScript = "alert('New PERA field should not be empty!');"
            args.IsValid = False
            Exit Sub
        End If
        If Not IsNumeric(txtNewMeal.Text) Then
            vScript = "alert('New Meal Allow field should not be empty!');"
            args.IsValid = False
            Exit Sub
        End If
        ''''''''''' now ensure that values entered should be at least greater than or equal to the current values
        If Val(txtNewSal.Text) < Val(txtCurrSal.Text) Then
            vScript = "alert('New Salary Field should be at least equal to or greater than the current salary.');"
            args.IsValid = False
            Exit Sub
        End If

        If Not IsDate(txtDatePrepared.Text) Then
            vScript = "alert('Invalid date format in Date Prepared field. Please correct the error.');"
            args.IsValid = False
            Exit Sub
        End If
        If Not IsDate(txtDateRecommended.Text) Then
            vScript = "alert('Invalid date format in Date Recommended field. Please correct the error.');"
            args.IsValid = False
            Exit Sub
        End If
        If Not IsDate(txtDateApproved.Text) Then
            vScript = "alert('Invalid date format in Date Approved field. Please correct the error.');"
            args.IsValid = False
            Exit Sub
        End If
        If cmbRecommendedBy.SelectedValue = "" Then
            vScript = "alert('You must first select the employee who recommended the request.');"
            args.IsValid = False
            Exit Sub
        End If
        If cmbApprovedBy.SelectedValue = "" Then
            vScript = "alert('You must first select the employee who approved the request.');"
            args.IsValid = False
            Exit Sub
        End If
        txtNewSal.Text.Replace(",", "")
        txtNewACA.Text.Replace(",", "")
        txtNewRATA.Text.Replace(",", "")
        txtNewPERA.Text.Replace(",", "")
        txtNewMeal.Text.Replace(",", "")
        args.IsValid = True
    End Sub

    Protected Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdUpdate.Click
        Server.Transfer("massupdateemr.aspx")
    End Sub

    Protected Sub cmbEmp_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbEmp.SelectedIndexChanged
        If cmbEmp.SelectedValue = "Please select employee..." Then
            vScript = "alert('Please select an employee first...');"
            cmdSave.Enabled = False
        Else
            cmdSave.Enabled = True
            GetData()
        End If
    End Sub

    Protected Sub txtEffectivityDate_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtEffectivityDate.Init
        txtEffectivityDate.Attributes.Add("onfocus", "showCalendarControl(this);")
    End Sub

    Protected Sub txtDateRecommended_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtDateRecommended.Init
        txtDateRecommended.Attributes.Add("onfocus", "showCalendarControl(this);")
    End Sub

    Protected Sub txtDateApproved_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtDateApproved.Init
        txtDateApproved.Attributes.Add("onfocus", "showCalendarControl(this);")
    End Sub
End Class
