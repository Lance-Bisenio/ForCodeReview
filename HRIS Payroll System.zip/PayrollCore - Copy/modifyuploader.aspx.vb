﻿Imports denaro.fis
Partial Class modifyuploader
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Dim vValue As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            vScript = "alert('Your login session has expired. Please re-login again.'); window.close();"
            Exit Sub
        End If

        vValue = Request.Item("id")

        If Not IsPostBack Then
            If vValue <> "" Then 'edit mode
                Dim c As New sqlclient.sqlConnection(connStr)
                Dim cm As New sqlclient.sqlCommand
                Dim rs As sqlclient.sqlDataReader
                Try
                    c.Open()
                Catch ex As sqlclient.sqlException
                    vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                        ex.Message.Replace("'", "").Replace(vbCrLf, "") & "');"
                    c.Dispose()
                    cm.Dispose()
                    Exit Sub
                End Try
                cm.Connection = c
                cm.CommandText = "select * from _db where ProfileCd='" & vValue & "'"
                Try
                    rs = cm.ExecuteReader
                    If rs.Read Then
                        txtProfileCd.Text = rs("ProfileCd")
                        txtProfileName.Text = rs("ProfileName")
                        cmbTarget.SelectedValue = rs("TableName")
                    End If
                    rs.Close()
                Catch ex As sqlclient.sqlException
                    vScript = "alert('Error occurred while trying to retrieve the database. Error is: " & _
                        ex.Message.Replace("'", "").Replace(vbCrLf, "") & "');"
                Finally
                    c.Close()
                    cm.Dispose()
                    c.Dispose()
                End Try
            End If
        End If
    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        Dim c As New sqlclient.sqlConnection(connStr)
        Dim cm As New sqlclient.sqlCommand

        Try
            c.Open()
        Catch ex As sqlclient.sqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace("'", "").Replace(vbCrLf, "") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        cm.Connection = c

        Try
            If vValue = "" Then 'add mode
                cm.CommandText = "insert into _db (ProfileCd,ProfileName,TableName) values ('" & _
                    txtProfileCd.Text & "','" & txtProfileName.Text & "','" & cmbTarget.SelectedValue & "')"
                cm.ExecuteNonQuery()
            Else
                cm.CommandText = "update _field set ProfileCd='" & txtProfileCd.Text & _
                    "',TableName='" & cmbTarget.SelectedValue & "' where ProfileCd='" & vValue & _
                    "' and TableName='" & cmbTarget.SelectedValue & "'"
                cm.ExecuteNonQuery()
                cm.CommandText = "update _db set ProfileCd='" & txtProfileCd.Text & _
                    "',ProfileName='" & txtProfileName.Text & "',TableName='" & _
                    cmbTarget.SelectedValue & "' where ProfileCd='" & vValue & "'"
                cm.ExecuteNonQuery()
            End If

            vScript = "alert('Changes were successfully saved. Click the Ok button to configure the fields list.'); " & _
                "window.location='modifyuploader_2.aspx?id=" & txtProfileCd.Text & "';"
        Catch ex As sqlclient.sqlException
            vScript = "alert('" & ex.Message.Replace("'", "").Replace(vbCrLf, "") & "');"
        Finally
            c.Close()
            cm.Dispose()
            c.Dispose()
        End Try
    End Sub
End Class
