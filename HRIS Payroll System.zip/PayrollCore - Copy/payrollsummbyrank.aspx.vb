﻿Imports denaro.fis
Partial Class payrollsummbyrank
    Inherits System.Web.UI.Page
    Public vDump As String = ""
    Public vScript As String = ""
    Structure Register
        Dim Rank As String
        Dim BasicPay As Decimal
        Dim NetPay As Decimal
        Dim Gross As Decimal
        Dim TotDed As Decimal
        Dim Aca As Decimal
        Dim Rata As Decimal
        Dim Pera As Decimal
        Dim Meal As Decimal
        Dim Senior As Decimal
        Dim Absences As Decimal
        Dim Tardiness As Decimal
        Dim OT As Decimal
        Dim ND As Decimal
        Dim RD As Decimal
        Dim Holiday As Decimal
        Dim UnionDues As Decimal
        Dim Tax As Decimal
        Dim Sss As Decimal
        Dim PagIbig As Decimal
        Dim Phic As Decimal
        Dim Incent() As Decimal
        Dim Deduct() As Decimal
    End Structure
    
    Protected Sub cmbClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbClose.Click
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = Nothing Or Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If
        If Not IsPostBack Then
            Dim c As New SqlClient.SqlConnection(connStr)
            Dim cm As New SqlClient.SqlCommand
            Dim rs As SqlClient.SqlDataReader

            Try
                c.Open()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                c.Dispose()
                cm.Dispose()
                Exit Sub
            End Try

            cm.Connection = c
            cm.CommandText = "select * from agency order by AgencyName"
            cmbOfc.Items.Clear()
            Try
                rs = cm.ExecuteReader
                Do While rs.Read
                    cmbOfc.Items.Add(New ListItem(rs("AgencyName"), rs("AgencyCd")))
                Loop
                rs.Close()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to retrieve Office List. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                c.Close()
                c.Dispose()
                cm.Dispose()
                Exit Sub
            End Try

            cm.CommandText = "select * from currency_ref order by CurrName"
            cmbCurr.Items.Clear()
            Try
                rs = cm.ExecuteReader
                Do While rs.Read
                    cmbCurr.Items.Add(New ListItem(rs("CurrName"), rs("CurrCd")))
                Loop
                rs.Close()
            Catch ex As SqlClient.SqlException
                vScript = "alert('Error occurred while trying to retrieve Currencies List. Error is: " & _
                    ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            Finally
                c.Close()
                c.Dispose()
                cm.Dispose()
            End Try

            If cmbCurr.Items.Count > 0 Then
                cmbCurr.SelectedIndex = 0
            End If

            If cmbOfc.Items.Count > 1 Then
                cmbOfc.Items.Add("All")
                cmbOfc.SelectedValue = "All"
            ElseIf cmbOfc.Items.Count > 0 Then
                cmbOfc.SelectedIndex = 0
            End If

            cmbYear.Items.Clear()
            For ictr As Integer = Now.Year To Now.Year - 5 Step -1
                cmbYear.Items.Add(ictr)
            Next

            cmbYear.SelectedIndex = 0
            GetPayOutList()
        End If
    End Sub
    Private Sub GetPayOutList()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        cm.Connection = c

        cm.CommandText = "select distinct PayDate from py_report where Year(PayDate)=" & cmbYear.SelectedValue

        If Not chkPost.Checked Then
            cm.CommandText += " and Posted=1"
        End If
        cm.CommandText += " order by PayDate desc "

        Try
            rs = cm.ExecuteReader
            cmbPayDate.Items.Clear()
            Do While rs.Read
                cmbPayDate.Items.Add(Format(CDate(rs("PayDate")), "MM/dd/yyyy"))
            Loop
            rs.Close()
            If cmbPayDate.Items.Count = 0 Then
                vScript = "alert('No single payroll register found on the selected year.');"
                cmdRefresh.Enabled = False
            Else
                cmdRefresh.Enabled = True
            End If
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to build Pay Out Dates. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            c.Dispose()
            cm.Dispose()
        End Try
    End Sub

    Protected Sub cmbYear_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbYear.SelectedIndexChanged, _
        chkPost.CheckedChanged
        GetPayOutList()
    End Sub

    Protected Sub cmdRefresh_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdRefresh.Click
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim vSQL As String = ""
        Dim da As New SqlClient.SqlDataAdapter
        Dim ds As New DataSet
        Dim iCtr As Integer
        Dim vData() As Register
        Dim vContent As New StringBuilder
        Dim vGrossPay As Decimal = 0
        Dim vDeductions As Decimal = 0
        Dim vClass As String = "odd"
        Dim vTmp As Decimal = 0

        lblCompany.Text = cmbOfc.SelectedItem.Text
        lblPeriod.Text = cmbPayDate.SelectedValue

        vSQL = "select EmploymentType,SUM(BasicRate) as BasicRate, SUM(amount_per) as NetPay,SUM(Aca) as ACA," & _
            "SUM(Rata) as Rata,SUM(Pera) as Pera,SUM(Absent) as absences, SUM(Tardiness) as Tardiness, SUM(A1) as OT, " & _
            "SUM(A2+A3+A4+B2+B4+C2+C4+D2+D4+E2+E4+F2+F4+NdReg) AS ND,SUM(E1+E3) AS RDPay," & _
            "SUM(B1+B3+C1+C3+D1+D3+F1+F3) AS HolidayPay,SUM(MealAllow) as Meal,SUM(SeniorAllowance) As SeniorAllowance,"
        For iCtr = 1 To 60
            vSQL += "sum(Other_Incent" & iCtr & ") as Incent" & iCtr & _
                ",sum(Other_Deduct" & iCtr & ") as Deduct" & iCtr & ","
        Next
        vSQL += "SUM(With_Tax) as Tax,SUM(SSS_Per) as SSSEmp, SUM(Sss_Gov) as SSSEmr," & _
            "SUM(Pagibig_Per) as PagIbigEmp,SUM(Pagibig_Gov) as PagibigEmr," & _
            "SUM(Medicare_Per) as PHICEmp, SUM(Medicare_Gov) as PHICEmr, SUM(Ec) as EC, " & _
            "SUM(UnionDues) as UnionDues " & _
            "from py_report where PayDate='" & Format(CDate(cmbPayDate.SelectedValue), "yyyy/MM/dd") & _
            "' and NetPayCurrCd='" & cmbCurr.SelectedValue & "' group by EmploymentType order by EmploymentType "

        Try
            da = New SqlClient.SqlDataAdapter(vSQL, c)
            da.Fill(ds, "register")
            da = New SqlClient.SqlDataAdapter("select * from py_syscntrl", c)
            da.Fill(ds, "syscntrl")

            ReDim vData(ds.Tables("register").Rows.Count)

            For iCtr = 0 To ds.Tables("register").Rows.Count - 1
                With ds.Tables("register").Rows(iCtr)
                    vData(iCtr).Rank = .Item("EmploymentType").ToString
                    vData(iCtr).BasicPay = .Item("BasicRate").ToString
                    vData(iCtr).NetPay = .Item("NetPay").ToString
                    vData(iCtr).Aca = .Item("ACA").ToString
                    vData(iCtr).Rata = .Item("Rata").ToString
                    vData(iCtr).Pera = .Item("Pera").ToString
                    vData(iCtr).Absences = .Item("Absences").ToString
                    vData(iCtr).Tardiness = .Item("Tardiness").ToString
                    vData(iCtr).OT = .Item("OT").ToString
                    vData(iCtr).ND = .Item("ND").ToString
                    vData(iCtr).RD = .Item("RDPay").ToString
                    vData(iCtr).Holiday = .Item("HolidayPay").ToString
                    vData(iCtr).Meal = .Item("Meal").ToString
                    vData(iCtr).Senior = .Item("SeniorAllowance").ToString
                    vData(iCtr).UnionDues = .Item("UnionDues").ToString
                    vData(iCtr).Tax = .Item("Tax").ToString
                    vData(iCtr).Sss = .Item("SSSEmp").ToString
                    vData(iCtr).PagIbig = .Item("PagIbigEmp").ToString
                    vData(iCtr).Phic = .Item("PHICEmp").ToString
                    ReDim vData(iCtr).Incent(60)
                    ReDim vData(iCtr).Deduct(60)
                    vData(iCtr).Gross = vData(iCtr).BasicPay + vData(iCtr).Aca + vData(iCtr).Rata + vData(iCtr).Pera + _
                        vData(iCtr).Absences + vData(iCtr).Tardiness + vData(iCtr).OT + vData(iCtr).ND + vData(iCtr).RD + _
                        vData(iCtr).Holiday + vData(iCtr).Meal + vData(iCtr).Senior
                    vData(iCtr).TotDed = vData(iCtr).UnionDues + vData(iCtr).Tax + vData(iCtr).Sss + vData(iCtr).PagIbig + _
                        vData(iCtr).Phic

                    For idx As Integer = 1 To 60
                        vData(iCtr).Incent(idx - 1) = .Item("Incent" & idx).ToString
                        vData(iCtr).Deduct(idx - 1) = .Item("Deduct" & idx).ToString
                        vData(iCtr).Gross += Val(.Item("Incent" & idx).ToString)
                        vData(iCtr).TotDed += Val(.Item("Deduct" & idx).ToString)
                    Next
                End With
            Next

            'now dump to string 
            vContent.AppendLine("<tr class='titleBar'><th>Particulars</th>")
            For iCtr = 0 To UBound(vData)
                If vData(iCtr).Rank <> "" Then
                    vContent.AppendLine("<th>" & vData(iCtr).Rank & "</th>")
                End If
            Next
            vContent.AppendLine("<th>Total</th></tr>")

            vContent.AppendLine("<tr class='activeBar'><td class='labelC' colspan='" & UBound(vData) + 2 & "'><strong>Compensation</strong></td></tr>")

            'basic salary
            vTmp = 0
            For iCtr = 0 To UBound(vData)
                If vData(iCtr).Rank <> "" Then
                    vTmp += vData(iCtr).BasicPay
                End If
            Next
            If vTmp <> 0 Then
                vContent.AppendLine("<tr class='odd'><td class='labelL'>Basic Salary:</td>")
                For iCtr = 0 To UBound(vData)
                    If vData(iCtr).Rank <> "" Then
                        vContent.Append("<td class='labelR'>" & Format(vData(iCtr).BasicPay, "###,###,##0.00") & "</td>")
                    End If
                Next
                vContent.Append("<td class='labelR'>" & Format(vTmp, "###,###,##0.00") & "</td></tr>")
            End If
            
            'absences
            vTmp = 0
            For iCtr = 0 To UBound(vData)
                If vData(iCtr).Rank <> "" Then
                    vTmp += vData(iCtr).Absences
                End If
            Next
            If vTmp <> 0 Then
                vContent.AppendLine("<tr class='even'><td class='labelL'>Absences:</td>")
                For iCtr = 0 To UBound(vData)
                    If vData(iCtr).Rank <> "" Then
                        vContent.Append("<td class='labelR'>" & Format(vData(iCtr).Absences, "###,###,##0.00") & "</td>")
                    End If
                Next
                vContent.Append("<td class='labelR'>" & Format(vTmp, "###,###,##0.00") & "</td></tr>")
            End If
            
            'tardiness & undertime
            vTmp = 0
            For iCtr = 0 To UBound(vData)
                If vData(iCtr).Rank <> "" Then
                    vTmp += vData(iCtr).Tardiness
                End If
            Next
            If vTmp <> 0 Then
                vContent.AppendLine("<tr class='odd'><td class='labelL'>Tardiness & Undertime:</td>")
                For iCtr = 0 To UBound(vData)
                    If vData(iCtr).Rank <> "" Then
                        vContent.Append("<td class='labelR'>" & Format(vData(iCtr).Tardiness, "###,###,##0.00") & "</td>")
                    End If
                Next
                vContent.Append("<td class='labelR'>" & Format(vTmp, "###,###,##0.00") & "</td></tr>")
            End If
            
            'Overtime
            vTmp = 0
            For iCtr = 0 To UBound(vData)
                If vData(iCtr).Rank <> "" Then
                    vTmp += vData(iCtr).OT
                End If
            Next
            If vTmp <> 0 Then
                vContent.AppendLine("<tr class='even'><td class='labelL'>Overtime:</td>")
                For iCtr = 0 To UBound(vData)
                    If vData(iCtr).Rank <> "" Then
                        vContent.Append("<td class='labelR'>" & Format(vData(iCtr).OT, "###,###,##0.00") & "</td>")
                    End If
                Next
                vContent.Append("<td class='labelR'>" & Format(vTmp, "###,###,##0.00") & "</td></tr>")
            End If
            
            'ND
            vTmp = 0
            For iCtr = 0 To UBound(vData)
                If vData(iCtr).Rank <> "" Then
                    vTmp += vData(iCtr).ND
                End If
            Next
            If vTmp <> 0 Then
                vContent.AppendLine("<tr class='odd'><td class='labelL'>Night Diff.:</td>")
                For iCtr = 0 To UBound(vData)
                    If vData(iCtr).Rank <> "" Then
                        vContent.Append("<td class='labelR'>" & Format(vData(iCtr).ND, "###,###,##0.00") & "</td>")
                    End If
                Next
                vContent.Append("<td class='labelR'>" & Format(vTmp, "###,###,##0.00") & "</td></tr>")
            End If
            
            'restday
            vTmp = 0
            For iCtr = 0 To UBound(vData)
                If vData(iCtr).Rank <> "" Then
                    vTmp += vData(iCtr).RD
                End If
            Next
            If vTmp <> 0 Then
                vContent.AppendLine("<tr class='even'><td class='labelL'>Restday:</td>")
                For iCtr = 0 To UBound(vData)
                    If vData(iCtr).Rank <> "" Then
                        vContent.Append("<td class='labelR'>" & Format(vData(iCtr).RD, "###,###,##0.00") & "</td>")
                    End If
                Next
                vContent.Append("<td class='labelR'>" & Format(vTmp, "###,###,##0.00") & "</td></tr>")
            End If
            
            'holiday
            vTmp = 0
            For iCtr = 0 To UBound(vData)
                If vData(iCtr).Rank <> "" Then
                    vTmp += vData(iCtr).Holiday
                End If
            Next
            If vTmp <> 0 Then
                vContent.AppendLine("<tr class='odd'><td class='labelL'>Holiday Pay:</td>")
                For iCtr = 0 To UBound(vData)
                    If vData(iCtr).Rank <> "" Then
                        vContent.Append("<td class='labelR'>" & Format(vData(iCtr).Holiday, "###,###,##0.00") & "</td>")
                    End If
                Next
                vContent.Append("<td class='labelR'>" & Format(vTmp, "###,###,##0.00") & "</td></tr>")
            End If
            
            'senior allowance
            vTmp = 0
            For iCtr = 0 To UBound(vData)
                If vData(iCtr).Rank <> "" Then
                    vTmp += vData(iCtr).Senior
                End If
            Next
            If vTmp <> 0 Then
                vContent.AppendLine("<tr class='even'><td class='labelL'>Senior Allowance:</td>")
                For iCtr = 0 To UBound(vData)
                    If vData(iCtr).Rank <> "" Then
                        vContent.Append("<td class='labelR'>" & Format(vData(iCtr).Senior, "###,###,##0.00") & "</td>")
                    End If
                Next
                vContent.Append("<td class='labelR'>" & Format(vTmp, "###,###,##0.00") & "</td></tr>")
            End If
            
            'meal
            vTmp = 0
            For iCtr = 0 To UBound(vData)
                If vData(iCtr).Rank <> "" Then
                    vTmp += vData(iCtr).Meal
                End If
            Next
            If vTmp <> 0 Then
                vContent.AppendLine("<tr class='odd'><td class='labelL'>Meal Allowance:</td>")
                For iCtr = 0 To UBound(vData)
                    If vData(iCtr).Rank <> "" Then
                        vContent.Append("<td class='labelR'>" & Format(vData(iCtr).Meal, "###,###,##0.00") & "</td>")
                    End If
                Next
                vContent.Append("<td class='labelR'>" & Format(vTmp, "###,###,##0.00") & "</td></tr>")
            End If
            
            'ACA
            vTmp = 0
            For iCtr = 0 To UBound(vData)
                If vData(iCtr).Rank <> "" Then
                    vTmp += vData(iCtr).Aca
                End If
            Next
            If vTmp <> 0 Then
                vContent.AppendLine("<tr class='even'><td class='labelL'>ACA/COLA:</td>")
                For iCtr = 0 To UBound(vData)
                    If vData(iCtr).Rank <> "" Then
                        vContent.Append("<td class='labelR'>" & Format(vData(iCtr).Aca, "###,###,##0.00") & "</td>")
                    End If
                Next
                vContent.Append("<td class='labelR'>" & Format(vTmp, "###,###,##0.00") & "</td></tr>")
            End If
            
            'rata
            vTmp = 0
            For iCtr = 0 To UBound(vData)
                If vData(iCtr).Rank <> "" Then
                    vTmp += vData(iCtr).Rata
                End If
            Next
            If vTmp <> 0 Then
                vContent.AppendLine("<tr class='odd'><td class='labelL'>RA/TA:</td>")
                For iCtr = 0 To UBound(vData)
                    If vData(iCtr).Rank <> "" Then
                        vContent.Append("<td class='labelR'>" & Format(vData(iCtr).Rata, "###,###,##0.00") & "</td>")
                    End If
                Next
                vContent.Append("<td class='labelR'>" & Format(vTmp, "###,###,##0.00") & "</td></tr>")
            End If
            
            'pera
            vTmp = 0
            For iCtr = 0 To UBound(vData)
                If vData(iCtr).Rank <> "" Then
                    vTmp += vData(iCtr).Pera
                End If
            Next
            If vTmp <> 0 Then
                vContent.AppendLine("<tr class='even'><td class='labelL'>PERA:</td>")
                For iCtr = 0 To UBound(vData)
                    If vData(iCtr).Rank <> "" Then
                        vContent.Append("<td class='labelR'>" & Format(vData(iCtr).Pera, "###,###,##0.00") & "</td>")
                    End If
                Next
                vContent.Append("<td class='labelR'>" & Format(vTmp, "###,###,##0.00") & "</td></tr>")
            End If

            'insert other income 
            vClass = "odd"
            For idx As Integer = 0 To 59
                vTmp = 0
                For iCtr = 0 To UBound(vData)
                    If vData(iCtr).Rank <> "" Then
                        vTmp += vData(iCtr).Incent(idx)
                    End If
                Next
                If vTmp <> 0 Then
                    vContent.AppendLine("<tr class='" & vClass & "'><td class='labelL'>" & _
                    ds.Tables("syscntrl").Rows(0).Item("OthIncent" & idx + 1 & "Cd").ToString & ":</td>")
                    For iCtr = 0 To UBound(vData)
                        If vData(iCtr).Rank <> "" Then
                            vContent.Append("<td class='labelR'>" & Format(vData(iCtr).Incent(idx), "###,###,##0.00") & "</td>")
                        End If
                    Next
                    vContent.Append("<td class='labelR'>" & Format(vTmp, "###,###,##0.00") & "</td></tr>")
                    vClass = IIf(vClass = "odd", "even", "odd")
                End If
            Next
            
            'Total Compensation
            vTmp = 0
            For iCtr = 0 To UBound(vData)
                If vData(iCtr).Rank <> "" Then
                    vTmp += vData(iCtr).Gross
                End If
            Next
            If vTmp <> 0 Then
                vContent.AppendLine("<tr class='activeBar'><td class='labelL'>Total Compesnation:</td>")
                For iCtr = 0 To UBound(vData)
                    If vData(iCtr).Rank <> "" Then
                        vContent.Append("<td class='labelR'>" & Format(vData(iCtr).Gross, "###,###,##0.00") & "</td>")
                    End If
                Next
                vContent.Append("<td class='labelR'>" & Format(vTmp, "###,###,##0.00") & "</td></tr>")
            End If
            
            'deductions
            vContent.AppendLine("<tr class='activeBar'><td class='labelC' colspan='" & UBound(vData) + 2 & "'><strong>Deductions</strong></td></tr>")

            'tax
            vTmp = 0
            For iCtr = 0 To UBound(vData)
                If vData(iCtr).Rank <> "" Then
                    vTmp += vData(iCtr).Tax
                End If
            Next
            If vTmp <> 0 Then
                vContent.AppendLine("<tr class='odd'><td class='labelL'>Withholding Tax:</td>")
                For iCtr = 0 To UBound(vData)
                    If vData(iCtr).Rank <> "" Then
                        vContent.Append("<td class='labelR'>" & Format(vData(iCtr).Tax, "###,###,##0.00") & "</td>")
                    End If
                Next
                vContent.Append("<td class='labelR'>" & Format(vTmp, "###,###,##0.00") & "</td></tr>")
            End If
            
            'SSS
            vTmp = 0
            For iCtr = 0 To UBound(vData)
                If vData(iCtr).Rank <> "" Then
                    vTmp += vData(iCtr).Sss
                End If
            Next
            If vTmp <> 0 Then
                vContent.AppendLine("<tr class='even'><td class='labelL'>SSS:</td>")
                For iCtr = 0 To UBound(vData)
                    If vData(iCtr).Rank <> "" Then
                        vContent.Append("<td class='labelR'>" & Format(vData(iCtr).Sss, "###,###,##0.00") & "</td>")
                    End If
                Next
                vContent.Append("<td class='labelR'>" & Format(vTmp, "###,###,##0.00") & "</td></tr>")
            End If
            
            'pagibig
            vTmp = 0
            For iCtr = 0 To UBound(vData)
                If vData(iCtr).Rank <> "" Then
                    vTmp += vData(iCtr).PagIbig
                End If
            Next
            If vTmp <> 0 Then
                vContent.AppendLine("<tr class='odd'><td class='labelL'>PAGIBIG:</td>")
                For iCtr = 0 To UBound(vData)
                    If vData(iCtr).Rank <> "" Then
                        vContent.Append("<td class='labelR'>" & Format(vData(iCtr).PagIbig, "###,###,##0.00") & "</td>")
                    End If
                Next
                vContent.Append("<td class='labelR'>" & Format(vTmp, "###,###,##0.00") & "</td></tr>")
            End If
            
            'phic
            vTmp = 0
            For iCtr = 0 To UBound(vData)
                If vData(iCtr).Rank <> "" Then
                    vTmp += vData(iCtr).Phic
                End If
            Next
            If vTmp <> 0 Then
                vContent.AppendLine("<tr class='even'><td class='labelL'>Philhealth:</td>")
                For iCtr = 0 To UBound(vData)
                    If vData(iCtr).Rank <> "" Then
                        vContent.Append("<td class='labelR'>" & Format(vData(iCtr).Phic, "###,###,##0.00") & "</td>")
                    End If
                Next
                vContent.Append("<td class='labelR'>" & Format(vTmp, "###,###,##0.00") & "</td></tr>")
            End If
            
            'union dues
            vTmp = 0
            For iCtr = 0 To UBound(vData)
                If vData(iCtr).Rank <> "" Then
                    vTmp += vData(iCtr).UnionDues
                End If
            Next
            If vTmp <> 0 Then
                vContent.AppendLine("<tr class='odd'><td class='labelL'>Union Dues:</td>")
                For iCtr = 0 To UBound(vData)
                    If vData(iCtr).Rank <> "" Then
                        vContent.Append("<td class='labelR'>" & Format(vData(iCtr).UnionDues, "###,###,##0.00") & "</td>")
                    End If
                Next
                vContent.Append("<td class='labelR'>" & Format(vTmp, "###,###,##0.00") & "</td></tr>")
            End If
            

            'insert other deductions
            vClass = "even"
            For idx As Integer = 0 To 59
                vTmp = 0
                For iCtr = 0 To UBound(vData)
                    If vData(iCtr).Rank <> "" Then
                        vTmp += vData(iCtr).Deduct(idx)
                    End If
                Next
                If vTmp <> 0 Then
                    vContent.AppendLine("<tr class='" & vClass & "'><td class='labelL'>" & _
                    ds.Tables("syscntrl").Rows(0).Item("OthDed" & idx + 1 & "Cd").ToString & ":</td>")
                    For iCtr = 0 To UBound(vData)
                        If vData(iCtr).Rank <> "" Then
                            vContent.Append("<td class='labelR'>" & Format(vData(iCtr).Deduct(idx), "###,###,##0.00") & "</td>")
                        End If
                    Next
                    vContent.Append("<td class='labelR'>" & Format(vTmp, "###,###,##0.00") & "</td></tr>")
                    vClass = IIf(vClass = "odd", "even", "odd")
                End If
            Next

            'total deductions
            vTmp = 0
            For iCtr = 0 To UBound(vData)
                If vData(iCtr).Rank <> "" Then
                    vTmp += vData(iCtr).TotDed
                End If
            Next
            If vTmp <> 0 Then
                vContent.AppendLine("<tr class='activeBar'><td class='labelL'>Total Deductions:</td>")
                For iCtr = 0 To UBound(vData)
                    If vData(iCtr).Rank <> "" Then
                        vContent.Append("<td class='labelR'>" & Format(vData(iCtr).TotDed, "###,###,##0.00") & "</td>")
                    End If
                Next
                vContent.Append("<td class='labelR'>" & Format(vTmp, "###,###,##0.00") & "</td></tr>")
            End If

            'net pay(
            vTmp = 0
            For iCtr = 0 To UBound(vData)
                If vData(iCtr).Rank <> "" Then
                    vTmp += vData(iCtr).NetPay
                End If
            Next
            If vTmp <> 0 Then
                vContent.AppendLine("<tr class='activeBar'><td class='labelL'><strong>Net Pay:</strong></td>")
                For iCtr = 0 To UBound(vData)
                    If vData(iCtr).Rank <> "" Then
                        vContent.Append("<td class='labelR'><strong>" & Format(vData(iCtr).NetPay, "###,###,##0.00") & "</strong></td>")
                    End If
                Next
                vContent.Append("<td class='labelR'><strong>" & Format(vTmp, "###,###,##0.00") & "</strong></td></tr>")
            End If

            vDump = vContent.ToString
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to retrieve payroll register. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Dispose()
            ds.Dispose()
            da.Dispose()
        End Try
    End Sub
End Class
