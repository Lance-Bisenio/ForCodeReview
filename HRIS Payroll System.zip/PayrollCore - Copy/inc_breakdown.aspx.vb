﻿Imports denaro.fis
Partial Class inc_breakdown
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Public vData As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Or Session("uid") = Nothing Then
            vScript = "alert('Your login session has expired. Please re-login again.'); window.close();"
            Exit Sub
        End If

        If Not IsPostBack Then
            If Request.Item("m") = "inc" Then
                lblTitle.Text = "Other Custom Income"
                getIncDetails()
            Else
                lblTitle.Text = "Other Custom Deductions"
                getDedDetails()
            End If
        End If
    End Sub
    Private Sub getIncDetails()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cmRef As New SqlClient.SqlCommand
        Dim cmRef2 As New SqlClient.SqlCommand
        Dim rsRef As SqlClient.SqlDataReader
        Dim rsRef2 As SqlClient.SqlDataReader
        Dim rs As SqlClient.SqlDataReader
        Dim vDescr As String
        Dim iCtr As Integer
        Dim vClass As String = "odd"
        Dim vTotal As Decimal = 0

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connec to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            cmRef.Dispose()
            Exit Sub
        End Try

        vData = ""

        cm.Connection = c
        cmRef.Connection = c
        cmRef2.Connection = c

        cmRef.CommandText = "select * from py_syscntrl"
        Try
            rsRef = cmRef.ExecuteReader
            If rsRef.Read Then
                cm.CommandText = "select * from py_report where Emp_Cd='" & Request.Item("e") & _
                    "' and PayDate='" & Format(CDate(Request.Item("p")), "yyyy/MM/dd") & "'"
                rs = cm.ExecuteReader
                If rs.Read Then
                    For iCtr = 1 To 60
                        If rs("Other_Incent" & iCtr) <> 0 Then
                            cmRef2.CommandText = "select Descr from py_other_incentvs where Incentive_Cd='" & _
                                rsRef("OthIncent" & iCtr & "Cd") & "'"
                            rsRef2 = cmRef2.ExecuteReader
                            vDescr = "Unknown Income/Incentive"
                            If rsRef2.Read Then
                                vDescr = rsRef2("Descr")
                            End If
                            rsRef2.Close()
                            vData += "<tr class='" & vClass & "'>" & _
                                "<td class='labelR'>" & vDescr & "</td>" & _
                                "<td class='labelR'>" & Format(rs("Other_Incent" & iCtr), "##,##0.00") & "</td></tr>"
                            vTotal += rs("Other_Incent" & iCtr)
                            vclass = IIf(vclass = "odd", "even", "odd")
                        End If
                    Next
                End If
                rs.Close()
            End If
            rsRef.Close()
            lblTotal.Text = Format(vTotal, "###,##0.00")
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to retrieve data. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            c.Dispose()
            cm.Dispose()
            cmRef.Dispose()
            cmRef2.Dispose()
        End Try
    End Sub
    Private Sub getDedDetails()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cmRef As New SqlClient.SqlCommand
        Dim cmRef2 As New SqlClient.SqlCommand
        Dim rsRef As SqlClient.SqlDataReader
        Dim rsRef2 As SqlClient.SqlDataReader
        Dim rs As SqlClient.SqlDataReader
        Dim vDescr As String
        Dim iCtr As Integer
        Dim vClass As String = "odd"
        Dim vTotal As Decimal = 0

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connec to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            cmRef.Dispose()
            Exit Sub
        End Try

        vData = ""

        cm.Connection = c
        cmRef.Connection = c
        cmRef2.Connection = c

        cmRef.CommandText = "select * from py_syscntrl"
        Try
            rsRef = cmRef.ExecuteReader
            If rsRef.Read Then
                cm.CommandText = "select * from py_report where Emp_Cd='" & Request.Item("e") & _
                    "' and PayDate='" & Format(CDate(Request.Item("p")), "yyyy/MM/dd") & "'"
                rs = cm.ExecuteReader
                If rs.Read Then
                    For iCtr = 1 To 60
                        If rs("Other_Deduct" & iCtr) <> 0 Then
                            cmRef2.CommandText = "select Loan_Name from py_loan_ref where Loan_Cd='" & _
                                rsRef("OthDed" & iCtr & "Cd") & "'"
                            rsRef2 = cmRef2.ExecuteReader
                            vDescr = "Unknown Loan/Deduction"
                            If rsRef2.Read Then
                                vDescr = rsRef2("Loan_Name")
                            End If
                            rsRef2.Close()
                            vData += "<tr class='" & vClass & "'>" & _
                                "<td class='labelR'>" & vDescr & "</td>" & _
                                "<td class='labelR'>" & Format(rs("Other_Deduct" & iCtr), "##,##0.00") & "</td></tr>"
                            vTotal += rs("Other_Deduct" & iCtr)
                            vClass = IIf(vClass = "odd", "even", "odd")
                        End If
                    Next
                End If
                rs.Close()
            End If
            rsRef.Close()
            lblTotal.Text = Format(vTotal, "###,##0.00")
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to retrieve data. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            c.Dispose()
            cm.Dispose()
            cmRef.Dispose()
            cmRef2.Dispose()
        End Try
    End Sub
End Class
