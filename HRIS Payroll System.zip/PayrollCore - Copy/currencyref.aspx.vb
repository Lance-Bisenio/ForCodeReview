﻿Imports denaro.fis
Partial Class currencyref
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If
        If Not CanRun(Session("caption"), Request.Item("id")) Then
            Session("denied") = "1"
            Server.Transfer("main.aspx")
            Exit Sub
        End If

        If Not IsPostBack Then
            lblCaption.Text = "Currency Reference Maintenance"
            DataRefresh()
        End If
    End Sub
    Private Sub DataRefresh()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim da As SqlClient.SqlDataAdapter
        Dim ds As New DataSet

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error connecting to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            da.Dispose()
            ds.Dispose()
            Exit Sub
        End Try

        Try
            da = New SqlClient.SqlDataAdapter("select * from currency_ref order by CurrName", c)
            da.Fill(ds, "currency")
            tblCurrency.DataSource = ds.Tables("currency")
            tblCurrency.DataBind()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error retrieving currency reference. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            da.Dispose()
            ds.Dispose()
        End Try
    End Sub

    Protected Sub tblCurrency_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles tblCurrency.PageIndexChanging
        tblCurrency.PageIndex = e.NewPageIndex
        DataRefresh()
    End Sub

    Protected Sub tblCurrency_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tblCurrency.SelectedIndexChanged
        Session("symbol") = tblCurrency.SelectedRow.Cells(0).Text
        RefreshDtl()
    End Sub
    Private Sub RefreshDtl()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim da As SqlClient.SqlDataAdapter
        Dim ds As New DataSet

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error connecting to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            da.Dispose()
            ds.Dispose()
            Exit Sub
        End Try

        Try
            da = New SqlClient.SqlDataAdapter("select * from currency_ref_hist where CurrCd='" & _
                tblCurrency.SelectedRow.Cells(0).Text & "' order by TranDate DESC", c)
            da.Fill(ds, "history")
            tblHistory.DataSource = ds.Tables("history")
            tblHistory.DataBind()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error retrieving currency History. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            da.Dispose()
            ds.Dispose()
        End Try
    End Sub

    Protected Sub tblHistory_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles tblHistory.PageIndexChanging
        tblHistory.PageIndex = e.NewPageIndex
        RefreshDtl()
    End Sub

    Protected Sub cmdClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdClose.Click
        Session.Remove("symbol")
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub cmdDel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDel.Click
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        Try
            cm.Connection = c
            cm.CommandText = "delete from currency_ref_hist where CurrCd='" & _
                tblCurrency.SelectedRow.Cells(0).Text & "'"
            cm.ExecuteNonQuery()
            cm.CommandText = "delete from currency_ref where CurrCd='" & _
                tblCurrency.SelectedRow.Cells(0).Text & "'"
            cm.ExecuteNonQuery()
            DataRefresh()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to delete the record. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            cm.Dispose()
            c.Dispose()
        End Try
    End Sub

    Protected Sub cmdRefresh_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdRefresh.Click
        DataRefresh()
    End Sub
End Class
