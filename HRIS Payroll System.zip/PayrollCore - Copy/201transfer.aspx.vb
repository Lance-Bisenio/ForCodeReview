Imports denaro
Partial Class _201transfer
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Dim c As New sqlclient.sqlconnection
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If

        If Not IsPostBack Then
            If Not CanRun(Session("caption"), Request.Item("id")) Then
                Session("denied") = "1"
                Server.Transfer("main.aspx")
                Exit Sub
            End If
            lblCaption.Text = "Hire Applicant"
            DataRefresh()
        End If
    End Sub
    Private Sub DataRefresh()
        Dim da As sqlclient.sqldataadapter
        Dim ds As New DataSet
        Dim vSQL As String = "select Request_No,Date_Requested as " & _
            "DateRequested,Date_Required as DateRequired,Number_Needed," & _
            "Position_Cd +'=>'+Position as Pos," & _
            "Rate,Frozen,Requested_By,Void from hr_hiring_request,py_position_ref where  " & _
            "Position_Cd=Pos_Cd  order by Date_Requested desc"
        c.ConnectionString = connStr
        da = New sqlclient.sqldataadapter(vSQL, c)
        da.Fill(ds, "request")
        tblRequest.DataSource = ds.Tables("request")
        tblRequest.DataBind()
        da.Dispose()
        ds.Dispose()
    End Sub

    Protected Sub tblRequest_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles tblRequest.PageIndexChanging
        tblRequest.PageIndex = e.NewPageIndex
        DataRefresh()
    End Sub
    Private Sub RefreshApplicant()
        Dim da As sqlclient.sqlDataAdapter
        Dim ds As New DataSet
        Dim vReqNo As String = tblRequest.SelectedRow.Cells(0).Text

        c.ConnectionString = connStr
        da = New sqlclient.sqlDataAdapter("select DateFiled as Date_Filed," & _
            "hr_applicant_master.ApplicantNo,Lname,Fname,Mname,Pos_Cd as Position,Tel,Email," & _
            "DesiredSalaryFrom,DesiredSalaryTo from hr_applicant_master,hr_shortlist where " & _
            "hr_applicant_master.ApplicantNo=" & _
            "hr_shortlist.ApplicantNo and hr_shortlist.RequestNo=" & vReqNo & _
            " and Hired=0 order by Lname,Fname", c)
        da.Fill(ds, "applicant")
        tblApplicant.DataSource = ds.Tables("applicant")
        tblApplicant.DataBind()
        ds.Dispose()
        da.Dispose()
    End Sub
    
    Protected Sub tblRequest_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tblRequest.SelectedIndexChanged
        RefreshApplicant()
    End Sub

    Protected Sub tblApplicant_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles tblApplicant.PageIndexChanging
        tblApplicant.PageIndex = e.NewPageIndex
        RefreshApplicant()
    End Sub

    Protected Sub cmdViewReq_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdViewReq.Click
        If tblRequest.SelectedIndex <> -1 And tblRequest.SelectedIndex <= tblRequest.Rows.Count Then
            Session("mode") = "v"
            Session("reqno") = tblRequest.SelectedRow.Cells(0).Text
            vScript = "logwin=window.open('modifypr.aspx','logwin','location=no,toolber=no,width=600,height=468,top=100,left=100');"
        Else
            vScript = "alert('You must first select a Request #.');"
        End If
    End Sub

    Protected Sub cmdGenInfo_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdGenInfo.Click, _
        cmdGenInfo2.Click, cmdEducation.Click, cmdFamily.Click, cmdIdent.Click, cmdRef.Click, cmdSkills.Click, _
        cmdWork.Click

        Dim vASPX As String = ""
        Dim vScale As String = ""
        If tblApplicant.SelectedIndex <> -1 And tblApplicant.SelectedIndex <= tblApplicant.Rows.Count And _
            tblApplicant.Rows.Count > 0 Then
            Session("applicantno") = tblApplicant.SelectedRow.Cells(1).Text
            Select Case CType(sender, System.Web.UI.WebControls.Button).ID.ToLower
                Case "cmdgeninfo"
                    vASPX = "applicantgeninfo.aspx"
                    vScale = "width=700,height=450,top=100,left=100"
                Case "cmdgeninfo2"
                    vASPX = "applicantgeninfo2.aspx"
                    vScale = "width=650,height=280,top=100,left=100"
                Case "cmdeducation"
                    vASPX = "applicanteducation.aspx"

                Case "cmdfamily"
                    vASPX = "applicantfamily.aspx"
                    vScale = "width=700,height=450,top=100,left=100"
                Case "cmdident"
                    vASPX = "applicantident.aspx"
                    vScale = "width=550,height=180,top=200,left=200"
                Case "cmdref"
                    vASPX = "applicantref.aspx"
                    vScale = "width=830,height=270,top=100,left=100"
                Case "cmdskills"
                    vASPX = "applicantskills.aspx"
                    vScale = "width=650,height=450,top=100,left=100"
                Case "cmdwork"
                    vASPX = "applicantwork.aspx"
                    vScale = "width=800,height=450,top=100,left=100"
            End Select
            vScript = "logwin=window.open('" & vASPX & "','logwin','location=no,toolber=no," & _
                vScale & "');"
        Else
            vScript = "alert('You must first select an applicant record to view its information.');"
        End If
    End Sub

    Protected Sub cmdReturn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.Click
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub cmdHire_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdHire.Click
        If tblApplicant.SelectedIndex <> -1 And tblApplicant.SelectedIndex <= tblApplicant.Rows.Count And _
            tblApplicant.Rows.Count > 0 Then
            Session.Remove("empid")
            Session("fromapplicant") = 1
            Session("applicantno") = tblApplicant.SelectedRow.Cells(1).Text
            Session("reqno") = tblRequest.SelectedRow.Cells(0).Text
            vScript = "editwin=window.open('empstep1.aspx','empwin','toolbar=no,location=no,width=600,height=400,top=100,left=100');"
        Else
            vScript = "alert('You must first select an applicant.');"
        End If
    End Sub
End Class
