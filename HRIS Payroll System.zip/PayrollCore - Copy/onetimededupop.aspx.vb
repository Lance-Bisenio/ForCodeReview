Imports denaro.fis
Partial Class onetimededupop
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Dim vType As String = ""
    Dim rdo As String = ""
    Dim vMode As String = ""
    Dim vID As String = ""
    Dim vEmp As String = ""
    Dim vAmt As Decimal = 0
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Session("returnaddr") = "dailylog.aspx"
            Server.Transfer("index.aspx")
        End If

        'vPdate = Request.Item("pDate")
        vType = Request.Item("Type")
        rdo = Request.Item("rdo")
        vMode = Request.Item("mode")
        vID = Request.Item("vID")
        vEmp = Request.Item("vEmp")
        vAmt = Request.Item("vAmt")
        If Not IsPostBack Then
            'BuildCombo("Select Emp_Cd, (Emp_Lname+', '+Emp_Fname) as Name from py_emp_master " & _
            '    "where Date_Resign is null and DateDismissed is null and DateHold is null and Date_Retired is null " & _
            '    " and DateSuspended is null and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
            '    "' and Property='employmenttype' and Property_Value=EmploymentType)  order by Emp_Lname, Emp_Fname", cmbEmp)
            BuildCombo("Select Emp_Cd, (Emp_Lname+', '+Emp_Fname) as Name from py_emp_master " & _
                "where DateDismissed is null and DateHold is null and Date_Retired is null " & _
                " and DateSuspended is null and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='employmenttype' and Property_Value=EmploymentType)  order by Emp_Lname, Emp_Fname", cmbEmp)

            cmbEmp.Items.Add("Select Employee...")
            cmbEmp.SelectedValue = "Select Employee..."
            txtAmount.Text = "0"
            txtType.Text = vType
            'getcutoff(vPdate)
            txtStart.Text = Request.Item("sdate")
            txtEnd.Text = Request.Item("edate")
            If vEmp <> "" Then
                cmbEmp.Enabled = False
                cmbEmp.SelectedValue = vEmp
                txtAmount.Text = vAmt
            End If
        End If
    End Sub

    Private Sub getcutoff(ByVal pDate As Date)
        'Dim c As New sqlclient.sqlconnection(connStr)
        'Dim cm As New sqlclient.sqlcommand
        'Dim rs As sqlclient.sqldatareader

        'c.Open()
        'cm.Connection = c

        'cm.CommandText = "Select TOP 1 FromDate, ToDate from py_report where PayDate='" & Format(pDate, "yyyy/MM/dd") & "'"
        'rs = cm.ExecuteReader
        'If rs.Read Then
        '    txtStart.Text = IIf(IsDBNull(rs("FromDate")), "", rs("FromDate"))
        '    txtEnd.Text = IIf(IsDBNull(rs("ToDate")), "", rs("ToDate"))
        'End If
        'rs.Close()
        'cm.Dispose()
        'c.Close()
        'c.Dispose()
    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click

        If Not IsNumeric(txtAmount.Text) Then
            vScript = "alert('Please input a valid amount');"
            Exit Sub
        End If

        Dim c As New sqlclient.sqlconnection(connStr)
        Dim cm As New sqlclient.sqlcommand
        Dim vUser As String = Session("uid")
        Dim vOldVal As String = ""
        Dim vNewVal As String = ""
        Dim vRemarks As String = ""
        Dim vModule As String = "ONE TIME DEDUCTION/INCENTIVE"
        Dim vEvent As String = ""


        Dim vTypeOf As String = txtType.Text
        Dim vAmount As Decimal = txtAmount.Text
        Dim vStart As Date = txtStart.Text
        Dim vEnd As Date = txtEnd.Text
        Dim vEmp As String = cmbEmp.SelectedValue
        Dim vGetSday As String
        Dim vFreq As String
        Dim vREm As String

        c.Open()
        cm.Connection = c

        If vMode = "a" And rdo = "0" Then 'Add incentive
            vEvent = "ADD"
            vOldVal = "Incentive Code=New|Incentive Amount=New|From Date=New|To Date=New"
            vNewVal = "Incentive Code=" & vTypeOf & "|Incentive Amount=" & vAmount & "|From Date=" & _
                Format(vStart, "yyyy/MM/dd") & "|To Date=" & Format(vEnd, "yyyy/MM/dd") & ""

            vRemarks = vUser & " add one time incentive to " & vEmp
            If cmbEmp.SelectedValue = "Select Employee..." Then
                vScript = "alert('Please select an employee first...');"
                Exit Sub
            End If
            If Val(txtAmount.Text) = 0 Then
                vScript = "alert('You must enter a value other than zero.');"
                Exit Sub
            End If
            Try
                'clean up existing data
                'cm.CommandText = "delete from py_incentives_dtl where Emp_Cd='" & vEmp & _
                '    "' and Incentive_Cd='" & vTypeOf & "' and FromDate='" & _
                '    Format(vStart, "yyyy/MM/dd") & "'"
                'cm.ExecuteNonQuery()

                'now insert the modified data
                cm.CommandText = "Insert into py_incentives_dtl(Incentive_Cd,Incentive_Amt,FromDate,ToDate,Emp_Cd,Recurring) values('" & _
                    vTypeOf & "','" & vAmount & "','" & Format(vStart, "yyyy/MM/dd") & "','" & Format(vEnd, "yyyy/MM/dd") _
                    & "','" & vEmp & "','0')"
                cm.ExecuteNonQuery()
                vScript = "alert('Adding of incentives successful.');"
                txtAmount.Text = "0"
                cmbEmp.SelectedValue = "Select Employee..."

                EventLog(vUser, Request.ServerVariables("REMOTE_ADDR"), vEvent, vOldVal, vNewVal, vRemarks, vModule)
            Catch ex As sqlclient.sqlException
                vScript = "alert('Error occured while saving.');"
            End Try
        ElseIf vMode = "e" And rdo = "0" Then 'Edit  incentive
            cm.CommandText = "Update py_incentives_dtl set Incentive_Cd='" & vTypeOf & "', Incentive_Amt='" & vAmount & _
                             "', FromDate='" & Format(vStart, "yyyy/MM/dd") & _
                             "', ToDate='" & Format(vEnd, "yyyy/MM/dd") & "', Recurring='0' where Id='" & vID & "'"
            cm.ExecuteNonQuery()
            vScript = "alert('Record successfully saved.');self.close();"
        ElseIf vMode = "a" And rdo = "1" Then 'Add Loan
            If cmbEmp.SelectedValue = "Select Employee..." Then
                vScript = "alert('You must first select an employee.');"
                Exit Sub
            End If
            If Val(txtAmount.Text) = 0 Then
                vScript = "alert('You must enter a value other then zero.');"
                Exit Sub
            End If

            vREm = " one time payment in " & vTypeOf
            vGetSday = CDate(txtStart.Text).Day

            If vGetSday = "11" Then
                vFreq = 2
            Else
                vFreq = 1
            End If
            vEvent = "ADD"

            vOldVal = "Emp_Cd(hdr)=New Loan|Loan_Cd(hdr)=New Loan|Amt_Bal(hdr)=New Loan|Amt_Loan(hdr)=New Loan|Loan_Date(hdr)=New Loan|Start_Date(hdr)=New Loan|ProdDescr(hdr)=New Loan|MonthlyAmort(hdr)=New Loan|End_Date(hdr)=New Loan|FreqCd(hdr)=New Loan|Emp_Cd(dtl)=New Loan|Tran_Date(dtl)=New Loan|Amt_Cost(dtl)=New Loan|Loan_Cd(dtl)=New Loan|Loan_Date(dtl)=New Loan"
            vNewVal = "Emp_Cd(hdr)=" & vEmp & "|Loan_Cd(hdr)=" & vTypeOf & "|Amt_Bal(hdr)=" & _
                vAmount & "|Amt_Loan(hdr)=" & vAmount & "|Loan_Date(hdr)=" & Format(vStart, "yyyy/MM/dd") & _
                "|Start_Date(hdr)=" & Format(vStart, "yyyy/MM/dd") & "|ProdDescr(hdr)=" & vREm & _
                "|MonthlyAmort(hdr)=" & vAmount & "|End_Date(hdr)=" & Format(vEnd, "yyyy/MM/dd") & _
                "|Freq_Cd(hdr)=" & vFreq & "|Emp_Cd(dtl)=" & vEmp & "|Tran_Date(dtl)=" & _
                Format(vStart, "yyyy/MM/dd") & "|Amt_Cost(dtl)=" & vAmount & "|Loan_Cd(dtl)=" & vTypeOf & _
                "|Loan_Date(dtl)=" & Format(vStart, "yyyy/MM/dd")
            vRemarks = vUser & " add one time loan to " & vEmp

            'ensure that data to be inserted does not clash with the existing data (either garbage or not)
            cm.CommandText = "delete from py_loan_hdr where Emp_Cd='" & vEmp & "' and Loan_Cd='" & vTypeOf & _
              "' and Loan_Date='" & Format(vStart, "yyyy/MM/dd") & "'"
            cm.ExecuteNonQuery()

            cm.CommandText = "delete from py_loan_dtl where Emp_Cd='" & vEmp & "' and Loan_Cd='" & vTypeOf & _
              "' and Loan_Date='" & Format(vStart, "yyyy/MM/dd") & "'"
            cm.ExecuteNonQuery()

            cm.CommandText = "Insert into py_loan_hdr(Emp_Cd,Loan_Cd,Amt_Bal,Amt_Loan,Amt_Paid,Loan_Date,Start_Date,Int_Rate,Month_To_Pay,Active,ProdDescr,Monthly,MonthlyAmort,Recurring,End_Date,PaymentsMade,FreqCd,DocNo)" & _
                             " values ('" & vEmp & "','" & vTypeOf & "','" & vAmount & "','" & _
                             vAmount & "','0','" & Format(vStart, "yyyy/MM/dd") & "','" & _
                             Format(vStart, "yyyy/MM/dd") & "','0','1','1','" & vREm & " ','0','" & _
                             vAmount & "','0','" & Format(vEnd, "yyyy/MM/dd") & "','0','0',null)"
            cm.ExecuteNonQuery()

            'INSERT TO DTL
            cm.CommandText = "Insert into py_loan_dtl(Emp_Cd,Tran_Date,Amt_Cost,Loan_Cd,Paid,Amt_Paid,Date_Paid,Loan_Date,Active,OrNo)" & _
                             " values ('" & vEmp & "','" & Format(vStart, "yyyy/MM/dd") & "','" & _
                             vAmount & "','" & vTypeOf & "','0','0',null,'" & Format(vStart, "yyyy/MM/dd") & "','1',null)"
            cm.ExecuteNonQuery()

            vScript = "alert('Adding of loan successful');"
            cmbEmp.SelectedValue = "Select Employee..."
            txtAmount.Text = "0"

            EventLog(vUser, Request.ServerVariables("REMOTE_ADDR"), vEvent, vOldVal, vNewVal, vRemarks, vModule)
        Else 'Edit Loan

            cm.CommandText = "Update py_loan_hdr set Amt_Bal='" & vAmount & "',Amt_Loan='" & vAmount & _
                "',MonthlyAmort='" & vAmount & "' where Id='" & vID & "'"
            cm.ExecuteNonQuery()

            cm.CommandText = "Update py_loan_dtl set Amt_Cost='" & vAmount & "' where Emp_Cd='" & vEmp & _
                "' and Loan_Cd='" & vTypeOf & "' and Tran_Date='" & Format(vStart, "yyyy/MM/dd") & _
                "' and Amt_Cost='" & vAmount & "'"
            cm.ExecuteNonQuery()

            vScript = "alert('Record successfully saved.');self.close();"
        End If

        c.Close()
        cm.Dispose()
        c.Dispose()
    End Sub
End Class
