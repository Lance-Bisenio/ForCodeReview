Imports denaro
Partial Class modifyincent
    Inherits System.Web.UI.Page
    Public vScript As String = "window.focus();"

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            vScript = "alert('Your login session has expired. Please re-login again.'); window.close();"
            Exit Sub
        End If

        If Not IsPostBack Then
            Dim c As New sqlclient.sqlConnection(connStr)
            Dim dr As sqlclient.sqlDataReader
            Dim cm As New sqlclient.sqlCommand
            Dim cm_emp As New sqlclient.sqlCommand
            Dim PayCd_Days As String
            Dim PayCd_Days_one() As String

            lblCaption.Text = "Add/Modify Incentives and Other Income"
            txtIncentCd.Text = Session("incentcd")

            Try
                c.Open()
            Catch ex As sqlclient.sqlexception
                vScript = "alert('Error occurred while trying to connect to SQL Server. Error is: " & ex.Message.Replace(vbCrLf, "\n") & "');"
                cm.Dispose()
                c.Dispose()
                Exit Sub
            End Try

            BuildCombo("select CurrCd,CurrName from currency_ref order by CurrName", cmbSrcCurr, c)
            BuildCombo("select CurrCd,CurrName from currency_ref order by CurrName", cmbTargetCurr, c)

            cm.Connection = c
            cm.CommandText = "Select * from py_pay_mode where Pay_Cd='SM'"
            Try
                dr = cm.ExecuteReader
                If dr.Read Then
                    PayCd_Days = IIf(IsDBNull(dr("Days")), "", dr("Days"))
                    PayCd_Days_one = PayCd_Days.Split(",")
                    cmbFreq.Items.Add(New ListItem("Every 1st Period", PayCd_Days_one(1) - 1))
                    cmbFreq.Items.Add(New ListItem("Every 2nd Period", IIf(PayCd_Days_one(0) - 1 = 0, 30, PayCd_Days_one(0) - 1)))
                End If
                dr.Close()
            Catch ex As sqlclient.sqlexception
                vScript = "alert('Error occurred while trying to retrieve Payment Mode Reference. Error is: " & _
                    ex.Message.Replace(vbCrLf, "\n") & "');"
                c.Close()
                c.Dispose()
                cm.Dispose()
                Exit Sub
            End Try
            txtIncentCd.Text = Session("incentcd")
            If Session("mode") = "e" Then 'edit mode
                cm.CommandText = "select Emp_Cd,(select (Emp_Lname+', '+Emp_Fname) from py_emp_master where py_emp_master.Emp_Cd=" & _
                    "py_incentives_dtl.Emp_Cd) as Name,Incentive_Amt,FromDate,ToDate,Recurring,FreqCd,SrcCurrCd,TargetCurrCd " & _
                    "from py_incentives_dtl where Id=" & _
                    Session("tid") & " and Incentive_Cd='" & Session("incentcd") & "'"
                Try
                    dr = cm.ExecuteReader

                    If dr.Read Then
                        txtEmp.Text = dr("Emp_Cd")
                        txtEmpName.Text = IIf(IsDBNull(dr("Name")), "Unknown", dr("Name"))
                        txtAmt.Text = dr("Incentive_Amt")
                        txtStart.Text = IIf(IsDBNull(dr("FromDate")), "", dr("FromDate"))
                        txtEnd.Text = IIf(IsDBNull(dr("ToDate")), "", dr("ToDate"))
                        cmbFreq.SelectedValue = IIf(IsDBNull(dr("FreqCd")), 0, dr("FreqCd"))
                        chkRecurr.Checked = txtStart.Text.Trim = ""
                        cmbSrcCurr.SelectedValue = IIf(IsDBNull(dr("SrcCurrCd")), "PHP", dr("SrcCurrCd"))
                        cmbTargetCurr.SelectedValue = IIf(IsDBNull(dr("TargetCurrCd")), "PHP", dr("TargetCurrCd"))
                    End If
                    dr.Close()
                    txtEmp.ReadOnly = True
                Catch ex As sqlclient.sqlexception
                    vScript = "alert('Error occurred while retrieving Incentives Ledger. Error is: " & _
                        ex.Message.Replace(vbCrLf, "\n") & "');"
                Finally
                    c.Close()
                    c.Dispose()
                    cm.Dispose()
                End Try
            Else    'add mode
                txtStart.Text = Format(Now, "MM/dd/yyyy")
                txtEnd.Text = txtStart.Text
                txtAmt.Text = "0.00"
            End If
        End If
    End Sub


    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim vSQL As String = ""

        If txtAmt.Text = "" Or Not IsNumeric(txtAmt.Text) Then
            vScript = "alert('Amount field should be numeric.');"
            Exit Sub
        End If
        txtAmt.Text = txtAmt.Text.Replace(",", "")
        If Val(txtAmt.Text) = 0 Then
            vScript = "alert('Amount field should not be zero.');"
            Exit Sub
        End If
        If txtEmpName.Text = "" Then
            vScript = "alert('You must first enter a valid Employee Id.');"
            Exit Sub
        End If

        If Session("mode") = "a" Then 'add mode
            vSQL = "insert into py_incentives_dtl (Incentive_Cd,Emp_Cd,Incentive_Amt,SrcCurrCd,TargetCurrCd,FromDate,ToDate,FreqCd,Recurring)" & _
                " values ('" & txtIncentCd.Text & "','" & txtEmp.Text & "'," & txtAmt.Text & ",'" & _
                cmbSrcCurr.SelectedValue & "','" & cmbTargetCurr.SelectedValue & "',"

            If txtStart.Text = "" Then
                vSQL += "null,"
            Else
                vSQL += "'" & Format(CDate(txtStart.Text), "yyyy/MM/dd") & "',"
            End If

            If txtEnd.Text = "" Then
                vSQL += "null,"
            Else
                vSQL += "'" & Format(CDate(txtEnd.Text), "yyyy/MM/dd") & "',"
            End If

            If cmbFreq.SelectedValue = -1 Then
                vSQL += "0,"
            Else
                vSQL += cmbFreq.SelectedValue & ","
            End If
            If chkRecurr.Checked Then
                vSQL += "1)"
            Else
                vSQL += "0)"
            End If
        Else 'edit mode
            vSQL = "update py_incentives_dtl set " & "Incentive_Amt=" & txtAmt.Text & _
                ",SrcCurrCd='" & cmbSrcCurr.SelectedValue & "',TargetCurrCd='" & _
                cmbTargetCurr.SelectedValue & "',FromDate="

            If txtStart.Text = "" Then
                vSQL += "null"
            Else
                vSQL += "'" & Format(CDate(txtStart.Text), "yyyy/MM/dd") & "'"
            End If

            If txtEnd.Text = "" Then
                vSQL += ",ToDate=null"
            Else
                vSQL += ",ToDate='" & Format(CDate(txtEnd.Text), "yyyy/MM/dd") & "'"
            End If

            If cmbFreq.SelectedValue = -1 Then
                vSQL += ",FreqCd=0"
            Else
                'If chkRepeat.Checked Then
                vSQL += ",FreqCd=" & cmbFreq.SelectedValue
            End If

            If chkRecurr.Checked Then
                vSQL += ",Recurring=1"
            Else
                vSQL += ",Recurring=0"
            End If
            vSQL += " where Id=" & session("tid") & " and Incentive_Cd='" & _
                    txtIncentCd.Text & "' "
        End If

        Try
            c.ConnectionString = connStr
            c.Open()
            cm.Connection = c
            cm.CommandText = vSQL
            cm.ExecuteNonQuery()
            vScript = "alert('Changes saved successfully. Click the Search/Refresh button again to update the screen information.'); window.close(); "
            c.Close()
            c.Dispose()
            cm.Dispose()
        Catch ex As sqlclient.sqlexception
            vScript = "alert('Error occurred while try to execute your request. Error is: " & _
                ex.Message.Replace(vbCrLf, "\n").Replace("'", "") & "');"
        End Try
    End Sub

    Protected Sub txtEmp_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtEmp.TextChanged
        Dim c As New sqlclient.sqlconnection(connStr)
        Dim cm_emp As New sqlclient.sqlcommand
        Dim dr_emp As sqlclient.sqldatareader

        c.ConnectionString = connStr

        Try
            c.Open()
        Catch ex As sqlclient.sqlexception
            vScript = "alert('Error occurred while trying to connect to SQL Server. Error in line 289: " & _
                ex.Message.Replace(vbCrLf, "\n") & "');"
            c.Dispose()
            cm_emp.Dispose()
            Exit Sub
        End Try

        cm_emp.Connection = c
        cm_emp.CommandText = "select Emp_Lname,Emp_Fname from py_emp_master where Emp_Cd='" & txtEmp.Text & "'"

        Try
            dr_emp = cm_emp.ExecuteReader
            If dr_emp.Read Then
                txtEmpName.Text = dr_emp("Emp_Lname") & ", " & dr_emp("Emp_Fname")
            Else
                txtEmpName.Text = ""
                vScript = "alert('Employee does not exist');"
            End If
            dr_emp.Close()
        Catch ex As sqlclient.sqlexception
            vScript = "alert('Error occurred while validating Employee Id entered. Error in line 303: " & _
                ex.Message.Replace(vbCrLf, "\n") & "');"
        Finally
            c.Close()
            cm_emp.Dispose()
            c.Dispose()
        End Try
    End Sub
End Class
