Imports denaro
Partial Class leavemonitor
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Dim vClass As String = "odd"
    Protected Sub cal_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cal.SelectionChanged
        If txtStatus.Value = "start" Then
            txtFrom.Text = cal.SelectedDate
        Else
            txtTo.Text = cal.SelectedDate
        End If
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Session("returnaddr") = "leavemonitor.aspx"
            Server.Transfer("index.aspx")
        End If
        Session.Remove("vFilterHeader")
        If Not IsPostBack Then
            lblCaption.Text = "Employee Leave Monitoring"
            If Not CanRun(Session("caption"), Request.Item("id")) Then
                Session("denied") = "1"
                Server.Transfer("main.aspx")
                Exit Sub
            End If
            txtFrom.Text = Format(DateAdd(DateInterval.Day, -15, Now), "MM/dd/yyyy")
            txtTo.Text = Format(Now, "MM/dd/yyyy")
            BuildCombo("select Leave_Cd,Descr from py_leave_ref", cmbLeaveType)
            cmbLeaveType.Items.Add("Show all Leaves")
            cmbLeaveType.SelectedValue = "Show all Leaves"
            cmdA.Enabled = False
            BuildCombo("select Rc_Cd,Descr from rc where exists (select User_Id from rights_list where User_Id='" & _
                    Session("uid") & "' and property='rc' and Property_Value=Rc_Cd) order by Descr", cmbRC)
            BuildCombo("select AgencyCd,AgencyName from agency where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='agency' and Property_Value=AgencyCd) order by AgencyName", cmbOfc)
            BuildCombo("select Div_Cd,Descr from hr_div_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='division' and Property_Value=Div_Cd) order by Descr", cmbDiv)
            BuildCombo("select Dept_Cd,Descr from hr_dept_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='department' and Property_Value=Dept_Cd) order by Descr", cmbDept)
            BuildCombo("select Section_Cd,Descr from hr_section_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='section' and Property_Value=Section_Cd) order by Descr", cmbSection)
            BuildCombo("select Unit_Cd,Descr from hr_unit_ref where exists (select User_Id from rights_list where User_Id='" & _
                Session("uid") & "' and property='unit' and Property_Value=Unit_Cd) order by Descr", cmbUnit)

            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' MODIFIED BY:     Rudner Diaz                                                            ''
            '' DATE:            4/5/2013                                                               ''
            '' PURPOSE:         To include the Payment mode in the query                               ''
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            BuildCombo("select Pay_Cd,Payment from py_pay_mode order by Payment", cmbPaymode)
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            cmbRC.Items.Add("All")
            cmbRC.SelectedValue = "All"
            cmbOfc.Items.Add("All")
            cmbOfc.SelectedValue = "All"
            cmbDiv.Items.Add("All")
            cmbDiv.SelectedValue = "All"
            cmbDept.Items.Add("All")
            cmbDept.SelectedValue = "All"
            cmbSection.Items.Add("All")
            cmbSection.SelectedValue = "All"
            cmbUnit.Items.Add("All")
            cmbUnit.SelectedValue = "All"
            Session("letter") = "A"
            DataRefresh(Session("letter"))
        End If
    End Sub
    Private Function isPayrollPosted() As Boolean
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim dr As SqlClient.SqlDataReader
        Dim isPosted As Boolean = False

        c.Open()
        cm.Connection = c

        'Check for posted payroll
        cm.CommandText = "SELECT 1 FROM py_report WHERE Emp_Cd='" & Session("empid") & "' AND '" & Session("vLeaveDate") & _
            "' BETWEEN FromDate AND ToDate AND Posted=1"
        dr = cm.ExecuteReader
        isPosted = dr.HasRows
        dr.Close()

        cm.Dispose()
        c.Close()

        Return isPosted
        dr.Close()
    End Function
    Private Sub DataRefresh(ByVal pLetter As String)
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim da As SqlClient.SqlDataAdapter
        Dim ds As New DataSet
        Dim vFilter As String = " and " & cmbType.SelectedValue & " like '" & pLetter & "%' "
        Dim vSql As String = ""
        Dim vQuery As String = ""

        If cmbRC.SelectedValue <> "All" Then   'filter by cost center
            vFilter += " and Rc_Cd='" & cmbRC.SelectedValue & "' "
            vQuery += " and Rc_Cd='" & cmbRC.SelectedValue & "' "
            Session("vFilterHeader") += "Cost Center : " & ExtractDescr(cmbRC.SelectedItem.Text) & "<br />"
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='rc' and Property_Value=Rc_Cd) "
            vQuery += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                "' and Property='rc' and Property_Value=Rc_Cd) "
        End If
        If cmbOfc.SelectedValue <> "All" Then        'filter by office/agency
            vFilter += " and Agency_Cd='" & cmbOfc.SelectedValue & "' "
            vQuery += " and Agency_Cd='" & cmbOfc.SelectedValue & "' "
            Session("vFilterHeader") += "Company : " & ExtractDescr(cmbOfc.SelectedItem.Text) & "<br />"
        Else
            vFilter += "  and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='agency' and Property_Value=Agency_Cd) "
            vQuery += "  and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='agency' and Property_Value=Agency_Cd) "
        End If
        If cmbDiv.SelectedValue <> "All" Then      'filter by division
            vFilter += " and Divcd='" & cmbDiv.SelectedValue & "' "
            vQuery += " and Divcd='" & cmbDiv.SelectedValue & "' "
            Session("vFilterHeader") += "Group : " & ExtractDescr(cmbDiv.SelectedItem.Text) & "<br />"
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='division' and Property_Value=DivCd) "
            vQuery += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='division' and Property_Value=DivCd) "
        End If
        If cmbDept.SelectedValue <> "All" Then  'filter by departments
            vFilter += " and DeptCd='" & cmbDept.SelectedValue & "' "
            vQuery += " and DeptCd='" & cmbDept.SelectedValue & "' "
            Session("vFilterHeader") += "Division/Regional Office : " & ExtractDescr(cmbDept.SelectedItem.Text) & "<br />"
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='department' and Property_Value=DeptCd) "
            vQuery += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='department' and Property_Value=DeptCd) "
        End If
        If cmbSection.SelectedValue <> "All" Then 'filter by section
            vFilter += " and SectionCd='" & cmbSection.SelectedValue & "' "
            vQuery += " and SectionCd='" & cmbSection.SelectedValue & "' "
            Session("vFilterHeader") += "Department/Area Office : " & ExtractDescr(cmbSection.SelectedItem.Text) & "<br />"
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='section' and Property_Value=SectionCd) "
            vQuery += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='section' and Property_Value=SectionCd) "
        End If
        If cmbUnit.SelectedValue <> "All" Then  'filter by units
            vFilter += " and UnitCd='" & cmbUnit.SelectedValue & "' "
            vQuery += " and UnitCd='" & cmbUnit.SelectedValue & "' "
            Session("vFilterHeader") += "Section/Branch : " & ExtractDescr(cmbUnit.SelectedItem.Text) & "<br />"
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='unit' and Property_Value=UnitCd) "
            vQuery += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='unit' and Property_Value=UnitCd) "
        End If

        If cmbUnit.SelectedValue <> "All" Then  'filter by units
            vFilter += " and UnitCd='" & cmbUnit.SelectedValue & "' "
            vQuery += " and UnitCd='" & cmbUnit.SelectedValue & "' "
            Session("vFilterHeader") += "Section/Branch : " & ExtractDescr(cmbUnit.SelectedItem.Text) & "<br />"
        Else
            vFilter += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='unit' and Property_Value=UnitCd) "
            vQuery += " and exists (select User_Id from rights_list where User_Id='" & Session("uid") & _
                    "' and Property='unit' and Property_Value=UnitCd) "
        End If
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:     Rudner Diaz                                                            ''
        '' DATE:            4/5/2013                                                               ''
        '' PURPOSE:         To include the Payment mode in the query                               ''
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        If cmbpaymode.selectedvalue <> "All" Then
            vFilter += " and Pay_Cd='" & cmbPaymode.SelectedValue & "' "
            vQuery += " and Pay_Cd='" & cmbPaymode.SelectedValue & "' "
            Session("vFilterHeader") += "Payment Mode : " & ExtractDescr(cmbPaymode.SelectedItem.Text) & "<br />"
        Else

        End If
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  LANCE BISENIO                                             ''
        '' DATE MODIFIED:  2/21/2012                                               ''
        '' PURPOSE:  ADD FILTER EMPLOYEE STATUS (Active,In-Active)                 ''
        ''                                                                         ''
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        ''''''''''''''''''''''''' NEW CODE ''''''''''''''''''''''''''''''''''''''''''
        Select Case Val(cmbStatus.SelectedValue)
            Case 1  'active employees only
                vFilter += " and Date_Resign is null AND Date_Retired IS NULL AND DateHold IS NULL AND DateDismissed IS NULL"
            Case 0  'inactive employees only
                vFilter += " and (Date_Resign is not null OR Date_Retired IS NOT NULL OR DateHold IS NOT NULL Or DateDismissed IS NOT NULL)"
        End Select
        ''''''''''''''''''''''''' END CODE ''''''''''''''''''''''''''''''''''''''''''
        
        da = New SqlClient.SqlDataAdapter("select Emp_Cd,Emp_Lname,Emp_Fname,Emp_Mname from py_emp_master " & _
            "where Emp_Cd <> '" & Session("uid") & "' " & _
            vFilter & " order by Emp_Lname,Emp_Fname,Emp_Mname", c)

        da.Fill(ds, "EmpMaster")
        tblEmp.DataSource = ds.Tables("EmpMaster")
        tblEmp.DataBind()
        da.Dispose()
        ds.Dispose()
        c.Dispose()
        Session("filter") = "where Date_Resign is null and DateHold is null and Date_Retired is null " & _
            vQuery
        Session("vPeriod") = Format(CDate(Me.txtFrom.Text), "MM/dd/yyyy") & " - " & Format(CDate(Me.txtTo.Text), "MM/dd/yyyy")
        setVoidCaption()
        tblEmp.SelectedIndex = -1
    End Sub
    Private Sub setVoidCaption()
        If rdoVoid.SelectedValue = 0 Then   'active
            cmdVoid.Text = "Void Application"
        Else
            cmdVoid.Text = "Reactivate Application"
        End If
    End Sub
    Protected Sub cmdA_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdA.Click, _
        cmdB.Click, cmdC.Click, cmdD.Click, cmdE.Click, cmdF.Click, cmdG.Click, cmdH.Click, cmdI.Click, _
        cmdJ.Click, cmdK.Click, cmdL.Click, cmdM.Click, cmdN.Click, cmdO.Click, cmdP.Click, cmdQ.Click, _
        cmdR.Click, cmdS.Click, cmdT.Click, cmdU.Click, cmdV.Click, cmdW.Click, cmdX.Click, cmdY.Click, cmdZ.Click
        EnableAll()
        Session("letter") = CType(sender, LinkButton).Text
        txtSearch.Text = CType(sender, LinkButton).Text
        tblEmp.SelectedIndex = -1
        DataRefresh(Session("letter"))
        CType(sender, LinkButton).Enabled = False
    End Sub
    Private Sub EnableAll()
        cmdA.Enabled = True : cmdB.Enabled = True : cmdC.Enabled = True : cmdD.Enabled = True
        cmdE.Enabled = True : cmdF.Enabled = True : cmdG.Enabled = True : cmdH.Enabled = True
        cmdI.Enabled = True : cmdJ.Enabled = True : cmdK.Enabled = True : cmdL.Enabled = True
        cmdM.Enabled = True : cmdN.Enabled = True : cmdO.Enabled = True : cmdP.Enabled = True
        cmdQ.Enabled = True : cmdR.Enabled = True : cmdS.Enabled = True : cmdT.Enabled = True
        cmdU.Enabled = True : cmdV.Enabled = True : cmdW.Enabled = True : cmdX.Enabled = True
        cmdY.Enabled = True : cmdZ.Enabled = True
    End Sub

    Protected Sub tblEmp_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles tblEmp.PageIndexChanging
        tblEmp.PageIndex = e.NewPageIndex
        DataRefresh(txtSearch.Text)
    End Sub

    Private Sub GetLeaveCredits(ByVal vEmpId As String)
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim da As SqlClient.SqlDataAdapter
        Dim ds As New DataSet
        da = New SqlClient.SqlDataAdapter("select Leave_Cd,Balance,Used from py_emp_leave where Emp_Cd='" & _
            vEmpId & "'", c)
        da.Fill(ds, "Leave")
        tblLeave.DataSource = ds.Tables("Leave")
        tblLeave.DataBind()
        da.Dispose()
        ds.Dispose()
        c.Dispose()
    End Sub
    Protected Sub tblEmp_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tblEmp.SelectedIndexChanged
        Dim vEmpId As String = tblEmp.SelectedRow.Cells(0).Text

        Session("empid") = vEmpId
        GetLeaveCredits(vEmpId)
        RefreshLeave(vEmpId)
        setVoidCaption()
    End Sub

    Private Sub RefreshLeave(ByVal pEmpId As String)
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim da As SqlClient.SqlDataAdapter
        Dim ds As New DataSet
        Dim vQry As String = "select TranDate as Tran_Date,CASE WHEN EL=1 THEN 'EL' ELSE LeaveCd END AS LeaveCd,DaysLeave," & _
            "StartDate as DateStart," & _
            "EndDate as DateEnd,Void,Paid,ApprovedBy,DateApproved as Date_Approved,RecommendedBy,DateRecommended,NotedBy,DateNoted,EffectivityDate" & _
            ",Posted,ApplicationNo from hr_leave_application where Emp_Cd='" & pEmpId & "' and StartDate between '" & _
            Format(CDate(txtFrom.Text), "yyyy/MM/dd") & " 00:00:00' and '" & _
            Format(CDate(txtTo.Text), "yyyy/MM/dd") & " 23:59:59' " & _
            " and Paid=" & rdoPaid.SelectedValue & " and Void=" & rdoVoid.SelectedValue

        If cmbLeaveType.SelectedValue <> "Show all Leaves" Then
            vQry += " and LeaveCd='" & cmbLeaveType.SelectedValue & "' "
        Else
            vQry += " and LeaveCd<>'OT' "
        End If

        vQry += " order by TranDate desc"
        da = New SqlClient.SqlDataAdapter(vQry, c)
        da.Fill(ds, "Applications")
        tblApplication.DataSource = ds.Tables("Applications")
        tblApplication.DataBind()
        tblApplication.SelectedIndex = -1
        da.Dispose()
        ds.Dispose()
        c.Dispose()
    End Sub
    
    Protected Sub cmdReturn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.Click
        Session.Remove("vLeaveDate")
        Session.Remove("letter")
        Session.Remove("empid")
        Session.Remove("tdate")
        Session.Remove("mode")
        Session.Remove("filter")
        Session.Remove("origfilter")
        Session.Remove("leavetype")
        Session.Remove("vleavetype")
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub tblApplication_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles tblApplication.PageIndexChanging
        tblApplication.PageIndex = e.NewPageIndex
        RefreshLeave(Session("empid"))
    End Sub

    Protected Sub cmdAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdAdd.Click
        If tblEmp.SelectedIndex <> -1 Then    'a selection was made
            Session("empid") = tblEmp.SelectedRow.Cells(0).Text & "=>" & _
                tblEmp.SelectedRow.Cells(1).Text & ", " & _
                tblEmp.SelectedRow.Cells(2).Text
            Session.Remove("tdate")
            Session.Remove("mode")
            vScript = "leavewin=window.open('modifyleave.aspx','leavewin','location=no,toolber=no,width=550,height=520,top=100,left=100');"
        Else
            vScript = "alert('Please select an employee first before adding an application.');"
        End If
    End Sub

  
    Protected Sub cmdPost_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdPost.Init
        cmdPost.Attributes.Add("onclick", "return post();")
    End Sub
    Protected Sub cmdPost_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdPost.Click
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim dr As SqlClient.SqlDataReader

        c.Open()
        cm.Connection = c

        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                                             ''
        '' DATE MODIFIED: 5/11/2013                                                 ''
        '' PURPOSE: TO ENHANCE THE CONDITION OF APPROVED APPLICATION                ''
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        ''''''''''''''''''''''''' OLD CODE '''''''''''''''''''''''''''''''''''''''''''
        'cm.CommandText = "select ApplicationNo,Paid from hr_leave_application where " & _
        '    " ApprovedBy is not null and Void=0 and TranDate between '" & Format(CDate(txtFrom.Text), "yyyy/MM/dd") & _
        '    " 00:00:00' and '" & Format(CDate(txtTo.Text), "yyyy/MM/dd") & " 23:59:59' " & _
        '    " and LeaveCd<>'OT' and DateApproved is not null and exists (" & _
        '    " select Emp_Cd from py_emp_master " & Session("filter") & _
        '    " and py_emp_master.Emp_Cd=hr_leave_application.Emp_Cd)"
        ''''''''''''''''''''''''' END OLD CODE '''''''''''''''''''''''''''''''''''''''
        cm.CommandText = "select ApplicationNo,Paid from hr_leave_application where " & _
            " Paid=1 and Void=0 and StartDate between '" & Format(CDate(txtFrom.Text), "yyyy/MM/dd") & _
            " 00:00:00' and '" & Format(CDate(txtTo.Text), "yyyy/MM/dd") & " 23:59:59' " & _
            " and LeaveCd<>'OT' and exists (" & _
            " select Emp_Cd from py_emp_master " & Session("filter") & _
            " and py_emp_master.Emp_Cd=hr_leave_application.Emp_Cd) and " & _
            " ((ApprovedBy is not null and DateApproved is not null and RecommendedBy is null and NotedBy is null)" & _
            " or (ApprovedBy is not null and DateApproved is not null and RecommendedBy is not null and DateRecommended is not null and NotedBy is null)" & _
            " or (ApprovedBy is not null and DateApproved is not null and RecommendedBy is not null and DateRecommended is not null and NotedBy is not null and DateNoted is not null))"
        ''''''''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''''''''
        
        dr = cm.ExecuteReader
        Do While dr.Read
            ResyncLeave2Logs(dr("ApplicationNo"), False, c)
        Loop
        dr.Close()
        cm.Dispose()
        c.Close()
        c.Dispose()
        vScript = "alert('Posting complete.');"
    End Sub

    Protected Sub cmdSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSearch.Click
        DataRefresh(txtSearch.Text)
    End Sub

    Protected Sub cmdProoflist_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdProoflist.Click
        Session("origfilter") = Session("filter")
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' Modified by   :  Rudner D. Diaz                                          ''
        '' Date Modified :  April 20, 2012                                          ''
        '' Reason        :  Added a session variable to determine the type of leave ''
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        If cmbLeaveType.SelectedValue <> "Show all Leaves" Then
            Session("vleavetype") = cmbLeaveType.SelectedValue
        Else
            Session("vleavetype") = ""
        End If
        '''''''''''End of Modification''''''''''''''''''''''''''''''''''''''''''''''''
        If tblEmp.SelectedIndex >= 0 And txtType.Value = "1" Then
            Session("filter") = Session("origfilter") & " and Emp_Cd='" & tblEmp.SelectedRow.Cells(0).Text & "'"
        Else
            Session("filter") = Session("origfilter")
        End If

        vScript = "javascript:win=window.open('leavelist.aspx','win','toolbar=no,scrollbars=yes,top=100,left=100,width=800,height=600');"
    End Sub

    Protected Sub cmdView_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdView.Click
        If tblEmp.SelectedIndex >= 0 And tblEmp.SelectedIndex < tblEmp.PageSize And _
            tblApplication.SelectedIndex >= 0 And tblApplication.SelectedIndex < tblEmp.PageSize Then

            Session("empid") = tblEmp.SelectedRow.Cells(0).Text & "=>" & _
                                   tblEmp.SelectedRow.Cells(1).Text & ", " & _
                                   tblEmp.SelectedRow.Cells(2).Text
            Session("tdate") = tblApplication.SelectedRow.Cells(1).Text
            Session("mode") = "v"
            Session("leavetype") = IIf(tblApplication.SelectedRow.Cells(2).Text = "EL", "SL", tblApplication.SelectedRow.Cells(2).Text)
            Session("void") = rdoVoid.SelectedValue
            vScript = "leavewin=window.open('modifyleave.aspx','leavewin','location=no,toolber=no,width=550,height=520,top=100,left=100');"
        Else
            vScript = "alert('You must first select an application');"
        End If
    End Sub

    Protected Sub cmdEdit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdEdit.Click
        If rdoVoid.SelectedValue = 0 Then
            If Not isPayrollPosted() Then
                If tblEmp.SelectedIndex >= 0 And tblEmp.SelectedIndex < tblEmp.PageSize And _
                    tblApplication.SelectedIndex >= 0 And tblApplication.SelectedIndex < tblEmp.PageSize Then

                    Session("empid") = tblEmp.SelectedRow.Cells(0).Text & "=>" & _
                            tblEmp.SelectedRow.Cells(1).Text & ", " & _
                            tblEmp.SelectedRow.Cells(2).Text
                    Session("tdate") = tblApplication.SelectedRow.Cells(1).Text
                    Session("void") = rdoVoid.SelectedValue
                    Session("leavetype") = IIf(tblApplication.SelectedRow.Cells(2).Text = "EL", "SL", _
                        tblApplication.SelectedRow.Cells(2).Text)
                    Session.Remove("mode")
                    vScript = "leavewin=window.open('modifyleave.aspx','leavewin','location=no,toolber=no,width=550,height=520,top=100,left=100');"
                Else
                    vScript = "alert('You must first select an application to edit.');"
                End If
            Else
                vScript = "alert('Editing is not allowed due to payroll freeze.');"
            End If
        Else
            vScript = "alert('Editing of cancelled leave applications are not allowed.');"
        End If
    End Sub

    Protected Sub cmdVoid_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdVoid.Click
        If tblEmp.SelectedIndex >= 0 And tblEmp.SelectedIndex < tblEmp.PageSize And _
            tblApplication.SelectedIndex >= 0 And tblApplication.SelectedIndex < tblEmp.PageSize Then

            Dim c As New SqlClient.SqlConnection(connStr)
            Dim vVoid As Boolean = cmdVoid.Text.Contains("Void")
            Dim cm As New SqlClient.SqlCommand
            Dim dr As SqlClient.SqlDataReader
            Dim vPaid As Boolean = False
            Dim vPosted As Boolean = False
            Dim vLeaveDate As Date
            Dim isPosted As Boolean = False
            Dim vDaysLeave As Decimal = 0
            Dim vLeaveCd As String = ""
            Dim vEL As Decimal = 0
            Dim vVal(2) As String


            ' Edited April 15 2009
            ' Checking Of Payroll Post
            c.Open()
            cm.Connection = c

            'cm.CommandText = "select Void,Paid,StartDate,EffectivityDate,EL from hr_leave_application where Emp_Cd='" & _
            '    Session("empid") & "' and TranDate='" & Format(CDate(Session("tdate")), "yyyy/MM/dd HH:mm:ss") & "'"
            cm.CommandText = "select LeaveCd,Void,Paid,StartDate,EffectivityDate,EL,DaysLeave from " & _
                "hr_leave_application where ApplicationNo='" & _
                tblApplication.SelectedRow.Cells(0).Text & "'"
            dr = cm.ExecuteReader
            If dr.Read Then
                'vVoid = dr("Void")
                vPaid = dr("Paid")
                vLeaveDate = dr("StartDate")
                vEL = dr("EL")
                vDaysLeave = dr("DaysLeave")
                vLeaveCd = dr("LeaveCd")
                Session("vLeaveDate") = vLeaveDate
                If Not IsDBNull(dr("EffectivityDate")) Then vLeaveDate = dr("EffectivityDate")
            End If
            dr.Close()
            vVal(0) = "Emp ID=" & Session("empid") & _
                "|Start Date=" & vLeaveDate & _
                "|Leave Type=" & vLeaveCd & _
                "|Days Leave=" & vDaysLeave & _
                "|Paid Leave?=" & IIf(vPaid = 1, "Paid", "without Pay") & _
                "|Active?=" & IIf(vVoid, "Active", "Cancelled")

            vVal(1) = "Emp ID=" & Session("empid") & _
                "|Start Date=" & vLeaveDate & _
                "|Leave Type=" & vLeaveCd & _
                "|Days Leave=" & vDaysLeave & _
                "|Paid Leave?=" & IIf(vPaid = 1, "Paid", "without Pay") & _
                "|Active?=" & IIf(vVoid, "Cancelled", "Active")

            If Not isPayrollPosted() Then
                If vVoid Then   'void application
                    cm.CommandText = "update hr_leave_application set Void=" & IIf(vVoid, 1, 0) & _
                        " where ApplicationNo='" & tblApplication.SelectedRow.Cells(0).Text & "'"
                Else    'reactivate application
                    cm.CommandText = "update hr_leave_application set Void=" & IIf(vVoid, 1, 0) & _
                        ",DateApproved=null where ApplicationNo='" & tblApplication.SelectedRow.Cells(0).Text & "'"
                End If
                
                cm.ExecuteNonQuery()

                If vPaid Then ' If paid.
                    'synchronize leave balances
                    If vVoid Then   'leave was cancelled
                        cm.CommandText = "update py_emp_leave set Balance=Balance + " & vDaysLeave & _
                            ", Used=Used - " & vDaysLeave & _
                            " where Emp_Cd='" & Session("empid") & "' and Leave_Cd='" & vLeaveCd & "'"
                    Else            'leave was reactivated
                        cm.CommandText = "update py_emp_leave set Balance=Balance - " & vDaysLeave & _
                            ", Used=Used + " & vDaysLeave & _
                            " where Emp_Cd='" & Session("empid") & "' and Leave_Cd='" & vLeaveCd & "'"
                    End If
                    cm.ExecuteNonQuery()
                    'synchronize logs
                    ResyncLeave2Logs(tblApplication.SelectedRow.Cells(0).Text, vVoid, c)
                End If

                'If Not vVoid Then
                '    cm.CommandText = "DELETE FROM py_time_log_dtl WHERE Emp_Cd='" & Session("empid") & "' AND TranDate = '" & Format(CDate(Session("tdate")), "yyyy/MM/dd") & _
                '                     "' AND Reason = 'Posted-LeaveApp'"
                '    cm.ExecuteNonQuery()
                'End If
                EventLog(Session("uid"), Request.ServerVariables("REMOTE_ADDR"), "VOID", _
                    vVal(0), vVal(1), "Employee ID: " & Session("empid") & _
                    " Leave Application was " & IIf(vVoid, "Voided", "Reactivated"), "Leave Monitoring", c)

                vScript = "alert('Application successfully " & IIf(vVoid, "cancelled.", "reactivated.") & "');document.form1.submit();"
            Else
                vScript = "alert('Editing is not allowed due to payroll freeze.');"
            End If

            cm.Dispose()
            c.Close()
            txtStatus.Value = ""
            RefreshLeave(Session("empid"))
            GetLeaveCredits(Session("empid"))
            Session.Remove("leavetype")
            Session.Remove("hours")
        Else
            vScript = "alert('You must first select an application to Void/Reactivate.');"
        End If
    End Sub

    Protected Sub cmdSync_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSync.Click
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cmEmp As New SqlClient.SqlCommand
        Dim cm As New SqlClient.SqlCommand
        Dim cmRef As New SqlClient.SqlCommand
        Dim rsRef As SqlClient.SqlDataReader
        Dim rsEmp As SqlClient.SqlDataReader
        Dim rs As SqlClient.SqlDataReader

        Dim vTotalEO As Single = 0
        Dim vTotExpired As Single = 0
        Dim vUsed As Single = 0

        '''''' Added by :   Rudner Diaz                                                   ''
        '''''' Date     :   July 3, 2012                                                  ''
        '''''' Reason   :   Synchronization of Leaves from nexus(leave.aspx) to workspace ''
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

        Dim vVLUsed As Decimal = 0
        Dim vSLUsed As Decimal = 0
        Dim vVLPrevUsed As Decimal = 0
        Dim vSLPrevUsed As Decimal = 0
        Dim vVLCurrCredit As Decimal = 0
        Dim vVLLastCredit As Decimal = 0
        Dim vSLCurrCredit As Decimal = 0
        Dim vSLLastCredit As Decimal = 0
        Dim dVLExpDate As Date = Nothing
        Dim dSLExpDate As Date = Nothing
        ''''''''''''''''''''''''''''''''''''''''''

        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY:  VIC GATCHALIAN                                  ''
        '' DATE MODIFIED: 2/8/2013                                       ''
        '' PURPOSE: TO ADD THE RETRIEVAL OF RANK AND GROUP               ''
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        Dim vRank As String = "99"
        Dim vGroupCd As String = "99"
        Dim vStatus As String = "99"
        Dim vDateHired As Date
        Dim vYrsOfService As Decimal = 0
        Dim vCredits As Decimal = 0
        '''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''''''

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            cmEmp.Dispose()
            Exit Sub
        End Try

        cm.Connection = c
        cmEmp.Connection = c
        cmRef.Connection = c

        'cmEmp.CommandText = "select Emp_Cd from py_emp_master where Date_Resign is null and Emp_Cd in ('50401')"

        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFIED BY: VIC GATCHALIAN                              ''
        '' DATE MODIFIED: 2/8/2013                                  ''
        '' PURPOSE: TO GET THE RANK OF THE EMPLOYEE TO GET THE LEAVE''
        ''          CREDIT OF THE EMPLOYEE.                         ''
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        ''''''''''''''''''' OLD CODE '''''''''''''''''''''''''''''''''
        'cmEmp.CommandText = "select Emp_Cd from py_emp_master where Date_Resign is null order by Emp_Lname"
        ''''''''''''''''''' END OLD CODE '''''''''''''''''''''''''''''
        cmEmp.CommandText = "select Emp_Cd,EmploymentType,GroupCd,Emp_Status,Start_Date " & _
            "from py_emp_master where Date_Resign is null order by Emp_Lname"
        ''''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''


        Try
            rsEmp = cmEmp.ExecuteReader
            Do While rsEmp.Read
                vVLUsed = 0
                vSLUsed = 0
                vVLPrevUsed = 0
                vSLPrevUsed = 0
                vVLCurrCredit = 0
                vVLLastCredit = 0
                vSLCurrCredit = 0
                vSLLastCredit = 0

                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY:  VIC GATCHALIAN                             ''
                '' DATE MODIFIED: 2/8/2013                                  ''
                '' PURPOSE: TO RETRIEVE THE RANK AND GROUP OF THE EMPLOYEE  ''
                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                vRank = rsEmp("EmploymentType")
                vGroupCd = rsEmp("GroupCd")
                vStatus = rsEmp("Emp_Status")
                If Not IsDBNull(rsEmp("Start_Date")) Then
                    vDateHired = rsEmp("Start_Date")
                    vYrsOfService = Math.Round(DateDiff(DateInterval.Day, vDateHired, Now) / 365, 2)
                End If
                '''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''

                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY:  VIC GATCHALIAN                                     ''
                '' DATE MODIFIED: 2/8/2013                                          ''
                '' PURPOSE: TO UPDATE THE LEAVE CREDITS OF ALL LEAVES               ''
                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                cmRef.CommandText = "select Leave_Cd from py_leave_ref where AlwaysPaid=0 and (Rank='*' or Rank='" & vRank & _
                    "') and (Status='*' or Status='" & vStatus & "')"
                rsRef = cmRef.ExecuteReader
                Do While rsRef.Read
                    vCredits = 0
                    cm.CommandText = "select Credits from py_leave_table where LeaveCd='" & _
                        rsRef("Leave_Cd") & "' and EmploymentType='" & vRank & _
                        "' and " & vYrsOfService & " between YearFrom and YearTo"
                    rs = cm.ExecuteReader
                    If rs.Read Then
                        vCredits = rs("Credits")
                    End If
                    rs.Close()

                    cm.CommandText = "select 1 from py_emp_leave where Emp_Cd='" & rsEmp("Emp_Cd") & "'"
                    rs = cm.ExecuteReader
                    If rs.HasRows Then
                        rs.Close()
                        cm.CommandText = "update py_emp_leave set Credit=" & vCredits & " where Leave_Cd='" & _
                            rsRef("Leave_Cd") & "' and Emp_Cd='" & rsEmp("Emp_Cd") & "'"
                    Else
                        rs.Close()
                        cm.CommandText = "insert into py_emp_leave (Emp_Cd,Leave_Cd,Credit,[Used],Balance) values ('" & _
                            rsEmp("Emp_Cd") & "','" & rsRef("Leave_Cd") & "'," & vCredits & ",0,0)"
                    End If
                    cm.ExecuteNonQuery()
                Loop
                rsRef.Close()
                ''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''''''''''


                'get current and Last credit of VL
                cm.CommandText = "select * from py_emp_leave where Emp_Cd='" & rsEmp("Emp_Cd") & _
                    "' and Leave_Cd='VL'"
                Try
                    rs = cm.ExecuteReader
                    If rs.Read Then
                        vVLCurrCredit = IIf(IsDBNull(rs("Credit")), 0, rs("Credit"))
                        vVLLastCredit = IIf(IsDBNull(rs("BalanceLastYear")), 0, rs("BalanceLastYear"))
                        If Not IsDBNull(rs("ExpiryDate")) Then
                            dVLExpDate = Format(rs("ExpiryDate"), "yyyy/MM/dd")
                        End If
                    End If
                    rs.Close()
                Catch ex As SqlClient.SqlException
                    vScript = "alert('Error occurred while trying to retrieve VL Balances. Error is: " & _
                        ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                    c.Close()
                    c.Dispose()
                    cm.Dispose()
                    cmEmp.Dispose()
                    Exit Sub
                End Try

                '''' Get the VL application based on the Transaction date to charged from the Previous Balance
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '''' Modified By:  Rudner D. Diaz, Jr.
                '''' Date       :  5/11/2012
                '''' Reason     :  To get the number of days that be charge on the previous years balance
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                If dVLExpDate <> Nothing Then
                    'get all filed applications prior or equal to expiry date of previous year's balance
                    cm.CommandText = "select sum(DaysLeave) as TotalUsed from hr_leave_application where Emp_Cd='" & rsEmp("Emp_Cd") & _
                        "' and LeaveCd='VL' and Void=0 and Paid=1 and ApprovedBy is not null and DateApproved is not null and " & _
                        "(NotedBy is null or (NotedBy is not null and DateNoted is not null)) and " & _
                        "(RecommendedBy is null or (RecommendedBy is not null and DateRecommended is not null))" & _
                        " and TranDate <='" & Format(dVLExpDate, "yyyy/MM/dd") & "' and Year(TranDate)=" & Now.Year
                    rs = cm.ExecuteReader
                    If rs.Read Then
                        If Not IsDBNull(rs("TotalUsed")) Then vVLPrevUsed = rs("TotalUsed")
                    End If
                    rs.Close()

                    'now get all filed application past the expiry date of previous year's balance
                    cm.CommandText = "select sum(DaysLeave) as TotalUsed from hr_leave_application where Emp_Cd='" & rsEmp("Emp_Cd") & _
                        "' and LeaveCd='VL' and Void=0 and Paid=1 and ApprovedBy is not null and DateApproved is not null and " & _
                        "(NotedBy is null or (NotedBy is not null and DateNoted is not null)) and " & _
                        "(RecommendedBy is null or (RecommendedBy is not null and DateRecommended is not null)) and TranDate >'" & _
                        Format(dVLExpDate, "yyyy/MM/dd") & "' and year(TranDate)=" & Now.Year
                    rs = cm.ExecuteReader
                    If rs.Read Then
                        If Not IsDBNull(rs("TotalUsed")) Then vVLUsed = rs("TotalUsed")
                    End If
                    rs.Close()
                Else
                    'get all used applications and assume the deductions to previous year's balance
                    cm.CommandText = "select sum(DaysLeave) as TotalUsed from hr_leave_application where Emp_Cd='" & rsEmp("Emp_Cd") & _
                        "' and LeaveCd='VL' and Void=0 and Paid=1 and ApprovedBy is not null and DateApproved is not null and " & _
                        "(NotedBy is null or (NotedBy is not null and DateNoted is not null)) and " & _
                        "(RecommendedBy is null or (RecommendedBy is not null and DateRecommended is not null))" & _
                        " and Year(TranDate)=" & Now.Year
                    rs = cm.ExecuteReader
                    If rs.Read Then
                        If Not IsDBNull(rs("TotalUsed")) Then vVLPrevUsed = rs("TotalUsed")
                    End If
                    rs.Close()
                End If

                If vVLLastCredit > 0 Then   'with previous year's balance deduct used from previous years first 
                    If vVLLastCredit - vVLPrevUsed < 0 Then 'last credit is not sufficient
                        cm.CommandText = "update py_emp_leave set UsedLastYear=BalanceLastYear" & _
                            ",Used=" & vVLUsed + (vVLPrevUsed - vVLLastCredit) & ",Balance=" & vVLCurrCredit - (vVLUsed + (vVLPrevUsed - vVLLastCredit)) & _
                            " where Emp_Cd='" & rsEmp("Emp_Cd") & "' and Leave_Cd='VL'"
                    Else    'last credit is sufficient to total used
                        cm.CommandText = "update py_emp_leave set UsedLastYear=" & vVLPrevUsed & _
                            ",Used=" & vVLUsed & ",Balance=" & vVLCurrCredit - vVLUsed & _
                            " where Emp_Cd='" & rsEmp("Emp_Cd") & "' and Leave_Cd='VL'"
                    End If
                Else    'update the current balance instead 
                    cm.CommandText = "update py_emp_leave set Used=" & vVLUsed + vVLPrevUsed & ",Balance=" & vVLCurrCredit - vVLUsed - vVLPrevUsed & _
                        ",UsedLastYear=BalanceLastYear where Emp_Cd='" & rsEmp("Emp_Cd") & "' and Leave_Cd='VL'"
                End If
                cm.ExecuteNonQuery()

                'get current and last credit of SL
                cm.CommandText = "select * from py_emp_leave where Emp_Cd='" & rsEmp("Emp_Cd") & _
                   "' and Leave_Cd='SL'"
                Try
                    rs = cm.ExecuteReader
                    If rs.Read Then
                        vSLCurrCredit = IIf(IsDBNull(rs("Credit")), 0, rs("Credit"))
                        vSLLastCredit = IIf(IsDBNull(rs("BalanceLastYear")), 0, rs("BalanceLastYear"))
                        If Not IsDBNull(rs("ExpiryDate")) Then
                            dSLExpDate = Format(rs("ExpiryDate"), "yyyy/MM/dd")
                        End If
                    End If
                    rs.Close()
                Catch ex As SqlClient.SqlException
                    vScript = "alert('Error occurred while trying to retrieve SL Balances. Error is: " & _
                        ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
                    c.Close()
                    c.Dispose()
                    cm.Dispose()
                    cmEmp.Dispose()
                    Exit Sub
                End Try

                If dSLExpDate <> Nothing Then
                    'now get all filed application past the expiry date of previous year's balance
                    cm.CommandText = "select sum(DaysLeave) as TotalUsed from hr_leave_application where Emp_Cd='" & rsEmp("Emp_Cd") & _
                        "' and LeaveCd='SL' and Void=0 and Paid=1 and ApprovedBy is not null and DateApproved is not null and " & _
                        "(NotedBy is null or (NotedBy is not null and DateNoted is not null)) and " & _
                        "(RecommendedBy is null or (RecommendedBy is not null and DateRecommended is not null)) and TranDate <= '" & _
                        Format(dSLExpDate, "yyyy/MM/dd") & "' and year(TranDate)=" & Now.Year
                    'Response.Write(cm.CommandText)
                    rs = cm.ExecuteReader
                    If rs.Read Then
                        If Not IsDBNull(rs("TotalUsed")) Then vSLPrevUsed = rs("TotalUsed")
                    End If
                    rs.Close()

                    'now get all filed application past the expiry date of previous year's balance
                    cm.CommandText = "select sum(DaysLeave) as TotalUsed from hr_leave_application where Emp_Cd='" & rsEmp("Emp_Cd") & _
                        "' and LeaveCd='SL' and Void=0 and Paid=1 and ApprovedBy is not null and DateApproved is not null and " & _
                        "(NotedBy is null or (NotedBy is not null and DateNoted is not null)) and " & _
                        "(RecommendedBy is null or (RecommendedBy is not null and DateRecommended is not null)) and TranDate >'" & _
                        Format(dSLExpDate, "yyyy/MM/dd") & "' and year(TranDate)=" & Now.Year
                    rs = cm.ExecuteReader
                    If rs.Read Then
                        If Not IsDBNull(rs("TotalUsed")) Then vSLUsed = rs("TotalUsed")
                    End If
                    rs.Close()
                Else
                    'get all used applications and assume the deductions to previous year's balance
                    cm.CommandText = "select sum(DaysLeave) as TotalUsed from hr_leave_application where Emp_Cd='" & rsEmp("Emp_Cd") & _
                        "' and LeaveCd='SL' and Void=0 and Paid=1 and ApprovedBy is not null and DateApproved is not null and " & _
                        "(NotedBy is null or (NotedBy is not null and DateNoted is not null)) and " & _
                        "(RecommendedBy is null or (RecommendedBy is not null and DateRecommended is not null))" & _
                        " and Year(TranDate)=" & Now.Year
                    rs = cm.ExecuteReader
                    If rs.Read Then
                        If Not IsDBNull(rs("TotalUsed")) Then vSLPrevUsed = rs("TotalUsed")
                    End If
                    rs.Close()
                End If

                '''''''If no credit in the current year deduct the Used to the fund(Previous Balance)
                '''' Modified By    :   Rudner D. Diaz, JR.                                                    ''
                '''' Date Modified  :   May 18, 2012                                                           ''
                '''' Reason         :   For Manila Peninsula - To deduct the SL used to the Current Balance    ''
                ''''                :   before to deduct in Fund(Previous Balance)                             ''
                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                If vSLCurrCredit > 0 Then
                    If vSLCurrCredit - vSLUsed - vSLPrevUsed < 0 Then
same:
                        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                        '' MODIFIED BY:  VIC GATCHALIAN                                 ''
                        '' DATE MODIFIED: 7/16/2012                                     ''
                        '' PURPOSE: TO REMOVE THE CALCULATION OF BALANCELASTYEAR        ''
                        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                        ''''''''''''''''''' OLD CODE '''''''''''''''''''''''''''''''''''''
                        'cm.CommandText = "update py_emp_leave set UsedLastYear=" & (vSLPrevUsed + vSLUsed) - vSLCurrCredit & _
                        '    ",Used=" & vSLCurrCredit & ",Balance=0,BalanceLastYear=" & vSLLastCredit - ((vSLPrevUsed + vSLUsed) - vSLCurrCredit) & _
                        '    " where Emp_Cd='" & rsEmp("Emp_Cd") & "' and Leave_Cd='SL'"
                        ''''''''''''''''''' END OLD CODE ''''''''''''''''''''''''''''''''''
                        cm.CommandText = "update py_emp_leave set UsedLastYear=" & (vSLPrevUsed + vSLUsed) - vSLCurrCredit & _
                            ",Used=" & vSLCurrCredit & ",Balance=0 where Emp_Cd='" & rsEmp("Emp_Cd") & "' and Leave_Cd='SL'"
                        ''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''
                    Else
                        cm.CommandText = "update py_emp_leave set UsedLastYear=0" & _
                            ",Used=" & vSLUsed + vSLPrevUsed & ",Balance=" & vSLCurrCredit - vSLUsed - vSLPrevUsed & _
                            " where Emp_Cd='" & rsEmp("Emp_Cd") & "' and Leave_Cd='SL'"
                    End If
                Else
                    GoTo same
                End If

                '''''''''''''''''''''''''''''For All Clients'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                'If vSLLastCredit > 0 Then   'with previous year's balance deduct used from previous years first 
                '    If vSLLastCredit - vSLPrevUsed < 0 Then 'last credit is not sufficient
                '        cm.CommandText = "update py_emp_leave set UsedLastYear=BalanceLastYear" & _
                '            ",Used=" & vSLUsed + (vSLPrevUsed - vSLLastCredit) & ",Balance=" & vSLCurrCredit - (vSLUsed + (vSLPrevUsed - vSLLastCredit)) & _
                '            " where Emp_Cd='" & rsEmp("Emp_Cd") & "' and Leave_Cd='SL'"
                '    Else    'last credit is sufficient to total used
                '        cm.CommandText = "update py_emp_leave set UsedLastYear=" & vSLPrevUsed & _
                '            ",Used=" & vSLUsed & ",Balance=" & vSLCurrCredit - vSLUsed & _
                '            " where Emp_Cd='" & rsEmp("Emp_Cd") & "' and Leave_Cd='SL'"
                '    End If
                'Else    'update the current balance instead 
                '    cm.CommandText = "update py_emp_leave set Used=" & vSLUsed + vSLPrevUsed & ",Balance=" & vSLCurrCredit - vSLUsed - vSLPrevUsed & _
                '        ",UsedLastYear=BalanceLastYear where Emp_Cd='" & rsEmp("Emp_Cd") & "' and Leave_Cd='SL'"
                'End If
                cm.ExecuteNonQuery()


                'synchronize extra off
                
                'get approved OT for EO
                'cm.CommandText = "select DaysLeave,StartDate from hr_leave_application " & _
                '    "where DateApproved is not null and Void=0 and LeaveCd='OT' and CreditTo='EO' and Emp_Cd='" & _
                '    vId & "'"
                cm.CommandText = "select * from hr_leave_application where Emp_Cd='" & rsEmp("Emp_Cd") & "'" & _
                                 "and LeaveCd='OT' and CreditTo='EO' and " & _
                                 "((ApprovedBy is not null and DateApproved is not null and RecommendedBy is null) or " & _
                                 " (ApprovedBy is not null and DateApproved is not null and RecommendedBy is Not null and " & _
                                 " DateRecommended is Not null and NotedBy is null) or " & _
                                 "(ApprovedBy is not null and DateApproved is not null and RecommendedBy is not null and DateRecommended is not null and " & _
                                 "NotedBy is not null and DateNoted is Not null)) and Void=0 and Status is null order by StartDate desc"

                'cm.CommandText = "select * from hr_leave_application where Emp_Cd='50401'" & _
                '                 "and LeaveCd='OT' and CreditTo='EO' and " & _
                '                 "((ApprovedBy is not null and DateApproved is not null and RecommendedBy is null) or " & _
                '                 " (ApprovedBy is not null and DateApproved is not null and RecommendedBy is Not null and " & _
                '                 " DateRecommended is Not null and NotedBy is null) or " & _
                '                 "(ApprovedBy is not null and DateApproved is not null and RecommendedBy is not null and DateRecommended is not null and " & _
                '                 "NotedBy is not null and DateNoted is Not null)) and Void=0 and Status is null order by StartDate desc"
                'Response.Write(cm.CommandText)

                rs = cm.ExecuteReader
                vTotExpired = 0
                vTotalEO = 0
                Do While rs.Read
                    '''''''''''''''''''''''''''''''''''''''''''''''''''''
                    ''''' Modified By   :   Rudner D. Diaz, Jr.
                    ''''' Date          :   July 2, 2012
                    ''''' Reason        :   Commented because the code is already added on the App_Code/eis
                    'vTotalEO += rs("DaysLeave")   ''''
                    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

                    vTotalEO += EOTimeConvert(rs("Emp_Cd"), Format(rs("StartDate"), "yyyy/MM/dd"), rs("DaysLeave"), rs("Remarks"), c)

                    If Math.Abs(DateDiff(DateInterval.Day, CDate(rs("StartDate")), Now)) > 30 Then
                        'vTotExpired += rs("DaysLeave")
                    End If
                Loop
                rs.Close()

                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '' MODIFIED BY:  VIC GATCHALIAN                                                   ''
                '' DATE MODIFIED: 3/9/2012                                                        ''
                '' PURPOSE: TO RE-CALIBRATE THE DIVISOR TO 6.5 AS PER POLICY OF MANILA PENINSULA  ''
                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                ''''''''''''''''''''''''''''''' OLD CODE '''''''''''''''''''''''''''''''''''''''''''
                'vTotalEO = Math.Round(vTotalEO / 8, 2)
                'vTotExpired = Math.Round(vTotExpired / 8, 2)
                '''''''''''''''''''''''''''''' END OLD CODE ''''''''''''''''''''''''''''''''''''''''
                'vTotalEO = Math.Round(vTotalEO / 6.5, 2)
                'vTotExpired = Math.Round(vTotExpired / 6.5, 2)
                '''''''''''''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''''''''

                'get used EOs
                'cm.CommandText = "select sum(DaysLeave) as Used from hr_leave_application " & _
                '    " where DateApproved is not null and Void=0 and Paid=1 and LeaveCd='EO' and Emp_Cd='" & _
                '    vId & "'"

                cm.CommandText = "select sum(DaysLeave) as Used from hr_leave_application where LeaveCd='EO' and Emp_Cd='" & rsEmp("Emp_Cd") & "' and " & _
                                 "((ApprovedBy is not null and DateApproved is not null and RecommendedBy is null)" & _
                                 " or (ApprovedBy is not null and DateApproved is not null and RecommendedBy is not null and DateRecommended is not null and NotedBy is null)" & _
                                 " or (ApprovedBy is not null and DateApproved is not null and RecommendedBy is not null and DateRecommended is not null " & _
                                 " and NotedBy is not null and DateNoted is not null)) and Void=0 "

                'cm.CommandText = "select sum(DaysLeave) as Used from hr_leave_application where LeaveCd='EO' and Emp_Cd='50401' and " & _
                '                 "((ApprovedBy is not null and DateApproved is not null and RecommendedBy is null)" & _
                '                 " or (ApprovedBy is not null and DateApproved is not null and RecommendedBy is not null and DateRecommended is not null and NotedBy is null)" & _
                '                 " or (ApprovedBy is not null and DateApproved is not null and RecommendedBy is not null and DateRecommended is not null " & _
                '                 " and NotedBy is not null and DateNoted is not null)) and Void=0 "
                rs = cm.ExecuteReader
                vUsed = 0
                If rs.Read Then
                    If Not IsDBNull(rs("Used")) Then vUsed = rs("Used")
                End If
                rs.Close()
                'update leave credit of employee
                cm.CommandText = "select * from py_emp_leave where Leave_Cd='EO' and Emp_Cd='" & rsEmp("Emp_Cd") & "'"
                rs = cm.ExecuteReader
                If rs.HasRows Then
                    cm.CommandText = "update py_emp_leave set Credit=" & vTotalEO & _
                        ",Used=" & vUsed + vTotExpired & _
                        ",Balance=" & vTotalEO - vUsed - vTotExpired & _
                        " where Leave_Cd='EO' and Emp_Cd='" & rsEmp("Emp_Cd") & "'"
                    'Response.Write(cm.CommandText)
                Else
                    cm.CommandText = "insert into py_emp_leave (Emp_Cd,Leave_Cd,Credit,Balance,Used,LastUpdate) values ('" & _
                        rsEmp("Emp_Cd") & "','EO'," & vTotalEO & "," & vTotalEO - vUsed - vTotExpired & "," & vUsed + vTotExpired & ",'" & _
                        Format(Now, "yyyy/MM/dd HH:mm:ss") & "')"
                End If
                rs.Close()
                cm.ExecuteNonQuery()
                ''''''''''''''END OF MODIFICATION''''''''''''''''''''''''''''''''''''''
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                ''''' Commented by  :   Rudner D. Diaz                               ''
                ''''' Date          :   July 3, 2012                                 ''
                ''''' Reason        :   To sysnchronized the computation of leaves   ''
                '''''                   from nexus(leave.aspx) to workspace          ''
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                ''get approved OT for EO
                'cm.CommandText = "select DaysLeave,StartDate from hr_leave_application " & _
                '    "where DateApproved is not null and Void=0 and LeaveCd='OT' and CreditTo='EO' and Emp_Cd='" & _
                '    rsEmp("Emp_Cd") & "'"

                'rs = cm.ExecuteReader
                'vTotExpired = 0
                'Do While rs.Read
                '    vTotalEO += rs("DaysLeave")
                '    If Math.Abs(DateDiff(DateInterval.Day, CDate(rs("StartDate")), Now)) > 30 Then
                '        'vTotExpired += rs("DaysLeave")
                '    End If
                'Loop
                'rs.Close()

                'vTotalEO = Math.Round(vTotalEO / 6.5, 2)
                'vTotExpired = Math.Round(vTotExpired / 6.5, 2)

                ''get used EOs
                'cm.CommandText = "select sum(DaysLeave) as Used from hr_leave_application " & _
                '    " where DateApproved is not null and Void=0 and Paid=1 and LeaveCd='EO' and Emp_Cd='" & _
                '    rsEmp("Emp_Cd") & "'"

                'rs = cm.ExecuteReader
                'If rs.Read Then
                '    If Not IsDBNull(rs("Used")) Then vUsed = rs("Used")
                'End If
                'rs.Close()
                ''update leave credit of employee
                'cm.CommandText = "select * from py_emp_leave where Leave_Cd='EO' and Emp_Cd='" & rsEmp("Emp_Cd") & "'"
                'rs = cm.ExecuteReader
                'If rs.HasRows Then
                '    cm.CommandText = "update py_emp_leave set Credit=" & vTotalEO & _
                '        ",Used=" & vUsed + vTotExpired & _
                '        ",Balance=" & vTotalEO - vUsed - vTotExpired & _
                '        " where Leave_Cd='EO' and Emp_Cd='" & rsEmp("Emp_Cd") & "'"
                'Else
                '    cm.CommandText = "insert into py_emp_leave (Emp_Cd,Leave_Cd,Credit,Balance,Used,LastUpdate) values ('" & _
                '        rsEmp("Emp_Cd") & "','EO'," & vTotalEO & "," & vTotalEO - vUsed - vTotExpired & "," & vUsed + vTotExpired & ",'" & _
                '        Format(Now, "yyyy/MM/dd HH:mm:ss") & "')"
                'End If
                'rs.Close()
                'cm.ExecuteNonQuery()
                '''''''''''' End of Modification  '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            Loop
            rsEmp.Close()
            vScript = "alert('Recalculation of Leave Balance complete. You may click the Print Prooflist to dump the leave balance report.');"
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to retrieve record. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            cm.Dispose()
            cmEmp.Dispose()
            c.Dispose()
        End Try
    End Sub

    Protected Sub tblLeave_PageIndexChanging(sender As Object, e As GridViewPageEventArgs) Handles tblLeave.PageIndexChanging
        Dim vEmpId As String = tblEmp.SelectedRow.Cells(0).Text

        tblLeave.PageIndex = e.NewPageIndex
        GetLeaveCredits(vEmpId)
    End Sub

End Class
