﻿Imports denaro.fis
Partial Class brokentimeallow
    Inherits System.Web.UI.Page
    Public vScript As String = ""
    Public vDump As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If

        If Not CanRun(Session("caption"), Request.Item("id")) Then
            Session("denied") = "1"
            Server.Transfer("main.aspx")
            Exit Sub
        End If

        If Not IsPostBack Then
            Dim iCtr As Integer

            cmbYrFr.Items.Clear()
            cmbYrTo.Items.Clear()
            For iCtr = Now.Year - 5 To Now.Year
                cmbYrFr.Items.Add(iCtr)
                cmbYrTo.Items.Add(iCtr)
            Next
            cmbMonthFr.SelectedValue = Now.Month
            cmbMonthTo.SelectedValue = Now.Month
            cmbYrFr.SelectedValue = Now.Year
            cmbYrTo.SelectedValue = Now.Year
            BuildDaysFrom()
            BuildDaysTo()
        End If
    End Sub
    Private Sub BuildDaysFrom()
        Dim ictr As Integer

        cmbDayFr.Items.Clear()
        For ictr = 1 To MonthEND(CDate(cmbMonthFr.SelectedValue & "/1/" & cmbYrFr.SelectedValue)).Day
            cmbDayFr.Items.Add(ictr)
        Next
        cmbDayFr.SelectedValue = Now.Day
    End Sub
    Private Sub BuildDaysTo()
        Dim ictr As Integer

        cmbDayTo.Items.Clear()
        For ictr = 1 To MonthEND(CDate(cmbMonthTo.SelectedValue & "/1/" & cmbYrTo.SelectedValue)).Day
            cmbDayTo.Items.Add(ictr)
        Next
        cmbDayTo.SelectedValue = Now.Day
    End Sub
    Protected Sub cmdClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdClose.Click
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub cmbMonthFr_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbMonthFr.SelectedIndexChanged, cmbYrFr.SelectedIndexChanged
        BuildDaysFrom()
    End Sub

    Protected Sub cmbMonthTo_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbMonthTo.SelectedIndexChanged, cmbYrTo.SelectedIndexChanged
        BuildDaysTo()
    End Sub

    Protected Sub cmdGenerate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdGenerate.Click
        Dim vData As New StringBuilder
        Dim vClass As String = "odd"
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cmRef As New SqlClient.SqlCommand
        Dim rs As SqlClient.SqlDataReader
        Dim rsRef As SqlClient.SqlDataReader
        Dim iCtr As Integer
        Dim vId As String = ""

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            cmRef.Dispose()
            Exit Sub
        End Try

        cm.Connection = c
        cmRef.Connection = c
        cm.CommandText = "select distinct COUNT(*),Date_Sched,Emp_Cd," & _
            "(select Emp_Lname+', '+Emp_Fname from py_emp_master where py_emp_master.Emp_Cd=py_emp_time_sched.Emp_Cd) as Name " & _
            "from py_emp_time_sched where Date_Sched between '" & _
            cmbYrFr.SelectedValue & "/" & cmbMonthFr.SelectedValue & "/" & cmbDayFr.SelectedValue & _
            "' and '" & cmbYrTo.SelectedValue & "/" & cmbMonthTo.SelectedValue & "/" & cmbDayTo.SelectedValue & _
            "' group by Emp_Cd,Date_Sched order by Name,Date_Sched"

        Try
            rs = cm.ExecuteReader
            iCtr = 0
            Do While rs.Read
                If rs(0) > 1 Then
                    If vId = "" Then
                        vId = rs("Emp_Cd")
                    End If

                    If vId <> rs("Emp_Cd") Then
                        vData.AppendLine("<tr class='" & vClass & "'>" & _
                            "<td class='labelL'>&nbsp;</td>" & _
                            "<td class='labelL'>&nbsp;</td>" & _
                            "<td class='labelC'>Total:</td>" & _
                            "<td class='labelC'>" & iCtr & "</td>" & _
                            "<td class='labelC'>&nbsp;</td></tr>")
                        vId = rs("Emp_Cd")
                        iCtr = 0
                    End If
                    cmRef.CommandText = "select Start_Time,End_Time from py_emp_time_sched where Emp_Cd='" & _
                        rs("Emp_Cd") & "' and Date_Sched='" & Format(rs("Date_Sched"), "yyyy/MM/dd") & "'"
                    rsRef = cmRef.ExecuteReader
                    rsRef.Read()
                    vData.AppendLine("<tr class='" & vClass & "'>" & _
                        "<td class='labelL'>" & rs("Emp_Cd") & "</td>" & _
                        "<td class='labelL'>" & rs("Name") & "</td>" & _
                        "<td class='labelC'>" & Format(rs("Date_Sched"), "MM/dd/yyyy") & "</td>" & _
                        "<td class='labelC'>" & rsRef("Start_Time") & "</td>" & _
                        "<td class='labelC'>" & rsRef("End_Time") & "</td></tr>")
                    Do While rsRef.Read
                        vData.AppendLine("<tr class='" & vClass & "'>" & _
                            "<td class='labelL'>&nbsp;</td>" & _
                            "<td class='labelL'>&nbsp;</td>" & _
                            "<td class='labelC'>&nbsp;</td>" & _
                            "<td class='labelC'>" & rsRef("Start_Time") & "</td>" & _
                            "<td class='labelC'>" & rsRef("End_Time") & "</td></tr>")
                    Loop
                    rsRef.Close()
                    vClass = IIf(vClass = "odd", "even", "odd")
                    iCtr += 1
                End If
            Loop
            rs.Close()
            vDump = vData.ToString
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to retrieve records. Error is: " & _
                ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            c.Dispose()
            cm.Dispose()
            cmRef.Dispose()
        End Try
    End Sub
End Class
