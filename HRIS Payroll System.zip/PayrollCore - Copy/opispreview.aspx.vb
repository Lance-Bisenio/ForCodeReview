Imports System.Data
Imports denaro.fis

Partial Class step13
    Inherits System.Web.UI.Page
    Public vEmpHist As String = ""
    Public vEmpSholastic As String = ""
    Public vEmpCharRef As String = ""
    Public vDepInfo As String = ""
    Public vEmpSiblings As String = ""
    Public vEmpRelatives As String = ""
    Public vEmpSeminars As String = ""
    Public vExamsTaken As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Response.Write("You must first login to view this page.")
            Exit Sub
        End If
        If Session("id") = "" Or Session("id") = Nothing Then
            Response.Write("<p align='center'><strong>You must first select an Employee to view its data.</strong></p>")
            Exit Sub
        End If
        If Not IsPostBack Then
            Dim c As New sqlclient.sqlconnection(connStr)
            Dim cm As New sqlclient.sqlcommand("select * from hr_emp_tmp_master where ApplicantNo='" & Session("id") & "'", c)
            Dim rs As sqlclient.sqldatareader
            Dim cmRef As New sqlclient.sqlcommand
            Dim rsRef As sqlclient.sqldatareader

            c.Open()
            rs = cm.ExecuteReader
            If rs.Read Then

                lblAppNo.Text = Session("id")
                lblAppName.Text = IIf(IsDBNull(rs("Lname")), "", rs("Lname"))
                lblEmpFname.Text = IIf(IsDBNull(rs("Fname")), "", rs("Fname"))
                lblEmpMName.Text = IIf(IsDBNull(rs("Mname")), "", rs("Mname"))
                lblAppNName.Text = IIf(IsDBNull(rs("NickName")), "", rs("NickName"))
                lblAppAddress.Text = IIf(IsDBNull(rs("Address")), "", rs("Address"))
                lblAppMobileNo.Text = IIf(IsDBNull(rs("MobileNo")), "", rs("MobileNo"))
                lblAppTelNo.Text = IIf(IsDBNull(rs("Tel")), "", rs("Tel"))
                lblAppResCert.Text = IIf(IsDBNull(rs("Res_Cert")), "", rs("Res_Cert"))
                lblPlaceIssued.Text = IIf(IsDBNull(rs("ResCertPlaceIssued")), "", rs("ResCertPlaceIssued"))

                lblDateIssued.Text = ""
                If Not IsDBNull(rs("ResCertDateIssued")) Then
                    lblDateIssued.Text = Format(rs("ResCertDateIssued"), "MM/dd/yyyy")
                End If
                lblAppTIN.Text = IIf(IsDBNull(rs("Tin")), "", rs("Tin"))
                lblAppEmailAddress.Text = IIf(IsDBNull(rs("Email")), "", rs("Email"))
                lblAppGSISNo.Text = IIf(IsDBNull(rs("GSIS_No")), "", rs("GSIS_No"))
                lblAppSSSNo.Text = IIf(IsDBNull(rs("SSS_No")), "", rs("SSS_No"))
                lblAppPhilHealth.Text = IIf(IsDBNull(rs("PhicNo")), "", rs("PhicNo"))
                lblAppPagIbig.Text = IIf(IsDBNull(rs("Pagibig_No")), "", rs("Pagibig_No"))
                
                lblAge.Text = 0
                lblAppBday.Text = ""
                If Not IsDBNull(rs("Bday")) Then
                    If IsDate(rs("Bday")) Then
                        lblAppBday.Text = rs("Bday")
                        lblAge.Text = DateDiff(DateInterval.Year, CDate(rs("Bday")), Now())
                        If CDate(rs("Bday")).Month > Now.Month Then
                            lblAge.Text = Val(lblAge.Text) - 1
                        Else
                            If CDate(rs("Bday")).Month >= Now.Month Then
                                If CDate(rs("Bday")).Day > Now.Day Then
                                    lblAge.Text = Val(lblAge.Text) - 1
                                End If
                            End If

                        End If
                        'txtAge.Text = Math.Floor(DateDiff(DateInterval.Month, rs("Bday"), Now) / 12)
                    End If
                End If


                lblNoofChildren.Text = IIf(IsDBNull(rs("ChildrenNo")), 0, rs("ChildrenNo"))

                lblAppBPlace.Text = IIf(IsDBNull(rs("BirthPlace")), "", rs("BirthPlace"))
                lblEyeColor.Text = IIf(IsDBNull(rs("EyeColor")), "", rs("EyeColor"))
                lblHairColor.Text = IIf(IsDBNull(rs("HairColor")), "", rs("HairColor"))
                lblDistingMark.Text = IIf(IsDBNull(rs("DistingMark")), "", rs("DistingMark"))

                lblAppSex.Text = "Female"
                If rs("male") = 1 Then
                    lblAppSex.Text = "Male"
                End If

                lblAppBloodType.Text = IIf(IsDBNull(rs("BloodType")), "", rs("BloodType"))
                lblAppSkills.Text = ""
                If Not IsDBNull(rs("Skills")) Then
                    cmRef.Connection = c
                    cmRef.CommandText = "select SkillCd,Descr from hr_skills_ref where SkillCd in ('" & _
                        rs("Skills").ToString.Replace(",", "','") & "')"
                    rsRef = cmRef.ExecuteReader
                    Do While rsRef.Read
                        lblAppSkills.Text += "* " & rsRef("Descr") & "<br/>"
                    Loop
                    cmRef.Dispose()
                    rsRef.Close()
                End If
                lblAppCivilStatus.Text = IIf(IsDBNull(rs("Civil_Cd")), "", rs("Civil_Cd"))
                lblAppWeight.Text = IIf(IsDBNull(rs("Weight")), "", rs("Weight") & _
                                    " kilograms (" & Math.Round((rs("Weight") * 2.2046226), 2) & " lbs.)")


                Dim vFoot As Decimal = rs("Height") * 0.0328   'convert to foot
                Dim vInches As Decimal = Math.Ceiling((vFoot - Int(vFoot)) * 12)

                If vInches >= 12 Then
                    vFoot = Int(vFoot) + 1
                    vInches -= 12
                End If
                lblAppHeight.Text = IIf(IsDBNull(rs("Height")), "", rs("Height") & " centimeters (" & _
                                    Math.Round(Int(vFoot), 0) & "'" & vInches & """") & ")"

                lblAppReligion.Text = GetRef("hr_religion_ref", "Descr", "ReligionCd", IIf(IsDBNull(rs("ReligionCd")), "", rs("ReligionCd")))

                lblAppCity.Text = GetRef("city_ref", "Descr", "CityCd", IIf(IsDBNull(rs("City")), "", rs("City")))
                lblAppCountry.Text = GetRef("hr_country_ref", "Descr", "CountryCd", IIf(IsDBNull(rs("CountryCd")), "", rs("CountryCd")))
                lblAppZipCode.Text = IIf(IsDBNull(rs("Zip")), "", rs("Zip"))
                'GetRef("Zip_ref", "AreaNM", "ZipCd", IIf(IsDBNull(rs("Zip")), "", rs("Zip")))
                lblRegion.Text = GetRef("region_ref", "Descr", "RegionCd", IIf(IsDBNull(rs("RegionCd")), "", rs("RegionCd")))
                lblProvince.Text = GetRef("province_ref", "Descr", "ProvCd", IIf(IsDBNull(rs("ProvCd")), "", rs("ProvCd")))
                lblTaxCode.Text = GetRef("py_tax_ref", "Descr", "Tax_Cd", IIf(IsDBNull(rs("TaxCd")), "", rs("TaxCd")))

                lblDialectSpoken.Text = ""
                If Not IsDBNull(rs("DialectCd")) Then
                    cmRef.Connection = c
                    cmRef.CommandText = "select DialectCd,Descr from hr_dialect_ref where DialectCd in ('" & _
                           rs("DialectCd").ToString.Replace(",", "','") & "')"
                    rsRef = cmRef.ExecuteReader
                    Do While rsRef.Read
                        lblDialectSpoken.Text += "*" & rsRef("Descr") & "<br/>"
                    Loop
                    cmRef.Dispose()
                    rsRef.Close()
                End If
                lblAppLanguage.Text = ""
                If Not IsDBNull(rs("LanguageCd")) Then
                    cmRef.Connection = c
                    cmRef.CommandText = "select LanguageCd,Descr from hr_language_ref where LanguageCd in ('" & _
                           rs("LanguageCd").ToString.Replace(",", "','") & "')"
                    rsRef = cmRef.ExecuteReader
                    Do While rsRef.Read
                        lblAppLanguage.Text += "*" & rsRef("Descr") & "<br/>"
                    Loop
                    cmRef.Dispose()
                    rsRef.Close()
                End If
                lblAppCitizenship.Text = GetRef("hr_citizenship_ref", "Descr", "Citizen_Cd", IIf(IsDBNull(rs("CitizenCd")), "", rs("CitizenCd")))

                lblAppSkillTraining.Text = ""
                Dim aTraining As String()
                If Not IsDBNull(rs("Self_Trainings")) Then
                    aTraining = rs("Self_Trainings").ToString.Split(";")
                    For i As Integer = 0 To UBound(aTraining)
                        lblAppSkillTraining.Text += "*" & aTraining(i) & "<br/>"
                    Next
                End If
                lblMacOperated.Text = ""
                Dim aMachines As String()
                If Not IsDBNull(rs("MacOprtd")) Then
                    aMachines = rs("MacOprtd").ToString.Split(";")
                    For i As Integer = 0 To UBound(aMachines)
                        lblMacOperated.Text += " *" & aMachines(i) & "<br/>"
                    Next
                End If


                lblAppProvAddress.Text = IIf(IsDBNull(rs("Prov_Address")), "", rs("Prov_Address"))
                lblAppEmrgncyConName.Text = IIf(IsDBNull(rs("EmergencyContactPerson")), "", rs("EmergencyContactPerson"))
                lblAppEmrgncyRelation.Text = IIf(IsDBNull(rs("EmergencyRelation")), "", rs("EmergencyRelation"))
                lblAppEmrgncyConNo.Text = IIf(IsDBNull(rs("EmergencyContactNo")), "", rs("EmergencyContactNo"))
                lblAppEmrgncyAdd.Text = IIf(IsDBNull(rs("EmergencyAddress")), "", rs("EmergencyAddress"))
                lblEmergencyEmail.Text = IIf(IsDBNull(rs("EmergencyEmail")), "", rs("EmergencyEmail"))
                lblAppSpouseName.Text = IIf(IsDBNull(rs("Spouse_Lname")), "", rs("Spouse_Lname"))
                lblSpouseFname.Text = IIf(IsDBNull(rs("Spouse_Fname")), "", rs("Spouse_Fname"))
                lblSpouseMName.Text = IIf(IsDBNull(rs("Spouse_Mname")), "", rs("Spouse_Mname"))
                lblAppSpouseOccu.Text = IIf(IsDBNull(rs("Spouse_Occupation")), "", rs("Spouse_Occupation"))
                lblAppSpouseConNo.Text = IIf(IsDBNull(rs("Spouse_Tel")), "", rs("Spouse_Tel"))
                lblAppSpouseBusAdd.Text = IIf(IsDBNull(rs("Spouse_Bus_Addr")), "", rs("Spouse_Bus_Addr"))
                lblSpouseEmployer.Text = IIf(IsDBNull(rs("Spouse_Emr")), "", rs("Spouse_Emr"))
                lblSpouseLocalAddress.Text = IIf(IsDBNull(rs("SpouseAddress")), "", rs("SpouseAddress"))
                lblSpouseProvAddress.Text = IIf(IsDBNull(rs("SpouseProvAddress")), "", rs("SpouseProvAddress"))

                lblAppFatherName.Text = IIf(IsDBNull(rs("Father_Lname")), "", rs("Father_Lname"))
                lblFatherFname.Text = IIf(IsDBNull(rs("Father_Fname")), "", rs("Father_Fname"))
                lblFatherMname.Text = IIf(IsDBNull(rs("Father_Mname")), "", rs("Father_Mname"))
                lblFatherBDay.Text = ""
                If Not IsDBNull(rs("FatherBDay")) Then
                    lblFatherBDay.Text = Format(rs("FatherBday"), "MM/dd/yyyy")
                End If
                lblAppFatherOccu.Text = IIf(IsDBNull(rs("FatherOcc")), "", rs("FatherOcc"))
                lblAppFatherConNo.Text = IIf(IsDBNull(rs("FatherContact")), "", rs("FatherContact"))
                lblAppFatherAdd.Text = IIf(IsDBNull(rs("FatherAddress")), "", rs("FatherAddress"))

                lblAppFatherDeaceased.Text = "&nbsp;"
                If rs("FatherAlive") = 1 Then
                    lblAppFatherDeaceased.Text = "Deceased"
                End If
                lblAppFatherCauseDeath.Text = IIf(IsDBNull(rs("FatherDeathCause")), "&nbsp;", rs("FatherDeathCause"))

                lblAppMotherName.Text = IIf(IsDBNull(rs("Mother_Lname")), "", rs("Mother_Lname"))
                lblMotherFname.Text = IIf(IsDBNull(rs("Mother_Fname")), "", rs("Mother_Fname"))
                lblMotherMName.Text = IIf(IsDBNull(rs("Mother_Mname")), "", rs("Mother_Mname"))
                lblMotherBday.Text = ""
                If Not IsDBNull(rs("MotherBDay")) Then
                    lblMotherBday.Text = Format(rs("MotherBday"), "MM/dd/yyyy")
                End If

                lblAppMotherOccu.Text = IIf(IsDBNull(rs("MotherOcc")), "", rs("MotherOcc"))
                lblAppMotherConNo.Text = IIf(IsDBNull(rs("MotherContact")), "", rs("MotherContact"))
                lblAppMotherAdd.Text = IIf(IsDBNull(rs("MotherAddress")), "", rs("MotherAddress"))

                lblAppMotherDeaceased.Text = "&nbsp;"
                If rs("MotherAlive") = 1 Then
                    lblAppMotherDeaceased.Text = "Deceased"
                End If
                lblAppMotherCauseDeath.Text = IIf(IsDBNull(rs("MotherDeathCause")), "&nbsp;", rs("MotherDeathCause"))
                rs.Close()
                'Childrens Information
                cm.CommandText = "Select Application_No,SeqId,Dependent_Name,Relation,Birth_Date,PlaceofBirth," & _
                                 "Address,Sex from hr_emp_tmp_dependents where Application_No='" & Session("id") & _
                                 "' and rel_type='dependents' order by SeqId asc"
                rs = cm.ExecuteReader
                Dim age As Integer = 0
                Do While rs.Read
                    age = 0
                    If Not IsDBNull(rs("Birth_Date")) Then
                        age = Math.Floor(DateDiff(DateInterval.Month, rs("Birth_Date"), Now) / 12)
                        vDepInfo += "<tr>" & _
                                    "<td style='font-size: 12px; padding: 2px;' align='center'>" & rs("Dependent_Name") & "</td>" & _
                                    "<td style='font-size: 12px; padding: 2px;' align='center'>" & rs("Sex") & "</td>" & _
                                    "<td style='font-size: 12px; padding: 2px;' align='center'>" & rs("Relation") & "</td>" & _
                                    "<td style='font-size: 12px; padding: 2px;' align='center'>" & rs("Birth_Date") & "</td>" & _
                                    "<td style='font-size: 12px; padding: 2px;' align='center'>" & rs("PlaceofBirth") & "</td>" & _
                                    "<td style='font-size: 12px; padding: 2px;' align='center'>" & age & "</td>" & _
                                "</tr>"
                    End If

                Loop
                rs.Close()

                'relatives
                cm.CommandText = "Select Application_No,SeqId,Dependent_Name," & _
                                 "Relation,PlaceofBirth,School,rel_type,Sex,Position,contacts" & _
                                 " from hr_emp_tmp_dependents where Application_No='" & Session("id") & _
                                 "' and rel_type='relatives' order by SeqId asc"
                rs = cm.ExecuteReader
                Do While rs.Read
                    vEmpRelatives += "<tr>" & _
                                "<td style='font-size: 12px; padding: 2px;' align='center'>" & rs("Dependent_Name") & "</td>" & _
                                "<td style='font-size: 12px; padding: 2px;' align='center'>" & rs("Sex") & "</td>" & _
                                "<td style='font-size: 12px; padding: 2px;' align='center'>" & rs("School") & "</td>" & _
                                "<td style='font-size: 12px; padding: 2px;' align='center'>" & rs("PlaceofBirth") & "</td>" & _
                                "<td style='font-size: 12px; padding: 2px;' align='center'>" & rs("Position") & "</td>" & _
                                "<td style='font-size: 12px; padding: 2px;' align='center'>" & rs("Contacts") & "</td>" & _
                              "</tr>"
                    'End If
                Loop
                rs.Close()
                'Siblings Information
                cm.CommandText = "select ApplicantNo,Fname,Relationship,CompSchool," & _
                                 "Position,ContactNum,birthday,Sex from hr_emp_tmp_sibling" & _
                                 " where ApplicantNo='" & Session("id") & "' order by itemid asc"

                rs = cm.ExecuteReader
                Do While rs.Read
                    vEmpSiblings += "<tr>" & _
                                        "<td style='font-size: 12px; padding: 2px;' align='center'>" & rs("Fname") & "</td>" & _
                                        "<td style='font-size: 12px; padding: 2px;' align='center'>" & rs("Sex") & "</td>" & _
                                        "<td style='font-size: 12px; padding: 2px;' align='center'>" & rs("Relationship") & "</td>" & _
                                        "<td style='font-size: 12px; padding: 2px;' align='center'>" & rs("birthday") & "</td>" & _
                                        "<td style='font-size: 12px; padding: 2px;' align='center'>" & rs("CompSchool") & "</td>" & _
                                        "<td style='font-size: 12px; padding: 2px;' align='center'>" & rs("Position") & "</td>" & _
                                        "<td style='font-size: 12px; padding: 2px;' align='center'>" & rs("ContactNum") & "</td>" & _
                                    "</tr>"
                Loop
                rs.Close()
                cm.CommandText = "select Emp_Cd,SeqId,Type,From_Date as From_Date," & _
                                 "School,Course,To_Date as To_Date," & _
                                 "Accomplishments,School_Address,Final_Grade,Year_Grad" & _
                                 " from hr_emp_tmp_scholastic " & _
                                 "where Emp_Cd='" & Session("id") & "' order by From_Date desc"

                rs = cm.ExecuteReader
                Do While rs.Read
                    vEmpSholastic += "<tr>" & _
                                       "<td style='font-size: 12px; padding: 2px;' align='center'>" & rs("From_Date") & "</td>" & _
                                       "<td style='font-size: 12px; padding: 2px;' align='center'>" & rs("To_Date") & "</td>" & _
                                       "<td style='font-size: 12px; padding: 2px;' align='center'>" & IIf(rs("Course") = "", "&nbsp;", rs("Course")) & "</td>" & _
                                       "<td style='font-size: 12px; padding: 2px;' align='center'>" & rs("School") & "</td>" & _
                                       "<td style='font-size: 12px; padding: 2px;' align='left'>" & rs("School_Address") & "</td>" & _
                                       "<td style='font-size: 12px; padding: 2px;' align='center'>" & rs("Final_Grade") & "</td>" & _
                                   "</tr>"
                Loop
                rs.Close()
                
                'Examinations Taken
                cm.CommandText = "select SeqId,Emp_Cd,LicenseName,License_No," & _
                                 "CAST(Date_Issued AS DATE) AS Date_Issued," & _
                                 "CAST(Date_Exam AS DATE) AS Date_Exam," & _
                                 "Place_Exam," & _
                                 "Remarks,Score," & _
                                 "CAST(Exp_Date AS DATE) AS Exp_Date" & _
                                 " from hr_emp_tmp_license_ref " & _
                                 "where Emp_Cd='" & Session("id") & "' order by Date_Issued desc"
                rs = cm.ExecuteReader
                Do While rs.Read
                    vExamsTaken += "<tr>" & _
                                    "<td style='font-size: 12px; padding: 2px;' align='center'>" & rs("LicenseName") & "</td>" & _
                                    "<td style='font-size: 12px; padding: 2px;' align='center'>" & rs("License_No") & "</td>" & _
                                    "<td style='font-size: 12px; padding: 2px;' align='center'>" & rs("Date_Issued") & "</td>" & _
                                    "<td style='font-size: 12px; padding: 2px;' align='center'>" & rs("Exp_Date") & "</td>" & _
                                    "<td style='font-size: 12px; padding: 2px;' align='center'>" & rs("Date_Exam") & "</td>" & _
                                    "<td style='font-size: 12px; padding: 2px;' align='center'>" & rs("Place_Exam") & "</td>" & _
                                    "<td style='font-size: 12px; padding: 2px;' align='center'>" & rs("Score") & "</td>" & _
                                    "<td style='font-size: 12px; padding: 2px;' align='center'>" & rs("Remarks") & "</td>" & _
                                  "</tr>"
                    'End If
                Loop
                rs.Close()
                cm.CommandText = "select substring(from_date,4,4) as fyear," & _
                                 "substring(from_date,1,2) as fmonth," & _
                                 "Emp_Id,Employer,Position,Annual_Salary,From_Date," & _
                                 "To_Date,Accomplishments,[Function],Address," & _
                                 "Nature,GovServ,SeqId,Supervisor,ReasonforLeaving," & _
                                 "SupervisorNo,EmployerNo,SupPosition from hr_emp_tmp_employment_hist " & _
                                 "where Emp_Id='" & Session("id") & "' order by fyear desc, fmonth desc"
                rs = cm.ExecuteReader
                Do While rs.Read
                    Dim AnnualSalary As Integer = 0

                    If IsDBNull(rs("Annual_Salary")) Then
                        AnnualSalary = 0
                    Else
                        AnnualSalary = rs("Annual_Salary")
                    End If
                    vEmpHist += "<tr>" & _
                                   "<td style='padding: 2px;' align='center'>" & rs("From_Date") & "</td>" & _
                                   "<td style='padding: 2px;' align='center'>" & rs("To_Date") & "</td>" & _
                                   "<td style='padding: 2px;' align='center'>" & rs("Employer") & "</td>" & _
                                   "<td style='padding: 2px;' align='left'>" & rs("Address") & "</td>" & _
                                   "<td style='padding: 2px;' align='left'>" & rs("EmployerNo") & "</td>" & _
                                   "<td style='padding: 2px;' align='center'>" & rs("Position") & "</td>" & _
                                   "<td style='padding: 2px;' align='center'>" & Format(AnnualSalary, "#,###,##0.00") & "</td>" & _
                                   "<td style='padding: 2px;' align='left'>" & rs("Supervisor") & "</td>" & _
                                   "<td style='padding: 2px;' align='left'>" & rs("Function") & "</td>" & _
                                   "<td style='padding: 2px;' align='left'>" & rs("ReasonforLeaving") & "</td>" & _
                               "</tr>"
                Loop
                rs.Close()
                cm.CommandText = "select Training_Name,From_Date,To_Date,No_of_Hours,Held,Remarks,Speaker" & _
                                 " from hr_emp_tmp_training where Emp_Id='" & Session("id") & "' order by From_Date desc"
                rs = cm.ExecuteReader
                Do While rs.Read
                    vEmpSeminars += "<tr>" & _
                                   "<td style='font-size: 12px; padding: 2px;font-family:Arial;' align='center'>" & rs("Training_Name") & "</td>" & _
                                   "<td style='font-size: 12px; padding: 2px;font-family:Arial;' align='center'>" & rs("From_Date") & "</td>" & _
                                   "<td style='font-size: 12px; padding: 2px;font-family:Arial;' align='center'>" & rs("To_Date") & "</td>" & _
                                   "<td style='font-size: 12px; padding: 2px;font-family:Arial;' align='left'>" & rs("No_of_Hours") & "</td>" & _
                                   "<td style='font-size: 12px; padding: 2px;font-family:Arial;' align='left'>" & rs("Speaker") & "</td>" & _
                                   "<td style='font-size: 12px; padding: 2px;font-family:Arial;' align='center'>" & rs("Held") & "</td>" & _
                                   "<td style='font-size: 12px; padding: 2px;font-family:Arial;' align='left'>" & rs("Remarks") & "</td>" & _
                               "</tr>"
                Loop
                rs.Close()
                c.Close()
                cm.Dispose()
                c.Dispose()
            End If
        End If
    End Sub

End Class
