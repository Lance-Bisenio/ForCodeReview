﻿
Partial Class _2316temp
    Inherits System.Web.UI.Page
    Public vScript As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            vScript = "alert('Your login session has expired. Please login again.'); window.close();"
        End If

        Dim vDetails() As String = Session("2316dump").ToString.Split("~")
        Dim vTaxpayerNo() As String = vDetails(2).ToString.Split("-")
        Dim vDependent() As String = vDetails(11).ToString.Split("|")
        Dim vDependentSub() As String
        Dim v15() As String
        Dim v18() As String

        'vDetails() = Session("2316dump")
        'For iCtr = 0 To UBound(vDetails)
        '    Response.Write(iCtr & " - " & vDetails(iCtr) & "<br>")
        'Next

        lbl1.Text = vDetails(0)
        lbl2_1.Text = vDetails(1)
        lbl2_2.Text = vDetails(1)

        lbl3_1.Text = vTaxpayerNo(0)
        lbl3_2.Text = vTaxpayerNo(1)
        lbl3_3.Text = vTaxpayerNo(1)
        lbl3_4.Text = "0000"

        lbl4.Text = vDetails(3) & ", " & vDetails(4) & " " & vDetails(5)
        lbl5.Text = ""
        lbl6.Text = vDetails(6)
        lbl6A.Text = vDetails(7)

        lbl6B.Text = ""
        lbl6C.Text = ""
        lbl6D.Text = ""
        lbl6E.Text = ""

        lbl7_m.Text = Format(Month(vDetails(8)), "00")
        lbl7_d.Text = Format(Day(vDetails(8)), "00")
        lbl7_y.Text = Year(vDetails(8))
        lbl8.Text = vDetails(9)

        If vDetails(10) = "S" Then
            lbl9_m.Text = ""
            lbl9_s.Text = "X"
        Else
            lbl9_m.Text = "X"
            lbl9_s.Text = ""
        End If

        lbl9A_n.Text = "X"
        lbl9A_y.Text = ""

        If vDependent(0) <> "^" Then
            vDependentSub = vDependent(0).ToString.Split("^")
            lbl10A.Text = vDependentSub(0)
            lbl10A_m.Text = Format(Month(vDependentSub(1)), "00")
            lbl10A_d.Text = Format(Day(vDependentSub(1)), "00")
            lbl10A_y.Text = Year(vDependentSub(1))
        End If

        If vDependent(1) <> "^" Then
            vDependentSub = vDependent(1).ToString.Split("^")
            lbl10B.Text = vDependentSub(0)
            lbl10B_m.Text = Format(Month(vDependentSub(1)), "00")
            lbl10B_d.Text = Format(Day(vDependentSub(1)), "00")
            lbl10B_y.Text = Year(vDependentSub(1))
        End If

        If vDependent(2) <> "^" Then
            vDependentSub = vDependent(2).ToString.Split("^")
            lbl10C.Text = vDependentSub(0)
            lbl10C_m.Text = Format(Month(vDependentSub(1)), "00")
            lbl10C_d.Text = Format(Day(vDependentSub(1)), "00")
            lbl10C_y.Text = Year(vDependentSub(1))
        End If

        If vDependent(3) <> "^" Then
            vDependentSub = vDependent(3).ToString.Split("^")
            lbl10D.Text = vDependentSub(0)
            lbl10D_m.Text = Format(Month(vDependentSub(1)), "00")
            lbl10D_d.Text = Format(Day(vDependentSub(1)), "00")
            lbl10D_y.Text = Year(vDependentSub(1))
        End If

        lbl12.Text = "0.00"
        lbl13.Text = "0.00"
        lbl14.Text = ""

        If vDetails(12) = "" Then
            v15 = vDetails(12).ToString.Split("-")
            lbl15_1.Text = v15(0)
            lbl15_2.Text = v15(1)
            lbl15_3.Text = v15(2)
            lbl15_4.Text = v15(3)
        End If
        
        lbl16.Text = vDetails(13)
        lbl17.Text = vDetails(14)
        lbl17A.Text = vDetails(15)
        lbl17B.Text = ""
        lbl17C.Text = ""

        If vDetails(13) = "" Then
            v18 = vDetails(13).ToString.Split("-")
            lbl18_1.Text = v18(0)
            lbl18_2.Text = v18(1)
            lbl18_3.Text = v18(2)
            lbl18_4.Text = v18(3)
        End If
        
        lbl24.Text = Format(Val(vDetails(20)), "#,###,##0.00")
        lbl26.Text = Format(Val(vDetails(21)), "#,###,##0.00")
        lbl28.Text = Format(Val(vDetails(22)), "#,###,##0.00")

        lbl29.Text = Format(Val(vDetails(23)), "#,###,##0.00")
        lbl30A.Text = Format(Val(vDetails(24)), "#,###,##0.00")
        lbl30B.Text = Format(Val(vDetails(25)), "#,###,##0.00")

        lbl31.Text = Format(Val(vDetails(26)), "#,###,##0.00")
        lbl32.Text = ""
        lbl33.Text = ""
        lbl34.Text = ""
        lbl35.Text = ""
        lbl36.Text = ""
        lbl37.Text = Format(Val(vDetails(27)), "#,###,##0.00")
        lbl38.Text = ""
        lbl39.Text = Format(Val(vDetails(28)), "#,###,##0.00")

        lbl40.Text = Format(Val(vDetails(29)), "#,###,##0.00")
        lbl42.Text = Format(Val(vDetails(30)) - Val(lbl39.Text.Replace(",", "")), "#,###,##0.00")
        lbl51.Text = Format(Val(vDetails(31)), "#,###,##0.00")

        lbl56.Text = vDetails(32)
        lbl57.Text = vDetails(3) & ", " & vDetails(4) & " " & vDetails(5)
        lbl58.Text = vDetails(32)
        lbl59.Text = vDetails(3) & ", " & vDetails(4) & " " & vDetails(5)

        lbl41.Text = Format(Val(lbl32.Text.Replace(",", "")) + Val(lbl33.Text.Replace(",", "")) + _
                            Val(lbl34.Text.Replace(",", "")) + Val(lbl35.Text.Replace(",", "")) + _
                            Val(lbl36.Text.Replace(",", "")) + Val(lbl37.Text.Replace(",", "")) + _
                            Val(lbl38.Text.Replace(",", "")) + Val(lbl39.Text.Replace(",", "")) + _
                            Val(lbl40.Text.Replace(",", "")), "#,###,##0.00")

        lbl55.Text = Format(Val(lbl42.Text.Replace(",", "")) + Val(lbl43.Text.Replace(",", "")) + _
                            Val(lbl44.Text.Replace(",", "")) + Val(lbl45.Text.Replace(",", "")) + _
                            Val(lbl46.Text.Replace(",", "")) + Val(lbl47A_2.Text.Replace(",", "")) + _
                            Val(lbl47B_2.Text.Replace(",", "")) + Val(lbl48.Text.Replace(",", "")) + _
                            Val(lbl49.Text.Replace(",", "")) + Val(lbl50.Text.Replace(",", "")) + _
                            Val(lbl51.Text.Replace(",", "")) + Val(lbl52.Text.Replace(",", "")) + _
                            Val(lbl53.Text.Replace(",", "")) + Val(lbl54A_2.Text.Replace(",", "")) + _
                            Val(lbl54B_2.Text.Replace(",", "")), "#,###,##0.00")

        lbl22.Text = Format(Val(lbl41.Text.Replace(",", "")), "#,###,##0.00")
        lbl23.Text = Format(Val(lbl55.Text.Replace(",", "")), "#,###,##0.00")

        lbl21.Text = Format(Val(lbl41.Text.Replace(",", "")) + Val(lbl55.Text.Replace(",", "")), "#,###,##0.00")

        lbl25.Text = Format(Val(lbl23.Text.Replace(",", "")) + Val(lbl24.Text.Replace(",", "")), "#,###,##0.00")

        

    End Sub
End Class
