Imports denaro
Partial Class leavereport
    Inherits System.Web.UI.Page
    Public vData As String = ""
    Public vScript As String = ""
    Public vShowGrace As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("uid") = "" Then
            Server.Transfer("index.aspx")
            Exit Sub
        End If
        Session.Remove("vHeader")
        Session.Remove("vPeriod")
        Session.Remove("vFilter")

        Session.Remove("vList")

        If Not CanRun(Session("caption"), Request.Item("id")) Then
            Session("denied") = "1"
            Server.Transfer("main.aspx")
            Exit Sub
        End If
        vScript = "chk(document.getElementById(""cmbRpt""))"
        If Not IsPostBack Then
            lblCaption.Text = "Leave, Overtime and Tardiness Matrix Report"
            cmbMonth.SelectedValue = Now.Month
            BuildCombo("select Rc_Cd, Descr from rc where Rc_Cd in ('" & _
                Session("rclist").ToString.Replace(",", "','") & "') order by Descr ", cmbRC)
            BuildCombo("select AgencyCd,AgencyName from agency where Agencycd in ('" & _
                Session("agencylist").ToString.Replace(",", "','") & "') order by AgencyName", cmbOfc)
            BuildCombo("select Div_Cd,Descr from hr_div_ref where Div_Cd in ('" & _
                Session("divlist").ToString.Replace(",", "','") & "') order by Descr", cmbDiv)
            BuildCombo("select Dept_Cd,Descr from hr_dept_ref where Dept_Cd in ('" & _
                Session("deptlist").ToString.Replace(",", "','") & "') order by Descr", cmbDept)
            BuildCombo("select Section_Cd,Descr from hr_section_ref where Section_Cd in ('" & _
                Session("sectionlist").ToString.Replace(",", "','") & "') order by Descr", cmbSection)
            BuildCombo("select Unit_Cd,Descr from hr_unit_ref where Unit_Cd in ('" & _
                Session("unitlist").ToString.Replace(",", "','") & "') order by Descr", cmbUnit)
            BuildCombo("select EmploymentType,Descr from hr_employment_type where EmploymentType in ('" & _
                Session("typelist").ToString.Replace(",", "','") & "') order by Descr", cmbEmpType)

            BuildCombo("select Pay_Cd, Payment from py_pay_mode order by Payment", cmbPayMode)

            cmbRC.Items.Add("All")
            cmbRC.SelectedValue = "All"
            cmbOfc.Items.Add("All")
            cmbOfc.SelectedValue = "All"
            cmbDiv.Items.Add("All")
            cmbDiv.SelectedValue = "All"
            cmbDept.Items.Add("All")
            cmbDept.SelectedValue = "All"
            cmbSection.Items.Add("All")
            cmbSection.SelectedValue = "All"
            cmbUnit.Items.Add("All")
            cmbUnit.SelectedValue = "All"
            cmbEmpType.Items.Add("All")
            cmbEmpType.SelectedValue = "All"

            cmbYear.Items.Clear()
            For i As Integer = Now.Year To Now.Year - 5 Step -1
                cmbYear.Items.Add(i)
            Next
            cmbYear.SelectedValue = Now.Year
            GetPeriods()
            PopulateLeaves()
        End If
    End Sub
    Private Sub PopulateLeaves()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand("select Leave_Cd,Descr from py_leave_ref order by Descr", c)
        Dim rs As SqlClient.SqlDataReader

        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to connect to database. Error is: " & ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        chkLeave.Items.Clear()
        Try
            rs = cm.ExecuteReader
            Do While rs.Read
                chkLeave.Items.Add(New ListItem(rs("Descr"), rs("Leave_Cd")))
            Loop
            rs.Close()
        Catch ex As SqlClient.SqlException
            vScript = "alert('Error occurred while trying to retrieve records.  Error is: " & ex.Message.Replace(vbCrLf, "").Replace("'", "") & "');"
        Finally
            c.Close()
            c.Dispose()
            cm.Dispose()
        End Try
    End Sub
    Private Sub GetPeriods()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand("select * from py_pay_mode where Pay_Cd='SM'", c)
        Dim rs As SqlClient.SqlDataReader
        Dim vDaysList As String = ""
        Dim vDays() As String
        Try
            c.Open()
        Catch ex As system.exception
            vScript = ""
            c.Dispose()
            cm.Dispose()
            Exit Sub
        End Try

        cmbPeriod.Items.Clear()
        Try
            rs = cm.ExecuteReader
            If rs.Read Then
                vDaysList = rs("Days")
            End If
            rs.Close()
            vDays = vDaysList.Split(",")

            For i As Integer = 0 To UBound(vDays)
                cmbPeriod.Items.Add(cmbMonth.SelectedValue & "/" & vDays(i))
            Next
        Catch ex As system.exception
            vScript = "alert('Error');"
        Finally
            c.Close()
            c.Dispose()
            cm.Dispose()
        End Try
        

        ''pay mode semi-monthly 11 - 26
        'If cmbPayMode.SelectedValue = "SM" Then
        '    cmbPeriod.Items.Add(cmbMonth.SelectedValue & "/11/" & Now.Year)
        '    If cmbMonth.SelectedValue = 12 Then
        '        cmbPeriod.Items.Add(DateAdd(DateInterval.Day, -1, CDate("1/11/" & Now.Year + 1)))
        '    Else
        '        cmbPeriod.Items.Add(DateAdd(DateInterval.Day, +15, CDate(cmbMonth.SelectedValue & "/11/" & Now.Year)))
        '    End If

        '    'add previous year's data
        '    cmbPeriod.Items.Add(cmbMonth.SelectedValue & "/11/" & Now.Year - 1)
        '    If cmbMonth.SelectedValue = 12 Then
        '        cmbPeriod.Items.Add(DateAdd(DateInterval.Day, -1, CDate("1/11/" & Now.Year)))
        '    Else
        '        cmbPeriod.Items.Add(DateAdd(DateInterval.Day, +15, CDate(cmbMonth.SelectedValue & "/11/" & Now.Year - 1)))
        '    End If

        'End If

        ''pay mode semi-monthly 15 - 30
        'If cmbPayMode.SelectedValue = "DY" Then
        '    cmbPeriod.Items.Add(cmbMonth.SelectedValue & "/1/" & Now.Year)
        '    If cmbMonth.SelectedValue = 12 Then
        '        cmbPeriod.Items.Add(DateAdd(DateInterval.Day, -1, CDate("1/1/" & Now.Year + 1)))
        '    Else
        '        cmbPeriod.Items.Add(DateAdd(DateInterval.Day, -1, CDate(cmbMonth.SelectedValue + 1 & "/1/" & Now.Year)))
        '    End If

        '    'add previous year's data
        '    cmbPeriod.Items.Add(cmbMonth.SelectedValue & "/1/" & Now.Year - 1)
        '    If cmbMonth.SelectedValue = 12 Then
        '        cmbPeriod.Items.Add(DateAdd(DateInterval.Day, -1, CDate("1/1/" & Now.Year)))
        '    Else
        '        cmbPeriod.Items.Add(DateAdd(DateInterval.Day, -1, CDate(cmbMonth.SelectedValue + 1 & "/1/" & Now.Year - 1)))
        '    End If
        'End If


    End Sub
    Protected Sub cmdReturn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.Click
        Session.Remove("vHeader")
        Session.Remove("vPeriod")
        Session.Remove("vFilter")
        Server.Transfer("main.aspx")
    End Sub

    Protected Sub cmbMonth_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbMonth.SelectedIndexChanged
        GetPeriods()
    End Sub

    Protected Sub cmdRefresh_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdRefresh.Click
        RefreshData()
    End Sub
    Function CheckLeaveSelection() As String
        Dim vList As String = ""
        Dim i As Integer

        For i = 0 To chkLeave.Items.Count - 1
            If chkLeave.Items(i).Selected Then
                vList += chkLeave.Items(i).Value & ","
            End If
        Next

        If vList <> "" Then
            vList = Mid(vList, 1, Len(vList) - 1)
            vList = "'" & vList.Replace(",", "','") & "'"
        End If
        Return vList
    End Function
    Private Sub RefreshData()
        Dim c As New SqlClient.SqlConnection(connStr)
        Dim cm As New SqlClient.SqlCommand
        Dim cmLeave As New SqlClient.SqlCommand
        Dim cmWOP As New SqlClient.SqlCommand

        Dim rs As SqlClient.SqlDataReader
        Dim rsLeave As SqlClient.SqlDataReader
        Dim rsWOP As SqlClient.SqlDataReader

        Dim iCtr As Integer = 0
        Dim vStart As Date
        Dim vEnd As Date
        Dim vMode As String = ""
        Dim vLeave(16) As String
        Dim vTotal As Decimal = 0
        Dim vTotalHrs As Decimal = 0
        Dim vFilter As String = ""
        Dim vSW As String = "odd"
        Dim vList As String
        Dim vDumpF As Single = 0
        Dim vDiff As Integer = 0
        Dim vDaysLeave As Decimal = 0
        Dim i As Integer = 0
        Dim vLabel As Label
        Dim iSub As Integer = 0

        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' MODIFID BY:  VIC GATCHALIAN                                     ''
        '' DATE MODIFIED: 2/23/2012                                        ''
        '' PURPOSE: TO SUPPORT LEAVE SELECTION FLEXIBILITY INSTEAD OF      ''
        ''          DISPLAYING ALL TYPES OF LEAVE                          ''
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        Dim vLeaveSelect As String = CheckLeaveSelection()
        '''''''''''''''''' END OF MODIFICATION ''''''''''''''''''''''''''''''


        'create headers
        vStart = CDate(cmbPeriod.SelectedValue & "/" & cmbYear.SelectedValue)

        If cmbPeriod.SelectedIndex < cmbPeriod.Items.Count - 1 Then
            vEnd = CDate(cmbPeriod.Items(cmbPeriod.SelectedIndex + 1).Text & "/" & cmbYear.SelectedValue).AddDays(-1)
        Else
            vEnd = CDate(cmbPeriod.Items(0).Text & "/" & cmbYear.SelectedValue).AddDays(-1)
        End If
        If vEnd < vStart Then vEnd = vEnd.AddMonths(1) 'vend is next month

        TxtTTLCtrls.Text = DateDiff(DateInterval.DayOfYear, vStart, vEnd) + 1

        For i = 0 To Controls(0).Controls.Count - 1
            If Controls(0).Controls(i).ID.Contains("lblDay") Then

                Controls(0).Controls(i).Visible = True
                If vStart > vEnd Then
                    'Response.Write(vStart & " " & Controls(0).Controls(i).ID & "<br/>")
                    Controls(0).Controls(i).Visible = False
                End If

                vLabel = Controls(0).Controls(i)
                vLabel.Text = vStart.Day
                vStart = vStart.AddDays(1)

            End If
        Next
        'Response.Write(DateDiff(DateInterval.DayOfYear, CDate(vStart), CDate(vEnd)))
        'retrieve data 
        Try
            c.Open()
        Catch ex As SqlClient.SqlException
            vScript = "alert(""" & ex.Message.Replace(vbCrLf, "") & """);"
            Exit Sub
        End Try

        cm.Connection = c
        cmLeave.Connection = c
        cmWOP.Connection = c

        Session.Remove("vHeader")
        Session.Remove("vPeriod")
        Session.Remove("vFilter")

        If cmbRC.SelectedValue <> "All" Then   'filter by cost center
            vFilter += " and Rc_Cd='" & cmbRC.SelectedValue & "' "
            Session("vFilter") += "Cost Center : " & cmbRC.SelectedItem.Text & "<br />"
        Else
            vFilter += " and Rc_Cd = any (select Property_Value from rights_list where User_Id='" & _
                Session("uid") & "' and Property='rc') "
        End If

        If cmbOfc.SelectedValue <> "All" Then        'filter by office/agency
            vFilter += " and Agency_Cd='" & cmbOfc.SelectedValue & "' "
            Session("vFilter") += "Office : " & cmbOfc.SelectedItem.Text & "<br />"
        Else
            vFilter += " and Agency_Cd = any (select Property_Value from rights_list where User_Id='" & _
                Session("uid") & "' and Property='agency') "
        End If

        If cmbDiv.SelectedValue <> "All" Then      'filter by division
            vFilter += " and Divcd='" & cmbDiv.SelectedValue & "' "
            Session("vFilter") += "Division : " & cmbDiv.SelectedItem.Text & "<br />"
        Else
            vFilter += " and DivCd = any (select Property_Value from rights_list where User_Id='" & _
                Session("uid") & "' and Property='division') "
        End If

        If cmbDept.SelectedValue <> "All" Then  'filter by departments
            vFilter += " and DeptCd='" & cmbDept.SelectedValue & "' "
            Session("vFilter") += "Department : " & cmbDept.SelectedItem.Text & "<br />"
        Else
            vFilter += " and DeptCd = any (select Property_Value from rights_list where User_Id='" & _
                Session("uid") & "' and Property='department') "
        End If

        If cmbSection.SelectedValue <> "All" Then 'filter by section
            vFilter += " and SectionCd='" & cmbSection.SelectedValue & "' "
            Session("vFilter") += "Section : " & cmbSection.SelectedItem.Text & "<br />"
        Else
            vFilter += " and SectionCd = any (select Property_Value from rights_list where User_Id='" & _
                Session("uid") & "' and Property='section') "
        End If

        If cmbUnit.SelectedValue <> "All" Then  'filter by units
            vFilter += " and UnitCd='" & cmbUnit.SelectedValue & "' "
            Session("vFilter") += "Unit : " & cmbUnit.SelectedItem.Text & "<br />"
        Else
            vFilter += " and UnitCd = any (select Property_Value from rights_list where User_Id='" & _
                Session("uid") & "' and Property='unit') "
        End If

        If cmbEmpType.SelectedValue <> "All" Then 'filter by employment types
            vFilter += " and EmploymentType='" & cmbEmpType.SelectedValue & "' "
            Session("vFilter") += "Rank : " & cmbEmpType.SelectedItem.Text & "<br/>"
        Else
            vFilter += " and EmploymentType = any (select Property_Value from rights_list where User_Id='" & _
                Session("uid") & "' and Property='employmenttype') "
        End If

        Session("vPeriod") = Format(CDate(cmbPeriod.SelectedItem.ToString & "/" & cmbYear.SelectedValue), "MM/dd/yyyy")
        Session("vHeader") = cmbRpt.SelectedItem.ToString
        vStart = CDate(cmbPeriod.SelectedValue & "/" & cmbYear.SelectedValue)

        cm.CommandText = "select Emp_Cd,Emp_Fname,Emp_Lname,GracePeriod from py_emp_master where " & _
            "Date_Resign is null and DateHold is null and " & _
            "Date_Retired is null " & vFilter & " order by Emp_Lname,Emp_Fname"

        Try
            rs = cm.ExecuteReader
        Catch ex As SqlClient.SqlException
            vScript = "alert(""" & ex.Message.Replace(vbCrLf, "") & """);"
            c.Close()
            c.Dispose()
            cm.Dispose()
            cmLeave.Dispose()
            Exit Sub
        End Try

        vData = ""
        Dim vDate As Date
        Do While rs.Read

            For iCtr = 1 To TxtTTLCtrls.Text
                vLeave(iCtr) = ""
            Next iCtr
            vMode = ""
            Select Case cmbRpt.SelectedValue
                Case 0  'Vl,SL and other leaves (Approved with pay)
                    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                    '' MODIFID BY:  VIC GATCHALIAN                                     ''
                    '' DATE MODIFIED: 2/23/2012                                        ''
                    '' PURPOSE: TO SUPPORT LEAVE SELECTION FLEXIBILITY INSTEAD OF      ''
                    ''          DISPLAYING ALL TYPES OF LEAVE                          ''
                    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                    If vLeaveSelect = "" Then
                        vScript = "alert('You must first select at least one type of Leave.');"
                        rs.Close()
                        c.Close()
                        c.Dispose()
                        cm.Dispose()
                        cmLeave.Dispose()
                        Exit Sub
                    End If
                    '''''''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''

                    Dim vAdd As Integer = 0
                    Dim vDay As Date
                    vTotal = 0
                    vTotalHrs = 0

                    'For iCtr = 1 To IIf(cmbPeriod.SelectedIndex = 0 Or cmbPeriod.SelectedIndex = 2, 15, Date.DaysInMonth(CDate(cmbPeriod.SelectedItem.Text).Year, CDate(cmbPeriod.SelectedItem.Text).Month) - 15)
                    vDay = vStart
                    'For iCtr = 1 To TxtTTLCtrls.Text
                    iCtr = 1
                    Do While vDay <= vEnd
                        'If cmbPeriod.SelectedIndex = 1 Or cmbPeriod.SelectedIndex = 3 Then
                        'vAdd = 15
                        'End If
                        'cmLeave.CommandText = "select Hrs_Rendered,TranCd from py_time_log_dtl where Emp_Cd='" & _
                        '    rs("Emp_Cd") & "' and LateFiled=0 and TranDate='" & Format(CDate(cmbMonth.SelectedValue & _
                        '    "/" & vAdd + iCtr & "/" & vStart.Year), "yyyy/MM/dd") & "' and exists (select Leave_Cd " & _
                        '    " from py_leave_ref where Leave_Cd=TranCd)"

                        'vDate = CDate(DateAdd(DateInterval.Day, +iCtr - 1, vStart))

                        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                        '' MODIFIED BY:  VIC GATCHALIAN                                           ''
                        '' DATE MODIFIED:  2/23/2012                                              ''
                        '' PURPOSE: TO SUPPORT RETRIEVAL OF USER SELECTED TYPE OF LEAVE INSTEAD   ''
                        ''          OF DISPLAYING ALL TYPES OF LEAVES.                            ''
                        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                        '''''''''''''''''''''''''' OLD CODE ''''''''''''''''''''''''''''''''''''''''
                        'cmLeave.CommandText = "select Hrs_Rendered,TranCd from py_time_log_dtl where Emp_Cd='" & _
                        '    rs("Emp_Cd") & "' and LateFiled=0 and TranDate='" & Format(vDay, "yyyy/MM/dd") & "' " & _
                        '    " and exists (select Leave_Cd from py_leave_ref where Leave_Cd=TranCd)"
                        '''''''''''''''''''''''''' END OLD CODE ''''''''''''''''''''''''''''''''''''
                        cmLeave.CommandText = "select Hrs_Rendered,TranCd from py_time_log_dtl where Emp_Cd='" & _
                            rs("Emp_Cd") & "' and LateFiled=0 and TranDate='" & Format(vDay, "yyyy/MM/dd") & "' " & _
                            " and TranCd in (" & vLeaveSelect & ")"
                        '''''''''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''''

                        rsLeave = cmLeave.ExecuteReader
                        'vTotalHrs = 0
                        Do While rsLeave.Read
                            If rsLeave("Hrs_Rendered") > 0 Then
                                'vDay = Format(CDate(cmbMonth.SelectedValue & "/" & iCtr & "/" & vStart.Year), "yyyy/MM/dd")
                                'vDay = Format(CDate(DateAdd(DateInterval.Day, +iCtr - 1, vStart)))
                                'vLeave(Day(vDay)) = rsLeave("TranCd") & "=" & rsLeave("Hrs_Rendered") & "<br/>"
                                vLeave(iCtr) = rsLeave("TranCd") & "=" & rsLeave("Hrs_Rendered") & "<br/>"
                                vTotalHrs += rsLeave("Hrs_Rendered")
                            End If
                        Loop
                        rsLeave.Close()

                        'Next iCtr
                        vDay = vDay.AddDays(1)
                        iCtr += 1
                    Loop
                    vTotal = vTotalHrs / 8
                    '-----------------------------------------------------------------------------------------------------------------------------
                    vMode = "leave"
                Case 1  'VL,SL and other leaves (approved w/o pay) (DONE)
                    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                    '' MODIFID BY:  VIC GATCHALIAN                                     ''
                    '' DATE MODIFIED: 2/23/2012                                        ''
                    '' PURPOSE: TO SUPPORT LEAVE SELECTION FLEXIBILITY INSTEAD OF      ''
                    ''          DISPLAYING ALL TYPES OF LEAVE                          ''
                    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                    If vLeaveSelect = "" Then
                        vScript = "alert('You must first select at least one type of Leave.');"
                        rs.Close()
                        c.Close()
                        c.Dispose()
                        cm.Dispose()
                        cmLeave.Dispose()
                        Exit Sub
                    End If
                    '''''''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''

                    Dim vAdd As Integer = 0
                    Dim vDay As Date
                    Dim LeaveType As String = ""
                    vTotal = 0
                    vTotalHrs = 0

                    'For iCtr = 1 To IIf(cmbPeriod.SelectedIndex = 0 Or cmbPeriod.SelectedIndex = 2, 15, 
                    'Date.DaysInMonth(CDate(cmbPeriod.SelectedItem.Text).Year, CDate(cmbPeriod.SelectedItem.Text).Month) - 15)
                    vDay = vStart
                    'For iCtr = 1 To TxtTTLCtrls.Text
                    iCtr = 1
                    Do While vDay <= vEnd
                        'If cmbPeriod.SelectedIndex = 1 Or cmbPeriod.SelectedIndex = 3 Then
                        '    vAdd = 15
                        'End If
                        'vDate = Format(CDate(cmbMonth.SelectedValue & _
                        '    "/" & vAdd + iCtr & "/" & vStart.Year), "yyyy/MM/dd")

                        ' vDate = CDate(DateAdd(DateInterval.Day, +iCtr - 1, vStart))
                        'cmLeave.CommandText = "select Hrs_Rendered,TranCd,TranDate from py_time_log_dtl where Emp_Cd='" & _
                        '    rs("Emp_Cd") & "' and LateFiled=0 and TranDate='" & vDay & _
                        '    "' and TranCd in ('ABSENT','TARD','UT')"
                        cmLeave.CommandText = "select Hrs_Rendered,TranCd,TranDate from py_time_log_dtl where Emp_Cd='" & _
                            rs("Emp_Cd") & "' and LateFiled=0 and TranDate='" & Format(vDay, "yyyy/MM/dd") & _
                            "' and TranCd='ABSENT'"

                        rsLeave = cmLeave.ExecuteReader
                        Do While rsLeave.Read
                            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                            '' MODIFIED BY:  VIC GATCHALIAN                                                    ''
                            '' DATE MODIFIED: 2/23/2012                                                        ''
                            '' PURPOSE: TO DISPLAY ONLY TRANSACTIONS SELECTED BY THE USER                      ''
                            '''''''''''''''''''''''' OLD CODE '''''''''''''''''''''''''''''''''''''''''''''''''''
                            'cmWOP.CommandText = "select LeaveCd,StartDate from hr_leave_application where Emp_Cd='" & _
                            '    rs("Emp_Cd") & "' and '" & Format(vDay, "yyyy/MM/dd") & "' between StartDate and EndDate and Void=0 " & _
                            '    "and DateApproved is not null and Paid=0"
                            '''''''''''''''''''''''' END OLD CODE ''''''''''''''''''''''''''''''''''''''''''''''
                            cmWOP.CommandText = "select LeaveCd,StartDate from hr_leave_application where Emp_Cd='" & _
                                rs("Emp_Cd") & "' and '" & Format(vDay, "yyyy/MM/dd") & "' between StartDate and EndDate and Void=0 " & _
                                "and DateApproved is not null and Paid=0 and LeaveCd in (" & vLeaveSelect & ")"
                            '''''''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''''''''''''''

                            rsWOP = cmWOP.ExecuteReader

                            If rsWOP.Read Then
                                LeaveType = rsWOP("LeaveCd")
                                If rsLeave("Hrs_Rendered") > 0 Then
                                    'vDay = Format(CDate(cmbMonth.SelectedValue & "/" & iCtr & "/" & vStart.Year), "yyyy/MM/dd")
                                    'vDay = Format(CDate(DateAdd(DateInterval.Day, +iCtr - 1, vStart)))
                                    'vLeave(Day(vDay)) = LeaveType & "=" & rsLeave("Hrs_Rendered") & "<br/>"
                                    vLeave(iCtr) = LeaveType & "=" & rsLeave("Hrs_Rendered") & "<br/>"
                                    vTotalHrs += rsLeave("Hrs_Rendered")
                                    vTotal += 1
                                End If
                            End If
                            rsWOP.Close()
                        Loop
                        rsLeave.Close()
                        ' Next iCtr
                        vDay = vDay.AddDays(1)
                        iCtr += 1
                    Loop
                    cmWOP.Dispose()
                    vTotalHrs = vTotalHrs / 8      'converted into days

                    vMode = "leave"
                    '-----------------------------------------------------------------------------------------------------------------------------

                Case 2  'VL,SL and other leaves (canceled/void)
                    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                    '' MODIFIED BY:  VIC GATCHALIAN                                       ''
                    '' DATE MODIFIED:  2/23/2012                                          ''
                    '' PURPOSE:  TO DISPLAY ONLY TRANSACTIONS SELECTED BY THE USER        ''
                    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                    ''''''''''''''''''''''' OLD CODE '''''''''''''''''''''''''''''''''''''''
                    'cmLeave.CommandText = "select StartDate,sum(DaysLeave) * 8 as DumpField from " & _
                    '    "hr_leave_application where Emp_Cd='" & rs("Emp_Cd") & _
                    '    "' and Void=1 and LeaveCd<>'OT' and StartDate between '" & _
                    '    Format(vStart, "yyyy/MM/dd") & "' and '" & Format(vEnd, "yyyy/MM/dd") & "' GROUP BY StartDate"
                    ''''''''''''''''''''''' END OLD CODE ''''''''''''''''''''''''''''''''''''
                    If vLeaveSelect = "" Then
                        vScript = "alert('You must first select at least one type of Leave.');"
                        rs.Close()
                        c.Close()
                        c.Dispose()
                        cm.Dispose()
                        cmLeave.Dispose()
                        Exit Sub
                    End If

                    cmLeave.CommandText = "select StartDate,sum(DaysLeave) * 8 as DumpField from " & _
                        "hr_leave_application where Emp_Cd='" & rs("Emp_Cd") & _
                        "' and Void=1 and LeaveCd in (" & vLeaveSelect & ") and StartDate between '" & _
                        Format(vStart, "yyyy/MM/dd") & "' and '" & Format(vEnd, "yyyy/MM/dd") & "' GROUP BY StartDate"
                    ''''''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''''

                    '-----------------------------------------------------------------------------------------------------------------------------
                    vMode = "leave"
                Case 3      'VL,SL and other Leave Applications (Pending for Approval) Report
                    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                    '' MODIFID BY:  VIC GATCHALIAN                                     ''
                    '' DATE MODIFIED: 4/26/2012                                        ''
                    '' PURPOSE: TO SHOW THE LEAVE APPLICATIONS PENDING FOR APPROVAL    ''
                    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                    If vLeaveSelect = "" Then
                        vScript = "alert('You must first select at least one type of Leave.');"
                        rs.Close()
                        c.Close()
                        c.Dispose()
                        cm.Dispose()
                        cmLeave.Dispose()
                        Exit Sub
                    End If

                    cmLeave.CommandText = "select StartDate,sum(DaysLeave) * 8 as DumpField from " & _
                        "hr_leave_application where Emp_Cd='" & rs("Emp_Cd") & _
                        "' and Void=0 and LeaveCd in (" & vLeaveSelect & ") and StartDate between '" & _
                        Format(vStart, "yyyy/MM/dd") & "' and '" & Format(vEnd, "yyyy/MM/dd") & _
                        "' and ((ApprovedBy is not null and DateApproved is null) or " & _
                        "(DateApproved is not null and RecommendedBy is not null and DateRecommended is null) or " & _
                        "(DateRecommended is not null and NotedBy is not null and Datenoted is null)) GROUP BY StartDate"

                    vMode = "leave"
                    ''''''''''''''''''''''' END OF MODIFICATION '''''''''''''''''''''''''''''
                Case 4  'overtime report
                    cmLeave.CommandText = "select sum(Hrs_Rendered) as DumpField,TranDate as StartDate from " & _
                        "py_time_log_dtl where Emp_Cd='" & rs("Emp_Cd") & _
                        "' and LateFiled=0 AND TranCd in ('A1','B1','B3','C1','C3','D1','D3','E1','E3','F1','F3','G1','G3') " & _
                        "and TranDate between '" & Format(vStart, "yyyy/MM/dd") & "' and '" & Format(vEnd, "yyyy/MM/dd") & "' GROUP BY TranDate"
                    '-----------------------------------------------------------------------------------------------------------------------------

                Case 5  'tardiness beyond grace period

                    ''''' modified by vic gatchalian on 7/26/2011
                    'TardinessWithGracePeriod(vLeave, c, vStart, vEnd, rs("Emp_Cd"), IIf(IsDBNull(rs("GracePeriod")), 0, rs("GracePeriod")))
                    vShowGrace = "<th class='titleBar' style='width: 84px; border: solid 1px #8b8b8a;'>Grace Period (mins.)</th>"
                    cmLeave.CommandText = "select sum(Hrs_Rendered) as DumpField,TranDate as StartDate " & _
                        "from py_time_log_dtl where Emp_Cd='" & rs("Emp_Cd") & _
                        "' and LateFiled=0 AND TranCd='TARD' and TranDate between '" & _
                        Format(vStart, "yyyy/MM/dd") & "' and '" & Format(vEnd, "yyyy/MM/dd") & "' GROUP BY TranDate"
                    ''''''''''   end modification''''''''''''''''
                    '-----------------------------------------------------------------------------------------------------------------------------

                Case 7  'tardiness without grace period (DONE)
                    TardinessWithoutGracePeriod(vLeave, c, vStart, vEnd, rs("Emp_Cd"))
                    '-----------------------------------------------------------------------------------------------------------------------------

                Case 8  'undertime report
                    cmLeave.CommandText = "select sum(Hrs_Rendered) as DumpField,TranDate as StartDate " & _
                        "from py_time_log_dtl where Emp_Cd='" & rs("Emp_Cd") & _
                        "' and LateFiled=0 AND TranCd='UT' and TranDate between '" & _
                        Format(vStart, "yyyy/MM/dd") & "' and '" & Format(vEnd, "yyyy/MM/dd") & "' GROUP BY TranDate"
                    '-----------------------------------------------------------------------------------------------------------------------------
                Case 9  'manhours report
                    '''''''''   added by vic gatchalian on 7/26/2011
                    cmLeave.CommandText = "select round(cast(DATEDIFF(mi," & _
                        "cast(year(tran_date) as varchar) + '/' + cast(month(tran_date) as varchar) + '/' + " & _
                        "cast(day(tran_date) as varchar) + ' ' + time_in," & _
                        "cast(year(time_outdate) as varchar) + '/'+ cast(month(time_outdate) as varchar)+ '/'+" & _
                        "cast(day(time_outdate) as varchar)+' ' + time_out) as decimal) / 60,2) as DumpField," & _
                        "Tran_Date as StartDate from py_time_log where Emp_Cd='" & rs("Emp_Cd") & "' and Tran_Date between '" & _
                        Format(vStart, "yyyy/MM/dd") & "' and '" & Format(vEnd, "yyyy/MM/dd") & "'"
                    '''''''''''''''''' end modification ''''''''''''''''''''
                Case 10 'night diff report
                    cmLeave.CommandText = "select sum(Hrs_Rendered) as DumpField,TranDate as StartDate " & _
                        "from py_time_log_dtl where Emp_Cd='" & rs("Emp_Cd") & _
                        "' and TranCd in ('A2','A3','A4','B2','B4','C2','C4','D2','D4','E2','E4','F2','F4','G2','G4')" & _
                        " and LateFiled=0 and TranDate between '" & _
                        Format(vStart, "yyyy/MM/dd") & "' and '" & Format(vEnd, "yyyy/MM/dd") & "' GROUP BY TranDate"
            End Select

            If cmbRpt.SelectedValue <> 0 And cmbRpt.SelectedValue <> 1 And cmbRpt.SelectedValue <> 7 Then '_
                'And cmbRpt.SelectedValue <> 5 Then
                Try
                    rsLeave = cmLeave.ExecuteReader

                    'vDate = CDate(DateAdd(DateInterval.Day, +iCtr - 1, vStart))
                    vDate = vStart
                    Do While rsLeave.Read
                        vDiff = DateDiff(DateInterval.Day, vStart, CDate(rsLeave("StartDate")))
                        vLeave(vDiff + 1) = IIf(IsDBNull(rsLeave("DumpField")), 0, rsLeave("DumpField"))
                    Loop
                    'If rsLeave.HasRows Then
                    '    For iCtr = 0 To UBound(vLeave)
                    '        'vLeave(Day(rsLeave("StartDate"))) = rsLeave("DumpField")
                    '        If rsLeave.Read() Then
                    '            vLeave(iCtr) = rsLeave("DumpField")
                    '        End If
                    '    Next
                    'End If

                    'Do While rsLeave.Read
                    '    Select Case cmbPeriod.SelectedIndex
                    '        Case 0, 2
                    '            vLeave(Day(rsLeave("StartDate"))) = rsLeave("DumpField")

                    '        Case 1, 3
                    '            vLeave(Day(rsLeave("StartDate")) - 15) = rsLeave("DumpField")
                    '    End Select
                    'Loop
                    rsLeave.Close()
                Catch ex As SqlClient.SqlException
                    vScript = "alert(""" & ex.Message.Replace(vbCrLf, "") & """);"
                    c.Close()
                    c.Dispose()
                    cm.Dispose()
                    cmLeave.Dispose()
                    Exit Sub
                End Try

            End If

            If cmbRpt.SelectedValue > 1 Then
                vTotal = 0
                vTotalHrs = 0
                For iCtr = 1 To TxtTTLCtrls.Text
                    If vLeave(iCtr) <> "" And vLeave(iCtr) <> "0" Then
                        vTotal += 1
                        vTotalHrs += Val(vLeave(iCtr))
                    End If
                Next iCtr
            End If

            If (chkShow.Checked And vTotal <> 0) Or Not chkShow.Checked Then
                vData += "<tr class='" & vSW & "'><td class='labelBR' style='valign'>&nbsp;</td>" & _
                    "<td class='labelBL' align='left'>" & rs("Emp_Cd") & "=>&nbsp;" & rs("Emp_Lname") & ", " & rs("Emp_Fname") & "</td>" & _
                    IIf(cmbRpt.SelectedValue = 5, "<td align='center'>" & Format(rs("GracePeriod"), "00") & "</td>", "") & _
                    "<td class='labelBC'><a href=""javascript:ModifyMe('" & rs("Emp_Cd") & "','" & _
                        Format(vStart, "yyyy/MM/dd") & "','" & vMode & "');"">" & IIf(IsNumeric(vLeave(1)), Math.Round(Val(vLeave(1)), 2), vLeave(1)) & "</a>&nbsp;</td>" & _
                    "<td class='labelBC'><a href=""javascript:ModifyMe('" & rs("Emp_Cd") & "','" & _
                        Format(vStart.AddDays(1), "yyyy/MM/dd") & "','" & vMode & "');"">" & IIf(IsNumeric(vLeave(2)), Math.Round(Val(vLeave(2)), 2), vLeave(2)) & "</a>&nbsp;</td>" & _
                    "<td class='labelBC'><a href=""javascript:ModifyMe('" & rs("Emp_Cd") & "','" & _
                        Format(vStart.AddDays(2), "yyyy/MM/dd") & "','" & vMode & "');"">" & IIf(IsNumeric(vLeave(3)), Math.Round(Val(vLeave(3)), 2), vLeave(3)) & "</a>&nbsp;</td>" & _
                    "<td class='labelBC'><a href=""javascript:ModifyMe('" & rs("Emp_Cd") & "','" & _
                        Format(vStart.AddDays(3), "yyyy/MM/dd") & "','" & vMode & "');"">" & IIf(IsNumeric(vLeave(4)), Math.Round(Val(vLeave(4)), 2), vLeave(4)) & "</a>&nbsp;</td>" & _
                    "<td class='labelBC'><a href=""javascript:ModifyMe('" & rs("Emp_Cd") & "','" & _
                        Format(vStart.AddDays(4), "yyyy/MM/dd") & "','" & vMode & "');"">" & IIf(IsNumeric(vLeave(5)), Math.Round(Val(vLeave(5)), 2), vLeave(5)) & "</a>&nbsp;</td>" & _
                    "<td class='labelBC'><a href=""javascript:ModifyMe('" & rs("Emp_Cd") & "','" & _
                        Format(vStart.AddDays(5), "yyyy/MM/dd") & "','" & vMode & "');"">" & IIf(IsNumeric(vLeave(6)), Math.Round(Val(vLeave(6)), 2), vLeave(6)) & "</a>&nbsp;</td>" & _
                    "<td class='labelBC'><a href=""javascript:ModifyMe('" & rs("Emp_Cd") & "','" & _
                        Format(vStart.AddDays(6), "yyyy/MM/dd") & "','" & vMode & "');"">" & IIf(IsNumeric(vLeave(7)), Math.Round(Val(vLeave(7)), 2), vLeave(7)) & "</a>&nbsp;</td>" & _
                    "<td class='labelBC'><a href=""javascript:ModifyMe('" & rs("Emp_Cd") & "','" & _
                        Format(vStart.AddDays(7), "yyyy/MM/dd") & "','" & vMode & "');"">" & IIf(IsNumeric(vLeave(8)), Math.Round(Val(vLeave(8)), 2), vLeave(8)) & "</a>&nbsp;</td>" & _
                    "<td class='labelBC'><a href=""javascript:ModifyMe('" & rs("Emp_Cd") & "','" & _
                        Format(vStart.AddDays(8), "yyyy/MM/dd") & "','" & vMode & "');"">" & IIf(IsNumeric(vLeave(9)), Math.Round(Val(vLeave(9)), 2), vLeave(9)) & "</a>&nbsp;</td>" & _
                    "<td class='labelBC'><a href=""javascript:ModifyMe('" & rs("Emp_Cd") & "','" & _
                        Format(vStart.AddDays(9), "yyyy/MM/dd") & "','" & vMode & "');"">" & IIf(IsNumeric(vLeave(10)), Math.Round(Val(vLeave(10)), 2), vLeave(10)) & "</a>&nbsp;</td>" & _
                    "<td class='labelBC'><a href=""javascript:ModifyMe('" & rs("Emp_Cd") & "','" & _
                        Format(vStart.AddDays(10), "yyyy/MM/dd") & "','" & vMode & "');"">" & IIf(IsNumeric(vLeave(11)), Math.Round(Val(vLeave(11)), 2), vLeave(11)) & "</a>&nbsp;</td>" & _
                    "<td class='labelBC'><a href=""javascript:ModifyMe('" & rs("Emp_Cd") & "','" & _
                        Format(vStart.AddDays(11), "yyyy/MM/dd") & "','" & vMode & "');"">" & IIf(IsNumeric(vLeave(12)), Math.Round(Val(vLeave(12)), 2), vLeave(12)) & "</a>&nbsp;</td>" & _
                    "<td class='labelBC'><a href=""javascript:ModifyMe('" & rs("Emp_Cd") & "','" & _
                        Format(vStart.AddDays(12), "yyyy/MM/dd") & "','" & vMode & "');"">" & IIf(IsNumeric(vLeave(13)), Math.Round(Val(vLeave(13)), 2), vLeave(13)) & "</a>&nbsp;</td>" & _
                    "<td class='labelBC'><a href=""javascript:ModifyMe('" & rs("Emp_Cd") & "','" & _
                        Format(vStart.AddDays(13), "yyyy/MM/dd") & "','" & vMode & "');"">" & IIf(IsNumeric(vLeave(14)), Math.Round(Val(vLeave(14)), 2), vLeave(14)) & "</a>&nbsp;</td>" & _
                    "<td class='labelBC'><a href=""javascript:ModifyMe('" & rs("Emp_Cd") & "','" & _
                        Format(vStart.AddDays(14), "yyyy/MM/dd") & "','" & vMode & "');"">" & IIf(IsNumeric(vLeave(15)), Math.Round(Val(vLeave(15)), 2), vLeave(15)) & "</a>&nbsp;</td>" & _
                    "<td class='labelBC'><a href=""javascript:ModifyMe('" & rs("Emp_Cd") & "','" & _
                        Format(vStart.AddDays(15), "yyyy/MM/dd") & "','" & vMode & "');"">" & IIf(IsNumeric(vLeave(16)), Math.Round(Val(vLeave(16)), 2), vLeave(16)) & "</a>&nbsp;</td>" & _
                    "<td class='labelBR'>" & Math.Round(vTotalHrs, 2) & "&nbsp;</td>" & _
                    "<td class='labelBR'>" & Math.Round(vTotal, 2) & "&nbsp;</td>" & _
                    "</tr>"
                If vSW = "odd" Then
                    vSW = "even"
                Else
                    vSW = "odd"
                End If
            End If
        Loop

        Session.Remove("vList")
        vList = "<table style='width: 920px' border='1' cellpadding='0' cellspacing='0' class='label'>" & _
                "<tr><th>&nbsp;</th><th style='width: 421px'>Employee Code/Name</th>" & _
                IIf(cmbRpt.SelectedValue = 5, "<th class='titleBar' style='border: solid 1px #8b8b8a;'>Grace Period(mins.)</th>", "") & _
                "<th style='width: 32px'>" & _
                lblDay1.Text & "</th><th style='width: 36px'>" & _
                lblDay2.Text & "</th><th style='width: 36px'>" & _
                lblDay3.Text & "</th><th style='width: 36px'>" & _
                lblDay4.Text & "</th><th style='width: 36px'>" & _
                lblDay5.Text & "</th><th style='width: 36px'>" & _
                lblDay6.Text & "</th><th style='width: 36px'>" & _
                lblDay7.Text & "</th><th style='width: 36px'>" & _
                lblDay8.Text & "</th><th style='width: 36px'>" & _
                lblDay9.Text & "</th><th style='width: 36px'>" & _
                lblDay10.Text & "</th><th style='width: 36px'>" & _
                lblDay11.Text & "</th><th style='width: 36px'>" & _
                lblDay12.Text & "</th><th style='width: 36px'>" & _
                lblDay13.Text & "</th><th style='width: 36px'>" & _
                lblDay14.Text & "</th><th style='width: 36px'>" & _
                lblDay15.Text & "</th><th style='width: 36px'>" & _
                lblDay16.Text & "</th><th style='width: 36px'>" & _
                "Total (hrs)</th><th>Total (Freq)</th></tr>"
        vList += vData
        vList += "</table>"
        Session("vList") = vList

        rs.Close()
        cm.Dispose()
        cmLeave.Dispose()
        c.Close()
    End Sub
    Private Sub TardinessWithoutGracePeriod(ByRef vLeave() As String, ByRef c As SqlClient.SqlConnection, _
        ByRef vStart As Date, ByRef vEnd As Date, ByVal pId As String)

        Dim vTmpStart As Date = vStart
        Dim vAdd As Integer = 0
        Dim vGrace As Decimal = 0
        Dim vStartTime As String = ""
        Dim vIn As String = ""
        Dim vFlexi As Integer = 0
        Dim cmLeave As New SqlClient.SqlCommand
        Dim rsLeave As SqlClient.SqlDataReader
        Dim iCtr As Integer

        cmLeave.Connection = c
        cmLeave.CommandText = "SELECT Allow_Reg_Timein FROM py_emp_master WHERE Emp_Cd='" & pId & "'"

        Try
            rsLeave = cmLeave.ExecuteReader
            If rsLeave.Read Then
                vFlexi = IIf(rsLeave("Allow_Reg_Timein") = 1, 0, 1)
            End If
            rsLeave.Close()
        Catch ex As SqlClient.SqlException
            vScript = "alert(""" & ex.Message.Replace(vbCrLf, "") & """);"
        End Try

        iCtr = 1
        Do While vTmpStart <= vEnd
            vStartTime = ""
            vIn = ""

            cmLeave.CommandText = "SELECT Tran_Date,Sched_In,Time_In FROM py_time_log WHERE Emp_Cd='" & _
                pId & "' AND Tran_Date='" & Format(vTmpStart, "yyyy/MM/dd") & "'"

            Try
                rsLeave = cmLeave.ExecuteReader
                If rsLeave.Read Then
                    vIn = IIf(IsDBNull(rsLeave("Time_In")), "", Format(CDate(rsLeave("Tran_Date")), "yyyy/MM/dd") & " " & rsLeave("Time_In"))
                    vStartTime = IIf(IsDBNull(rsLeave("Sched_In")), "", rsLeave("Sched_In"))

                    If vIn <> "" And vStartTime <> "" And IsDate(vIn) And IsDate(vStartTime) Then
                        If CDate(vIn) > CDate(vStartTime) Then  'with tardiness
                            If chkFlexi.Checked And vFlexi = 1 Then
                                vLeave(iCtr) = 0
                            Else
                                vLeave(iCtr) = Math.Round(DateDiff(DateInterval.Minute, CDate(vStartTime), CDate(vIn)) / 60, 2)
                            End If
                        End If
                    End If
                End If
                rsLeave.Close()
            Catch ex As SqlClient.SqlException
                vScript = "alert(""" & ex.Message.Replace(vbCrLf, "") & """);"
                Exit Sub
            End Try
            vTmpStart = vTmpStart.AddDays(1)
            iCtr += 1
        Loop
       
    End Sub
    Private Sub TardinessWithGracePeriod(ByRef vLeave() As String, ByRef c As SqlClient.SqlConnection, _
        ByRef vStart As Date, ByRef vEnd As Date, ByVal pId As String, ByVal pGrace As Integer)

        Dim vTmpStart As Date = vStart
        Dim vAdd As Integer = 0
        Dim vGrace As Decimal = 0
        Dim vStartTime As String = ""
        Dim vIn As String = ""
        Dim vFlexi As Integer = 0
        Dim cmLeave As New SqlClient.SqlCommand
        Dim rsLeave As SqlClient.SqlDataReader
        Dim iCtr As Integer

        cmLeave.Connection = c
        vShowGrace = "<th class='titleBar' style='width: 84px; border: solid 1px #8b8b8a;'>Grace Period (mins.)</th>"

        iCtr = 1
        Do While vTmpStart <= vEnd
            vStartTime = ""
            vIn = ""

            cmLeave.CommandText = "SELECT Tran_Date,Sched_In,Time_In FROM py_time_log WHERE Emp_Cd='" & _
                pId & "' AND Tran_Date='" & Format(vTmpStart, "yyyy/MM/dd") & "'"

            Try
                rsLeave = cmLeave.ExecuteReader

                If rsLeave.Read Then
                    vIn = IIf(IsDBNull(rsLeave("Time_In")), "", Format(CDate(rsLeave("Tran_Date")), "yyyy/MM/dd") & " " & rsLeave("Time_In"))
                    vStartTime = IIf(IsDBNull(rsLeave("Sched_In")), "", rsLeave("Sched_In"))
                    If vStartTime <> "" Then vStartTime = Format(CDate(vStartTime).AddMinutes(pGrace), "yyyy/MM/dd HH:mm:00")

                    If vIn <> "" And vStartTime <> "" And IsDate(vIn) And IsDate(vStartTime) Then
                        If CDate(vIn) > CDate(vStartTime) Then  'with tardiness
                            vLeave(iCtr) = Math.Round(DateDiff(DateInterval.Minute, CDate(vStartTime), CDate(vIn)) / 60, 2)
                        End If
                    End If
                End If

                rsLeave.Close()
            Catch ex As SqlClient.SqlException
                vScript = "alert(""" & ex.Message.Replace(vbCrLf, "") & """);"
                Exit Sub
            End Try

            vTmpStart = vTmpStart.AddDays(1)
            iCtr += 1
        Loop

    End Sub
    Protected Sub cmbRpt_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbRpt.Init
        cmbRpt.Attributes.Add("onchange", "chk(this);")
    End Sub

    Protected Sub cmbPayMode_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbPayMode.SelectedIndexChanged
        GetPeriods()
    End Sub

    Protected Sub cmdSet_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSet.Click
        RefreshData()
    End Sub
End Class
